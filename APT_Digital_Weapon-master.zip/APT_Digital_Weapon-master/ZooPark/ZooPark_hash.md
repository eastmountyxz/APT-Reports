|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[28649ff242fca31230e8f3210eda9056](https://www.virustotal.com/gui/file/28649ff242fca31230e8f3210eda9056)|Android||2019-08-29 02:20:35|28649ff242fca31230e8f3210eda9056.virus|
|[0745b0957aab92b6a09645e076b4f339](https://www.virustotal.com/gui/file/0745b0957aab92b6a09645e076b4f339)|Android||2019-05-30 16:38:36|/data/maxplayer.apk|
|[4d8ddec9243bc6ac0419c561fe413cfc](https://www.virustotal.com/gui/file/4d8ddec9243bc6ac0419c561fe413cfc)|Android||2019-03-31 13:22:44|kmplayer.apk|
|[366defa5b85a044aac3dcc96ca4b7fbe](https://www.virustotal.com/gui/file/366defa5b85a044aac3dcc96ca4b7fbe)|unknown||2019-02-11 20:23:39|1910f5ddb0fc0438a3e2a553c97559557898e6310bf7e37b13cf3013fd66ea75.vbs.bin|
|[58cc3935fbfdb2990304b99fbb919dad](https://www.virustotal.com/gui/file/58cc3935fbfdb2990304b99fbb919dad)|Win32 EXE||2019-01-11 19:10:14|n.v|
|[539d00b4f198967d32e3289d5f7a1bf4](https://www.virustotal.com/gui/file/539d00b4f198967d32e3289d5f7a1bf4)|unknown|Nemucod|2018-11-06 07:59:21|%APPDATA%\roaming\microsoft\protect\update.vbs|
|[c7e4d75caa8e07847e47eadce229c288](https://www.virustotal.com/gui/file/c7e4d75caa8e07847e47eadce229c288)|Android||2018-10-25 03:50:37|3aa28d2829ace4613bab93f2cd51e15bd1dab3fe961586e72c0a2d04cd32a968.bin|
|[345c2325dd633099f29b6d7141a4703d](https://www.virustotal.com/gui/file/345c2325dd633099f29b6d7141a4703d)|Android||2018-10-21 02:30:50|62778520e27b393323ad0469cc8405fe7d1430dbd2eeaf016499f6eb48ad4ad8.bin|
|[a7d00c8629079f944b61c4dd5c77c8fb](https://www.virustotal.com/gui/file/a7d00c8629079f944b61c4dd5c77c8fb)|Android||2018-09-11 06:41:59| |
|[a7d00c8629079f944b61c4dd5c77c8fb](https://www.virustotal.com/gui/file/a7d00c8629079f944b61c4dd5c77c8fb)|Android||2018-09-11 06:41:59| |
|[1874aa71c9b13eec5b587e8ed6a71606](https://www.virustotal.com/gui/file/1874aa71c9b13eec5b587e8ed6a71606)|Android||2018-08-30 02:21:02|1874aa71c9b13eec5b587e8ed6a71606.virus|
|[e3de33496a50de23b997d43dcc42d4ed](https://www.virustotal.com/gui/file/e3de33496a50de23b997d43dcc42d4ed)|unknown|Nemucod|2018-08-25 07:46:28|=?UTF-8?B?2KrZgtiv2YrYsSDZhdmI2YLZgS3Yrtin2LUg2KjYp9mE2KXYrtmI2KkudmJz?=|
|[c9410a6c342327bdef6cd777344e4b35](https://www.virustotal.com/gui/file/c9410a6c342327bdef6cd777344e4b35)|unknown||2018-07-30 09:46:31|تقدير موقف-خاص بالإخوة.doc.vbs|
|[191cc5d165472ae19e665821be71c282](https://www.virustotal.com/gui/file/191cc5d165472ae19e665821be71c282)|Android||2018-05-23 03:20:13|191cc5d165472ae19e665821be71c282.virus|
|[a856f9de281cadad7142828dda3843b4](https://www.virustotal.com/gui/file/a856f9de281cadad7142828dda3843b4)|Android||2018-05-21 02:26:19|a856f9de281cadad7142828dda3843b4.virus|
|[b44b91b14f176fbf93d998141931a4aa](https://www.virustotal.com/gui/file/b44b91b14f176fbf93d998141931a4aa)|Android||2018-05-08 13:02:59|309523ecd0c4bc5e337005e71666da3711d0cda519100d5d5aa019b22dc61cbd.bin|
|[b44b91b14f176fbf93d998141931a4aa](https://www.virustotal.com/gui/file/b44b91b14f176fbf93d998141931a4aa)|Android||2018-05-08 13:02:59|309523ecd0c4bc5e337005e71666da3711d0cda519100d5d5aa019b22dc61cbd.bin|
|[5ad36f6dd060e52771a8e4a1dd90c50c](https://www.virustotal.com/gui/file/5ad36f6dd060e52771a8e4a1dd90c50c)|Android||2018-05-08 13:02:07|ef4d8bf8fec822eceb6bb8644a2a07972419e851c7c26e483620d9ca7c5e806e.bin|
|[5ad36f6dd060e52771a8e4a1dd90c50c](https://www.virustotal.com/gui/file/5ad36f6dd060e52771a8e4a1dd90c50c)|Android||2018-05-08 13:02:07|ef4d8bf8fec822eceb6bb8644a2a07972419e851c7c26e483620d9ca7c5e806e.bin|
|[519018ecfc50c0cf6cd0c88cc41b2a69](https://www.virustotal.com/gui/file/519018ecfc50c0cf6cd0c88cc41b2a69)|Android||2018-05-08 13:00:51|adc712518e21d182acbf154a12c3d451bf82f1981e4d195fa2e33de32aa19dc5.bin|
|[519018ecfc50c0cf6cd0c88cc41b2a69](https://www.virustotal.com/gui/file/519018ecfc50c0cf6cd0c88cc41b2a69)|Android||2018-05-08 13:00:51|adc712518e21d182acbf154a12c3d451bf82f1981e4d195fa2e33de32aa19dc5.bin|
|[232bd3dde6914db0a3dbfc21ed178887](https://www.virustotal.com/gui/file/232bd3dde6914db0a3dbfc21ed178887)|Android||2018-05-08 13:00:07|141b76bcd7a6ae41feccb263b0bda7879eca2f42974e124acccb38810cee52c7.bin|
|[232bd3dde6914db0a3dbfc21ed178887](https://www.virustotal.com/gui/file/232bd3dde6914db0a3dbfc21ed178887)|Android||2018-05-08 13:00:07|141b76bcd7a6ae41feccb263b0bda7879eca2f42974e124acccb38810cee52c7.bin|
|[5efddd7f0fc2125e78a2ca18b68464ec](https://www.virustotal.com/gui/file/5efddd7f0fc2125e78a2ca18b68464ec)|Android||2018-05-03 17:21:06|5efddd7f0fc2125e78a2ca18b68464ec.virus|
|[5efddd7f0fc2125e78a2ca18b68464ec](https://www.virustotal.com/gui/file/5efddd7f0fc2125e78a2ca18b68464ec)|Android||2018-05-03 17:21:06|5efddd7f0fc2125e78a2ca18b68464ec.virus|
|[699a7eedd244f402303bcffdee1f0ed1](https://www.virustotal.com/gui/file/699a7eedd244f402303bcffdee1f0ed1)|Android||2018-04-24 19:12:48|7a7eee78dfffa5974a2da9bdd3337fb16e5e1d658cbe5284ef352114ef446f6a.bin|
|[699a7eedd244f402303bcffdee1f0ed1](https://www.virustotal.com/gui/file/699a7eedd244f402303bcffdee1f0ed1)|Android||2018-04-24 19:12:48|7a7eee78dfffa5974a2da9bdd3337fb16e5e1d658cbe5284ef352114ef446f6a.bin|
|[cb67abd070ae188390fc040cbe60e677](https://www.virustotal.com/gui/file/cb67abd070ae188390fc040cbe60e677)|Android||2017-09-24 18:35:23|cb67abd070ae188390fc040cbe60e677.virus|
|[cb67abd070ae188390fc040cbe60e677](https://www.virustotal.com/gui/file/cb67abd070ae188390fc040cbe60e677)|Android||2017-09-24 18:35:23|cb67abd070ae188390fc040cbe60e677.virus|
|[e2f62b5acf3795a62e9d54e1301c4e7b](https://www.virustotal.com/gui/file/e2f62b5acf3795a62e9d54e1301c4e7b)|Android||2017-08-19 09:06:40|e2f62b5acf3795a62e9d54e1301c4e7b.virus|
|[e2f62b5acf3795a62e9d54e1301c4e7b](https://www.virustotal.com/gui/file/e2f62b5acf3795a62e9d54e1301c4e7b)|Android||2017-08-19 09:06:40|e2f62b5acf3795a62e9d54e1301c4e7b.virus|
|[ac4402e04de0949d7beed975db84e594](https://www.virustotal.com/gui/file/ac4402e04de0949d7beed975db84e594)|Android||2017-04-08 23:07:33|ac4402e04de0949d7beed975db84e594.virus|
|[ac4402e04de0949d7beed975db84e594](https://www.virustotal.com/gui/file/ac4402e04de0949d7beed975db84e594)|Android||2017-04-08 23:07:33|ac4402e04de0949d7beed975db84e594.virus|
|[6a388edbce88bb0331ae875ceeb2f319](https://www.virustotal.com/gui/file/6a388edbce88bb0331ae875ceeb2f319)|Android||2016-11-26 08:32:10|041b4d2280cae9720a62350de4541172933909380bb02701a7d20f87e670bac4.bin|
|[6a388edbce88bb0331ae875ceeb2f319](https://www.virustotal.com/gui/file/6a388edbce88bb0331ae875ceeb2f319)|Android||2016-11-26 08:32:10|041b4d2280cae9720a62350de4541172933909380bb02701a7d20f87e670bac4.bin|
|[7d7ad116e6a42d4e518378e2313e9392](https://www.virustotal.com/gui/file/7d7ad116e6a42d4e518378e2313e9392)|Android||2016-11-06 11:50:21|f7fe4e299599a60a4797f9a13468e366394dc2d86ab768f681a0876d8ff052e0.bin|
|[7d7ad116e6a42d4e518378e2313e9392](https://www.virustotal.com/gui/file/7d7ad116e6a42d4e518378e2313e9392)|Android||2016-11-06 11:50:21|f7fe4e299599a60a4797f9a13468e366394dc2d86ab768f681a0876d8ff052e0.bin|
|[5b0431bbebdc48d2fa37882f7343b011](https://www.virustotal.com/gui/file/5b0431bbebdc48d2fa37882f7343b011)|Win32 EXE||2016-10-03 23:37:13|d493a43aff4d5909df569c6eb8e03cef7596266e|
|[b714b092d2f28fcf78ef8d02b46dbf9c](https://www.virustotal.com/gui/file/b714b092d2f28fcf78ef8d02b46dbf9c)|Android||2016-09-12 16:23:07|b714b092d2f28fcf78ef8d02b46dbf9c.virus|
|[b714b092d2f28fcf78ef8d02b46dbf9c](https://www.virustotal.com/gui/file/b714b092d2f28fcf78ef8d02b46dbf9c)|Android||2016-09-12 16:23:07|b714b092d2f28fcf78ef8d02b46dbf9c.virus|
|[31edb7591bfeeb72e0652c17781640af](https://www.virustotal.com/gui/file/31edb7591bfeeb72e0652c17781640af)|Win32 EXE|dynamer|2016-08-18 16:20:51|31edb7591bfeeb72e0652c17781640af.virus|
|[ec5a6f0e743f4b858aba9de96a33fb0c](https://www.virustotal.com/gui/file/ec5a6f0e743f4b858aba9de96a33fb0c)|Android||2016-01-27 07:43:30|ec5a6f0e743f4b858aba9de96a33fb0c.virus|
|[ec5a6f0e743f4b858aba9de96a33fb0c](https://www.virustotal.com/gui/file/ec5a6f0e743f4b858aba9de96a33fb0c)|Android||2016-01-27 07:43:30|ec5a6f0e743f4b858aba9de96a33fb0c.virus|
|[272c4558ea51c2a7d0a257b7d2756bd7](https://www.virustotal.com/gui/file/272c4558ea51c2a7d0a257b7d2756bd7)|Android||2020-03-28 20:33:46|KMPlayer.v.1.1-1[1].apk|
