**NAME:**  
ZooPark  
  
**Alias**  
军刀狮, APT-C-38, ZooPark  

**Description**:   
ZooPark, named by Kaspersky, is a sophisticated cyberespionage operation that has been focusing on Android device users in the Middle East countries. The threat actors behind ZooPark infect Android devices using at least four generations of the espionage malware since at least 2015.
  
**References**:  
https://usa.kaspersky.com/about/press-releases/2018_zoopark-new-android-based-malware