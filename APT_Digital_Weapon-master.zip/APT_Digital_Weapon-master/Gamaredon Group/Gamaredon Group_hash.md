|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[3774879dc6653a9c9649fa10e39d7230](https://www.virustotal.com/gui/file/3774879dc6653a9c9649fa10e39d7230)|DOC||2019-12-28 04:56:42|pos.dot|
|[f54c06edae339a973fed6c2f5fb60ca2](https://www.virustotal.com/gui/file/f54c06edae339a973fed6c2f5fb60ca2)|DOCX||2019-12-27 16:36:31|71001791.docx|
|[9ee8bd0d8ba5f281fa92ff22f79b751d](https://www.virustotal.com/gui/file/9ee8bd0d8ba5f281fa92ff22f79b751d)|DOC||2019-12-06 11:05:46|nato.dot|
|[4affa059d3e5f3bb7983d9a05c4b111b](https://www.virustotal.com/gui/file/4affa059d3e5f3bb7983d9a05c4b111b)|DOCX||2019-12-06 08:00:04|contact.docx|
|[0b87e68ce08f4043a9407707c419c4a3](https://www.virustotal.com/gui/file/0b87e68ce08f4043a9407707c419c4a3)|DOCX||2019-12-03 14:21:10|D:\Download\0f431af2019932d4a2956911583dcb5aacdaf3810ca43a31d40f701ada6693fb.bin|
|[212d71fe48597a4f8c567422d60eafbb](https://www.virustotal.com/gui/file/212d71fe48597a4f8c567422d60eafbb)|DOCX||2019-11-29 07:33:12|Запит_СБУ.docx|
|[bc4fde585ccb356cde8ac2f543fa27b4](https://www.virustotal.com/gui/file/bc4fde585ccb356cde8ac2f543fa27b4)|DOCX||2019-11-28 10:35:58|1f185b6d28c8e87142d8fb0f8172caf56924ab1812c3dca218b7da5e01d23b54.bin|
|[6313ba6679b19b5a8b9ca829edcae2a0](https://www.virustotal.com/gui/file/6313ba6679b19b5a8b9ca829edcae2a0)|DOCX||2019-11-26 15:33:06|ba962aeef2ae951306da0196301b2fe8fa1ac668400b1ea5f44a4aefb3ee5dc2.bin|
|[33f67d594049e04822e207ee5b442df7](https://www.virustotal.com/gui/file/33f67d594049e04822e207ee5b442df7)|DOCX||2019-11-26 15:29:39|f8c110022c7c8d03f60d5a53cbafbe9ea2b54cdc596e31b3f8e3ff203c2733bd.bin|
|[ba9b05847e50e508ee2decd9dde42032](https://www.virustotal.com/gui/file/ba9b05847e50e508ee2decd9dde42032)|DOC||2019-11-26 07:26:21|yota.dot|
|[ba0cf841188e1e81d07475f93296270d](https://www.virustotal.com/gui/file/ba0cf841188e1e81d07475f93296270d)|DOCX||2019-11-25 14:39:20|Запит_СЗР.docx|
|[af965a38a900a248222ab45d329bd328](https://www.virustotal.com/gui/file/af965a38a900a248222ab45d329bd328)|DOCX||2019-11-25 14:34:59|730074e62545c3075aace0eb0d4fbb31717f0845651e990224c0ace3618e5a1b.bin|
|[64bc5a0ee79b1cc88e8858b858fc6782](https://www.virustotal.com/gui/file/64bc5a0ee79b1cc88e8858b858fc6782)|DOCX||2019-11-25 14:31:21|Запит_СЗР.docx|
|[6e359f1c1d36c6a8a5f19bfb5bbafbf2](https://www.virustotal.com/gui/file/6e359f1c1d36c6a8a5f19bfb5bbafbf2)|DOC||2019-11-25 13:43:25|yota.dot|
|[57f315e2e991ae79b476b0ede9053f9a](https://www.virustotal.com/gui/file/57f315e2e991ae79b476b0ede9053f9a)|ZIP||2019-11-25 12:37:10|запит.docx|
|[bcdcc72117c2db1b0eb9eb228d150bac](https://www.virustotal.com/gui/file/bcdcc72117c2db1b0eb9eb228d150bac)|ZIP||2019-11-25 12:35:04|zapit.docx|
|[4778869cf2564b14b6bbf4baf361469a](https://www.virustotal.com/gui/file/4778869cf2564b14b6bbf4baf361469a)|DOCX||2019-11-25 12:24:29|47723574d99719733f87e1859e80cfbd88c5c482428344593d2d025bf2108368.bin|
|[10a52e38cfde59cb604f9022ef62c1fd](https://www.virustotal.com/gui/file/10a52e38cfde59cb604f9022ef62c1fd)|DOCX||2019-11-21 20:03:33|343_9130.docx|
|[85d07e3a3120e6756632f62c03923a1e](https://www.virustotal.com/gui/file/85d07e3a3120e6756632f62c03923a1e)|DOCX||2019-11-21 14:46:46|647dfdf939de6a8d9f7572c389910c8fe4b469676162e6f02e23ef79e3be4868.bin|
|[6540a2b273cfb57af53b619da4c8ecd8](https://www.virustotal.com/gui/file/6540a2b273cfb57af53b619da4c8ecd8)|DOCX||2019-11-19 08:57:23|Матеріали.docx|
|[d3057705590e38b9b06e6147b2f57011](https://www.virustotal.com/gui/file/d3057705590e38b9b06e6147b2f57011)|DOCX||2019-11-18 10:26:49|провадження.docx|
|[6bf9d9d41243568dc917df768de68529](https://www.virustotal.com/gui/file/6bf9d9d41243568dc917df768de68529)|TXT||2019-11-13 21:57:42|VirusShare_6bf9d9d41243568dc917df768de68529|
|[75ad80c780417092a27fa7af45638810](https://www.virustotal.com/gui/file/75ad80c780417092a27fa7af45638810)|DOCX||2019-11-11 10:47:13|64c6a60f51761b22b94914a6974e8478aad05b7f91ba87ddd8c1d1fb079e4249.bin|
|[989cd417ec7cffa3ec1f7ca022f20a51](https://www.virustotal.com/gui/file/989cd417ec7cffa3ec1f7ca022f20a51)|DOCX||2019-11-11 10:24:25|bcbc916f37d20f9dfe2c747095d901791e1e4fde7b49585d77c1e1f0288aa193.bin|
|[82b1e8b44adbbbf67e6bc4535eb02849](https://www.virustotal.com/gui/file/82b1e8b44adbbbf67e6bc4535eb02849)|DOCX||2019-11-08 16:15:21|Запит.docx|
|[b221647d110bd2be2c6e9c5d727ca8db](https://www.virustotal.com/gui/file/b221647d110bd2be2c6e9c5d727ca8db)|DOCX||2019-11-07 17:26:43|da1291742f5bcbe2d5c44aaae4fccd86b539fa68e679f0994bb681b391c8f3ce.bin|
|[dbf4f92852cdae17aa3f2b1234f0140e](https://www.virustotal.com/gui/file/dbf4f92852cdae17aa3f2b1234f0140e)|DOCX||2019-11-07 13:16:52|b3b06267814370d32ea0ab8bd802bcaef127ad98ee41d9c805555efbd1a8b187.bin|
|[80a465fafd84b6fcdb0c2a9e030eb7fd](https://www.virustotal.com/gui/file/80a465fafd84b6fcdb0c2a9e030eb7fd)|DOCX||2019-11-06 14:09:15|Документ Microsoft Office Word.docx|
|[986fb45573c836b9f791b0be30353cab](https://www.virustotal.com/gui/file/986fb45573c836b9f791b0be30353cab)|unknown||2019-10-14 05:07:39|dttcodexgigas.26576e428d355294a87a5d49965c3880d7461c51|
|[2f10b010bae2543893f5751ff818614a](https://www.virustotal.com/gui/file/2f10b010bae2543893f5751ff818614a)|LNK||2019-10-10 23:17:47|%TEMP%\7zipsfx.000\20404|
|[587772ca5487c212b922080d6d1199bb](https://www.virustotal.com/gui/file/587772ca5487c212b922080d6d1199bb)|RTF||2019-09-18 11:42:04|=?UTF-8?B?0JTQvtC60YPQvNC10L3RgiBNaWNyb3NvZnQgT2ZmaWNlIFdvcmQucnRm?=|
|[b4ae60433b31798f7839157b514d9d24](https://www.virustotal.com/gui/file/b4ae60433b31798f7839157b514d9d24)|RTF||2019-09-18 09:57:17|=?UTF-8?B?0JTQvtC60YPQvNC10L3RgiBNaWNyb3NvZnQgT2ZmaWNlIFdvcmQucnRm?=|
|[2620527d01c3b4b2de7e1f7327d709b7](https://www.virustotal.com/gui/file/2620527d01c3b4b2de7e1f7327d709b7)|Win32 EXE||2019-09-13 13:24:32|Email Reader|
|[a910ff1e23f1c3f31298b974c3ab472d](https://www.virustotal.com/gui/file/a910ff1e23f1c3f31298b974c3ab472d)|Win32 EXE||2019-09-13 08:04:35|WinWord|
|[6fa30bb816deb9733b9982b5f7ad84ae](https://www.virustotal.com/gui/file/6fa30bb816deb9733b9982b5f7ad84ae)|DOCX||2019-09-10 10:42:52|PARP.docx|
|[8811849f9eee5a7c90e484ce64567b67](https://www.virustotal.com/gui/file/8811849f9eee5a7c90e484ce64567b67)|DOCX||2019-09-10 10:41:24|Planning.docx|
|[99764e3edf488b60d18123ef768d20f0](https://www.virustotal.com/gui/file/99764e3edf488b60d18123ef768d20f0)|DOCX||2019-09-10 08:09:44|e68001e37577a909804009dcbdfd9d25a40e0f750475922195d2649f3d207821.bin|
|[e3ea809b92b17225eb8ffc5ab3b68541](https://www.virustotal.com/gui/file/e3ea809b92b17225eb8ffc5ab3b68541)|DOCX||2019-09-09 13:01:01|f071e1338464c6d05913cbef422956c8fd6863c66199e4b48cc5ca598f346a9f.bin|
|[bdc577cc1302b7b89552ce843af1ceae](https://www.virustotal.com/gui/file/bdc577cc1302b7b89552ce843af1ceae)|DOC|o97m|2019-09-06 12:15:01|internet.dot|
|[727de5973be8e005eea75916d39f4577](https://www.virustotal.com/gui/file/727de5973be8e005eea75916d39f4577)|DOCX||2019-09-05 13:20:02|=?UTF-8?B?0L/RgNC+0YLQvtC60L7Quy5kb2N4?=|
|[b7d85299085f6988074a3ccbeb765866](https://www.virustotal.com/gui/file/b7d85299085f6988074a3ccbeb765866)|Win32 EXE||2019-09-05 12:46:45|Email LibreOffice|
|[3f9a555d9150c2839c68b71796839f9b](https://www.virustotal.com/gui/file/3f9a555d9150c2839c68b71796839f9b)|DOCX||2019-09-04 14:08:07|04.09.2019.docx|
|[5704a4d69396904478bf7bc643ff0f56](https://www.virustotal.com/gui/file/5704a4d69396904478bf7bc643ff0f56)|Win32 EXE||2019-09-04 09:00:34|Email LibreOffice|
|[792b1cb81d07f4e322cc0aa4e1349a5d](https://www.virustotal.com/gui/file/792b1cb81d07f4e322cc0aa4e1349a5d)|DOC||2019-09-02 15:32:36|creative.dot|
|[a5852fbed678df23613186515eeb61e1](https://www.virustotal.com/gui/file/a5852fbed678df23613186515eeb61e1)|DOCX||2019-08-30 21:51:01|=?UTF-8?B?0JTQntCS0IbQlNCa0JAuZG9jeA==?=|
|[3804f9ddaefd8aafca97a49f535a2889](https://www.virustotal.com/gui/file/3804f9ddaefd8aafca97a49f535a2889)|Win32 EXE||2019-08-24 02:14:16|Setup-d8h3dhwsd.exe|
|[50ee3d46ce94b7b650ba3b875f87cf94](https://www.virustotal.com/gui/file/50ee3d46ce94b7b650ba3b875f87cf94)|RAR||2019-08-24 02:11:47|Microsoft Office 2016.rar|
|[12b5371d60129f305743284edfb59b50](https://www.virustotal.com/gui/file/12b5371d60129f305743284edfb59b50)|Win32 EXE||2019-08-22 07:20:26|Email LibreOffice|
|[b92b46f3ed031887d302a173d47406c4](https://www.virustotal.com/gui/file/b92b46f3ed031887d302a173d47406c4)|TAR||2019-08-21 13:56:15|project.rar|
|[133ae7a92ed59adc18da80398a3d7226](https://www.virustotal.com/gui/file/133ae7a92ed59adc18da80398a3d7226)|Win32 EXE||2019-08-19 16:18:28|Email LibreOffice|
|[1426f88edaf207d2c62422f343209fae](https://www.virustotal.com/gui/file/1426f88edaf207d2c62422f343209fae)|Win32 EXE||2019-08-15 10:47:56|Email LibreOffice|
|[6991d3c62b47340f0c97e2918b0ccff5](https://www.virustotal.com/gui/file/6991d3c62b47340f0c97e2918b0ccff5)|TAR||2019-08-15 07:02:16|SSU.rar|
|[1676158ff7d9751413308094c97c7055](https://www.virustotal.com/gui/file/1676158ff7d9751413308094c97c7055)|Win32 EXE||2019-08-14 22:24:35|Email LibreOffice|
|[3162b546bc2251c609ac35a798708d0f](https://www.virustotal.com/gui/file/3162b546bc2251c609ac35a798708d0f)|DOC||2019-08-10 16:37:47| |
|[1d49f4eb95f481edba72080920f12846](https://www.virustotal.com/gui/file/1d49f4eb95f481edba72080920f12846)|DOC||2019-08-06 22:41:15|1D49F4EB95F481EDBA72080920F12846.mlw|
|[7adc386261df1e49e71bb4a7b5c33c4c](https://www.virustotal.com/gui/file/7adc386261df1e49e71bb4a7b5c33c4c)|unknown||2019-08-04 15:39:55|dttcodexgigas.9f863b2cfcb62bf8cd908dd728ca9b5c36ec86dc|
|[c3e36447b17b7373251b40c04bfceab3](https://www.virustotal.com/gui/file/c3e36447b17b7373251b40c04bfceab3)|Win32 EXE||2019-08-04 10:42:50|Microsoft Office Help|
|[07c82a8bacbd196a9788c9d6cda68f5a](https://www.virustotal.com/gui/file/07c82a8bacbd196a9788c9d6cda68f5a)|Win32 EXE||2019-08-04 04:44:26|AdapterTroubleshooter|
|[4d373da58026abd1d69ca38faeada36e](https://www.virustotal.com/gui/file/4d373da58026abd1d69ca38faeada36e)|Win32 EXE||2019-08-02 19:49:23|setup.exe|
|[73bc90e40f241df4e7b60125ad372ab8](https://www.virustotal.com/gui/file/73bc90e40f241df4e7b60125ad372ab8)|Win32 EXE||2019-08-02 18:41:37|Email LibreOffice|
|[fc6aeb444a654eb473aa6f094ac9ee5f](https://www.virustotal.com/gui/file/fc6aeb444a654eb473aa6f094ac9ee5f)|RAR||2019-08-02 14:38:59|Microsoft Office 2016.rar|
|[566b4a539a97b90491b51972d6109021](https://www.virustotal.com/gui/file/566b4a539a97b90491b51972d6109021)|Win32 EXE||2019-07-29 00:21:39|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\14638|
|[39f0474ec6298873a74dbc795fb02f09](https://www.virustotal.com/gui/file/39f0474ec6298873a74dbc795fb02f09)|TXT||2019-07-29 00:21:37|dttcodexgigas.bc562f8175ee2bf48de0f2b179c8b6890746fe97|
|[4ca32e745ec278d45aa3442434f2c17b](https://www.virustotal.com/gui/file/4ca32e745ec278d45aa3442434f2c17b)|Win32 EXE||2019-07-28 20:47:13|setup.exe|
|[e6c7740e22a800c4fd5bad5e3e530f91](https://www.virustotal.com/gui/file/e6c7740e22a800c4fd5bad5e3e530f91)|DOC|sagent|2019-07-25 06:00:43|79fd962eb0c256f32786dab4d42cb416f6c1e6766bf0e2dcafdf5ffa2c5e61c1.bin|
|[c36e5805a693abca6b749f9ef7eacf23](https://www.virustotal.com/gui/file/c36e5805a693abca6b749f9ef7eacf23)|LNK||2019-07-19 01:31:37|%TEMP%\7zipsfx.000\105|
|[2d8712b97dd3d2a81179bd6f049b6a5e](https://www.virustotal.com/gui/file/2d8712b97dd3d2a81179bd6f049b6a5e)|LNK||2019-07-02 07:19:22|%TEMP%\7zipsfx.000\3111|
|[4774b17b55d5f3b2f204ee3030b3b904](https://www.virustotal.com/gui/file/4774b17b55d5f3b2f204ee3030b3b904)|unknown||2019-06-25 21:52:13|%TEMP%\rarsfx0\26442.cmd|
|[5269553745d8172bd38e28e75c5bc41e](https://www.virustotal.com/gui/file/5269553745d8172bd38e28e75c5bc41e)|Win32 EXE||2019-06-07 01:05:00|Email LibreOffice|
|[80176cd1a8ae182bb0c7ee472741402e](https://www.virustotal.com/gui/file/80176cd1a8ae182bb0c7ee472741402e)|Win32 EXE||2019-06-05 23:54:18|%TEMP%\7zipsfx.000\12854.txt|
|[f4ba1d3c6eb5e4e0e842dd24f92acc96](https://www.virustotal.com/gui/file/f4ba1d3c6eb5e4e0e842dd24f92acc96)|Win32 EXE||2019-06-05 20:08:24|29641.txt|
|[d20e11aa2c13dee9ff35a3b1d6f11fea](https://www.virustotal.com/gui/file/d20e11aa2c13dee9ff35a3b1d6f11fea)|Win32 EXE||2019-06-05 18:59:49|Email LibreOffice|
|[c7878559481197ff4b05e5d6844ad1a7](https://www.virustotal.com/gui/file/c7878559481197ff4b05e5d6844ad1a7)|Win32 EXE||2019-06-05 16:25:19|CSPSetup|
|[d7852624cc0f1caa590d838d5e1c156f](https://www.virustotal.com/gui/file/d7852624cc0f1caa590d838d5e1c156f)|Win32 EXE||2019-06-05 14:59:17|wink.txt|
|[b4359fc4df75581f3579837eb3bed116](https://www.virustotal.com/gui/file/b4359fc4df75581f3579837eb3bed116)|Win32 EXE||2019-06-05 12:22:38|b4359fc4df75581f3579837eb3bed116.virus|
|[3417f096507f33194ea4281376a7f5fc](https://www.virustotal.com/gui/file/3417f096507f33194ea4281376a7f5fc)|Win32 EXE||2019-06-05 11:31:51|Email LibreOffice|
|[f9e9fa86afc30ea502b4367965e8eae4](https://www.virustotal.com/gui/file/f9e9fa86afc30ea502b4367965e8eae4)|Win32 EXE||2019-06-05 11:12:51|CSPSetup|
|[4de17a719f4fe79511625dc052906a9f](https://www.virustotal.com/gui/file/4de17a719f4fe79511625dc052906a9f)|DOCX||2019-06-04 11:46:10|14468|
|[2da8f864ef0d4522f187b72e8c0c6e6b](https://www.virustotal.com/gui/file/2da8f864ef0d4522f187b72e8c0c6e6b)|Win32 EXE||2019-06-01 20:05:54|wink.txt|
|[d1196e8ca10fe9aa98f19ddce99c32e3](https://www.virustotal.com/gui/file/d1196e8ca10fe9aa98f19ddce99c32e3)|Win32 EXE||2019-06-01 16:25:14|CSPSetup|
|[67c20c837a358f2ef79f9e65732f6326](https://www.virustotal.com/gui/file/67c20c837a358f2ef79f9e65732f6326)|Win32 EXE||2019-05-31 18:47:41|Email LibreOffice|
|[c5b84af695f20cb2aee7834e7cf7df84](https://www.virustotal.com/gui/file/c5b84af695f20cb2aee7834e7cf7df84)|Win32 EXE||2019-05-30 22:05:45|d3ad9b3b0b6cee60c828c847c9ebd9f7cd5e6b6b5ef31b368b16437e48f7204f.bin|
|[7d75017e14fe6a15b24d07219e0ed23c](https://www.virustotal.com/gui/file/7d75017e14fe6a15b24d07219e0ed23c)|Win32 EXE||2019-05-30 18:39:09| |
|[6efe05055f3d3131cbeea53ba2595f3b](https://www.virustotal.com/gui/file/6efe05055f3d3131cbeea53ba2595f3b)|unknown||2019-05-30 11:48:07|dttcodexgigas.7f9e6ba281a9b0c5c8c65a2a0ff0a24762d096b6|
|[22d83c0a0fc85cd4f6eb1856ab0c37e7](https://www.virustotal.com/gui/file/22d83c0a0fc85cd4f6eb1856ab0c37e7)|Win32 EXE||2019-05-30 08:46:46|7ZSfxMod|
|[852105c14ec909e2c6ec3db4ab7837fe](https://www.virustotal.com/gui/file/852105c14ec909e2c6ec3db4ab7837fe)|Win32 EXE||2019-05-30 08:37:24|C:\Users\j.yoroi\AppData\Local\Temp\7ZipSfx.000\win.exe|
|[1ff325f332f84fe9d6b6a142bc872f8a](https://www.virustotal.com/gui/file/1ff325f332f84fe9d6b6a142bc872f8a)|Win32 EXE||2019-05-29 11:14:36| |
|[35019bcc7571fbba4515871e0cc2a290](https://www.virustotal.com/gui/file/35019bcc7571fbba4515871e0cc2a290)|Win32 EXE||2019-05-29 11:11:56|7ZSfxMod|
|[4dd230bf83bc5102751dd4c824cc3c3b](https://www.virustotal.com/gui/file/4dd230bf83bc5102751dd4c824cc3c3b)|Win32 EXE||2019-05-29 10:06:59|7ZSfxMod|
|[bb0b88d4a6bc6b5f861e85a20391ae88](https://www.virustotal.com/gui/file/bb0b88d4a6bc6b5f861e85a20391ae88)|Win32 EXE||2019-05-29 10:02:26|CSPSetup|
|[7ec3d435389bf51afdf2d15a6fc11404](https://www.virustotal.com/gui/file/7ec3d435389bf51afdf2d15a6fc11404)|Win32 EXE||2019-05-29 10:00:44|Email LibreOffice|
|[4f0dcad3e878f6c84ec458b1d4164b5e](https://www.virustotal.com/gui/file/4f0dcad3e878f6c84ec458b1d4164b5e)|Win32 EXE||2019-05-29 10:00:04|4f0dcad3e878f6c84ec458b1d4164b5e.virus|
|[d1dc809fb3808fc0b5bb35023683b618](https://www.virustotal.com/gui/file/d1dc809fb3808fc0b5bb35023683b618)|Win32 EXE||2019-05-29 09:30:32| |
|[319eebd79dd3113c785342d6f3cc47e4](https://www.virustotal.com/gui/file/319eebd79dd3113c785342d6f3cc47e4)|Win32 EXE||2019-05-29 07:59:31|Email LibreOffice|
|[c5a402ad472b551d5142fcdfa03e8e5d](https://www.virustotal.com/gui/file/c5a402ad472b551d5142fcdfa03e8e5d)|Win32 EXE||2019-05-29 01:46:35|AdapterTroubleshooter|
|[a10cc26fbc4569b932035286f0ba0e42](https://www.virustotal.com/gui/file/a10cc26fbc4569b932035286f0ba0e42)|Win32 EXE||2019-05-28 18:17:40|%TEMP%\7zipsfx.000\21196.txt|
|[a7e85dd383b0d8c799af4d9be7a90692](https://www.virustotal.com/gui/file/a7e85dd383b0d8c799af4d9be7a90692)|Win32 EXE||2019-05-28 08:40:39|7ZSfxMod|
|[354c3e844f2a935117a867e80c66df9a](https://www.virustotal.com/gui/file/354c3e844f2a935117a867e80c66df9a)|Email||2019-05-28 08:40:33|=?UTF-8?Q?Fw__=E2=84=961210933002000298=2Eeml?=|
|[f712ba991cebdf9637141b9582611d95](https://www.virustotal.com/gui/file/f712ba991cebdf9637141b9582611d95)|Win32 EXE||2019-05-28 08:26:09|7ZSfxMod|
|[83fefc859e778fb5c4c876dba3ea7941](https://www.virustotal.com/gui/file/83fefc859e778fb5c4c876dba3ea7941)|Win32 EXE||2019-05-28 08:21:40|83fefc859e778fb5c4c876dba3ea7941.virus|
|[e955fd20c39b87b8b16abef992695aad](https://www.virustotal.com/gui/file/e955fd20c39b87b8b16abef992695aad)|Win32 EXE||2019-05-28 00:37:54|Email LibreOffice|
|[5e6bb7cbc4bb98d4043f6645f6f63f78](https://www.virustotal.com/gui/file/5e6bb7cbc4bb98d4043f6645f6f63f78)|DOCX||2019-05-27 20:40:30|%TEMP%\7zipsfx.000\20261|
|[b2e8bff37e027cdad6342ac89e77d8a7](https://www.virustotal.com/gui/file/b2e8bff37e027cdad6342ac89e77d8a7)|Win32 EXE||2019-05-27 19:49:07| |
|[e1ffb143aa2a372dd6f4454fda7a9cac](https://www.virustotal.com/gui/file/e1ffb143aa2a372dd6f4454fda7a9cac)|Win32 EXE|occamy|2019-05-27 17:52:20|%TEMP%\7zipsfx.000\11439|
|[3d0627f25b82b480f3657a029b26762b](https://www.virustotal.com/gui/file/3d0627f25b82b480f3657a029b26762b)|Text||2019-05-27 17:52:19|%TEMP%\rarsfx0\setup.vbs|
|[488418d7012f343977323c17508ea116](https://www.virustotal.com/gui/file/488418d7012f343977323c17508ea116)|unknown||2019-05-27 17:52:17|%TEMP%\rarsfx0\11060.cmd|
|[f4708aa5dfb8a7beb61e54cdc053c609](https://www.virustotal.com/gui/file/f4708aa5dfb8a7beb61e54cdc053c609)|Win32 EXE||2019-05-27 17:43:15|601d85c0236f8d3a82fecf353adb106fac23f1681ef866783ff6e634538c9ce0.bin|
|[2d3424e0e53e14b0a7f9646ecfeb52cf](https://www.virustotal.com/gui/file/2d3424e0e53e14b0a7f9646ecfeb52cf)|Win32 EXE||2019-05-27 14:36:04|Email LibreOffice|
|[89af0cd6f39d0c6abc1dadab4f68edf5](https://www.virustotal.com/gui/file/89af0cd6f39d0c6abc1dadab4f68edf5)|Win32 EXE||2019-05-27 13:01:21|7ZSfxMod|
|[f52ccc05bcdc8fd5a8d3edc5f1593e64](https://www.virustotal.com/gui/file/f52ccc05bcdc8fd5a8d3edc5f1593e64)|TAR||2019-05-27 08:54:34|=?UTF-8?B?0L/RltC00L7Qt9GA0LAucmFy?=|
|[d42f2d4c27aaca93541f56682e0c28a5](https://www.virustotal.com/gui/file/d42f2d4c27aaca93541f56682e0c28a5)|Win32 EXE||2019-05-25 21:40:24|7ZSfxMod|
|[36f1969a1a3ec3a40cd3f191341344bf](https://www.virustotal.com/gui/file/36f1969a1a3ec3a40cd3f191341344bf)|Win32 EXE||2019-05-25 11:50:15| |
|[b6689becb1c447da518ef1e0975dda09](https://www.virustotal.com/gui/file/b6689becb1c447da518ef1e0975dda09)|Win32 EXE||2019-05-25 11:16:16|7ZSfxMod|
|[1fdb2a09f50246d5cf5ba339048ef429](https://www.virustotal.com/gui/file/1fdb2a09f50246d5cf5ba339048ef429)|Win32 EXE||2019-05-24 20:21:05| |
|[bb74b9d03fa2cbff0c74c8a601c0ac07](https://www.virustotal.com/gui/file/bb74b9d03fa2cbff0c74c8a601c0ac07)|Win32 EXE||2019-05-24 07:29:57|Email LibreOffice|
|[3f73da503e09c537796b51f8d8fa7571](https://www.virustotal.com/gui/file/3f73da503e09c537796b51f8d8fa7571)|Win32 EXE||2019-05-23 20:08:51|wink.txt|
|[e6d82303409d5478212caf2405964283](https://www.virustotal.com/gui/file/e6d82303409d5478212caf2405964283)|DOCX||2019-05-23 16:04:29|%TEMP%\7zipsfx.000\17338|
|[4fb8e45460349f15f74496c4b9a9f6d2](https://www.virustotal.com/gui/file/4fb8e45460349f15f74496c4b9a9f6d2)|Win32 EXE||2019-05-23 13:26:12|7ZSfxMod|
|[fdff06122cd8b830799e0feacb384574](https://www.virustotal.com/gui/file/fdff06122cd8b830799e0feacb384574)|Win32 EXE||2019-05-23 12:02:21|Email LibreOffice|
|[67d815b0fa607c4cd219d043543d3e93](https://www.virustotal.com/gui/file/67d815b0fa607c4cd219d043543d3e93)|Win32 EXE||2019-05-22 14:45:30|Email LibreOffice|
|[28231a5d6e3363bdecfee8765ebb1212](https://www.virustotal.com/gui/file/28231a5d6e3363bdecfee8765ebb1212)|DOCX||2019-05-22 10:20:56|15803|
|[6f3f1b5d4d755b301c013843c5c006d0](https://www.virustotal.com/gui/file/6f3f1b5d4d755b301c013843c5c006d0)|Win32 EXE||2019-05-22 06:39:11|Email LibreOffice|
|[e2ad04bf2c0ce3308757fa33b93de55e](https://www.virustotal.com/gui/file/e2ad04bf2c0ce3308757fa33b93de55e)|Win32 EXE||2019-05-21 19:23:20|7ZSfxMod|
|[c4470529df4a3d08629818f59c15483f](https://www.virustotal.com/gui/file/c4470529df4a3d08629818f59c15483f)|Win32 EXE||2019-05-20 04:59:42| |
|[ac062a39c35e0de6f72575890052f0fd](https://www.virustotal.com/gui/file/ac062a39c35e0de6f72575890052f0fd)|Win32 EXE||2019-05-19 06:20:51|%TEMP%\7zipsfx.000\win.txt|
|[2358adb562ffa00e3631300d1daf9acc](https://www.virustotal.com/gui/file/2358adb562ffa00e3631300d1daf9acc)|Win32 EXE||2019-05-19 06:16:02|7ZSfxMod|
|[af676851cb3102e27e4a0954a54c7f37](https://www.virustotal.com/gui/file/af676851cb3102e27e4a0954a54c7f37)|Win32 EXE||2019-05-16 12:47:28| |
|[dd8b589c99a4853bb21fe9b78288c664](https://www.virustotal.com/gui/file/dd8b589c99a4853bb21fe9b78288c664)|Win32 EXE||2019-05-16 12:16:02|7ZSfxMod|
|[d86716ad15a962e2a7b8644fcfd0cf08](https://www.virustotal.com/gui/file/d86716ad15a962e2a7b8644fcfd0cf08)|Win32 EXE||2019-05-16 12:06:34|ieinstal.exe|
|[e4a3ce22d5e70f54ef34f42a3e138e50](https://www.virustotal.com/gui/file/e4a3ce22d5e70f54ef34f42a3e138e50)|Win32 EXE||2019-05-15 20:59:03|e4a3ce22d5e70f54ef34f42a3e138e50.virobj|
|[b3822c5e2fb768927c520e4324bf9f80](https://www.virustotal.com/gui/file/b3822c5e2fb768927c520e4324bf9f80)|Win32 EXE|agentwdcr|2019-05-15 20:32:40|/var/vb100/rep_file_pool///000220/2703/b3822c5e2fb768927c520e4324bf9f80|
|[9897d36e1263caa92d029798f76013b2](https://www.virustotal.com/gui/file/9897d36e1263caa92d029798f76013b2)|Win32 EXE|agentwdcr|2019-05-15 20:31:23|7ZSfxMod|
|[fa5d3231d468f174b1d935babbf5e3c5](https://www.virustotal.com/gui/file/fa5d3231d468f174b1d935babbf5e3c5)|Win32 EXE||2019-05-15 18:11:39|%TEMP%\7zipsfx.000\taskmgk.exe|
|[089a689844d9a6febee2a04e6224c421](https://www.virustotal.com/gui/file/089a689844d9a6febee2a04e6224c421)|Win32 EXE||2019-05-15 18:09:35| |
|[d81c7ea5269b1a2176e001b1325720bf](https://www.virustotal.com/gui/file/d81c7ea5269b1a2176e001b1325720bf)|Win32 EXE||2019-05-15 17:31:45|7ZSfxMod|
|[99325c6e0ed2dd0d84978ef687294620](https://www.virustotal.com/gui/file/99325c6e0ed2dd0d84978ef687294620)|DOCX||2019-05-13 21:09:25|%TEMP%\7zipsfx.000\11620|
|[6907fc6af47ed8ed33085ce6e69a6ef5](https://www.virustotal.com/gui/file/6907fc6af47ed8ed33085ce6e69a6ef5)|Win32 EXE||2019-05-13 17:38:24|Згода на обробку персональних даних у картотеках та за допомогою інформаційно-телекомунікаційної системи бази персональних даних.scr|
|[360243c88f782bb399334c213aecabf5](https://www.virustotal.com/gui/file/360243c88f782bb399334c213aecabf5)|Win32 EXE||2019-05-11 08:47:44|%TEMP%\7zipsfx.000\win.txt|
|[1921d2d1b52b849dd5fa053b65b0189f](https://www.virustotal.com/gui/file/1921d2d1b52b849dd5fa053b65b0189f)|Win32 EXE||2019-05-10 15:18:13|7ZSfxMod|
|[03b51fcaae7385b0a64241a8c7da5812](https://www.virustotal.com/gui/file/03b51fcaae7385b0a64241a8c7da5812)|Win32 EXE||2019-05-10 12:27:29|7ZSfxMod|
|[2d16110b786bd12722985d78d4bab2c8](https://www.virustotal.com/gui/file/2d16110b786bd12722985d78d4bab2c8)|DOCX||2019-05-07 20:14:20|%TEMP%\7zipsfx.000\2276|
|[b11d660444d5af55598d3f44e7431c8a](https://www.virustotal.com/gui/file/b11d660444d5af55598d3f44e7431c8a)|Win32 EXE||2019-05-07 17:54:40|%TEMP%\7zipsfx.001\taskmgc.exe|
|[22d4747d99e636b3082a87bd9662f3a4](https://www.virustotal.com/gui/file/22d4747d99e636b3082a87bd9662f3a4)|Win32 EXE||2019-05-07 16:48:16|Проект порядку денного 3 всеукраїнського форуму Громадських рад України (autosave 05 травня 2019 року).scr|
|[7e086d9d3c5f7897dd6741be6f42b14d](https://www.virustotal.com/gui/file/7e086d9d3c5f7897dd6741be6f42b14d)|Win32 EXE||2019-04-28 08:26:07|Process Explorer|
|[4ee4737eafbd24d1523454995d852b5c](https://www.virustotal.com/gui/file/4ee4737eafbd24d1523454995d852b5c)|unknown||2019-04-25 21:22:30|%TEMP%\7zipsfx.000\7789.cmd|
|[2ecbefbe6ecc2c927b1d27864211e0ae](https://www.virustotal.com/gui/file/2ecbefbe6ecc2c927b1d27864211e0ae)|Win32 EXE||2019-04-25 08:43:02| |
|[5e938691647e7b6e89f1cd9cb9825d4a](https://www.virustotal.com/gui/file/5e938691647e7b6e89f1cd9cb9825d4a)|unknown||2019-04-18 12:39:38|dttcodexgigas.4eef6fbd04c60eee5ee10e91c8dbab6e46d35425|
|[056627b3cf6e96da264674e4d5bd09da](https://www.virustotal.com/gui/file/056627b3cf6e96da264674e4d5bd09da)|Win32 EXE||2019-04-16 19:46:36|WinWord|
|[7b543243c9e1922219b334e2982db943](https://www.virustotal.com/gui/file/7b543243c9e1922219b334e2982db943)|DOC||2019-04-16 15:29:16|=?UTF-8?B?0JrQu9C+0L/QvtGC0LDQvdC90Y8g0LXQutGB0L/QtdGA0YLQuNC30LDQodC60LDRh9C60L4uZG9j?=|
|[d9c305054fdae149fca47a04f8f065c3](https://www.virustotal.com/gui/file/d9c305054fdae149fca47a04f8f065c3)|DOC||2019-04-16 14:59:55|=?UTF-8?B?0LLRltC00L/QvtCy0ZbQtNGMINCR0LDQsdGW0L3Rgy5kb2M=?=|
|[8eb98aab56283b15fa93b88e5e19fd4e](https://www.virustotal.com/gui/file/8eb98aab56283b15fa93b88e5e19fd4e)|Win32 EXE||2019-04-15 19:10:48|win.bin|
|[0fe5e07626042e39245206c27643a24e](https://www.virustotal.com/gui/file/0fe5e07626042e39245206c27643a24e)|ACE||2019-04-15 11:59:15|/attachments.rar|
|[4ac8c1577da364c48f5c1154389e6828](https://www.virustotal.com/gui/file/4ac8c1577da364c48f5c1154389e6828)|Win32 EXE||2019-04-15 11:37:32|WinWord|
|[0dd25c2f43a123b7e05b2da234b91e3a](https://www.virustotal.com/gui/file/0dd25c2f43a123b7e05b2da234b91e3a)|Win32 EXE||2019-04-12 23:53:38|Office|
|[c1acce3a8480a356654a7acadc627444](https://www.virustotal.com/gui/file/c1acce3a8480a356654a7acadc627444)|LNK||2019-04-12 23:53:37|%TEMP%\7zipsfx.000\28262|
|[49cde7d0ca755f0c284d9690e84711ac](https://www.virustotal.com/gui/file/49cde7d0ca755f0c284d9690e84711ac)|Win32 EXE||2019-04-12 20:31:28|WinWord|
|[6dd44138e6be34f439f153ea73cd11ac](https://www.virustotal.com/gui/file/6dd44138e6be34f439f153ea73cd11ac)|Win32 EXE||2019-04-12 20:30:16|WinWord|
|[76dacc74a1472f1f141f0116dee76e68](https://www.virustotal.com/gui/file/76dacc74a1472f1f141f0116dee76e68)|Win32 EXE||2019-04-12 20:21:30|WinWord|
|[cda07c50679b9a3e83714f2f4407cdd4](https://www.virustotal.com/gui/file/cda07c50679b9a3e83714f2f4407cdd4)|Win32 EXE||2019-04-12 19:47:27|WinWord|
|[a2757d71dd76c2940292d49ea2ed98e0](https://www.virustotal.com/gui/file/a2757d71dd76c2940292d49ea2ed98e0)|unknown||2019-04-10 13:22:42|pers.dat|
|[4d792320eb70c46a4eb6c042eea3b70e](https://www.virustotal.com/gui/file/4d792320eb70c46a4eb6c042eea3b70e)|Text||2019-04-09 09:41:06|fc6cbf19331033ae758ca91fe6bab1539793b6153b10a0a7d61f60bdfc4bc791.bin|
|[f180fe8186c7300d53a765ba49852dbf](https://www.virustotal.com/gui/file/f180fe8186c7300d53a765ba49852dbf)|Win32 EXE||2019-04-09 07:10:27|winlogon|
|[b27f7c4915832de93c7fd1fcf43f8372](https://www.virustotal.com/gui/file/b27f7c4915832de93c7fd1fcf43f8372)|Win32 EXE||2019-04-09 07:07:36|winlogon|
|[eed5711480423ff0f896226a34ffe2fd](https://www.virustotal.com/gui/file/eed5711480423ff0f896226a34ffe2fd)|ACE|CVE-2018-20250|2019-04-05 09:14:49|rnbo.rar|
|[579d676ef5476bc473cc57848b6dc6ae](https://www.virustotal.com/gui/file/579d676ef5476bc473cc57848b6dc6ae)|Win32 EXE||2019-04-04 15:12:08|a49dc86dc9ae36313a36cbe2c7b712eebebe923971e29aeab564d8d1cef699bb.bin|
|[4073df9b1f774d9898b4106920ab3fc1](https://www.virustotal.com/gui/file/4073df9b1f774d9898b4106920ab3fc1)|DOCX||2019-04-04 15:12:04|%TEMP%\7zipsfx.000\11326|
|[709f532d57e16f2bfc9d9597a7f304af](https://www.virustotal.com/gui/file/709f532d57e16f2bfc9d9597a7f304af)|Win32 EXE||2019-04-04 11:08:54|L-Office|
|[e5e53fb859009229ecf8866958cf0db3](https://www.virustotal.com/gui/file/e5e53fb859009229ecf8866958cf0db3)|Win32 EXE||2019-04-03 18:01:42|%TEMP%\7zipsfx.000\winsetup|
|[5e1b5bc0a468f5fa454ac7ce4586ba7b](https://www.virustotal.com/gui/file/5e1b5bc0a468f5fa454ac7ce4586ba7b)|Win32 EXE||2019-04-01 18:44:21|%TEMP%\7zipsfx.000\win_x64.exe|
|[676a700817d4d1a1fbeaba3cdccda42a](https://www.virustotal.com/gui/file/676a700817d4d1a1fbeaba3cdccda42a)|Win32 EXE||2019-04-01 13:48:48|vpnclient-win-msi-5.0.07.0410-k9.exe|
|[a5f5e256690241ba57a036ad0d34f952](https://www.virustotal.com/gui/file/a5f5e256690241ba57a036ad0d34f952)|Win32 DLL|Ursu|2019-03-29 16:05:05|myfile.exe|
|[52472ec1485f18455de5eece3e20708e](https://www.virustotal.com/gui/file/52472ec1485f18455de5eece3e20708e)|Win32 EXE|Darkcomet|2019-03-27 11:47:04|L-Office|
|[cb73dcf24f61e07f752d8f8dadc7f90e](https://www.virustotal.com/gui/file/cb73dcf24f61e07f752d8f8dadc7f90e)|Win32 EXE||2019-03-25 16:57:49|E-Office|
|[4238285f4d34944c7bb7ebb4a2ccceeb](https://www.virustotal.com/gui/file/4238285f4d34944c7bb7ebb4a2ccceeb)|Win32 EXE||2019-03-21 01:36:38|%TEMP%\7zipsfx.000\cooks|
|[8d4d133df52a4fe07833e80627b67cc6](https://www.virustotal.com/gui/file/8d4d133df52a4fe07833e80627b67cc6)|Win32 EXE||2019-03-20 13:14:35|Office|
|[1f25616ece58c8fb1adf9599b4427f6b](https://www.virustotal.com/gui/file/1f25616ece58c8fb1adf9599b4427f6b)|Win32 EXE||2019-03-09 23:52:16|Office|
|[0c3c958b3fadbcef4048ce072ca13ed6](https://www.virustotal.com/gui/file/0c3c958b3fadbcef4048ce072ca13ed6)|Win32 EXE||2019-03-09 14:11:23|Office|
|[304576ff20117ffc0b743dc64349451b](https://www.virustotal.com/gui/file/304576ff20117ffc0b743dc64349451b)|unknown||2019-03-06 11:42:21| |
|[49b4a1123ff61b6a9c8229886cdd8e12](https://www.virustotal.com/gui/file/49b4a1123ff61b6a9c8229886cdd8e12)|unknown||2019-03-06 10:21:17| |
|[5c81239f50dcabd9c9a691a86ab5524f](https://www.virustotal.com/gui/file/5c81239f50dcabd9c9a691a86ab5524f)|Win32 EXE||2019-01-12 22:50:11|CSPSetup|
|[34ff17db1d4efff89cfee8d03d48e5d7](https://www.virustotal.com/gui/file/34ff17db1d4efff89cfee8d03d48e5d7)|unknown||2019-01-03 05:17:31|dttcodexgigas.ecf7419378f90d6a7b63ddce2f8d55371c35cb77|
|[197a825d4bfeb093a3c4b969fd4c7338](https://www.virustotal.com/gui/file/197a825d4bfeb093a3c4b969fd4c7338)|unknown||2019-01-03 04:46:06|dttcodexgigas.d621b10c0f97fa845809db057a772359c0ad49bc|
|[265c3c01f267b699ef0e5c0b8e4a5715](https://www.virustotal.com/gui/file/265c3c01f267b699ef0e5c0b8e4a5715)|TXT||2019-01-03 04:15:20|dttcodexgigas.36d3e62f5a24c4c7985093b48b5751f2f8dac7a6|
|[f8e884b75216c3e054e9869f933194e5](https://www.virustotal.com/gui/file/f8e884b75216c3e054e9869f933194e5)|Win32 EXE||2019-01-02 10:41:45|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/CSPSetup2019.bin|
|[2651ee62f76756a8941ef6632577e427](https://www.virustotal.com/gui/file/2651ee62f76756a8941ef6632577e427)|Win32 EXE||2018-12-28 03:45:15|%TEMP%\7zipsfx.000\dec_31489.exe|
|[9136ffa83ef2415a76d437a303e9b38e](https://www.virustotal.com/gui/file/9136ffa83ef2415a76d437a303e9b38e)|Win32 EXE||2018-12-28 03:45:10|%TEMP%\7zipsfx.000\4720.exe|
|[7acb1b099adbe17a8d5194da2637be51](https://www.virustotal.com/gui/file/7acb1b099adbe17a8d5194da2637be51)|Text||2018-11-23 05:02:40|dttcodexgigas.f827eec8835ef1fff82c65df404dc25738d40175|
|[c38acf9a656513d2d99803dcc3e0caca](https://www.virustotal.com/gui/file/c38acf9a656513d2d99803dcc3e0caca)|Text||2018-11-12 12:30:07| |
|[3fc1cd6eade766fc989684dd1390d640](https://www.virustotal.com/gui/file/3fc1cd6eade766fc989684dd1390d640)|Win32 EXE||2018-11-03 12:56:17|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/Pteranodon.bin|
|[52815c0c8dd35e80f52576be8d02e620](https://www.virustotal.com/gui/file/52815c0c8dd35e80f52576be8d02e620)|ZIP||2018-11-02 21:18:35|%TEMP%\7zipsfx.000\setup.dll.zip|
|[369a82f8bb8c906b8cde4f688c08bd71](https://www.virustotal.com/gui/file/369a82f8bb8c906b8cde4f688c08bd71)|Win32 EXE||2018-11-01 23:16:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/Pteranodon2.bin|
|[51ab00c724a29198eed3cb9b50925046](https://www.virustotal.com/gui/file/51ab00c724a29198eed3cb9b50925046)|Win32 EXE||2018-11-01 21:35:52|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/photoshopimplant.bin|
|[1008b087c95d29cc650bc45a37d18d2c](https://www.virustotal.com/gui/file/1008b087c95d29cc650bc45a37d18d2c)|unknown||2018-10-14 00:54:24|%TEMP%\7zipsfx.000\akeyc.cmd|
|[158270c1d7a630a93f665264dd3a776b](https://www.virustotal.com/gui/file/158270c1d7a630a93f665264dd3a776b)|Win32 DLL|zapchast|2018-10-14 00:34:54|codexgigas_995da3bb87432dbfeaa2e6aea1324ed3a40f1420|
|[5b9a992c0fd1d2902fa37966f3d7764d](https://www.virustotal.com/gui/file/5b9a992c0fd1d2902fa37966f3d7764d)|Win32 EXE||2018-10-14 00:09:23|CSPSetup|
|[2d7a583e3ae3c6e4665a2a6c5ed1ba76](https://www.virustotal.com/gui/file/2d7a583e3ae3c6e4665a2a6c5ed1ba76)|Text||2018-10-13 21:50:25| |
|[aec091aa478a9e2a419cba10fdc8c04b](https://www.virustotal.com/gui/file/aec091aa478a9e2a419cba10fdc8c04b)|unknown||2018-10-13 21:21:16| |
|[9ef80aade8845222a8966e1db1219390](https://www.virustotal.com/gui/file/9ef80aade8845222a8966e1db1219390)|Win32 EXE||2018-10-13 21:06:57|/var/vb100/rep_file_pool///000219/7891/9ef80aade8845222a8966e1db1219390|
|[ac07567f2735a26d3d973b605d38ec92](https://www.virustotal.com/gui/file/ac07567f2735a26d3d973b605d38ec92)|unknown||2018-10-13 19:45:59| |
|[8ae5f3d79c4da3741bf9388543fe7479](https://www.virustotal.com/gui/file/8ae5f3d79c4da3741bf9388543fe7479)|Text||2018-10-12 15:26:58|f715505bce521c2d826f1e8237b582a2831082b5e2632600ad07c95072829a62.sample|
|[f53abf8ec98d18088ae1e65c53a38320](https://www.virustotal.com/gui/file/f53abf8ec98d18088ae1e65c53a38320)|unknown||2018-10-12 15:26:58|8d46246696fc2bed3531aadc9e1bae4086bd32a39ed9d0cfb51e804a44337c38.sample|
|[e0dfc17c215b7b767370dabcb39abff8](https://www.virustotal.com/gui/file/e0dfc17c215b7b767370dabcb39abff8)|unknown||2018-10-12 15:26:58|%TEMP%\7zipsfx.000\cookies.cmd|
|[649e69583e86412115ecaf926b5d2b20](https://www.virustotal.com/gui/file/649e69583e86412115ecaf926b5d2b20)|LNK||2018-10-12 15:24:00|%TEMP%\7zipsfx.000\cookieserr.lnk|
|[3d34f5cf65db1edd81b511c5e2dbe4e3](https://www.virustotal.com/gui/file/3d34f5cf65db1edd81b511c5e2dbe4e3)|Win32 DLL|razy|2018-10-12 01:57:50|3d34f5cf65db1edd81b511c5e2dbe4e3.virus|
|[07451ce00b2bf8b4722f72442e4e1c80](https://www.virustotal.com/gui/file/07451ce00b2bf8b4722f72442e4e1c80)|unknown||2018-10-12 00:34:38| |
|[1cb9c98197938bf4f54f366f264c5013](https://www.virustotal.com/gui/file/1cb9c98197938bf4f54f366f264c5013)|Text||2018-10-11 23:40:54| |
|[3b1af72d038daa57445abb9151d05a1e](https://www.virustotal.com/gui/file/3b1af72d038daa57445abb9151d05a1e)|unknown||2018-10-11 16:14:05| |
|[bacd768209887b7e4c03fe7f0ed0e907](https://www.virustotal.com/gui/file/bacd768209887b7e4c03fe7f0ed0e907)|Win32 EXE||2018-10-06 21:53:39|Photoshop|
|[55fa78917b590e945a3f645a4ca6d11a](https://www.virustotal.com/gui/file/55fa78917b590e945a3f645a4ca6d11a)|Win32 EXE||2018-10-06 19:02:02|Photoshop|
|[a146eb7ea437a9cf8f23ca201f230f9c](https://www.virustotal.com/gui/file/a146eb7ea437a9cf8f23ca201f230f9c)|Win32 EXE||2018-10-06 07:15:52|CSPSetup|
|[4b203d625c335bdccabed556480b2a77](https://www.virustotal.com/gui/file/4b203d625c335bdccabed556480b2a77)|Win32 EXE|agentwdcr|2018-10-06 05:05:24|ieinstal.exe|
|[f27b2ad0a7a3936c264ff5c5c1f4ec18](https://www.virustotal.com/gui/file/f27b2ad0a7a3936c264ff5c5c1f4ec18)|Win32 EXE||2018-10-06 04:45:48|ieinstal.exe|
|[7a7397a8dc3b01965ed1f0925c851fe2](https://www.virustotal.com/gui/file/7a7397a8dc3b01965ed1f0925c851fe2)|Win32 EXE||2018-10-05 22:06:47|CSPSetup|
|[1e5446a3ee1d308a89338e18f24580bd](https://www.virustotal.com/gui/file/1e5446a3ee1d308a89338e18f24580bd)|Win32 EXE||2018-10-04 11:30:19|%HOMEPATH%\cookieserr\cookies.exe|
|[605fe3746f003bce8a18be1f216afb72](https://www.virustotal.com/gui/file/605fe3746f003bce8a18be1f216afb72)|Win32 EXE||2018-10-03 13:11:49|Photoshop|
|[c7bda65e820338a42a02eb0c1e20d961](https://www.virustotal.com/gui/file/c7bda65e820338a42a02eb0c1e20d961)|Win32 EXE||2018-09-25 10:55:34|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/GamaredonImplant.bin|
|[b835bf9188ed749da201403a51481399](https://www.virustotal.com/gui/file/b835bf9188ed749da201403a51481399)|Win32 EXE||2018-09-25 03:52:55|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/Pteranodon4.bin|
|[19ddb00f3eaa750c1316bd615b3d1622](https://www.virustotal.com/gui/file/19ddb00f3eaa750c1316bd615b3d1622)|Win32 DLL|razy|2018-09-25 00:00:15|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/Pteranodon3.bin|
|[04449f25e64ba893acdcba5f1694cd41](https://www.virustotal.com/gui/file/04449f25e64ba893acdcba5f1694cd41)|Win32 DLL|razy|2018-09-24 23:47:42|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GamaredonGroup/PteranodonImplant7.bin|
|[b24ccbf98cc8a933af635346bea38255](https://www.virustotal.com/gui/file/b24ccbf98cc8a933af635346bea38255)|Win32 EXE||2018-09-21 08:31:09|CSPSetup|
|[5e8c42762899f379eab542663d5a91d8](https://www.virustotal.com/gui/file/5e8c42762899f379eab542663d5a91d8)|Win32 EXE||2018-09-20 01:03:19|CSPSetup|
|[b20bb9d2bfc72008f13cddc1ec8ab023](https://www.virustotal.com/gui/file/b20bb9d2bfc72008f13cddc1ec8ab023)|Win32 EXE||2018-09-20 00:51:54|CSPSetup|
|[50c9bd25da911ea1a05cef494434b394](https://www.virustotal.com/gui/file/50c9bd25da911ea1a05cef494434b394)|Win32 EXE||2018-09-16 05:14:44|CSPSetup|
|[72e1a63a6eeda201501b4ad539fc3de6](https://www.virustotal.com/gui/file/72e1a63a6eeda201501b4ad539fc3de6)|Win32 EXE||2018-09-16 02:23:56|codexgigas_5793043a79f1c99ac7da9b89ccd80a777c6a99ac|
|[afee58ed3e1d7a443dd0efa962d5e906](https://www.virustotal.com/gui/file/afee58ed3e1d7a443dd0efa962d5e906)|Win32 EXE||2018-09-16 02:14:24|CSPSetup|
|[2021f62938ff23b815198344ba7aa925](https://www.virustotal.com/gui/file/2021f62938ff23b815198344ba7aa925)|Win32 EXE||2018-09-16 01:42:37|codexgigas_b393301b5e745e5a30cdcc9fdd1c693011be3bbf|
|[185aab5c2c2fb3b880a4747659376111](https://www.virustotal.com/gui/file/185aab5c2c2fb3b880a4747659376111)|Win32 EXE||2018-09-12 14:11:48|CSPSetup|
|[9df3f16da657c6321f32b566e10a3814](https://www.virustotal.com/gui/file/9df3f16da657c6321f32b566e10a3814)|Win32 EXE||2018-09-12 08:30:03|CSPSetup|
|[bfe9619b665d06327cd9bfbcea94ead4](https://www.virustotal.com/gui/file/bfe9619b665d06327cd9bfbcea94ead4)|Win32 EXE||2018-09-11 22:54:31|codexgigas_dec435144d217a2f8499c84746461a1b5d144b92|
|[c11a891acda97dfef4d19c786698f521](https://www.virustotal.com/gui/file/c11a891acda97dfef4d19c786698f521)|Win32 EXE||2018-09-11 19:15:23|.|
|[6dec9dd94c61cb868397345e3a6a445f](https://www.virustotal.com/gui/file/6dec9dd94c61cb868397345e3a6a445f)|Win32 EXE||2018-09-11 19:02:26|CSPSetup|
|[c75c376c5d25e562d070199d18470259](https://www.virustotal.com/gui/file/c75c376c5d25e562d070199d18470259)|Win32 EXE||2018-09-07 02:00:40|CSPSetup|
|[02ff8a4e18b6054d7cde14ef694ab7b4](https://www.virustotal.com/gui/file/02ff8a4e18b6054d7cde14ef694ab7b4)|Win32 EXE||2018-09-06 20:50:51|CSPSetup|
|[d6a58dec34f97a28493b0c62f01103fd](https://www.virustotal.com/gui/file/d6a58dec34f97a28493b0c62f01103fd)|Win32 EXE||2018-09-06 12:54:56|CSPSetup|
|[63e9ce22dbf66934fd75c77bc84954d0](https://www.virustotal.com/gui/file/63e9ce22dbf66934fd75c77bc84954d0)|Win32 EXE||2018-09-06 07:38:31|Photoshop|
|[efa8102f432189bb44b4d6e8663831b0](https://www.virustotal.com/gui/file/efa8102f432189bb44b4d6e8663831b0)|Win32 EXE||2018-09-06 04:59:04|CSPSetup|
|[d5ce359c155461f616a038e91dc0c5bd](https://www.virustotal.com/gui/file/d5ce359c155461f616a038e91dc0c5bd)|Win32 EXE||2018-09-05 21:18:29|CSPSetup|
|[bb723f5bc37bb5d7ac5935c05dd1acd9](https://www.virustotal.com/gui/file/bb723f5bc37bb5d7ac5935c05dd1acd9)|Win32 EXE||2018-09-05 04:46:18|CSPSetup|
|[62a30dad22aab2e28eca4e769cdd818a](https://www.virustotal.com/gui/file/62a30dad22aab2e28eca4e769cdd818a)|Win32 EXE||2018-09-04 20:54:54|Photoshop|
|[99ae7d9ae0d8f5285101270440e9445e](https://www.virustotal.com/gui/file/99ae7d9ae0d8f5285101270440e9445e)|Win32 EXE||2018-09-04 20:03:53|CSPSetup|
|[1a8fab469a67ba2fd5feec963f839e3b](https://www.virustotal.com/gui/file/1a8fab469a67ba2fd5feec963f839e3b)|Win32 EXE||2018-09-04 19:56:20|.|
|[bd7d773219e90d90b31e6dfa69f740f9](https://www.virustotal.com/gui/file/bd7d773219e90d90b31e6dfa69f740f9)|Win32 EXE||2018-09-04 19:35:18|CSPSetup|
|[07cd93c31b265c7905b3305b09eaaa36](https://www.virustotal.com/gui/file/07cd93c31b265c7905b3305b09eaaa36)|Win32 EXE||2018-09-04 17:48:02|ipad.system|
|[06a135e1022d5cc897b3957c9dac98b6](https://www.virustotal.com/gui/file/06a135e1022d5cc897b3957c9dac98b6)|Win32 EXE||2018-09-04 03:46:51|Photoshop|
|[a2ae7ec60b9b8b8f1b23721c7e7bc8e4](https://www.virustotal.com/gui/file/a2ae7ec60b9b8b8f1b23721c7e7bc8e4)|Win32 EXE||2018-09-03 22:40:08|Photoshop|
|[66e26ab0a7dc3c4130acb9d88f3903a8](https://www.virustotal.com/gui/file/66e26ab0a7dc3c4130acb9d88f3903a8)|Win32 EXE||2018-09-03 11:48:10|CheckSecurityUSB.exe|
|[b8aa66a0592bc4b7de8c5cf348c2ea41](https://www.virustotal.com/gui/file/b8aa66a0592bc4b7de8c5cf348c2ea41)|Win32 EXE||2018-09-02 15:02:52|Photoshop|
|[b624dbbb892487d826d9ea2a3ada9173](https://www.virustotal.com/gui/file/b624dbbb892487d826d9ea2a3ada9173)|Win32 EXE||2018-07-19 05:54:47|7ZSfxNew|
|[a8734436c6948f6879bba1dba09d8810](https://www.virustotal.com/gui/file/a8734436c6948f6879bba1dba09d8810)|Win32 EXE||2018-05-12 20:25:04|ImagingDevices.cpl|
|[c29e524436ea9cb42f27134de631432b](https://www.virustotal.com/gui/file/c29e524436ea9cb42f27134de631432b)|unknown||2018-05-08 14:23:26| |
|[28de38a9dd33947d312345186f2dc94b](https://www.virustotal.com/gui/file/28de38a9dd33947d312345186f2dc94b)|unknown||2015-07-12 10:39:59|rc4.key|
|[232ac84d1fb215e93d759c6034d43e89](https://www.virustotal.com/gui/file/232ac84d1fb215e93d759c6034d43e89)|Win32 EXE||2015-06-10 08:25:10|win32k.sys|
|[54c6f440dce326a8f7f628d2bd0e757c](https://www.virustotal.com/gui/file/54c6f440dce326a8f7f628d2bd0e757c)|Win32 DLL||2014-01-18 08:12:26|MS RC4 Encryption Plugin|
|[834c709455bfefb9b0e8976bad13a8f4](https://www.virustotal.com/gui/file/834c709455bfefb9b0e8976bad13a8f4)|Win32 EXE||2012-06-21 21:20:32|myfile.exe|
|[2d041b4a4e8870464542aad3435dfafd](https://www.virustotal.com/gui/file/2d041b4a4e8870464542aad3435dfafd)|Win32 EXE||2009-05-08 16:30:01|C:\Новая папка\win.exe|
|[bd126a7b59d5d1f97ba89a3e71425731](https://www.virustotal.com/gui/file/bd126a7b59d5d1f97ba89a3e71425731)|Win32 EXE||2009-04-25 23:42:23|%TEMP%\6349.tmp\wget.exe|
|[8aeba52be05a59306e54ef9baa917658](https://www.virustotal.com/gui/file/8aeba52be05a59306e54ef9baa917658)|DOCX||2020-03-30 17:52:57|Запит на iнформацiю.docx|
|[b6e30ea779ab250032fb7f3c2c493778](https://www.virustotal.com/gui/file/b6e30ea779ab250032fb7f3c2c493778)|DOCX|o97m|2020-03-25 12:10:26|Вiтання СБУ.docx|
|[c047dd99d3658e5df1d0f14f0beb7917](https://www.virustotal.com/gui/file/c047dd99d3658e5df1d0f14f0beb7917)|DOCX|o97m|2020-03-25 10:32:20|Р’iС‚Р°РЅРЅСЏ РЎР‘РЈ.docx|
|[5521933bb7979270c678f2649feca7ee](https://www.virustotal.com/gui/file/5521933bb7979270c678f2649feca7ee)|DOCX|o97m|2020-03-25 10:28:20|Інструкція COVID-19.docx|
|[2147f94942593ef3473ea00c83c2267d](https://www.virustotal.com/gui/file/2147f94942593ef3473ea00c83c2267d)|DOCX|o97m|2020-03-25 06:49:42|Запит на iнформацiю.docx|
|[b99dceea34d883db0ba4db7d626b11c2](https://www.virustotal.com/gui/file/b99dceea34d883db0ba4db7d626b11c2)|DOCX|o97m|2020-03-13 11:50:55|BILATERAL COOPERATION PLAN.DOCX|
|[ffa2fc9b24b87b6eead448641eb1eee8](https://www.virustotal.com/gui/file/ffa2fc9b24b87b6eead448641eb1eee8)|DOCX||2020-03-05 12:04:15|b6a94f565d482906be7da4d801153eb4dab46d92f43be3e1d59ddd2c7f328109.bin|
|[02aae0f838095a9d70004dae8d600aa1](https://www.virustotal.com/gui/file/02aae0f838095a9d70004dae8d600aa1)|LNK||2020-09-24 17:53:17|Доповідь за даними звіту СММ ОБСЄ від 08.09.2020 214-2020.lnk|
|[aa7c27927cdc2752fb19ed5ebef77c2e](https://www.virustotal.com/gui/file/aa7c27927cdc2752fb19ed5ebef77c2e)|LNK|Skeeyah|2020-09-24 16:12:09|Оперативне зведення станом на 28 липня 2020 року (за матеріалами ДЗНД та регіональних органів СБУ).lnk|
|[1910f8c2e402feaed3b2c42daa41492c](https://www.virustotal.com/gui/file/1910f8c2e402feaed3b2c42daa41492c)|TXT|Wacatac|2020-09-24 12:29:50|Звіт про заборгованість за бюджетними коштами.eml|
|[bdc37774a976e27d9c5bd178f3ac215f](https://www.virustotal.com/gui/file/bdc37774a976e27d9c5bd178f3ac215f)|RAR|Wacatac|2020-09-24 12:27:49|зведення.rar|
|[b826df9dd8241b1f5ddd24ae445f71b5](https://www.virustotal.com/gui/file/b826df9dd8241b1f5ddd24ae445f71b5)|TXT|Skeeyah|2020-09-24 12:27:29|Оперативне зведення.eml|
|[9072ce3a391123c4f87a490d59a5cc29](https://www.virustotal.com/gui/file/9072ce3a391123c4f87a490d59a5cc29)|TXT|o97m|2020-09-24 12:25:25|Про неправомірні дії слідчого СБ України.eml|
|[c307be292d9b688827c22de2464abb32](https://www.virustotal.com/gui/file/c307be292d9b688827c22de2464abb32)|LNK||2020-09-11 14:01:51|Клопотання про тимчасовий доступ до речей і документів у кримінальному провадженні 22019180000000342 від 11.03.2020 року.lnk|
|[9fd9286abc36040699f1fdd748e1d301](https://www.virustotal.com/gui/file/9fd9286abc36040699f1fdd748e1d301)|TXT|Wacatac|2020-07-16 01:03:33|85271f654a244925f9c3c8cab9e48d270b0f6a0555d5598a4533f1439564ecc3|
|[2021f95550104a55a82b94fe18964cb2](https://www.virustotal.com/gui/file/2021f95550104a55a82b94fe18964cb2)|TXT|Wacatac|2020-07-16 01:02:50|82f721290668ed2e7d8725b83ff99872b1ce7b4d71d69b5246b72b47c3a766df|
|[e3f9f8bf475f01613f0b0defc774a920](https://www.virustotal.com/gui/file/e3f9f8bf475f01613f0b0defc774a920)|TXT|Wacatac|2020-07-16 01:02:47|efbe8e4af9f65fd6017a4e7e1b0003d9cda7707cb460d91de17895da3ca34882|
|[c914d499cb3af219a0f43d06674312ff](https://www.virustotal.com/gui/file/c914d499cb3af219a0f43d06674312ff)|FPX|Wacatac|2020-07-15 09:17:11|Керівникам регіональних підрозділів задіяних в ООС.msg|
|[6e271a66789ba0380150a7c020898b7d](https://www.virustotal.com/gui/file/6e271a66789ba0380150a7c020898b7d)|FPX|Wacatac|2020-07-15 09:15:34|Запит на отримання публічної інформації.msg|
|[be65f590356af51ad26b67dc7d59c85b](https://www.virustotal.com/gui/file/be65f590356af51ad26b67dc7d59c85b)|RAR|o97m|2020-06-17 15:16:53|Дослідження.rar|
|[a33b4abb1597b652fcc57ea54e70374a](https://www.virustotal.com/gui/file/a33b4abb1597b652fcc57ea54e70374a)|TXT|o97m|2020-06-13 01:03:30|79bef521934faa13ce53e61209f0e6bf6e8b02a4058f8f7014b5811e3784852f|
|[7dc664eb3b791d67bc767c88c1012800](https://www.virustotal.com/gui/file/7dc664eb3b791d67bc767c88c1012800)|DOCX|o97m|2020-06-12 10:11:58|/var/test_dir/com/test_wait/42403c430e24e38866f5eb0f17d62432edcd988d6902e825fc4b93d1b280befb.exe|
|[89d6bbbaa54253f56af8769ed6c1e9ec](https://www.virustotal.com/gui/file/89d6bbbaa54253f56af8769ed6c1e9ec)|DOCX|CVE-2017-11882|2020-05-03 16:34:16|Условия создание фрагмента.docx|
|[3973d7da737d0cc7b6b8536f36f0c98a](https://www.virustotal.com/gui/file/3973d7da737d0cc7b6b8536f36f0c98a)|Win32 EXE|Fareit|2020-05-03 13:00:56|service.exe|
|[b5622716e68468ff38d32ef5f4795a87](https://www.virustotal.com/gui/file/b5622716e68468ff38d32ef5f4795a87)|FPX|Fareit|2020-05-03 05:37:38|4.msi|
|[0fe3f5fbf08c53ee45d8094632dbdb59](https://www.virustotal.com/gui/file/0fe3f5fbf08c53ee45d8094632dbdb59)|Win32 EXE||2020-04-30 04:33:37|C:\Windows\Installer\MSIB176.tmp|
|[e6183f5be1d907fb9a53e08b5c28a9ae](https://www.virustotal.com/gui/file/e6183f5be1d907fb9a53e08b5c28a9ae)|DOCX|CVE-2017-11882|2020-04-29 14:46:32|Условия.docx|
|[c09794ddb7f5ce5f88304843687fd55c](https://www.virustotal.com/gui/file/c09794ddb7f5ce5f88304843687fd55c)|Win32 EXE|o97m|2020-04-21 01:00:19|c09794ddb7f5ce5f88304843687fd55c.virus|
|[62fab80572b2dbd3506bec30187433db](https://www.virustotal.com/gui/file/62fab80572b2dbd3506bec30187433db)|Win32 EXE|Tiggre|2020-04-15 16:50:27|CSPSetup|
|[7df85f5215c5a11c4e2ad007bd5b1571](https://www.virustotal.com/gui/file/7df85f5215c5a11c4e2ad007bd5b1571)|Win32 EXE||2020-04-14 00:47:20|C:\perfcrt\fontwin.exe|
|[d10c70f8eef196e148fea275230de1d9](https://www.virustotal.com/gui/file/d10c70f8eef196e148fea275230de1d9)|DOCX|o97m|2020-04-13 15:05:16|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\af8d3d8de10dd577daef8662f512f04c0ee20a9eefcfcc62afa2d545ce333778|
|[3140e5c776400c841efbc79b85bf245a](https://www.virustotal.com/gui/file/3140e5c776400c841efbc79b85bf245a)|DOCX||2020-04-13 11:26:55|PROJECT.DOCX|
|[ae474082c747fd8f9b367e702cecd42f](https://www.virustotal.com/gui/file/ae474082c747fd8f9b367e702cecd42f)|DOCX|o97m|2020-04-01 07:05:11|D:\2_CV-2\2_CV-2\1_anketa-ukr 21_02.doc|
|[0faf92d7be43a3fd9c130d85f59daf9b](https://www.virustotal.com/gui/file/0faf92d7be43a3fd9c130d85f59daf9b)|DOCX||2020-03-27 13:29:17|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\29ac457c75d24595f0f4187ff1238757a2b65d4cf47dd5d50b124ebba286699f|
|[971c53db7f875a1008995b0397cba489](https://www.virustotal.com/gui/file/971c53db7f875a1008995b0397cba489)|DOCX||2020-03-26 07:44:17|Р’iС‚Р°РЅРЅСЏ РЎР‘РЈ.docx|
|[b54ad8e721a2c8175daa357dc9252103](https://www.virustotal.com/gui/file/b54ad8e721a2c8175daa357dc9252103)|DOCX|o97m|2020-03-25 10:08:00|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\0a64cb0a8c4dd82c3ee6e15dcdef50bf11c2b014d2f188b5e0f96e8fd6e41aea|
|[fb8722ae0331545a5756fb6c726ba7fa](https://www.virustotal.com/gui/file/fb8722ae0331545a5756fb6c726ba7fa)|DOCX||2020-03-23 17:33:33|test.docx|
|[7cdf57c02f50e6477452678d3023cdb8](https://www.virustotal.com/gui/file/7cdf57c02f50e6477452678d3023cdb8)|DOCX|o97m|2020-03-23 15:22:16|Project TIKA in Ukraine.docx|
|[4da1af09833868e013e02add23e59957](https://www.virustotal.com/gui/file/4da1af09833868e013e02add23e59957)|DOCX||2020-03-23 12:53:30|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\455f4b78389a4d4cfbf759074f1b550ad3d31693f66edacf78cfb3b58da1bb06|
|[7f31dc3a5051c517193b3655d2ef96db](https://www.virustotal.com/gui/file/7f31dc3a5051c517193b3655d2ef96db)|Win32 EXE|Remcos|2020-03-19 05:50:18|POEA Advisories re-2020 Novel Corona Virus.2.pdf.bin|
|[6928b6c0da32bfd34a837dafd42b3abe](https://www.virustotal.com/gui/file/6928b6c0da32bfd34a837dafd42b3abe)|DOCX|o97m|2020-03-17 08:38:09|OSCE.docx|
|[7ef3d61b6e56de27c689c668b4688414](https://www.virustotal.com/gui/file/7ef3d61b6e56de27c689c668b4688414)|DOCX||2020-03-16 10:58:13|OSCE.docx|
|[8ab0f330f7307210b6f7daf34632d513](https://www.virustotal.com/gui/file/8ab0f330f7307210b6f7daf34632d513)|Win32 DLL|Razy|2020-03-12 12:50:47|8ab0f330f7307210b6f7daf34632d513.virus|
|[2e70b2b0cf4e2d3ac2ed6d1ea967f18e](https://www.virustotal.com/gui/file/2e70b2b0cf4e2d3ac2ed6d1ea967f18e)|DOC|o97m|2020-03-07 17:56:05|250b09f87fe506fbc6cedf9dbfcb594f7795ed0e02f982b5837334f09e8a184b.bin|
|[a887990c6d16ddd9b3b6a95c9625cd12](https://www.virustotal.com/gui/file/a887990c6d16ddd9b3b6a95c9625cd12)|DOC|o97m|2020-03-06 20:39:36|9cd5fa89d579a664c28da16064057096a5703773cef0a079f228f21a4b7fd5d2.bin|
|[7ed9035341a1906ff731236633b8d911](https://www.virustotal.com/gui/file/7ed9035341a1906ff731236633b8d911)|DOCX|o97m|2020-03-06 10:04:29|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\036c2088cb48215f21d4f7d751d750b859d57018c04f6cadd45c0c4fee23a9f8|
|[9786a23382b5d7ed1f1f8d640cfc82b5](https://www.virustotal.com/gui/file/9786a23382b5d7ed1f1f8d640cfc82b5)|DOCX|PhishingSite|2020-03-05 18:36:05|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\19d03a25af5b71e859561ff8ccc0a073acb9c61b987bdb28395339f72baf46b4|
|[c49732e71629a9024efe7599e0bb1280](https://www.virustotal.com/gui/file/c49732e71629a9024efe7599e0bb1280)|DOC|o97m|2020-03-05 17:06:35|c089ccd376c9a4d5e5bdd553181ab4821d2c26fefc299cce7a4f023a660484d5.bin|
|[6885d6b44be537824377b74b63534d82](https://www.virustotal.com/gui/file/6885d6b44be537824377b74b63534d82)|DOCX|o97m|2020-03-05 07:34:38|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\84e0b1d94a43c87de55c000e3acae17f4493a57badda3b27146ad8ed0f90c93e|
|[3352636bdec80c3a6876d09cb043aa9d](https://www.virustotal.com/gui/file/3352636bdec80c3a6876d09cb043aa9d)|DOCX|o97m|2020-03-04 13:39:18|cc775e3cf1a64effa55570715b73413c3ea3a6b47764a998b1272b5be059c25b.bin|
|[7219192d3fce7a1b2a0b6320da6cc4a3](https://www.virustotal.com/gui/file/7219192d3fce7a1b2a0b6320da6cc4a3)|DOCX||2020-03-03 09:27:19|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\8310d39aa1cdd13ca82c769d61049310f8ddaea7cd2c3b940a8a3c248e5e7b06|
|[9cbb376a12b0b45566218988f3327a6b](https://www.virustotal.com/gui/file/9cbb376a12b0b45566218988f3327a6b)|Win32 EXE|Kryptik|2020-02-26 07:39:14|pLPYaR.exe|
|[5d195e8c89c1340edc1eb395efee07b3](https://www.virustotal.com/gui/file/5d195e8c89c1340edc1eb395efee07b3)|DOC|o97m|2020-02-25 07:35:17|946405e2f26e1cc0bd22bc7e12d403da939f02e9c4d8ddd012f049cf4bf1fda9.bin|
|[24d81c9a605ccaca1a625576f22d1dae](https://www.virustotal.com/gui/file/24d81c9a605ccaca1a625576f22d1dae)|DOCX|o97m|2020-02-24 15:52:57|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\85267e52016b6124e4e42f8b52e68475174c8a2bdf0bc0b501e058e2d388a819|
|[f59c558d9b33a25ac8b32f495f6fd035](https://www.virustotal.com/gui/file/f59c558d9b33a25ac8b32f495f6fd035)|Win32 EXE|Remcos|2020-02-24 02:33:53|C:\Users\Administrator\AppData\Local\Temp\POEA HEALTH ADVISORY re-2020 Novel Corona Virus.pdf.exe|
|[876fbe266169f49ba8529371539aea42](https://www.virustotal.com/gui/file/876fbe266169f49ba8529371539aea42)|DOCX|o97m|2020-02-21 12:52:37|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\76486e88533eafd7599afb761c8afc1ab2ecc82c77f1612ae23efe2a53e450d9|
|[d63ad6a56ccf39e9f14c18dd34877372](https://www.virustotal.com/gui/file/d63ad6a56ccf39e9f14c18dd34877372)|DOCX||2020-02-19 15:58:38|dod_91301035.docx|
|[36edd53ae803acf01300c357912b8732](https://www.virustotal.com/gui/file/36edd53ae803acf01300c357912b8732)|DOCX||2020-02-19 13:20:30|копії документів.docx|
|[a4dd0a5d5fe84107042acf20d4e4fb42](https://www.virustotal.com/gui/file/a4dd0a5d5fe84107042acf20d4e4fb42)|DOCX|sLoad|2020-02-19 10:02:27|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\5f3625d52ef0d8880038525d8239c91fc5b9f844d16a22e11b37c60b701c10de|
|[c8178099e0d3c41b167deb1ebddf04d9](https://www.virustotal.com/gui/file/c8178099e0d3c41b167deb1ebddf04d9)|DOC|Valyria|2020-02-19 08:07:09|4.dot|
|[5127bf64cae774bf6c8796b716ddcd7a](https://www.virustotal.com/gui/file/5127bf64cae774bf6c8796b716ddcd7a)|DOCX||2020-02-18 14:31:46|ae585bd2daf391eda369b1fcfd6f30d974bb2a62e1d88c9fc59935ab404f0a80.docx.bin|
|[444ea777c80e44f993116db8bdbcc925](https://www.virustotal.com/gui/file/444ea777c80e44f993116db8bdbcc925)|DOCX|sLoad|2020-02-18 07:39:35|36956_1582020906_fd8de97c7be6be03bfbe398058998994348407b29af5624855d98c24e91e077b|
|[fb66c5163f0d956f276e383c1ce614fd](https://www.virustotal.com/gui/file/fb66c5163f0d956f276e383c1ce614fd)|DOCX||2020-02-17 14:18:28|копії документів.docx|
|[61ce777555ee4d591ff151e0927ab8d4](https://www.virustotal.com/gui/file/61ce777555ee4d591ff151e0927ab8d4)|Win32 EXE||2020-02-17 06:07:57|fejlstatis|
|[a3042b64c0c3086b890cc3f6cfb334dd](https://www.virustotal.com/gui/file/a3042b64c0c3086b890cc3f6cfb334dd)|Win32 EXE|Fareit|2020-02-17 06:07:56|Absolut8|
|[7e8e435dcceccb90924cb7c672cb22a8](https://www.virustotal.com/gui/file/7e8e435dcceccb90924cb7c672cb22a8)|XLSM|o97m|2020-02-14 11:49:34|17161e0ab3907f637c2202a384de67fca49171c79b1b24db7c78a4680637e3d5.bin|
|[4098d58f016f3274d28fda17143a2214](https://www.virustotal.com/gui/file/4098d58f016f3274d28fda17143a2214)|XLSM|o97m|2020-02-14 08:30:51|315e297ac510f3f2a60176f9c12fcf92681bbad758135767ba805cdea830b9ee.bin|
|[87a20b16fb3b87f76cbeb5ae80ea97dc](https://www.virustotal.com/gui/file/87a20b16fb3b87f76cbeb5ae80ea97dc)|XLSM||2020-02-14 07:41:47|ab533d6ca0c2be8860a0f7fbfc7820ffd595edc63e540ff4c5991808da6a257d.bin|
|[8b13fbe298577ebaf4dbd3a5f608db01](https://www.virustotal.com/gui/file/8b13fbe298577ebaf4dbd3a5f608db01)|DOCX|sLoad|2020-02-13 10:36:17|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\65768b96918a26ad548ecf9d6c4801029f21207801e91c35803b8c7af5ae8cb4|
|[7c7386c86cfeb790fe65dc27545da45f](https://www.virustotal.com/gui/file/7c7386c86cfeb790fe65dc27545da45f)|DOC|Valyria|2020-02-12 00:23:03|payload_1.exe|
|[7ccdc032f75bc86691d01624163f3d9c](https://www.virustotal.com/gui/file/7ccdc032f75bc86691d01624163f3d9c)|DOCX|o97m|2020-02-11 21:44:49|41211089112.docx|
|[f09caf4b676f0c5e0960c875d35233a9](https://www.virustotal.com/gui/file/f09caf4b676f0c5e0960c875d35233a9)|DOCX|o97m|2020-02-11 13:09:12|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\92a2e3b3c9409d27d6a9ad0b6f6ba1fca06a1085b31361448ff982cc355ae50e|
|[adc1731b9c5079e6f50a6e0922d781fa](https://www.virustotal.com/gui/file/adc1731b9c5079e6f50a6e0922d781fa)|DOCX||2020-02-03 08:57:03|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\02a2c65af9e4791b41ef6aa32c2ab4e2ff599249617ac192232fc2b9b923fcf2|
|[0200516105bb4189dd76e3711b078b6f](https://www.virustotal.com/gui/file/0200516105bb4189dd76e3711b078b6f)|DOC|Valyria|2020-01-30 10:23:06|lushtom.dot|
|[a46d83ad3239327c36209638a898e3e5](https://www.virustotal.com/gui/file/a46d83ad3239327c36209638a898e3e5)|DOCX||2020-01-30 07:56:35|Концепція виборів 2020.docx|
|[16dffa9b40d15e6bde46818a3896d0cf](https://www.virustotal.com/gui/file/16dffa9b40d15e6bde46818a3896d0cf)|DOCX||2020-01-29 16:01:35|РљРѕРЅС†РµРїС†С–СЏ РІРёР±РѕСЂС–РІ 2020.docx|
|[7ad46247c3afea892771d091a813a88d](https://www.virustotal.com/gui/file/7ad46247c3afea892771d091a813a88d)|DOCX||2020-01-29 12:19:05|D:\Download\Концепція виборів 2020.docx|
|[049b0f0e415832d5f3f52cb260e513c5](https://www.virustotal.com/gui/file/049b0f0e415832d5f3f52cb260e513c5)|DOC|Valyria|2020-01-29 09:22:50|rudolfa.dot|
|[9f8824f9e505f08d338251c62a8bfc65](https://www.virustotal.com/gui/file/9f8824f9e505f08d338251c62a8bfc65)|DOC|Valyria|2020-01-28 11:16:20|dukro.dot|
|[553f7fdc124ecaeabade7949a01e57a8](https://www.virustotal.com/gui/file/553f7fdc124ecaeabade7949a01e57a8)|DOC|occamy|2020-01-28 11:15:51|kilo.dot|
|[a4b6abdbcdceab1ad5cf6784600aca34](https://www.virustotal.com/gui/file/a4b6abdbcdceab1ad5cf6784600aca34)|DOCX|sLoad|2020-01-27 15:59:31|225-0-20.docx|
|[d44d7050dcdd93aa9516c1dc6cb0c988](https://www.virustotal.com/gui/file/d44d7050dcdd93aa9516c1dc6cb0c988)|DOC|o97m|2020-01-16 21:04:54|musik.dot|
|[b677fc191f139f3c55ef416b86f028ed](https://www.virustotal.com/gui/file/b677fc191f139f3c55ef416b86f028ed)|DOCX||2020-01-16 14:21:58|Доступ до публічної інформації.docx|
|[df5ecffd866f24452031b27351c016ae](https://www.virustotal.com/gui/file/df5ecffd866f24452031b27351c016ae)|DOCX||2020-01-16 12:13:54|Доступ до публічної інформації.docx|
|[c0dc0c23e675d0c380e243fb36ee005e](https://www.virustotal.com/gui/file/c0dc0c23e675d0c380e243fb36ee005e)|DOCX|o97m|2020-01-14 14:19:13|c0dc0c23e675d0c380e243fb36ee005e.DOCX|
|[79acfbb6e17c81fa2304425e2470bc5a](https://www.virustotal.com/gui/file/79acfbb6e17c81fa2304425e2470bc5a)|DOCX|sLoad|2020-01-13 17:01:27|20110020141.docx|
|[d1122e13aedfee3c8b908edc6055103f](https://www.virustotal.com/gui/file/d1122e13aedfee3c8b908edc6055103f)|Win32 DLL|Razy|2020-01-13 01:28:40|dttcodexgigas.567a7162d803599a28c923d1641cd2d406c08c68|
|[4286a15469ae50182cea715ed6fa4109](https://www.virustotal.com/gui/file/4286a15469ae50182cea715ed6fa4109)|Win32 EXE|Razy|2020-01-12 14:24:06|Aversome.exe|
|[b429db29d9a3ca1decc4245d83a00c12](https://www.virustotal.com/gui/file/b429db29d9a3ca1decc4245d83a00c12)|TXT||2020-01-12 14:24:04|%TEMP%\7zipsfx.000\excelmymacros.txt|
|[7084f660bebd624e3346e1c0f675e328](https://www.virustotal.com/gui/file/7084f660bebd624e3346e1c0f675e328)|TXT||2020-01-12 14:24:03|%TEMP%\7zipsfx.000\wordmacros.txt|
|[62690979d73cfb6a38994e25a0b7aa4f](https://www.virustotal.com/gui/file/62690979d73cfb6a38994e25a0b7aa4f)|TXT||2020-01-12 14:23:58|%TEMP%\7zipsfx.000\8957.cmd|
|[af19975e1450d0ca7c4533f11d5e67d2](https://www.virustotal.com/gui/file/af19975e1450d0ca7c4533f11d5e67d2)|Win32 EXE|occamy|2020-01-12 13:11:10|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\28847|
|[107010d9e4ff8436f872f17a2b13bbe4](https://www.virustotal.com/gui/file/107010d9e4ff8436f872f17a2b13bbe4)|Win32 EXE|Starter|2020-01-12 10:42:57|D:\Virus\Pterodo_10.01.2020\2\2\7ZipSfx.018\xOtAJwL.exe|
|[b26b88cfdd4b358b02929dcf47da7a2f](https://www.virustotal.com/gui/file/b26b88cfdd4b358b02929dcf47da7a2f)|DOC|o97m|2020-01-09 15:54:06|creatives.dot|
|[b2484c5a5a061f707f339769d7848f89](https://www.virustotal.com/gui/file/b2484c5a5a061f707f339769d7848f89)|DOCX|sLoad|2020-01-09 13:15:10|РњР°С‚РµСЂС–Р°Р»Рё РќРђР РђР”Р?? (10.01.2020).docx|
|[c9fef16e054a3a83f4c7da58629ae3b9](https://www.virustotal.com/gui/file/c9fef16e054a3a83f4c7da58629ae3b9)|DOCX|sLoad|2020-01-02 07:15:12|6147838.docx|
|[11d780dce6461482686da081ffa60d22](https://www.virustotal.com/gui/file/11d780dce6461482686da081ffa60d22)|DOC|o97m|2019-11-18 19:34:39|e2cb06e0a5c14b4c5f58d0e56a1dc10b6a1007cf56c77ae6cb07946c3dfe82d8.bin|
|[a25210fd54f7af0940280dfdea6da8f1](https://www.virustotal.com/gui/file/a25210fd54f7af0940280dfdea6da8f1)|TXT||2019-11-18 16:02:58|39c6884526e7b7f2ed6e47b630010508bb5957385eccf248c961cbd5bcb802c6.bin|
|[2fd3d6c6badd772442a3b6c420c43ab2](https://www.virustotal.com/gui/file/2fd3d6c6badd772442a3b6c420c43ab2)|Win32 DLL|Skeeyah|2019-10-06 02:00:26|<LS_APPDATA>\microsoft\windows\explorer\explorer.dll|
|[34ba523de5fa043bc77371799f261458](https://www.virustotal.com/gui/file/34ba523de5fa043bc77371799f261458)|Win64 EXE||2015-09-24 20:17:21|C:\Users\Evgeny\Documents\wintools\7+ Taskbar Tweaker\winapiexec\winapiexec64.exe|
