|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[9fbdc5eca123e81571e8966b9b4e4a1e](https://www.virustotal.com/gui/file/9fbdc5eca123e81571e8966b9b4e4a1e)|Win32 EXE|Kryptik|2015-11-14 11:33:51|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkTequila/DarkTequila.exe|
|[5b03784620586f3190146ead20e26770](https://www.virustotal.com/gui/file/5b03784620586f3190146ead20e26770)|Win32 EXE|Kryptik|2015-11-05 07:18:24|4f49a01e02e8c47d84480f6fb92700aa091133c894821fff83c7502c7af136d9.bin|
