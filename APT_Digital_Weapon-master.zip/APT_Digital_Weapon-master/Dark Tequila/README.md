**NAME:**  
Dark Tequila  

**Description**:   
Dark Tequila is a complex malicious campaign targeting Mexican users, with the primary purpose of stealing financial information, as well as login credentials to popular websites that range from code versioning repositories to public file storage accounts and domain registrars. The campaign has been active since at least 2013 and there are two known infection vectors: spear-phishing and infection by USB device.
  
**References**:  
https://securelist.com/dark-tequila-anejo/87528/