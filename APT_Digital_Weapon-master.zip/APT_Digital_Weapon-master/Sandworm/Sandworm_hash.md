|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[67b1d64f669eabd6f843a163edeb88a2](https://www.virustotal.com/gui/file/67b1d64f669eabd6f843a163edeb88a2)|Win32 EXE||2018-10-29 14:20:53|wsmprovav.exe|
|[0fd6c923edc283fb034f12557bd7719d](https://www.virustotal.com/gui/file/0fd6c923edc283fb034f12557bd7719d)|Win32 DLL||2018-09-26 07:32:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/VoodooBearAPT/BlackEnergy.bin|
|[6884e3541834cc5310a3733f44b38910](https://www.virustotal.com/gui/file/6884e3541834cc5310a3733f44b38910)|Win32 DLL||2018-09-26 07:32:49|msiexec|
