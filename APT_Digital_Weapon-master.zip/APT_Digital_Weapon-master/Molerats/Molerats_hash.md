|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4ab58bdb5cfd3a41242eabcc2526c4b9](https://www.virustotal.com/gui/file/4ab58bdb5cfd3a41242eabcc2526c4b9)|Win32 EXE||2019-11-28 11:02:35|______ _____ ______.bin|
|[e92dfda447e5ffcecf39eece07723d04](https://www.virustotal.com/gui/file/e92dfda447e5ffcecf39eece07723d04)|RAR||2019-11-28 10:44:19|حكومة اشتية باسماء.uue|
|[95194b04018a200d1413f501ff31ecf1](https://www.virustotal.com/gui/file/95194b04018a200d1413f501ff31ecf1)|Win32 EXE||2019-10-23 12:16:01|safaratt.exe|
|[c61aa3ab6d335ef45dd4345b7f3ce276](https://www.virustotal.com/gui/file/c61aa3ab6d335ef45dd4345b7f3ce276)|Android||2019-10-14 07:55:54|101510_Google_Play_Store.apk|
|[058368ede8f3b487768e1beb0070a4b8](https://www.virustotal.com/gui/file/058368ede8f3b487768e1beb0070a4b8)|Win32 EXE|barys|2019-10-09 20:31:01|PE Explorer|
|[bef000aa7ccfd79b76a645ed60462ed1](https://www.virustotal.com/gui/file/bef000aa7ccfd79b76a645ed60462ed1)|ZIP||2019-10-08 15:57:51|alkharijia.zip";filename*=UTF-8''alkharijia.zip|
|[7d45cc22d0b11ca9eb82d3ad45fe03bb](https://www.virustotal.com/gui/file/7d45cc22d0b11ca9eb82d3ad45fe03bb)|DOCX||2019-09-28 08:59:16|s.docx|
|[9130aa7170a3663cd781010c7261171d](https://www.virustotal.com/gui/file/9130aa7170a3663cd781010c7261171d)|Win32 EXE||2019-08-26 10:56:29|wdwd.exe|
|[d38592133501622f7a649a2b16d0d1d6](https://www.virustotal.com/gui/file/d38592133501622f7a649a2b16d0d1d6)|Win32 EXE||2019-06-25 08:01:23|________ _____ ____ ___ ___ ______ _________ ______ ____ _____.exe|
|[947557a55267dffb3f85e0d7496a3679](https://www.virustotal.com/gui/file/947557a55267dffb3f85e0d7496a3679)|Win32 EXE|Xtreme|2019-05-27 13:24:56|Zaha‮4pm.scr|
|[75ea74251fa57750681c8e6f99696b1b](https://www.virustotal.com/gui/file/75ea74251fa57750681c8e6f99696b1b)|Win32 EXE||2019-04-15 18:37:25|.|
|[46173adc26721fb54f6e1a1091a892d4](https://www.virustotal.com/gui/file/46173adc26721fb54f6e1a1091a892d4)|Win32 EXE|razy|2019-01-31 19:38:18|HelpPane.exe|
|[063a50e5e4b4d17a23ac8c8b33501719](https://www.virustotal.com/gui/file/063a50e5e4b4d17a23ac8c8b33501719)|DOCM||2019-01-31 13:07:40|1.doc|
|[c9cae9026ee2034626e4a43cfdd8b192](https://www.virustotal.com/gui/file/c9cae9026ee2034626e4a43cfdd8b192)|Win32 EXE||2019-01-31 10:32:34|PasswordChanger1C.exe|
|[c2ee081ec3adef4afacab1f326ee50ff](https://www.virustotal.com/gui/file/c2ee081ec3adef4afacab1f326ee50ff)|Win32 EXE||2018-11-15 10:12:28|myfile.exe|
|[9fe7666e41086ea039ca5bbdf32f8b81](https://www.virustotal.com/gui/file/9fe7666e41086ea039ca5bbdf32f8b81)|RAR||2018-11-06 10:19:20|_______ ______ ______.rar";filename*=UTF-8''%D8%A7%D9%84%D8%AA%D8%B3%D8%AC%D9%8A%D9%84%20%D8%A7%D9%84%D8%B5%D9%88%D8%AA%D9%8A%20%D8%A7%D9%84%D8%A3%D8%B5%D9%84%D9%8A.rar|
|[be1093ae9878fedc847f2fe599265504](https://www.virustotal.com/gui/file/be1093ae9878fedc847f2fe599265504)|Text||2018-10-30 15:02:26|VirusShare_be1093ae9878fedc847f2fe599265504|
|[a8d2f8d5c0195a6d20cf9218de1c7a6c](https://www.virustotal.com/gui/file/a8d2f8d5c0195a6d20cf9218de1c7a6c)|Win32 EXE||2018-10-26 07:43:38|محضر اجتماع اللجنة التنفيذية لمنظمة التحرير الفلسطينية امس الاربعاء.exe|
|[b92dfbaf520fea67cbbc9e6d9530e89a](https://www.virustotal.com/gui/file/b92dfbaf520fea67cbbc9e6d9530e89a)|Win32 EXE||2018-10-25 06:51:46|محضر اجتماع سري جمع الرئيس عباس مع ماجد فرج.exe|
|[51a59aec24b5046ec4615728a5b52802](https://www.virustotal.com/gui/file/51a59aec24b5046ec4615728a5b52802)|Win32 EXE||2018-10-22 09:14:53|E:\Samples\BitFunnelAVC\1022\needAssign\1afc85ec106b21cdaeee2c353f0a75e85a9da8af0edc0817eb989ddc7f230501|
|[342a4d93df060289b2d8362461875905](https://www.virustotal.com/gui/file/342a4d93df060289b2d8362461875905)|Win32 EXE|Kryptik|2018-10-15 12:57:01|Process Explorer|
|[16cf86aacb8926eab66259d8a5946ed9](https://www.virustotal.com/gui/file/16cf86aacb8926eab66259d8a5946ed9)|Win32 EXE||2018-10-10 09:14:38|Folder.exe|
|[a93792edd5a522f7bcd597550853d345](https://www.virustotal.com/gui/file/a93792edd5a522f7bcd597550853d345)|Win32 EXE|Omaneat|2018-10-02 06:18:05|رد حركة حماس على ورقة المصالحة المصرية.exe|
|[4f34902c9f458008bae26bfa5c1c00da](https://www.virustotal.com/gui/file/4f34902c9f458008bae26bfa5c1c00da)|RAR|Omaneat|2018-10-01 08:08:20|Fateh.hamas.rar|
|[6767b5c04a5be3e50879490b6104135c](https://www.virustotal.com/gui/file/6767b5c04a5be3e50879490b6104135c)|Win32 EXE||2018-09-28 14:25:56|تعميم خاص للسادة السفراء ...exe|
|[535f8ea65969a84a68ceaf88778c6176](https://www.virustotal.com/gui/file/535f8ea65969a84a68ceaf88778c6176)|RAR||2018-09-27 16:02:51|Scaner20-09.rar|
|[10dfa690662b9c6db805b95500fc753d](https://www.virustotal.com/gui/file/10dfa690662b9c6db805b95500fc753d)|Win32 EXE||2018-09-27 13:08:56|ccleaner|
|[ce5aa4956d4d0d66bed361ddd7db1a3b](https://www.virustotal.com/gui/file/ce5aa4956d4d0d66bed361ddd7db1a3b)|RAR|Kryptik|2018-09-26 13:51:34|empassy 05-09-2018.rar|
|[cab62bb5f00fe15683c6af760c8e8f7e](https://www.virustotal.com/gui/file/cab62bb5f00fe15683c6af760c8e8f7e)|Win32 EXE|Kryptik|2018-09-25 06:47:37|WindowPicture.exe|
|[905ebd9fc96d835041417e95d7e3485d](https://www.virustotal.com/gui/file/905ebd9fc96d835041417e95d7e3485d)|Win32 EXE||2018-09-23 12:29:27|asd.exe|
|[92dd0f16e8ae274d83ba1d0d5b2e3428](https://www.virustotal.com/gui/file/92dd0f16e8ae274d83ba1d0d5b2e3428)|Win32 EXE||2018-09-18 09:34:39|GameDownload|
|[e686ffa90b2bfb567547f1c0dad1ae0b](https://www.virustotal.com/gui/file/e686ffa90b2bfb567547f1c0dad1ae0b)|RAR||2018-09-17 16:22:34|93204e5b027f94fa4e351369da33a680c1db5bb6bc9368f6be95717e615773ac.bin|
|[883450ffe5f36e7fc8845b4ccf727ad3](https://www.virustotal.com/gui/file/883450ffe5f36e7fc8845b4ccf727ad3)|Win32 EXE||2018-09-13 07:53:43|ccleaner|
|[64acf1090cb5d41382a2ea5f87a9dcfc](https://www.virustotal.com/gui/file/64acf1090cb5d41382a2ea5f87a9dcfc)|Win32 EXE||2018-09-10 05:45:34|=?UTF-8?B?2LLZitin2LHYqSDYudin2KzZhNipINmI2LPYsdmK2LnYqSDZhNmI2YHYryDZgtmK2KfYr9iq2YbYpyDZhNmE2YLYp9mH2LHYqSDZhNio2K3YqyDYp9mF2YjYsSDYrNmI2YfYsdmK2KkuZXhl?=|
|[f1d744b367a1ad3617a0efb7f55b2d20](https://www.virustotal.com/gui/file/f1d744b367a1ad3617a0efb7f55b2d20)|Win32 EXE||2018-09-10 05:44:57|=?UTF-8?B?2LPYqNioINin2YTYstmK2KfYsdipINin2YTYudin2KzZhNipINmI2YTZgtin2KEg2YXYuSDZiNmB2K8g2K/YrdmE2KfZhi5leGU=?=|
|[a8215f6123c062adfade83c772c85358](https://www.virustotal.com/gui/file/a8215f6123c062adfade83c772c85358)|Win32 EXE||2018-09-09 09:45:33|a8215f6123c062adfade83c772c85358-pe|
|[debf2c03ad06c09cedb55b2bccd5d9a1](https://www.virustotal.com/gui/file/debf2c03ad06c09cedb55b2bccd5d9a1)|Win32 EXE||2018-09-04 09:38:08|محضر اجتماع الرئيس عباس مع وفد المخابرات المصرية.exe|
|[2caf83a20774f4e56532b3a1197ec71e](https://www.virustotal.com/gui/file/2caf83a20774f4e56532b3a1197ec71e)|Win32 EXE||2018-08-28 12:25:39|=?UTF-8?B?2YXYpyDYs9mK2KrZhSDYqNit2KvZhyDZgdmKINin2KzYqtmF2KfYuSDYp9mE2YTYrNmG2Kkg2KfZhNiq2YbZgdmK2LDZitipINin2YTZhNmK2YTYqSAuLiDZiNmC2LHYp9ix2KfYqiDYrdin2LPZhdipLmV4ZQ==?=|
|[a233d90b8e5c19c4b3373bb76eb11428](https://www.virustotal.com/gui/file/a233d90b8e5c19c4b3373bb76eb11428)|Win32 EXE||2018-08-04 10:13:33|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/TheBigBang.bin|
|[6df5103e673b1b8424b4435efbdb935c](https://www.virustotal.com/gui/file/6df5103e673b1b8424b4435efbdb935c)|Win32 EXE||2018-07-30 08:35:51|مسودة اتفاق تهدئة شاملة لقطاع غزة.exe|
|[87d7d314f86f61a9099a51c269b4ec78](https://www.virustotal.com/gui/file/87d7d314f86f61a9099a51c269b4ec78)|Win32 EXE||2018-07-11 02:18:12|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/TheBigBangImplant.bin|
|[2e651c1ceed5a18d3d601c66c799cb2e](https://www.virustotal.com/gui/file/2e651c1ceed5a18d3d601c66c799cb2e)|Win32 EXE||2018-07-11 01:57:40|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/GazaGroupImplant.bin|
|[4c04feb7df387bb9fe778b2af7904d3a](https://www.virustotal.com/gui/file/4c04feb7df387bb9fe778b2af7904d3a)|Win32 EXE|razy|2018-07-10 07:20:12|Folder.exe|
|[4f9383ae4d0285aeb86e56797f3193f7](https://www.virustotal.com/gui/file/4f9383ae4d0285aeb86e56797f3193f7)|DEX|androidos|2018-06-11 12:03:58|u9wy99-KVn4v7oxw46Nx20180617-12936-16gho3n|
|[8f1b709ae4fb41b32674ca8c41bfcbf7](https://www.virustotal.com/gui/file/8f1b709ae4fb41b32674ca8c41bfcbf7)|Android||2018-06-10 12:57:30|Golden Cup_v1.1 (anew.football.cup.world.com.worldcup).apk|
|[fd8c8ae6a261b0e88df06236c5b70be6](https://www.virustotal.com/gui/file/fd8c8ae6a261b0e88df06236c5b70be6)|Win32 EXE|razy|2018-04-22 04:26:15|Interenet Assistant.exe|
|[81881a0841deaa0ef1ea92c51d8c8845](https://www.virustotal.com/gui/file/81881a0841deaa0ef1ea92c51d8c8845)|Win32 EXE||2018-04-20 04:19:07|Win Graphic Driver.exe|
|[a3dc31c456508df7dfac8349eb0d2b65](https://www.virustotal.com/gui/file/a3dc31c456508df7dfac8349eb0d2b65)|DOC||2018-04-18 08:47:09|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/TheBigBangAPT.doc|
|[18864d22331fc6503641f128226aaea8](https://www.virustotal.com/gui/file/18864d22331fc6503641f128226aaea8)|Win32 EXE||2018-04-17 09:50:44|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/ImplantBigBang.bin|
|[2f8face85084bea8adacac36ee2f641f](https://www.virustotal.com/gui/file/2f8face85084bea8adacac36ee2f641f)|Win32 EXE||2018-04-17 09:48:54|التقرير الإعلامي الشهري.exe|
|[805ca34e94da9615c13d8af48307fb07](https://www.virustotal.com/gui/file/805ca34e94da9615c13d8af48307fb07)|Win32 EXE|razy|2018-04-11 08:38:58|Folder.exe|
|[f6ffa064a492e91854d35e7f225b1313](https://www.virustotal.com/gui/file/f6ffa064a492e91854d35e7f225b1313)|Android||2018-03-15 00:37:25|com.winkchat.apk|
|[57917f2b37fd187104b8775a831605f7](https://www.virustotal.com/gui/file/57917f2b37fd187104b8775a831605f7)|Android||2018-01-10 15:50:58|57917f2b37fd187104b8775a831605f7.virus|
|[b3e40659ae0a0852e2f6eb928d402d9d](https://www.virustotal.com/gui/file/b3e40659ae0a0852e2f6eb928d402d9d)|Android||2017-12-22 05:47:29|com.coder.glancelove.apk|
|[7a9503152b4c8c1ee80ac7daf5405a91](https://www.virustotal.com/gui/file/7a9503152b4c8c1ee80ac7daf5405a91)|Android||2017-12-15 02:51:10|y16AsJJ2ejQypcHpzGaF20180617-26324-1o346yv|
|[754b8fa89f8e86ba4467bd3ea7c613ce](https://www.virustotal.com/gui/file/754b8fa89f8e86ba4467bd3ea7c613ce)|Android||2017-12-08 03:08:11|com.voka.vokachat.apk|
|[5b2aac6372dea167c737b0036e1bd515](https://www.virustotal.com/gui/file/5b2aac6372dea167c737b0036e1bd515)|Android||2017-11-23 06:29:02|uJys9zXkGzBhv8WfxMQz20180617-28640-1aqcu8p|
|[ab062d97943cb28647738f17c328b926](https://www.virustotal.com/gui/file/ab062d97943cb28647738f17c328b926)|Android||2017-11-20 02:05:20|com.arabway.chattak.apk|
|[95a782bd8711ac14ad76b068767515d7](https://www.virustotal.com/gui/file/95a782bd8711ac14ad76b068767515d7)|Android||2017-11-17 00:49:37|p_zrbSHXqiQ5RzvJg44m20180617-3650-x8pitv|
|[336f5a833cda25df3a72e330a4e8c304](https://www.virustotal.com/gui/file/336f5a833cda25df3a72e330a4e8c304)|Win32 EXE||2017-10-21 12:09:42|E:/virussign/malware/new_request/20171024/336f5a833cda25df3a72e330a4e8c304.vir|
|[7e98a474b77cf5807186dac773d355c7](https://www.virustotal.com/gui/file/7e98a474b77cf5807186dac773d355c7)|Android||2017-07-31 20:03:27|7e98a474b77cf5807186dac773d355c7.virus|
|[552796e71f7ff304f91b39f5da46499b](https://www.virustotal.com/gui/file/552796e71f7ff304f91b39f5da46499b)|Win32 EXE|MSILPerseus|2017-07-26 00:08:08|nvStView.exe|
|[ea406ea60a05afa14f7debc67a75a472](https://www.virustotal.com/gui/file/ea406ea60a05afa14f7debc67a75a472)|Win32 EXE||2017-07-18 13:46:23|Folder.exe|
|[ebd8f1104e138ea07b3dbf432d855987](https://www.virustotal.com/gui/file/ebd8f1104e138ea07b3dbf432d855987)|Android||2017-07-07 09:03:20|systemupdate.apk|
|[2b3df594e5d73a95c9f2d820072b067a](https://www.virustotal.com/gui/file/2b3df594e5d73a95c9f2d820072b067a)|Win32 DLL||2017-06-20 13:12:25|/home/ubuntu/pastes/RVTJ1qXG.exe|
|[bfefedb094f40c276bf1ae26b225e310](https://www.virustotal.com/gui/file/bfefedb094f40c276bf1ae26b225e310)|Win32 EXE||2017-06-20 12:51:01|notepad.exe|
|[4f3b1a2088e473c7d2373849deb4536f](https://www.virustotal.com/gui/file/4f3b1a2088e473c7d2373849deb4536f)|Win32 EXE|CobaltStrike|2017-06-20 12:50:59|4f3b1a2088e473c7d2373849deb4536f.virus|
|[87a67371770fda4c2650564cbb00934d](https://www.virustotal.com/gui/file/87a67371770fda4c2650564cbb00934d)|RTF|CVE-2017-0199|2017-06-20 10:13:51|87a67371770fda4c2650564cbb00934d.virus|
|[3ff60c100b67697163291690e0c2c2b7](https://www.virustotal.com/gui/file/3ff60c100b67697163291690e0c2c2b7)|Win32 EXE|Bublik|2017-05-28 13:05:18|db53b35c80e8ec3f8782c4d34c83389e8e9b837a6b3cc700c1b566e4e4450ec2.exe|
|[66f144be4d4ef9c83bea528a4cd3baf3](https://www.virustotal.com/gui/file/66f144be4d4ef9c83bea528a4cd3baf3)|Win32 EXE|Bublik|2017-05-28 07:55:58|Firefox|
|[6fba58b9f9496cc52e78379de9f7f24e](https://www.virustotal.com/gui/file/6fba58b9f9496cc52e78379de9f7f24e)|Win32 EXE|MSILPerseus|2017-05-14 14:50:19|nvStView.exe|
|[7d3426d8eb70e4486e803afb3eeac14f](https://www.virustotal.com/gui/file/7d3426d8eb70e4486e803afb3eeac14f)|Win32 EXE|Bublik|2017-05-04 08:20:40|284af7a2fafdbff3bbc28b9075f469d2352758b62d182b0e056d29ee74688126.bin|
|[0ee4757ab9040a95e035a667457e4bc6](https://www.virustotal.com/gui/file/0ee4757ab9040a95e035a667457e4bc6)|Win32 EXE|Bublik|2017-04-27 08:51:43|0ee4757ab9040a95e035a667457e4bc6.virus|
|[a3de096598e3c9c8f3ab194edc4caa76](https://www.virustotal.com/gui/file/a3de096598e3c9c8f3ab194edc4caa76)|Win32 EXE|Kryptik|2017-04-23 13:36:47|A3DE096598E3C9C8F3AB194EDC4CAA76.PE|
|[67f48fd24bae3e63b29edccc524f4096](https://www.virustotal.com/gui/file/67f48fd24bae3e63b29edccc524f4096)|RAR|Bublik|2017-04-17 23:38:50|67f48fd24bae3e63b29edccc524f4096.virus|
|[7b536c348a21c309605fa2cd2860a41d](https://www.virustotal.com/gui/file/7b536c348a21c309605fa2cd2860a41d)|RAR|Bublik|2017-04-17 23:25:20|7b536c348a21c309605fa2cd2860a41d.virus|
|[eb521caebcf03df561443194c37911a5](https://www.virustotal.com/gui/file/eb521caebcf03df561443194c37911a5)|Win32 EXE|MSILPerseus|2017-04-05 20:38:20|nvStView.exe|
|[b7390bc8c8a9a71a69ce4cc0c928153b](https://www.virustotal.com/gui/file/b7390bc8c8a9a71a69ce4cc0c928153b)|Win32 EXE|dynamer|2017-04-05 15:11:47|????? ??????? ???? ????? ???????-5-4-2017-65898552145699874521456985234458442587445566320210504884.exe|
|[70d03e34cadb0f1e1bc6f4bf8486e4e8](https://www.virustotal.com/gui/file/70d03e34cadb0f1e1bc6f4bf8486e4e8)|Win32 EXE|Kryptik|2017-03-30 09:18:38|Egyptian_agreement_with_President_Mahmoud_Abbas.exe|
|[c078743eac33df15af2d9a4f24159500](https://www.virustotal.com/gui/file/c078743eac33df15af2d9a4f24159500)|Win32 EXE||2017-03-28 08:05:32|SearchIndexer.exe|
|[f43188accfb6923d62fe265d6d9c0940](https://www.virustotal.com/gui/file/f43188accfb6923d62fe265d6d9c0940)|Win32 EXE|Kryptik|2017-03-19 20:20:04|thJUieIPHexrOdxhJKhGNziMLTKRKzsaer|
|[b68fcf8feb35a00362758fc0f92f7c2e](https://www.virustotal.com/gui/file/b68fcf8feb35a00362758fc0f92f7c2e)|Win32 EXE|dynamer|2017-03-19 09:39:21|micr data|
|[d87c872869023911494305ef4acbd966](https://www.virustotal.com/gui/file/d87c872869023911494305ef4acbd966)|Win32 EXE||2017-03-19 09:39:21|micr data|
|[6d6f34f7cfcb64e44d67638a2f33d619](https://www.virustotal.com/gui/file/6d6f34f7cfcb64e44d67638a2f33d619)|unknown|Bublik|2017-03-19 09:38:48|6d6f34f7cfcb64e44d67638a2f33d619.virus|
|[056d83c1c1b5f905d18b3c5d58ff5342](https://www.virustotal.com/gui/file/056d83c1c1b5f905d18b3c5d58ff5342)|Win32 EXE|dynamer|2017-03-16 17:01:02|Internet Download Manager|
|[7bef124131ffc2ef3db349b980e52847](https://www.virustotal.com/gui/file/7bef124131ffc2ef3db349b980e52847)|Win32 EXE|Bublik|2017-03-13 18:12:36|7bef124131ffc2ef3db349b980e52847.virus|
|[8799b3d6b2ce50d4dd5f5114635a4b96](https://www.virustotal.com/gui/file/8799b3d6b2ce50d4dd5f5114635a4b96)|Text||2017-03-09 15:05:15|1b5f1ee1aee0bdca5250ce22ecb1f102bcb1dd5f9231e25acb1729899e0f300c.bin|
|[3f401889a6805d8a702dbfa905b3e85c](https://www.virustotal.com/gui/file/3f401889a6805d8a702dbfa905b3e85c)|Android||2017-03-03 02:43:52|3f401889a6805d8a702dbfa905b3e85c.apk|
|[9ec6823230ab22ba1bec76acb869e7f9](https://www.virustotal.com/gui/file/9ec6823230ab22ba1bec76acb869e7f9)|Android||2017-02-17 01:59:58|412bef1458fadc45f25b223d584120e0476cb90583d10fac3a2bdcb874f1cd51.bin|
|[3f67231f30fa742138e713085e1279a6](https://www.virustotal.com/gui/file/3f67231f30fa742138e713085e1279a6)|Win32 EXE||2017-02-03 06:28:09|PortableApps.com Launcher|
|[86a89693a273d6962825cf1846c3b6ce](https://www.virustotal.com/gui/file/86a89693a273d6962825cf1846c3b6ce)|Win32 EXE||2017-02-03 06:25:35|PortableApps.com Launcher|
|[5472d0554a0188c0ecebd065eddb9485](https://www.virustotal.com/gui/file/5472d0554a0188c0ecebd065eddb9485)|Win32 EXE|dynamer|2016-09-19 09:57:59|Apple Software Update|
|[b841e134ec7fe48095754742c8a2b8d7](https://www.virustotal.com/gui/file/b841e134ec7fe48095754742c8a2b8d7)|Win32 EXE||2016-09-05 08:43:12|b841e134ec7fe48095754742c8a2b8d7.virus|
|[f8ff494b1c0403c3c99c6d67bef7069a](https://www.virustotal.com/gui/file/f8ff494b1c0403c3c99c6d67bef7069a)|Win32 EXE|dynamer|2016-08-29 15:54:15|binder.exe|
|[48a8e95e79787eb27465aad52855788a](https://www.virustotal.com/gui/file/48a8e95e79787eb27465aad52855788a)|Win32 EXE|dynamer|2016-08-28 18:49:29|19.exe|
|[a866f515362066aea4bbef0b6c1bdb13](https://www.virustotal.com/gui/file/a866f515362066aea4bbef0b6c1bdb13)|Win32 EXE|dynamer|2016-08-28 14:44:00|binder.exe|
|[5cc9964dd41be3d9dacbd0425ec032a9](https://www.virustotal.com/gui/file/5cc9964dd41be3d9dacbd0425ec032a9)|Win32 EXE|dynamer|2016-08-28 14:41:25|binder.exe|
|[15f7682a178f789edb40ceaaba9e5103](https://www.virustotal.com/gui/file/15f7682a178f789edb40ceaaba9e5103)|Win32 EXE|dynamer|2016-08-27 11:49:36|200.exe|
|[e8909f06ef95b222121b72e12db2111d](https://www.virustotal.com/gui/file/e8909f06ef95b222121b72e12db2111d)|Win32 EXE|dynamer|2016-08-27 11:48:00|10.exe|
|[7dd199b0c678ef409a7dc461de850849](https://www.virustotal.com/gui/file/7dd199b0c678ef409a7dc461de850849)|Win32 EXE||2016-08-27 08:13:06|13.exe|
|[ddd73e73be2cc934d5721d4fc62cd98c](https://www.virustotal.com/gui/file/ddd73e73be2cc934d5721d4fc62cd98c)|Win32 EXE|dynamer|2016-08-26 15:31:24|123.exe|
|[3d2e266b9fdad45aef7d83164beb7a37](https://www.virustotal.com/gui/file/3d2e266b9fdad45aef7d83164beb7a37)|Win32 EXE|dynamer|2016-08-26 15:29:02|binder.exe|
|[7840f2473b3a0e0960a1925f3cd0c3b1](https://www.virustotal.com/gui/file/7840f2473b3a0e0960a1925f3cd0c3b1)|Win32 EXE|dynamer|2016-08-26 12:07:14|DFDSF.exe|
|[de2e753d12ce07f7b3f97c498d3477f8](https://www.virustotal.com/gui/file/de2e753d12ce07f7b3f97c498d3477f8)|Win32 EXE|dynamer|2016-08-26 11:47:46|المصدر السياسي-26-8-16·dotx.scr|
|[a7f58a9d83ca22846282994a0393fb82](https://www.virustotal.com/gui/file/a7f58a9d83ca22846282994a0393fb82)|Win32 EXE|dynamer|2016-08-22 15:00:35|www.elnnews.docx.exe|
|[fe742125449afabb37b21844171fbc99](https://www.virustotal.com/gui/file/fe742125449afabb37b21844171fbc99)|Win32 EXE|MSILPerseus|2016-08-19 17:11:06|BronCoder.exe|
|[655f56f880655198962ca8dd746431e8](https://www.virustotal.com/gui/file/655f56f880655198962ca8dd746431e8)|Win32 EXE||2016-08-18 19:46:30|shortcut.exe|
|[4a71557dd68a260b250a96c4ac2b230f](https://www.virustotal.com/gui/file/4a71557dd68a260b250a96c4ac2b230f)|Android||2016-08-18 00:17:46|4a71557dd68a260b250a96c4ac2b230f.virus|
|[696232159428bcb2bda5ac2c755e8fed](https://www.virustotal.com/gui/file/696232159428bcb2bda5ac2c755e8fed)|Text||2016-08-03 08:23:09|c.vbs|
|[4ddf3ff57db24513a16eacb99ad07675](https://www.virustotal.com/gui/file/4ddf3ff57db24513a16eacb99ad07675)|Android||2016-08-03 02:50:11|4ddf3ff57db24513a16eacb99ad07675.virus|
|[d652113a710bef40f91f890bb6395e6d](https://www.virustotal.com/gui/file/d652113a710bef40f91f890bb6395e6d)|Android||2016-08-02 10:19:43|BallpoolBilliardSnooker.apk|
|[568218bb07c021bbab3b6d6560d7208c](https://www.virustotal.com/gui/file/568218bb07c021bbab3b6d6560d7208c)|Win32 EXE|zapchast|2016-08-01 17:51:46|568218bb07c021bbab3b6d6560d7208c.virus|
|[cf51142459f7b40e751e91179c001299](https://www.virustotal.com/gui/file/cf51142459f7b40e751e91179c001299)|Win32 EXE|dynamer|2016-07-25 10:42:53|kk.exe|
|[e1b56d70fa5397509f901ed72724a5e9](https://www.virustotal.com/gui/file/e1b56d70fa5397509f901ed72724a5e9)|Win32 EXE|dynamer|2016-07-14 17:12:44|New Microsoft Office Word Document.doc.doc|
|[e782610bf209e81ecc42ca94b9388580](https://www.virustotal.com/gui/file/e782610bf209e81ecc42ca94b9388580)|RAR|dynamer|2016-07-13 15:59:39|f16d3cf1b36dfce2c530f01c8f1b47698cc139da934c71fc0518817d95da5183.bin|
|[8be6fbad0618d6a398966af3d20f5418](https://www.virustotal.com/gui/file/8be6fbad0618d6a398966af3d20f5418)|Text||2016-07-11 14:09:57|Downloder.hta|
|[4eb6b5f6e3cb72869f29d567ac888c05](https://www.virustotal.com/gui/file/4eb6b5f6e3cb72869f29d567ac888c05)|Text||2016-07-11 14:08:19|Downloder.hta|
|[d297e0db6d63a952b08b6f0e3fe101e7](https://www.virustotal.com/gui/file/d297e0db6d63a952b08b6f0e3fe101e7)|Win32 EXE|Disfa|2016-06-27 07:11:50|c3009a51b416c6a22a6c044cbf0b7a9a9b863a7632da9a4e01efc08aec2bd37e.exe|
|[cfe26b57e168b6c6a18c668e36a3e939](https://www.virustotal.com/gui/file/cfe26b57e168b6c6a18c668e36a3e939)|Win32 EXE||2016-06-19 08:27:08|20160611-NCRI-AR-Rajavi-Syria-Ramadan,docx.exe|
|[0d67422ba42d4a548e807b0298e372c7](https://www.virustotal.com/gui/file/0d67422ba42d4a548e807b0298e372c7)|Win32 EXE|dapato|2016-06-15 01:08:43|test.doc|
|[0606fee55f39784e9889c1aaa0f27882](https://www.virustotal.com/gui/file/0606fee55f39784e9889c1aaa0f27882)|Win32 EXE|dynamer|2016-06-09 08:49:22|IMG-20151230-WA0023.jpg.exe|
|[3c21e0d77f8fb350255a080838058095](https://www.virustotal.com/gui/file/3c21e0d77f8fb350255a080838058095)|Android||2016-06-04 17:44:17| |
|[6218a61d18f5a74f82abc31a5f073c4b](https://www.virustotal.com/gui/file/6218a61d18f5a74f82abc31a5f073c4b)|Win32 EXE||2016-06-04 02:13:06|6218a61d18f5a74f82abc31a5f073c4b.virus|
|[40e9ed913857d5196368a64d9972fcb8](https://www.virustotal.com/gui/file/40e9ed913857d5196368a64d9972fcb8)|Win32 EXE||2016-06-02 09:48:48|40e9ed913857d5196368a64d9972fcb8.virus|
|[c291cfac28f323f9808d633a8558a35a](https://www.virustotal.com/gui/file/c291cfac28f323f9808d633a8558a35a)|Win32 EXE||2016-06-02 07:32:11|gK7owIn3Wv|
|[897061cd7f0bbae1b024ed9c1c1998a1](https://www.virustotal.com/gui/file/897061cd7f0bbae1b024ed9c1c1998a1)|Win32 EXE|dynamer|2016-06-01 05:26:47|7c1b4a2a-fd4c-5cd8-b3f4-421d2bda9756.mal_|
|[90c49d0cef0dfcff3c09723a9918688d](https://www.virustotal.com/gui/file/90c49d0cef0dfcff3c09723a9918688d)|Win32 EXE||2016-05-31 12:08:03|sbzyq vpt pustph ptuy ptpzpsy.MP3.TXT|
|[7c14974dd39b071558c619d16c4216db](https://www.virustotal.com/gui/file/7c14974dd39b071558c619d16c4216db)|Win32 EXE|Bublik|2016-05-31 09:02:30|LegIjlR0rl|
|[ae9e9e3c73483e8b6c6e58e5629dc4d0](https://www.virustotal.com/gui/file/ae9e9e3c73483e8b6c6e58e5629dc4d0)|Win32 EXE||2016-05-31 08:11:33|تسريب هام اجتماع امني اماراتي.exe|
|[0ca048153ac96e5c41243b364092af07](https://www.virustotal.com/gui/file/0ca048153ac96e5c41243b364092af07)|Win32 EXE|dynamer|2016-05-31 07:34:20|op.exe|
|[348d6c08f155f0781574c34e573b6f1f](https://www.virustotal.com/gui/file/348d6c08f155f0781574c34e573b6f1f)|Win32 EXE||2016-05-31 03:39:27|m:\x\83c34a1fab8df308b4c7eb97cb823b6fe925b14f1dd1797a3f73143ca2862428.exe|
|[1856f46da93c3b152c358e0f6db53402](https://www.virustotal.com/gui/file/1856f46da93c3b152c358e0f6db53402)|Win32 EXE|dynamer|2016-05-30 08:11:32|op - Copy.exe|
|[8a2e5662ed22d0d555e6b90fe5e1c902](https://www.virustotal.com/gui/file/8a2e5662ed22d0d555e6b90fe5e1c902)|Win32 EXE|dapato|2016-05-29 08:24:47|937b3f38879cccd1d177c2eafd4627291cd4c3d3e31e6c113687f911569df50b.bin|
|[517822af63d640dfe8c6590b36ad8f80](https://www.virustotal.com/gui/file/517822af63d640dfe8c6590b36ad8f80)|Win32 EXE|Disfa|2016-05-24 11:28:56|WindowsApplication1.exe|
|[f17cd2526a0e46d806863e1320a2cf5b](https://www.virustotal.com/gui/file/f17cd2526a0e46d806863e1320a2cf5b)|Win32 EXE|Disfa|2016-05-24 11:27:46|nj.exe|
|[72bea803a834f7736679781a1d729b1f](https://www.virustotal.com/gui/file/72bea803a834f7736679781a1d729b1f)|Win32 EXE|Kryptik|2016-05-24 11:26:09|00027174.exe|
|[22cc7ce1e17852b6d09d5641b6abca0d](https://www.virustotal.com/gui/file/22cc7ce1e17852b6d09d5641b6abca0d)|Win32 EXE|dynamer|2016-05-24 10:52:20|1.scr|
|[55d33d9da371fdfe7871f2479621444a](https://www.virustotal.com/gui/file/55d33d9da371fdfe7871f2479621444a)|Win32 EXE||2016-05-23 15:27:30|vlc|
|[5f0437c7dc45d4c10a045954db77dd31](https://www.virustotal.com/gui/file/5f0437c7dc45d4c10a045954db77dd31)|Win32 EXE||2016-05-22 07:56:37|مصادر الرئيس يطيح بقيادة فتح في غزة ويكلف أبو سمهدانة لقيادة التنظيم.doc.exe|
|[d179427d46d38d78a7a60512a4595496](https://www.virustotal.com/gui/file/d179427d46d38d78a7a60512a4595496)|Win32 EXE|Disfa|2016-05-17 18:05:28|Attachments.docx.exe|
|[ddeee52c00a95167353215d14b3aaa68](https://www.virustotal.com/gui/file/ddeee52c00a95167353215d14b3aaa68)|Win32 EXE||2016-05-17 09:47:05|ddeee52c00a95167353215d14b3aaa68.virus|
|[4484eb027d30c4705717cde931245827](https://www.virustotal.com/gui/file/4484eb027d30c4705717cde931245827)|Win32 EXE|Athena|2016-05-16 17:17:54|4484eb027d30c4705717cde931245827.virus|
|[838696872f924d28b08aaaa67388202e](https://www.virustotal.com/gui/file/838696872f924d28b08aaaa67388202e)|Win32 EXE|dynamer|2016-05-14 05:38:26|BitTorrent.exe|
|[0512f533bf2e8e5ec9637b804c101c2b](https://www.virustotal.com/gui/file/0512f533bf2e8e5ec9637b804c101c2b)|Win32 EXE|blocker|2016-05-13 09:55:25|asd.exe|
|[8fdd4ba7920b3d6ab2f0106fdf4ed702](https://www.virustotal.com/gui/file/8fdd4ba7920b3d6ab2f0106fdf4ed702)|Win32 EXE||2016-05-13 09:49:24|mmm.exe|
|[a3296e4d931583415c2b1b7a68c96508](https://www.virustotal.com/gui/file/a3296e4d931583415c2b1b7a68c96508)|Win32 EXE||2016-05-13 09:32:41| |
|[29771c26bfdd125e7427cd57a98730ff](https://www.virustotal.com/gui/file/29771c26bfdd125e7427cd57a98730ff)|Win32 EXE||2016-05-13 09:32:08|mmm.exe|
|[acab47bb5e8ed34056905ff63353cabc](https://www.virustotal.com/gui/file/acab47bb5e8ed34056905ff63353cabc)|Win32 EXE|dynamer|2016-05-13 09:29:43|123.exe|
|[215556af1a5fef7e08a6124d94487d2f](https://www.virustotal.com/gui/file/215556af1a5fef7e08a6124d94487d2f)|Win32 EXE|dynamer|2016-05-13 09:05:08|1.exe|
|[968ef6cb0dfb082df7a68c3b8869c57b](https://www.virustotal.com/gui/file/968ef6cb0dfb082df7a68c3b8869c57b)|Win32 EXE|Disfa|2016-05-11 23:35:12| |
|[a3dfd16ac5e2e0343e61e19c13fcff2b](https://www.virustotal.com/gui/file/a3dfd16ac5e2e0343e61e19c13fcff2b)|Win32 EXE||2016-05-11 22:26:57|m:\x\02cd6e26f2914857f5ce54e5e1a78e7c6367612524528c9f459095e5f23c34da.exe|
|[62df4bc3738be5ad4892200a1dc6b59a](https://www.virustotal.com/gui/file/62df4bc3738be5ad4892200a1dc6b59a)|Win32 EXE|dynamer|2016-05-10 13:24:41|معلومات عن هجوم محتمل من الحوثيين على مواقع سعودية - خاص.exe|
|[e8be9843c372d280a506ac260567bf91](https://www.virustotal.com/gui/file/e8be9843c372d280a506ac260567bf91)|Win32 EXE||2016-05-08 14:30:37|tisBdumjjZiHLsdFbCYLukimSvNJvosTbAkJa|
|[833b3af9bd8ffd0390bca1d43ee78cc3](https://www.virustotal.com/gui/file/833b3af9bd8ffd0390bca1d43ee78cc3)|Win32 EXE|injector|2016-05-03 08:51:51|codex-gigas_cc12a029c367e006fcdb83b4c6880900|
|[a803f9914141f2ca72eb0c2162e2ba36](https://www.virustotal.com/gui/file/a803f9914141f2ca72eb0c2162e2ba36)|Win32 EXE||2016-05-01 14:36:36|MicrosoftOffice.exe|
|[5bf5be6b45292fba0c0edc415f248922](https://www.virustotal.com/gui/file/5bf5be6b45292fba0c0edc415f248922)|Win32 EXE|MSILPerseus|2016-05-01 14:34:29|MicrosoftOffice.exe|
|[3eaa4c1c6716133612cba0ea4a6905b5](https://www.virustotal.com/gui/file/3eaa4c1c6716133612cba0ea4a6905b5)|Win32 EXE||2016-04-25 09:31:04|attachment.docx.exe|
|[13af6a3c3a3908fd4e606a1f19b05714](https://www.virustotal.com/gui/file/13af6a3c3a3908fd4e606a1f19b05714)|Win32 EXE|dapato|2016-04-19 08:11:29|?????????????????????? ?????????????????????.docx.exe|
|[aa4774f70e080ab0a33c6b8f83c70589](https://www.virustotal.com/gui/file/aa4774f70e080ab0a33c6b8f83c70589)|Win32 EXE||2016-04-18 21:22:15|74111ea19fc7a855f1a2232e1d318966e6e2fee2.bin|
|[974037c602a559c471bbda3d07f50650](https://www.virustotal.com/gui/file/974037c602a559c471bbda3d07f50650)|Win32 EXE|Andromeda|2016-04-18 11:35:55|Secrets documents Panama.docx.exe|
|[21ce82db335964b8624f8eb0668b539f](https://www.virustotal.com/gui/file/21ce82db335964b8624f8eb0668b539f)|Win32 EXE|Andromeda|2016-04-18 09:28:51|إبن المفتي التكفيري في حماس بقبضة شرطة مكافحة المخدرات.docx.exe|
|[39581b22fb078851d6daa492c4f5be97](https://www.virustotal.com/gui/file/39581b22fb078851d6daa492c4f5be97)|Win32 EXE|Disfa|2016-04-18 08:06:52|WindowsApplication1.exe|
|[a12eb4cd0cad629fce59ae5120b82133](https://www.virustotal.com/gui/file/a12eb4cd0cad629fce59ae5120b82133)|Win32 EXE||2016-04-09 10:13:23|Attachments.dotx.scr|
|[14c1e03de25811c3d6d467837a16bb29](https://www.virustotal.com/gui/file/14c1e03de25811c3d6d467837a16bb29)|Win32 EXE|Disfa|2016-04-08 22:42:44| |
|[0abbd2765b563f2b8748485fa84da070](https://www.virustotal.com/gui/file/0abbd2765b563f2b8748485fa84da070)|Win32 EXE||2016-04-02 08:41:08|0abbd2765b563f2b8748485fa84da070.virus|
|[f9bcc21fbb40247167c8c85ed6ef56e3](https://www.virustotal.com/gui/file/f9bcc21fbb40247167c8c85ed6ef56e3)|RAR||2016-03-31 23:13:58|09c2e0b3b439dadd72a9e1faca131355434ec17d8ceb839ea6c7c8aec31eb6d9.bin|
|[148a3e3cc76cf6753b15070fe3514dae](https://www.virustotal.com/gui/file/148a3e3cc76cf6753b15070fe3514dae)|Win32 EXE|Disfa|2016-03-30 07:45:13|cSFsolFE1W|
|[df3f3ad279ca98f947214ffb3c91c514](https://www.virustotal.com/gui/file/df3f3ad279ca98f947214ffb3c91c514)|Win32 EXE||2016-03-29 11:27:32|MOM.InstallProxy.exe|
|[e8a29c7a6f6c0140152ca8a01e336b37](https://www.virustotal.com/gui/file/e8a29c7a6f6c0140152ca8a01e336b37)|RAR|autoit|2016-03-29 11:18:45|President Abu Mazen meetings with Khaled Meshaal.lha|
|[99215adb3d924f52d69beab6981791eb](https://www.virustotal.com/gui/file/99215adb3d924f52d69beab6981791eb)|Win32 EXE|Pigeon|2016-03-22 04:03:51|ex.exe|
|[b3a472f81f800b32fe6595f44c9bf63b](https://www.virustotal.com/gui/file/b3a472f81f800b32fe6595f44c9bf63b)|Win32 EXE||2016-03-17 08:01:53|Apple Software Update|
|[841565c67006e6a0a450c48054cf348c](https://www.virustotal.com/gui/file/841565c67006e6a0a450c48054cf348c)|Win32 EXE|razy|2016-03-02 14:01:10|WinRAR|
|[0e9b363de7dd2b10afd5d1947fa0e006](https://www.virustotal.com/gui/file/0e9b363de7dd2b10afd5d1947fa0e006)|Win32 EXE|dynamer|2016-03-01 23:30:10| |
|[6d418227feb7a60727326583b52187e6](https://www.virustotal.com/gui/file/6d418227feb7a60727326583b52187e6)|Win32 EXE|injector|2016-03-01 12:20:59| |
|[63d933310cfb26ec9913a26bef230a99](https://www.virustotal.com/gui/file/63d933310cfb26ec9913a26bef230a99)|Win32 EXE||2016-02-26 23:55:23| |
|[acd58bb34bb275de1570917624ade609](https://www.virustotal.com/gui/file/acd58bb34bb275de1570917624ade609)|Win32 EXE|Disfa|2016-02-22 21:07:37|WindowsApplication2.exe|
|[7d1f1fed52745d36d737efa7d43f4b95](https://www.virustotal.com/gui/file/7d1f1fed52745d36d737efa7d43f4b95)|Win32 EXE||2016-02-16 23:34:23|c:\Windows\system32\ctfmon.exe|
|[be23b3afd1fd32c900f012cb2a8ba755](https://www.virustotal.com/gui/file/be23b3afd1fd32c900f012cb2a8ba755)|Win32 EXE|Disfa|2016-02-16 18:37:37|Silverlight.exe|
|[7a4588dc14ae38505662b75da93ca8a7](https://www.virustotal.com/gui/file/7a4588dc14ae38505662b75da93ca8a7)|Win32 EXE|dapato|2016-02-11 18:23:28|c:\Windows\system32\iisreset.exe|
|[d6ef9b0cdb49b56c53da3433e30f3fd6](https://www.virustotal.com/gui/file/d6ef9b0cdb49b56c53da3433e30f3fd6)|Android||2016-02-11 13:55:59|LoveSongs.apk|
|[aa45a3dfd4e7329df37d8c74f0da01b4](https://www.virustotal.com/gui/file/aa45a3dfd4e7329df37d8c74f0da01b4)|Win32 EXE|Disfa|2016-02-11 00:50:45| |
|[87e5555cff74d41551d6d29b9c01c0cb](https://www.virustotal.com/gui/file/87e5555cff74d41551d6d29b9c01c0cb)|Win32 EXE|dynamer|2016-02-10 10:30:11|???? ???? ?????? ??? ?????.scr|
|[6c4d355411b8d7da56a2c7c14693a3ae](https://www.virustotal.com/gui/file/6c4d355411b8d7da56a2c7c14693a3ae)|Win32 EXE|Xtreme|2016-02-08 16:34:05| |
|[ccfa1b31c47c9f124fefe206301b3a5f](https://www.virustotal.com/gui/file/ccfa1b31c47c9f124fefe206301b3a5f)|Win32 EXE|Disfa|2016-02-05 04:07:28| |
|[51817d6fa9f1ba398176abe63230568a](https://www.virustotal.com/gui/file/51817d6fa9f1ba398176abe63230568a)|Win32 EXE||2016-01-31 03:21:00| |
|[f8ad6a207bee8c042220cc52af2dac29](https://www.virustotal.com/gui/file/f8ad6a207bee8c042220cc52af2dac29)|Win32 EXE||2016-01-19 11:08:23|العمالة.scr|
|[72076b1b2d9cb0507e5c94c2b422cce7](https://www.virustotal.com/gui/file/72076b1b2d9cb0507e5c94c2b422cce7)|Win32 EXE|dynamer|2016-01-19 07:57:10|ef83733c16ef6a467dcba32f4ffa39db3255dc73ae137742a0c756391eaf972d|
|[5947bbad60d4d00ef545e2fb3b1fd03e](https://www.virustotal.com/gui/file/5947bbad60d4d00ef545e2fb3b1fd03e)|Win32 EXE|dapato|2016-01-12 00:58:18|c:\Windows\system32\mqsvc.exe|
|[6e2e488cddf1d15d0411f3838ed04683](https://www.virustotal.com/gui/file/6e2e488cddf1d15d0411f3838ed04683)|Win32 EXE|dapato|2016-01-08 00:52:23|c:\Windows\system32\ClipUp.exe|
|[37cb0df3af8d3ca2086eedaf3479d21c](https://www.virustotal.com/gui/file/37cb0df3af8d3ca2086eedaf3479d21c)|Win32 EXE|dynamer|2016-01-07 05:51:17| |
|[0b40d67579af550c0a3aee359c2c71ba](https://www.virustotal.com/gui/file/0b40d67579af550c0a3aee359c2c71ba)|Win32 EXE|dynamer|2016-01-05 09:51:02| |
|[0a49531fc0c00e991e51f34398f3ab88](https://www.virustotal.com/gui/file/0a49531fc0c00e991e51f34398f3ab88)|Win32 EXE|Disfa|2016-01-02 06:07:37| |
|[ac19a1e5d604d82ef81e35756f3a10d1](https://www.virustotal.com/gui/file/ac19a1e5d604d82ef81e35756f3a10d1)|Win32 EXE|dapato|2016-01-01 10:50:08|???? ???? ??? ????? ???????? ??? ?? ???.exe|
|[853a53cf799e2e3e1fc244a0751a4e96](https://www.virustotal.com/gui/file/853a53cf799e2e3e1fc244a0751a4e96)|Win32 EXE|Disfa|2015-12-24 21:23:17| |
|[c28376fc9ee627b51e3f52503397e2dc](https://www.virustotal.com/gui/file/c28376fc9ee627b51e3f52503397e2dc)|Win32 EXE|dynamer|2015-12-24 21:22:02| |
|[19cd219bbb62f9ba3655b0dadf324ee2](https://www.virustotal.com/gui/file/19cd219bbb62f9ba3655b0dadf324ee2)|Android||2015-12-22 11:53:13|2016-تطبيق-للمحمول-تملي-معاك.apk|
|[4e3925abf0cb66ce4476dffc41131396](https://www.virustotal.com/gui/file/4e3925abf0cb66ce4476dffc41131396)|Win32 EXE|Disfa|2015-12-18 02:35:01|Project1.exe|
|[ac3918287452febd3855ff4bc3d82a07](https://www.virustotal.com/gui/file/ac3918287452febd3855ff4bc3d82a07)|Win32 EXE|Disfa|2015-12-18 02:34:39|Project1.exe|
|[2cbd8e0eb9df67e7d304f28803d4529e](https://www.virustotal.com/gui/file/2cbd8e0eb9df67e7d304f28803d4529e)|Win32 EXE|Delf|2015-12-17 01:51:25| |
|[d9eacff28841c51ace9712af78bcbdd0](https://www.virustotal.com/gui/file/d9eacff28841c51ace9712af78bcbdd0)|Win32 EXE|Disfa|2015-11-19 09:20:34|NRRRbVUAWb.exe|
|[f007b759a30edf46fd921e2d87a39d5d](https://www.virustotal.com/gui/file/f007b759a30edf46fd921e2d87a39d5d)|Win32 EXE|Andromeda|2015-10-29 17:01:47|Windows XP.exe|
|[2a0f5d8c5bc021a1cefed7442b02df52](https://www.virustotal.com/gui/file/2a0f5d8c5bc021a1cefed7442b02df52)|Win32 EXE|dynamer|2015-10-29 07:18:59| |
|[6ee7264d4a974d0fffed7f39652d1dad](https://www.virustotal.com/gui/file/6ee7264d4a974d0fffed7f39652d1dad)|Win32 EXE|Darkcomet|2015-10-28 07:19:47| |
|[8f8e5a9553a27a9341ed6022028b231d](https://www.virustotal.com/gui/file/8f8e5a9553a27a9341ed6022028b231d)|Win32 EXE|Andromeda|2015-10-17 08:28:10|Mo-Server.exe|
|[ef53161673ca4caa7e9c4b33a0d02a90](https://www.virustotal.com/gui/file/ef53161673ca4caa7e9c4b33a0d02a90)|Win32 EXE|Disfa|2015-10-14 10:43:43|ïë ­§© ãë è¢  ã § éç§© é¥«ïëï.scr|
|[2993b77d82622d665f9b2f06c89741be](https://www.virustotal.com/gui/file/2993b77d82622d665f9b2f06c89741be)|Win32 EXE|Zbot|2015-10-13 16:17:31|c:\Windows\system32\conhost.exe|
|[76f9443edc9b71b2f2494cff6d4a26a8](https://www.virustotal.com/gui/file/76f9443edc9b71b2f2494cff6d4a26a8)|Win32 EXE|Xtreme|2015-10-08 21:23:27|/home/virustotal/sample/76F9443EDC9B71B2F2494CFF6D4A26A8|
|[3ce01ad1b116943f5fb1b2925c5dcaf1](https://www.virustotal.com/gui/file/3ce01ad1b116943f5fb1b2925c5dcaf1)|Win32 EXE|Disfa|2015-10-08 11:22:09|DoAli.exe|
|[f7cf132313438115b0bbed035078fb1c](https://www.virustotal.com/gui/file/f7cf132313438115b0bbed035078fb1c)|Win32 EXE|Disfa|2015-10-05 18:18:27|mohammed_dhlan.Doct.exe|
|[64af25b42e21f01a213c32cc66cfd749](https://www.virustotal.com/gui/file/64af25b42e21f01a213c32cc66cfd749)|Win32 EXE|MSILPerseus|2015-10-01 07:20:11|DoAli.exe|
|[0aed206fc534c310724e122bf6bcdf7f](https://www.virustotal.com/gui/file/0aed206fc534c310724e122bf6bcdf7f)|Win32 EXE||2015-10-01 07:19:27| |
|[0a38ddcc3431bae448e38c99562162ef](https://www.virustotal.com/gui/file/0a38ddcc3431bae448e38c99562162ef)|Win32 EXE|Disfa|2015-09-24 21:30:53| |
|[a2e82ed55692bf64b819117c48f13f62](https://www.virustotal.com/gui/file/a2e82ed55692bf64b819117c48f13f62)|Win32 EXE|Disfa|2015-09-22 06:18:35|Silverlight.exe|
|[69a042c9ed90a30444606407f77e199f](https://www.virustotal.com/gui/file/69a042c9ed90a30444606407f77e199f)|Win32 EXE|dapato|2015-09-21 10:12:04|??????? ???????? ??? ??????.exe|
|[bd2234dae56580aaa7f880a7db0f397d](https://www.virustotal.com/gui/file/bd2234dae56580aaa7f880a7db0f397d)|Win32 EXE||2015-09-17 07:38:56|isheriff_bd2234dae56580aaa7f880a7db0f397d.bin|
|[2dc30f736f1a485dbbeed63ec9259726](https://www.virustotal.com/gui/file/2dc30f736f1a485dbbeed63ec9259726)|Win32 EXE|dynamer|2015-09-16 06:20:18|6A6F1C61E9CADD4F2C6E5BC2CA6B8A2C|
|[d3c8ecf591381b31d3aa796471b5b0f1](https://www.virustotal.com/gui/file/d3c8ecf591381b31d3aa796471b5b0f1)|Win32 EXE|Disfa|2015-09-14 08:10:56|Server.exe|
|[28fbfd2ad1b500b62377dde5795cdf85](https://www.virustotal.com/gui/file/28fbfd2ad1b500b62377dde5795cdf85)|Win32 EXE|Redhip|2015-09-13 10:21:44|x|
|[2ab91cedd813e306248e545075c60866](https://www.virustotal.com/gui/file/2ab91cedd813e306248e545075c60866)|Win32 EXE|Disfa|2015-09-13 10:20:59|BC9D64316A3EC713E3D438BDFBB066DD|
|[e8c4a336c901a8799525ea30486838b3](https://www.virustotal.com/gui/file/e8c4a336c901a8799525ea30486838b3)|Win32 EXE|Disfa|2015-09-13 10:20:45|Mo-Server.exe|
|[cd10d61a0d2d43a6ab16a9f50b1ad894](https://www.virustotal.com/gui/file/cd10d61a0d2d43a6ab16a9f50b1ad894)|Win32 EXE|Zbot|2015-09-13 10:20:39|Silverlight.exe|
|[a7bf176d5bd80c2ad3815ec41e9ba6e6](https://www.virustotal.com/gui/file/a7bf176d5bd80c2ad3815ec41e9ba6e6)|Win32 EXE|dynamer|2015-09-12 08:29:43|???? ?????? ?????? ?? ????.scr|
|[f48aab23d1def618449d705146153966](https://www.virustotal.com/gui/file/f48aab23d1def618449d705146153966)|Win32 EXE|Redhip|2015-09-11 06:21:15|awd|
|[efca552b3ca4b8ff8686fd313ff2d48e](https://www.virustotal.com/gui/file/efca552b3ca4b8ff8686fd313ff2d48e)|Win32 EXE|Disfa|2015-09-09 01:28:48|na|
|[f59453d2ff8f29617db23201c568017c](https://www.virustotal.com/gui/file/f59453d2ff8f29617db23201c568017c)|Win32 EXE|Redhip|2015-09-09 01:28:36|nj|
|[2851685f217eb1ce573fc2bae7918801](https://www.virustotal.com/gui/file/2851685f217eb1ce573fc2bae7918801)|Win32 EXE|skeeyah|2015-09-07 11:29:11|Z:\0x2851685F217EB1CE573FC2BAE7918801\حركة فتح والمؤمرات الخارجية.exe|
|[61381610e76266423ace96670de45dc0](https://www.virustotal.com/gui/file/61381610e76266423ace96670de45dc0)|Win32 EXE|Disfa|2015-09-07 07:37:33|61381610E76266423ACE96670DE45DC0|
|[d817fd5a442c7668607ae895d4298040](https://www.virustotal.com/gui/file/d817fd5a442c7668607ae895d4298040)|Win32 EXE|Disfa|2015-09-07 01:23:59| |
|[04b2d3f38055b2b821b30e82c44d6040](https://www.virustotal.com/gui/file/04b2d3f38055b2b821b30e82c44d6040)|Win32 EXE|Disfa|2015-09-06 17:28:21|04b2d3f38055b2b821b30e82c44d6040.virobj|
|[9a9d01bcb93ef99e1b8ebf727d72e91f](https://www.virustotal.com/gui/file/9a9d01bcb93ef99e1b8ebf727d72e91f)|Win32 EXE|Disfa|2015-09-06 08:58:41| |
|[2f352cd6486c518ddc61b7ebbeab5f01](https://www.virustotal.com/gui/file/2f352cd6486c518ddc61b7ebbeab5f01)|Win32 EXE|Disfa|2015-09-06 06:33:03|Server.exe|
|[b3fb8253595fed348464b5c9a01ad4ad](https://www.virustotal.com/gui/file/b3fb8253595fed348464b5c9a01ad4ad)|Win32 EXE|Disfa|2015-09-04 16:28:14|eset.exe|
|[d24b6317064da37d31ce4459ac7f4b69](https://www.virustotal.com/gui/file/d24b6317064da37d31ce4459ac7f4b69)|Win32 EXE|Disfa|2015-09-01 18:31:36|Silverlight.exe|
|[bbf576cf704b71c739e8777eb6c9ff82](https://www.virustotal.com/gui/file/bbf576cf704b71c739e8777eb6c9ff82)|Win32 EXE|skeeyah|2015-08-30 11:58:43| |
|[276e54a5e32bef12367c5b31bf9c179e](https://www.virustotal.com/gui/file/276e54a5e32bef12367c5b31bf9c179e)|Win32 EXE|dynamer|2015-08-27 18:00:50| |
|[ff295cf738de580e2ee41d0100c848ae](https://www.virustotal.com/gui/file/ff295cf738de580e2ee41d0100c848ae)|Win32 EXE|Xtreme|2015-08-27 16:44:02| |
|[118a606fb131c082b55a5625661b666a](https://www.virustotal.com/gui/file/118a606fb131c082b55a5625661b666a)|Win32 EXE|Disfa|2015-08-24 01:37:11|windows.rar|
|[27a1891db06d316b43a48ddefebf73bf](https://www.virustotal.com/gui/file/27a1891db06d316b43a48ddefebf73bf)|Win32 EXE|blocker|2015-08-24 01:36:29|%D8%AE%D9%8A%D8%A7%D9%86%D8%A9%20%D8%AD%D9%85%D8%A7%D8%B3.exe|
|[992d434a726b9c50851b809fb95c169b](https://www.virustotal.com/gui/file/992d434a726b9c50851b809fb95c169b)|Win32 EXE|dynamer|2015-08-22 16:21:50| |
|[fa428fef017b496dcae6428889114fcc](https://www.virustotal.com/gui/file/fa428fef017b496dcae6428889114fcc)|Win32 EXE|bitrep|2015-08-21 06:50:23| |
|[50b1e6e24a1db4d68a2d51bd7115baa3](https://www.virustotal.com/gui/file/50b1e6e24a1db4d68a2d51bd7115baa3)|Win32 EXE|Disfa|2015-08-20 10:43:42|hkcmd.exe|
|[a1e60d076cc9488eb7d86bd70ff70154](https://www.virustotal.com/gui/file/a1e60d076cc9488eb7d86bd70ff70154)|Win32 EXE|Disfa|2015-08-19 08:04:27|d.exe|
|[c92e26ac3145718e531330b87772d216](https://www.virustotal.com/gui/file/c92e26ac3145718e531330b87772d216)|Win32 EXE|Xtreme|2015-08-18 02:12:57|sky.exe|
|[cc9faec3f39edaf7a59e9d9a7577451c](https://www.virustotal.com/gui/file/cc9faec3f39edaf7a59e9d9a7577451c)|Win32 EXE|Disfa|2015-08-18 01:23:09| |
|[ea788c263e04b93d36e0d82bb7d1bc05](https://www.virustotal.com/gui/file/ea788c263e04b93d36e0d82bb7d1bc05)|Win32 EXE|skeeyah|2015-08-18 01:22:42|االحقيقة الكاملة وراء مرض ابو الغصين.exe|
|[b929fc62db2b3c8cc6a03063767be125](https://www.virustotal.com/gui/file/b929fc62db2b3c8cc6a03063767be125)|Win32 EXE|Disfa|2015-08-14 17:15:51| |
|[0bd3b5c667878830da088527d1b753ec](https://www.virustotal.com/gui/file/0bd3b5c667878830da088527d1b753ec)|Win32 EXE|Disfa|2015-08-12 15:46:05|azzam-al_ahmed.exe|
|[4c325c62d2cd9a69aa2ccf920a61b4c1](https://www.virustotal.com/gui/file/4c325c62d2cd9a69aa2ccf920a61b4c1)|Win32 EXE|Disfa|2015-08-07 01:14:02|WindowsFormsApplication1.exe|
|[8492c3111c7c0998f0dc1b63967e5c65](https://www.virustotal.com/gui/file/8492c3111c7c0998f0dc1b63967e5c65)|Win32 EXE|Disfa|2015-08-06 16:58:31|WindowsFormsApplication1.exe|
|[1c4ab6cf907175d114c48c30a38bf379](https://www.virustotal.com/gui/file/1c4ab6cf907175d114c48c30a38bf379)|Win32 EXE|dapato|2015-08-05 14:16:44|خاص للاطلاع  لسيادتكم.exe|
|[eb7b7c974a66e7f9a0ead3113f949ec8](https://www.virustotal.com/gui/file/eb7b7c974a66e7f9a0ead3113f949ec8)|Win32 EXE|Zbot|2015-08-04 18:03:09|m:\dailytesters\##\_ESET\W\Win32.TrojanDownloader.AutoHK.AK trojan\B8D3FA45B6780BFC0DB9B465883EF0E4B0C4C8540EF3CA9E9999815BED8D1144.EXE|
|[129f4b0a1f209784bf7071c14119bf9f](https://www.virustotal.com/gui/file/129f4b0a1f209784bf7071c14119bf9f)|Win32 EXE|Disfa|2015-07-29 08:13:55|java update.exe|
|[8ad4c22449b98339548d38bf87bf50aa](https://www.virustotal.com/gui/file/8ad4c22449b98339548d38bf87bf50aa)|Win32 EXE|Xtreme|2015-07-27 01:19:31|m:\dailytesters\vl\B\B55831D44D92F49DB2E79B6200E7B074\B1AEF4A16ABF763C4D35F773B4BE675D0B76950B6833B485A0D46D861F70ABDC.EXE|
|[b77a14a594a59c3b86edd940fb35ab5e](https://www.virustotal.com/gui/file/b77a14a594a59c3b86edd940fb35ab5e)|Win32 EXE||2015-07-26 15:57:14| |
|[cb539dfaeecc4baf875a1e431701ff9d](https://www.virustotal.com/gui/file/cb539dfaeecc4baf875a1e431701ff9d)|Win32 EXE|Zbot|2015-07-26 15:54:01|isheriff_cb539dfaeecc4baf875a1e431701ff9d.bin|
|[9ef41a195932ede4e9e6800e7d272a2e](https://www.virustotal.com/gui/file/9ef41a195932ede4e9e6800e7d272a2e)|Win32 EXE|Disfa|2015-07-26 10:38:15|%D8%B9%D9%85%D9%84%D9%8A%D8%A9%20%D8%A7%D8%BA%D8%AA%D9%8A%D8%A7%D9%84%20%D8%B7%D9%84%D8%A7%D9%84%20%D8%A7%D9%84%D8%A7%D8%B1%D8%AF%D9%86%D9%8AYouTube.exe|
|[6c4b69c19f2c3ac23ac392b8631e31bb](https://www.virustotal.com/gui/file/6c4b69c19f2c3ac23ac392b8631e31bb)|Win32 EXE|Zbot|2015-07-20 01:21:57|WindowsApplication1.exe|
|[0f83377c44adba238fd0f0eb241981a6](https://www.virustotal.com/gui/file/0f83377c44adba238fd0f0eb241981a6)|Win32 EXE|Disfa|2015-07-13 17:07:57|Mr.TeTcHeR.exe|
|[abd8f478faf299f8684a517dcb1df997](https://www.virustotal.com/gui/file/abd8f478faf299f8684a517dcb1df997)|Win32 EXE|Disfa|2015-07-09 21:09:55|abas.exe|
|[1673583bc5b7a485119d4a1342d6ada8](https://www.virustotal.com/gui/file/1673583bc5b7a485119d4a1342d6ada8)|Win32 EXE|dynamer|2015-06-29 13:56:45|????? ?????.. ??????? ??? ?????? ?????? ????? ???.scr|
|[8921bf7c4ff825cb89099ddaa22c8cfd](https://www.virustotal.com/gui/file/8921bf7c4ff825cb89099ddaa22c8cfd)|Win32 EXE||2015-06-22 08:24:32|/home/virustotal/sample/8921BF7C4FF825CB89099DDAA22C8CFD|
|[3bb319214d83dfb8dc1f3c944fb06e3b](https://www.virustotal.com/gui/file/3bb319214d83dfb8dc1f3c944fb06e3b)|Win32 EXE|kazy|2015-06-22 08:03:11|ccleaner|
|[5cfd542a561f1ee679fcd6aa81991f3a](https://www.virustotal.com/gui/file/5cfd542a561f1ee679fcd6aa81991f3a)|Win32 EXE|Xtreme|2015-06-14 16:06:50|/var/www/clean-mx/virusesevidence/output.108181065.txt|
|[674dec356cd9d8f24ef0f2ec73aaec88](https://www.virustotal.com/gui/file/674dec356cd9d8f24ef0f2ec73aaec88)|Win32 EXE|PoisonIvy|2015-06-11 02:03:42|/home/virustotal/sample/674DEC356CD9D8F24EF0F2EC73AAEC88|
|[53badcb66f848805e781716f95cf10ab](https://www.virustotal.com/gui/file/53badcb66f848805e781716f95cf10ab)|Win32 EXE|blocker|2015-06-11 01:01:35| |
|[1d693473ff431c7cea3e7ab0130eaa3d](https://www.virustotal.com/gui/file/1d693473ff431c7cea3e7ab0130eaa3d)|Win32 EXE||2015-06-11 01:01:00|m:\dailytesters\##\_ESET\W\Win32.TrojanDownloader.AutoHK.AC trojan\FF2E5DF951C7F6EC5C957DA2843627F9FA15C553BCDFCBE7629CB7B306F23F7B.EXE|
|[e20b5b300424fb1ea3c07a31f1279bde](https://www.virustotal.com/gui/file/e20b5b300424fb1ea3c07a31f1279bde)|Win32 EXE|injector|2015-06-11 00:59:35|/home/virustotal/sample/E20B5B300424FB1EA3C07A31F1279BDE|
|[302565aec2cd47bb6b62fa398144e0ad](https://www.virustotal.com/gui/file/302565aec2cd47bb6b62fa398144e0ad)|RAR||2015-06-06 23:11:27|Tasreb.rar|
|[f6e8e1b239b66632fd77ac5edef7598d](https://www.virustotal.com/gui/file/f6e8e1b239b66632fd77ac5edef7598d)|Win32 EXE|tspy|2015-06-06 14:08:59|/home/virustotal/sample/F6E8E1B239B66632FD77AC5EDEF7598D|
|[826ab586b412d174b6abb78faa1f3737](https://www.virustotal.com/gui/file/826ab586b412d174b6abb78faa1f3737)|Win32 EXE||2015-06-05 08:48:18|72.dll|
|[f54c8a235c5cce30884f07b4a8351ebf](https://www.virustotal.com/gui/file/f54c8a235c5cce30884f07b4a8351ebf)|Win32 EXE|kazy|2015-06-05 00:37:51|/home/virustotal/sample/F54C8A235C5CCE30884F07B4A8351EBF|
|[9ea2f8acddcd5ac32cfb45d5708b1e1e](https://www.virustotal.com/gui/file/9ea2f8acddcd5ac32cfb45d5708b1e1e)|Win32 EXE|barys|2015-06-05 00:33:22|/home/virustotal/sample/9EA2F8ACDDCD5AC32CFB45D5708B1E1E|
|[62b1e795a10bcd4412483a176df6bc77](https://www.virustotal.com/gui/file/62b1e795a10bcd4412483a176df6bc77)|Win32 EXE||2015-06-05 00:28:51|/home/virustotal/sample/62B1E795A10BCD4412483A176DF6BC77|
|[5e59acf240e2881b1c1e2f5586c9ca6f](https://www.virustotal.com/gui/file/5e59acf240e2881b1c1e2f5586c9ca6f)|Win32 EXE|agentwdcr|2015-05-31 16:08:23|/var/vb100/rep_file_pool///000176/3674/5e59acf240e2881b1c1e2f5586c9ca6f|
|[39758da17265a07f2370cd04057ea749](https://www.virustotal.com/gui/file/39758da17265a07f2370cd04057ea749)|Win32 EXE|barys|2015-05-30 13:33:52|/home/virustotal/sample/39758DA17265A07F2370CD04057EA749|
|[5e255a512dd38ffc86a2a4f95c62c13f](https://www.virustotal.com/gui/file/5e255a512dd38ffc86a2a4f95c62c13f)|Win32 EXE||2015-05-22 07:22:44|/home/virustotal/sample/5E255A512DD38FFC86A2A4F95C62C13F|
|[62c0b9ea3638bef977a7d33970e52e38](https://www.virustotal.com/gui/file/62c0b9ea3638bef977a7d33970e52e38)|Win32 EXE|blocker|2015-05-15 16:33:04| |
|[ffe598b9c3de334571881035d478abe4](https://www.virustotal.com/gui/file/ffe598b9c3de334571881035d478abe4)|Win32 EXE|blocker|2015-05-15 13:35:38| |
|[efe54df820fa8434cf14a5a8f55f52b7](https://www.virustotal.com/gui/file/efe54df820fa8434cf14a5a8f55f52b7)|Win32 EXE|blocker|2015-05-12 03:21:23| |
|[dd2d6b625e7add1528311a0cf5fd5eae](https://www.virustotal.com/gui/file/dd2d6b625e7add1528311a0cf5fd5eae)|Win32 EXE|Disfa|2015-05-11 20:59:43|hkcmd.exe|
|[24d2ce38d2886a00e678e8c23ad8d1ca](https://www.virustotal.com/gui/file/24d2ce38d2886a00e678e8c23ad8d1ca)|Win32 EXE|blocker|2015-05-04 22:08:17| |
|[868781bcb4a4dcb1ed493cd353c9e9ab](https://www.virustotal.com/gui/file/868781bcb4a4dcb1ed493cd353c9e9ab)|Win32 EXE||2015-05-02 08:13:13|/home/virustotal/sample/868781BCB4A4DCB1ED493CD353C9E9AB|
|[d5dff6db76b75d346d3b33bba5b7cbfa](https://www.virustotal.com/gui/file/d5dff6db76b75d346d3b33bba5b7cbfa)|Win32 EXE|injector|2015-04-17 20:12:26|w-2e3d0a4982.rar|
|[4d0cbb45b47eb95a9d00aba9b0f7daad](https://www.virustotal.com/gui/file/4d0cbb45b47eb95a9d00aba9b0f7daad)|Win32 EXE|Xtreme|2015-04-16 11:53:28|/home/virustotal/sample/4D0CBB45B47EB95A9D00ABA9B0F7DAAD|
|[360200d659519c5d398b05804975ebbe](https://www.virustotal.com/gui/file/360200d659519c5d398b05804975ebbe)|Win32 EXE||2015-04-15 20:57:02|Eraser.exe|
|[699067ce203ab9893943905e5b76f106](https://www.virustotal.com/gui/file/699067ce203ab9893943905e5b76f106)|Win32 EXE||2015-04-15 09:32:20|/home/virustotal/sample/699067CE203AB9893943905E5B76F106|
|[f33b62d496f58e752bb190296781cff9](https://www.virustotal.com/gui/file/f33b62d496f58e752bb190296781cff9)|Win32 EXE|bitrep|2015-04-14 06:28:48|daesh1.rar|
|[4e8cbe3f2cf11d35827194fd016dbd7b](https://www.virustotal.com/gui/file/4e8cbe3f2cf11d35827194fd016dbd7b)|Win32 EXE|Xtreme|2015-04-09 12:12:33|/home/virustotal/sample/4E8CBE3F2CF11D35827194FD016DBD7B|
|[b4c8ff21441e99f8199b3a8d7e0a61b9](https://www.virustotal.com/gui/file/b4c8ff21441e99f8199b3a8d7e0a61b9)|Win32 EXE|Xtreme|2015-04-09 12:05:44|/home/virustotal/sample/B4C8FF21441E99F8199B3A8D7E0A61B9|
|[3c73f34e9119de7789f2c2b9d0ed0440](https://www.virustotal.com/gui/file/3c73f34e9119de7789f2c2b9d0ed0440)|Win32 EXE||2015-03-30 09:58:23|/home/virustotal/sample/3C73F34E9119DE7789F2C2B9D0ED0440|
|[3dcb43a83a53a965b40de316c1593bca](https://www.virustotal.com/gui/file/3dcb43a83a53a965b40de316c1593bca)|Win32 EXE|PoisonIvy|2015-03-25 16:57:47|/home/virustotal/sample/3DCB43A83A53A965B40DE316C1593BCA|
|[d5b63862b8328fb45c3dabdcdf070d0d](https://www.virustotal.com/gui/file/d5b63862b8328fb45c3dabdcdf070d0d)|Win32 EXE|PoisonIvy|2015-03-25 13:25:27|ccleaner|
|[e540076f48d7069bacb6d607f2d389d9](https://www.virustotal.com/gui/file/e540076f48d7069bacb6d607f2d389d9)|Win32 EXE|PoisonIvy|2015-03-25 13:25:17|WiutrdJRTYKHU.exe|
|[bc42a09888de8b311f2e9ab0fc966c8c](https://www.virustotal.com/gui/file/bc42a09888de8b311f2e9ab0fc966c8c)|Win32 EXE|PoisonIvy|2015-03-25 13:03:18|/home/virustotal/sample/BC42A09888DE8B311F2E9AB0FC966C8C|
|[b184fa51604d7eaa5a45350d1e08e5b7](https://www.virustotal.com/gui/file/b184fa51604d7eaa5a45350d1e08e5b7)|Win32 EXE|Xtreme|2015-03-20 02:36:30|isheriff_b184fa51604d7eaa5a45350d1e08e5b7.bin|
|[77d43f0b32e30a3de6879610666f1b39](https://www.virustotal.com/gui/file/77d43f0b32e30a3de6879610666f1b39)|Win32 EXE|kazy|2015-03-19 08:13:10|WindoSDHBFH98327GYOBUIJNK.exe|
|[11a00d29d583b66bedd8dfe728144850](https://www.virustotal.com/gui/file/11a00d29d583b66bedd8dfe728144850)|Win32 EXE||2015-03-18 05:06:44|/home/virustotal/sample/11A00D29D583B66BEDD8DFE728144850|
|[cb008f71eb83e68b9f601533910b6cc8](https://www.virustotal.com/gui/file/cb008f71eb83e68b9f601533910b6cc8)|Win32 EXE|PoisonIvy|2015-03-12 23:27:53|sotb.exe|
|[89ff2642d8c6b0b49a009a36380495a7](https://www.virustotal.com/gui/file/89ff2642d8c6b0b49a009a36380495a7)|Win32 EXE|krypt|2015-03-12 23:05:24|isheriff_89ff2642d8c6b0b49a009a36380495a7.bin|
|[18d2222b56a499946e107721e5057a71](https://www.virustotal.com/gui/file/18d2222b56a499946e107721e5057a71)|Win32 EXE|kazy|2015-03-12 20:30:23|Win457fgSDGDfh4.exe|
|[f55646d64e9338db64ed9ba868c39ca6](https://www.virustotal.com/gui/file/f55646d64e9338db64ed9ba868c39ca6)|RAR||2015-03-12 19:49:32|dseebw.rar|
|[ec05a45ebd201a83974229a79979a672](https://www.virustotal.com/gui/file/ec05a45ebd201a83974229a79979a672)|Win32 EXE||2015-03-12 11:50:08|??? ??? ??? ?? ????? ?? ????? ??? ????.exe|
|[c7063f0178ea48e02f54769c0da275b8](https://www.virustotal.com/gui/file/c7063f0178ea48e02f54769c0da275b8)|Win32 EXE|injector|2015-03-09 06:11:49|WinComAanDoZ.exe|
|[42fca7968f6de3904225445312e4e985](https://www.virustotal.com/gui/file/42fca7968f6de3904225445312e4e985)|Win32 EXE||2015-03-04 00:42:12|WiytgfbDFH3487HUNWFJSF.exe|
|[53754fc20891b33d600f57a6e5975a41](https://www.virustotal.com/gui/file/53754fc20891b33d600f57a6e5975a41)|Win32 EXE||2015-03-04 00:41:56|AVP|
|[7578744cbed4963fe06f501d23d740b8](https://www.virustotal.com/gui/file/7578744cbed4963fe06f501d23d740b8)|RAR||2015-03-03 22:24:41|%D7%94%D7%9E%D7%A9%D7%98%D7%A8%D7%94_%D7%94%D7%A6%D7%91%D7%90%D7%99%D7%AA.rar|
|[b0f49c2c29d3966125dd322a504799c6](https://www.virustotal.com/gui/file/b0f49c2c29d3966125dd322a504799c6)|Win32 EXE||2015-03-03 14:25:42|/home/virustotal/sample/B0F49C2C29D3966125DD322A504799C6|
|[59bf51b101afd68d7dfc92140cbc312b](https://www.virustotal.com/gui/file/59bf51b101afd68d7dfc92140cbc312b)|RAR||2015-03-02 18:07:30|448c3d73f7b4a0d9b25534c9e79095ee2653172.rar|
|[7f684863780310a718254ff0f7f28ed2](https://www.virustotal.com/gui/file/7f684863780310a718254ff0f7f28ed2)|Win32 EXE||2015-03-01 10:17:59|המלט הישראלי המשוכלל הרמס 905 בפעולה.exe|
|[b0b9332082e98d51cb7265a45a945a22](https://www.virustotal.com/gui/file/b0b9332082e98d51cb7265a45a945a22)|Win32 EXE||2015-02-24 07:34:48|swedan.scr|
|[1f644de33d57c12a393b12f92a7c44c5](https://www.virustotal.com/gui/file/1f644de33d57c12a393b12f92a7c44c5)|Win32 EXE||2015-02-21 02:30:40|IPv.15Registerkey.exe|
|[0392f8be82a297242baad10a9a2912eb](https://www.virustotal.com/gui/file/0392f8be82a297242baad10a9a2912eb)|Win32 EXE|blocker|2015-02-17 18:47:45| |
|[17d70c318c6d16ea599e39550c44fa7f](https://www.virustotal.com/gui/file/17d70c318c6d16ea599e39550c44fa7f)|Win32 EXE||2015-02-16 07:40:12|???? ??? ???? ?????? ???? ?? ??? ???? ? ????? ??? ?? ????? ???? ????????? ????.exe|
|[476764a1e6e121cf59c7f101f0e14968](https://www.virustotal.com/gui/file/476764a1e6e121cf59c7f101f0e14968)|Win32 EXE|H-worm|2015-02-10 01:44:01|firefox.exe|
|[f93a95668040e143f19f94210ca18d88](https://www.virustotal.com/gui/file/f93a95668040e143f19f94210ca18d88)|Win32 EXE||2015-02-09 01:37:10|/home/test/Documents/EXE/malware_data/files/train/f93a95668040e143f19f94210ca18d88|
|[a347d25ed2ee07cbfe4baaabc6ff768b](https://www.virustotal.com/gui/file/a347d25ed2ee07cbfe4baaabc6ff768b)|Win32 EXE|kazy|2015-02-07 05:43:46|/home/virustotal/sample/A347D25ED2EE07CBFE4BAAABC6FF768B|
|[d5eee8dc2507d46e1dc11f7b7441f506](https://www.virustotal.com/gui/file/d5eee8dc2507d46e1dc11f7b7441f506)|Win32 EXE|autoit|2015-02-05 19:18:19|d5eee8dc2507d46e1dc11f7b7441f506.exe|
|[064f0a5fcc869f6eb77405d3fe98af87](https://www.virustotal.com/gui/file/064f0a5fcc869f6eb77405d3fe98af87)|Win32 EXE|Zbot|2015-02-04 03:51:30|w-5bae07407c.rar|
|[7ed4897b11798f4639c73d57f901a661](https://www.virustotal.com/gui/file/7ed4897b11798f4639c73d57f901a661)|Win32 EXE||2015-02-03 13:37:34|VirusShare_7ed4897b11798f4639c73d57f901a661|
|[9c85c9400f941c4f2c8a1833fbc9283f](https://www.virustotal.com/gui/file/9c85c9400f941c4f2c8a1833fbc9283f)|Win32 EXE|kazy|2015-02-02 21:49:12|1wbrflfx.exe|
|[ecb97f19ab0568cd0536567a7def44ff](https://www.virustotal.com/gui/file/ecb97f19ab0568cd0536567a7def44ff)|Win32 EXE|dynamer|2015-02-02 11:43:12|ecb97f19ab0568cd0536567a7def44ff|
|[7d27548e3f56fa532c571fb409ecd7b6](https://www.virustotal.com/gui/file/7d27548e3f56fa532c571fb409ecd7b6)|Win32 EXE||2015-02-01 15:44:12|/home/test/Documents/EXE/malware_data/files/train/7d27548e3f56fa532c571fb409ecd7b6|
|[fe71389acd3ee1b42a0895668c73dc21](https://www.virustotal.com/gui/file/fe71389acd3ee1b42a0895668c73dc21)|Win32 EXE|Disfa|2015-02-01 15:42:15|/var/www/clean-mx/virusesevidence/output.56199023.txt|
|[fbb0ba6e2e570ca1b4f495f3040b6f6d](https://www.virustotal.com/gui/file/fbb0ba6e2e570ca1b4f495f3040b6f6d)|Win32 EXE|dapato|2015-01-31 22:00:36|fbb0ba6e2e570ca1b4f495f3040b6f6d.exe|
|[6212e9a07225d6b71769d2bbbc20cd04](https://www.virustotal.com/gui/file/6212e9a07225d6b71769d2bbbc20cd04)|Win32 EXE||2015-01-31 21:53:24|/home/test/Documents/EXE/malware_data/files/train/6212e9a07225d6b71769d2bbbc20cd04|
|[0975222de39433a25e672595b1960cdb](https://www.virustotal.com/gui/file/0975222de39433a25e672595b1960cdb)|Win32 EXE|Disfa|2015-01-30 20:20:12|0975222de39433a25e672595b1960cdb|
|[83ad97bf1d5a9044aafba6aac4b7387e](https://www.virustotal.com/gui/file/83ad97bf1d5a9044aafba6aac4b7387e)|Win32 EXE|H-worm|2015-01-30 12:12:51|/var/www/clean-mx/virusesevidence/output.56199068.txt|
|[e613fbaaf0e64b1ca740f9859d5caf0b](https://www.virustotal.com/gui/file/e613fbaaf0e64b1ca740f9859d5caf0b)|Win32 EXE|Kryptik|2015-01-28 17:26:09|/home/test/Documents/EXE/malware_data/files/train/e613fbaaf0e64b1ca740f9859d5caf0b|
|[1966f3b1d4adec25ab866c4e061a1e50](https://www.virustotal.com/gui/file/1966f3b1d4adec25ab866c4e061a1e50)|Win32 EXE|Disfa|2015-01-28 13:38:06|/home/test/Documents/EXE/malware_data/files/train/1966f3b1d4adec25ab866c4e061a1e50|
|[17ee9082d6030c69c0ffd768e76004da](https://www.virustotal.com/gui/file/17ee9082d6030c69c0ffd768e76004da)|Win32 EXE||2015-01-28 05:13:18|svhost|
|[5e518584ac5c33c5809e037b25e1e9d7](https://www.virustotal.com/gui/file/5e518584ac5c33c5809e037b25e1e9d7)|Win32 EXE||2015-01-27 22:01:07|svhost|
|[2c8c94e85ef8c757586590e8d1abdc6c](https://www.virustotal.com/gui/file/2c8c94e85ef8c757586590e8d1abdc6c)|Win32 EXE||2015-01-27 19:39:17|2c8c94e85ef8c757586590e8d1abdc6c.exe|
|[280d547e055de707c1e357b95568b9a9](https://www.virustotal.com/gui/file/280d547e055de707c1e357b95568b9a9)|Win32 EXE||2015-01-26 18:12:40|svhost|
|[8943a561f0839d43b8bd476357992540](https://www.virustotal.com/gui/file/8943a561f0839d43b8bd476357992540)|Win32 EXE|Disfa|2015-01-26 08:20:59|8943a561f0839d43b8bd476357992540.exe|
|[573138482b185f493b49d3966650cdad](https://www.virustotal.com/gui/file/573138482b185f493b49d3966650cdad)|Win32 EXE||2015-01-23 20:19:07|hezbalaah.scr|
|[2930596d4e1328b79c349455e71ee1b0](https://www.virustotal.com/gui/file/2930596d4e1328b79c349455e71ee1b0)|Win32 EXE|dapato|2015-01-23 20:11:21|hezbalaah.scr|
|[e42cd849370f2be67f40b97b5d741b37](https://www.virustotal.com/gui/file/e42cd849370f2be67f40b97b5d741b37)|Win32 EXE||2015-01-22 12:10:36|/home/test/Documents/EXE/malware_data/files/train/e42cd849370f2be67f40b97b5d741b37|
|[76a68fe73fff571f257a1b0f100aca1d](https://www.virustotal.com/gui/file/76a68fe73fff571f257a1b0f100aca1d)|Win32 EXE||2015-01-21 14:31:06|/home/test/Documents/EXE/malware_data/files/train/76a68fe73fff571f257a1b0f100aca1d|
|[1325ab5dca14b58a8a7b9a8f5a1ee4dc](https://www.virustotal.com/gui/file/1325ab5dca14b58a8a7b9a8f5a1ee4dc)|Win32 EXE||2015-01-20 08:58:56|/home/test/Documents/EXE/malware_data/files/train/1325ab5dca14b58a8a7b9a8f5a1ee4dc|
|[841c3afaa8caf0ac33bf783d5feaeadb](https://www.virustotal.com/gui/file/841c3afaa8caf0ac33bf783d5feaeadb)|Win32 EXE||2015-01-18 01:26:41|8d3ec2c97867dd48459951a5c3761e0696f09a1606af6cf1163bfdf283cc3c26|
|[df38b1562e4f0b735b3e10bae78df2a9](https://www.virustotal.com/gui/file/df38b1562e4f0b735b3e10bae78df2a9)|Win32 EXE|dapato|2015-01-15 12:12:35|iran.scr|
|[1d393d173f0415a98a906064348b3dc5](https://www.virustotal.com/gui/file/1d393d173f0415a98a906064348b3dc5)|Win32 EXE||2015-01-13 10:56:05|svhost|
|[bbc79bca19b0ebb95cb9cc69cc656382](https://www.virustotal.com/gui/file/bbc79bca19b0ebb95cb9cc69cc656382)|Win32 EXE||2015-01-13 00:26:45|Skype|
|[ac89e42ee593cea80030820618f2bcf6](https://www.virustotal.com/gui/file/ac89e42ee593cea80030820618f2bcf6)|Win32 EXE|Xtreme|2015-01-12 01:45:33|ac89e42ee593cea80030820618f2bcf6|
|[b053bbb499d68cce1782b33fde7b43ff](https://www.virustotal.com/gui/file/b053bbb499d68cce1782b33fde7b43ff)|Win32 EXE|Disfa|2015-01-11 10:10:03|Process Hacker|
|[4e2405d93e541f9bae34564c80f7432e](https://www.virustotal.com/gui/file/4e2405d93e541f9bae34564c80f7432e)|Win32 EXE||2015-01-10 12:00:07|micro.exe|
|[466667cea81ad59dc210ccb3bebbfa9e](https://www.virustotal.com/gui/file/466667cea81ad59dc210ccb3bebbfa9e)|Win32 EXE||2015-01-07 14:53:50|pat.exe|
|[9eb3d9e045dba73f449661a2a49a9e6d](https://www.virustotal.com/gui/file/9eb3d9e045dba73f449661a2a49a9e6d)|Win32 EXE||2015-01-07 14:53:45|updater.exe|
|[aefea9d795624da16d878dc9bb81bf87](https://www.virustotal.com/gui/file/aefea9d795624da16d878dc9bb81bf87)|Win32 EXE||2015-01-02 10:03:04|Skype|
|[b82de5f1c26143083d988b06f6c927c3](https://www.virustotal.com/gui/file/b82de5f1c26143083d988b06f6c927c3)|Win32 EXE|Andromeda|2015-01-01 19:15:48|b82de5f1c26143083d988b06f6c927c3|
|[accf82fc29467c08ce087072fea3d14a](https://www.virustotal.com/gui/file/accf82fc29467c08ce087072fea3d14a)|Win32 EXE|Athena|2015-01-01 19:01:45|NBJ.exe|
|[18259503e5dfdf9f5c3fc98cdfac6b78](https://www.virustotal.com/gui/file/18259503e5dfdf9f5c3fc98cdfac6b78)|Win32 EXE|Vertexbot|2014-12-31 01:06:19|/home/virustotal/sample/18259503E5DFDF9F5C3FC98CDFAC6B78|
|[0b074367862e1b0ae461900c8f8b81b6](https://www.virustotal.com/gui/file/0b074367862e1b0ae461900c8f8b81b6)|Win32 EXE|Vertexbot|2014-12-30 15:09:55|/home/virustotal/sample/0B074367862E1B0AE461900C8F8B81B6|
|[89f2213a9a839af098e664aaa671111b](https://www.virustotal.com/gui/file/89f2213a9a839af098e664aaa671111b)|RAR|Vertexbot|2014-12-30 15:05:03|/home/virustotal/sample/89F2213A9A839AF098E664AAA671111B|
|[23108c347282ff101a2104bcf54204a8](https://www.virustotal.com/gui/file/23108c347282ff101a2104bcf54204a8)|Win32 EXE||2014-12-24 19:27:59|/home/virustotal/sample/23108C347282FF101A2104BCF54204A8|
|[ca78b173218ad8be863c7e00fec61f2f](https://www.virustotal.com/gui/file/ca78b173218ad8be863c7e00fec61f2f)|ZIP||2014-12-24 19:25:17|/home/virustotal/sample/CA78B173218AD8BE863C7E00FEC61F2F|
|[e61732add06f5eb98fe6ad42ce9682f6](https://www.virustotal.com/gui/file/e61732add06f5eb98fe6ad42ce9682f6)|Win32 EXE||2014-12-17 20:26:07|deaf.scr|
|[6b4248a01a26ff07a85b5316702a2f5f](https://www.virustotal.com/gui/file/6b4248a01a26ff07a85b5316702a2f5f)|Win32 EXE||2014-12-16 21:08:38|Wextract|
|[a59399c7608d140dc9cb5dffcb46f1d9](https://www.virustotal.com/gui/file/a59399c7608d140dc9cb5dffcb46f1d9)|Win32 EXE||2014-12-16 20:59:05|Wextract|
|[7075c9a874ab5b0c27942714394f3885](https://www.virustotal.com/gui/file/7075c9a874ab5b0c27942714394f3885)|Win32 EXE||2014-12-16 19:04:07|Nveron|
|[8bbad466f2257e05f66ece621ccf2056](https://www.virustotal.com/gui/file/8bbad466f2257e05f66ece621ccf2056)|Win32 EXE||2014-12-16 18:23:56|Nveron|
|[2986d9af413cd09d9ffdb40040e5c180](https://www.virustotal.com/gui/file/2986d9af413cd09d9ffdb40040e5c180)|Win32 EXE||2014-12-16 05:18:36|svhost|
|[940a1b2c537fa2f764283795e9b665ba](https://www.virustotal.com/gui/file/940a1b2c537fa2f764283795e9b665ba)|Win32 EXE||2014-12-09 20:17:27|2014.scr|
|[36e3307f26e5b8bdba30d7ea7ca62cd8](https://www.virustotal.com/gui/file/36e3307f26e5b8bdba30d7ea7ca62cd8)|Win32 EXE|dynamer|2014-12-09 02:07:13|36e3307f26e5b8bdba30d7ea7ca62cd8|
|[c64052167d6a183a3ecc259ee0f3a0c6](https://www.virustotal.com/gui/file/c64052167d6a183a3ecc259ee0f3a0c6)|Win32 EXE|Xtreme|2014-12-05 18:38:30|c64052167d6a183a3ecc259ee0f3a0c6|
|[b7b01ee8548d4097f528ae4280834667](https://www.virustotal.com/gui/file/b7b01ee8548d4097f528ae4280834667)|Win32 EXE|Xtreme|2014-12-05 04:45:05|b7b01ee8548d4097f528ae4280834667|
|[73c46bacc471db08a6c0e31caef3f9e8](https://www.virustotal.com/gui/file/73c46bacc471db08a6c0e31caef3f9e8)|Win32 EXE|Symmi|2014-12-03 17:52:11|snyp|
|[e85c9666ddb6239fff16fa7b78c8f96b](https://www.virustotal.com/gui/file/e85c9666ddb6239fff16fa7b78c8f96b)|Win32 EXE|Symmi|2014-12-02 09:37:42|OneDrive|
|[e1d2543aba350a83c968872fbe957d85](https://www.virustotal.com/gui/file/e1d2543aba350a83c968872fbe957d85)|Win32 EXE|Symmi|2014-11-28 11:55:15|snyp|
|[e3e2cd771c8183464737233d17cd6a09](https://www.virustotal.com/gui/file/e3e2cd771c8183464737233d17cd6a09)|Win32 EXE|strictor|2014-11-28 05:09:29|e71ec4a6ced32f716a691d0c75f08efbf0b8afd5|
|[a4c1ceda720e1b3f860a81674588542f](https://www.virustotal.com/gui/file/a4c1ceda720e1b3f860a81674588542f)|Win32 EXE||2014-11-27 07:00:30|syn|
|[f78fcd4eaf3d9cd95116b6e6212ad327](https://www.virustotal.com/gui/file/f78fcd4eaf3d9cd95116b6e6212ad327)|Win32 EXE|Symmi|2014-11-27 00:33:13|snyp|
|[0aee50dff0a4c22da5ff3decdb261897](https://www.virustotal.com/gui/file/0aee50dff0a4c22da5ff3decdb261897)|Win32 EXE|Symmi|2014-11-20 15:10:18|OneDrive|
|[441951e52741195e037b0ed14e5b183c](https://www.virustotal.com/gui/file/441951e52741195e037b0ed14e5b183c)|Win32 EXE|Symmi|2014-11-19 19:43:12|OneDrive|
|[c7a864cbad17223470965cc33133b36e](https://www.virustotal.com/gui/file/c7a864cbad17223470965cc33133b36e)|Win32 EXE|Symmi|2014-11-19 15:15:21|OneDrive|
|[a37b7ef490aec8a0d97c1e70733c11c6](https://www.virustotal.com/gui/file/a37b7ef490aec8a0d97c1e70733c11c6)|Win32 EXE|Symmi|2014-11-19 14:06:33|OneDrive|
|[77d02be92d052f35604caa9885dd9a77](https://www.virustotal.com/gui/file/77d02be92d052f35604caa9885dd9a77)|Win32 EXE|Xtreme|2014-11-18 22:57:34|77d02be92d052f35604caa9885dd9a77|
|[436a7ad10b379ddc0a454e5129dc3ba6](https://www.virustotal.com/gui/file/436a7ad10b379ddc0a454e5129dc3ba6)|Win32 EXE|Symmi|2014-11-13 05:33:14|synn|
|[c48cba5e50a58dcec3c57c5f7cc3332d](https://www.virustotal.com/gui/file/c48cba5e50a58dcec3c57c5f7cc3332d)|Win32 EXE|Vertexbot|2014-11-13 05:05:13|/home/virustotal/sample/C48CBA5E50A58DCEC3C57C5F7CC3332D|
|[658f47b30d545498e3895c5aa333ecb1](https://www.virustotal.com/gui/file/658f47b30d545498e3895c5aa333ecb1)|Win32 EXE|Vertexbot|2014-11-13 04:55:03|/home/virustotal/sample/658F47B30D545498E3895C5AA333ECB1|
|[927dba3c9b98fd749017e3dee270136b](https://www.virustotal.com/gui/file/927dba3c9b98fd749017e3dee270136b)|Win32 EXE|Xtreme|2014-11-12 15:40:03|927dba3c9b98fd749017e3dee270136b|
|[91510aa0bbf961a34f0326fbaf2bcbb1](https://www.virustotal.com/gui/file/91510aa0bbf961a34f0326fbaf2bcbb1)|Win32 EXE|Symmi|2014-11-10 08:10:50|synn|
|[bb15e754ae3b85a12447b448f6f7e43e](https://www.virustotal.com/gui/file/bb15e754ae3b85a12447b448f6f7e43e)|Win32 EXE|Zbot|2014-11-10 05:44:58|bb15e754ae3b85a12447b448f6f7e43e|
|[8ff5ef99faf5e17b7d5b46585bac7b43](https://www.virustotal.com/gui/file/8ff5ef99faf5e17b7d5b46585bac7b43)|Win32 EXE||2014-11-10 05:30:21|8ff5ef99faf5e17b7d5b46585bac7b43|
|[f75cebd9a5d2f367117109845561e2d4](https://www.virustotal.com/gui/file/f75cebd9a5d2f367117109845561e2d4)|Win32 EXE|Symmi|2014-11-05 15:29:36|synn|
|[a1b7f8f3cf6dee880028bd6db8111a1d](https://www.virustotal.com/gui/file/a1b7f8f3cf6dee880028bd6db8111a1d)|Win32 EXE|Symmi|2014-10-28 08:32:17|synn|
|[d048a6a8377a865f07cbc2429ffaa3e7](https://www.virustotal.com/gui/file/d048a6a8377a865f07cbc2429ffaa3e7)|Win32 EXE||2014-10-25 14:04:03|Skype|
|[fa6fbd1dd2d58885772bd0b37633d5d7](https://www.virustotal.com/gui/file/fa6fbd1dd2d58885772bd0b37633d5d7)|Win32 EXE||2014-10-23 14:49:25|svhost|
|[4791667a4935718c4a55fa23eb18a520](https://www.virustotal.com/gui/file/4791667a4935718c4a55fa23eb18a520)|Win32 EXE||2014-10-21 10:00:35|4791667a4935718c4a55fa23eb18a520|
|[fa8c119b3f0b1f9c2aa9f5d8908c9536](https://www.virustotal.com/gui/file/fa8c119b3f0b1f9c2aa9f5d8908c9536)|Win32 EXE|Disfa|2014-10-17 04:00:43|fa8c119b3f0b1f9c2aa9f5d8908c9536|
|[05618077c03b80ace066b9851966fbb1](https://www.virustotal.com/gui/file/05618077c03b80ace066b9851966fbb1)|Win32 EXE|Xtreme|2014-10-16 17:28:10|05618077c03b80ace066b9851966fbb1|
|[7aefb825277764cd9f31bc1f2370d18d](https://www.virustotal.com/gui/file/7aefb825277764cd9f31bc1f2370d18d)|Win32 EXE|Xtreme|2014-10-15 17:24:52|w-fc65215b1b.rar|
|[238b48338c14c8ea87ff7ccab4544252](https://www.virustotal.com/gui/file/238b48338c14c8ea87ff7ccab4544252)|Win32 EXE||2014-10-14 09:50:09|svhost|
|[2bce2ccd484a063e5e432a6f651782d9](https://www.virustotal.com/gui/file/2bce2ccd484a063e5e432a6f651782d9)|Win32 EXE||2014-10-13 15:30:23|Wextract|
|[63c480b1cc601b02b4acb30309b007e6](https://www.virustotal.com/gui/file/63c480b1cc601b02b4acb30309b007e6)|Win32 EXE|Symmi|2014-10-13 02:09:31|snys|
|[a313d1092c5245da1c20ac05915a3d11](https://www.virustotal.com/gui/file/a313d1092c5245da1c20ac05915a3d11)|Win32 EXE|Symmi|2014-10-08 09:22:31|synn|
|[7681ae3933f3e13eb8e2a9be281a5763](https://www.virustotal.com/gui/file/7681ae3933f3e13eb8e2a9be281a5763)|Win32 EXE|Symmi|2014-10-07 08:10:43|w-afead148c4.rar|
|[4a0ef41272210f41b987224ff57f6280](https://www.virustotal.com/gui/file/4a0ef41272210f41b987224ff57f6280)|Win32 EXE|Zbot|2014-10-06 08:39:46|vti-rescan|
|[5e43b6ca1fa9536f31e09d9a418ac8c3](https://www.virustotal.com/gui/file/5e43b6ca1fa9536f31e09d9a418ac8c3)|Win32 EXE||2014-10-05 08:34:13|AJYHTFGEWHR.exe|
|[0b2023bc4adfbb8157da9147b9fafacb](https://www.virustotal.com/gui/file/0b2023bc4adfbb8157da9147b9fafacb)|Win32 EXE|Zbot|2014-10-01 09:57:30|vt-upload-gjWSu|
|[e763e2a3b0b1ed43447afe281e134e95](https://www.virustotal.com/gui/file/e763e2a3b0b1ed43447afe281e134e95)|Win32 EXE|Symmi|2014-09-29 20:58:43|synn|
|[6ff73820c23551225de0ca08c2fc4397](https://www.virustotal.com/gui/file/6ff73820c23551225de0ca08c2fc4397)|Win32 EXE|Symmi|2014-09-29 09:23:02|synn|
|[948d32f3f12b8c7e47a6102ab968f705](https://www.virustotal.com/gui/file/948d32f3f12b8c7e47a6102ab968f705)|Win32 EXE|poison|2014-09-19 23:24:19|/home/virustotal/sample/948D32F3F12B8C7E47A6102AB968F705|
|[6be46a719b962792fd8f453914a87d3e](https://www.virustotal.com/gui/file/6be46a719b962792fd8f453914a87d3e)|Win32 EXE||2014-09-14 16:48:28|0449259e-09ba-11e8-9a53-c80aa9379365|
|[2e49f5bd50a4e82db05b4e42f18536f3](https://www.virustotal.com/gui/file/2e49f5bd50a4e82db05b4e42f18536f3)|Win32 EXE|Disfa|2014-09-06 15:50:21|w-b7e7f236ca.rar|
|[6203dde9fad9da6f9a85d609397105f0](https://www.virustotal.com/gui/file/6203dde9fad9da6f9a85d609397105f0)|Win32 EXE|PoisonIvy|2014-09-03 22:30:09|C:\Users\Hanan\Downloads\Malware\Mails\IDF 03-09-2014\file\Dumped.ex_|
|[71b00cbd186b1c168fd207b8f43fc8e0](https://www.virustotal.com/gui/file/71b00cbd186b1c168fd207b8f43fc8e0)|Win32 EXE|H-worm|2014-09-01 12:34:02|vti-rescan|
|[76f74b24480bc1a42998c9440ddc2fad](https://www.virustotal.com/gui/file/76f74b24480bc1a42998c9440ddc2fad)|Win32 EXE|Symmi|2014-08-22 00:45:49|syn|
|[dff746868a1559de9d25037e73c06c52](https://www.virustotal.com/gui/file/dff746868a1559de9d25037e73c06c52)|Win32 EXE||2014-08-01 03:06:59|svhost|
|[9469ff12c582cf7943582dd28a1920cc](https://www.virustotal.com/gui/file/9469ff12c582cf7943582dd28a1920cc)|Win32 EXE|Sality|2014-07-27 13:14:06|syn|
|[686779709226c6727bd9ebc4b1ff21b1](https://www.virustotal.com/gui/file/686779709226c6727bd9ebc4b1ff21b1)|Win32 EXE|Sality|2014-07-27 11:31:27|syn|
|[d72906bc778d710b7ce5c5185280ea3d](https://www.virustotal.com/gui/file/d72906bc778d710b7ce5c5185280ea3d)|Win32 EXE|strictor|2014-07-24 19:10:01|Skype|
|[c900f5a9fd675e3ab56d62f03ee76cae](https://www.virustotal.com/gui/file/c900f5a9fd675e3ab56d62f03ee76cae)|Win32 EXE|Symmi|2014-07-16 11:32:16|synn|
|[b312d48899c00e8bbaaff72503a07de8](https://www.virustotal.com/gui/file/b312d48899c00e8bbaaff72503a07de8)|Win32 EXE||2014-06-29 09:35:15|Skype|
|[02ffcfdcfb205cece05597fce1b307b7](https://www.virustotal.com/gui/file/02ffcfdcfb205cece05597fce1b307b7)|Win32 EXE|Symmi|2014-06-24 20:11:58|synn|
|[b08a67892d2198aeb2826b398f8c6c74](https://www.virustotal.com/gui/file/b08a67892d2198aeb2826b398f8c6c74)|Win32 EXE|Symmi|2014-06-20 15:52:29|snyp|
|[4377b17d7984838993b998c4bab97925](https://www.virustotal.com/gui/file/4377b17d7984838993b998c4bab97925)|Win32 EXE|Symmi|2014-06-18 21:01:06|sny|
|[a668c1dbdcdf2d561bea512361b101b9](https://www.virustotal.com/gui/file/a668c1dbdcdf2d561bea512361b101b9)|Win32 EXE|Symmi|2014-06-18 09:47:52|synn|
|[4907a68a3ff0f010ed74214f957746c0](https://www.virustotal.com/gui/file/4907a68a3ff0f010ed74214f957746c0)|Win32 EXE|Symmi|2014-06-09 20:11:35|sny|
|[f3d6bb7addc88ad45f79c5199f8db2e0](https://www.virustotal.com/gui/file/f3d6bb7addc88ad45f79c5199f8db2e0)|Win32 EXE|Symmi|2014-06-08 17:29:41|sny|
|[a0b76ea08917a9dd785a0a1a6ae6eebe](https://www.virustotal.com/gui/file/a0b76ea08917a9dd785a0a1a6ae6eebe)|Win32 EXE|Symmi|2014-06-04 02:36:26|sny|
|[bd54d70d473d45b75cc8bf1fbe6fa022](https://www.virustotal.com/gui/file/bd54d70d473d45b75cc8bf1fbe6fa022)|Win32 EXE|Symmi|2014-05-30 17:46:06|syn|
|[a90225a88ee974453b93ee7f0d93b104](https://www.virustotal.com/gui/file/a90225a88ee974453b93ee7f0d93b104)|Win32 EXE||2014-05-28 16:46:50|chrome_exe|
|[a6a839438d35f503dfebc6c5eec4330e](https://www.virustotal.com/gui/file/a6a839438d35f503dfebc6c5eec4330e)|Win32 EXE||2014-05-27 23:13:19|vti-rescan|
|[2d843b8452b5e48acbbe869e51337993](https://www.virustotal.com/gui/file/2d843b8452b5e48acbbe869e51337993)|Win32 EXE||2014-05-27 02:38:41|Skype.exe|
|[2607abe604832363514eb58c33a682fc](https://www.virustotal.com/gui/file/2607abe604832363514eb58c33a682fc)|Win32 EXE|Symmi|2014-05-20 06:16:59|sny|
|[f3d9689121a996f68533bd78eb6a18d9](https://www.virustotal.com/gui/file/f3d9689121a996f68533bd78eb6a18d9)|Win32 EXE|Symmi|2014-05-19 20:12:15|synn|
|[2219f3941603262dc3478c60df3b02f6](https://www.virustotal.com/gui/file/2219f3941603262dc3478c60df3b02f6)|Win32 EXE|Symmi|2014-05-15 21:48:58|sny|
|[9dccb01facfbbb69429ef0faf4bc1bda](https://www.virustotal.com/gui/file/9dccb01facfbbb69429ef0faf4bc1bda)|Win32 EXE||2014-05-12 10:33:43|/home/virustotal/sample/9DCCB01FACFBBB69429EF0FAF4BC1BDA|
|[518a765d999191b9ed7c4730714def31](https://www.virustotal.com/gui/file/518a765d999191b9ed7c4730714def31)|Win32 EXE||2014-05-08 09:55:41|Skype|
|[96d56c4a5426466f2a0dc3813386818d](https://www.virustotal.com/gui/file/96d56c4a5426466f2a0dc3813386818d)|Win32 EXE||2014-05-07 09:32:26|Skype|
|[f7ba0e5a7eeaeb359234b204fb1954ae](https://www.virustotal.com/gui/file/f7ba0e5a7eeaeb359234b204fb1954ae)|Win32 EXE|Symmi|2014-05-02 19:02:23|syns|
|[decb846191be54c441677bb1da264029](https://www.virustotal.com/gui/file/decb846191be54c441677bb1da264029)|Win32 EXE|Symmi|2014-05-01 12:23:38|syns|
|[8ca915ab1d69a7007237eb83ae37eae5](https://www.virustotal.com/gui/file/8ca915ab1d69a7007237eb83ae37eae5)|Win32 EXE||2014-04-30 18:09:56|vti-rescan|
|[6f9585c8748cd0e7103eab4eda233666](https://www.virustotal.com/gui/file/6f9585c8748cd0e7103eab4eda233666)|Win32 EXE||2014-04-22 23:59:49|9b7023a38070c871fdd39ea4c5246a151ebb1248cc8bcb35a1d51906b0de65d8.vir|
|[a75281ee9c7c365a776ce8d2b11d28da](https://www.virustotal.com/gui/file/a75281ee9c7c365a776ce8d2b11d28da)|Win32 EXE||2014-04-21 17:12:57|vti-rescan|
|[8ef883fd3e6523975ef9f6310b604feb](https://www.virustotal.com/gui/file/8ef883fd3e6523975ef9f6310b604feb)|Win32 EXE|Symmi|2014-04-16 11:15:41|syns|
|[ef893ee05b6239fd2918e29e50973bc3](https://www.virustotal.com/gui/file/ef893ee05b6239fd2918e29e50973bc3)|Win32 EXE|Symmi|2014-04-02 10:22:20|syn|
|[c60ada815212fc9c58fb801f99c230a4](https://www.virustotal.com/gui/file/c60ada815212fc9c58fb801f99c230a4)|Win32 EXE|strictor|2014-03-26 01:58:36|Skype|
|[2b94213b0ba7200742a08992b69a127a](https://www.virustotal.com/gui/file/2b94213b0ba7200742a08992b69a127a)|Win32 EXE|Symmi|2014-03-17 10:13:35|syns|
|[2b473f1f7c2b2b97f928c1fc497c0650](https://www.virustotal.com/gui/file/2b473f1f7c2b2b97f928c1fc497c0650)|Win32 EXE|kazy|2014-03-13 11:45:46|/home/virustotal/sample/2B473F1F7C2B2B97F928C1FC497C0650|
|[fe326b5439d0cf5683f24b2792807481](https://www.virustotal.com/gui/file/fe326b5439d0cf5683f24b2792807481)|Win32 EXE|Symmi|2014-03-03 09:51:30|syns|
|[7ed79032a1ad8535242428e69507ca0a](https://www.virustotal.com/gui/file/7ed79032a1ad8535242428e69507ca0a)|Win32 EXE||2014-02-13 09:33:52|Explore|
|[fac66827a8cf3197358c1eaf1d6aa2bf](https://www.virustotal.com/gui/file/fac66827a8cf3197358c1eaf1d6aa2bf)|Win32 EXE|Symmi|2014-02-11 10:24:03|syn|
|[8a9b52ff90bbd585907694e68551b991](https://www.virustotal.com/gui/file/8a9b52ff90bbd585907694e68551b991)|Win32 EXE|strictor|2014-02-04 18:06:50|taskhosts|
|[33d56702729fd2bc5eb0f467663b03b4](https://www.virustotal.com/gui/file/33d56702729fd2bc5eb0f467663b03b4)|Win32 EXE|Symmi|2014-01-21 18:55:05|syn|
|[2aad951dbecb6d4715b306b337ca5c34](https://www.virustotal.com/gui/file/2aad951dbecb6d4715b306b337ca5c34)|Win32 EXE|Xtreme|2013-12-22 08:49:07|WinWord|
|[b23c2925ee2d48517d17d4886e21c630](https://www.virustotal.com/gui/file/b23c2925ee2d48517d17d4886e21c630)|Win32 EXE|strictor|2013-12-20 19:14:41|Skype|
|[34c5e6b2a988076035e47d1f74319e86](https://www.virustotal.com/gui/file/34c5e6b2a988076035e47d1f74319e86)|RAR||2013-12-18 23:15:11|PM Netanyahu Remarks at the Start of the Weekly Cabinet Meeting.rar|
|[13e351c327579fee7c2b975b17ef377c](https://www.virustotal.com/gui/file/13e351c327579fee7c2b975b17ef377c)|Win32 EXE||2013-12-03 16:58:45|afe220114dfeb1df3329bdea4e34ce767d8050d1da4394879ef4cd3d62c19034.vir|
|[c0488b48d6aabe828a76ae427bd36cf1](https://www.virustotal.com/gui/file/c0488b48d6aabe828a76ae427bd36cf1)|Win32 EXE|Xtreme|2013-11-25 13:40:57|67a70518abb3b268c9dd580c4074daa5e37ed777a302b378d549b47db85ae5d9.vir|
|[14d83f01ecf644dc29302b95542c9d35](https://www.virustotal.com/gui/file/14d83f01ecf644dc29302b95542c9d35)|Win32 EXE||2013-11-10 16:49:24|Major Israel-US rift over Washington plan to let Tehran continue enriching uranium with sanctions relief.scr|
|[e7e05001a294ebfe8a012dd3bce78e96](https://www.virustotal.com/gui/file/e7e05001a294ebfe8a012dd3bce78e96)|Win32 EXE||2013-08-27 11:31:04|2369c434e37be58506063abd6aad9321fac8edda|
|[d14e0a3d408065b1551f2827b50b83ca](https://www.virustotal.com/gui/file/d14e0a3d408065b1551f2827b50b83ca)|Win32 EXE|kazy|2013-08-21 17:16:43|9deee5f984b0f0c9c5e0dc83909acf77f50d671e|
|[926235fcf7b91442a405b5760a0729eb](https://www.virustotal.com/gui/file/926235fcf7b91442a405b5760a0729eb)|Win32 EXE||2013-08-12 22:23:14|chrome_exe|
|[2eb1503751a7c74890096b1837c7bd81](https://www.virustotal.com/gui/file/2eb1503751a7c74890096b1837c7bd81)|Win32 EXE|graftor|2013-08-10 13:16:43|540e975884cbb673a8d45f73cd5f26ebd0837e0c|
|[b7df947b4a67a884c751840f83c4405e](https://www.virustotal.com/gui/file/b7df947b4a67a884c751840f83c4405e)|Win32 EXE|Xtreme|2013-08-10 02:34:41|6a1bd6ced824ff5e4f11b47aca2381c3f3c4ec64|
|[d9a7c4a100cfefef995785f707be895c](https://www.virustotal.com/gui/file/d9a7c4a100cfefef995785f707be895c)|Win32 EXE|Dorkbot|2013-08-09 09:18:11|bc2c1e2d23058a9277e8f3550fb7b0dfbb2c6e8a19e7981e24a72ea725682ecf.vir|
|[31f96add841594d35e6e97376114e756](https://www.virustotal.com/gui/file/31f96add841594d35e6e97376114e756)|Win32 EXE|Delf|2013-08-08 08:16:28|82b485f10c49a186718aba5e691a2384154e847c|
|[998f30457bc48a1a6567203e0ec3282e](https://www.virustotal.com/gui/file/998f30457bc48a1a6567203e0ec3282e)|Win32 EXE|graftor|2013-08-07 21:46:58|RJEa|
|[b05603938a888018d4dcdc551c4be8ac](https://www.virustotal.com/gui/file/b05603938a888018d4dcdc551c4be8ac)|Win32 EXE|Dorkbot|2013-08-07 21:16:26|Kaspersky Password Manager|
|[a60873e364a01870b2010518d05a62df](https://www.virustotal.com/gui/file/a60873e364a01870b2010518d05a62df)|Win32 EXE|Dorkbot|2013-07-24 17:50:29|b943b3a819f5774cb72a2438bd4859a841156818|
|[2559fe4eb88561138ce292df5d0e099f](https://www.virustotal.com/gui/file/2559fe4eb88561138ce292df5d0e099f)|Win32 EXE||2013-07-21 22:53:06|NE|
|[16346b95e6deef9da7fe796c31b9dec4](https://www.virustotal.com/gui/file/16346b95e6deef9da7fe796c31b9dec4)|Win32 EXE|Dorkbot|2013-07-18 12:51:37|b745cf098e8643fb92723dedaef3343ec659baa288fffe847e961a8e62c2075f.vir|
|[cf31aea415e7013e85d1687a1c0f5daa](https://www.virustotal.com/gui/file/cf31aea415e7013e85d1687a1c0f5daa)|Win32 EXE|Dorkbot|2013-07-15 15:53:14|IDF Unit 8200 greatest spy of all time on Palestinian and Arab networks.doc- - - - - - - - - - - - - - - - -.scr|
|[e85fc76362c2e9dc7329fddda8acc89e](https://www.virustotal.com/gui/file/e85fc76362c2e9dc7329fddda8acc89e)|Win32 EXE||2013-07-09 06:43:00|PE Explorer|
|[a8714aac274a18f1724d9702d40030bf](https://www.virustotal.com/gui/file/a8714aac274a18f1724d9702d40030bf)|Win32 EXE|injector|2013-07-09 06:39:36|vti-rescan|
|[9dff139bbbe476770294fb86f4e156ac](https://www.virustotal.com/gui/file/9dff139bbbe476770294fb86f4e156ac)|Win32 EXE|injector|2013-07-04 09:28:17|vti-rescan|
|[6350d1039742b87b7917a5e26de2c25c](https://www.virustotal.com/gui/file/6350d1039742b87b7917a5e26de2c25c)|Win32 EXE||2013-06-29 17:46:36|vt-upload-A5DfF|
|[973b5f2a5608d243e7305ee4f9249302](https://www.virustotal.com/gui/file/973b5f2a5608d243e7305ee4f9249302)|Win32 EXE||2013-06-12 09:25:30|sara.scr.exe|
|[9ef9a631160b96322010a5238defc673](https://www.virustotal.com/gui/file/9ef9a631160b96322010a5238defc673)|Win32 EXE||2013-06-07 17:12:54|1.exe|
|[46cf06848e4d97fb3caa47c17cdd7a9e](https://www.virustotal.com/gui/file/46cf06848e4d97fb3caa47c17cdd7a9e)|Win32 EXE|dapato|2013-05-20 17:54:41|Kaspersky Password Manager|
|[1b26203d329a6663dfcb286bc4702c77](https://www.virustotal.com/gui/file/1b26203d329a6663dfcb286bc4702c77)|Win32 EXE|strictor|2013-04-21 18:55:20|program|
|[ed53831468ddf4220e1dc3c3398f7f39](https://www.virustotal.com/gui/file/ed53831468ddf4220e1dc3c3398f7f39)|Win32 EXE|Xtreme|2013-04-21 15:27:25|WinWord|
|[963bfae19b3da5bece081dff1d1e3ef9](https://www.virustotal.com/gui/file/963bfae19b3da5bece081dff1d1e3ef9)|Win32 EXE|krypt|2013-04-09 02:06:31|Firefox|
|[0dc102cfb87c937eeffe01a06f94e229](https://www.virustotal.com/gui/file/0dc102cfb87c937eeffe01a06f94e229)|Win32 EXE|graftor|2013-03-31 02:19:45|VirusShare_0dc102cfb87c937eeffe01a06f94e229|
|[41454b390b73a45004b916b96c693312](https://www.virustotal.com/gui/file/41454b390b73a45004b916b96c693312)|Win32 EXE|Xtreme|2013-03-25 15:09:27|Kaspersky Password Manager|
|[4dc0bcdcfb3f3d794175b21872a76079](https://www.virustotal.com/gui/file/4dc0bcdcfb3f3d794175b21872a76079)|Win32 EXE||2013-03-09 11:49:09|trigger|
|[a1187de4c4b88e560d46940b820a6228](https://www.virustotal.com/gui/file/a1187de4c4b88e560d46940b820a6228)|Win32 EXE|MSILPerseus|2013-02-20 09:37:22|WinRAR|
|[c03b5985f2504939da9874246a439e25](https://www.virustotal.com/gui/file/c03b5985f2504939da9874246a439e25)|Win32 EXE|Xtreme|2013-01-24 19:10:59|WinRAR|
|[d9d1b0c467fa4999def6cd53447f1221](https://www.virustotal.com/gui/file/d9d1b0c467fa4999def6cd53447f1221)|Win32 EXE|Xtreme|2013-01-18 20:13:55|WinWord|
|[9d144a828f757a90b86976ef0c906b3f](https://www.virustotal.com/gui/file/9d144a828f757a90b86976ef0c906b3f)|Win32 EXE||2013-01-10 12:16:30|WinWord|
|[c8202523f35295e8bc8cc1731edb0559](https://www.virustotal.com/gui/file/c8202523f35295e8bc8cc1731edb0559)|Win32 EXE|razy|2012-12-09 06:16:48|c8202523f35295e8bc8cc1731edb0559|
|[dbe2ac744a3947b6306e13ebccb718bf](https://www.virustotal.com/gui/file/dbe2ac744a3947b6306e13ebccb718bf)|Win32 EXE||2012-11-15 21:15:07|WinRAR|
|[91fc9d1b635fdee4e56aec32688a0e6c](https://www.virustotal.com/gui/file/91fc9d1b635fdee4e56aec32688a0e6c)|Win32 EXE|Malex|2012-11-15 17:59:13|Kaspersky Password Manager|
|[c1ec435e97a4a4c5585392d738b5879f](https://www.virustotal.com/gui/file/c1ec435e97a4a4c5585392d738b5879f)|Win32 EXE||2012-11-15 16:26:30|NE|
|[72fd6074915f8f123eb44b3dd475d36b](https://www.virustotal.com/gui/file/72fd6074915f8f123eb44b3dd475d36b)|Win32 EXE|Quasar|2012-10-31 20:19:56|WinWord|
|[2bfe41d7fdb6f4c1e38db4a5c3eb1211](https://www.virustotal.com/gui/file/2bfe41d7fdb6f4c1e38db4a5c3eb1211)|Win32 EXE|graftor|2012-10-25 16:31:08|WinWord|
|[2bcdc5091c446e8b6888d802a3589e09](https://www.virustotal.com/gui/file/2bcdc5091c446e8b6888d802a3589e09)|Win32 EXE|graftor|2012-10-25 08:40:59|WinWord|
|[861c90536b3b5a4a8309adbbfd5c4713](https://www.virustotal.com/gui/file/861c90536b3b5a4a8309adbbfd5c4713)|Win32 EXE|kazy|2012-10-22 13:59:54|WinRAR|
|[f68f85b0fbca450f0d5c8828063ad30d](https://www.virustotal.com/gui/file/f68f85b0fbca450f0d5c8828063ad30d)|Win32 EXE|dapato|2012-10-07 01:54:46|Bk1TJvc4d|
|[3da8c22f5340850ee5a2c25b1d17fc27](https://www.virustotal.com/gui/file/3da8c22f5340850ee5a2c25b1d17fc27)|Win32 EXE|kazy|2012-10-03 07:17:01|WinRAR|
|[9c39d6f52e1e1be5ae61bab90971d054](https://www.virustotal.com/gui/file/9c39d6f52e1e1be5ae61bab90971d054)|Win32 EXE|Xtreme|2012-09-27 08:25:20|WinRAR|
|[86be5f0d2303fb4a8a8e297a53ac0026](https://www.virustotal.com/gui/file/86be5f0d2303fb4a8a8e297a53ac0026)|Win32 EXE|Xtreme|2012-09-20 01:14:42|WinRAR|
|[216689b2ca82f16a0cab3a2712c27da6](https://www.virustotal.com/gui/file/216689b2ca82f16a0cab3a2712c27da6)|Win32 EXE|Xtreme|2012-09-14 14:11:25|WinRAR|
|[5b740b4623b2d1049c0036a6aae684b0](https://www.virustotal.com/gui/file/5b740b4623b2d1049c0036a6aae684b0)|Win32 EXE|razy|2012-09-14 13:06:24|WinRAR|
|[b6c8a6d6c35428779c5c65c1b273eba0](https://www.virustotal.com/gui/file/b6c8a6d6c35428779c5c65c1b273eba0)|Win32 EXE||2012-09-04 11:00:07|win32x.exe|
|[66ddf27517985a75b2317231b46a6f62](https://www.virustotal.com/gui/file/66ddf27517985a75b2317231b46a6f62)|Win32 EXE|kazy|2012-08-02 00:10:13|vti-rescan|
|[cebc8b51d51e442e2af8c86e70c8adf4](https://www.virustotal.com/gui/file/cebc8b51d51e442e2af8c86e70c8adf4)|Win32 EXE||2012-07-30 18:06:02|Bk1TJvc4d|
|[15fc009d9caaa8f11d6c3da2b69ea06e](https://www.virustotal.com/gui/file/15fc009d9caaa8f11d6c3da2b69ea06e)|Win32 EXE|Symmi|2012-06-30 07:34:30|b70e1f1746ad00181c386efcdfd36a817e328b47d513d0960a9f3ecd515d10d1.vir|
|[0a67f9cc30083afb7e1f8295ae152bb6](https://www.virustotal.com/gui/file/0a67f9cc30083afb7e1f8295ae152bb6)|Win32 EXE|Xtreme|2012-06-25 10:15:10|Microsoft Word Update.exe|
|[c21d7165b25caf65d7f92ff758c1b5b1](https://www.virustotal.com/gui/file/c21d7165b25caf65d7f92ff758c1b5b1)|Win32 EXE||2012-06-25 06:16:49|WinWord|
|[ebc9bdf9fdf0a9773899d96d24ac46f4](https://www.virustotal.com/gui/file/ebc9bdf9fdf0a9773899d96d24ac46f4)|Win32 EXE|injector|2012-06-05 16:47:08|882b9fc7a0fc323257f070eeef2480f2684c39cdabd8a07b464e441f2141b8d6.vir|
|[6e416c45a833f959a63785892042595a](https://www.virustotal.com/gui/file/6e416c45a833f959a63785892042595a)|Win32 EXE|Reconyc|2012-06-02 07:49:48|stb|
|[940b3acdf1e26fcccf74a5a0359fb079](https://www.virustotal.com/gui/file/940b3acdf1e26fcccf74a5a0359fb079)|Win32 EXE|zapchast|2012-05-29 06:35:13|948a6379a26fe479eb55268daa13c4851921e77d67ddb38f74bb8860602f94af.vir|
|[4a06d9989a8c3a9967c2011e5baf3010](https://www.virustotal.com/gui/file/4a06d9989a8c3a9967c2011e5baf3010)|Win32 EXE|Xtreme|2012-05-17 21:44:29|32c488d34de5e6f88eb5e97169fae4d12d519e521e277c020b1a41b300badad2.vir|
|[a5de87646ee943cd1f448a67fdbe2817](https://www.virustotal.com/gui/file/a5de87646ee943cd1f448a67fdbe2817)|Win32 EXE|Bublik|2012-03-24 22:36:23|a5de87646ee943cd1f448a67fdbe2817|
|[fc17f3b2e2c7f5f24d35899d95b8c4a6](https://www.virustotal.com/gui/file/fc17f3b2e2c7f5f24d35899d95b8c4a6)|Win32 EXE|Xtreme|2012-01-03 04:21:37|fc17f3b2e2c7f5f24d35899d95b8c4a6.dat|
|[7c5272f3f24acb225270dded72cfc1d4](https://www.virustotal.com/gui/file/7c5272f3f24acb225270dded72cfc1d4)|Win32 EXE||2011-12-31 12:04:35|NE|
|[8aeaa0c81a36449ec9613ca846e196f2](https://www.virustotal.com/gui/file/8aeaa0c81a36449ec9613ca846e196f2)|Win32 EXE||2011-12-30 20:41:47|NE|
|[ff8e19ca8a224cc843bf0f2f74a3274e](https://www.virustotal.com/gui/file/ff8e19ca8a224cc843bf0f2f74a3274e)|Win32 EXE||2011-12-30 19:08:49|NE|
|[e431634699d7e5025ecdf7b51a800620](https://www.virustotal.com/gui/file/e431634699d7e5025ecdf7b51a800620)|Win32 EXE|strictor|2011-12-02 12:06:11|E431634699D7E5025ECDF7B51A800620|
|[b455426811b82cb412952f63d911d2a8](https://www.virustotal.com/gui/file/b455426811b82cb412952f63d911d2a8)|Win32 EXE||2011-12-02 03:39:07|NE|
|[0abf3fa976372cbc8bf33162795e42a8](https://www.virustotal.com/gui/file/0abf3fa976372cbc8bf33162795e42a8)|Win32 EXE||2011-11-30 21:55:36|NE|
|[0aa7b256d2dcc8bd3914f895b134b225](https://www.virustotal.com/gui/file/0aa7b256d2dcc8bd3914f895b134b225)|Win32 EXE|PoisonIvy|2011-11-30 04:20:34|Doggy Style|
|[ec5b360f5ff6251a08a14a2e95c4caa4](https://www.virustotal.com/gui/file/ec5b360f5ff6251a08a14a2e95c4caa4)|Win32 EXE|Delf|2011-11-27 19:05:19|1ca4266f213da0a4cc42a8a9cb935d2e708a18537985a7fdcd767dd808706af2|
|[f982401e46864f640bcaedc200319109](https://www.virustotal.com/gui/file/f982401e46864f640bcaedc200319109)|Win32 EXE|Delf|2011-10-26 09:10:18|f982401e46864f640bcaedc200319109|
|[97576fa7a236679dbe3abe1a4e852026](https://www.virustotal.com/gui/file/97576fa7a236679dbe3abe1a4e852026)|Win32 EXE|Bublik|2011-10-20 17:08:10|Java(TM) Control Panel|
|[0b3b1e2e22c548d8f53c2aa338abd66e](https://www.virustotal.com/gui/file/0b3b1e2e22c548d8f53c2aa338abd66e)|Win32 EXE||2011-10-04 10:03:35|Java(TM) Control Panel|
|[1f1e9958440d773c34415d9eb6334b25](https://www.virustotal.com/gui/file/1f1e9958440d773c34415d9eb6334b25)|Win32 EXE||2011-08-08 11:42:07|1f1e9958440d773c34415d9eb6334b25.exe|
|[5b1495eb00dea8f039aadeeaa7b2a3cd](https://www.virustotal.com/gui/file/5b1495eb00dea8f039aadeeaa7b2a3cd)|DOCX||2020-03-11 14:00:39|C:\Users\<USER>\AppData\Roaming\info.docx|
|[11191e0768311d2ac37a5e970eba5b9b](https://www.virustotal.com/gui/file/11191e0768311d2ac37a5e970eba5b9b)|TXT|Sagent|2020-03-05 10:22:18|Microsoft.vbs.bin|
|[33a6df1f861a71cd6af6317ad64e9dc1](https://www.virustotal.com/gui/file/33a6df1f861a71cd6af6317ad64e9dc1)|Win32 EXE|Bublik|2020-03-03 22:54:07|Process Explorer|
|[a71fc13f7a99e97c91ab96e4ea39852b](https://www.virustotal.com/gui/file/a71fc13f7a99e97c91ab96e4ea39852b)|Win32 EXE|Bublik|2020-03-03 07:24:17|TuneupUI.exe|
|[e2e00f544217c4b0be9c0012080ba3ca](https://www.virustotal.com/gui/file/e2e00f544217c4b0be9c0012080ba3ca)|JPEG||2020-03-02 05:59:17|imgonline-com-ua-dexifPKLQYIHeMAk9.jpg|
|[3ecff195b1b39d4903a5fab6fe4aeb88](https://www.virustotal.com/gui/file/3ecff195b1b39d4903a5fab6fe4aeb88)|DOCX||2020-02-14 21:02:19|daily_report.docx|
|[6be39fcc9ae3160ff178941d6926da31](https://www.virustotal.com/gui/file/6be39fcc9ae3160ff178941d6926da31)|Win32 EXE|Wacatac|2020-02-12 13:19:59|HelpPane.exe|
|[53c6b415bc5a95e793deb83db67f52e2](https://www.virustotal.com/gui/file/53c6b415bc5a95e793deb83db67f52e2)|Win32 EXE|Wacatac|2020-02-12 11:26:03|C:\Users\<USER>\TeamViewer.exe|
|[cbd993b4e9cc3858a1ad3c7b0339f520](https://www.virustotal.com/gui/file/cbd993b4e9cc3858a1ad3c7b0339f520)|Win32 EXE||2020-02-12 11:24:02|Abo Mazen and Coshnir.exe|
|[8d61e3fc68c77fb3dd26713899fa750a](https://www.virustotal.com/gui/file/8d61e3fc68c77fb3dd26713899fa750a)|Win32 EXE|occamy|2020-02-09 10:03:22|HelpPane.exe|
|[f87f65b3e06f2eefb5e8ba2d75f713a6](https://www.virustotal.com/gui/file/f87f65b3e06f2eefb5e8ba2d75f713a6)|Win32 EXE||2020-02-09 10:01:14|لقاء ابو مازن و كوشنير.exe|
|[817861fce29bac3b28f06615b4f1803f](https://www.virustotal.com/gui/file/817861fce29bac3b28f06615b4f1803f)|DOC|o97m|2020-02-02 12:52:19|السيرة الذاتية منال1.doc|
|[a7cf4df8315c62dbebfbfea7553ef749](https://www.virustotal.com/gui/file/a7cf4df8315c62dbebfbfea7553ef749)|Win32 EXE|Strictor|2020-01-29 11:08:26|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[ca8c7395c7d6601644b48687b650cfde](https://www.virustotal.com/gui/file/ca8c7395c7d6601644b48687b650cfde)|PDF||2020-01-22 19:23:04|%TEMP%\congratulations_jan-7.pdf|
|[09cd0da3fb00692e714e251bb3ee6342](https://www.virustotal.com/gui/file/09cd0da3fb00692e714e251bb3ee6342)|Win32 EXE|Delf|2020-01-22 19:22:17|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[4653916d821f58fcf9dde8c2c5e05a0c](https://www.virustotal.com/gui/file/4653916d821f58fcf9dde8c2c5e05a0c)|DOCX||2020-01-22 13:27:23|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\8c0966c9518a7ec5bd1ed969222b2bcf9420295450b7ed2f45972e766d26ded8|
|[a9120dc0a86b53d37762787a3996bf6c](https://www.virustotal.com/gui/file/a9120dc0a86b53d37762787a3996bf6c)|DOTM|o97m|2020-01-22 13:02:18|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\a0ae5cc0659693e4c49d3597d5191923fcfb54040b9b5c8229e4c46b9330c367|
|[9a29edd98bb9cbea56f1ac9e1a7a1599](https://www.virustotal.com/gui/file/9a29edd98bb9cbea56f1ac9e1a7a1599)|Win32 EXE||2020-01-22 12:37:49|dttcodexgigas.0f127ed88cd82db863dc08b3c55b14cd001a7297|
|[e8effd3ad2069ff8ff6344b85fc12dd6](https://www.virustotal.com/gui/file/e8effd3ad2069ff8ff6344b85fc12dd6)|Win32 EXE||2020-01-22 12:29:16|80fb33854bf54ceac731aed91c677d8fb933d1593eb95447b06bd9b80f562ed2.sample|
|[91f83b03651bb4d1c0a40e29fc2c92a1](https://www.virustotal.com/gui/file/91f83b03651bb4d1c0a40e29fc2c92a1)|DOC|Sagent|2020-01-22 08:41:44|b33f22b967a5be0e886d479d47d6c9d35c6639d2ba2e14ffe42e7d2e5b11ad80.doc.bin|
|[ea654d6d107386cc04e942770882d0e0](https://www.virustotal.com/gui/file/ea654d6d107386cc04e942770882d0e0)|RAR|Skeeyah|2020-01-21 21:50:40|%D9%87%D9%86%D9%8A%D8%A9%20%D8%B3%D9%8A%D9%82%D9%8A%D9%85%20%D9%81%D9%8A%20%D8%A7%D9%84%D8%AE%D8%A7%D8%B1%D8%AC%20%D9%88%20%D8%AD%D9%85%D8%A7%D8%B3%20%D8%AA%D8%B5%D8%B9%D8%AF%20%D9%81%D9%8A%20%D8%BA%D8%B2%D8%A9.r23|
|[12518e566e8d0b98d333a775f808aabf](https://www.virustotal.com/gui/file/12518e566e8d0b98d333a775f808aabf)|Win32 EXE||2020-01-21 13:25:04|Installation|
|[6fffd2a1eb7b0a6eb64f52229b958689](https://www.virustotal.com/gui/file/6fffd2a1eb7b0a6eb64f52229b958689)|Win32 EXE|Razy|2020-01-21 13:22:59|REG.exe|
|[6520d32aa6f0df11fe84b99208507a0e](https://www.virustotal.com/gui/file/6520d32aa6f0df11fe84b99208507a0e)|Win32 EXE|Skeeyah|2020-01-21 12:01:13|123.exe|
|[e3094c544b77d07e5b12328082078fc3](https://www.virustotal.com/gui/file/e3094c544b77d07e5b12328082078fc3)|Win32 EXE|Skeeyah|2020-01-20 21:22:17|ENIGMA.EXE|
|[ce8c498f2b8b2074a1d67d09b74fc675](https://www.virustotal.com/gui/file/ce8c498f2b8b2074a1d67d09b74fc675)|RAR||2020-01-20 18:31:18|runawy.rar|
|[d077e2a0c58d0486c793bfe5ea81aaa5](https://www.virustotal.com/gui/file/d077e2a0c58d0486c793bfe5ea81aaa5)|PDF|PhishingSite|2020-01-20 17:12:35|هنية سيقيم في الخارج و حماس تصعد في غزة.pdf|
|[20d21c75b92be3cfcd5f69a3ef1deed2](https://www.virustotal.com/gui/file/20d21c75b92be3cfcd5f69a3ef1deed2)|Win32 EXE||2020-01-20 12:09:44|617132.exe|
|[3296b51479c7540331233f47ed7c38dd](https://www.virustotal.com/gui/file/3296b51479c7540331233f47ed7c38dd)|Win32 EXE|Delf|2020-01-14 09:58:48|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[70ccb054fdcea1bfe1f9dd2466ae03d8](https://www.virustotal.com/gui/file/70ccb054fdcea1bfe1f9dd2466ae03d8)|Win32 EXE|Johnnie|2020-01-06 11:13:20|Wordeditor_exe|
|[db8404ac009f5af82a14eccfa270722c](https://www.virustotal.com/gui/file/db8404ac009f5af82a14eccfa270722c)|Win32 EXE|Graftor|2020-01-06 11:10:51|Wordeditor_exe|
|[9bc9765f2ed702514f7b14bcf23a79c7](https://www.virustotal.com/gui/file/9bc9765f2ed702514f7b14bcf23a79c7)|Win32 EXE|Graftor|2020-01-02 11:59:19|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[1d14681881a40ebf4201e4ff59994b07](https://www.virustotal.com/gui/file/1d14681881a40ebf4201e4ff59994b07)|DOCX||2019-12-21 11:37:36|APA adopted resolution Unlimited support for Palestinian people.docx|
|[90cdf5ab3b741330e5424061c7e4b2e2](https://www.virustotal.com/gui/file/90cdf5ab3b741330e5424061c7e4b2e2)|Win32 EXE|Zbot|2019-12-21 09:07:07|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[2f78dce2158807d279b4d358d2b6de94](https://www.virustotal.com/gui/file/2f78dce2158807d279b4d358d2b6de94)|Win32 EXE||2019-12-21 09:03:21|اعلان مرتقب لصفقة القرن و ابو مازن يوافق بشرط واحد.exe|
|[9bb70dfa2e39be46278fb19764a6149a](https://www.virustotal.com/gui/file/9bb70dfa2e39be46278fb19764a6149a)|Win32 EXE|Zbot|2019-12-16 21:05:24|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[072ddcf7e38ac538f1a410c6e29339bb](https://www.virustotal.com/gui/file/072ddcf7e38ac538f1a410c6e29339bb)|Win32 EXE||2019-12-12 21:23:59|VeraCrypt|
|[f2e5a5be1e2969190830061c361d462b](https://www.virustotal.com/gui/file/f2e5a5be1e2969190830061c361d462b)|RAR||2019-12-12 16:22:02|c39e3adb6e15b9964bf0f9702b632086951b4ed9f9fb9cadd6975962a031a398.bin|
|[879a3533c0ae0e28c8bbf99a6e41f5e6](https://www.virustotal.com/gui/file/879a3533c0ae0e28c8bbf99a6e41f5e6)|ZIP||2019-12-12 10:20:45|255a29f88150285a9553f67a6475dc50fcbb5fc737a0178cc0e737d49c8d1b20.bin|
|[4d9b6b0e7670dd5919b188cb71d478c0](https://www.virustotal.com/gui/file/4d9b6b0e7670dd5919b188cb71d478c0)|Win32 EXE||2019-12-11 19:25:41|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[d5fbba51a80f866961bc5d06b64e33db](https://www.virustotal.com/gui/file/d5fbba51a80f866961bc5d06b64e33db)|Win32 EXE|Skeeyah|2019-12-11 10:58:54|1fedd4c7b2dbe95533a276405d2250cca0d638e74560593957a25b456a12ef23.sample|
|[faa9beb6037ab10ca4ddeeb50ce9bb35](https://www.virustotal.com/gui/file/faa9beb6037ab10ca4ddeeb50ce9bb35)|Win32 EXE|Skeeyah|2019-12-10 15:15:26|reisen.exe|
|[18d9d61bcffa8cd137aabd4c877a0e68](https://www.virustotal.com/gui/file/18d9d61bcffa8cd137aabd4c877a0e68)|PDF||2019-12-09 22:27:08|%TEMP%\directory of government services.pdf|
|[bf7e04810f840a899387f1228fa9e404](https://www.virustotal.com/gui/file/bf7e04810f840a899387f1228fa9e404)|PDF||2019-12-09 22:26:21|9d6ce7c585609b8b23703617ef9d480c1cfe0f3bf6f57e178773823b8bf86495.bin|
|[edc3b146a5103051b39967246823ca09](https://www.virustotal.com/gui/file/edc3b146a5103051b39967246823ca09)|Win32 EXE|Graftor|2019-12-09 22:25:47|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[4d1a5d9be9ef74a4548f692d1944841f](https://www.virustotal.com/gui/file/4d1a5d9be9ef74a4548f692d1944841f)|Win32 EXE|Skeeyah|2019-12-09 11:39:36|ENIGMA.EXE|
|[97a0696b3e6be9d5a72d6a8ea8ad6492](https://www.virustotal.com/gui/file/97a0696b3e6be9d5a72d6a8ea8ad6492)|Win32 EXE||2019-12-09 11:34:58|محضر اجتماع قيادةالاجهزة الامنية في غزة من اجل افشال  انطلاقة فتح.exe|
|[c7d7ee62e093c84b51d595f4dc56eab1](https://www.virustotal.com/gui/file/c7d7ee62e093c84b51d595f4dc56eab1)|Win32 EXE||2019-12-08 12:07:21|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[e4bfa116cb8d1c4949b2c1b82c343963](https://www.virustotal.com/gui/file/e4bfa116cb8d1c4949b2c1b82c343963)|Win32 EXE||2019-11-28 10:51:49|imecfmui.exe|
|[12e2a99bcb4e4dba99043c6c048f1121](https://www.virustotal.com/gui/file/12e2a99bcb4e4dba99043c6c048f1121)|DOTM|Sagent|2019-11-25 02:29:37|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\71ea0ba573451b14bb411ad28e5aac883f8af0376db8c9d34f309778c901c5d6|
|[5acdcad5aec8f1f548acc6cc4da8059d](https://www.virustotal.com/gui/file/5acdcad5aec8f1f548acc6cc4da8059d)|Win32 EXE||2019-11-24 14:17:45|pAmRONJVlifBLOs8.bin|
|[4ae4e0f8747a27f41e444fbc047f0191](https://www.virustotal.com/gui/file/4ae4e0f8747a27f41e444fbc047f0191)|DOCX|Sagent|2019-11-24 11:05:57|strike0eFapB.date|
|[3ad34c3f7c36534ba364eb725114e90a](https://www.virustotal.com/gui/file/3ad34c3f7c36534ba364eb725114e90a)|Win32 EXE|Disfa|2019-11-19 10:22:30|C:\users\public\pdf.exe|
|[c13fccda7c3e78f9c0b181d4e46e07c1](https://www.virustotal.com/gui/file/c13fccda7c3e78f9c0b181d4e46e07c1)|Win32 EXE||2019-11-18 05:47:51|c13fccda7c3e78f9c0b181d4e46e07c1.virus|
|[e914fb1ba62bf92ab3aba6114a4cc75a](https://www.virustotal.com/gui/file/e914fb1ba62bf92ab3aba6114a4cc75a)|RAR||2019-11-16 10:54:38|Details Ceasefire with Israel.xz|
|[fa691513ea80257b098202418d148cd8](https://www.virustotal.com/gui/file/fa691513ea80257b098202418d148cd8)|ZIP||2019-11-15 15:34:33|Details%20Ceasefire%20with%20Israel.zip|
|[6527680490e0c8eb248f7c3197e3af7d](https://www.virustotal.com/gui/file/6527680490e0c8eb248f7c3197e3af7d)|Win32 EXE||2019-10-23 02:46:12|\Users\Petra\paint.exe|
|[42583cd85ce3d605e27a8cbaff518cb6](https://www.virustotal.com/gui/file/42583cd85ce3d605e27a8cbaff518cb6)|Win32 EXE||2019-10-22 17:58:28|تعميم داخلي بخصوص الانتخابات.exe|
|[b6086041d08f45b381218e3b6ba56412](https://www.virustotal.com/gui/file/b6086041d08f45b381218e3b6ba56412)|DOCM|Sagent|2019-10-13 09:46:43|feec28c7c19a8d0ebdca8fcfc0415ae79ef08362bd72304a99eeea55c8871e21.bin|
|[ea417866aa8986a05a070662e95cdfaa](https://www.virustotal.com/gui/file/ea417866aa8986a05a070662e95cdfaa)|RAR|Banload|2019-10-13 00:37:36|243f1301d1d759c17cd49336512ebceb9d347995c90a6e00aff926439d63f12d.bin|
|[0eb66bc4af9e3923dba806a48a454f1e](https://www.virustotal.com/gui/file/0eb66bc4af9e3923dba806a48a454f1e)|Win32 EXE|Minerd|2019-10-12 09:02:57|PDFViewer.exe|
|[2aee67749a7ab1aecc6b201c2fccc1df](https://www.virustotal.com/gui/file/2aee67749a7ab1aecc6b201c2fccc1df)|FPX||2019-10-06 14:17:28|03be1d7e1071b018d3fbc6496788fd7234b0bb6d3614bec5b482f3bf95aeb506.bin|
|[9b9136d65d0fdde391eae66826fbd3e9](https://www.virustotal.com/gui/file/9b9136d65d0fdde391eae66826fbd3e9)|FPX|Sagent|2019-09-16 16:43:27|4f51b180a6d0b074778d055580788dc33c9e1fd2e49f3c9a19793245a8671cba.bin|
|[b76f5f87364fa71559ffc14573420da4](https://www.virustotal.com/gui/file/b76f5f87364fa71559ffc14573420da4)|TXT||2019-09-15 12:37:38|9451a110f75cbc3b66af5acb11a07a8d5e20e15e5487292722e695678272bca7.bin|
|[db51f2715c81c4357d11d69ac96bf582](https://www.virustotal.com/gui/file/db51f2715c81c4357d11d69ac96bf582)|DOCM|Banload|2019-09-15 09:56:33|bf126c2c8f7d4263c78f4b97857912a3c1e87c73fee3f18095d58ef5053f2959.bin|
|[ae714ab6314d677fb78fa2deb682d5c4](https://www.virustotal.com/gui/file/ae714ab6314d677fb78fa2deb682d5c4)|Win32 EXE|Graftor|2019-08-21 08:56:41|QuickAssist.exe|
|[774bbc1483accf3c961f9fec9656184d](https://www.virustotal.com/gui/file/774bbc1483accf3c961f9fec9656184d)|Win32 EXE||2019-08-21 08:56:25|1d8c54c9af1b05b9679f1c67850a7e2eb6db95343a44d9aa882896c6d4f9c490.bin|
|[aa14bb7cc0e0474fe083e87fe881475c](https://www.virustotal.com/gui/file/aa14bb7cc0e0474fe083e87fe881475c)|Win32 EXE||2019-08-15 16:45:28|aa14bb7cc0e0474fe083e87fe881475c.virus|
|[4e6dc692951ae7cdb3cd2f26d1956ba1](https://www.virustotal.com/gui/file/4e6dc692951ae7cdb3cd2f26d1956ba1)|Win32 EXE|Razy|2019-08-13 21:45:08|dxdiag.exe|
|[85421af1931005afc7957e4d67e1ac75](https://www.virustotal.com/gui/file/85421af1931005afc7957e4d67e1ac75)|Win32 EXE||2019-08-06 10:44:49| |
|[a1f46d1569a43e2951a1343767987bb7](https://www.virustotal.com/gui/file/a1f46d1569a43e2951a1343767987bb7)|Win32 EXE|Bublik|2018-12-10 19:21:03|a1f46d1569a43e2951a1343767987bb7.virus|
|[67f4d13d4c2ee48bcf7eab534e0d6809](https://www.virustotal.com/gui/file/67f4d13d4c2ee48bcf7eab534e0d6809)|Win32 EXE|Bublik|2018-12-10 19:21:01|67f4d13d4c2ee48bcf7eab534e0d6809.virus|
|[2b0050e7488358835fbb8a88593e0299](https://www.virustotal.com/gui/file/2b0050e7488358835fbb8a88593e0299)|Win32 EXE|Bublik|2018-12-10 19:21:00|2b0050e7488358835fbb8a88593e0299.virus|
|[1f3bb8d3b851c464ce28cb88573091d4](https://www.virustotal.com/gui/file/1f3bb8d3b851c464ce28cb88573091d4)|Win32 EXE|Bublik|2018-12-10 19:20:59|1f3bb8d3b851c464ce28cb88573091d4.virus|
|[1acdb69ea6421f3c5ebec123af1c161e](https://www.virustotal.com/gui/file/1acdb69ea6421f3c5ebec123af1c161e)|Win32 EXE|Bublik|2018-12-10 19:20:58|1acdb69ea6421f3c5ebec123af1c161e.virus|
|[04258329908f95c84adfe0d8f130a345](https://www.virustotal.com/gui/file/04258329908f95c84adfe0d8f130a345)|Win32 EXE|Bublik|2018-12-10 19:20:56|04258329908f95c84adfe0d8f130a345.virus|
|[d35be65d011bcad42a9bdca3276449ed](https://www.virustotal.com/gui/file/d35be65d011bcad42a9bdca3276449ed)|Win32 EXE|Bublik|2018-12-10 19:20:54|d35be65d011bcad42a9bdca3276449ed.virus|
|[b63c345496d057b516fc17f0fbe7eb49](https://www.virustotal.com/gui/file/b63c345496d057b516fc17f0fbe7eb49)|Win32 EXE|Bublik|2018-12-10 19:20:53|b63c345496d057b516fc17f0fbe7eb49.virus|
|[545aa3df3cdc890fbf78d656f792e042](https://www.virustotal.com/gui/file/545aa3df3cdc890fbf78d656f792e042)|Win32 EXE|Bublik|2018-12-10 19:20:52|545aa3df3cdc890fbf78d656f792e042.virus|
|[14dbe8f57efe1fe58d30294943a6b5ff](https://www.virustotal.com/gui/file/14dbe8f57efe1fe58d30294943a6b5ff)|Win32 EXE||2018-11-11 12:59:21|14dbe8f57efe1fe58d30294943a6b5ff.vir|
|[7d71b7a1448fe1931e10bd48eeda792d](https://www.virustotal.com/gui/file/7d71b7a1448fe1931e10bd48eeda792d)|Win32 EXE|Bublik|2018-09-10 11:17:13|Vedio Player|
|[cfc14fe4875d4432b7c3d9eb5bab97f4](https://www.virustotal.com/gui/file/cfc14fe4875d4432b7c3d9eb5bab97f4)|Win32 EXE|Bublik|2018-09-10 11:15:05|Video Player|
|[3374e05565e7d6b09e254670e5d5a2b5](https://www.virustotal.com/gui/file/3374e05565e7d6b09e254670e5d5a2b5)|RAR|Bublik|2018-09-10 08:51:21|19ede61c865a3cdd59d3a5d1a79b7ce83ca7828a6b80a2f968d82b5b56a8603c.bin|
|[a6a852facf823225eddfa5e11ce1e066](https://www.virustotal.com/gui/file/a6a852facf823225eddfa5e11ce1e066)|Win32 EXE|Bublik|2018-07-30 10:23:16|3a32c81ec609a5466f050c09156f25b5561c691763f865ee437e95a246dcbbe1.bin|
|[ee3d6287d470eda1053fb41aea1e52d7](https://www.virustotal.com/gui/file/ee3d6287d470eda1053fb41aea1e52d7)|Win32 EXE|Bublik|2018-07-30 10:20:05|EE3D6287D470EDA1053FB41AEA1E52D7.EXE|
|[2926e4f68450976b5c9a1646af39003f](https://www.virustotal.com/gui/file/2926e4f68450976b5c9a1646af39003f)|RAR|Bublik|2018-07-30 10:08:50|9a3ec0a8b2a88106fc537d9cae1989f6fba36bb43352a944d2031e7b2ab7673c.bin|
|[f55e3c74f61311543b622caf7b279586](https://www.virustotal.com/gui/file/f55e3c74f61311543b622caf7b279586)|Win32 EXE|Bublik|2018-07-25 01:53:54|%HOMEPATH%\start menu\programs\startup\svchost.exe|
|[a4f89f64c7dc50ed59b4569480a3202f](https://www.virustotal.com/gui/file/a4f89f64c7dc50ed59b4569480a3202f)|Win32 EXE|Bublik|2018-07-24 13:18:59|UAE secret Leaks  between mohammed dahalan and hamad almazrouei.exe|
|[99e3ead5525742faeec94fd477b97ba6](https://www.virustotal.com/gui/file/99e3ead5525742faeec94fd477b97ba6)|RAR|Bublik|2018-07-24 12:32:01|89d7337ac102cd80316ad59a1dcfcc5c7849d0e7520f0f85e1781574423e38ea.bin|
|[044c6626c9a392fb9807397aeca3ecc3](https://www.virustotal.com/gui/file/044c6626c9a392fb9807397aeca3ecc3)|Win32 EXE|Bublik|2018-07-23 02:01:52|044c6626c9a392fb9807397aeca3ecc3.vir|
|[922fd46d5fc0b4b62b4bd4f645de1b69](https://www.virustotal.com/gui/file/922fd46d5fc0b4b62b4bd4f645de1b69)|Win32 EXE|Bublik|2018-04-12 05:53:09|WinRAR|
|[2f42789c856be57848b7e5bd062257c2](https://www.virustotal.com/gui/file/2f42789c856be57848b7e5bd062257c2)|Win32 EXE|Bublik|2018-04-03 16:21:03|RtlUpd|
|[f8f4d1a38c8a4de0a20c04ae57966342](https://www.virustotal.com/gui/file/f8f4d1a38c8a4de0a20c04ae57966342)|Win32 EXE|Bublik|2018-04-02 11:23:41|bindtest.exe|
|[b506449803bcbc79a77d5ec7a15dfae1](https://www.virustotal.com/gui/file/b506449803bcbc79a77d5ec7a15dfae1)|Win32 EXE|Bublik|2018-03-22 11:05:01|WinRAR|
|[03ad1477e35bab3a2ddd0863d3eb28d5](https://www.virustotal.com/gui/file/03ad1477e35bab3a2ddd0863d3eb28d5)|Win32 EXE|Bublik|2018-02-26 19:01:17|78696cf4370817cb0ffd6930a92553d3551fe77cdc6d45638ddd13f05b9218b8.bin|
|[bee397bd554e1db00e07a106aeb6d6ff](https://www.virustotal.com/gui/file/bee397bd554e1db00e07a106aeb6d6ff)|Win32 EXE|Bublik|2018-02-24 05:16:31|5109f2c8f014698f1d2f0d59a7c9cc1cd9400a6fe4dcde95cc475f453e74bc6e.bin|
|[3c2bc6af0f3b8c288d0140b62a2abaaf](https://www.virustotal.com/gui/file/3c2bc6af0f3b8c288d0140b62a2abaaf)|RAR|Bublik|2018-02-21 08:08:17|______ 21-02-2018.zip";filename*=UTF-8''%D8%A7%D9%84%D8%AE%D8%B7%D8%A7%D8%A8%2021-02-2018.zip|
|[a1c59445c8a8474c25454fb541b3c004](https://www.virustotal.com/gui/file/a1c59445c8a8474c25454fb541b3c004)|Win32 EXE|Bublik|2018-02-05 13:49:22|=?UTF-8?B?2KrYudmF2YrZhSDZh9in2YUg2KjYrti12YjYtSDYqtio2KfYr9mEINin2YTZhdmE2YHYp9iqINmI2KfZhNmF2YjYp9mC2Lkg2KfZhNmF2LnYqtmF2K/YqSDZhNmE2YTYqtio2KfYr9mELmV4ZQ==?=|
|[3cf3874498bdf2c5046a59464fbd4831](https://www.virustotal.com/gui/file/3cf3874498bdf2c5046a59464fbd4831)|Win32 EXE|Bublik|2018-01-22 12:55:41|vlc|
|[6bb72079a68b09e7051d751dbf0f584b](https://www.virustotal.com/gui/file/6bb72079a68b09e7051d751dbf0f584b)|Win32 EXE|Bublik|2018-01-22 12:51:03|399344aa609f17e558356709a398b4478e5c737c7cc843e3d111d33192c35e5a.bin|
|[096e7811312a218e12c7931c2d1f51c0](https://www.virustotal.com/gui/file/096e7811312a218e12c7931c2d1f51c0)|Win32 EXE|Bublik|2017-11-26 09:12:32|iTunes|
|[e3e4b8ffc5c666166da9a6549b9ae54d](https://www.virustotal.com/gui/file/e3e4b8ffc5c666166da9a6549b9ae54d)|Win32 EXE|Bublik|2017-11-14 10:47:50|HelpPane.exe|
|[f2ac4c2c3e6a5054b3041b6ed3f9e3f3](https://www.virustotal.com/gui/file/f2ac4c2c3e6a5054b3041b6ed3f9e3f3)|Win32 EXE|Bublik|2017-11-14 10:47:28|51c1e6ce3ff1f42734bfa19a7142b5154172232afc5528dad4c527df3a44c0c1.bin|
|[9350924e72bc1260a231db7e1ce931df](https://www.virustotal.com/gui/file/9350924e72bc1260a231db7e1ce931df)|Win32 EXE|Bublik|2017-11-09 09:07:24|TCPView|
|[9d0d80c9e91adcf47fdaf12d59d95a76](https://www.virustotal.com/gui/file/9d0d80c9e91adcf47fdaf12d59d95a76)|Win32 EXE|Bublik|2017-11-09 09:06:59|bindtest.exe|
|[27cc457a71d722436655a7123a4a27d1](https://www.virustotal.com/gui/file/27cc457a71d722436655a7123a4a27d1)|Win32 EXE|Bublik|2017-10-17 07:03:34|e6e5593cbac23ec5c51e5f63c4c6616a8eb71697a89f9d1d17cc7be91c36e3e9.bin|
|[a1ebf3676cc7ba2ba2398e9e282a61b1](https://www.virustotal.com/gui/file/a1ebf3676cc7ba2ba2398e9e282a61b1)|Win32 EXE||2017-08-10 10:43:28|%TEMP%\aut473c.tmp|
|[8a0fc69a0138865bd6b8d6aa60babbeb](https://www.virustotal.com/gui/file/8a0fc69a0138865bd6b8d6aa60babbeb)|Win32 EXE|Skeeyah|2017-08-10 09:55:27|localfile~|
|[b7c0d1eeb32d24dd8df6106ed0225a90](https://www.virustotal.com/gui/file/b7c0d1eeb32d24dd8df6106ed0225a90)|Win32 EXE||2017-07-20 19:44:03|212aa6e3f236550bb4b9328071ee4f0e8a74465c75dcf1e6cde8502afde91364.bin|
|[763c02e8386d7b53bdf8531e70c88b89](https://www.virustotal.com/gui/file/763c02e8386d7b53bdf8531e70c88b89)|Win32 EXE||2016-05-25 06:23:50|chrome_exe|
|[01dc06e8c987825776a43f1f7ef5e41a](https://www.virustotal.com/gui/file/01dc06e8c987825776a43f1f7ef5e41a)|Win32 EXE|Razy|2016-03-01 12:28:57|OfficeCenter.exe|
|[8f646adc6318eb037fc3a1a926f903dc](https://www.virustotal.com/gui/file/8f646adc6318eb037fc3a1a926f903dc)|Win32 EXE||2016-01-06 11:11:32|e3779f6252ca606ace9ae06623ba086d1a441582b625e433799260d71cdb1b4b.bin|
|[8c80d850100753f82d21f0a1d2abff93](https://www.virustotal.com/gui/file/8c80d850100753f82d21f0a1d2abff93)|Win32 EXE|Razy|2015-12-10 12:15:10|bindtest.exe|
