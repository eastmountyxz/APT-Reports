**NAME:**  
Molerats  
  
**Alias**  
Gaza Hackers Team, Gaza cybergang, Operation Molerats, Extreme Jackal, Moonlight, Hamas, Gaza, Molerats  

**Description**:   
Molerats, also known as Gaza Cybergang, is a politically-motivated threat group that has been operating since 2012. The group's victims are primarily in the Middle East, Europe, and the United States. In mid-2017, related attacks are discovered inside an oil and gas organization in the MENA region, infiltrating systems and pilfering data, apparently for more than a year. Clearsky pointed out the attack group may link to Hamas in a public report.

**References**:   
https://www.clearskysec.com/wp-content/uploads/2016/01/Operation%20DustySky_TLP_WHITE.pdf  
https://www.clearskysec.com/wp-content/uploads/2016/06/Operation-DustySky2_-6.2016_TLP_White.pdf  
https://www.fireeye.com/blog/threat-research/2013/08/operation-molerats-middle-east-cyber-attacks-using-poison-ivy.html  
http://blog.vectranetworks.com/blog/moonlight-middle-east-targeted-attacks  
https://securelist.com/gaza-cybergang-group1-operation-sneakypastes/90068/  