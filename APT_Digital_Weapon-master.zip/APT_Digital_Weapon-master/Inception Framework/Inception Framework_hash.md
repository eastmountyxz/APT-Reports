|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[a9220b25961f5151b9df0eb1cceab94b](https://www.virustotal.com/gui/file/a9220b25961f5151b9df0eb1cceab94b)|unknown||2018-11-06 15:05:27|payload_unmodified.dat|
|[a9220ec80024b1900f3234a9c5823896](https://www.virustotal.com/gui/file/a9220ec80024b1900f3234a9c5823896)|DOCX|o97m|2018-10-25 11:14:39|609422-1571147514.docx|
|[ae8fbf3984a876d7b4fb82ba84768a99](https://www.virustotal.com/gui/file/ae8fbf3984a876d7b4fb82ba84768a99)|RTF||2018-10-10 12:51:12|1.rtf|
|[f411d5bdadfe7ccd406d6777d94616ca](https://www.virustotal.com/gui/file/f411d5bdadfe7ccd406d6777d94616ca)|DOCX|o97m|2018-08-13 06:37:01|=?UTF-8?B?0KHQsNC90LrRhtC40LguZG9j?=|
|[ff07f9f5373855f1c48c1f9a48fe6d52](https://www.virustotal.com/gui/file/ff07f9f5373855f1c48c1f9a48fe6d52)|DOCX|o97m|2018-07-20 09:08:57|=?UTF-8?B?0J/QvtCy0LXRgdGC0LrQsC5kb2M=?=|
