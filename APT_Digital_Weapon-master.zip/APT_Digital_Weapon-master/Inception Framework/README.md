**NAME:**  
Inception Framework  
  
**Alias**  
Cloud Atlas, Inception Framework  

**Description**:   
Inception Framework is an attack framework discovered by Symantec. Targets include individuals in strategic positions: Executives in important businesses such as oil, finance and engineering, military officers, embassy personnel and government officials. 
The Inception attacks began by focusing on targets primarily located in Russia or related to Russian interests, but have since spread to targets in other locations around the world.

**References**:  
https://www.symantec.com/blogs/threat-intelligence/inception-framework-hiding-behind-proxies