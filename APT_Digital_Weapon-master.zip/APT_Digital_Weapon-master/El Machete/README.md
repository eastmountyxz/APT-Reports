**NAME:**  
El Machete  
  
**Alias**  
Machete, El Machete  

**Description**:   
Machete is a targeted attack campaign with Spanish speaking roots. It started in 2010 and was renewed with an improved infrastructure in 2012.
Most of the victims are located in Venezuela, Ecuador, Colombia, Peru, Russia, Cuba, and Spain. The targets include high-level profiles, including intelligence services, military, embassies and government institutions. In some cases, such as Russia, the target appears to be an embassy from one of the countries of this list.

**References**:  
https://securelist.com/blog/research/66108/el-machete/  
https://www.cylance.com/en_us/blog/el-machete-malware-attacks-cut-through-latam.html
