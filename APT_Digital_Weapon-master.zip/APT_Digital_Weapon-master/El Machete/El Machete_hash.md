|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[a23d27688c57fb8d1b4979c4643c7dbc](https://www.virustotal.com/gui/file/a23d27688c57fb8d1b4979c4643c7dbc)|Win32 EXE||2019-07-07 13:51:53|Down.exe|
|[9eb9af0f63644fee49d083c1c330226b](https://www.virustotal.com/gui/file/9eb9af0f63644fee49d083c1c330226b)|Win32 EXE||2019-07-04 17:24:27|RAD OFL0120_jpg.scr|
|[8d92e51008d4ec7530bb16b3caa63fbb](https://www.virustotal.com/gui/file/8d92e51008d4ec7530bb16b3caa63fbb)|Win32 EXE||2019-07-04 17:16:50|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\chrome_Up.sfx.exe|
|[ca0bdef2b365c70733aa61ad2224475b](https://www.virustotal.com/gui/file/ca0bdef2b365c70733aa61ad2224475b)|Win32 EXE||2019-07-04 03:23:29|7ZSfxMod|
|[04fa52b44178bec611232d260ec18c03](https://www.virustotal.com/gui/file/04fa52b44178bec611232d260ec18c03)|Win32 EXE||2019-06-23 04:42:35|7ZSfxMod|
|[ec9e0092505743e000bd95c3e4677aff](https://www.virustotal.com/gui/file/ec9e0092505743e000bd95c3e4677aff)|Win32 EXE||2019-06-23 01:04:06|7ZSfxMod|
|[19b049ab19fd3e8c6f5b36c6a41024fe](https://www.virustotal.com/gui/file/19b049ab19fd3e8c6f5b36c6a41024fe)|Win32 EXE||2019-06-07 18:36:04|7ZSfxMod|
|[69e8e8258fbda29a140fb820c93afbcc](https://www.virustotal.com/gui/file/69e8e8258fbda29a140fb820c93afbcc)|Win32 EXE||2019-06-07 15:58:47|chrome.sfx.exe|
|[b2975864ad694469b04165bd09277421](https://www.virustotal.com/gui/file/b2975864ad694469b04165bd09277421)|Win32 EXE||2019-06-07 15:51:59|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\ChrOme_UpdAte.sfx.exe|
|[4da12f54f0b7413d04f6832d26ee4633](https://www.virustotal.com/gui/file/4da12f54f0b7413d04f6832d26ee4633)|Win32 EXE||2019-05-24 01:05:19|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\ChromeUpdate.sfx.exe|
|[2adb5b013ba4de9a20c7c9e185930675](https://www.virustotal.com/gui/file/2adb5b013ba4de9a20c7c9e185930675)|Win32 EXE||2019-05-23 19:42:41| |
|[22b2718408aa6dbbfb05066325838468](https://www.virustotal.com/gui/file/22b2718408aa6dbbfb05066325838468)|Win32 EXE||2019-05-17 15:37:26|7ZSfxMod|
|[84d0eb92a62f095271fd7a22352144d4](https://www.virustotal.com/gui/file/84d0eb92a62f095271fd7a22352144d4)|Win32 EXE||2019-05-17 11:04:28|GoogleUpdate.exe|
|[c8ca25bd428818277968ac3239cfc573](https://www.virustotal.com/gui/file/c8ca25bd428818277968ac3239cfc573)|Win32 EXE||2019-05-17 11:04:25|GoogleCrash.exe|
|[c312d1a4ac706d910c611ad8f600fe68](https://www.virustotal.com/gui/file/c312d1a4ac706d910c611ad8f600fe68)|Win32 EXE||2019-05-17 11:04:14|Chrome.exe|
|[2a0334ad957b03058572f29be768af46](https://www.virustotal.com/gui/file/2a0334ad957b03058572f29be768af46)|Win32 EXE||2019-05-17 03:32:29|Word.exe|
|[a3f35e1ec2a70df31296deef93129904](https://www.virustotal.com/gui/file/a3f35e1ec2a70df31296deef93129904)|Win32 EXE||2019-05-16 23:35:00|Chrome.exe|
|[b9806b73c97d1eab5c4dde19fb20a403](https://www.virustotal.com/gui/file/b9806b73c97d1eab5c4dde19fb20a403)|Win32 EXE||2019-05-16 19:11:22|chrome.sfx.exe|
|[95a9f742768e75c5ac4614ed0645c510](https://www.virustotal.com/gui/file/95a9f742768e75c5ac4614ed0645c510)|Win32 EXE||2019-05-16 18:59:33|7ZSfxMod|
|[f84f600384a857b583fa5d24de290de4](https://www.virustotal.com/gui/file/f84f600384a857b583fa5d24de290de4)|Win32 EXE||2019-05-16 17:34:57|7ZSfxMod|
|[6af41f9e24272a0390d2e0fe243da44d](https://www.virustotal.com/gui/file/6af41f9e24272a0390d2e0fe243da44d)|Win32 EXE||2019-05-16 15:00:46|Javasfx.exe|
|[07092b9d975b59fff37e2ee9a9848461](https://www.virustotal.com/gui/file/07092b9d975b59fff37e2ee9a9848461)|Win32 EXE||2019-05-16 14:51:53|javaO.exe|
|[2ce3bd85af9055a3c6a8236f9d41efff](https://www.virustotal.com/gui/file/2ce3bd85af9055a3c6a8236f9d41efff)|Win32 EXE||2019-05-08 05:15:41|Javasfx.exe|
|[077b07dad085c3411b79e06cb71e197f](https://www.virustotal.com/gui/file/077b07dad085c3411b79e06cb71e197f)|Win32 EXE||2019-05-07 17:47:19|Javasfx.exe|
|[d982b4b5c6d30deb60e395f2e900076d](https://www.virustotal.com/gui/file/d982b4b5c6d30deb60e395f2e900076d)|Win32 EXE||2019-05-04 22:07:39|final.exe|
|[fa8b27a0a73c47492c97e6bc38f2493f](https://www.virustotal.com/gui/file/fa8b27a0a73c47492c97e6bc38f2493f)|Win32 EXE||2019-05-02 21:47:46|JAVA.sfx.exe|
|[d2ecd1ad6c6acf7f1c3ad43bbd5974db](https://www.virustotal.com/gui/file/d2ecd1ad6c6acf7f1c3ad43bbd5974db)|Win32 EXE||2019-04-28 10:51:59|python27.dll.exe|
|[b60a6d58660438f56c23dc5dabdcb6ca](https://www.virustotal.com/gui/file/b60a6d58660438f56c23dc5dabdcb6ca)|Win32 EXE||2019-04-26 11:20:25|Adobe.exe|
|[b13b3efc01637ed591aee0ffbf110d68](https://www.virustotal.com/gui/file/b13b3efc01637ed591aee0ffbf110d68)|Win32 EXE||2019-04-18 16:57:16|p.exe|
|[f8c7dd6f89c6a18f2360ecf675c7e351](https://www.virustotal.com/gui/file/f8c7dd6f89c6a18f2360ecf675c7e351)|Win32 EXE||2019-04-18 16:57:14|18d2730ccf0dad92efe9ff2789af3c36b220e87f691d1cd421faf2c572edb89c.bin|
|[33aac948ba9f11ff8e8fba02127e2c34](https://www.virustotal.com/gui/file/33aac948ba9f11ff8e8fba02127e2c34)|Win32 EXE||2019-02-23 04:37:38|GoogleUpdate.exe|
|[f76ee4d0e496fd22bc87e685653a296b](https://www.virustotal.com/gui/file/f76ee4d0e496fd22bc87e685653a296b)|Win32 EXE||2019-02-23 04:37:34|GoogleCrash.exe|
|[48e6c558a87577281a6b1f37e426f8ed](https://www.virustotal.com/gui/file/48e6c558a87577281a6b1f37e426f8ed)|Win32 EXE||2019-02-23 04:37:27|Chrome.exe|
|[33edc43992137c0d4b07a4c1ed389e1e](https://www.virustotal.com/gui/file/33edc43992137c0d4b07a4c1ed389e1e)|Win32 EXE||2019-02-23 00:34:22|Chrome_Update.sfx.exe|
|[15e50c8efe8f72064d51fc04437bed26](https://www.virustotal.com/gui/file/15e50c8efe8f72064d51fc04437bed26)|Win32 EXE||2019-01-05 14:22:53|GoogleUpdate.exe|
|[396b6502c46b45d9f5efff728fa27055](https://www.virustotal.com/gui/file/396b6502c46b45d9f5efff728fa27055)|Win32 EXE||2019-01-05 14:22:50|Chrome.exe|
|[4bfd79b34234060f9d4dc26bd23c67c9](https://www.virustotal.com/gui/file/4bfd79b34234060f9d4dc26bd23c67c9)|Win32 EXE||2019-01-05 13:43:59|GoogleCrash.exe|
|[fd301450a00094407729b9139c6c544a](https://www.virustotal.com/gui/file/fd301450a00094407729b9139c6c544a)|Win32 EXE||2019-01-03 09:16:25| |
|[be34bf00f72612c3f2f682b3396477b7](https://www.virustotal.com/gui/file/be34bf00f72612c3f2f682b3396477b7)|Win32 EXE||2018-11-19 11:43:00|RAVBg.ext.scr|
|[4d06a98aa9d52177cc141c4ca63aa191](https://www.virustotal.com/gui/file/4d06a98aa9d52177cc141c4ca63aa191)|DOCX||2018-11-19 11:42:46|05_10_2016_INFORME_DE_PRENSA_NACIONAL.docx|
|[48bc4b7f816918168456a7632175f24f](https://www.virustotal.com/gui/file/48bc4b7f816918168456a7632175f24f)|Win32 EXE||2018-10-10 14:41:50|JavaUe.exe|
|[99a60df2c5efac8eb1c1c376758de082](https://www.virustotal.com/gui/file/99a60df2c5efac8eb1c1c376758de082)|Win32 EXE||2018-10-10 14:41:27|Javak.exe|
|[e6e23c76daee5a8ac5ba9122be7c1da1](https://www.virustotal.com/gui/file/e6e23c76daee5a8ac5ba9122be7c1da1)|Win32 EXE||2018-10-03 04:30:35|RAVBg.int.scr|
|[ddba0c2e4ed307a192f0cdb5f167e476](https://www.virustotal.com/gui/file/ddba0c2e4ed307a192f0cdb5f167e476)|DOC||2018-10-03 04:30:20|2016_00109_01.doc|
|[188e4f29b4c952311d2691173ba0d2f4](https://www.virustotal.com/gui/file/188e4f29b4c952311d2691173ba0d2f4)|Win32 EXE||2018-09-28 00:27:21| |
|[a8fdda6440427265471421f60506eec0](https://www.virustotal.com/gui/file/a8fdda6440427265471421f60506eec0)|Win32 EXE||2018-09-26 10:23:47|JavaUe.exe|
|[dafc716f572743a4d53b766496454c11](https://www.virustotal.com/gui/file/dafc716f572743a4d53b766496454c11)|Win32 EXE||2018-09-05 23:19:37| |
|[9bc58a40aa36674fe4a44abfd938a8db](https://www.virustotal.com/gui/file/9bc58a40aa36674fe4a44abfd938a8db)|Win32 EXE||2018-07-19 05:35:25|RdrCEF.exe|
|[7163167a07b2ba31d6064297167cc19f](https://www.virustotal.com/gui/file/7163167a07b2ba31d6064297167cc19f)|Win32 EXE||2018-07-11 06:34:41|7ZSfxMod|
|[de8b61ae73f510eba526684f85b7cacb](https://www.virustotal.com/gui/file/de8b61ae73f510eba526684f85b7cacb)|Win32 EXE||2018-06-16 17:24:37|Down.exe|
|[dd4389198abe57219d74928d6e775f6b](https://www.virustotal.com/gui/file/dd4389198abe57219d74928d6e775f6b)|Win32 EXE||2018-06-15 19:22:01|C:\Users\<USER>\AppData\Local\Temp\7ZipSfx.000\Down.sfx.exe|
|[f06d99d3f32f3b3600767de2f67cab35](https://www.virustotal.com/gui/file/f06d99d3f32f3b3600767de2f67cab35)|Win32 EXE||2018-06-09 01:48:34|Javak.exe|
|[624a23ea378b4422beb4189ac75a478d](https://www.virustotal.com/gui/file/624a23ea378b4422beb4189ac75a478d)|Win32 EXE||2018-06-01 12:32:32|Down.exe|
|[1acc3b68da6b0a800cd58af30d47b01e](https://www.virustotal.com/gui/file/1acc3b68da6b0a800cd58af30d47b01e)|Win32 EXE||2018-05-26 18:52:11|GoogleUpdate.exe|
|[3239f2d8acee4742f9b4d919e61b8983](https://www.virustotal.com/gui/file/3239f2d8acee4742f9b4d919e61b8983)|Win32 EXE||2018-05-26 18:52:06|GoogleCrash.exe|
|[6370323a5960f06b77a61487b75aabe3](https://www.virustotal.com/gui/file/6370323a5960f06b77a61487b75aabe3)|Win32 EXE||2018-05-26 18:52:01|Chrome.exe|
|[5a46d793cf82822cb334b70609a9acd7](https://www.virustotal.com/gui/file/5a46d793cf82822cb334b70609a9acd7)|Win32 EXE||2018-05-15 19:51:55|Down.exe|
|[72705cb6aa6467233fd979e248dcd720](https://www.virustotal.com/gui/file/72705cb6aa6467233fd979e248dcd720)|Win32 EXE||2018-05-06 00:01:43| |
|[bdede8c167b85250401c7605d81d05f2](https://www.virustotal.com/gui/file/bdede8c167b85250401c7605d81d05f2)|Win32 EXE||2018-04-27 04:59:44|Down.exe|
|[086019f09fa8d34acff7d217a3775a82](https://www.virustotal.com/gui/file/086019f09fa8d34acff7d217a3775a82)|Win32 EXE||2018-04-26 23:44:33| |
|[3059186fd83253e27ee0aacfdd522743](https://www.virustotal.com/gui/file/3059186fd83253e27ee0aacfdd522743)|Win32 EXE||2018-04-26 23:44:05| |
|[a0437c1fe3897a2a621ff3d85068935b](https://www.virustotal.com/gui/file/a0437c1fe3897a2a621ff3d85068935b)|Win32 EXE|dynamer|2018-03-21 05:14:24|a0437c1fe3897a2a621ff3d85068935b|
|[f09779d4b8c505f9512895655e8db8f4](https://www.virustotal.com/gui/file/f09779d4b8c505f9512895655e8db8f4)|PDF||2017-09-29 12:18:58|ORDENES_GENERALES.pdf|
|[f2cdf0913b300b05ea497dac4623f5b9](https://www.virustotal.com/gui/file/f2cdf0913b300b05ea497dac4623f5b9)|Win32 EXE||2017-09-20 12:14:03|a1220050c54365f4e780a942f3e05c880af9c5ea|
|[85f82804f84a08e82716b172343ceb1c](https://www.virustotal.com/gui/file/85f82804f84a08e82716b172343ceb1c)|Win32 EXE||2017-09-06 04:55:41|RAVBg.scr|
|[ed110fa9db083a319037d2eb36d0cde4](https://www.virustotal.com/gui/file/ed110fa9db083a319037d2eb36d0cde4)|PDF||2017-08-15 16:38:15|713751_mc505_15.pdf|
|[d7440cdb40bdc9fe3cca33ade82bdb96](https://www.virustotal.com/gui/file/d7440cdb40bdc9fe3cca33ade82bdb96)|Win32 EXE||2017-08-15 16:37:59|3fa4defac48a14e983a5d224bffbc81206561a559f4e393bcd6c232b0450fd23.bin|
|[9610ac79191c356bb3e69eb046c46e11](https://www.virustotal.com/gui/file/9610ac79191c356bb3e69eb046c46e11)|Win32 EXE||2017-07-12 17:57:07|9610ac79191c356bb3e69eb046c46e11.virus|
|[a1abc63b6659caa09207e94e24ca8773](https://www.virustotal.com/gui/file/a1abc63b6659caa09207e94e24ca8773)|PDF||2017-07-02 17:15:37|RAD-0677-CEOFANB.pdf|
|[ebe65434ed2aa8dd3c2dd862b61d7f50](https://www.virustotal.com/gui/file/ebe65434ed2aa8dd3c2dd862b61d7f50)|PDF||2017-06-22 01:19:04|NOTA_020_NY_Coordinadores_Nacionales.pdf|
|[46b71e9f7e19d26218bd2e8df7503a71](https://www.virustotal.com/gui/file/46b71e9f7e19d26218bd2e8df7503a71)|Win32 EXE||2017-06-22 01:19:04|Java2.exe|
|[cb0bcf05e74a16a15dbf4a944ac68bff](https://www.virustotal.com/gui/file/cb0bcf05e74a16a15dbf4a944ac68bff)|Win32 EXE||2017-06-16 21:04:44|RAVBg.scr|
|[0a79c31c4d9c3d4f27cbe9d6e237de7b](https://www.virustotal.com/gui/file/0a79c31c4d9c3d4f27cbe9d6e237de7b)|Win32 EXE||2017-06-13 03:28:26|RAVBg.scr|
|[a107eb5a10a86b334a211a60385877ad](https://www.virustotal.com/gui/file/a107eb5a10a86b334a211a60385877ad)|DOCX||2017-05-27 08:05:38|74a3ff07154e48bcf040105a786e1a59dc74f3e81eea729c3aff2ee356df8d7e.bin|
|[bce2111e524ad67cc5acc35faa5157d0](https://www.virustotal.com/gui/file/bce2111e524ad67cc5acc35faa5157d0)|Win32 EXE||2017-05-27 08:05:38|RAVBg.exe|
|[a9f85c610a174562dd925dfc6451d01a](https://www.virustotal.com/gui/file/a9f85c610a174562dd925dfc6451d01a)|Win32 EXE||2017-05-09 16:18:46|RAVBg.exe|
|[eea6db192d4e1c7325cf22e46c15a5bf](https://www.virustotal.com/gui/file/eea6db192d4e1c7325cf22e46c15a5bf)|DOCX||2017-05-09 15:54:12|INFORME_DE_PRENSA_NACIONAL.docx|
|[4e4c4694975c62e4cb86128152b99b38](https://www.virustotal.com/gui/file/4e4c4694975c62e4cb86128152b99b38)|DOC||2017-05-05 14:06:48|carta_social_de_las_americas.doc|
|[112ea185037cfae41c75708a6fcce959](https://www.virustotal.com/gui/file/112ea185037cfae41c75708a6fcce959)|Win32 EXE||2017-05-05 14:06:48|RAVBg.exe|
|[e9a3bc1027084cdc07a8e00183e317f8](https://www.virustotal.com/gui/file/e9a3bc1027084cdc07a8e00183e317f8)|PDF||2017-04-15 21:51:41|RDGMA_07_4432.pdf|
|[c5f3bbba35d05fb2485a008b69757338](https://www.virustotal.com/gui/file/c5f3bbba35d05fb2485a008b69757338)|Win32 EXE||2017-03-31 15:04:10|jsx.scr|
|[fba464e3e48d3635316902e9f42bcc10](https://www.virustotal.com/gui/file/fba464e3e48d3635316902e9f42bcc10)|Win32 EXE||2017-03-31 14:00:16|jsx.scr|
|[3f72c6c806a3976386a726fc520c8348](https://www.virustotal.com/gui/file/3f72c6c806a3976386a726fc520c8348)|Win32 EXE||2017-03-23 13:14:04|RAVBg.scr|
|[412fddf75fbd5f423da0bfd431fe7faf](https://www.virustotal.com/gui/file/412fddf75fbd5f423da0bfd431fe7faf)|Win32 EXE|dynamer|2017-03-22 19:48:49|RAVBg.scr|
|[4287c5eed6680e0ebf48f0e4ca1b68e9](https://www.virustotal.com/gui/file/4287c5eed6680e0ebf48f0e4ca1b68e9)|PDF||2017-03-22 19:42:56|Semanario_En_Marcha_1756_11.pdf|
|[a76e815c94c7a876792810db0e84d437](https://www.virustotal.com/gui/file/a76e815c94c7a876792810db0e84d437)|PDF||2017-03-16 16:09:57|Citacion_Judicial_expediente_10388.pdf|
|[4b68b68d1c8a23008401a4e30a3de70f](https://www.virustotal.com/gui/file/4b68b68d1c8a23008401a4e30a3de70f)|Win32 EXE||2017-03-16 16:09:57|RAVBg.exe|
|[742a8c60a6942b8aa5416aad69719d55](https://www.virustotal.com/gui/file/742a8c60a6942b8aa5416aad69719d55)|Win32 EXE||2017-03-16 15:16:28|Adobe Reader|
|[6e73e3f50e99d99f4d45bb88bb0f2bc7](https://www.virustotal.com/gui/file/6e73e3f50e99d99f4d45bb88bb0f2bc7)|Win32 EXE||2017-03-10 17:49:16|RAVBg.exe|
|[81f0b7e18e746ddd486eb4912bdda3b4](https://www.virustotal.com/gui/file/81f0b7e18e746ddd486eb4912bdda3b4)|DOCX||2017-03-10 17:49:02|Articulo_sobre_funcionarias_de_Nicaragua.docx|
|[d59e80ca9ef695553fc48012a8c3ccc9](https://www.virustotal.com/gui/file/d59e80ca9ef695553fc48012a8c3ccc9)|Win32 EXE|Androm|2017-03-10 15:00:00|Microsoft Windows|
|[83370e28201139a6ea15fcaa04472873](https://www.virustotal.com/gui/file/83370e28201139a6ea15fcaa04472873)|Win32 EXE||2017-03-06 20:53:53|RAVBg.exe|
|[ff38976e24238c6dbbd9380599626e04](https://www.virustotal.com/gui/file/ff38976e24238c6dbbd9380599626e04)|DOCX||2017-03-06 20:53:53|Informe_Derechos_Humanos_en_Nicaragua.docx|
|[f315699edaa4737ab11c6be2b12fa16d](https://www.virustotal.com/gui/file/f315699edaa4737ab11c6be2b12fa16d)|Win32 EXE||2017-03-06 20:53:49|Microsoft Windows|
|[d3e8f5a25f61b637d8f9ac30caa10e16](https://www.virustotal.com/gui/file/d3e8f5a25f61b637d8f9ac30caa10e16)|RAR||2017-03-06 20:43:59|Debes%20utilizar%20una%20computadora%20para%20extraer%20el%20contenido.rar|
|[8be54309aea92e4a9fd9e15d68cd89c9](https://www.virustotal.com/gui/file/8be54309aea92e4a9fd9e15d68cd89c9)|Win32 EXE||2017-02-28 03:14:27|ravbg2017.exe|
|[0ca254eb34e13c2a6904d5a8f86b30c2](https://www.virustotal.com/gui/file/0ca254eb34e13c2a6904d5a8f86b30c2)|Win32 EXE||2017-02-09 18:20:39|RAVBg.scr|
|[7cd5fed328110ffe6a3e3ef1404516b8](https://www.virustotal.com/gui/file/7cd5fed328110ffe6a3e3ef1404516b8)|ZIP|Androm|2017-02-09 11:55:14|1acfe9c7e4418f0e0877876134a1f2882a3899e6|
|[77b387bb683d1b6f0874796413803bb1](https://www.virustotal.com/gui/file/77b387bb683d1b6f0874796413803bb1)|Win32 EXE||2017-02-04 16:26:24|RAVBg.scr|
|[f8e81d84a3ffa651ba3925379d9fa8a0](https://www.virustotal.com/gui/file/f8e81d84a3ffa651ba3925379d9fa8a0)|Win32 EXE||2017-02-04 13:43:29|Adobe Reader|
|[fe0e895b8168e3e69c173a6e1c20d9a5](https://www.virustotal.com/gui/file/fe0e895b8168e3e69c173a6e1c20d9a5)|DOCX||2017-01-31 18:38:27|3d955a4ed6eaba916ac680d9a0dcc8ff3bd83eec7d97a73c5f66b5a13f0e80d4.bin|
|[9429ed8bcb57267d55e1b990310e701e](https://www.virustotal.com/gui/file/9429ed8bcb57267d55e1b990310e701e)|Win32 EXE||2017-01-31 18:38:25|RAVBg.exe|
|[4605e835d7b2b9a1b3c4c55749889432](https://www.virustotal.com/gui/file/4605e835d7b2b9a1b3c4c55749889432)|Win32 EXE|Androm|2017-01-31 15:41:49|Microsoft Windows|
|[be098a2a4c29742981239bc9d39a1804](https://www.virustotal.com/gui/file/be098a2a4c29742981239bc9d39a1804)|RAR||2017-01-31 12:54:21|ffd6c98a17db2e346f29fdc0cc3dc91b5764da9c.exe|
|[e44e108a7f5a4457458cd5c6bc34af21](https://www.virustotal.com/gui/file/e44e108a7f5a4457458cd5c6bc34af21)|Win32 EXE||2017-01-27 21:01:11|jsx.scr|
|[7b06b3442600c5e661ffbad2e7257608](https://www.virustotal.com/gui/file/7b06b3442600c5e661ffbad2e7257608)|ZIP|Darkcomet|2017-01-27 15:15:00|37b8362db4d4a2b21ae908e4be53b9e7ccb033b8|
|[1bf6f5204dced9aa0b258868c0f0f17c](https://www.virustotal.com/gui/file/1bf6f5204dced9aa0b258868c0f0f17c)|Win32 EXE||2017-01-13 00:53:04|jsx.scr|
|[702b3da308e5d7e6ab640e51cfb9f0cc](https://www.virustotal.com/gui/file/702b3da308e5d7e6ab640e51cfb9f0cc)|ZIP|Darkcomet|2017-01-12 16:58:29|db7cc1697bf646601f219fe27885edfebac49a23|
|[bdd316ba062ce53ec1990f7c3ac86a8f](https://www.virustotal.com/gui/file/bdd316ba062ce53ec1990f7c3ac86a8f)|Win32 EXE||2016-12-17 06:51:12|RAVBg.scr|
|[7195fe90a2bc744ad8acbc89df460ed2](https://www.virustotal.com/gui/file/7195fe90a2bc744ad8acbc89df460ed2)|DOCX||2016-12-17 06:51:08|Mision_Secreta_de_la_DINA_en_Washigton.docx|
|[a7c66e88a7c7ad34d0eb5db9b41ffb5f](https://www.virustotal.com/gui/file/a7c66e88a7c7ad34d0eb5db9b41ffb5f)|Win32 EXE||2016-12-17 02:20:43|Microsoft Windows|
|[2093ee12517a2dd29c6e39f5d697a71e](https://www.virustotal.com/gui/file/2093ee12517a2dd29c6e39f5d697a71e)|RAR||2016-12-16 22:20:07|Mision_Secreta_de_la_DINA_en_Washigton.rar|
|[e8ba98b6e61948f5c59b5d5cd5c6199b](https://www.virustotal.com/gui/file/e8ba98b6e61948f5c59b5d5cd5c6199b)|DOCX||2016-12-11 05:49:29|Aniversario_de_cascos_azules_ecuatorianos.docx|
|[420614ab0c9dda5f613b219ac2833c68](https://www.virustotal.com/gui/file/420614ab0c9dda5f613b219ac2833c68)|Win32 EXE||2016-12-11 02:01:23|Microsoft Windows|
|[075cb8a337270bce038e33951d884650](https://www.virustotal.com/gui/file/075cb8a337270bce038e33951d884650)|Win32 EXE||2016-12-07 19:52:25|RAVBg.scr|
|[c7a08cccf51050165a91295a147f227f](https://www.virustotal.com/gui/file/c7a08cccf51050165a91295a147f227f)|Win32 EXE||2016-12-07 15:58:47|Microsoft Windows|
|[5b8c1ade0287bee0d1d794a396caaf5d](https://www.virustotal.com/gui/file/5b8c1ade0287bee0d1d794a396caaf5d)|RAR|Androm|2016-12-07 12:01:53|RDGMA_07_4432.rar|
|[b42d807f57db035f8ad86ab00541e50f](https://www.virustotal.com/gui/file/b42d807f57db035f8ad86ab00541e50f)|DOCX||2016-12-06 03:42:47|DECRETO_No_18_Duelo_Virgilio_Godoy.docx|
|[dffce034cb32015ed78aed37e1833629](https://www.virustotal.com/gui/file/dffce034cb32015ed78aed37e1833629)|Win32 EXE|dynamer|2016-12-05 19:42:52|RAVBg.scr|
|[baa9fe022093f692d8c33b9fdc4e0246](https://www.virustotal.com/gui/file/baa9fe022093f692d8c33b9fdc4e0246)|Win32 EXE|dynamer|2016-12-05 15:55:58|Microsoft Windows|
|[c00b206bb563413c35523b06719bae64](https://www.virustotal.com/gui/file/c00b206bb563413c35523b06719bae64)|Win32 EXE|dynamer|2016-11-25 22:01:58|RAVBg.scr|
|[fa85c2c01ad03339e7e386a80203f17b](https://www.virustotal.com/gui/file/fa85c2c01ad03339e7e386a80203f17b)|DOCX||2016-11-25 22:01:54|Ministerio_de_Defensa_ordena_al_Issfa_que_no_suspenda_tres_prestaciones.docx|
|[ee2f5fe72962adc42b1c0e71972ab02a](https://www.virustotal.com/gui/file/ee2f5fe72962adc42b1c0e71972ab02a)|Win32 EXE|dynamer|2016-11-23 17:33:46|2f878a3043d8f506fa53265afcea40b622e82806d1438cf4a07f92fb01d9962f.bin|
|[3cfff71639f5d5571d613df4871943ac](https://www.virustotal.com/gui/file/3cfff71639f5d5571d613df4871943ac)|DOCX||2016-11-23 17:33:42|Articulo_de_Opinion_Heinz_Dieterich.docx|
|[5d08fc538329fa9305586b5e1f21ad83](https://www.virustotal.com/gui/file/5d08fc538329fa9305586b5e1f21ad83)|Win32 EXE|dynamer|2016-11-23 13:40:56|Microsoft Windows|
|[a854ec9ca4c220274a075a792a8e1c67](https://www.virustotal.com/gui/file/a854ec9ca4c220274a075a792a8e1c67)|Win32 EXE|dynamer|2016-11-17 01:48:48|Microsoft Windows|
|[5478b81d67fd5720d60f26ff4d5105fd](https://www.virustotal.com/gui/file/5478b81d67fd5720d60f26ff4d5105fd)|DOC||2016-10-12 12:21:02|CIRCULAR_8_OCT_2016.doc|
|[38e5ee2aecf10fe7f02bd4f0c1c20058](https://www.virustotal.com/gui/file/38e5ee2aecf10fe7f02bd4f0c1c20058)|Win32 EXE||2016-10-12 04:21:07|RAVBg.ext.scr|
|[eb23912f533bad9366793daf06a2b567](https://www.virustotal.com/gui/file/eb23912f533bad9366793daf06a2b567)|Win32 EXE|Darkcomet|2016-10-12 00:30:08|Microsoft Windows|
|[b85d07ea85445688d17532b387828019](https://www.virustotal.com/gui/file/b85d07ea85445688d17532b387828019)|ZIP|Darkcomet|2016-10-11 20:51:35|CIRCULAR_8_OCT_2016.zip|
|[8ba74f100e01cbb3c654408363efe6ab](https://www.virustotal.com/gui/file/8ba74f100e01cbb3c654408363efe6ab)|DOC||2016-10-09 19:02:03|977_REG_IN_CO_012_V1.doc|
|[4b31855ede33bc25ba1a8da39d6fd6f0](https://www.virustotal.com/gui/file/4b31855ede33bc25ba1a8da39d6fd6f0)|Win32 EXE||2016-10-09 11:02:54|RAVBg.int.scr|
|[6ee614c1f9314c888a58ecaf350be782](https://www.virustotal.com/gui/file/6ee614c1f9314c888a58ecaf350be782)|Win32 EXE||2016-10-09 07:22:54|Microsoft Windows|
|[81e8df1f364570de95665a10c82432a1](https://www.virustotal.com/gui/file/81e8df1f364570de95665a10c82432a1)|DOC||2016-10-08 19:34:46|Boletn_PAT_034_UADMNE_Visita_de_Guardianes_del_Mar_a_repartos_navales.doc|
|[968fdc344c24b14061f3e7693b1462d2](https://www.virustotal.com/gui/file/968fdc344c24b14061f3e7693b1462d2)|Win32 EXE||2016-10-08 11:34:45|jsx.scr|
|[ab0a4dc1c8d067ca58e89b4cd9a71154](https://www.virustotal.com/gui/file/ab0a4dc1c8d067ca58e89b4cd9a71154)|Win32 EXE||2016-10-07 21:54:17|Microsoft Windows|
|[be55e627241c9930fc1713e11b495739](https://www.virustotal.com/gui/file/be55e627241c9930fc1713e11b495739)|DOCX||2016-10-05 11:01:30|Denuncia_penal_o_querella.docx|
|[63d7e9ee1086e81873a9275eab8d9cea](https://www.virustotal.com/gui/file/63d7e9ee1086e81873a9275eab8d9cea)|Win32 EXE||2016-10-05 03:01:31|RAVBg.ext.scr|
|[cf90a40ba183d89244f966780845a2f5](https://www.virustotal.com/gui/file/cf90a40ba183d89244f966780845a2f5)|Win32 EXE|dynamer|2016-10-02 14:19:10|Microsoft Windows|
|[171ffc2331fc59c7166b22507754722f](https://www.virustotal.com/gui/file/171ffc2331fc59c7166b22507754722f)|Win32 EXE||2016-09-18 18:46:49|jsx.scr|
|[4b29580d94598a9fb088b9c798e3b0ca](https://www.virustotal.com/gui/file/4b29580d94598a9fb088b9c798e3b0ca)|Win32 EXE|Darkcomet|2016-09-18 15:00:32|Adobe Reader|
|[e2013d4e600c5c42e312aafdc661d0d1](https://www.virustotal.com/gui/file/e2013d4e600c5c42e312aafdc661d0d1)|RAR|Darkcomet|2016-09-18 11:25:11|ORDENES_GENERALES.rar|
|[ae2b837524f4fea346fcf3c2ee5f0c9c](https://www.virustotal.com/gui/file/ae2b837524f4fea346fcf3c2ee5f0c9c)|DOC||2016-07-09 22:52:46|Notificacion_Judicial_No_8030923_2015.doc|
|[ec86dc8f2dbc082e67c3947ea2f45c48](https://www.virustotal.com/gui/file/ec86dc8f2dbc082e67c3947ea2f45c48)|Win32 EXE||2016-07-09 14:48:43|Microsoft Windows|
|[483ae36e4ddb79de9bec51d3bf0acd04](https://www.virustotal.com/gui/file/483ae36e4ddb79de9bec51d3bf0acd04)|Win32 EXE||2016-07-09 14:46:59|Ja.exe|
|[addd0069320fd8482650ab135dc7819c](https://www.virustotal.com/gui/file/addd0069320fd8482650ab135dc7819c)|Win32 EXE|dynamer|2016-07-09 14:40:09|RAVBg.sfx.exe|
|[b2b3fd5e2b4bca2a4f1ebc710350e584](https://www.virustotal.com/gui/file/b2b3fd5e2b4bca2a4f1ebc710350e584)|Win32 EXE|dynamer|2016-07-09 14:35:09|jsx.scr|
|[e761bef078b8774c3d9027d07bef5c45](https://www.virustotal.com/gui/file/e761bef078b8774c3d9027d07bef5c45)|Win32 EXE||2016-05-12 08:41:15|e761bef078b8774c3d9027d07bef5c45.virus|
|[1a7f741e2e200bd75c89e0a6e0726c4d](https://www.virustotal.com/gui/file/1a7f741e2e200bd75c89e0a6e0726c4d)|Win32 EXE||2016-05-02 13:13:45| |
|[a834ae9731f6677677a3ed4d9dd4793c](https://www.virustotal.com/gui/file/a834ae9731f6677677a3ed4d9dd4793c)|Win32 EXE||2016-05-01 18:58:51|jsx.scr|
|[5f6ce912a4e023a9395c03f1cac268b2](https://www.virustotal.com/gui/file/5f6ce912a4e023a9395c03f1cac268b2)|DOCX||2016-05-01 18:58:44|DIRECTIVA_MANDO_OPERACIONAL.docx|
|[b992f57ac0550f1df0e6b29f3dd8f0ef](https://www.virustotal.com/gui/file/b992f57ac0550f1df0e6b29f3dd8f0ef)|Win32 EXE||2016-05-01 18:42:25|Microsoft Windows|
|[9a7ef967333d6fcbda2665adfcb2731b](https://www.virustotal.com/gui/file/9a7ef967333d6fcbda2665adfcb2731b)|DOCX||2016-04-28 23:57:38|Padrino_Lopez_Hay_un_golpe_de_Estado_en_desarrollo.docx|
|[2298d4514829801ffac579e712c59216](https://www.virustotal.com/gui/file/2298d4514829801ffac579e712c59216)|Win32 EXE|dynamer|2016-04-28 15:57:36|jsx.scr|
|[9cdd74d3891feae6e330b95d1ced7d0f](https://www.virustotal.com/gui/file/9cdd74d3891feae6e330b95d1ced7d0f)|Win32 EXE|Darkcomet|2016-04-28 15:41:13|Microsoft Windows|
|[ce18ded185ab496066a6cf44f71bc6de](https://www.virustotal.com/gui/file/ce18ded185ab496066a6cf44f71bc6de)|Win32 EXE||2016-04-15 01:51:56|jsx.scr|
|[24c14c68477c07a3a5e50de257a97440](https://www.virustotal.com/gui/file/24c14c68477c07a3a5e50de257a97440)|DOC||2016-04-15 01:51:54|ROSARIO_EN_MULTINOTICIAS_13_ABRIL_2016.doc|
|[2d87f53f7f7e513c4257959b140bd50b](https://www.virustotal.com/gui/file/2d87f53f7f7e513c4257959b140bd50b)|Win32 EXE||2016-04-15 01:49:48|Microsoft Windows|
|[7aea8468677608e0b81c80edc3fab292](https://www.virustotal.com/gui/file/7aea8468677608e0b81c80edc3fab292)|ZIP||2016-04-15 01:48:37|1ea534811fb44933ba4426cee48012a14c625a9c|
|[a132cba5d33b96a4ba2609458a1dbdfa](https://www.virustotal.com/gui/file/a132cba5d33b96a4ba2609458a1dbdfa)|Win32 EXE|dynamer|2016-03-28 10:55:28| |
|[51bf2c59ff04ee7e4a60da5ffb92573d](https://www.virustotal.com/gui/file/51bf2c59ff04ee7e4a60da5ffb92573d)|MP3||2016-02-20 01:57:17|001_fiebre_de_amor.mp3|
|[aef0622e73946484a7fb405f71b9f087](https://www.virustotal.com/gui/file/aef0622e73946484a7fb405f71b9f087)|JPEG||2016-02-20 01:52:47|LISTA_DEL_RADG_N_0931208.jpg|
|[fce70d2e3d4532dd987c103d3b9d3ebd](https://www.virustotal.com/gui/file/fce70d2e3d4532dd987c103d3b9d3ebd)|PPT||2016-02-20 01:30:47|El_Arte_De_La_Guerra.ppt|
|[635b5369663b6c3e5a7ff156f263f826](https://www.virustotal.com/gui/file/635b5369663b6c3e5a7ff156f263f826)|Win32 EXE||2016-02-20 01:24:25|JavaFX.exe|
|[a9e4871abc06cf51bcd6b47413c4a9e4](https://www.virustotal.com/gui/file/a9e4871abc06cf51bcd6b47413c4a9e4)|DOCX||2016-02-07 02:26:18|REINCORPORACION.docx|
|[b697146395114080ff16623388085fd4](https://www.virustotal.com/gui/file/b697146395114080ff16623388085fd4)|Win32 EXE||2016-02-06 18:26:21|27.exe|
|[e2da476bf44c48b7dd2d40d8e686281a](https://www.virustotal.com/gui/file/e2da476bf44c48b7dd2d40d8e686281a)|Win32 EXE||2016-02-06 16:01:29|Microsoft Windows|
|[2f1b0b409f3654cd6193d822f953d4f1](https://www.virustotal.com/gui/file/2f1b0b409f3654cd6193d822f953d4f1)|DOCX||2016-02-06 12:35:47|Cuestionario.docx|
|[b68b7f6ebd3b7bd80de1845d8a5ae4c6](https://www.virustotal.com/gui/file/b68b7f6ebd3b7bd80de1845d8a5ae4c6)|Win32 EXE|dynamer|2016-02-06 04:35:50|22.exe|
|[7ac1fa84d0fec58c43d7d5e905e12299](https://www.virustotal.com/gui/file/7ac1fa84d0fec58c43d7d5e905e12299)|Win32 EXE||2016-02-06 04:34:20|Microsoft Windows|
|[d4ae5403b9c40cdcaffd0ea075169c2e](https://www.virustotal.com/gui/file/d4ae5403b9c40cdcaffd0ea075169c2e)|PPTX||2015-11-13 05:10:40|INSTRUCTIVO_LOGISTICO.pptx|
|[e0afb50f7b22259635238e8d2a331ace](https://www.virustotal.com/gui/file/e0afb50f7b22259635238e8d2a331ace)|Win32 EXE||2015-11-12 21:13:40|Microsoft Windows Viewer|
|[ad5a546d40681295fe2c1c2daca900cd](https://www.virustotal.com/gui/file/ad5a546d40681295fe2c1c2daca900cd)|Win32 EXE|Darkcomet|2015-11-12 21:09:42|Microsoft Office Power Point|
|[d867b6fef025d27f203851fb74aa26c1](https://www.virustotal.com/gui/file/d867b6fef025d27f203851fb74aa26c1)|Win32 EXE||2015-11-12 21:04:02|jsx.scr|
|[5a82c6482b97f4bfac507f79d11a6854](https://www.virustotal.com/gui/file/5a82c6482b97f4bfac507f79d11a6854)|Win32 EXE||2015-11-12 21:02:49|Microsoft Windows|
|[2db0e8ce5164cccc75340d9b61fad91c](https://www.virustotal.com/gui/file/2db0e8ce5164cccc75340d9b61fad91c)|DOCX||2015-10-23 15:00:36|Nicaragua_denuncia_ante_la_CIJ_las.docx|
|[d7accc228fcb5e7975415d9d3d5de44c](https://www.virustotal.com/gui/file/d7accc228fcb5e7975415d9d3d5de44c)|Win32 EXE||2015-10-23 07:00:36|jsx.scr|
|[c3fbc02c15d361f9f4cb19881c270e5c](https://www.virustotal.com/gui/file/c3fbc02c15d361f9f4cb19881c270e5c)|Win32 EXE||2015-10-23 03:43:36|Microsoft Windows|
|[93b119301f15bc628d1a7726bca088d3](https://www.virustotal.com/gui/file/93b119301f15bc628d1a7726bca088d3)|Win32 EXE||2015-10-22 17:05:19|Oct.exe|
|[9ccde140fb692094a9d35c87dda7d502](https://www.virustotal.com/gui/file/9ccde140fb692094a9d35c87dda7d502)|PDF||2015-10-22 17:05:19|209-707-1-PB.pdf|
|[7c0e352f4e69373f7bcfe197aeb51043](https://www.virustotal.com/gui/file/7c0e352f4e69373f7bcfe197aeb51043)|Win32 EXE||2015-10-08 00:35:10|Instalar2.exe|
|[83868405167349e6c21bf02632944a7e](https://www.virustotal.com/gui/file/83868405167349e6c21bf02632944a7e)|DOC||2015-10-02 02:32:54|PARTE_ESPECIAL_COMANDANCIA_GENERAL_DE_LA_AVIACIN_20SEP15.doc|
|[bbeec6725e6b4a9580d4d6b641dcbbbb](https://www.virustotal.com/gui/file/bbeec6725e6b4a9580d4d6b641dcbbbb)|Win32 EXE||2015-10-01 18:32:55|jsx.scr|
|[6443a28f6d7137970b48c8d43d7df03d](https://www.virustotal.com/gui/file/6443a28f6d7137970b48c8d43d7df03d)|Win32 EXE||2015-09-13 06:39:54|Java2014.exe|
|[048f6154fe68c6f8582ac020e400b26e](https://www.virustotal.com/gui/file/048f6154fe68c6f8582ac020e400b26e)|PPT||2015-09-13 06:39:51|Curriculum_vitae.pps|
|[df6b74721b9fd643867423e242d30e08](https://www.virustotal.com/gui/file/df6b74721b9fd643867423e242d30e08)|Win32 EXE|Darkcomet|2015-09-12 22:37:07|Microsoft Office Power Point|
|[22cf5d279e34884981bbc6ad03d48df6](https://www.virustotal.com/gui/file/22cf5d279e34884981bbc6ad03d48df6)|Win32 EXE||2014-12-01 01:27:03|Javabcgf.scr|
|[f083d5a693697ca7cd7b59265fb57bba](https://www.virustotal.com/gui/file/f083d5a693697ca7cd7b59265fb57bba)|DOC||2014-11-30 17:27:01|Notificacion_Judicial_No_8030923_2014.doc|
|[7ee0ea2ca86ab0f7440fa9dac5860c1e](https://www.virustotal.com/gui/file/7ee0ea2ca86ab0f7440fa9dac5860c1e)|Windows Installer||2014-09-04 21:48:40|HotBrazilianX.pps|
|[67593be1586fa629d9ecae84b66c6a0c](https://www.virustotal.com/gui/file/67593be1586fa629d9ecae84b66c6a0c)|Windows Installer||2014-09-01 17:19:59|Hermosa_XXX.pps|
|[e486eddffd13bed33e68d6d8d4052270](https://www.virustotal.com/gui/file/e486eddffd13bed33e68d6d8d4052270)|Win32 EXE||2014-09-01 09:16:26|Microsoft Office Power Point|
|[ae1614194512e79314f41a94e0fb4701](https://www.virustotal.com/gui/file/ae1614194512e79314f41a94e0fb4701)|Win32 EXE||2013-10-30 15:09:27|JavaAlq.exe|
|[0c16147dafcea8ba09c027f92d1d154c](https://www.virustotal.com/gui/file/0c16147dafcea8ba09c027f92d1d154c)|Win32 EXE||2013-09-03 16:57:36|283dd9336093dfe8f4587879a5506058b98fa171|
|[70c1055255e991926fad58ab93190738](https://www.virustotal.com/gui/file/70c1055255e991926fad58ab93190738)|Win32 EXE||2013-08-23 20:04:57|328a709fd919c1a1517438956f4797f84c82dbac|
|[be82fcea3aed84f561e57e7861add1ca](https://www.virustotal.com/gui/file/be82fcea3aed84f561e57e7861add1ca)|Win32 EXE||2013-08-15 04:21:02|JavaAlq.exe|
|[688bdb55a387262478de0251cf2f7484](https://www.virustotal.com/gui/file/688bdb55a387262478de0251cf2f7484)|unknown||2013-07-04 19:13:16|Suntzu.ppt|
|[64ed9861aa60984e444423df7c3057f4](https://www.virustotal.com/gui/file/64ed9861aa60984e444423df7c3057f4)|Win32 EXE||2012-11-29 13:31:13|5c84ee01eacd2abb44b8a8945bfa0349a0804e3243931cc3277f469d3142abd6.vir|
|[270e52904eff620f54772a47e87ea71c](https://www.virustotal.com/gui/file/270e52904eff620f54772a47e87ea71c)|Win32 EXE||2011-09-12 16:29:32|final.exe|
|[a2fc14a2c59303e4b8fab95a79463d4a](https://www.virustotal.com/gui/file/a2fc14a2c59303e4b8fab95a79463d4a)|Win32 EXE||2011-09-08 19:36:10| |
|[4293b54943c304ffb6a5fb8763eaa58a](https://www.virustotal.com/gui/file/4293b54943c304ffb6a5fb8763eaa58a)|Win32 EXE||2011-08-22 17:34:51|ManualConsolaXbox360.exe|
|[6a1b69d3410a04105087ae88a217b0d7](https://www.virustotal.com/gui/file/6a1b69d3410a04105087ae88a217b0d7)|Win32 EXE||2011-05-18 11:56:47|JAVA.exe|
|[36f4ae3959e8f9442e9774795d44bd99](https://www.virustotal.com/gui/file/36f4ae3959e8f9442e9774795d44bd99)|Win32 EXE||2011-05-03 22:23:55|JavaU.exe|
|[326da40ff58ff663f958292b581d19e5](https://www.virustotal.com/gui/file/326da40ff58ff663f958292b581d19e5)|Win32 EXE||2011-04-18 19:13:19|FINAL.exe|
|[12fcf0fc3cf66a49e3ee40cac6332e6f](https://www.virustotal.com/gui/file/12fcf0fc3cf66a49e3ee40cac6332e6f)|Win32 EXE||2011-03-25 16:33:31|Farc.pdf.scr|
|[ac3dab8458ceca649f4813cba15e25b0](https://www.virustotal.com/gui/file/ac3dab8458ceca649f4813cba15e25b0)|Win32 EXE||2011-03-18 15:20:24|final.exe|
|[e70bd516f2a5ffae65044e4c56729ad8](https://www.virustotal.com/gui/file/e70bd516f2a5ffae65044e4c56729ad8)|Win32 EXE||2011-03-18 02:30:46|final.exe|
|[6800f317a97fdb16756ef5acdf85e595](https://www.virustotal.com/gui/file/6800f317a97fdb16756ef5acdf85e595)|Win32 EXE||2011-03-16 17:33:54|FinalEX.exe|
|[9aa69ffd242bc707423307f5d62f272b](https://www.virustotal.com/gui/file/9aa69ffd242bc707423307f5d62f272b)|Win32 EXE||2011-03-10 16:02:31|final1.exe|
|[212ab5b43f815832b0ba35752e4b7439](https://www.virustotal.com/gui/file/212ab5b43f815832b0ba35752e4b7439)|PPS||2009-05-11 20:13:05|ProfeciadeMariaenFatima.pps|
|[f85489c1d1ff3374f92ccb7267032016](https://www.virustotal.com/gui/file/f85489c1d1ff3374f92ccb7267032016)|TXT||2020-06-13 23:47:04|UpdateSession|
|[fbe5b66db57fb52b231c5374ac2ac805](https://www.virustotal.com/gui/file/fbe5b66db57fb52b231c5374ac2ac805)|DOC||2020-04-11 21:26:03| |
|[6b33fa0c52ca413d4214dcde007f89c1](https://www.virustotal.com/gui/file/6b33fa0c52ca413d4214dcde007f89c1)|FPX||2020-04-08 01:29:19|7c38d073b77ff7afc8f65aac812316d0fa9356115f1f3e78aca9fd496d177cad.bin|
