**NAME:**  
DustSquad  
  
**Description**:   
DustSquad is a Russian-language cyberespionage actor that focuses on Central Asian users and diplomatic entities. One associated malicious program for Windows called Octopus that mostly targets diplomatic entities, which pretending to be Telegram Messenger with a Russian interface. Android system is their target as well
  
**References**:  
https://securelist.com/octopus-infested-seas-of-central-asia/88200/
