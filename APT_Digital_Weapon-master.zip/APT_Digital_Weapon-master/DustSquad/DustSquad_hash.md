|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[bbb701630f30c5c85cebbc953b98ff38](https://www.virustotal.com/gui/file/bbb701630f30c5c85cebbc953b98ff38)|Win32 EXE||2019-11-20 06:44:53|%APPDATA%\microsoft\windows\start menu\programs\startup\java7.exe|
|[62fb5aa21f62e92586829520078c2561](https://www.virustotal.com/gui/file/62fb5aa21f62e92586829520078c2561)|Win32 EXE||2019-11-19 03:51:42|исправленный вариан_18.11.2019г.exe|
|[98b1c326572110a4c88c6741575910c2](https://www.virustotal.com/gui/file/98b1c326572110a4c88c6741575910c2)|RAR||2019-11-19 03:48:02|исправленный вариан_18.11.2019г.rar|
|[7c0050a3e7aa3172392dcbab3bb92566](https://www.virustotal.com/gui/file/7c0050a3e7aa3172392dcbab3bb92566)|Win32 EXE|Delf|2018-06-14 11:13:03|caaf10e6f65d630130c04453160596eada9a5b78167c934e9ea3e8baffa2c345.bin|
|[87126c8489baa8096c6f30456f5bef5e](https://www.virustotal.com/gui/file/87126c8489baa8096c6f30456f5bef5e)|Win32 EXE|Delf|2018-03-21 15:21:42|myfile.exe|
|[979eff03faeaeea5310df53ee1a2fc8e](https://www.virustotal.com/gui/file/979eff03faeaeea5310df53ee1a2fc8e)|ZIP||2018-03-20 16:05:18|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DustSquad/OctopusTelegramMessengerDropper.bin|
|[38f30749a87dcbf156689300737a094e](https://www.virustotal.com/gui/file/38f30749a87dcbf156689300737a094e)|Win32 EXE|Delf|2018-01-31 11:57:33|myfile.exe|
|[ee3c829e7c773b4f94b700902ea3223c](https://www.virustotal.com/gui/file/ee3c829e7c773b4f94b700902ea3223c)|Win32 EXE|Delf|2018-01-03 21:41:30|2af44715d4f0655bd50d30d46b01336b7f7743ade6b78e2e7650a8d60dc35858.bin|
|[ae4e901509b05022bbe7ef340f4ad96c](https://www.virustotal.com/gui/file/ae4e901509b05022bbe7ef340f4ad96c)|Win32 EXE|Delf|2017-11-26 17:09:58|28618a61886d711887adbf88bedbc697f5299cbd9e5c66faf86cd10143764a47.bin|
|[a90caeb6645b6c866ef60eb2d5f2d0c5](https://www.virustotal.com/gui/file/a90caeb6645b6c866ef60eb2d5f2d0c5)|Win32 EXE|Delf|2017-11-24 19:16:32|2e42c3e545c8fed42dd937520669557c6b93dfef908d47c4ec674b1523589fb2.bin|
|[6fda541befa1ca675d9a0cc310c49061](https://www.virustotal.com/gui/file/6fda541befa1ca675d9a0cc310c49061)|Win32 EXE|Delf|2017-10-27 01:27:37|7de61844dca0f8e22c63e7b58e9d512c12ad08f988631940258c15c36a5ca120.bin|
|[e149c1da1e05774e6b168b6b00272eb4](https://www.virustotal.com/gui/file/e149c1da1e05774e6b168b6b00272eb4)|Win32 EXE|Delf|2017-07-10 06:44:05|7bf35882-653a-11e7-b618-0016383a46b3|
|[1610cddb80d1be5d711feb46610f8a77](https://www.virustotal.com/gui/file/1610cddb80d1be5d711feb46610f8a77)|Win32 EXE|Delf|2017-01-08 13:09:54|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DustSquad/OctopusDelphi.exe|
|[4f4a8898b0aa4507dbb568dca1dedd38](https://www.virustotal.com/gui/file/4f4a8898b0aa4507dbb568dca1dedd38)|Win32 EXE|Delf|2017-01-07 21:52:56|70dce2b7a0a95be49e9e961f72ac6832da2ab954d6231949cddca47b13174336.bin|
|[3a54b3f9e9bd54b4098fe592d805bf72](https://www.virustotal.com/gui/file/3a54b3f9e9bd54b4098fe592d805bf72)|Win32 EXE|Delf|2016-12-13 21:56:02|1dedf3bd4a1616d0b6608bfc2ea40d3349de47c3a6fa0dce299f350dc654a4fc.bin|
|[88ad67294cf53d521f8295aa1a7b5c46](https://www.virustotal.com/gui/file/88ad67294cf53d521f8295aa1a7b5c46)|Win32 EXE|Delf|2016-03-05 12:58:55|7315424342a31ff02f70e57038b0406c5cad9763e185e3bc2312ed52e3a17e61.bin|
|[f7b1503a48a46e3269e6c6b537b033f8](https://www.virustotal.com/gui/file/f7b1503a48a46e3269e6c6b537b033f8)|Win32 EXE|Delf|2016-03-05 12:56:28|6912af422c3912eadfcd063359446580d2dd10aa24c10c6010ecec1f7c5e5d2b.bin|
|[546ab9cdac9a812aab3e785b749c89b2](https://www.virustotal.com/gui/file/546ab9cdac9a812aab3e785b749c89b2)|Win32 EXE|Delf|2016-02-14 02:02:03|26cec9c7e974726bb101dd1580b51447f93aa57173006ca7739f3582b337cbbb.bin|
|[ca743d10d27277584834e72afefd6be8](https://www.virustotal.com/gui/file/ca743d10d27277584834e72afefd6be8)|Win32 EXE|Delf|2015-11-27 03:26:07|c:\Windows\system32\spool\tools\PrintBrmEngine.exe|
