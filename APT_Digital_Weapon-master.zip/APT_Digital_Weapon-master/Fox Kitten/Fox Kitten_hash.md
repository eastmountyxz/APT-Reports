|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[cc00068cc0d745a357db6ef9d08d1854](https://www.virustotal.com/gui/file/cc00068cc0d745a357db6ef9d08d1854)|Android|androidos|2019-10-16 17:52:19|CatchAndSee_v1.apk|
|[a84549691a492ad081bf177b6c4518b0](https://www.virustotal.com/gui/file/a84549691a492ad081bf177b6c4518b0)|Win64 EXE||2019-10-07 15:27:18|Y:\Information Security\Issues\5-10-19\FPSRV-HZ\M\PerfLogs\psexec.exe|
|[783dc28185837c8e66dca34e9a519c7c](https://www.virustotal.com/gui/file/783dc28185837c8e66dca34e9a519c7c)|Win32 EXE||2019-10-03 07:04:56|sshnet.exe|
|[a87d59456f323bd373cb958273dfe8bb](https://www.virustotal.com/gui/file/a87d59456f323bd373cb958273dfe8bb)|TXT||2019-04-19 07:32:18|195e95b6a1f9de762ee01027f903010c560ce76e050d61a7223b6fce0b1060a3.bin|
|[0c4db17ed145310f336ab4887914f80c](https://www.virustotal.com/gui/file/0c4db17ed145310f336ab4887914f80c)|TXT||2019-03-21 07:00:13|49d5cfb41066bca7c9f03aad2d729e9d9d99c95bc9c50c152af3ccc94e3db4f9.bin|
|[b4fcb52673089caf3e6e76379f2604d8](https://www.virustotal.com/gui/file/b4fcb52673089caf3e6e76379f2604d8)|TXT||2018-12-16 14:39:10|32e602df2a327292b9c93b609d2d210e568a058a200563795654cf16c3afc6b8.bin|
|[0f7d3d33d7235b13d0fac4329e0d2420](https://www.virustotal.com/gui/file/0f7d3d33d7235b13d0fac4329e0d2420)|TXT||2018-11-27 09:01:07|cmd.aspx|
|[31b431df84eaf71848c8b172c40124ec](https://www.virustotal.com/gui/file/31b431df84eaf71848c8b172c40124ec)|TXT||2018-10-22 15:39:26|C:\Users\ADMINI~1\AppData\Local\Temp\AutoRDPwn-master\Resources\Scripts\Invoke-SMBExec.ps1|
|[54af54c9e0aa4b26c4be803c44c5f473](https://www.virustotal.com/gui/file/54af54c9e0aa4b26c4be803c44c5f473)|TXT||2018-10-22 15:38:17|Invoke-TheHash.psm1|
|[b63de834ab7cc8fcd0e71003c6786213](https://www.virustotal.com/gui/file/b63de834ab7cc8fcd0e71003c6786213)|TXT||2018-09-05 12:02:34|d4a177af7b6e19ff4f1917e2f0a606c21845c7921e62453432ff341485b4cfa8.bin|
|[808502752ca0492aca995e9b620d507b](https://www.virustotal.com/gui/file/808502752ca0492aca995e9b620d507b)|Win64 EXE|Johnnie|2018-08-15 09:33:26|JuicyPotato.exe|
|[6fea7a30b2bd6014c1b15defe8963273](https://www.virustotal.com/gui/file/6fea7a30b2bd6014c1b15defe8963273)|TXT||2018-04-28 14:38:40|tiny.aspx|
|[01a9293fb10985204a4278006796ea3f](https://www.virustotal.com/gui/file/01a9293fb10985204a4278006796ea3f)|Win32 EXE||2017-12-14 05:51:58|port.exe|
|[f064ff619ebf67a59566c0dd54c5d05c](https://www.virustotal.com/gui/file/f064ff619ebf67a59566c0dd54c5d05c)|Win32 EXE||2017-12-14 05:51:48|sshnet.exe|
|[cb84fc4682a74ba81ef477bc1359959b](https://www.virustotal.com/gui/file/cb84fc4682a74ba81ef477bc1359959b)|Win32 EXE|rozena|2017-12-14 05:51:31|ConsoleApplication5.exe|
|[cfcbb6472cac07ea138379578d80845b](https://www.virustotal.com/gui/file/cfcbb6472cac07ea138379578d80845b)|Win32 EXE|rozena|2017-12-14 05:51:19|ConsoleApplication5.exe|
|[29fb089328e78f67ff86739583a9e63a](https://www.virustotal.com/gui/file/29fb089328e78f67ff86739583a9e63a)|Win32 EXE||2017-12-11 22:30:18|sshnet.exe|
|[155837e476b50c93b6522b310a684a33](https://www.virustotal.com/gui/file/155837e476b50c93b6522b310a684a33)|Win32 EXE|rozena|2017-12-11 14:45:29|ConsoleApplication5.exe|
|[475f89de6031db2158231eafa07b8b72](https://www.virustotal.com/gui/file/475f89de6031db2158231eafa07b8b72)|Win32 EXE||2017-12-11 14:22:18|cs|
|[836d61745e087e6017832233701218a4](https://www.virustotal.com/gui/file/836d61745e087e6017832233701218a4)|TXT||2017-05-03 19:53:01|Invoke-TheHash.psd1|
|[41cda77c69614a0fbfcc4a38ebae659b](https://www.virustotal.com/gui/file/41cda77c69614a0fbfcc4a38ebae659b)|TXT||2013-09-02 06:11:35|37a2494de2689be02bb0e6185dcf0248001e90d2b049a32bb907e1025e550748.bin|
