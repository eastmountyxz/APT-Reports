**NAME:**  
APT10  
  
**Alias**  
Stone Panda, APT 10, menuPass, happyyongzi, POTASSIUM, DustStorm, Red Apollo, CVNX, HOGFISH, APT10  
  
**Description**:   
APT10 is the name given to a group of Chinese hackers first identified by FireEye. The group is said to have taken gigabytes of sensitive data from firms involved in the fields of aviation, space and satellite, manufacturing, pharmaceuticals, oil and gas exploration, communications, computer processor and maritime.
  
**References**:  
https://www.fireeye.com/blog/threat-research/2018/09/apt10-targeting-japanese-corporations-using-updated-ttps.html
