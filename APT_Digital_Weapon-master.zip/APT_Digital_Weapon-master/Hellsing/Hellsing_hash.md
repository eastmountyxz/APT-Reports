|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[ea5d9bb659f5f38ade8183b2647f368f](https://www.virustotal.com/gui/file/ea5d9bb659f5f38ade8183b2647f368f)|Win32 EXE||2019-04-30 07:52:45|injected_b882c850bde0a1d210d09760f5ff94e81491f043|
|[1fd7a38b452cfcedbe26bee721a659c0](https://www.virustotal.com/gui/file/1fd7a38b452cfcedbe26bee721a659c0)|Win32 EXE||2019-04-25 10:18:38|injected_3a14ea4d16ab059577bfee748b032a8e879095d9_fd9f8ab9e3235be1b359ba12075044bda2a9ba5d|
|[9de35edb5da909b84d2b4f1176a835b6](https://www.virustotal.com/gui/file/9de35edb5da909b84d2b4f1176a835b6)|Win32 EXE||2019-04-25 10:18:21|injected_1c99696330be3daff1b633ba9ba5b79a62a56fcb|
|[183d04fbd11553b2d650303a9118e294](https://www.virustotal.com/gui/file/183d04fbd11553b2d650303a9118e294)|Win32 EXE||2019-04-18 18:07:01| |
|[f2d02e1fde6eadfe1429eeebe99c6c95](https://www.virustotal.com/gui/file/f2d02e1fde6eadfe1429eeebe99c6c95)|Win32 EXE||2019-04-15 08:45:54|dllhost.exe.bin|
|[35ea5e4ce3f78c2d2e4c928f6be7e756](https://www.virustotal.com/gui/file/35ea5e4ce3f78c2d2e4c928f6be7e756)|Win32 DLL|razy|2019-03-11 12:37:40|35ea5e4ce3f78c2d2e4c928f6be7e756.virus|
|[d95fa92c21768687625d031c99d75989](https://www.virustotal.com/gui/file/d95fa92c21768687625d031c99d75989)|Win32 DLL|razy|2019-01-25 05:53:13|d95fa92c21768687625d031c99d75989.virus|
|[84fca27bc75f40194c95534b07838d6c](https://www.virustotal.com/gui/file/84fca27bc75f40194c95534b07838d6c)|RTF|CVE-2018-0802|2019-01-22 07:25:18|QĐ Tổng cục.doc|
|[6d2e6a61eede06fa9d633ce151208831](https://www.virustotal.com/gui/file/6d2e6a61eede06fa9d633ce151208831)|Win32 DLL|Ursu|2019-01-02 17:52:49|QcLite.dll|
|[40cfeb699d239652dd4a79c18b1c7366](https://www.virustotal.com/gui/file/40cfeb699d239652dd4a79c18b1c7366)|RTF|CVE-2018-0802|2019-01-02 03:59:41|508732|
|[c6a73e29c770065b4911ef46285d6557](https://www.virustotal.com/gui/file/c6a73e29c770065b4911ef46285d6557)|Win32 DLL||2018-12-27 09:55:39|eb0b848f18d8002aaf59faca18b28941df67dc46891868b96fa4daf03018d148.sample|
|[30528dc0c1e123dff51f40301cc03204](https://www.virustotal.com/gui/file/30528dc0c1e123dff51f40301cc03204)|RTF|CVE-2018-0802|2018-12-27 05:31:35|virus|
|[10348b56b0e3466f9f9fa62bda081c98](https://www.virustotal.com/gui/file/10348b56b0e3466f9f9fa62bda081c98)|RTF|CVE-2018-0802|2018-12-20 06:27:03|78965.doc|
|[45746a0a686750cb9f6775eee63d1f23](https://www.virustotal.com/gui/file/45746a0a686750cb9f6775eee63d1f23)|RTF|CVE-2018-0802|2018-11-28 09:13:22|Danh sach lop CCLLCT K69B03 - bo sung (1).doc|
|[dbb128b6a18cc7ac89041581c58f3e28](https://www.virustotal.com/gui/file/dbb128b6a18cc7ac89041581c58f3e28)|RTF|CVE-2018-0802|2018-11-05 23:51:32|TT.doc|
|[e228045ef57fb8cc1226b62ada7eee9b](https://www.virustotal.com/gui/file/e228045ef57fb8cc1226b62ada7eee9b)|RTF|CVE-2018-0802|2018-10-29 14:46:59|=?UTF-8?B?UVVZIENI4bq+IFbhu4AgSOG7mCBDSEnhur5VIE5HT+G6oEkgR0lBTy5kb2M=?=|
|[0a79949e454be32e6ab96808657969c6](https://www.virustotal.com/gui/file/0a79949e454be32e6ab96808657969c6)|RTF|CVE-2017-8759|2018-09-28 11:33:30|mal.rtf|
|[9e3dcc980bb4c1ce69048b6b5eeea823](https://www.virustotal.com/gui/file/9e3dcc980bb4c1ce69048b6b5eeea823)|Win32 EXE|Virut|2018-09-25 23:18:46| |
|[bd052811fffe5cc1e908a21a873fd43d](https://www.virustotal.com/gui/file/bd052811fffe5cc1e908a21a873fd43d)|Win32 DLL|Symmi|2018-09-25 22:30:53|bd052811fffe5cc1e908a21a873fd43d.virus|
|[d00775c66fa4835f1f427ff873b64cba](https://www.virustotal.com/gui/file/d00775c66fa4835f1f427ff873b64cba)|Win32 EXE|Virut|2018-09-25 19:14:16| |
|[bdaa11e64d00b25c99c254f0c2f5787f](https://www.virustotal.com/gui/file/bdaa11e64d00b25c99c254f0c2f5787f)|Win32 DLL|virtob|2018-09-25 14:36:51| |
|[b9a1fa2edb4eeb270b7c7e18e963ba5f](https://www.virustotal.com/gui/file/b9a1fa2edb4eeb270b7c7e18e963ba5f)|Win32 DLL|kazy|2018-09-25 14:04:08| |
|[294d7e213525c0bcb70b07667d789d6d](https://www.virustotal.com/gui/file/294d7e213525c0bcb70b07667d789d6d)|Win32 DLL|FakeLPK|2018-09-24 23:56:47| |
|[6a18a43b9c12ba82e7ef413d17bcc36b](https://www.virustotal.com/gui/file/6a18a43b9c12ba82e7ef413d17bcc36b)|Win32 DLL|virtob|2018-09-24 23:51:29| |
|[7a86f39d1a551bfb648856bc99fb10f9](https://www.virustotal.com/gui/file/7a86f39d1a551bfb648856bc99fb10f9)|Win32 DLL|pornoblocker|2018-09-24 23:41:34|myfile.exe|
|[88019fceae0b787d09ecdbd454a2b40e](https://www.virustotal.com/gui/file/88019fceae0b787d09ecdbd454a2b40e)|Win32 EXE|Parite|2018-09-24 22:26:33| |
|[58458a529d4ff6848be58ba26349749d](https://www.virustotal.com/gui/file/58458a529d4ff6848be58ba26349749d)|Win32 EXE|Virut|2018-09-24 18:08:06| |
|[03093a21dd46c916c846d2244dbf2bcb](https://www.virustotal.com/gui/file/03093a21dd46c916c846d2244dbf2bcb)|Win32 DLL|Parite|2018-09-24 15:19:07|myfile.exe|
|[d1e675aff0d308fece6194a7b629a6bd](https://www.virustotal.com/gui/file/d1e675aff0d308fece6194a7b629a6bd)|Win32 EXE|Virut|2018-09-24 08:19:43|102|
|[4ce12bbc292b9dd3a641b7e0483e8193](https://www.virustotal.com/gui/file/4ce12bbc292b9dd3a641b7e0483e8193)|Win64 EXE||2018-09-24 04:42:50|SecConfig.efi|
|[bc25bbf8a5bb344da9aef282fdab57cf](https://www.virustotal.com/gui/file/bc25bbf8a5bb344da9aef282fdab57cf)|Win32 EXE|Virut|2018-09-23 17:45:43|server|
|[d999a22ff6b541817221bd74e1d55f9f](https://www.virustotal.com/gui/file/d999a22ff6b541817221bd74e1d55f9f)|Win32 DLL|virtob|2018-09-23 12:51:01|d999a22ff6b541817221bd74e1d55f9f.virus|
|[f443b38ba80c228bf0d7defc9d8c18c5](https://www.virustotal.com/gui/file/f443b38ba80c228bf0d7defc9d8c18c5)|Win32 EXE|Virut|2018-09-23 12:44:08|server|
|[18d5de92036241d0d49b186840bdcc30](https://www.virustotal.com/gui/file/18d5de92036241d0d49b186840bdcc30)|Win32 DLL|virtob|2018-09-23 12:13:36|18d5de92036241d0d49b186840bdcc30.virobj|
|[1f9e6cfef0216755d6a9cec2fab0f5dc](https://www.virustotal.com/gui/file/1f9e6cfef0216755d6a9cec2fab0f5dc)|Win32 DLL||2018-09-23 06:38:52|1f9e6cfef0216755d6a9cec2fab0f5dc.virus|
|[083fd97c06babdb441f34cbb489d5a50](https://www.virustotal.com/gui/file/083fd97c06babdb441f34cbb489d5a50)|Win32 DLL|virtob|2018-09-23 05:20:20|083fd97c06babdb441f34cbb489d5a50.virobj|
|[239edaf861ddeb43113d913d081c48a1](https://www.virustotal.com/gui/file/239edaf861ddeb43113d913d081c48a1)|Win32 EXE|Virut|2018-09-23 03:47:26| |
|[d78ac51f69c511199bbe79a683037672](https://www.virustotal.com/gui/file/d78ac51f69c511199bbe79a683037672)|Win32 EXE||2018-09-23 03:27:48|_zerol_wsasme.exe|
|[232a788c66bbf24c556ad30997d61ff8](https://www.virustotal.com/gui/file/232a788c66bbf24c556ad30997d61ff8)|Win32 DLL||2018-09-22 20:53:04|232a788c66bbf24c556ad30997d61ff8.virus|
|[a87bd421844b838d487c1d94f7d06bc6](https://www.virustotal.com/gui/file/a87bd421844b838d487c1d94f7d06bc6)|Win32 DLL|razy|2018-09-22 12:49:30| |
|[2645eac10876fbe03976af2f69273f0a](https://www.virustotal.com/gui/file/2645eac10876fbe03976af2f69273f0a)|Win32 EXE|Virut|2018-09-22 11:12:31| |
|[a67c747837b14de1dbf6534aaf940731](https://www.virustotal.com/gui/file/a67c747837b14de1dbf6534aaf940731)|Win32 EXE|microfake|2018-09-22 11:08:55| |
|[f04afc1c31dacc002933a1f929d7b303](https://www.virustotal.com/gui/file/f04afc1c31dacc002933a1f929d7b303)|Win32 EXE||2018-09-22 09:42:45|QcConsol.exe|
|[5408ef844e2aeba3092d379420797078](https://www.virustotal.com/gui/file/5408ef844e2aeba3092d379420797078)|Win32 DLL|agentwdcr|2018-09-22 01:25:36|5408ef844e2aeba3092d379420797078.virus|
|[197cb8eaf3797318f49a01a53b6b6372](https://www.virustotal.com/gui/file/197cb8eaf3797318f49a01a53b6b6372)|Win32 DLL|virtob|2018-09-21 13:05:51| |
|[fc150c86b40d094ffa1d74346c519b7a](https://www.virustotal.com/gui/file/fc150c86b40d094ffa1d74346c519b7a)|Win32 EXE|Virut|2018-09-21 12:21:36|myfile.exe|
|[ec9d4ea6d94186185edc08bb588355c9](https://www.virustotal.com/gui/file/ec9d4ea6d94186185edc08bb588355c9)|Win32 EXE|Virut|2018-09-21 11:10:34| |
|[bdf46dd26d747ce97b8a45410a9cdc85](https://www.virustotal.com/gui/file/bdf46dd26d747ce97b8a45410a9cdc85)|Win32 DLL|virtob|2018-09-21 08:23:01|bdf46dd26d747ce97b8a45410a9cdc85.virus|
|[04f540671bfad403eb18569575a0add5](https://www.virustotal.com/gui/file/04f540671bfad403eb18569575a0add5)|Win32 EXE|razy|2018-09-21 02:18:52| |
|[d2961d64ecb9d22ef8b6d7280d818a29](https://www.virustotal.com/gui/file/d2961d64ecb9d22ef8b6d7280d818a29)|Win32 DLL|microfake|2018-09-20 18:24:17|lpk.dll|
|[10fa0058d6bdb26ae3e7880a9f6f1c87](https://www.virustotal.com/gui/file/10fa0058d6bdb26ae3e7880a9f6f1c87)|Win32 DLL|microfake|2018-09-20 00:42:04|10fa0058d6bdb26ae3e7880a9f6f1c87.virus|
|[40223513419edaea286c431eba5d1449](https://www.virustotal.com/gui/file/40223513419edaea286c431eba5d1449)|Win32 DLL|kazy|2018-09-20 00:40:12|40223513419edaea286c431eba5d1449.virus|
|[8f3b0daeaa04150b76ca9a3ddca7889c](https://www.virustotal.com/gui/file/8f3b0daeaa04150b76ca9a3ddca7889c)|Win32 DLL|kazy|2018-09-20 00:34:23|8f3b0daeaa04150b76ca9a3ddca7889c.virus|
|[2e99cdf7829a5714bd76d8c793039ec6](https://www.virustotal.com/gui/file/2e99cdf7829a5714bd76d8c793039ec6)|Win32 DLL||2018-09-20 00:33:59|2e99cdf7829a5714bd76d8c793039ec6.virus|
|[6c9d7a0f84c1bc18725fa59990c7abd8](https://www.virustotal.com/gui/file/6c9d7a0f84c1bc18725fa59990c7abd8)|Win32 DLL|kazy|2018-09-20 00:33:42|6c9d7a0f84c1bc18725fa59990c7abd8.virus|
|[2e73102f59a5f319414626e6ad7df6e2](https://www.virustotal.com/gui/file/2e73102f59a5f319414626e6ad7df6e2)|Win32 DLL||2018-09-20 00:33:03|2e73102f59a5f319414626e6ad7df6e2.virus|
|[8707578cc25e4047507ee293dea0d037](https://www.virustotal.com/gui/file/8707578cc25e4047507ee293dea0d037)|Win32 DLL|kazy|2018-09-20 00:23:52|8707578cc25e4047507ee293dea0d037.virus|
|[38b37cd02c736bb7b9a3fa77bb4095ce](https://www.virustotal.com/gui/file/38b37cd02c736bb7b9a3fa77bb4095ce)|Win32 DLL|microfake|2018-09-20 00:20:10|38b37cd02c736bb7b9a3fa77bb4095ce.virus|
|[11d364135c1012d8c584b18cb390757d](https://www.virustotal.com/gui/file/11d364135c1012d8c584b18cb390757d)|Win32 EXE|Virut|2018-09-19 22:14:40| |
|[1e9cdcb22b2e6a34d01b911820334942](https://www.virustotal.com/gui/file/1e9cdcb22b2e6a34d01b911820334942)|Win32 DLL||2018-09-09 17:16:37|.|
|[438944220df1b3b7942ce7263150361f](https://www.virustotal.com/gui/file/438944220df1b3b7942ce7263150361f)|RTF|o97m|2018-09-04 04:41:03|438944220df1b3b7942ce7263150361f-rtf|
|[c594d38ed3b243bd549457f213527b34](https://www.virustotal.com/gui/file/c594d38ed3b243bd549457f213527b34)|RTF|o97m|2018-08-24 04:04:59|=?UTF-8?B?TeG6q3UgYsOgaSB0aHUgaG/huqFjaCBo4buNYyB04bqtcCBOZ2jhu4sgcXV54bq/dCBUcnVuZyDGsMahbmcgNyBraG/DoSAxMi5kb2M=?=|
|[f1b352680bda1c2c7e04f4ae94f56a46](https://www.virustotal.com/gui/file/f1b352680bda1c2c7e04f4ae94f56a46)|Win32 DLL|Zbot|2018-07-28 12:50:22|f1b352680bda1c2c7e04f4ae94f56a46.virus|
|[90f4ca70fddcde6e77eb4f64e19b5146](https://www.virustotal.com/gui/file/90f4ca70fddcde6e77eb4f64e19b5146)|RTF||2018-04-23 06:24:47|=?UTF-8?B?0J/RgNC+0YLQvtC60L7QuyAyNjguZG9j?=|
|[c56c50c7e98f717ce0138620fb30b2c0](https://www.virustotal.com/gui/file/c56c50c7e98f717ce0138620fb30b2c0)|RTF||2018-04-22 20:39:30|722e5d3dcc8945f69135dc381a15b5cad9723cd11f7ea20991a3ab867d9428c7.bin|
|[d64161db327f4ec91d458a00293c62b0](https://www.virustotal.com/gui/file/d64161db327f4ec91d458a00293c62b0)|RTF|CVE-2017-11882|2018-04-04 08:39:04|d64161db327f4ec91d458a00293c62b0.virobj|
|[460572cc2326ad0cb62fd3517278cf8d](https://www.virustotal.com/gui/file/460572cc2326ad0cb62fd3517278cf8d)|RTF|o97m|2018-03-27 04:21:35|phu luc CNTT 2018.doc|
|[9c7297f032b5c1cfbc2d819815f72f80](https://www.virustotal.com/gui/file/9c7297f032b5c1cfbc2d819815f72f80)|RTF||2018-03-07 08:22:04|Tin Chính Hiệp toàn quốc Trung Quốc- 180307.doc|
|[de1b9f9086d7aa0685c07a62d2f9bd21](https://www.virustotal.com/gui/file/de1b9f9086d7aa0685c07a62d2f9bd21)|Win32 DLL|Ursu|2018-02-01 11:48:39|myfile.exe|
|[45a94b3b13101c932a72d89ff5eb715a](https://www.virustotal.com/gui/file/45a94b3b13101c932a72d89ff5eb715a)|RTF|CVE-2017-11882|2018-02-01 08:27:24|=?UTF-8?B?QsOhbyBjw6FvLmRvYw==?=|
|[f223e4175649fa2e34271db8c968db12](https://www.virustotal.com/gui/file/f223e4175649fa2e34271db8c968db12)|RTF|o97m|2018-01-31 02:34:04|9d0c4ec62abe79e754eaa2fd7696f98441bc783781d8656065cddfae3dbf503e.bin|
|[07544892999b91ae2c9280d8ee3c663a](https://www.virustotal.com/gui/file/07544892999b91ae2c9280d8ee3c663a)|RTF|o97m|2018-01-17 04:08:56|=?UTF-8?B?Q8OhYyBk4buxIMOhbiDhu6luZyBwaMOzIGJp4bq/biDEkeG7lWkga2jDrSBo4bqtdSBH4bq3cCBuaGnhu4F1IHbGsOG7m25nIG3huq9jLmRvYw==?=|
|[2eb3b85fb1f5c79879ee0e6623da4754](https://www.virustotal.com/gui/file/2eb3b85fb1f5c79879ee0e6623da4754)|RTF||2018-01-16 10:12:07|Danh sach phim sex.doc|
|[f8bbb28e84324eb4d72f8f852a5086d8](https://www.virustotal.com/gui/file/f8bbb28e84324eb4d72f8f852a5086d8)|RTF|o97m|2018-01-10 08:22:23|CP2017.12.doc|
|[aca7037286b64b0da05c9708d647c013](https://www.virustotal.com/gui/file/aca7037286b64b0da05c9708d647c013)|RTF|o97m|2017-12-06 18:13:06|Questions about the story.rtf|
|[ac9157fb554804636893154bf9b6c8e3](https://www.virustotal.com/gui/file/ac9157fb554804636893154bf9b6c8e3)|Win32 EXE|Symmi|2016-03-06 07:25:48|server|
|[fee0b982af421ff8c16c0187b376b086](https://www.virustotal.com/gui/file/fee0b982af421ff8c16c0187b376b086)|Win32 DLL||2014-08-19 06:15:26|%TEMP%\360drvmgr\sqlite3.dll|
|[f9a00b2264b08435553b6b94098504f4](https://www.virustotal.com/gui/file/f9a00b2264b08435553b6b94098504f4)|Win32 EXE|FakeLPK|2014-04-20 00:49:51|b70c106991a7577f31efeace40fc1dded28389c4|
|[0662e0e6e2db47c65ff600678007312a](https://www.virustotal.com/gui/file/0662e0e6e2db47c65ff600678007312a)|Win32 DLL|kazy|2011-07-03 14:17:03|/home/nfs/data/VirusShare_unzip/VirusShare_0662e0e6e2db47c65ff600678007312a|
|[bd19302a58133803622e119080a5ceda](https://www.virustotal.com/gui/file/bd19302a58133803622e119080a5ceda)|Win32 EXE||2011-01-26 07:33:06|ScnCfg.exe|
|[ab4ed49e594e6e31ab31ca4e411525ad](https://www.virustotal.com/gui/file/ab4ed49e594e6e31ab31ca4e411525ad)|Win32 EXE|Rincux|2010-06-30 12:21:35|ccuwco.exe|
|[109d51899c832287d7ce1f70b5bd885d](https://www.virustotal.com/gui/file/109d51899c832287d7ce1f70b5bd885d)|Win32 EXE||2010-04-18 15:04:38|QcConsol.exe|
|[62944e26b36b1dcace429ae26ba66164](https://www.virustotal.com/gui/file/62944e26b36b1dcace429ae26ba66164)|Win32 EXE||2009-05-30 17:58:55|dot1xtray|
|[5fd6b30d0e9d0bf6c388f8c8cbf9823e](https://www.virustotal.com/gui/file/5fd6b30d0e9d0bf6c388f8c8cbf9823e)|Win32 DLL|Pcclient|2008-02-16 18:15:42|/home/nfs/data/VirusShare_unzip/VirusShare_5fd6b30d0e9d0bf6c388f8c8cbf9823e|
|[2e522ce8104c0693288c997604ae0096](https://www.virustotal.com/gui/file/2e522ce8104c0693288c997604ae0096)|Win32 DLL||2020-04-06 02:50:40|goopdate.dll|
|[6d1876c07d176185dc61310b9aa510fe](https://www.virustotal.com/gui/file/6d1876c07d176185dc61310b9aa510fe)|unknown||2020-02-12 18:57:30|stdole.tlb|
|[42c1a3a74cec2dc4a1c1a7a10d9d14e4](https://www.virustotal.com/gui/file/42c1a3a74cec2dc4a1c1a7a10d9d14e4)|Win32 DLL||2020-02-06 16:30:02|./KISA_dataset_2020_train/ff959426156717926c20477710bc0db15d0300fba1fe184ad16ee20807302c16.vir|
|[7edeb624f2fef843ed26f24f3dd01a3f](https://www.virustotal.com/gui/file/7edeb624f2fef843ed26f24f3dd01a3f)|unknown||2020-02-06 08:30:24|ace641e02fe4d099a0eeccde08ffe45148a011e01720f3f5ea1b6b17f287044d.bin|
|[e9ba8cc1119dc4a972d0d363edcc0101](https://www.virustotal.com/gui/file/e9ba8cc1119dc4a972d0d363edcc0101)|RTF|CVE-2018-0802|2020-02-06 07:28:13|100ded4eeffbd9c927cccd7850a3e83a2fb7b127e40e03f1570bbf6939cbb5fe.bin|
|[6ea33305b5f0f703f569b9ebd6035bfd](https://www.virustotal.com/gui/file/6ea33305b5f0f703f569b9ebd6035bfd)|Win32 DLL|Ursu|2020-02-03 04:28:09|IGFXEM|
|[d8db9d6585d558ba2d28c33c6fc61874](https://www.virustotal.com/gui/file/d8db9d6585d558ba2d28c33c6fc61874)|Win32 DLL||2019-09-30 09:07:00|Detected_File_588D0B595A809CC8F04EC5A8A0C3F5DF957F7E40_20190930104410+0700|
|[a02e2796e0be9d84ee0d4b205673ec20](https://www.virustotal.com/gui/file/a02e2796e0be9d84ee0d4b205673ec20)|Win32 DLL|Waldek|2019-05-17 20:24:06|27f88f624608698f9cadca58558d96e27a93e1c526fb38f5bef3cb178b23e32b.bin|
|[1b19175c41b9a9881b23b4382cc5935f](https://www.virustotal.com/gui/file/1b19175c41b9a9881b23b4382cc5935f)|Win32 DLL||2018-10-30 04:02:24|%APPDATA%\roaming\microsoft\windows\printer shortcuts\qclite.dll|
|[81660985276cf9b6d979753b6e581d34](https://www.virustotal.com/gui/file/81660985276cf9b6d979753b6e581d34)|Win32 EXE|occamy|2018-10-22 09:14:03| |
|[6be1362d722ba4224979de91a2cd6242](https://www.virustotal.com/gui/file/6be1362d722ba4224979de91a2cd6242)|Win32 DLL|Ursu|2018-09-21 05:19:54|625bc62c9bd9e491839da3d77cc85f47aa57c0ef847107c922403783014ce75e.bin|
|[88cdd3ce6e5baa49dc69da664edee5c1](https://www.virustotal.com/gui/file/88cdd3ce6e5baa49dc69da664edee5c1)|Win32 DLL|Graftor|2018-09-19 05:36:42|C:\Users\<USER>\AppData\Local\Temp\88cdd3ce6e5baa49dc69da664edee5c1.dll|
|[4a21f9b508db19398aee7fe4ae0ac380](https://www.virustotal.com/gui/file/4a21f9b508db19398aee7fe4ae0ac380)|Win32 DLL|Graftor|2018-09-19 05:31:45|C:\Users\<USER>\AppData\Local\Temp\4a21f9b508db19398aee7fe4ae0ac380.dll|
|[2fb731903bd12ff61e6f778fdf9926ee](https://www.virustotal.com/gui/file/2fb731903bd12ff61e6f778fdf9926ee)|Win32 DLL|Graftor|2018-09-18 04:41:43| |
|[a9bcf983fe868a275f8d9d8f5defacf5](https://www.virustotal.com/gui/file/a9bcf983fe868a275f8d9d8f5defacf5)|Win32 DLL|Graftor|2018-09-14 19:52:50| |
|[782ff651f34c87448e4503b5444b6164](https://www.virustotal.com/gui/file/782ff651f34c87448e4503b5444b6164)|Win32 DLL|Ursu|2018-09-14 05:04:44|C:\Users\<USER>\AppData\Local\Temp\782ff651f34c87448e4503b5444b6164.dll|
|[a4ad564f8fe80e2ee52e643e449c487d](https://www.virustotal.com/gui/file/a4ad564f8fe80e2ee52e643e449c487d)|Win32 DLL|Graftor|2018-09-13 22:36:51|541ae0c502b45aebc55c4daefcdeed09cb4483b683ed3feb67ddcd929e604dc8.bin|
|[c73b000313dcd2289f51b367f744dcd8](https://www.virustotal.com/gui/file/c73b000313dcd2289f51b367f744dcd8)|Win32 DLL|Graftor|2018-09-13 05:00:08| |
|[7789055b0836a905d9aa68b1d4a50f09](https://www.virustotal.com/gui/file/7789055b0836a905d9aa68b1d4a50f09)|Win32 DLL|occamy|2018-07-17 08:31:48|C:\Users\<USER>\AppData\Local\Temp\7789055b0836a905d9aa68b1d4a50f09.dll|
|[809196a64ca4a32860d28760267a1a8b](https://www.virustotal.com/gui/file/809196a64ca4a32860d28760267a1a8b)|Win32 EXE|Glupteba|2018-01-31 07:53:47|ctfmon.exe|
|[1640ee7a414dff996af8265e0947de36](https://www.virustotal.com/gui/file/1640ee7a414dff996af8265e0947de36)|Win32 EXE|pswtool|2016-10-31 20:01:36| |
|[3ca7bd71b30007fc30717290bb437152](https://www.virustotal.com/gui/file/3ca7bd71b30007fc30717290bb437152)|Win32 DLL|Skeeyah|2016-10-01 08:08:48|fdf18d1a41a4983fa6ca9ce592583f96475481c57ef73fd3ca3b97770810d50c.bin|
|[1ea07468ebdfd3d9eec59ac57a490701](https://www.virustotal.com/gui/file/1ea07468ebdfd3d9eec59ac57a490701)|Win32 EXE|Johnnie|2016-08-31 02:11:46|chromepass.exe|
|[58fe8db0f7ae505346f6e4687d0ae233](https://www.virustotal.com/gui/file/58fe8db0f7ae505346f6e4687d0ae233)|Win32 DLL||2015-07-04 16:17:40|79b581cd154266bc771c70da42598276a571ab8692c2471957524e1159b4b61b.bin|
|[a44804c2767dccd4902aae30c36e62c0](https://www.virustotal.com/gui/file/a44804c2767dccd4902aae30c36e62c0)|Win32 EXE|Glupteba|2013-12-04 07:05:34|crack_hd.exe|
