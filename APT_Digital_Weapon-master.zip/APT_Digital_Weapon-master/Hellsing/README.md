**NAME:**  
Hellsing  
  
**Alias**  
Goblin Panda, Cycldek, Conimes, Gobelin Panda, Hellsing  

**Description**:   
The Hellsing APT group, uncovered by Kaspersky, is active in the APAC region, hitting targets mainly in the South China Sea area, with a focus on Malaysia, the Philippines and Indonesia. The targeting of the Naikon group by the Hellsing APT is perhaps the most interesting part, since it seems more likely to be an APT-on-APT attack.
  
**References**:  
https://securelist.com/the-chronicles-of-the-hellsing-apt-the-empire-strikes-back/69567/