|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[85e397114c401b0671ff74e7177cc361](https://www.virustotal.com/gui/file/85e397114c401b0671ff74e7177cc361)|Android||2019-07-15 21:32:51|85e397114c401b0671ff74e7177cc361.virus|
|[ea79617ba045e118ca26a0e39683700d](https://www.virustotal.com/gui/file/ea79617ba045e118ca26a0e39683700d)|Text||2017-12-08 05:40:15|ea79617ba045e118ca26a0e39683700d.virus|
|[871e4e5036c7909d6fd9f23285ff39b5](https://www.virustotal.com/gui/file/871e4e5036c7909d6fd9f23285ff39b5)|Win32 EXE|MSILPerseus|2017-05-04 01:07:06|1595747c1dd71c33a99b720821da420400daa033adcaa4c3d3b7fc34b527d60d.bin|
|[bdaaf37d1982a7221733c4cae17eccf8](https://www.virustotal.com/gui/file/bdaaf37d1982a7221733c4cae17eccf8)|Win32 EXE|keylogger|2017-05-03 07:10:32|76a75722021de6cbcabf6ea560ca2ac8ae817f0d659f9f363a74a9e1b14f0115.bin|
|[3f00799368f029c38cea4a1a56389ab7](https://www.virustotal.com/gui/file/3f00799368f029c38cea4a1a56389ab7)|unknown|Nemucod|2016-10-01 18:04:26|Malware (370).exe|
|[11b61b531a7bbc7668d7d346e4a17d5e](https://www.virustotal.com/gui/file/11b61b531a7bbc7668d7d346e4a17d5e)|Win32 EXE|kryptik|2015-10-19 16:33:25|NJ.exe|
|[a4e6c15984a86f2a102ad67fa870a844](https://www.virustotal.com/gui/file/a4e6c15984a86f2a102ad67fa870a844)|Win32 EXE||2015-04-14 02:05:40|SERVER PRO WEB.exe|
