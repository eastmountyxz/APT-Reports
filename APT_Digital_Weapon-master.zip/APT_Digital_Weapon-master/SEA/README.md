**NAME:**  
SEA  
  
**Description**:   
SEA, the Syrian Electronic Network Army, first appeared on the Internet in 2011 to support the Syrian President’s Ashad government through spam, website scams, malware, phishing and denial-of-service attacks to attack opposition parties, Western news organizations, and human rights organizations. It also invaded government websites in the Middle East and Europe as well as US defense contractors.

**References**:  
http://www.crowdstrike.com/blog/dns-lifeblood-your-domain/  
https://i.blackhat.com/eu-18/Wed-Dec-5/eu-18-DelRosso-Under-the-SEA.pdf
