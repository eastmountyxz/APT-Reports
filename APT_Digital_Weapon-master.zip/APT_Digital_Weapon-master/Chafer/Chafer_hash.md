|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[aade920e20a448f464aef752282a6267](https://www.virustotal.com/gui/file/aade920e20a448f464aef752282a6267)|Win32 EXE||2019-10-12 20:00:29|SIW|
|[9bd9a775ef26d8f4983a431b6eb3fcd7](https://www.virustotal.com/gui/file/9bd9a775ef26d8f4983a431b6eb3fcd7)|Text||2019-07-27 15:33:23|payload_1.exe|
|[7b16fc361b8e5092a6de246c5de3a37e](https://www.virustotal.com/gui/file/7b16fc361b8e5092a6de246c5de3a37e)|XLS|o97m|2019-07-27 13:26:13|7b16fc361b8e5092a6de246c5de3a37e.bin|
|[12477223678e4a41020e66faebd3dd95](https://www.virustotal.com/gui/file/12477223678e4a41020e66faebd3dd95)|Win32 EXE||2019-03-05 04:21:18| |
|[f6bf3fcebd42101b1018c6bb74723922](https://www.virustotal.com/gui/file/f6bf3fcebd42101b1018c6bb74723922)|C++||2018-12-17 19:04:44|dttcodexgigas.2b25e3a857a4b387370e42f172acf3b1dcd0263d|
|[903fc33fb5881cb720198049a107c980](https://www.virustotal.com/gui/file/903fc33fb5881cb720198049a107c980)|C++||2018-12-17 19:04:43|dttcodexgigas.601815c6fadc9df28d41cf9c70175fd140bb1cf9|
|[2eb13a66d5e70aab5a463b56c5a13105](https://www.virustotal.com/gui/file/2eb13a66d5e70aab5a463b56c5a13105)|Text||2018-12-17 19:04:38|dttcodexgigas.cba5c3e9acb0cbdd62773f11665e8332cfbfde54|
|[c1739917346e323755319a6008008b35](https://www.virustotal.com/gui/file/c1739917346e323755319a6008008b35)|Text||2018-12-17 19:04:38|dttcodexgigas.7a7bbcd3a626986fee22c7ba48aea7f0fa33cf74|
|[ede89b446d8703dd13d26168e8d58865](https://www.virustotal.com/gui/file/ede89b446d8703dd13d26168e8d58865)|unknown||2018-09-19 16:09:49|srv.dat|
|[7c08601341888b413779a3b33d8bf6dc](https://www.virustotal.com/gui/file/7c08601341888b413779a3b33d8bf6dc)|unknown||2018-09-19 15:25:27|srv_2 (1).dat|
|[25469ddaeff0dd3edb0f39bbe1dcdc46](https://www.virustotal.com/gui/file/25469ddaeff0dd3edb0f39bbe1dcdc46)|Win32 EXE|Ursu|2018-09-05 17:14:46|6a5bd102ca26aa0dd11bd7b74da378b7e9969e1ab0f80c4eb597adc0b94b4fc4.bin|
|[7b000bafeb5549dce2010df832a2f664](https://www.virustotal.com/gui/file/7b000bafeb5549dce2010df832a2f664)|Win64 EXE||2018-06-01 15:38:00| |
|[804460a4934947b5131ca79d9bd668cf](https://www.virustotal.com/gui/file/804460a4934947b5131ca79d9bd668cf)|Win32 EXE||2017-12-06 09:03:04|Windows-KB3101246.exe|
|[b38561661a7164e3bbb04edc3718fe89](https://www.virustotal.com/gui/file/b38561661a7164e3bbb04edc3718fe89)|Win32 DLL||2017-08-01 02:17:26|C:\Users\<USER>\AppData\Local\Temp\nsa357.tmp\nsExec.dll|
|[4bf178f778255b6e72a317c2eb8f4103](https://www.virustotal.com/gui/file/4bf178f778255b6e72a317c2eb8f4103)|Win32 EXE||2017-07-11 21:10:37|1e94a1ca83123688215b64369a37162448a0f3927e3f0f4f412ee352db6abf5c.bin|
|[5aee0c0a06ea91102649bed484c88147](https://www.virustotal.com/gui/file/5aee0c0a06ea91102649bed484c88147)|Text||2017-01-04 07:43:14|U1848931.TMP|
|[ecae141bb068131108c1cd826c82d88b](https://www.virustotal.com/gui/file/ecae141bb068131108c1cd826c82d88b)|Win32 EXE||2016-12-08 02:47:52|9d9853bf843f8fc221ff1ccf04e08c331d7e0a43b33280767c6c6f96c64b2044.bin|
|[c6721344af76403e9a7d816502dca1c8](https://www.virustotal.com/gui/file/c6721344af76403e9a7d816502dca1c8)|Win32 EXE|bitrep|2016-04-21 09:01:50|Splitter.exe|
|[d0e74da12c5e8d35f6db1ae0c60748b7](https://www.virustotal.com/gui/file/d0e74da12c5e8d35f6db1ae0c60748b7)|Win64 EXE||2018-08-21 08:02:03|mnl.exe|
|[16b9d761c4b583b56dea276b1d980734](https://www.virustotal.com/gui/file/16b9d761c4b583b56dea276b1d980734)|Win64 DLL|occamy|2017-05-09 05:22:51|MAI.dll|
|[efbd849619aee8bd3429dd9ccb2a1995](https://www.virustotal.com/gui/file/efbd849619aee8bd3429dd9ccb2a1995)|Win32 EXE||2016-11-15 13:16:16|%userprofile%\downloads\downloads\xnet.exe|
|[894fd325751465d6f48c17106a1a91d1](https://www.virustotal.com/gui/file/894fd325751465d6f48c17106a1a91d1)|Win64 DLL||2015-11-11 21:07:31|98a9b2329eefe618daa78b6afed82cebf40cb918ad0aae7a8d7f59af4cb13b41.kafan|
|[dc5695024cd23c90883db145cb236490](https://www.virustotal.com/gui/file/dc5695024cd23c90883db145cb236490)|Win32 EXE||2014-09-24 10:54:30|Plink|
|[dd9589b206791307d25e63d793c2ca31](https://www.virustotal.com/gui/file/dd9589b206791307d25e63d793c2ca31)|Win32 EXE||2011-04-07 21:26:00|mfevtpse.exe|
