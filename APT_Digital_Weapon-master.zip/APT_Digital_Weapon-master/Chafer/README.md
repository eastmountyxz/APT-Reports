**NAME:**  
Chafer  
  
**Alias**  
APT39, Chafer  
  
**Description**:   
Chafer’s (also known as APT39) focus on the telecommunications and travel industries suggests intent to perform monitoring, tracking, or surveillance operations against specific individuals. While its targeting scope is global, the activities are concentrated in the Middle East. Government entities targeting suggests a potential secondary intent to collect geopolitical data that may benefit nation-state decision making.
  
**References**:  
https://www.fireeye.com/blog/threat-research/2019/01/apt39-iranian-cyber-espionage-group-focused-on-personal-information.html  
https://mp.weixin.qq.com/s/c2z4laJ0oq5y0BAEFM3Y9w
