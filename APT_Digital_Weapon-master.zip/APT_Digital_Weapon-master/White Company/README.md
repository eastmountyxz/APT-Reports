**NAME:**  
White Company  

**Description**:   
White Company, uncovered by Cylance, is a well-resourced group targeting Pakistan’s Air Force through Operation Shaheen campaign. It possesses considerable resources that support the likelihood that the organization is part of a state-sponsored group.
  
**References**:  
https://www.cylance.com/en-us/company/news-and-press/press-releases/cylance-discovers-new-middle-eastern-APT-actor-the-white-company.html