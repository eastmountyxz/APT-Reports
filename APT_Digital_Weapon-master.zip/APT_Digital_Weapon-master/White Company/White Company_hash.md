|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c6bcd55b2a8822fe8294c149a3e35f00](https://www.virustotal.com/gui/file/c6bcd55b2a8822fe8294c149a3e35f00)|RTF|CVE-2015-1641|2019-06-03 06:23:11|z:\data_manual\rtf\c6bcd55b2a8822fe8294c149a3e35f00|
|[8f8ff36a977468d615d51a5bac07242f](https://www.virustotal.com/gui/file/8f8ff36a977468d615d51a5bac07242f)|Win32 EXE||2018-11-14 00:30:19|done.exe|
|[0edd591ba9fc1c8a4d133eae5e1414b0](https://www.virustotal.com/gui/file/0edd591ba9fc1c8a4d133eae5e1414b0)|Rich Text Format|CVE-2012-0158|2018-05-16 03:57:26|IDUF-01.doc|
|[690002ca27433efdd6c7c40f670f380d](https://www.virustotal.com/gui/file/690002ca27433efdd6c7c40f670f380d)|Win32 EXE||2018-03-28 09:13:04|BBMIM.EXE|
|[66c3900213c4d3997da2300f9cd02db6](https://www.virustotal.com/gui/file/66c3900213c4d3997da2300f9cd02db6)|RTF|CVE-2015-1641|2018-01-13 13:07:35|286C7F2635CABD27907946100D0CC50ACFBB518D3EE791438FAF45573F576D25|
|[58e3de0352abeacb25e65657e6cb3d1a](https://www.virustotal.com/gui/file/58e3de0352abeacb25e65657e6cb3d1a)|RTF|CVE-2015-1641|2017-12-29 00:41:58|/var/www/clean-mx/virusesevidence/output.112769647.txt|
|[422715f91c3d7e41fa561d29950daf02](https://www.virustotal.com/gui/file/422715f91c3d7e41fa561d29950daf02)|RTF|CVE-2015-1641|2017-12-15 03:13:08|95bd063b56b72dafd9f9753bf13d7e394f6ade4b|
|[a04be5dca1be950f164e00fa9163cd81](https://www.virustotal.com/gui/file/a04be5dca1be950f164e00fa9163cd81)|Win32 EXE||2017-12-11 20:29:30|CXVJ.exe|
|[445c476444731ff29d479e373daefcc6](https://www.virustotal.com/gui/file/445c476444731ff29d479e373daefcc6)|Win32 EXE||2017-11-02 15:15:23|myfile.exe|
|[6f454d39f02bc3e75e904a0f2f5edb89](https://www.virustotal.com/gui/file/6f454d39f02bc3e75e904a0f2f5edb89)|Win32 EXE|Fareit|2017-10-30 16:41:02|microsoftdm.exe|
|[1e3dbfd13ade35692303af86fe8c894c](https://www.virustotal.com/gui/file/1e3dbfd13ade35692303af86fe8c894c)|TXT|CVE-2012-0158|2017-10-17 06:42:23|1e3dbfd13ade35692303af86fe8c894c.virus|
|[5ea2ac12ff2ea7672a1b1d088a9056ef](https://www.virustotal.com/gui/file/5ea2ac12ff2ea7672a1b1d088a9056ef)|Win32 EXE|injector|2017-09-11 06:08:28|lHznBFNE.exe|
|[2d4de48d0a524dc5fab1dfeaf8f5bebb](https://www.virustotal.com/gui/file/2d4de48d0a524dc5fab1dfeaf8f5bebb)|Win32 EXE||2017-09-08 04:24:47|keytool|
|[352c2caf621c175e1cb92bdb2e270ba7](https://www.virustotal.com/gui/file/352c2caf621c175e1cb92bdb2e270ba7)|Win32 EXE|revenge|2017-09-07 06:26:27|keytool|
|[987cda2d7593cb61f1432d7955eb2cfd](https://www.virustotal.com/gui/file/987cda2d7593cb61f1432d7955eb2cfd)|RTF|CVE-2015-1641|2017-09-02 20:56:27|1df20ff6e4870100bdb36d93dfe2e9f7e6ae074c|
|[c1995a5c29a2dea9301630550b0d7978](https://www.virustotal.com/gui/file/c1995a5c29a2dea9301630550b0d7978)|Win32 EXE|Disfa|2017-08-31 00:03:09|E:/vt/malware/20170909/c1995a5c29a2dea9301630550b0d7978.vir|
