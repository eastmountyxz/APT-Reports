|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[e3af42af879cd82fd65b30373f805f6b](https://www.virustotal.com/gui/file/e3af42af879cd82fd65b30373f805f6b)|unknown||2019-08-17 00:48:30|repr.pyc|
|[1904cad4927541e47d453becbd934bf0](https://www.virustotal.com/gui/file/1904cad4927541e47d453becbd934bf0)|Win32 EXE||2018-12-20 12:59:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Triton/XenotimeTritonNetExecImplant.bin|
|[9c29c1ab56c939978ad6315d78571fa5](https://www.virustotal.com/gui/file/9c29c1ab56c939978ad6315d78571fa5)|Java|Triton|2018-10-23 17:54:30|script_test.py|
|[d259dc2a015734cdb39df2c0dd2a5ab5](https://www.virustotal.com/gui/file/d259dc2a015734cdb39df2c0dd2a5ab5)|ZIP|Triton|2018-10-23 17:42:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Triton/TRISIS-TRITON-HATMAN-master.zip|
|[4e5797312ed52d9eb80ec19848cadc95](https://www.virustotal.com/gui/file/4e5797312ed52d9eb80ec19848cadc95)|unknown||2018-10-17 02:27:39|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Triton/TritonCRC.bin|
|[8b675db417cc8b23f4c43f3de5c83438](https://www.virustotal.com/gui/file/8b675db417cc8b23f4c43f3de5c83438)|unknown|Triton|2018-09-28 05:32:58|sh.pyc|
|[e98f4f3505f05bf90e17554fbc97bba9](https://www.virustotal.com/gui/file/e98f4f3505f05bf90e17554fbc97bba9)|unknown|Triton|2018-01-26 00:43:10|TS_cnames.pyc|
|[f6b3a73c8c87506acda430671360ce15](https://www.virustotal.com/gui/file/f6b3a73c8c87506acda430671360ce15)|unknown|Triton|2018-01-26 00:43:10|TsLow.pyc|
|[27c69aa39024d21ea109cc9c9d944a04](https://www.virustotal.com/gui/file/27c69aa39024d21ea109cc9c9d944a04)|unknown|Triton|2018-01-25 22:52:15|TsHi.pyc|
|[288166952f934146be172f6353e9a1f5](https://www.virustotal.com/gui/file/288166952f934146be172f6353e9a1f5)|unknown|Triton|2018-01-25 21:39:00|TsBase.pyc|
|[0face841f7b2953e7c29c064d6886523](https://www.virustotal.com/gui/file/0face841f7b2953e7c29c064d6886523)|ZIP|Triton|2017-12-22 12:53:22|VirusShare_0face841f7b2953e7c29c064d6886523|
|[0544d425c7555dc4e9d76b571f31f500](https://www.virustotal.com/gui/file/0544d425c7555dc4e9d76b571f31f500)|unknown||2017-12-22 12:38:09|inject.bin|
|[437f135ba179959a580412e564d3107f](https://www.virustotal.com/gui/file/437f135ba179959a580412e564d3107f)|unknown|Triton|2017-12-22 12:37:36|imain.bin|
|[6c39c3f4a08d3d78f2eb973a94bd7718](https://www.virustotal.com/gui/file/6c39c3f4a08d3d78f2eb973a94bd7718)|Win32 EXE|Triton|2017-08-29 18:21:39|myfile.exe|
|[121772100e46dde2d6317b08c7a59e13](https://www.virustotal.com/gui/file/121772100e46dde2d6317b08c7a59e13)|Win32 EXE||2014-08-12 11:28:13|cryptcat.exe|
|[9a7234078559093e06c9d32148ed95a3](https://www.virustotal.com/gui/file/9a7234078559093e06c9d32148ed95a3)|Win32 DLL||2009-03-29 23:16:46|C54_WRC-8.15_CryptoPP530Fips32.dll|
