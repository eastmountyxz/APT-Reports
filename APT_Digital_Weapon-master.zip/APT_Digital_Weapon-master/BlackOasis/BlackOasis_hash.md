|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4a49135d2ecc07085a8b7c5925a36c0a](https://www.virustotal.com/gui/file/4a49135d2ecc07085a8b7c5925a36c0a)|Win32 EXE|FinSpy|2017-10-12 21:45:40|4a49135d2ecc07085a8b7c5925a36c0a.virus|
