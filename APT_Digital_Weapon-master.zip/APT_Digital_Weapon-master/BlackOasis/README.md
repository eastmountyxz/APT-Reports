**NAME:**  
BlackOasis  

**Description**:   
BlackOasis is a Middle Eastern threat group that is believed to be a customer of Gamma Group. The group has shown interest in prominent figures in the United Nations, as well as opposition bloggers, activists, regional news correspondents, and think tanks. A group known by Microsoft as Neodymium is reportedly associated closely with BlackOasis operations, but evidence to indicate the group names are aliases has not been identified.
  
**References**:  
https://securelist.com/blackoasis-apt-and-new-targeted-attacks-leveraging-zero-day-exploit/82732/  
https://securelist.com/apt-trends-report-q2-2017/79332/  
https://www.cyberscoop.com/middle-eastern-hacking-group-using-finfisher-malware-conduct-international-espionage/  

