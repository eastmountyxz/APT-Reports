|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d9630ae3dfceb77bd3999ff9b48fa422](https://www.virustotal.com/gui/file/d9630ae3dfceb77bd3999ff9b48fa422)|Win32 EXE||2019-10-26 08:51:56|cardsharper.exe|
|[a686576e71821c3a9fcbe608cc055e07](https://www.virustotal.com/gui/file/a686576e71821c3a9fcbe608cc055e07)|XLSX||2019-10-26 08:27:39|request for quotation.xlsx|
|[8e0b8b5200e879d7a4a62df5ea30253a](https://www.virustotal.com/gui/file/8e0b8b5200e879d7a4a62df5ea30253a)|XLS|o97m|2019-06-14 03:11:21|Request and specification of our new order.xls|
|[fc23bd61f8af13293fd960e6cb202145](https://www.virustotal.com/gui/file/fc23bd61f8af13293fd960e6cb202145)|Win32 EXE|injector|2019-06-14 00:41:51|/home/netml/Desktop/TestMalwares/fc23bd61f8af13293fd960e6cb202145|
|[32cd96865b4c82f65047c561286aeab8](https://www.virustotal.com/gui/file/32cd96865b4c82f65047c561286aeab8)|Win32 EXE|generickdz|2018-05-28 09:12:30| |
|[4cd888432c2ebe58c5f0524c153ba5b2](https://www.virustotal.com/gui/file/4cd888432c2ebe58c5f0524c153ba5b2)|Win32 EXE|tspy|2018-05-11 04:21:13|/var/www/clean-mx/virusesevidence/output.113235467.txt|
|[2972aa43720444dc64a8534385f7ad04](https://www.virustotal.com/gui/file/2972aa43720444dc64a8534385f7ad04)|Win32 EXE||2018-05-09 16:44:03|/var/www/clean-mx/virusesevidence/output.113249970.txt|
|[ce0cc48b0e0d9e10381a7f1fbdf66b56](https://www.virustotal.com/gui/file/ce0cc48b0e0d9e10381a7f1fbdf66b56)|Win32 EXE|tspy|2018-05-08 18:12:55|/var/www/clean-mx/virusesevidence/output.113228786.txt|
|[f082f44b0f4e52c44a6116e34ecb2a78](https://www.virustotal.com/gui/file/f082f44b0f4e52c44a6116e34ecb2a78)|XLSX|CVE-2017-11882|2018-05-02 08:33:07|SETTLEMENT OF OUTSTANDING.xlsx|
|[675b17eed5c3c5e0bb5ab937753672bb](https://www.virustotal.com/gui/file/675b17eed5c3c5e0bb5ab937753672bb)|PPSX|CVE-2017-8759|2018-04-17 10:43:20|65bdd250aa4b4809edc32faeba2781864a3fee7e53e1f768b35a2bdedbb1243b.ppsx.bin|
|[bcfe2c56500d6f58e8e3f4b5a35fb155](https://www.virustotal.com/gui/file/bcfe2c56500d6f58e8e3f4b5a35fb155)|ZIP|Adwind|2018-03-20 11:22:10|d27a29bdb0492b25bf71e536c8a1fae8373a4b57f01ad7481006f6849b246a97.bin|
|[1be08ed45c512f6daab34519995dda63](https://www.virustotal.com/gui/file/1be08ed45c512f6daab34519995dda63)|Win32 EXE|Andromeda|2017-06-22 12:36:29|ddd.exe|
|[bf58485904f69fb91b11cd802f6d76ca](https://www.virustotal.com/gui/file/bf58485904f69fb91b11cd802f6d76ca)|ZIP|Andromeda|2017-06-22 12:36:27|P-O of  Jun2017.zip|
|[a313f809b1faf1643e0201e29cb4cbc0](https://www.virustotal.com/gui/file/a313f809b1faf1643e0201e29cb4cbc0)|Win32 EXE|Andromeda|2017-06-19 05:53:54|niggab.exe|
