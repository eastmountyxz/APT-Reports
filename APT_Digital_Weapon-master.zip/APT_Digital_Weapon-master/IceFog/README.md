**NAME:**  
IceFog  
  
**Alias**  
Dagger Panda, Ice Fog, Temp.Trident, Nomad Panda , TA428, IceFog, SectorB06  
  
**Description**:   
Icefog, named by Kaspersky, is an APT that has been active since at least 2011, targeting mostly Japan and South Korea. Known targets include governmental institutions, military contractors, maritime and shipbuilding groups, telecom operators, industrial and high-tech companies and mass media.
This Icefog campaigns rely on custom-made cyber-espionage tools for Microsoft Windows and Apple Mac OS X. The operators process victims swiftly and in a surgical manner — locating and copying only specific, targeted information. Once the desired information is obtained, they abandon the infection and move on.

**References**:  
https://securelist.com/blog/research/57331/the-icefog-apt-a-tale-of-cloak-and-three-daggers/  
https://securelist.com/blog/incidents/58209/the-icefog-apt-hits-us-targets-with-java-backdoor/