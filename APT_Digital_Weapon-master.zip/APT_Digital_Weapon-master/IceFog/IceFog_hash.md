|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[1c2d4c95c1b4e9d5193423719a7bb075](https://www.virustotal.com/gui/file/1c2d4c95c1b4e9d5193423719a7bb075)|Win32 DLL|Zbot|2019-09-20 13:24:23| |
|[1ad16f26272b2148f2969538f40b0b5a](https://www.virustotal.com/gui/file/1ad16f26272b2148f2969538f40b0b5a)|Win32 DLL|Ursu|2019-05-26 10:03:17|lkajdslfjalkjdsfklasdfkajfdl.dll|
|[d691de13f2ecadbac94184441faafdf0](https://www.virustotal.com/gui/file/d691de13f2ecadbac94184441faafdf0)|Mach-O executable||2019-05-20 04:23:26|d691de13f2ecadbac94184441faafdf0.virobj|
|[7f899c213c044e0ede824d58cbe6709e](https://www.virustotal.com/gui/file/7f899c213c044e0ede824d58cbe6709e)|Win32 EXE|PoisonIvy|2019-05-08 18:17:38| |
|[ea5d9bb659f5f38ade8183b2647f368f](https://www.virustotal.com/gui/file/ea5d9bb659f5f38ade8183b2647f368f)|Win32 EXE||2019-04-30 07:52:45|injected_b882c850bde0a1d210d09760f5ff94e81491f043|
|[1fd7a38b452cfcedbe26bee721a659c0](https://www.virustotal.com/gui/file/1fd7a38b452cfcedbe26bee721a659c0)|Win32 EXE||2019-04-25 10:18:38|injected_3a14ea4d16ab059577bfee748b032a8e879095d9_fd9f8ab9e3235be1b359ba12075044bda2a9ba5d|
|[9de35edb5da909b84d2b4f1176a835b6](https://www.virustotal.com/gui/file/9de35edb5da909b84d2b4f1176a835b6)|Win32 EXE||2019-04-25 10:18:21|injected_1c99696330be3daff1b633ba9ba5b79a62a56fcb|
|[183d04fbd11553b2d650303a9118e294](https://www.virustotal.com/gui/file/183d04fbd11553b2d650303a9118e294)|Win32 EXE||2019-04-18 18:07:01| |
|[f2d02e1fde6eadfe1429eeebe99c6c95](https://www.virustotal.com/gui/file/f2d02e1fde6eadfe1429eeebe99c6c95)|Win32 EXE||2019-04-15 08:45:54|dllhost.exe.bin|
|[2868447eebdf897bdd6b7ce2a18f4609](https://www.virustotal.com/gui/file/2868447eebdf897bdd6b7ce2a18f4609)|Win32 DLL|PlugX|2019-04-10 19:52:23|cls.wll|
|[2868447eebdf897bdd6b7ce2a18f4609](https://www.virustotal.com/gui/file/2868447eebdf897bdd6b7ce2a18f4609)|Win32 DLL|PlugX|2019-04-10 19:52:23|cls.wll|
|[b8ae7df96f2b3f0af5f207340ff94a9c](https://www.virustotal.com/gui/file/b8ae7df96f2b3f0af5f207340ff94a9c)|unknown||2019-04-10 06:19:07|dttcodexgigas.f09d289a62dcad6ed86ce79d588ec2aa2f84eea3|
|[59891d3679de1d7d295353e454d579a3](https://www.virustotal.com/gui/file/59891d3679de1d7d295353e454d579a3)|Win32 EXE|Kryptik|2019-04-02 02:01:02|59891d3679de1d7d295353e454d579a3.virus|
|[7cbd6f7662cc2f33e9647c272d0ac534](https://www.virustotal.com/gui/file/7cbd6f7662cc2f33e9647c272d0ac534)|Win32 EXE|Kryptik|2019-04-02 02:00:15|7cbd6f7662cc2f33e9647c272d0ac534.virus|
|[a5a4046989fa0f99c2076aec3ea0ab2a](https://www.virustotal.com/gui/file/a5a4046989fa0f99c2076aec3ea0ab2a)|Win32 EXE|bodegun|2019-04-01 18:39:11|.|
|[b72448af5f58e70c225ab6525126cf8b](https://www.virustotal.com/gui/file/b72448af5f58e70c225ab6525126cf8b)|Win32 DLL|PlugX|2019-03-27 19:18:33|.|
|[b72448af5f58e70c225ab6525126cf8b](https://www.virustotal.com/gui/file/b72448af5f58e70c225ab6525126cf8b)|Win32 DLL|PlugX|2019-03-27 19:18:33|.|
|[51ccb399bcb25aa76cef062615028029](https://www.virustotal.com/gui/file/51ccb399bcb25aa76cef062615028029)|unknown|PlugX|2019-03-27 08:05:23|dttcodexgigas.70e7201d7fd7cc426cb7d0616e6acd4441fd754e|
|[a78212faa38ef1078b300a492997fc02](https://www.virustotal.com/gui/file/a78212faa38ef1078b300a492997fc02)|Win32 DLL||2019-03-12 14:14:30|/home/rm/projetos/tz/archive/a78212faa38ef1078b300a492997fc02|
|[35ea5e4ce3f78c2d2e4c928f6be7e756](https://www.virustotal.com/gui/file/35ea5e4ce3f78c2d2e4c928f6be7e756)|Win32 DLL|razy|2019-03-11 12:37:40|35ea5e4ce3f78c2d2e4c928f6be7e756.virus|
|[0b86cc8e56a400f1adeb1e7b6ebe6abe](https://www.virustotal.com/gui/file/0b86cc8e56a400f1adeb1e7b6ebe6abe)|Win32 DLL|PlugX|2019-03-02 19:02:56|/home/rm/projetos/tz/archive/0b86cc8e56a400f1adeb1e7b6ebe6abe|
|[574235456f8737e91d1a2201b81f6264](https://www.virustotal.com/gui/file/574235456f8737e91d1a2201b81f6264)|unknown||2019-02-05 20:06:44|dttcodexgigas.c9f3386626ad97c7faccda7202a0b18c7c0037cf|
|[d95fa92c21768687625d031c99d75989](https://www.virustotal.com/gui/file/d95fa92c21768687625d031c99d75989)|Win32 DLL|razy|2019-01-25 05:53:13|d95fa92c21768687625d031c99d75989.virus|
|[db8b21ca3e409dab10229b2a6f9dbfdd](https://www.virustotal.com/gui/file/db8b21ca3e409dab10229b2a6f9dbfdd)|Win32 DLL|Symmi|2019-01-24 00:35:05|dttcodexgigas.6e8d251cbe483a0bce3af909a998bf496182bcd3|
|[4178d9b22efe7044540043b5c770b6aa](https://www.virustotal.com/gui/file/4178d9b22efe7044540043b5c770b6aa)|Win32 DLL|Zbot|2019-01-15 16:52:08|087d8bee1db61273a7cd533d52b63265d3a8a8b897526d7849c48bcdba4b22ec.sample|
|[c6a73e29c770065b4911ef46285d6557](https://www.virustotal.com/gui/file/c6a73e29c770065b4911ef46285d6557)|Win32 DLL||2018-12-27 09:55:39|eb0b848f18d8002aaf59faca18b28941df67dc46891868b96fa4daf03018d148.sample|
|[30528dc0c1e123dff51f40301cc03204](https://www.virustotal.com/gui/file/30528dc0c1e123dff51f40301cc03204)|RTF|CVE-2018-0802|2018-12-27 05:31:35|virus|
|[5982ba16356ee8118e4cdbe54d182b11](https://www.virustotal.com/gui/file/5982ba16356ee8118e4cdbe54d182b11)|RTF|CVE-2018-0802|2018-12-26 09:48:52|scan.doc|
|[a94db3001c0c3fa3cf40bc7fdf9d21b7](https://www.virustotal.com/gui/file/a94db3001c0c3fa3cf40bc7fdf9d21b7)|RTF|CVE-2018-0802|2018-12-19 07:21:56|Medee Bolor 20181217.doc|
|[e5bdc78c686e15dfeed6696bcd5989c3](https://www.virustotal.com/gui/file/e5bdc78c686e15dfeed6696bcd5989c3)|Win32 DLL|Hussarini|2018-11-07 06:46:09|/home/rm/projetos/tz/archive/e5bdc78c686e15dfeed6696bcd5989c3|
|[86409708eb0c716858ea30ae15eb7d47](https://www.virustotal.com/gui/file/86409708eb0c716858ea30ae15eb7d47)|Win32 DLL|Hussarini|2018-11-07 05:07:49|dttcodexgigas.3c3e395262d5e2c15da159542209ee85a31e1af3|
|[588d89d69cdc614004f8a9895c868498](https://www.virustotal.com/gui/file/588d89d69cdc614004f8a9895c868498)|Win32 EXE|Kryptik|2018-10-10 23:29:43|C:\Documents and Settings\sys\Local Settings\Temp\Bubbles.exe|
|[390e2f852b8211ab0c5c67d76d9936ce](https://www.virustotal.com/gui/file/390e2f852b8211ab0c5c67d76d9936ce)|Win32 EXE|Kryptik|2018-10-10 23:25:09|Sfx.exe|
|[71e5b89d5a804ddbe84fa4950bf97ac7](https://www.virustotal.com/gui/file/71e5b89d5a804ddbe84fa4950bf97ac7)|Win32 DLL|Ursu|2018-09-18 03:21:03|/home/rm/projetos/tz/archive/71e5b89d5a804ddbe84fa4950bf97ac7|
|[b3efda0e130373daf6cb17801714b66f](https://www.virustotal.com/gui/file/b3efda0e130373daf6cb17801714b66f)|Win32 EXE||2018-09-14 12:03:58|/home/rm/projetos/tz/archive/b3efda0e130373daf6cb17801714b66f|
|[c7d2c170482d17e2e76e6937bd8ab9a5](https://www.virustotal.com/gui/file/c7d2c170482d17e2e76e6937bd8ab9a5)|Win32 DLL||2018-09-14 02:01:29|/home/rm/projetos/tz/archive/c7d2c170482d17e2e76e6937bd8ab9a5|
|[9344e542cc1916b9ddb587daa70f0652](https://www.virustotal.com/gui/file/9344e542cc1916b9ddb587daa70f0652)|Win32 DLL|Zbot|2018-08-23 14:26:49|myfile.exe|
|[363bcf8bbf8ae7def65adcec0a755d45](https://www.virustotal.com/gui/file/363bcf8bbf8ae7def65adcec0a755d45)|Rich Text Format|CVE-2012-0158|2018-05-08 09:16:47|/home/virustotal/sample/363BCF8BBF8AE7DEF65ADCEC0A755D45|
|[3ce3e49e0e31e69b2aabcb3d7569a63c](https://www.virustotal.com/gui/file/3ce3e49e0e31e69b2aabcb3d7569a63c)|Rich Text Format|CVE-2012-0158|2018-05-08 00:42:34|/home/virustotal/sample/3CE3E49E0E31E69B2AABCB3D7569A63C|
|[90f4ca70fddcde6e77eb4f64e19b5146](https://www.virustotal.com/gui/file/90f4ca70fddcde6e77eb4f64e19b5146)|RTF||2018-04-23 06:24:47|=?UTF-8?B?0J/RgNC+0YLQvtC60L7QuyAyNjguZG9j?=|
|[c56c50c7e98f717ce0138620fb30b2c0](https://www.virustotal.com/gui/file/c56c50c7e98f717ce0138620fb30b2c0)|RTF||2018-04-22 20:39:30|722e5d3dcc8945f69135dc381a15b5cad9723cd11f7ea20991a3ab867d9428c7.bin|
|[88d667cc01c4d8ee32e9de116f3bfdeb](https://www.virustotal.com/gui/file/88d667cc01c4d8ee32e9de116f3bfdeb)|RTF|o97m|2018-03-15 06:09:55|AMU_SLA_Agreement_Final_Dt_20-Spr_14.doc|
|[6fffdb88292eeed0483b4030e58f401e](https://www.virustotal.com/gui/file/6fffdb88292eeed0483b4030e58f401e)|Win32 DLL|Ursu|2018-03-07 21:43:55|RasTls.dll|
|[46d91a91ecdf9c0abc7355c4e7cf08fc](https://www.virustotal.com/gui/file/46d91a91ecdf9c0abc7355c4e7cf08fc)|RTF|o97m|2018-03-07 13:51:39|=?UTF-8?B?a2F0xLFsxLFtY8SxbGFyIGxpc3Rlc2kuZG9j?=|
|[6850e553445c0c9eac3206331eb0429b](https://www.virustotal.com/gui/file/6850e553445c0c9eac3206331eb0429b)|Win32 DLL|Ursu|2018-03-01 17:43:00| |
|[80883df4e89d5632fa72a85057773538](https://www.virustotal.com/gui/file/80883df4e89d5632fa72a85057773538)|RTF|o97m|2018-03-01 08:27:18|=?UTF-8?B?0JLQvdGD0YLRgNC10L3QvdGP0Y8g0L7Qv9C40YHRjCDQtNC+0LrRg9C80LXQvdGC0L7QsiBBR0FULmRvYw==?=|
|[d5c67718e35bd1083dd50335ba9e89da](https://www.virustotal.com/gui/file/d5c67718e35bd1083dd50335ba9e89da)|Win32 DLL||2018-02-27 11:27:29|RasTls.dll|
|[9ca6d45643f89bf233f08b7d74910346](https://www.virustotal.com/gui/file/9ca6d45643f89bf233f08b7d74910346)|RTF|o97m|2018-02-26 14:51:36|Address Book 2018.doc|
|[c2893fefcadbc7fed4fe74ea56133901](https://www.virustotal.com/gui/file/c2893fefcadbc7fed4fe74ea56133901)|Win32 DLL|PlugX|2018-02-26 11:35:24|RasTls.dll|
|[d00a34baad19d40dcefbadb0942a2e4d](https://www.virustotal.com/gui/file/d00a34baad19d40dcefbadb0942a2e4d)|RTF|CVE-2017-8759|2018-02-26 09:24:23|f5365387320ae6e6907fd2700f340ba8712cb08f7e52b2ec4dccfe99b3d648ef.bin|
|[63f9eaf7a80231480687b134b1915bd0](https://www.virustotal.com/gui/file/63f9eaf7a80231480687b134b1915bd0)|RTF|CVE-2012-0158|2018-02-26 05:12:32|Российский фигурист выиграл зимние Олимпийские игры PyeongChang в Южной Корее.doc|
|[7fa8c07634f937a1fcef9180531dc2e4](https://www.virustotal.com/gui/file/7fa8c07634f937a1fcef9180531dc2e4)|RTF|CVE-2012-0158|2018-02-26 04:23:22|счет.doc|
|[e7c5307691772a058fa7d9e8ea426a59](https://www.virustotal.com/gui/file/e7c5307691772a058fa7d9e8ea426a59)|RTF|CVE-2012-0158|2018-02-26 03:36:24|Задание.doc|
|[a0389879ea435e647d29f6966b1d601f](https://www.virustotal.com/gui/file/a0389879ea435e647d29f6966b1d601f)|Win32 EXE||2018-01-29 20:23:23|ClientRu|
|[c3ed6b34707e92f7aa35859a9647f044](https://www.virustotal.com/gui/file/c3ed6b34707e92f7aa35859a9647f044)|unknown|CVE-2012-0158|2017-08-03 11:18:56|План продажи.doc|
|[698df4c3d496bfa98929aa5289147467](https://www.virustotal.com/gui/file/698df4c3d496bfa98929aa5289147467)|Mach-O executable||2017-07-23 17:41:23|IceFog|
|[09d8f865bccfb239afab4f4f564081ff](https://www.virustotal.com/gui/file/09d8f865bccfb239afab4f4f564081ff)|Win32 DLL||2016-10-12 16:01:32|RasTls.dll|
|[47713144ae08560ba939ea01620a0a2d](https://www.virustotal.com/gui/file/47713144ae08560ba939ea01620a0a2d)|Win32 EXE||2016-10-12 08:28:45|/home/rm/projetos/tz/archive/47713144ae08560ba939ea01620a0a2d|
|[7b8c955a0f1d6d37833277849a070e37](https://www.virustotal.com/gui/file/7b8c955a0f1d6d37833277849a070e37)|Win32 DLL|Hussarini|2016-08-21 21:35:24|Outllib.dll|
|[a4dc9763d296c45a846156f02479ecde](https://www.virustotal.com/gui/file/a4dc9763d296c45a846156f02479ecde)|Win32 DLL||2016-07-08 18:12:17|/home/rm/projetos/tz/archive/a4dc9763d296c45a846156f02479ecde|
|[92853e0506ea16c6f17ac32f5ef8f3b3](https://www.virustotal.com/gui/file/92853e0506ea16c6f17ac32f5ef8f3b3)|Win32 DLL|Hussarini|2016-06-11 20:54:52|Outllib.dll|
|[aae3e322dbe5bb1894a412ca08afdf03](https://www.virustotal.com/gui/file/aae3e322dbe5bb1894a412ca08afdf03)|Win32 DLL||2016-05-31 00:33:56|/home/rm/projetos/tz/archive/aae3e322dbe5bb1894a412ca08afdf03|
|[e28c2d68a6f13e81d321712888c89e52](https://www.virustotal.com/gui/file/e28c2d68a6f13e81d321712888c89e52)|Win32 DLL||2016-05-20 22:13:21|/home/rm/projetos/tz/archive/e28c2d68a6f13e81d321712888c89e52|
|[4f11e00b015047642d8ddc306fc90da0](https://www.virustotal.com/gui/file/4f11e00b015047642d8ddc306fc90da0)|Win32 DLL|Hussarini|2016-05-16 08:43:24|4f11e00b015047642d8ddc306fc90da0.virobj|
|[0e25aa791c9119108af073bc9e9d0fa2](https://www.virustotal.com/gui/file/0e25aa791c9119108af073bc9e9d0fa2)|Win32 DLL||2016-05-11 22:28:11| |
|[404b1b78b4f34612e61d4af3bf5083f1](https://www.virustotal.com/gui/file/404b1b78b4f34612e61d4af3bf5083f1)|Win32 DLL||2016-05-11 10:04:18|RasTls.dll|
|[eb2d297d099f3d39874efa3f89735a01](https://www.virustotal.com/gui/file/eb2d297d099f3d39874efa3f89735a01)|Win32 DLL||2016-04-29 04:08:09|/home/rm/projetos/tz/archive/eb2d297d099f3d39874efa3f89735a01|
|[f8cc15db9c85da19555a7232b543c726](https://www.virustotal.com/gui/file/f8cc15db9c85da19555a7232b543c726)|Win32 EXE||2016-04-29 03:52:22|/home/rm/projetos/tz/archive/f8cc15db9c85da19555a7232b543c726|
|[a9ecf6d2674443cdac067b136b04c7d0](https://www.virustotal.com/gui/file/a9ecf6d2674443cdac067b136b04c7d0)|Win32 DLL||2016-04-26 09:23:10|RasTls.dll|
|[1554900f889c9498c43c9f875eceea38](https://www.virustotal.com/gui/file/1554900f889c9498c43c9f875eceea38)|Win32 EXE|dynamer|2016-03-04 08:12:17|netsh.exe|
|[a489f2b4505b8f291804e3931cf16ed8](https://www.virustotal.com/gui/file/a489f2b4505b8f291804e3931cf16ed8)|Win32 EXE|dynamer|2015-11-11 12:56:30|/home/rm/projetos/tz/archive/a489f2b4505b8f291804e3931cf16ed8|
|[2e74505cc08c0d0d88146d46915f37af](https://www.virustotal.com/gui/file/2e74505cc08c0d0d88146d46915f37af)|Win32 EXE|PlugX|2015-07-09 07:13:50|/home/rm/projetos/tz/archive/2e74505cc08c0d0d88146d46915f37af|
|[74583d7355113ad3e58e355b003083e5](https://www.virustotal.com/gui/file/74583d7355113ad3e58e355b003083e5)|Win32 EXE||2015-07-07 12:41:23|/home/rm/projetos/tz/archive/74583d7355113ad3e58e355b003083e5|
|[7dc1f0e60f11c456aa15cc3546716c17](https://www.virustotal.com/gui/file/7dc1f0e60f11c456aa15cc3546716c17)|Win32 DLL|razy|2015-07-07 12:41:13|RasTls.dll|
|[e84b74f07ae803852f2ed19458a1539d](https://www.virustotal.com/gui/file/e84b74f07ae803852f2ed19458a1539d)|Win32 EXE|dynamer|2015-07-07 03:01:42|/home/rm/projetos/tz/archive/e84b74f07ae803852f2ed19458a1539d|
|[664318c95c4a48debd3562ea602796b9](https://www.virustotal.com/gui/file/664318c95c4a48debd3562ea602796b9)|Win32 DLL|Zbot|2015-02-11 16:59:36|664318c95c4a48debd3562ea602796b9|
|[1a93c0257f52e2b1e8e4f52c033a61b3](https://www.virustotal.com/gui/file/1a93c0257f52e2b1e8e4f52c033a61b3)|Win32 EXE|PlugX|2014-09-16 12:22:39|/home/rm/projetos/tz/archive/1a93c0257f52e2b1e8e4f52c033a61b3|
|[b4249f9b49a9a177b4d2f4439373029a](https://www.virustotal.com/gui/file/b4249f9b49a9a177b4d2f4439373029a)|Mach-O executable||2013-09-28 08:44:18|vti-rescan|
|[615dd792093191e9fc975132a2db409a](https://www.virustotal.com/gui/file/615dd792093191e9fc975132a2db409a)|Mach-O executable||2013-09-28 05:34:08|615dd792093191e9fc975132a2db409a.vir|
|[f46eb126668dfc843a05958e71936b01](https://www.virustotal.com/gui/file/f46eb126668dfc843a05958e71936b01)|Win32 DLL|Ursu|2013-09-27 07:21:53|wdmaud.drv|
|[9f422bb6c00bb46fbfa3918ae3e9447a](https://www.virustotal.com/gui/file/9f422bb6c00bb46fbfa3918ae3e9447a)|Mach-O executable||2013-09-26 18:29:04|Img2icns|
|[cf1815491d41202eb8647341a8695e1e](https://www.virustotal.com/gui/file/cf1815491d41202eb8647341a8695e1e)|Mach-O executable||2013-09-26 07:55:22|launchd|
|[b1241cd7a0d7d58d1182badd0adba8ab](https://www.virustotal.com/gui/file/b1241cd7a0d7d58d1182badd0adba8ab)|Rich Text Format|CVE-2012-0158|2013-09-01 09:29:31|b0a4c43745b641a2c203536e3723bad9073b604d4946cdade3f42db6d157020d.rtf|
|[0e2694aea9d3de122611d88e37ffc7f0](https://www.virustotal.com/gui/file/0e2694aea9d3de122611d88e37ffc7f0)|Win32 EXE||2013-08-15 21:21:52|工程1|
|[15a342cf2cc4fc5ae933d463f5d2196f](https://www.virustotal.com/gui/file/15a342cf2cc4fc5ae933d463f5d2196f)|Win32 EXE||2013-07-21 04:03:44|15A342CF2CC4FC5AE933D463F5D2196F|
|[43678aa052ad677841bd2ef532ecd284](https://www.virustotal.com/gui/file/43678aa052ad677841bd2ef532ecd284)|Win32 EXE|Banload|2013-07-11 07:00:45|vti-rescan|
|[2a106c694660891e0950493e3eedc42d](https://www.virustotal.com/gui/file/2a106c694660891e0950493e3eedc42d)|Win32 EXE|Banload|2013-06-22 13:33:31|e799c8cf75fc7e6034bdbeefc7f84301cf807abe66b83f7e03dbd1a58905f4f9.bin|
|[fa452f67c6bf8056b563690d61c4a4c6](https://www.virustotal.com/gui/file/fa452f67c6bf8056b563690d61c4a4c6)|Win32 EXE||2013-06-21 04:39:23|/home/virustotal/sample/FA452F67C6BF8056B563690D61C4A4C6|
|[6d3d95137ef1ba5c6e15a4a95de8a546](https://www.virustotal.com/gui/file/6d3d95137ef1ba5c6e15a4a95de8a546)|Win32 DLL||2013-06-14 11:29:50|VirusShare_6d3d95137ef1ba5c6e15a4a95de8a546|
|[d421e0d74fa7035246c1ea51bd4d3114](https://www.virustotal.com/gui/file/d421e0d74fa7035246c1ea51bd4d3114)|Win32 DLL|Ursu|2013-05-30 01:32:34|vti-rescan|
|[beb9da03aff9386599625199a5a47b8d](https://www.virustotal.com/gui/file/beb9da03aff9386599625199a5a47b8d)|Win32 DLL|Symmi|2013-05-19 21:13:22|%WINDIR%\wdmaud.drv|
|[b21635b1b1fce93ff917d9308d4835fb](https://www.virustotal.com/gui/file/b21635b1b1fce93ff917d9308d4835fb)|Win32 DLL|Symmi|2013-03-02 14:10:48|vti-rescan|
|[387ae1e56fa48ec50a46394cc51acce7](https://www.virustotal.com/gui/file/387ae1e56fa48ec50a46394cc51acce7)|Win32 DLL|Symmi|2013-02-17 18:01:00|602af65ea3c8cdc09d14a16edf2b359c3b579aa6e3c7e077434d0be39cdd0631|
|[78d9ac9954516ac096992cf654caa1fc](https://www.virustotal.com/gui/file/78d9ac9954516ac096992cf654caa1fc)|Win32 EXE|Zbot|2013-02-06 16:42:16|vti-rescan|
|[8f816f4acc49f5ebba00d92437b42e85](https://www.virustotal.com/gui/file/8f816f4acc49f5ebba00d92437b42e85)|Win32 DLL|Symmi|2013-02-06 11:23:49|f8ebd024c0c911c356adf5674b07cff340df6a6ac50033e5d02418a843b34efb|
|[fba7b9ffd08110e37d2bdf77c0d8b806](https://www.virustotal.com/gui/file/fba7b9ffd08110e37d2bdf77c0d8b806)|Win32 EXE|Zbot|2013-02-05 09:19:24|vti-rescan|
|[5aaa057d3447a214e729276563d2f922](https://www.virustotal.com/gui/file/5aaa057d3447a214e729276563d2f922)|XLS|CVE-2012-0158|2013-02-05 05:02:04|d37b3b9aa419434208326f20be02ca352580af9b707c57b2e623c9ad8c99f4c5|
|[853096b7e1e4bdb9221875c30d9a15a0](https://www.virustotal.com/gui/file/853096b7e1e4bdb9221875c30d9a15a0)|Win32 DLL|Symmi|2013-01-26 14:20:59|853096b7e1e4bdb9221875c30d9a15a0.virobj|
|[eb4579f08cd270e496c70ddcaa29dacb](https://www.virustotal.com/gui/file/eb4579f08cd270e496c70ddcaa29dacb)|XLS|CVE-2012-0158|2013-01-23 05:24:44|vti-rescan|
|[219738275b9dfbef6be8b65473833e45](https://www.virustotal.com/gui/file/219738275b9dfbef6be8b65473833e45)|XLS|CVE-2012-0158|2013-01-22 08:36:05|説明書.xls|
|[c352c376968e8a1157fa425431776797](https://www.virustotal.com/gui/file/c352c376968e8a1157fa425431776797)|Win32 DLL|Symmi|2013-01-18 07:39:43|vti-rescan|
|[392f5372ba3348ea1820df34c078f6c8](https://www.virustotal.com/gui/file/392f5372ba3348ea1820df34c078f6c8)|Win32 EXE|Zbot|2013-01-17 11:30:01|VirusShare_392f5372ba3348ea1820df34c078f6c8|
|[31a530fea411455b8844fe019ffb66cd](https://www.virustotal.com/gui/file/31a530fea411455b8844fe019ffb66cd)|Win32 EXE|Zbot|2013-01-17 07:24:29|testing-samples/141d18becbd5ae1743a17c6b7f6014e5d8c7aac1223dc0e3585aae4232c5bcb1|
|[c5f3d21cb19a4b2d03aa42e4bf43b79b](https://www.virustotal.com/gui/file/c5f3d21cb19a4b2d03aa42e4bf43b79b)|unknown|CVE-2012-0158|2012-12-21 08:28:54|f6578f10f2719f4e27d279f542ca0d5c541e421ddbec70c86c161b25c81de1a4.rtf|
|[32e8d4b2f08aff883c8016b7ebd7c85b](https://www.virustotal.com/gui/file/32e8d4b2f08aff883c8016b7ebd7c85b)|Rich Text Format|CVE-2012-0158|2012-12-21 08:20:35|d84ce2b4df25766617c37ad800c9eb30cf8baff13614a9461c0c7d9fbd131f3a.rtf|
|[cd85a9a05538e89190d519703c9a1327](https://www.virustotal.com/gui/file/cd85a9a05538e89190d519703c9a1327)|Win32 EXE||2012-10-19 09:02:42|vti-rescan|
|[24751030c1fa40bd57988d4e6fe70117](https://www.virustotal.com/gui/file/24751030c1fa40bd57988d4e6fe70117)|Win32 DLL|Symmi|2012-08-30 09:32:37|24751030c1fa40bd57988d4e6fe70117.dll|
|[2761c55bafa96d5814e847b665006e49](https://www.virustotal.com/gui/file/2761c55bafa96d5814e847b665006e49)|Win32 DLL|Symmi|2012-08-27 08:06:20|vti-rescan|
|[3a6feab7eb90b87cf5a4e08bce2572e8](https://www.virustotal.com/gui/file/3a6feab7eb90b87cf5a4e08bce2572e8)|Win32 DLL|Symmi|2012-06-15 18:06:37|wdmaud.drv|
|[f4ced221baf2a482e60baf374ab063be](https://www.virustotal.com/gui/file/f4ced221baf2a482e60baf374ab063be)|Win32 EXE||2012-06-14 19:20:56|vti-rescan|
|[2d6a82fdb59e38d63027beac28dc2813](https://www.virustotal.com/gui/file/2d6a82fdb59e38d63027beac28dc2813)|Win32 DLL|Symmi|2012-04-20 01:24:35|vti-rescan|
|[80405f5681f1e4f2de6e8c26ec20c14d](https://www.virustotal.com/gui/file/80405f5681f1e4f2de6e8c26ec20c14d)|Win32 DLL|Symmi|2012-04-12 08:00:50|vti-rescan|
|[566b175ab355e6313ba0ca98b0146d84](https://www.virustotal.com/gui/file/566b175ab355e6313ba0ca98b0146d84)|Win32 DLL|Symmi|2011-12-02 07:02:13|VirusShare_566b175ab355e6313ba0ca98b0146d84|
|[f7547f23bd2fd37b7d44e8617f629b49](https://www.virustotal.com/gui/file/f7547f23bd2fd37b7d44e8617f629b49)|Win32 DLL|Symmi|2011-11-22 02:06:10|ace1db881a879bb73c66c14d74987f98702409636d5255cd9f46edcf436800ea|
|[162b349be9c6d11c58cf163e211d891c](https://www.virustotal.com/gui/file/162b349be9c6d11c58cf163e211d891c)|Win32 DLL||2011-08-03 02:06:46|vti-rescan|
|[acc57cc72a8d129703b4914c408a15a1](https://www.virustotal.com/gui/file/acc57cc72a8d129703b4914c408a15a1)|Win32 DLL||2011-05-16 00:49:01|vti-rescan|
|[95bec02acfdf30a308fb1aa9492f885a](https://www.virustotal.com/gui/file/95bec02acfdf30a308fb1aa9492f885a)|RTF|CVE-2017-11882|2020-02-20 09:46:09|muestras/5bbf2643a601e632a49406483c8fc5262a76e206bd969f2ba3f4f2e238768ab9|
|[b26b60c8ba87df6322fa48916b7ba86d](https://www.virustotal.com/gui/file/b26b60c8ba87df6322fa48916b7ba86d)|Win32 DLL|Injecto|2020-01-09 17:18:50|%APPDATA%\microsoft\word\startup\useless.wll|
|[f1b21f5f9941afd9eec0ab7456ec78b8](https://www.virustotal.com/gui/file/f1b21f5f9941afd9eec0ab7456ec78b8)|RTF|o97m|2020-01-09 01:48:51|/var/www/clean-mx/virusesevidence/output.148802639.txt|
