|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[3bcddbfd757de15ec350f1b4c9e92926](https://www.virustotal.com/gui/file/3bcddbfd757de15ec350f1b4c9e92926)|Win64 DLL||2020-09-19 06:28:21|a4fcc308e9a364d29057cc76dbe6a8c32ce24a1dbae5c0b6306471f61cbefb29.bin|
|[4cc8577c844e2492840aed08876eb1c4](https://www.virustotal.com/gui/file/4cc8577c844e2492840aed08876eb1c4)|Win32 EXE|Athena|2020-09-02 03:29:01|SUBEDIT|
|[1331b068477e2974894a899c855bfc4b](https://www.virustotal.com/gui/file/1331b068477e2974894a899c855bfc4b)|DOC||2020-09-01 17:57:55|04113d5fa51addc57a858f945cf7dbef6d24841d2a63db4bff475dde40fbe2b5.bin|
|[72503d7ef52495efa109941274b8769f](https://www.virustotal.com/gui/file/72503d7ef52495efa109941274b8769f)|Win32 EXE||2020-08-25 07:11:37|ssoclient|
|[7b2b6e47e33dddce7406fc989592ab50](https://www.virustotal.com/gui/file/7b2b6e47e33dddce7406fc989592ab50)|DOCX|CVE-2017-11882|2020-08-25 05:34:56|Adviser Senior Director eysd.docx|
|[59bc5eb1d3f1affd1496dfbb61f1537e](https://www.virustotal.com/gui/file/59bc5eb1d3f1affd1496dfbb61f1537e)|XLSM||2020-08-24 10:14:18|Project progress update.xlsm|
|[75c55e8a9b00a1d724ef4d451da5806f](https://www.virustotal.com/gui/file/75c55e8a9b00a1d724ef4d451da5806f)|Win32 EXE|Razy|2020-08-19 06:08:02|ConsoleAsync.exe|
|[878ad290280bb9e880c1366e8c386e1a](https://www.virustotal.com/gui/file/878ad290280bb9e880c1366e8c386e1a)|Win32 EXE|Wacatac|2020-08-10 07:17:54|India's 5th Gen Fighter Jet Report.exe|
|[005e8de2974db8722073fa54e8b8d435](https://www.virustotal.com/gui/file/005e8de2974db8722073fa54e8b8d435)|Android||2020-06-04 12:02:29|9c604f4d400c1c500e6ff231504d05235c242bf6580f49180196a534d50123c3.bin|
|[842c3c8b62e4ed67ec529ab08ee87c4a](https://www.virustotal.com/gui/file/842c3c8b62e4ed67ec529ab08ee87c4a)|Win32 EXE|occamy|2020-06-04 10:44:34|Notepad.NET.exe|
|[b96fe909c2d2f458abf71665ce1bb1ef](https://www.virustotal.com/gui/file/b96fe909c2d2f458abf71665ce1bb1ef)|Win32 EXE|Zbot|2020-05-20 11:36:42|%PROGRAMDATA%:applicationdata|
|[47568de42706aa3da39a03d1d0feddca](https://www.virustotal.com/gui/file/47568de42706aa3da39a03d1d0feddca)|DOCX|CVE-2017-11882|2020-05-20 06:37:48|904e966da7b38514f6ac23bba1dac1858888cd48fa77b73c770156b19a88a4c8.bin|
|[e7b6ec85ece1c431f07b4a47e264190d](https://www.virustotal.com/gui/file/e7b6ec85ece1c431f07b4a47e264190d)|Win32 EXE|occamy|2020-05-15 16:27:47|FINAL.exe|
|[16706dff8db6fcc1fbd6f80cfb2baeb1](https://www.virustotal.com/gui/file/16706dff8db6fcc1fbd6f80cfb2baeb1)|Win64 DLL||2020-05-06 12:22:20|%APPDATA%\microsoft\windows\device\drvupdtd.dll|
|[cf4ed89d96dab84a455a4f52400388cd](https://www.virustotal.com/gui/file/cf4ed89d96dab84a455a4f52400388cd)|Win32 EXE||2020-05-06 12:12:17|IMG 20200506_423654983625541565658745215.scr|
|[33a2941742ed2f4b6b412d239711d6a3](https://www.virustotal.com/gui/file/33a2941742ed2f4b6b412d239711d6a3)|Win32 EXE|Ursu|2020-05-05 23:38:44|84aa2e63228094380dc65286fdc88acd93246ba326e8160394ff71af74009010.bin|
|[dee2bc2f5424874a5fc7cf51c4cd2b55](https://www.virustotal.com/gui/file/dee2bc2f5424874a5fc7cf51c4cd2b55)|Win32 EXE|Ursu|2020-04-20 00:45:17|vs_community.exe|
|[94a87ee68fe8f998df3ffc84bb459a1d](https://www.virustotal.com/gui/file/94a87ee68fe8f998df3ffc84bb459a1d)|Win32 EXE|occamy|2020-04-17 05:55:00|f0190267b06cbaf459ee879440a6b394e2f1f7aa6d9e247d836c107acd04699a.sample|
|[2d2fe787b2728332341166938a25fa26](https://www.virustotal.com/gui/file/2d2fe787b2728332341166938a25fa26)|Win32 EXE|Injecto|2020-04-14 21:06:50|vs_community.exe|
|[c3d422c2065ec3d9063929a1d4955416](https://www.virustotal.com/gui/file/c3d422c2065ec3d9063929a1d4955416)|Win32 EXE|Razy|2020-02-20 16:22:02|audiopro.exe|
|[d373bf68ceb8e395719a1ad6befba66d](https://www.virustotal.com/gui/file/d373bf68ceb8e395719a1ad6befba66d)|Win32 EXE|Dapato|2020-02-04 17:03:53|/var/www/clean-mx/virusesevidence/output.147257188.txt|
|[6d7d69e897351f6af2399bfdcf00983a](https://www.virustotal.com/gui/file/6d7d69e897351f6af2399bfdcf00983a)|RTF|o97m|2020-02-02 19:06:07|e617ba1156d6c8d3e724bb74ad436bbe4ec3da8e46bd156ad5cfbabfefa07b99.bin|
|[d2d7723310c67b3df3d25529ca8b5a3b](https://www.virustotal.com/gui/file/d2d7723310c67b3df3d25529ca8b5a3b)|Win32 EXE|Ursu|2020-01-16 05:27:37|\ProgramData\Caches\nvbackend.exe|
|[8a4e265cfbad8d136222dda60505b61d](https://www.virustotal.com/gui/file/8a4e265cfbad8d136222dda60505b61d)|Win32 EXE|Ursu|2020-01-07 09:35:12|rcs.exe|
|[e91e10978ace80a789363288ffee178a](https://www.virustotal.com/gui/file/e91e10978ace80a789363288ffee178a)|Android||2019-12-23 09:29:35|7000035eb219b8d2da064a197cf4aa86471e893f9765c16e3f484f3b84b023ee.bin|
|[ef34e809b4a0e33eb1222409d13068ab](https://www.virustotal.com/gui/file/ef34e809b4a0e33eb1222409d13068ab)|Win32 EXE|Ursu|2019-10-18 12:36:02|ef34e809b4a0e33eb1222409d13068ab.virus|
|[62d8c20b64281b0d934358bf8d0fd2cf](https://www.virustotal.com/gui/file/62d8c20b64281b0d934358bf8d0fd2cf)|Win32 EXE|occamy|2018-12-30 09:08:39|b7730f9a05be8a0f25a3979b2f8d2fed791340a32385a9fd37d0e8b81119627d.bin|
|[74c3049ae9229675ccce544f0491e2f9](https://www.virustotal.com/gui/file/74c3049ae9229675ccce544f0491e2f9)|Win64 DLL||2018-08-29 20:27:23|79baf679e84b02a660e03602ff7aa4c9c86a92e0885b1a298c672db842be258d.bin|
|[c887fc425351a824a143a015d51ad0a7](https://www.virustotal.com/gui/file/c887fc425351a824a143a015d51ad0a7)|Win64 DLL||2018-07-03 14:23:14|%TEMP%\rarsfx0\drvupdtd.dll|
|[db4c95ea37fed6403546eadd9e691a1e](https://www.virustotal.com/gui/file/db4c95ea37fed6403546eadd9e691a1e)|Win32 EXE|occamy|2018-07-03 14:23:09|%TEMP%\rarsfx0\uflscan.exe|
|[a68fcf5b97265d97c6bc5613ae82c093](https://www.virustotal.com/gui/file/a68fcf5b97265d97c6bc5613ae82c093)|PPTX||2018-07-03 10:55:00|%TEMP%\rarsfx0\new microsoft office powerpoint presentation.pptx|
|[dd07291265098edef72d39b11c8a1e37](https://www.virustotal.com/gui/file/dd07291265098edef72d39b11c8a1e37)|Win64 EXE||2018-07-02 18:45:51|%TEMP%\rarsfx0\drvupdt.exe|
|[87866ae8936ec3fc04af3e0783ec36bf](https://www.virustotal.com/gui/file/87866ae8936ec3fc04af3e0783ec36bf)|Win32 EXE||2018-07-02 18:44:25|0f7082926241659fbebd229cdc41abe358be49110a80729b9ee891f2f7dcdf16.bin|
|[661dee790ea438b14553e622052909a5](https://www.virustotal.com/gui/file/661dee790ea438b14553e622052909a5)|Win32 EXE||2018-07-02 18:17:46|845a0e5720a6288794a6452adb8d3e7c22f5e6e6b9d4f7481fbd30e3efba4f28.bin|
|[1d6a516c77aaf1bbab1ac4051f86475c](https://www.virustotal.com/gui/file/1d6a516c77aaf1bbab1ac4051f86475c)|Win32 DLL|Skeeyah|2016-03-08 23:27:21| |
|[e7c0e92855a1b7d9b81eeb06cce5ce60](https://www.virustotal.com/gui/file/e7c0e92855a1b7d9b81eeb06cce5ce60)|Win32 EXE|Zbot|2016-03-08 23:27:15|e7c0e92855a1b7d9b81eeb06cce5ce60.virobj|
|[ccb6f24ff38770ab2efeb8f51de2a123](https://www.virustotal.com/gui/file/ccb6f24ff38770ab2efeb8f51de2a123)|Win32 EXE|Skeeyah|2016-03-08 23:23:47|c2.exe|
|[f55277807457e2a3e9ad4b6de64b549f](https://www.virustotal.com/gui/file/f55277807457e2a3e9ad4b6de64b549f)|Win32 EXE||2015-11-27 03:27:19| |
|[f499cabf7c2ddacad965ed2a086b481b](https://www.virustotal.com/gui/file/f499cabf7c2ddacad965ed2a086b481b)|Win64 EXE||2015-11-27 03:25:11|35e3f08ae93a7b4cd3e77a6438e318cd3c3b41efa5def52e5ebd182347e94fd9.bin|
|[5c4b2cf2bed7db57b7335ec426fe776b](https://www.virustotal.com/gui/file/5c4b2cf2bed7db57b7335ec426fe776b)|Win32 EXE|Skeeyah|2015-11-27 03:25:10|0af51a0ffb5798fb90a14070809fa9909195068ad1b91c1cadf5633b521e5132.bin|
|[83cba14904fdbf0e21d251fc5ab00666](https://www.virustotal.com/gui/file/83cba14904fdbf0e21d251fc5ab00666)|Win64 DLL||2015-11-27 03:25:02|af31cc534aa49f02e6c18a8cf3fd4c9cf366d462ee7caaf8c2a461405382073f.bin|
|[470175c447f025f4057b4dbacb931e42](https://www.virustotal.com/gui/file/470175c447f025f4057b4dbacb931e42)|Win32 DLL||2015-11-27 03:24:40|75972d15f3b2e97d52b9f8a6f42ea85976ed5bb9d609c3bf93ee98d6f4f4a648.bin|
|[2c8a7d32667b7b7c410f3b3347087996](https://www.virustotal.com/gui/file/2c8a7d32667b7b7c410f3b3347087996)|Win64 EXE||2015-10-12 13:35:03|%TEMP%\rarsfx0\ehtmlh.exe|
|[f9b9b9e2c87f9f4b5fbb89e5a1ac05eb](https://www.virustotal.com/gui/file/f9b9b9e2c87f9f4b5fbb89e5a1ac05eb)|Win64 DLL||2015-10-12 13:35:03|%TEMP%\rarsfx0\dhtmlh.dll|
|[48873bf5f51ed996b237ce3495bf6219](https://www.virustotal.com/gui/file/48873bf5f51ed996b237ce3495bf6219)|Win32 DLL|Zbot|2015-10-12 13:20:04|579309-7|
|[1ac4f4f7c5217adb16d83f902e51624a](https://www.virustotal.com/gui/file/1ac4f4f7c5217adb16d83f902e51624a)|Win32 EXE||2015-10-12 13:20:03|C:\Documents and Settings\Administrator\Local Settings\Temp\RarSFX0\rreegg.exe|
|[e130f1305948f0f7bd25f9d7101bd98a](https://www.virustotal.com/gui/file/e130f1305948f0f7bd25f9d7101bd98a)|Win32 EXE||2015-10-12 13:20:03|b26b024fa7be56d2b2e3815d8e97434f95b30bf25cda4259d3e20c14a92bd8ec.bin|
|[cb93aad2354aea2623a70abdd9ecc87b](https://www.virustotal.com/gui/file/cb93aad2354aea2623a70abdd9ecc87b)|Win32 EXE||2015-10-11 02:38:30|07247bb81cca445e0df110d73ea6bf7eb327cc99b614b99dfbcb5632025c99a0.bin|
|[91be9e93c7602202963650103ff8ee50](https://www.virustotal.com/gui/file/91be9e93c7602202963650103ff8ee50)|Win32 EXE||2015-10-11 02:38:29|Comss Vir Type-1 (27).exe|
|[20691b32c1839cb1e106f937dd101e4d](https://www.virustotal.com/gui/file/20691b32c1839cb1e106f937dd101e4d)|Win32 DLL||2015-07-03 07:38:21|%TEMP%\rarsfx0\pa2_dll.dll|
|[e20f58c1afb7d9262e5a15620b172bd4](https://www.virustotal.com/gui/file/e20f58c1afb7d9262e5a15620b172bd4)|Win64 DLL||2015-07-03 07:38:19|%TEMP%\rarsfx0\pa2_64dll.dll|
|[2d64174dc0bed8222eea4494a49744a5](https://www.virustotal.com/gui/file/2d64174dc0bed8222eea4494a49744a5)|Win32 EXE||2015-07-03 07:38:18|%TEMP%\RarSFX0\pa2.exe|
|[86320eb8adb48106b899e21be5d5387d](https://www.virustotal.com/gui/file/86320eb8adb48106b899e21be5d5387d)|Win64 EXE||2015-07-03 07:38:16|%APPDATA%\Microsoft\Windows\XML Help\pa2-64.exe|
|[f1598a2901388dc5244931226d300633](https://www.virustotal.com/gui/file/f1598a2901388dc5244931226d300633)|Win32 EXE||2015-07-02 21:22:42|www.mehrnews.com|
|[326843b42fca324e9fd023058a6c6b7a](https://www.virustotal.com/gui/file/326843b42fca324e9fd023058a6c6b7a)|Win32 EXE|Skeeyah|2015-06-26 11:08:21| |
|[6f5a36fb82de3aecd847978846be312e](https://www.virustotal.com/gui/file/6f5a36fb82de3aecd847978846be312e)|Win32 EXE||2015-05-15 22:08:30|C:\Documents and Settings\Administrator\Local Settings\Temp\RarSFX0\tcwin.exe|
|[68b84d8057f6e6def9e191ed218da0ee](https://www.virustotal.com/gui/file/68b84d8057f6e6def9e191ed218da0ee)|Win32 EXE||2015-05-15 22:08:28|rreegg.exe|
|[80c9fc38e7f6d96a09feaa99b7777e7d](https://www.virustotal.com/gui/file/80c9fc38e7f6d96a09feaa99b7777e7d)|Win32 EXE||2015-05-15 22:08:25|%TEMP%\RarSFX0\ehtmlh.exe|
|[a05b6a10d7643a2ef059d7e296cb87a6](https://www.virustotal.com/gui/file/a05b6a10d7643a2ef059d7e296cb87a6)|Win32 DLL||2015-05-15 22:08:23|C:\Documents and Settings\Administrator\Local Settings\Temp\RarSFX0\dhtmlh.dll|
|[87878f5404083c4c0ebf7a78e386a487](https://www.virustotal.com/gui/file/87878f5404083c4c0ebf7a78e386a487)|Win32 EXE||2015-05-15 12:26:08| |
|[a314ff2714660be06f9eb49e6024c8c5](https://www.virustotal.com/gui/file/a314ff2714660be06f9eb49e6024c8c5)|Win32 EXE||2014-12-11 01:56:02|013edd19a9e796d54b82dc34a400a0981c5e17fd65a235dd45231e7ef06ee53b.bin|
|[b547b27751022900d9126a82d82a411f](https://www.virustotal.com/gui/file/b547b27751022900d9126a82d82a411f)|Win32 EXE||2014-12-11 01:55:51|e036dbf4b0e6b36526f8b4f180ac624cfdc8f756|
|[f4e7111f9a5cd4451d422bc009844ec5](https://www.virustotal.com/gui/file/f4e7111f9a5cd4451d422bc009844ec5)|Win32 DLL|Ursu|2014-12-11 01:55:15|abb636cbab0bc591ba94203f41635fff009304b6|
|[a0c46b3f8370f2a2a6486d0ac686363c](https://www.virustotal.com/gui/file/a0c46b3f8370f2a2a6486d0ac686363c)|Win32 EXE||2014-12-11 01:55:14|d7d58a818649eae5116ab26351993436fc1255ee|
|[2e8e25f179172778f8efefac33f2dcb7](https://www.virustotal.com/gui/file/2e8e25f179172778f8efefac33f2dcb7)|Win32 EXE||2014-12-11 01:54:47|e7eeb7781f521ddc5481626a2410ed8cc871809c36d8d8f74af9dd3f8c42505d.bin|
|[bb186b0f3f2a1e0ef51d86d3494fd3be](https://www.virustotal.com/gui/file/bb186b0f3f2a1e0ef51d86d3494fd3be)|Win32 EXE||2014-12-11 01:54:33|%TEMP%\RarSFX0\ehtmlh.exe|
|[64bd09506365a0cf351a56edb2bb2bdc](https://www.virustotal.com/gui/file/64bd09506365a0cf351a56edb2bb2bdc)|Win32 EXE||2014-01-08 12:10:59|de339d3fe5acf83a0df5991bcce02574e1f2c4749b6d0e8f9edc563ef4f91d79.bin|
