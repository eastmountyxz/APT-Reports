**NAME:**  
Rampant Kitten

 
**Description**:   
Rampant Kitten, named by Check Point, is an ongoing surveillance operation by Iranian entities that has been targeting Iranian expats and dissidents for years. It intends to steal the victim’s personal documents as well as access to their Telegram Desktop and KeePass account information. The Android backdoor could extract two-factor authentication codes from SMS messages, record the phone’s voice surroundings and more. Related telegram phishing pages were distributed by using fake Telegram service accounts.

  
**References**:  
https://research.checkpoint.com/2020/rampant-kitten-an-iranian-espionage-campaign
