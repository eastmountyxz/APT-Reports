|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4b32521cc8a8c050fbc55b3f9d05c84d](https://www.virustotal.com/gui/file/4b32521cc8a8c050fbc55b3f9d05c84d)|Win64 DLL||2019-12-26 15:48:06| |
|[21e79ae1d7a5f020c171f412cbb92253](https://www.virustotal.com/gui/file/21e79ae1d7a5f020c171f412cbb92253)|Win64 DLL||2019-12-26 15:47:19| |
|[27370ffd32942337596785ec737a4e46](https://www.virustotal.com/gui/file/27370ffd32942337596785ec737a4e46)|Win64 DLL||2019-12-26 15:46:22|WinBio.dll|
|[a8ba59eebd4858b8b448f13a436edf60](https://www.virustotal.com/gui/file/a8ba59eebd4858b8b448f13a436edf60)|Win64 DLL||2019-12-26 15:45:17|a8ba59eebd4858b8b448f13a436edf60.virobj|
|[d41532ae67394c2f158f943fcf9651b2](https://www.virustotal.com/gui/file/d41532ae67394c2f158f943fcf9651b2)|ZIP||2019-12-06 01:52:29|My documents for Chris.xlsb|
|[8615ebe2800a66125b02436f7b2682a6](https://www.virustotal.com/gui/file/8615ebe2800a66125b02436f7b2682a6)|Text||2019-10-14 21:18:25|payload_1.exe|
|[3d9c6d16f774ceb0af2cc4a7b63d49ed](https://www.virustotal.com/gui/file/3d9c6d16f774ceb0af2cc4a7b63d49ed)|XLS||2019-10-14 18:14:44|malware.malware|
|[a67d6e87283c34459b4660f19747a306](https://www.virustotal.com/gui/file/a67d6e87283c34459b4660f19747a306)|Win32 DLL||2019-10-03 18:39:27|DWrite.dll|
|[7248b00b3a6cdc571fd11a6c7ed01801](https://www.virustotal.com/gui/file/7248b00b3a6cdc571fd11a6c7ed01801)|FPX||2019-09-24 15:36:11|order.xlsb|
|[2a8303d42ba7fcaf282f6c9c3b72db76](https://www.virustotal.com/gui/file/2a8303d42ba7fcaf282f6c9c3b72db76)|FPX|o97m|2019-06-25 14:40:55|5fa5970548b43ae7d93d758a1eef1f12fd76891e36538e3ac170d5ab30906b5c.bin|
|[a3f0ffde9d9479f05e8c82983416a82a](https://www.virustotal.com/gui/file/a3f0ffde9d9479f05e8c82983416a82a)|FPX||2019-06-25 14:37:08|60dfe419dcba6dfe16d24f663b3393deeffdedbe4da468be63c63ec4b914d485.bin|
|[5515d682f943f390c8ff031ba2a8865b](https://www.virustotal.com/gui/file/5515d682f943f390c8ff031ba2a8865b)|FPX||2019-06-03 17:05:08|BroveryXlsV1_modXLS_22826.xlsb|
|[af2f4142463f42548b8650a3adf5ceb2](https://www.virustotal.com/gui/file/af2f4142463f42548b8650a3adf5ceb2)|Win32 DLL||2019-05-23 20:04:43|Dwrite.dll|
|[1a3945b2385d6a45a80d7082923dd81b](https://www.virustotal.com/gui/file/1a3945b2385d6a45a80d7082923dd81b)|XLSB||2019-03-02 18:05:30|Gilded.xlsb|
|[f002c0d3d5cd52851ada08124b5ef6f0](https://www.virustotal.com/gui/file/f002c0d3d5cd52851ada08124b5ef6f0)|Win32 EXE||2019-02-08 13:25:30|Crosses|
|[c6b1a4804f3e33572e038d3d97496666](https://www.virustotal.com/gui/file/c6b1a4804f3e33572e038d3d97496666)|DOC||2018-11-13 08:29:45|6e1230088a34678726102353c622445e1f8b8b8c9ce1f025d11bfffd5017ca82.bin|
|[107690af267e719dc1fd549832663560](https://www.virustotal.com/gui/file/107690af267e719dc1fd549832663560)|DOC||2018-11-02 17:26:28|107690af267e719dc1fd549832663560.virobj|
|[eb561d46c6283c632df88bd20ade6df4](https://www.virustotal.com/gui/file/eb561d46c6283c632df88bd20ade6df4)|unknown||2018-10-03 20:11:29|js2.js_|
|[d68351f754a508a386c06946c8e79088](https://www.virustotal.com/gui/file/d68351f754a508a386c06946c8e79088)|Win32 EXE|rozena|2018-10-03 20:09:26|exe2.exe_|
|[63c98b8c34ee9261c0068c7f0435a9f9](https://www.virustotal.com/gui/file/63c98b8c34ee9261c0068c7f0435a9f9)|Win32 EXE|Kryptik|2018-10-03 17:20:55|Openness.exe|
|[7b528c9d8150e4a4ab27b90a4e333763](https://www.virustotal.com/gui/file/7b528c9d8150e4a4ab27b90a4e333763)|Text||2018-08-07 13:01:59|7b528c9d8150e4a4ab27b90a4e333763.virus|
|[c517f48bf95a4f3ecba2046d12e62c88](https://www.virustotal.com/gui/file/c517f48bf95a4f3ecba2046d12e62c88)|DOC||2018-07-19 16:25:17|c517f48bf95a4f3ecba2046d12e62c88.virus|
|[9a0e6048f5fb0e4d2f5c5ecfb4f8e95c](https://www.virustotal.com/gui/file/9a0e6048f5fb0e4d2f5c5ecfb4f8e95c)|DOC|o97m|2018-07-17 10:35:19|Malware.doc|
|[08cd3c6596b092dd6373b4330bcb6b3a](https://www.virustotal.com/gui/file/08cd3c6596b092dd6373b4330bcb6b3a)|DOC|o97m|2018-07-04 08:46:48|doc1.doc|
|[202c872316052ce342b406feaccb0fe3](https://www.virustotal.com/gui/file/202c872316052ce342b406feaccb0fe3)|DOC|dynamer|2018-06-28 12:04:43|doc1.doc|
|[2dc7a793d7b3d016db91213040c4631e](https://www.virustotal.com/gui/file/2dc7a793d7b3d016db91213040c4631e)|DOC|o97m|2018-06-28 11:20:24|2806.doc|
|[38242fb29d7cb82a4ffd651189d9821e](https://www.virustotal.com/gui/file/38242fb29d7cb82a4ffd651189d9821e)|Win32 DLL||2018-06-19 08:59:28|OLESS.dll|
|[fb90dda9b53455c73a5d64df71217da1](https://www.virustotal.com/gui/file/fb90dda9b53455c73a5d64df71217da1)|DOC|Banload|2018-06-15 10:18:27|infected.doc|
|[94e1f07a34ad040bd1a00419dc7ba971](https://www.virustotal.com/gui/file/94e1f07a34ad040bd1a00419dc7ba971)|DOC|Banload|2018-06-07 12:09:38|Bank Statement.doc|
|[40c4c02d1e506a5ffc2939ec0ee8e105](https://www.virustotal.com/gui/file/40c4c02d1e506a5ffc2939ec0ee8e105)|DOC||2018-06-06 16:46:34|40c4c02d1e506a5ffc2939ec0ee8e105.virus|
|[f0645bd9367faf4e21a9c5e8c132bed7](https://www.virustotal.com/gui/file/f0645bd9367faf4e21a9c5e8c132bed7)|Win32 DLL||2018-06-03 11:33:15|f0645bd9367faf4e21a9c5e8c132bed7.virus|
|[5605bfdee5e31f55c23273e4e71de3ae](https://www.virustotal.com/gui/file/5605bfdee5e31f55c23273e4e71de3ae)|DOC||2018-05-29 10:22:39|Screenshot + payment.doc|
|[d8b1d9c0b7f9bf7b3ee9219d6891aadb](https://www.virustotal.com/gui/file/d8b1d9c0b7f9bf7b3ee9219d6891aadb)|DOC||2018-05-29 10:17:08|Malaware.doc|
|[34a58e62866e5c17db61ee5f95d52c58](https://www.virustotal.com/gui/file/34a58e62866e5c17db61ee5f95d52c58)|Win32 DLL|malagent|2018-05-29 07:47:39|OLESS.dll|
|[d7ca38e21327541787ab84bde83d7f81](https://www.virustotal.com/gui/file/d7ca38e21327541787ab84bde83d7f81)|DOC||2018-05-21 17:33:52|VirusShare_d7ca38e21327541787ab84bde83d7f81|
|[4bee6ff39103ffe31118260f9b1c4884](https://www.virustotal.com/gui/file/4bee6ff39103ffe31118260f9b1c4884)|unknown||2018-05-20 18:33:05|MGsCOxPSNK.txt|
|[c38b06f871d2268972fa01725b59d7ed](https://www.virustotal.com/gui/file/c38b06f871d2268972fa01725b59d7ed)|Text|Dorkbot|2018-05-19 19:46:02|VnnJ4.ps1|
|[09d43765c2259a8df868a5fa6206ae2b](https://www.virustotal.com/gui/file/09d43765c2259a8df868a5fa6206ae2b)|Text||2018-05-19 19:45:05|myvtfile.exe|
|[581c2a76b382deedb48d1df077e5bdf1](https://www.virustotal.com/gui/file/581c2a76b382deedb48d1df077e5bdf1)|Text||2018-05-18 17:17:29|tCrrDqBQoCcEkbnK.txt|
|[bbaee5d936a3809f46fd409b8442f753](https://www.virustotal.com/gui/file/bbaee5d936a3809f46fd409b8442f753)|Text||2018-05-18 16:04:13|robots_nl.web-cdn.kz.txt|
|[f0e52df398b938bf82d9e71ce754ab34](https://www.virustotal.com/gui/file/f0e52df398b938bf82d9e71ce754ab34)|Win32 DLL|Ursu|2018-05-18 13:04:23|tt|
|[1b21bd1af3100587ef8e6e5681a1e78e](https://www.virustotal.com/gui/file/1b21bd1af3100587ef8e6e5681a1e78e)|DOC|o97m|2018-05-17 20:56:24|1_VPS_89.134-Clean.doc|
|[a0a09fdfe4ce7e5ffab8e28935cd5142](https://www.virustotal.com/gui/file/a0a09fdfe4ce7e5ffab8e28935cd5142)|DOC||2018-05-17 19:19:49|1VPS.doc|
|[04979fbd0bacea3a4ded5f162efb399a](https://www.virustotal.com/gui/file/04979fbd0bacea3a4ded5f162efb399a)|DOC|o97m|2018-05-17 19:16:56|2Statement.doc|
|[90f35fd205556a04d13216c33cb0dbe3](https://www.virustotal.com/gui/file/90f35fd205556a04d13216c33cb0dbe3)|Win32 DLL|Dorkbot|2018-05-17 12:59:29|myfile.exe|
|[de394e9d294d2c325298eb54826ba116](https://www.virustotal.com/gui/file/de394e9d294d2c325298eb54826ba116)|ZIP||2018-05-17 08:33:45|dog.zip|
|[c2a9443aac258a60d8cace43e839cf9f](https://www.virustotal.com/gui/file/c2a9443aac258a60d8cace43e839cf9f)|DOC||2018-05-11 00:55:40|cqHfjCkTtMwG.doc|
|[bb784d55895db10b67b1b4f1f5b0be16](https://www.virustotal.com/gui/file/bb784d55895db10b67b1b4f1f5b0be16)|HTML|Carbanak|2018-05-11 00:55:39|KbhpQIcahFCuZwq.sct|
|[d117c73e353193118a6383c30e42a95f](https://www.virustotal.com/gui/file/d117c73e353193118a6383c30e42a95f)|RTF|CVE-2017-8570|2018-05-09 14:39:49|d117c73e353193118a6383c30e42a95f.virus|
|[e020668055eb1d22710aa07f72860075](https://www.virustotal.com/gui/file/e020668055eb1d22710aa07f72860075)|DOC||2018-05-03 15:27:29|e020668055eb1d22710aa07f72860075.virus|
|[fa93c93a02fe2dee8a3b3d1cd82f293f](https://www.virustotal.com/gui/file/fa93c93a02fe2dee8a3b3d1cd82f293f)|RTF|o97m|2018-04-19 17:20:18|fa93c93a02fe2dee8a3b3d1cd82f293f.virus|
|[302ab8bd6a8effa58a675165aa9600a2](https://www.virustotal.com/gui/file/302ab8bd6a8effa58a675165aa9600a2)|DOC||2018-02-22 02:27:12|302ab8bd6a8effa58a675165aa9600a2.virus|
|[e12b96177f08e70e5a3649326eb44b98](https://www.virustotal.com/gui/file/e12b96177f08e70e5a3649326eb44b98)|DOC||2018-02-20 18:12:57|doc2.doc";filename*=UTF-8''doc2.doc|
|[58fbf6f9405327d8d158a1eeac19b81a](https://www.virustotal.com/gui/file/58fbf6f9405327d8d158a1eeac19b81a)|DOC||2018-02-16 20:55:49|58fbf6f9405327d8d158a1eeac19b81a.virus|
|[bb1a76702e2e7d0aa23385f24683d214](https://www.virustotal.com/gui/file/bb1a76702e2e7d0aa23385f24683d214)|DOC||2018-02-01 20:06:04|bb1a76702e2e7d0aa23385f24683d214.virus|
|[5972597b729a7d2853a3b37444e58e01](https://www.virustotal.com/gui/file/5972597b729a7d2853a3b37444e58e01)|DOC|Banload|2018-01-13 06:03:49|5972597b729a7d2853a3b37444e58e01.virus|
|[762eef684e01831aa2f96031eff378bf](https://www.virustotal.com/gui/file/762eef684e01831aa2f96031eff378bf)|DOC||2017-12-26 17:28:06|762eef684e01831aa2f96031eff378bf.virus|
|[bdaa27c6284ff95c01178db7a96121a4](https://www.virustotal.com/gui/file/bdaa27c6284ff95c01178db7a96121a4)|ZIP||2017-12-19 13:25:11|dog.zip|
|[949b7e0f9d309e8a7ab32fa4664a7906](https://www.virustotal.com/gui/file/949b7e0f9d309e8a7ab32fa4664a7906)|unknown||2017-12-17 11:12:00|19564bb0f2c8573586fadcbd864939c6e622f85e5b595a7ac34a9bebaa3f6bf2.bin|
|[fa1c548a5d691ac9ce7bfd929f204261](https://www.virustotal.com/gui/file/fa1c548a5d691ac9ce7bfd929f204261)|RTF||2017-12-10 20:44:05|fa1c548a5d691ac9ce7bfd929f204261.virus|
|[c7b224d95fc96094afd2678cae753dcb](https://www.virustotal.com/gui/file/c7b224d95fc96094afd2678cae753dcb)|Win32 EXE|Kryptik|2017-12-03 15:16:28|Soulfulness|
|[92dfd0534b080234f9536371be63e37a](https://www.virustotal.com/gui/file/92dfd0534b080234f9536371be63e37a)|Win32 DLL|Dorkbot|2017-11-30 18:16:02|myfile.exe|
|[be1154e38df490e1dcbde3ffb2ebd05c](https://www.virustotal.com/gui/file/be1154e38df490e1dcbde3ffb2ebd05c)|Win32 EXE||2017-11-28 19:05:37|be1154e38df490e1dcbde3ffb2ebd05c.virus|
|[7f1aa2b2d539aa7d3dbb067417457309](https://www.virustotal.com/gui/file/7f1aa2b2d539aa7d3dbb067417457309)|Text||2017-11-28 08:00:45|7f1aa2b2d539aa7d3dbb067417457309.virus|
|[50598c4dc7c299d0cbd92c128a56944e](https://www.virustotal.com/gui/file/50598c4dc7c299d0cbd92c128a56944e)|ZIP||2017-11-26 09:42:00|dog.zip|
|[6da6025fc7956f644b0b161781071cec](https://www.virustotal.com/gui/file/6da6025fc7956f644b0b161781071cec)|ZIP||2017-11-18 20:59:32|b94bea7e82acec04e6f0f183bbcf6f9cac0fc94f|
|[2ded75ea4e55ed1dad579b9ce0eb01b2](https://www.virustotal.com/gui/file/2ded75ea4e55ed1dad579b9ce0eb01b2)|Win32 EXE||2017-11-16 02:56:59|FontArabic.exe|
|[6fff1d68203f8d23ccd23507ba00b9df](https://www.virustotal.com/gui/file/6fff1d68203f8d23ccd23507ba00b9df)|DOC||2017-11-13 12:22:29|6fff1d68203f8d23ccd23507ba00b9df.virus|
|[40240ea32029b6eaf3556798f3fb31d5](https://www.virustotal.com/gui/file/40240ea32029b6eaf3556798f3fb31d5)|Win32 EXE||2017-11-10 17:21:40|40240ea32029b6eaf3556798f3fb31d5.virus|
|[ccb6108b7d29e8f3af6275c1256dd82e](https://www.virustotal.com/gui/file/ccb6108b7d29e8f3af6275c1256dd82e)|unknown||2017-11-08 15:28:09|C:\users\public\documents\system.ps1|
|[dae11ed0013d58000f10919b8cba8023](https://www.virustotal.com/gui/file/dae11ed0013d58000f10919b8cba8023)|Text||2017-11-05 15:33:18|dog.js|
|[14f71d5cb8f15f0a9943b5d709a85b73](https://www.virustotal.com/gui/file/14f71d5cb8f15f0a9943b5d709a85b73)|Win32 EXE|Dorkbot|2017-11-03 05:58:41|48a92c81bace0b39ab211f512755ec35176748c6c53437f317d959ae649604c1|
|[c4aabdcf19898d9c30c4c2edea0147f0](https://www.virustotal.com/gui/file/c4aabdcf19898d9c30c4c2edea0147f0)|DOC||2017-11-01 11:47:13|1513c7630c981e4b1d0d5a55809166721df4f87bb0fac2d2b8ff6afae187f01d.bin|
|[dc8b30c5253f02a790a31f2853fe41f8](https://www.virustotal.com/gui/file/dc8b30c5253f02a790a31f2853fe41f8)|DOC|o97m|2017-10-31 20:27:40|dc8b30c5253f02a790a31f2853fe41f8.virus|
|[e6201af714dca6e030bad9c5d2188c7c](https://www.virustotal.com/gui/file/e6201af714dca6e030bad9c5d2188c7c)|DOC||2017-10-20 15:11:18|localfile~|
|[039d9e47e4474bee24785f8ec5307695](https://www.virustotal.com/gui/file/039d9e47e4474bee24785f8ec5307695)|Win32 DLL|Dorkbot|2017-10-19 04:34:49|myfile.exe|
|[e9154e2f80389b853ab4cf2fe98f1ed2](https://www.virustotal.com/gui/file/e9154e2f80389b853ab4cf2fe98f1ed2)|DOCX||2017-10-16 21:11:26|e9154e2f80389b853ab4cf2fe98f1ed2.virus|
|[973377e27b5dffa289f84e62a6833ebc](https://www.virustotal.com/gui/file/973377e27b5dffa289f84e62a6833ebc)|RTF||2017-10-16 21:11:25|973377e27b5dffa289f84e62a6833ebc.virus|
|[521c81c62836a233a6e771bc3491300f](https://www.virustotal.com/gui/file/521c81c62836a233a6e771bc3491300f)|Text||2017-10-16 08:36:45|setup.ps1|
|[54e7f3a1a1a8857e35a45f4eb2a3317d](https://www.virustotal.com/gui/file/54e7f3a1a1a8857e35a45f4eb2a3317d)|Text||2017-10-16 08:36:44|checkupdate.ps1|
|[47111e9854db533c328ddbe6e962602a](https://www.virustotal.com/gui/file/47111e9854db533c328ddbe6e962602a)|DOCX|o97m|2017-10-14 03:44:01|47111e9854db533c328ddbe6e962602a_TouyBnTF.dOcx|
|[8ca3631aeb9a1980e9a6514be32fe20e](https://www.virustotal.com/gui/file/8ca3631aeb9a1980e9a6514be32fe20e)|DOC|o97m|2017-10-13 21:12:33|1010-51c5ce5bf3514b9740d4ef588a8f6783ec5c038f|
|[d5cd1dedf3bf5c943e348a8b84e37b2a](https://www.virustotal.com/gui/file/d5cd1dedf3bf5c943e348a8b84e37b2a)|RTF||2017-10-12 21:30:48|d5cd1dedf3bf5c943e348a8b84e37b2a.virus|
|[9a273653364dfb143ff196d826d2bac4](https://www.virustotal.com/gui/file/9a273653364dfb143ff196d826d2bac4)|Text||2017-10-12 10:01:06|myvtfile.exe|
|[211fbf34749df5e717e8b11fecb3f648](https://www.virustotal.com/gui/file/211fbf34749df5e717e8b11fecb3f648)|ZIP||2017-10-11 13:42:58|dog.zip|
|[3917028799d2aa3a43ec5bad067e99a5](https://www.virustotal.com/gui/file/3917028799d2aa3a43ec5bad067e99a5)|RTF||2017-10-10 16:50:49|3917028799d2aa3a43ec5bad067e99a5.virus|
|[135238bc43fddd0867676aef1e9aaf83](https://www.virustotal.com/gui/file/135238bc43fddd0867676aef1e9aaf83)|DOCM||2017-10-09 07:57:14|135238bc43fddd0867676aef1e9aaf83.virus|
|[29a3666cee0762fcd731fa663ebc0011](https://www.virustotal.com/gui/file/29a3666cee0762fcd731fa663ebc0011)|DOCX|o97m|2017-10-06 18:28:29|29a3666cee0762fcd731fa663ebc0011.virus|
|[a8e312d0c230e226e97e7a441fadbd85](https://www.virustotal.com/gui/file/a8e312d0c230e226e97e7a441fadbd85)|RTF|o97m|2017-10-06 18:28:10|a8e312d0c230e226e97e7a441fadbd85.virus|
|[0e012c1e7383951d9e02b55a9762f160](https://www.virustotal.com/gui/file/0e012c1e7383951d9e02b55a9762f160)|DOC||2017-10-05 04:56:32|0e012c1e7383951d9e02b55a9762f160.virus|
|[26c543ef701d657acbbd66b9b9506498](https://www.virustotal.com/gui/file/26c543ef701d657acbbd66b9b9506498)|DOCM||2017-10-04 11:58:14|26c543ef701d657acbbd66b9b9506498.virus|
|[18124f26e6bc8d2c52b98a30fe209525](https://www.virustotal.com/gui/file/18124f26e6bc8d2c52b98a30fe209525)|ZIP||2017-10-04 11:57:52|18124f26e6bc8d2c52b98a30fe209525.virus|
|[3e6e37b381bf968c7718cb2323f275f8](https://www.virustotal.com/gui/file/3e6e37b381bf968c7718cb2323f275f8)|unknown||2017-10-04 11:28:39|C:\users\public\documents\system.vbs|
|[a86249a392b394c803ddbd5bbaa0b4bb](https://www.virustotal.com/gui/file/a86249a392b394c803ddbd5bbaa0b4bb)|DOC||2017-10-04 11:24:10|a86249a392b394c803ddbd5bbaa0b4bb.virus|
|[29573b1fa60bce8e04dd2a4d554a7447](https://www.virustotal.com/gui/file/29573b1fa60bce8e04dd2a4d554a7447)|Text||2017-10-02 16:40:10|checkupdate.ps1|
|[cf8f754beb57d684f4f39dfbac823edf](https://www.virustotal.com/gui/file/cf8f754beb57d684f4f39dfbac823edf)|unknown||2017-09-28 05:25:04|/home/virustotal/sample/CF8F754BEB57D684F4F39DFBAC823EDF|
|[b0a365d0648612dfc33d88183ff7b0f0](https://www.virustotal.com/gui/file/b0a365d0648612dfc33d88183ff7b0f0)|DOC||2017-09-26 10:54:39|b0a365d0648612dfc33d88183ff7b0f0.virus|
|[397d45b6001919b04739e26379c84dd9](https://www.virustotal.com/gui/file/397d45b6001919b04739e26379c84dd9)|DOCX||2017-09-25 15:03:11|397d45b6001919b04739e26379c84dd9.virus|
|[8608b31a446f42a7f36807bd6c16d2c0](https://www.virustotal.com/gui/file/8608b31a446f42a7f36807bd6c16d2c0)|RTF||2017-09-25 14:57:54|8608b31a446f42a7f36807bd6c16d2c0.virus|
|[65c64c5aa55d3d78f08456cb20012fcf](https://www.virustotal.com/gui/file/65c64c5aa55d3d78f08456cb20012fcf)|Win32 EXE|Ursu|2017-09-25 09:05:04|ArabicBrowserFont.exe|
|[d62182cf1638d69d53e76834f49c6b63](https://www.virustotal.com/gui/file/d62182cf1638d69d53e76834f49c6b63)|DOC||2017-09-24 08:10:18|d62182cf1638d69d53e76834f49c6b63.virus|
|[2d36634974c85eff393698b39edc561c](https://www.virustotal.com/gui/file/2d36634974c85eff393698b39edc561c)|RTF||2017-09-22 18:51:31|2d36634974c85eff393698b39edc561c.virus|
|[560e72858ee413d7a6f72fff5ab7577b](https://www.virustotal.com/gui/file/560e72858ee413d7a6f72fff5ab7577b)|RTF||2017-09-22 15:41:14|560e72858ee413d7a6f72fff5ab7577b.virus|
|[402c34d7d6ce92bf5a048023bd2fde4a](https://www.virustotal.com/gui/file/402c34d7d6ce92bf5a048023bd2fde4a)|DOCX||2017-09-22 15:40:02|402c34d7d6ce92bf5a048023bd2fde4a.virus|
|[b3fb88a5aa791aea141bf3b4cf045355](https://www.virustotal.com/gui/file/b3fb88a5aa791aea141bf3b4cf045355)|ZIP||2017-09-21 12:51:25|dog.zip|
|[21a09cf81f3584a741c7167f622d6c50](https://www.virustotal.com/gui/file/21a09cf81f3584a741c7167f622d6c50)|Text||2017-09-20 18:50:16|ee993da34d2d28ab8dd08da73d8741b7d5eb2a0a77ad7b6878f766042af0bc9f.bin|
|[e184219366afb2e6bd0b9502beab1156](https://www.virustotal.com/gui/file/e184219366afb2e6bd0b9502beab1156)|RTF||2017-09-20 17:52:43|e184219366afb2e6bd0b9502beab1156.virus|
|[2a4d16ddad27c6eb60e197b6b07c2df0](https://www.virustotal.com/gui/file/2a4d16ddad27c6eb60e197b6b07c2df0)|Win32 DLL|Dorkbot|2017-09-20 10:50:17|myfile.exe|
|[1fbe77a3b5771ce4f95e02a49c5b7f30](https://www.virustotal.com/gui/file/1fbe77a3b5771ce4f95e02a49c5b7f30)|DOCX||2017-09-19 19:30:12|1fbe77a3b5771ce4f95e02a49c5b7f30.virus|
|[d1f55491472ca747561509106b71eab8](https://www.virustotal.com/gui/file/d1f55491472ca747561509106b71eab8)|RTF||2017-09-19 19:28:50|d1f55491472ca747561509106b71eab8.virus|
|[a5f75333d0c81387a5a9c7696b967a20](https://www.virustotal.com/gui/file/a5f75333d0c81387a5a9c7696b967a20)|RTF||2017-09-18 16:21:35|a5f75333d0c81387a5a9c7696b967a20.virus|
|[edc4f02f265a4aaa552435f293409f01](https://www.virustotal.com/gui/file/edc4f02f265a4aaa552435f293409f01)|RTF||2017-09-18 15:07:35|edc4f02f265a4aaa552435f293409f01.virus|
|[2dae76cff6dc1eecc70b4c9568911804](https://www.virustotal.com/gui/file/2dae76cff6dc1eecc70b4c9568911804)|FPX||2017-09-17 17:15:05|2dae76cff6dc1eecc70b4c9568911804.virus|
|[9f00ac3bef01d2e3d8ebc48c3468d5c0](https://www.virustotal.com/gui/file/9f00ac3bef01d2e3d8ebc48c3468d5c0)|DOCM||2017-09-17 13:51:48|9f00ac3bef01d2e3d8ebc48c3468d5c0.virus|
|[9aff95239539aa28270612a0ceda3a67](https://www.virustotal.com/gui/file/9aff95239539aa28270612a0ceda3a67)|Text||2017-09-17 13:28:18|9aff95239539aa28270612a0ceda3a67.virus|
|[672de2d22aaff8f70c87c616001519fd](https://www.virustotal.com/gui/file/672de2d22aaff8f70c87c616001519fd)|FPX||2017-09-17 09:41:40|672de2d22aaff8f70c87c616001519fd.virus|
|[0873ddb4df8320b493a719bdddd7d182](https://www.virustotal.com/gui/file/0873ddb4df8320b493a719bdddd7d182)|DOCM||2017-09-17 07:11:51|0873ddb4df8320b493a719bdddd7d182.virus|
|[189c72bfd8ae31abcff5e7da691a7d30](https://www.virustotal.com/gui/file/189c72bfd8ae31abcff5e7da691a7d30)|DOC||2017-09-15 17:51:42|189c72bfd8ae31abcff5e7da691a7d30.virus|
|[0e0a51489054529a9dcb177d39f08b81](https://www.virustotal.com/gui/file/0e0a51489054529a9dcb177d39f08b81)|RTF||2017-09-15 14:26:20|0e0a51489054529a9dcb177d39f08b81.virus|
|[0d6619481cfd29791a51ebb42ace5c03](https://www.virustotal.com/gui/file/0d6619481cfd29791a51ebb42ace5c03)|DOCX||2017-09-14 14:33:53|0d6619481cfd29791a51ebb42ace5c03.virus|
|[511af2b4c62fa4c2bb91f3be1ca96094](https://www.virustotal.com/gui/file/511af2b4c62fa4c2bb91f3be1ca96094)|RTF||2017-09-14 14:32:36|511af2b4c62fa4c2bb91f3be1ca96094.virus|
|[82a32d98e68891625b6de67a9d0b61c6](https://www.virustotal.com/gui/file/82a32d98e68891625b6de67a9d0b61c6)|DOCX||2017-09-13 14:52:04|82a32d98e68891625b6de67a9d0b61c6.virus|
|[c5e94d973ed4f963ddc09ab88def3b5f](https://www.virustotal.com/gui/file/c5e94d973ed4f963ddc09ab88def3b5f)|RTF||2017-09-13 14:46:55|c5e94d973ed4f963ddc09ab88def3b5f.virus|
|[94771bcf572d5c0b834f73d577f06cc8](https://www.virustotal.com/gui/file/94771bcf572d5c0b834f73d577f06cc8)|RTF||2017-09-12 18:29:39|94771bcf572d5c0b834f73d577f06cc8.virus|
|[c6cddc475d62503a17a34419918e7fc0](https://www.virustotal.com/gui/file/c6cddc475d62503a17a34419918e7fc0)|RTF||2017-09-12 14:37:08|c6cddc475d62503a17a34419918e7fc0.virus|
|[c90e22b6579a3447836e299cbc5d0af0](https://www.virustotal.com/gui/file/c90e22b6579a3447836e299cbc5d0af0)|DOC||2017-09-12 09:00:39|c90e22b6579a3447836e299cbc5d0af0.virus|
|[8bd798e89d075827cc757b9586f15ce2](https://www.virustotal.com/gui/file/8bd798e89d075827cc757b9586f15ce2)|RTF||2017-09-06 15:09:32|8bd798e89d075827cc757b9586f15ce2.virus|
|[47f6cddb718e3a44299d6f6cb502992d](https://www.virustotal.com/gui/file/47f6cddb718e3a44299d6f6cb502992d)|FPX||2017-09-06 10:44:36|/home/virustotal/sample/47F6CDDB718E3A44299D6F6CB502992D|
|[0e53da32937cb3718988026d9e96a5f0](https://www.virustotal.com/gui/file/0e53da32937cb3718988026d9e96a5f0)|DOCM||2017-09-06 10:33:58|0e53da32937cb3718988026d9e96a5f0.virus|
|[e17fe2978ebe1b0a6923acd2ffeda3c2](https://www.virustotal.com/gui/file/e17fe2978ebe1b0a6923acd2ffeda3c2)|RTF||2017-09-04 16:42:54|e17fe2978ebe1b0a6923acd2ffeda3c2.virus|
|[ebc529b32422b6385b6ba3416c7afe13](https://www.virustotal.com/gui/file/ebc529b32422b6385b6ba3416c7afe13)|DOC||2017-08-30 07:17:40|ebc529b32422b6385b6ba3416c7afe13.virus|
|[5c8fb51f64d7ad7b01173715b02e447a](https://www.virustotal.com/gui/file/5c8fb51f64d7ad7b01173715b02e447a)|Text||2017-08-21 21:11:00|5c8fb51f64d7ad7b01173715b02e447a.virus|
|[d4088f8202e0eb27f90e692f988f0780](https://www.virustotal.com/gui/file/d4088f8202e0eb27f90e692f988f0780)|DOC||2017-08-18 17:28:43|d4088f8202e0eb27f90e692f988f0780.virus|
|[170edf8b58126a5e69ef31b67953589a](https://www.virustotal.com/gui/file/170edf8b58126a5e69ef31b67953589a)|Text||2017-08-18 11:56:08|170edf8b58126a5e69ef31b67953589a.virus|
|[a9c50b7761519fb684cdee2d59f99f91](https://www.virustotal.com/gui/file/a9c50b7761519fb684cdee2d59f99f91)|RTF||2017-08-16 15:32:04|a9c50b7761519fb684cdee2d59f99f91.virus|
|[ee5a600ef9fd1defe07ea097095d1beb](https://www.virustotal.com/gui/file/ee5a600ef9fd1defe07ea097095d1beb)|RTF||2017-08-11 16:43:45|ee5a600ef9fd1defe07ea097095d1beb.virus|
|[5dd2e677fd1d65f051b7f54e7402721f](https://www.virustotal.com/gui/file/5dd2e677fd1d65f051b7f54e7402721f)|DOC||2017-08-11 15:16:34|5dd2e677fd1d65f051b7f54e7402721f.virus|
|[87327b4045b9d004697aec7e7a4b9ba8](https://www.virustotal.com/gui/file/87327b4045b9d004697aec7e7a4b9ba8)|Text||2017-08-10 01:11:39|598b04712b1308.59820880.ps1|
|[31fcf8a4ec7a4c693eda9336321cf401](https://www.virustotal.com/gui/file/31fcf8a4ec7a4c693eda9336321cf401)|Text||2017-08-10 01:07:16|a94c797957408db3650298597be87e6d73fb4ee1dd455e1925d928a909e199fe.js.bin|
|[d38fb2d95812ffa1014e52ef3079e5da](https://www.virustotal.com/gui/file/d38fb2d95812ffa1014e52ef3079e5da)|DOCX||2017-08-09 15:05:30|d38fb2d95812ffa1014e52ef3079e5da.virus|
|[03e85ad4217775906e6b5ceae8dc27af](https://www.virustotal.com/gui/file/03e85ad4217775906e6b5ceae8dc27af)|RTF||2017-08-09 15:04:59|03e85ad4217775906e6b5ceae8dc27af.virus|
|[79628a598303692238cc4aeb19da6fed](https://www.virustotal.com/gui/file/79628a598303692238cc4aeb19da6fed)|DOCX||2017-08-08 15:34:45|79628a598303692238cc4aeb19da6fed.virus|
|[21926646a658bdf39cf28cdfbb1aced7](https://www.virustotal.com/gui/file/21926646a658bdf39cf28cdfbb1aced7)|RTF||2017-08-08 15:34:03|21926646a658bdf39cf28cdfbb1aced7.virus|
|[41c6861313e731bd3f84dd70360573ce](https://www.virustotal.com/gui/file/41c6861313e731bd3f84dd70360573ce)|DOCX||2017-08-03 15:10:11|Dooq.docx|
|[9bb09ab6a057d9363fdc88bd5b1f7323](https://www.virustotal.com/gui/file/9bb09ab6a057d9363fdc88bd5b1f7323)|DOC||2017-07-30 10:04:15|9bb09ab6a057d9363fdc88bd5b1f7323.virus|
|[63e2eb258a85ed4e72f951cdbff2a58e](https://www.virustotal.com/gui/file/63e2eb258a85ed4e72f951cdbff2a58e)|DOCX||2017-07-27 17:12:35|63e2eb258a85ed4e72f951cdbff2a58e.virus|
|[f80a80d25b3393825baa1e84e76ddf6c](https://www.virustotal.com/gui/file/f80a80d25b3393825baa1e84e76ddf6c)|DOCX||2017-07-25 20:47:47|Doc0725.docx|
|[9788b3faa29ba9eb4cae46f3c249937e](https://www.virustotal.com/gui/file/9788b3faa29ba9eb4cae46f3c249937e)|RTF||2017-07-25 20:46:19|9788b3faa29ba9eb4cae46f3c249937e.virus|
|[6a860285a6f7521995151a2a0cb6e316](https://www.virustotal.com/gui/file/6a860285a6f7521995151a2a0cb6e316)|RTF||2017-07-21 18:55:16|6a860285a6f7521995151a2a0cb6e316.virus|
|[70f0f8db551dd6b084682188c3923e26](https://www.virustotal.com/gui/file/70f0f8db551dd6b084682188c3923e26)|DOCX||2017-07-20 20:45:37|70f0f8db551dd6b084682188c3923e26.virus|
|[24fab1e9831e57307d17981abaabf960](https://www.virustotal.com/gui/file/24fab1e9831e57307d17981abaabf960)|RTF||2017-07-19 18:17:00|menu.rtf|
|[6adec78e874232722c3758bbbcb95829](https://www.virustotal.com/gui/file/6adec78e874232722c3758bbbcb95829)|RTF||2017-07-19 15:47:46|6adec78e874232722c3758bbbcb95829.virus|
|[101bdbbd99cfd74aa5724842404642f2](https://www.virustotal.com/gui/file/101bdbbd99cfd74aa5724842404642f2)|DOCX||2017-07-19 15:36:03|101bdbbd99cfd74aa5724842404642f2.virus|
|[ddc9b71808be3a0e180e2befae4ff433](https://www.virustotal.com/gui/file/ddc9b71808be3a0e180e2befae4ff433)|Win32 DLL||2017-07-19 07:25:51|ddc9b71808be3a0e180e2befae4ff433.virus|
|[9b1af2d9c0c0687c70466385800b6847](https://www.virustotal.com/gui/file/9b1af2d9c0c0687c70466385800b6847)|DOC||2017-07-17 19:02:25|/home/dennis/Documents/bayes/anunak/cf86c7a92451dca1ebb76ebd3e469f3fa0d9b376487ee6d07ae57ab1b65a86f8.exe|
|[499ebef3ab31a2f98fc8a358bd085b0f](https://www.virustotal.com/gui/file/499ebef3ab31a2f98fc8a358bd085b0f)|DOCX||2017-07-17 15:54:31|499ebef3ab31a2f98fc8a358bd085b0f.virus|
|[5d49b444734b003b6917b81f0a779b3e](https://www.virustotal.com/gui/file/5d49b444734b003b6917b81f0a779b3e)|RTF||2017-07-17 15:51:46|5d49b444734b003b6917b81f0a779b3e.virus|
|[eccae23b894dccbfe15280af2d18dbaf](https://www.virustotal.com/gui/file/eccae23b894dccbfe15280af2d18dbaf)|DOC||2017-07-15 10:59:21|eccae23b894dccbfe15280af2d18dbaf.virus|
|[2cff793da6fec0731206d82d6213985e](https://www.virustotal.com/gui/file/2cff793da6fec0731206d82d6213985e)|DOC||2017-07-15 01:46:56|2cff793da6fec0731206d82d6213985e.virus|
|[8ae284d547bd1b8bd6bc2431735f9142](https://www.virustotal.com/gui/file/8ae284d547bd1b8bd6bc2431735f9142)|Win32 EXE||2017-07-14 14:49:42|8ae284d547bd1b8bd6bc2431735f9142.virus|
|[caec3babdec3cf267cc846fd084c4626](https://www.virustotal.com/gui/file/caec3babdec3cf267cc846fd084c4626)|DOCX||2017-07-14 14:40:29|caec3babdec3cf267cc846fd084c4626.virus|
|[dde72a54716deb88c1ffef2a63faab6b](https://www.virustotal.com/gui/file/dde72a54716deb88c1ffef2a63faab6b)|RTF||2017-07-14 14:38:20|dde72a54716deb88c1ffef2a63faab6b.virus|
|[3b12f36a01326ec649e4def08b860339](https://www.virustotal.com/gui/file/3b12f36a01326ec649e4def08b860339)|DOCX||2017-07-12 15:59:20|3b12f36a01326ec649e4def08b860339.virus|
|[793511c86a0469d579ff8cc99a7311e3](https://www.virustotal.com/gui/file/793511c86a0469d579ff8cc99a7311e3)|RTF||2017-07-12 15:56:54|793511c86a0469d579ff8cc99a7311e3.virus|
|[ecd8879702347966750c37247ef6c2e6](https://www.virustotal.com/gui/file/ecd8879702347966750c37247ef6c2e6)|Win32 EXE||2017-07-12 05:03:04|ecd8879702347966750c37247ef6c2e6.virus|
|[72d973ebfbc00d26170bfafdfbbd0179](https://www.virustotal.com/gui/file/72d973ebfbc00d26170bfafdfbbd0179)|RTF||2017-07-11 17:59:26|72d973ebfbc00d26170bfafdfbbd0179.virus|
|[4b7a742d5c98fc62f0f67445032e7bc6](https://www.virustotal.com/gui/file/4b7a742d5c98fc62f0f67445032e7bc6)|RTF||2017-07-10 15:23:40|4b7a742d5c98fc62f0f67445032e7bc6.virus|
|[1a9d799f9f35f63fc7eb5d558cba5202](https://www.virustotal.com/gui/file/1a9d799f9f35f63fc7eb5d558cba5202)|RTF||2017-07-07 18:12:09|1a9d799f9f35f63fc7eb5d558cba5202.virus|
|[9217e861d8d2f9c727d79c82a17341e8](https://www.virustotal.com/gui/file/9217e861d8d2f9c727d79c82a17341e8)|RTF||2017-07-06 18:38:56|df22408833b2ae58f0d3e2fe87581be31972ef56e0ebf5efafc4e6e0341b5521.bin|
|[8e1e7f5ad99e48b740fd00085eab1f84](https://www.virustotal.com/gui/file/8e1e7f5ad99e48b740fd00085eab1f84)|Win32 EXE|Kryptik|2017-07-05 18:25:48|8e1e7f5ad99e48b740fd00085eab1f84.virus|
|[17fabe288d640476a70154c59d5a1ba1](https://www.virustotal.com/gui/file/17fabe288d640476a70154c59d5a1ba1)|DOCX||2017-07-05 16:13:34|17fabe288d640476a70154c59d5a1ba1.virus|
|[22ad7c05128ca7b48b0a2a4507803b16](https://www.virustotal.com/gui/file/22ad7c05128ca7b48b0a2a4507803b16)|RTF||2017-07-05 16:11:13|22ad7c05128ca7b48b0a2a4507803b16.virus|
|[9ae433cd5397af6b485f1abb06b2c5a2](https://www.virustotal.com/gui/file/9ae433cd5397af6b485f1abb06b2c5a2)|Win32 EXE||2017-07-03 16:53:25|9ae433cd5397af6b485f1abb06b2c5a2.virus|
|[a3754fba24f85d1d1bb7c0382e41586b](https://www.virustotal.com/gui/file/a3754fba24f85d1d1bb7c0382e41586b)|Win32 EXE|Kryptik|2017-07-02 17:39:44|a3754fba24f85d1d1bb7c0382e41586b.virus|
|[467062d2a5a341716c42c6d7f36ba0ed](https://www.virustotal.com/gui/file/467062d2a5a341716c42c6d7f36ba0ed)|DOC||2017-06-30 14:39:28|check.doc|
|[c3f48e69bb90be828ba2835b76fb2080](https://www.virustotal.com/gui/file/c3f48e69bb90be828ba2835b76fb2080)|DOCX||2017-06-28 14:54:08|HALFBAKED-FIN7-7cc7b0b36fd6c4af1e42931747c1e7a6f26229859f1ea7b313ce039b6aacc4c0|
|[856cec68ddd28367c0d0f0a6f566187a](https://www.virustotal.com/gui/file/856cec68ddd28367c0d0f0a6f566187a)|RTF||2017-06-28 14:43:58|856cec68ddd28367c0d0f0a6f566187a.virus|
|[3a303f02e16d7d27fa78c3f48a55d992](https://www.virustotal.com/gui/file/3a303f02e16d7d27fa78c3f48a55d992)|RTF||2017-06-19 17:51:35|3a303f02e16d7d27fa78c3f48a55d992.virus|
|[f2ac2ec8173db4963dc2089ac90b8807](https://www.virustotal.com/gui/file/f2ac2ec8173db4963dc2089ac90b8807)|DOCX||2017-06-14 20:28:26|f2ac2ec8173db4963dc2089ac90b8807.virus|
|[6ac5ae6546746e3a9502cc489b71146e](https://www.virustotal.com/gui/file/6ac5ae6546746e3a9502cc489b71146e)|RTF||2017-06-14 17:52:14|VirusShare_6ac5ae6546746e3a9502cc489b71146e|
|[3769eaa65241470cff39cdeeca5a6d60](https://www.virustotal.com/gui/file/3769eaa65241470cff39cdeeca5a6d60)|DOC||2017-06-13 09:07:19|/home/virustotal/sample/3769EAA65241470CFF39CDEECA5A6D60|
|[782f4fdba196563fa2ba94014a4528f8](https://www.virustotal.com/gui/file/782f4fdba196563fa2ba94014a4528f8)|DOC|o97m|2017-06-13 05:38:33|782f4fdba196563fa2ba94014a4528f8.virus|
|[67c9bfd4d6ac397fb0cd7da2441a6fe2](https://www.virustotal.com/gui/file/67c9bfd4d6ac397fb0cd7da2441a6fe2)|DOCX||2017-06-12 19:53:37|67c9bfd4d6ac397fb0cd7da2441a6fe2.virus|
|[325844f1b956c52fc220932bc717f224](https://www.virustotal.com/gui/file/325844f1b956c52fc220932bc717f224)|RTF||2017-06-12 19:47:31|325844f1b956c52fc220932bc717f224.virus|
|[c0eba408923c9c60fd4b02fa49c2c8fb](https://www.virustotal.com/gui/file/c0eba408923c9c60fd4b02fa49c2c8fb)|RTF||2017-06-08 18:26:15|Chick Fil A Order.rtf|
|[ec935be37d48eba308dd0d9068b79c32](https://www.virustotal.com/gui/file/ec935be37d48eba308dd0d9068b79c32)|DOC|w2km|2017-06-05 04:25:12|ec935be37d48eba308dd0d9068b79c32.virus|
|[525c978806d1e7080d649a6ab105621e](https://www.virustotal.com/gui/file/525c978806d1e7080d649a6ab105621e)|DOC|skeeyah|2017-06-05 04:21:55|525c978806d1e7080d649a6ab105621e.virus|
|[1f98c4ff12fc2c6fbf8247a5b2e4e7f4](https://www.virustotal.com/gui/file/1f98c4ff12fc2c6fbf8247a5b2e4e7f4)|DOCX|o97m|2017-06-02 16:52:51|1f98c4ff12fc2c6fbf8247a5b2e4e7f4.virus|
|[1a6c18967f4ce1c91c77098af4957e6e](https://www.virustotal.com/gui/file/1a6c18967f4ce1c91c77098af4957e6e)|DOCX||2017-06-01 16:10:20|1a6c18967f4ce1c91c77098af4957e6e.virus|
|[99975b5ee2ddd31e89c9bdda7a3871d9](https://www.virustotal.com/gui/file/99975b5ee2ddd31e89c9bdda7a3871d9)|DOCX||2017-05-12 19:30:14|99975b5ee2ddd31e89c9bdda7a3871d9.virus|
|[c0d122bcdcb6ede7fc7f1182e4d0e599](https://www.virustotal.com/gui/file/c0d122bcdcb6ede7fc7f1182e4d0e599)|RTF||2017-05-12 18:24:48|c0d122bcdcb6ede7fc7f1182e4d0e599.virus|
|[c8b8420d1503ae48ff35362f5d29eeb3](https://www.virustotal.com/gui/file/c8b8420d1503ae48ff35362f5d29eeb3)|RTF||2017-05-11 16:22:33|c8b8420d1503ae48ff35362f5d29eeb3.virus|
|[effdaf7f61acb277ac44ee4d9bc8900a](https://www.virustotal.com/gui/file/effdaf7f61acb277ac44ee4d9bc8900a)|RTF||2017-05-10 19:50:57|effdaf7f61acb277ac44ee4d9bc8900a.virus|
|[291a17814d5dbb5bce5b186334cde4b1](https://www.virustotal.com/gui/file/291a17814d5dbb5bce5b186334cde4b1)|Win32 EXE||2017-05-08 19:48:41|291a17814d5dbb5bce5b186334cde4b1.virus|
|[6a41660e0fc6d462b53456aad4c0802b](https://www.virustotal.com/gui/file/6a41660e0fc6d462b53456aad4c0802b)|ZIP|w2km|2017-05-07 07:09:45|6a41660e0fc6d462b53456aad4c0802b.virus|
|[822ccf0b4923feb7ccdf4735d059eb80](https://www.virustotal.com/gui/file/822ccf0b4923feb7ccdf4735d059eb80)|DOC|w2km|2017-05-07 05:41:33|822ccf0b4923feb7ccdf4735d059eb80.virus|
|[9eb71edd5ec99294a1c341efa780b1b1](https://www.virustotal.com/gui/file/9eb71edd5ec99294a1c341efa780b1b1)|RTF||2017-05-05 18:11:29|Doc0505_1.rtf|
|[52cf6a63da29331d805a5a9b5015580f](https://www.virustotal.com/gui/file/52cf6a63da29331d805a5a9b5015580f)|DOCX||2017-05-05 15:49:02|52cf6a63da29331d805a5a9b5015580f.virus|
|[9b87f9f6498c241f50208f9906907195](https://www.virustotal.com/gui/file/9b87f9f6498c241f50208f9906907195)|RTF||2017-05-05 15:47:21|9b87f9f6498c241f50208f9906907195.virus|
|[7b2315ff1f2d763857aa70ad34b75449](https://www.virustotal.com/gui/file/7b2315ff1f2d763857aa70ad34b75449)|RTF||2017-05-04 20:52:30|7b2315ff1f2d763857aa70ad34b75449.virus|
|[74165408ff12d195fb9d68afe0a6011e](https://www.virustotal.com/gui/file/74165408ff12d195fb9d68afe0a6011e)|RTF||2017-05-04 19:17:18|Doc_0405.rtf|
|[e36d7fc794563090ffc1bd5784c67c05](https://www.virustotal.com/gui/file/e36d7fc794563090ffc1bd5784c67c05)|DOC|skeeyah|2017-05-04 07:56:51|e36d7fc794563090ffc1bd5784c67c05.virus|
|[1f5022a02c82fbe414dc91bf3f1b5180](https://www.virustotal.com/gui/file/1f5022a02c82fbe414dc91bf3f1b5180)|RTF||2017-05-03 19:39:05|1f5022a02c82fbe414dc91bf3f1b5180.virus|
|[894bb661d03e26713ca96cb058d7c470](https://www.virustotal.com/gui/file/894bb661d03e26713ca96cb058d7c470)|DOC|w2km|2017-05-03 07:31:41|/home/virustotal/sample/894BB661D03E26713CA96CB058D7C470|
|[7d664485c53b98180e6f3c69e9dfa81e](https://www.virustotal.com/gui/file/7d664485c53b98180e6f3c69e9dfa81e)|RTF||2017-04-28 17:53:40|7d664485c53b98180e6f3c69e9dfa81e.virus|
|[189c5a090d2b3b87ab65a8b156cd971e](https://www.virustotal.com/gui/file/189c5a090d2b3b87ab65a8b156cd971e)|RTF||2017-04-26 19:11:58|189c5a090d2b3b87ab65a8b156cd971e.virus|
|[42a2a2352f6b1f5818f3b695f240fc3a](https://www.virustotal.com/gui/file/42a2a2352f6b1f5818f3b695f240fc3a)|RTF||2017-04-26 16:19:25|42a2a2352f6b1f5818f3b695f240fc3a.virus|
|[5a0b796c7a6040e02c822cac4475f11a](https://www.virustotal.com/gui/file/5a0b796c7a6040e02c822cac4475f11a)|DOCX||2017-04-25 21:06:32|5a0b796c7a6040e02c822cac4475f11a.virus|
|[307a9ce257e97189e046fa91d3c27dab](https://www.virustotal.com/gui/file/307a9ce257e97189e046fa91d3c27dab)|RTF||2017-04-25 20:49:32|inf-943(1).rtf|
|[76eb6f124fba6599a54e92b829c55b63](https://www.virustotal.com/gui/file/76eb6f124fba6599a54e92b829c55b63)|DOCX|o97m|2017-04-24 23:48:50|76eb6f124fba6599a54e92b829c55b63.virus|
|[2dc0f4bece10759307026d90f585e006](https://www.virustotal.com/gui/file/2dc0f4bece10759307026d90f585e006)|RTF||2017-04-24 15:57:14|2dc0f4bece10759307026d90f585e006.virus|
|[b5cc86726ab8f1fb3c281ab8f935260f](https://www.virustotal.com/gui/file/b5cc86726ab8f1fb3c281ab8f935260f)|DOCX||2017-04-24 15:56:17|b5cc86726ab8f1fb3c281ab8f935260f.virus|
|[4b3dac0a4f452b07d29f26b119180bd2](https://www.virustotal.com/gui/file/4b3dac0a4f452b07d29f26b119180bd2)|Win32 EXE|rozena|2017-04-23 08:22:21|4b3dac0a4f452b07d29f26b119180bd2.virus|
|[562a64f1c09306d385962cf8084b6827](https://www.virustotal.com/gui/file/562a64f1c09306d385962cf8084b6827)|RTF|o97m|2017-04-18 19:10:03|562a64f1c09306d385962cf8084b6827.virus|
|[22e7d4f7401ef34b3b6d17c15291c497](https://www.virustotal.com/gui/file/22e7d4f7401ef34b3b6d17c15291c497)|DOCX||2017-04-18 19:09:13|22e7d4f7401ef34b3b6d17c15291c497.virus|
|[1a9e113b2f3caa7a141a94c8bc187ea7](https://www.virustotal.com/gui/file/1a9e113b2f3caa7a141a94c8bc187ea7)|RTF|o97m|2017-04-13 18:36:10|1a9e113b2f3caa7a141a94c8bc187ea7.virus|
|[619aa4e6c9db275381ab0e7fc7078f5f](https://www.virustotal.com/gui/file/619aa4e6c9db275381ab0e7fc7078f5f)|RTF||2017-04-07 17:01:41|VirusShare_619aa4e6c9db275381ab0e7fc7078f5f|
|[3c0bd71e91e0f18621ba43de4419f901](https://www.virustotal.com/gui/file/3c0bd71e91e0f18621ba43de4419f901)|RTF||2017-04-03 16:38:47|3c0bd71e91e0f18621ba43de4419f901.virus|
|[e494356fc0db7ef6009d29e5ae869717](https://www.virustotal.com/gui/file/e494356fc0db7ef6009d29e5ae869717)|DOCX||2017-03-31 22:52:45|inf6.docx|
|[749c5085cda920e830cfed32842ba835](https://www.virustotal.com/gui/file/749c5085cda920e830cfed32842ba835)|Win32 EXE||2017-03-26 09:05:48|749c5085cda920e830cfed32842ba835.virus|
|[754fc509328af413d93131e65fc46d31](https://www.virustotal.com/gui/file/754fc509328af413d93131e65fc46d31)|DOCX||2017-03-24 18:06:30|754fc509328af413d93131e65fc46d31.virus|
|[6a5a42ed234910121dbb7d1994ab5a5e](https://www.virustotal.com/gui/file/6a5a42ed234910121dbb7d1994ab5a5e)|DOCX||2017-03-23 19:56:01|6A5A42ED234910121DBB7D1994AB5A5E.virus|
|[b5829caad7c448c558cb1dab2d9f4320](https://www.virustotal.com/gui/file/b5829caad7c448c558cb1dab2d9f4320)|DOCX||2017-03-23 14:03:11|b5829caad7c448c558cb1dab2d9f4320.virus|
|[6cbb2b429ad3d4e07124162b7ad91883](https://www.virustotal.com/gui/file/6cbb2b429ad3d4e07124162b7ad91883)|DOC||2017-03-08 19:14:52|6cbb2b429ad3d4e07124162b7ad91883.virus|
|[f026b17758d7716ee28755c0fd403b61](https://www.virustotal.com/gui/file/f026b17758d7716ee28755c0fd403b61)|XLS||2017-03-01 06:54:53|f026b17758d7716ee28755c0fd403b61.virus|
|[03f9281912cfe47ce44372a0a8747047](https://www.virustotal.com/gui/file/03f9281912cfe47ce44372a0a8747047)|XLS||2017-03-01 06:52:10|03f9281912cfe47ce44372a0a8747047.virus|
|[91c00802c7f0caa10d6cf0e890a6d5f6](https://www.virustotal.com/gui/file/91c00802c7f0caa10d6cf0e890a6d5f6)|XLS||2017-03-01 06:33:36|91c00802c7f0caa10d6cf0e890a6d5f6.virus|
|[61065bc9a617867a04e3da60bdf2b903](https://www.virustotal.com/gui/file/61065bc9a617867a04e3da60bdf2b903)|XLS||2017-02-28 13:06:21|61065bc9a617867a04e3da60bdf2b903.virus|
|[d04b6410dddee19adec75f597c52e386](https://www.virustotal.com/gui/file/d04b6410dddee19adec75f597c52e386)|DOC||2017-02-22 15:26:31|d04b6410dddee19adec75f597c52e386.virus|
|[cc89ddac1afe69069eb18bac58c6a9e4](https://www.virustotal.com/gui/file/cc89ddac1afe69069eb18bac58c6a9e4)|DOTM||2017-02-21 21:56:09|cccb193de86fd7ff876e875c32305f33dc48843dc1180fb04be573014e944c09.bin|
|[5dace5ac5ba89c9bba4479264f75b2b6](https://www.virustotal.com/gui/file/5dace5ac5ba89c9bba4479264f75b2b6)|RTF|o97m|2017-02-20 19:24:51|5dace5ac5ba89c9bba4479264f75b2b6.virus|
|[5a88e3825c5e89b07fa9050b6b6eca7c](https://www.virustotal.com/gui/file/5a88e3825c5e89b07fa9050b6b6eca7c)|DOC|Kryptik|2017-02-17 19:26:45|/data/cfs/malshare/5a88e3825c5e89b07fa9050b6b6eca7c|
|[2abad0ae32dd72bac5da0af1e580a2eb](https://www.virustotal.com/gui/file/2abad0ae32dd72bac5da0af1e580a2eb)|DOC|w2km|2017-02-13 10:41:07|2abad0ae32dd72bac5da0af1e580a2eb_bEGGjcUEeA.dOc|
|[f20328b49ec605fd425ed101ff31f14b](https://www.virustotal.com/gui/file/f20328b49ec605fd425ed101ff31f14b)|DOC||2017-01-31 20:38:12|f20328b49ec605fd425ed101ff31f14b.virus|
|[14334c8f93f049659212773ecee477a2](https://www.virustotal.com/gui/file/14334c8f93f049659212773ecee477a2)|DOC|skeeyah|2017-01-31 20:38:05|14334c8f93f049659212773ecee477a2.virus|
|[ccd2372bb6b07f1b5a125e597005688d](https://www.virustotal.com/gui/file/ccd2372bb6b07f1b5a125e597005688d)|DOC|valyria|2017-01-31 20:34:02|ccd2372bb6b07f1b5a125e597005688d.virus|
|[f74958adcfb11abcb37e043013f6a90f](https://www.virustotal.com/gui/file/f74958adcfb11abcb37e043013f6a90f)|DOC|valyria|2017-01-31 20:33:59|f74958adcfb11abcb37e043013f6a90f.virus|
|[8fa8d4c30429c099dc7e565e57db55c0](https://www.virustotal.com/gui/file/8fa8d4c30429c099dc7e565e57db55c0)|DOC|valyria|2017-01-31 20:30:11|8fa8d4c30429c099dc7e565e57db55c0.virus|
|[37d323ffc33a0e1c6cd20234589a965d](https://www.virustotal.com/gui/file/37d323ffc33a0e1c6cd20234589a965d)|DOC|valyria|2017-01-31 20:29:53|37d323ffc33a0e1c6cd20234589a965d.virus|
|[032fe02e54a010d21fd71e97596f4101](https://www.virustotal.com/gui/file/032fe02e54a010d21fd71e97596f4101)|DOC|valyria|2017-01-31 20:28:49|032fe02e54a010d21fd71e97596f4101.virus|
|[6ff3272cd9edf115230bad6a55cb3ca8](https://www.virustotal.com/gui/file/6ff3272cd9edf115230bad6a55cb3ca8)|DOC|valyria|2017-01-31 20:27:58|6ff3272cd9edf115230bad6a55cb3ca8.virus|
|[cea2989309ccd5128f437335622978f1](https://www.virustotal.com/gui/file/cea2989309ccd5128f437335622978f1)|RTF||2017-01-13 16:45:25|cea2989309ccd5128f437335622978f1.virus|
|[4b783bd0bd7fcf880ca75359d9fc4da6](https://www.virustotal.com/gui/file/4b783bd0bd7fcf880ca75359d9fc4da6)|RTF||2016-12-27 16:46:54|4b783bd0bd7fcf880ca75359d9fc4da6.rtf|
|[cf4ccb3707e5597969738b4754782e4d](https://www.virustotal.com/gui/file/cf4ccb3707e5597969738b4754782e4d)|RTF||2016-12-15 22:12:18|cf4ccb3707e5597969738b4754782e4d.virus|
|[ae8404ad422e92b1be7561c418c35fb7](https://www.virustotal.com/gui/file/ae8404ad422e92b1be7561c418c35fb7)|DOCX||2016-12-15 21:46:04|BELLHOP-c9f3e017b921c3d90127b25ef2f0c770a7fcbb429177284115ad18569ba4a441|
|[af53db730732aa7db5fdd45ebba34b94](https://www.virustotal.com/gui/file/af53db730732aa7db5fdd45ebba34b94)|RTF||2016-12-12 19:53:42|af53db730732aa7db5fdd45ebba34b94.virus|
|[b14bc8cbc7f2d36179ebff96ade6d867](https://www.virustotal.com/gui/file/b14bc8cbc7f2d36179ebff96ade6d867)|PDF||2016-12-01 15:04:19|b14bc8cbc7f2d36179ebff96ade6d867.virus|
|[d5fbfd2d1d71405a755c73e1cac5df23](https://www.virustotal.com/gui/file/d5fbfd2d1d71405a755c73e1cac5df23)|DOCX||2016-11-15 14:45:12|2-reservation-1.docx|
|[80eed9f87a18b0093eb3f16fa495b6f7](https://www.virustotal.com/gui/file/80eed9f87a18b0093eb3f16fa495b6f7)|RTF|Carbanak|2016-11-08 17:17:32|80eed9f87a18b0093eb3f16fa495b6f7.virus|
|[4eda75dfd4d12eda6a6219423b5972bd](https://www.virustotal.com/gui/file/4eda75dfd4d12eda6a6219423b5972bd)|Win32 EXE||2016-10-24 18:16:13|4eda75dfd4d12eda6a6219423b5972bd.virus|
|[6a537d3aea21b633f80a1ddde0f33c18](https://www.virustotal.com/gui/file/6a537d3aea21b633f80a1ddde0f33c18)|FPX|o97m|2016-10-21 19:25:47|oleObject1.bin|
|[4ec7088aac32c94a7046810925bc1697](https://www.virustotal.com/gui/file/4ec7088aac32c94a7046810925bc1697)|C++||2016-10-13 19:33:36|TransbaseOdbcDriver.js|
|[36f36696b948b550ad4afe4b0bc53fbd](https://www.virustotal.com/gui/file/36f36696b948b550ad4afe4b0bc53fbd)|Win32 EXE|Kryptik|2016-10-13 01:57:10|36f36696b948b550ad4afe4b0bc53fbd_uFDMNULwDKbjMsmDJRvSFX.EXe|
|[c61dc9d26ac2b0bebca00c9c1b8bb9b3](https://www.virustotal.com/gui/file/c61dc9d26ac2b0bebca00c9c1b8bb9b3)|Win32 DLL|PoisonIvy|2016-10-11 17:59:43|112|
|[b4d48f3e1ae339f2fcb94b7abceecfff](https://www.virustotal.com/gui/file/b4d48f3e1ae339f2fcb94b7abceecfff)|DOCX||2016-10-11 16:28:20|b4d48f3e1ae339f2fcb94b7abceecfff.virus|
|[06b9e2fdd2c0eeb78b851c93ca66f25f](https://www.virustotal.com/gui/file/06b9e2fdd2c0eeb78b851c93ca66f25f)|DOCX||2016-10-06 01:53:59|06b9e2fdd2c0eeb78b851c93ca66f25f.virus|
|[30c4d4dd1e2ca4b56102a4c547fafce7](https://www.virustotal.com/gui/file/30c4d4dd1e2ca4b56102a4c547fafce7)|Win64 EXE||2016-10-05 18:38:25|deskperf.dll|
|[61054bdfd5220ecc37956c713f126d43](https://www.virustotal.com/gui/file/61054bdfd5220ecc37956c713f126d43)|Win32 DLL|dynamer|2016-09-21 14:48:31|1d9ded30af0f90bf61a685a3ee8eb9bc2ad36f82e824550e4781f7047163095a.dll.bin|
|[d4c1af678b3afa099f21ab5c29065fca](https://www.virustotal.com/gui/file/d4c1af678b3afa099f21ab5c29065fca)|Win32 DLL|dynamer|2016-09-19 11:24:04|crss.dll1|
|[f472e0cbebe609774ea93347d3913130](https://www.virustotal.com/gui/file/f472e0cbebe609774ea93347d3913130)|Win32 EXE||2016-09-12 09:10:54|f472e0cbebe609774ea93347d3913130.virus|
|[59453862a00339305eb848a95fba4782](https://www.virustotal.com/gui/file/59453862a00339305eb848a95fba4782)|unknown|CobaltStrike|2016-09-09 11:35:04|D:\ATM-image\1363addfrommemdump\process.0x8a16e030.0x3a20000.dmp|
|[7acb0eeca94a6eb902ba516f465bcfc6](https://www.virustotal.com/gui/file/7acb0eeca94a6eb902ba516f465bcfc6)|unknown|CobaltStrike|2016-09-09 11:34:58|D:\ATM-image\1363addfrommemdump\process.0x8a16e030.0x1ec0000.dmp|
|[2cd6451bf78b588bb253acaf899f74f5](https://www.virustotal.com/gui/file/2cd6451bf78b588bb253acaf899f74f5)|Win32 EXE||2016-09-09 08:11:03|D:\ATM-image\mem\infected\executable.3672.exe|
|[3c6d7b180f16c17f10f5e5b85998cbb1](https://www.virustotal.com/gui/file/3c6d7b180f16c17f10f5e5b85998cbb1)|Win32 EXE|graftor|2016-09-07 18:05:05|e40ff8bcdbea418dec3619bab309a131f489818c|
|[ff589433a19d91513e69f2ee36774cc5](https://www.virustotal.com/gui/file/ff589433a19d91513e69f2ee36774cc5)|Win32 EXE|razy|2016-09-04 21:13:45| |
|[e7aa5608c81ba4fcd8d166501b90fc06](https://www.virustotal.com/gui/file/e7aa5608c81ba4fcd8d166501b90fc06)|Win32 EXE||2016-09-04 14:44:21|myfile.exe|
|[6e9408c338e98a8bc166a8d4f8264019](https://www.virustotal.com/gui/file/6e9408c338e98a8bc166a8d4f8264019)|Win32 EXE||2016-09-01 02:21:21|Repossessions Commensurations|
|[c6ec176592ea26c4ee27974273e592ff](https://www.virustotal.com/gui/file/c6ec176592ea26c4ee27974273e592ff)|Win32 EXE|Carbanak|2016-08-30 19:36:43|c6ec176592ea26c4ee27974273e592ff.virus|
|[7a5fa7a9e9319e0871d2098a02f0bcfa](https://www.virustotal.com/gui/file/7a5fa7a9e9319e0871d2098a02f0bcfa)|FPX||2016-08-26 22:18:03|7a5fa7a9e9319e0871d2098a02f0bcfa_npeuTifuBfhnAmwGrDjx.Doc|
|[fbf653b89a0814f515ddbdcf82cc3795](https://www.virustotal.com/gui/file/fbf653b89a0814f515ddbdcf82cc3795)|DOCX||2016-08-26 18:37:37|024.DOC.Claim_Dave.docx|
|[e938f73a10e3d2afbd77dd8ecb3a3854](https://www.virustotal.com/gui/file/e938f73a10e3d2afbd77dd8ecb3a3854)|Win32 EXE||2016-08-18 20:54:22| |
|[e06a0257449fa8dc4ab8ccb6fbf2c50b](https://www.virustotal.com/gui/file/e06a0257449fa8dc4ab8ccb6fbf2c50b)|Win32 EXE|Zbot|2016-08-18 20:52:20| |
|[dbd7d010c4657b94f49ca85e4ff88790](https://www.virustotal.com/gui/file/dbd7d010c4657b94f49ca85e4ff88790)|Win32 EXE|graftor|2016-08-18 20:51:08| |
|[c179ad6f118c97d3db5e04308d48f89e](https://www.virustotal.com/gui/file/c179ad6f118c97d3db5e04308d48f89e)|Win32 EXE||2016-08-18 20:36:51| |
|[b79f7d41e30cf7d69a4d5d19dda8942e](https://www.virustotal.com/gui/file/b79f7d41e30cf7d69a4d5d19dda8942e)|Win32 EXE|graftor|2016-08-18 20:22:33| |
|[fbc310a9c431577f3489237d48763eea](https://www.virustotal.com/gui/file/fbc310a9c431577f3489237d48763eea)|Win32 EXE||2016-08-18 13:10:28| |
|[f4eddae1c0b40bfedeb89e814a2267a5](https://www.virustotal.com/gui/file/f4eddae1c0b40bfedeb89e814a2267a5)|Win32 EXE||2016-08-18 13:05:14| |
|[ef8e417e5adb2366a3279d6680c3b979](https://www.virustotal.com/gui/file/ef8e417e5adb2366a3279d6680c3b979)|Win32 EXE||2016-08-18 13:05:11| |
|[eaee5bf17195a03d6bf7189965ee1bdb](https://www.virustotal.com/gui/file/eaee5bf17195a03d6bf7189965ee1bdb)|Win32 EXE||2016-08-18 12:58:16| |
|[e742242f28842480e5c2b3357b7fd6ab](https://www.virustotal.com/gui/file/e742242f28842480e5c2b3357b7fd6ab)|Win32 EXE||2016-08-18 12:55:14| |
|[d943ccb4a3c802d304ac29df259d14f2](https://www.virustotal.com/gui/file/d943ccb4a3c802d304ac29df259d14f2)|Win32 EXE||2016-08-18 12:50:09| |
|[a8dc8985226b7b2c468bb82bad3e4d76](https://www.virustotal.com/gui/file/a8dc8985226b7b2c468bb82bad3e4d76)|Win32 EXE||2016-08-18 12:06:06| |
|[5443b81fbb439972de9e45d801ce907a](https://www.virustotal.com/gui/file/5443b81fbb439972de9e45d801ce907a)|Win32 EXE||2016-08-18 02:19:18| |
|[50f70e18fe0dedabefe9bf7679b6d56c](https://www.virustotal.com/gui/file/50f70e18fe0dedabefe9bf7679b6d56c)|Win32 EXE||2016-08-18 01:04:24| |
|[36cdf98bc79b6997dd4e3a6bed035dca](https://www.virustotal.com/gui/file/36cdf98bc79b6997dd4e3a6bed035dca)|Win32 EXE||2016-08-18 01:00:08| |
|[1300432e537e7ba07840adecf38e543b](https://www.virustotal.com/gui/file/1300432e537e7ba07840adecf38e543b)|Win32 EXE|razy|2016-08-17 18:32:38|AspScal.exe|
|[1046652e0aaa682f89068731fa5e8e50](https://www.virustotal.com/gui/file/1046652e0aaa682f89068731fa5e8e50)|Win32 EXE|Kryptik|2016-08-17 18:32:07|/home/virustotal/sample/1046652E0AAA682F89068731FA5E8E50.3B1013A7|
|[874058e8d8582bf85c115ce319c5b0af](https://www.virustotal.com/gui/file/874058e8d8582bf85c115ce319c5b0af)|Win32 EXE|Kryptik|2016-08-17 18:31:08| |
|[39012fb6f3a93897f6c5edb1a57f76a0](https://www.virustotal.com/gui/file/39012fb6f3a93897f6c5edb1a57f76a0)|Win32 EXE||2016-08-17 18:24:49| |
|[9865bb3b4e7112ec9269a98e029cf5cb](https://www.virustotal.com/gui/file/9865bb3b4e7112ec9269a98e029cf5cb)|Win32 EXE|Carbanak|2016-08-17 18:23:48| |
|[735ff7defe0aaa24e13b6795b8e85539](https://www.virustotal.com/gui/file/735ff7defe0aaa24e13b6795b8e85539)|Win32 EXE||2016-08-17 17:38:56| |
|[93e44ecfcffdbb1f7f3119251ddb7670](https://www.virustotal.com/gui/file/93e44ecfcffdbb1f7f3119251ddb7670)|Win32 EXE||2016-08-17 17:13:40| |
|[88c0af9266679e655298ce19e231dff1](https://www.virustotal.com/gui/file/88c0af9266679e655298ce19e231dff1)|Win32 EXE|foreign|2016-08-17 17:13:00|sdu_v42|
|[16cda323189d8eba4248c0a2f5ad0d8f](https://www.virustotal.com/gui/file/16cda323189d8eba4248c0a2f5ad0d8f)|Win32 EXE|Kryptik|2016-08-17 16:53:09| |
|[15a4eb525072642bb43f3c188a7c3504](https://www.virustotal.com/gui/file/15a4eb525072642bb43f3c188a7c3504)|Win32 EXE|Kryptik|2016-08-17 16:52:25| |
|[9ad8c68b478e9030859d8395d3fdb870](https://www.virustotal.com/gui/file/9ad8c68b478e9030859d8395d3fdb870)|Win32 EXE||2016-08-17 16:19:13|/DATA/etri_data/Data/Bin/20160902/vs/F06678BBD3170DDAE7202946C456E53D043C7B79FCF00E0CF56BD997040754BD|
|[08f83d98b18d3dff16c35a20e24ed49a](https://www.virustotal.com/gui/file/08f83d98b18d3dff16c35a20e24ed49a)|Win32 DLL|razy|2016-08-17 16:13:02|/home/virustotal/sample/08F83D98B18D3DFF16C35A20E24ED49A|
|[7b30231709f1ac69e4c9db584be692f0](https://www.virustotal.com/gui/file/7b30231709f1ac69e4c9db584be692f0)|Win32 EXE||2016-08-17 14:01:53| |
|[5da203fa799d79ed5dde485c1ed6ba76](https://www.virustotal.com/gui/file/5da203fa799d79ed5dde485c1ed6ba76)|Win32 EXE||2016-08-17 13:56:45| |
|[1f43a8803498482d360befc6dfab4218](https://www.virustotal.com/gui/file/1f43a8803498482d360befc6dfab4218)|Win32 EXE|Carbanak|2016-08-17 12:35:08|MT Tick|
|[184efc90afea91922eb48da3eb9af050](https://www.virustotal.com/gui/file/184efc90afea91922eb48da3eb9af050)|Win32 EXE|Zbot|2016-08-10 19:10:06|Opera|
|[342652dab8a5fb7073a99438abd5d28a](https://www.virustotal.com/gui/file/342652dab8a5fb7073a99438abd5d28a)|Win32 EXE|Locky|2016-08-10 06:06:05|$_0_|
|[f425e731d0cee5b49dc4d32b74156b80](https://www.virustotal.com/gui/file/f425e731d0cee5b49dc4d32b74156b80)|Win32 EXE|Tinba|2016-08-10 02:09:15|Odinaff.exe|
|[32eae3a8fd4a06819466dd07ca363c4f](https://www.virustotal.com/gui/file/32eae3a8fd4a06819466dd07ca363c4f)|Win32 EXE|KillDisk|2016-08-10 02:02:59|dropper.exe|
|[e91fc5e15fa391d180779b47d511980b](https://www.virustotal.com/gui/file/e91fc5e15fa391d180779b47d511980b)|Win32 EXE|agentwdcr|2016-08-09 06:40:34|e07267bbfcbff72a9aff1872603ffbb630997c36a1d9a565843cb59bc5d97d90.exe|
|[e2a6b351c276d02d71e18cd0677e8236](https://www.virustotal.com/gui/file/e2a6b351c276d02d71e18cd0677e8236)|DOC||2016-08-04 20:15:38|e2a6b351c276d02d71e18cd0677e8236.virus|
|[bbd99ef280efebe9066c0aef91bf02cd](https://www.virustotal.com/gui/file/bbd99ef280efebe9066c0aef91bf02cd)|MS Word Document||2016-07-30 14:14:02|bbd99ef280efebe9066c0aef91bf02cd.virus|
|[28ad8e3a225400a1d00f6023f8e6c9c8](https://www.virustotal.com/gui/file/28ad8e3a225400a1d00f6023f8e6c9c8)|DOCX|Banload|2016-07-26 19:51:27|28ad8e3a225400a1d00f6023f8e6c9c8.virus|
|[db80d28b89c248cd60b5a7db98a99c08](https://www.virustotal.com/gui/file/db80d28b89c248cd60b5a7db98a99c08)|Win32 EXE|ursu|2016-07-23 21:25:08|trhdytuytu|
|[188f261e5fca94bd1fc1edc1aafee8c0](https://www.virustotal.com/gui/file/188f261e5fca94bd1fc1edc1aafee8c0)|Win32 EXE|graftor|2016-07-12 07:11:08|188f261e5fca94bd1fc1edc1aafee8c0.virus|
|[13a5fab598763ae4141955f2903d66f9](https://www.virustotal.com/gui/file/13a5fab598763ae4141955f2903d66f9)|Win64 EXE||2016-07-08 05:39:06|13a5fab598763ae4141955f2903d66f9_fqQegKdNzLaS.ExE|
|[62659e1c3ab3b1feb85614ec15e1d701](https://www.virustotal.com/gui/file/62659e1c3ab3b1feb85614ec15e1d701)|DOC||2016-07-06 14:07:55|Alpha Trade Group.doc|
|[1c02c6b68025768d056805d26d33af4f](https://www.virustotal.com/gui/file/1c02c6b68025768d056805d26d33af4f)|Win32 EXE|razy|2016-07-05 18:41:17|JAVAW.exe|
|[bf077200aa5072279f7bb6c42676dd08](https://www.virustotal.com/gui/file/bf077200aa5072279f7bb6c42676dd08)|Win32 EXE||2016-06-30 18:25:33|sdu_v42|
|[75b55bb34dac9d02740b9ad6b6820360](https://www.virustotal.com/gui/file/75b55bb34dac9d02740b9ad6b6820360)|Win32 EXE||2016-06-30 13:28:30|c:\windows\psexesvc.exe|
|[27304b246c7d5b4e149124d5f93c5b01](https://www.virustotal.com/gui/file/27304b246c7d5b4e149124d5f93c5b01)|Win32 EXE||2016-06-30 13:21:27|PsExec|
|[0f556e5099e497b97865cff0a585cb29](https://www.virustotal.com/gui/file/0f556e5099e497b97865cff0a585cb29)|Win32 EXE|strictor|2016-06-11 22:51:31|DVT.AVVoiceChanger.RegistrationLoader.exe|
|[2828ea78cdda8f21187572c99ded6dc2](https://www.virustotal.com/gui/file/2828ea78cdda8f21187572c99ded6dc2)|Win32 EXE|deni|2016-05-27 22:29:18|2828ea78cdda8f21187572c99ded6dc2.virus|
|[5a45366da2a8023464d7ea09fd80ba9f](https://www.virustotal.com/gui/file/5a45366da2a8023464d7ea09fd80ba9f)|Win32 EXE|Kryptik|2016-05-27 00:46:23|2503bdaeaa264bfc67b3a3603ee48ddb7b964d6466fac0377885c6649209c098.bin|
|[bdd53483ebc48bddb67c02af7d86e27d](https://www.virustotal.com/gui/file/bdd53483ebc48bddb67c02af7d86e27d)|Win32 EXE||2016-05-25 17:05:14|VNCViewer|
|[5f73beb23c45006ad952a71fa62c6f9f](https://www.virustotal.com/gui/file/5f73beb23c45006ad952a71fa62c6f9f)|Win32 EXE||2016-05-20 15:59:07|5f73beb23c45006ad952a71fa62c6f9f.virus|
|[63241a3580cd1135170b044a84005e92](https://www.virustotal.com/gui/file/63241a3580cd1135170b044a84005e92)|Win32 EXE||2016-05-18 16:28:10|63241a3580cd1135170b044a84005e92.virus|
|[80bee18fba8db4ae56120ef860cf82a2](https://www.virustotal.com/gui/file/80bee18fba8db4ae56120ef860cf82a2)|Win32 EXE|KillDisk|2016-05-16 00:56:33|C:/Users/seongmin/Documents/VT2/malware/20170925/80bee18fba8db4ae56120ef860cf82a2.vir|
|[6d355ffa06ae39fc8671cc8ac38f984e](https://www.virustotal.com/gui/file/6d355ffa06ae39fc8671cc8ac38f984e)|Win32 EXE||2016-05-16 00:44:54|C:\Users\PC\Desktop\SWIFT log suppressors|
|[64b40780a94c4c4d1c1b4a0b12ce4b7d](https://www.virustotal.com/gui/file/64b40780a94c4c4d1c1b4a0b12ce4b7d)|Win32 EXE|dynamer|2016-05-12 00:21:32|Win32.Trojan.Agent@ae38884398fe3f26110bc3ca09e9103706d4da142276dbcdba0a9f176e0c275c.bin|
|[1e94f1fdf5ace5e57d8b7832ea2da22e](https://www.virustotal.com/gui/file/1e94f1fdf5ace5e57d8b7832ea2da22e)|Win64 EXE||2016-05-03 15:20:43|netscan.exe|
|[cb5e9706c05d21a1912e02c3bcc877f9](https://www.virustotal.com/gui/file/cb5e9706c05d21a1912e02c3bcc877f9)|Win32 EXE|Symmi|2016-05-01 16:29:41|win64.exe|
|[7bd2235f105dee20825b4395a04892bf](https://www.virustotal.com/gui/file/7bd2235f105dee20825b4395a04892bf)|DOC||2016-04-28 13:53:36|7bd2235f105dee20825b4395a04892bf.virus|
|[4bf691809224d17e49cebb071d22a867](https://www.virustotal.com/gui/file/4bf691809224d17e49cebb071d22a867)|DOC||2016-04-27 10:48:56|4bf691809224d17e49cebb071d22a867.virus|
|[fb6f9e615ca2d7585cd8381e43e9bc01](https://www.virustotal.com/gui/file/fb6f9e615ca2d7585cd8381e43e9bc01)|Win32 EXE||2016-04-25 09:14:13|restart_helper.exe|
|[e0ca85c0d264b84d977df0c48fd383cc](https://www.virustotal.com/gui/file/e0ca85c0d264b84d977df0c48fd383cc)|DOC||2016-04-18 09:20:34|e0ca85c0d264b84d977df0c48fd383cc.virus|
|[853a53419d9dbc606d2392b99e60c173](https://www.virustotal.com/gui/file/853a53419d9dbc606d2392b99e60c173)|DOC||2016-04-15 11:40:19|853a53419d9dbc606d2392b99e60c173.virus|
|[7e75a6c270f92c5cec18899c59f7d0f6](https://www.virustotal.com/gui/file/7e75a6c270f92c5cec18899c59f7d0f6)|Win32 EXE||2016-04-08 00:33:28| |
|[3715d57632a08df9897b0c87461a1f22](https://www.virustotal.com/gui/file/3715d57632a08df9897b0c87461a1f22)|Win32 EXE|Androm|2016-04-06 02:06:10|3715d57632a08df9897b0c87461a1f22.virus|
|[520d03a2b4158fa2b8cb0751ca996f7c](https://www.virustotal.com/gui/file/520d03a2b4158fa2b8cb0751ca996f7c)|Win32 EXE||2016-03-30 02:53:40|Copy of _00150000.mem.dat|
|[88718cc6c00683af78a6f04e4d977bb9](https://www.virustotal.com/gui/file/88718cc6c00683af78a6f04e4d977bb9)|Win32 EXE|Andromeda|2016-03-27 16:24:27|C:\1\1\1\user_logins\bak\Коллекция\37AE.tmp|
|[03bead6a263c179e848f14bf81b6f038](https://www.virustotal.com/gui/file/03bead6a263c179e848f14bf81b6f038)|Win32 EXE|razy|2016-03-26 10:13:28|smb.exe|
|[145e5fce55f6972a661411f842e58545](https://www.virustotal.com/gui/file/145e5fce55f6972a661411f842e58545)|Win32 EXE|Cryptowall|2016-03-21 20:00:29|Zello|
|[744d7f1946e65e6e76d647493585bf44](https://www.virustotal.com/gui/file/744d7f1946e65e6e76d647493585bf44)|Win32 EXE||2016-03-17 03:10:26|744d7f1946e65e6e76d647493585bf44.exe|
|[4ddafef0a42bc4baa885148180c50218](https://www.virustotal.com/gui/file/4ddafef0a42bc4baa885148180c50218)|Win32 EXE||2016-03-15 22:11:56|4ddafef0a42bc4baa885148180c50218.exe|
|[2be66a8b0c41ae32057ff3d086208594](https://www.virustotal.com/gui/file/2be66a8b0c41ae32057ff3d086208594)|PPT||2016-03-11 12:48:22|malware do not open - TRANSACTION REF NO L16000265 - malware do not open.ppt|
|[c6b57e042ceadb60d6fab217d3523e17](https://www.virustotal.com/gui/file/c6b57e042ceadb60d6fab217d3523e17)|Win32 EXE|kazy|2016-03-10 18:44:34|c6b57e042ceadb60d6fab217d3523e17.virus|
|[1cf6638e2df1c68d84521c5edf4365ba](https://www.virustotal.com/gui/file/1cf6638e2df1c68d84521c5edf4365ba)|Win32 EXE||2016-03-09 22:55:53|genranit.exe|
|[6f1ce2830557812f16d07a71e9beb065](https://www.virustotal.com/gui/file/6f1ce2830557812f16d07a71e9beb065)|Win32 EXE||2016-03-07 22:56:09|genranit.exe|
|[200d2182c417a9b919fc0635174277ef](https://www.virustotal.com/gui/file/200d2182c417a9b919fc0635174277ef)|DOC|Darkcomet|2016-03-05 17:40:03|Reverse debit posted in Error 040316.doc|
|[a06bf47c5147ad1b336633112a4a42a8](https://www.virustotal.com/gui/file/a06bf47c5147ad1b336633112a4a42a8)|Win32 EXE||2016-03-05 14:14:50|a06bf47c5147ad1b336633112a4a42a8.exe|
|[8bf90a3c890fa9017067559764ca7219](https://www.virustotal.com/gui/file/8bf90a3c890fa9017067559764ca7219)|DOC||2016-03-05 11:02:03|remitter request_2016-03-05-122839.doc|
|[1f1e6409fcc0e86166d38b774d9839cb](https://www.virustotal.com/gui/file/1f1e6409fcc0e86166d38b774d9839cb)|Win32 EXE||2016-03-04 01:31:18|genranit.exe|
|[31d649c3a3c88e6ddc2bb26118d5f9a5](https://www.virustotal.com/gui/file/31d649c3a3c88e6ddc2bb26118d5f9a5)|Win32 EXE||2016-03-03 06:10:19|degetereci.exe|
|[9b7da7602bbd939e269d8b6470176959](https://www.virustotal.com/gui/file/9b7da7602bbd939e269d8b6470176959)|Win32 EXE|Upatre|2016-03-02 21:59:21|run|
|[3de80e0d49e37ed46e572db458eae462](https://www.virustotal.com/gui/file/3de80e0d49e37ed46e572db458eae462)|Win32 DLL||2016-03-02 21:43:30|600894d20a1e76a8ac1b458c6827d451094c1f17|
|[bec09215f6e4bc094a73f23e50108f3e](https://www.virustotal.com/gui/file/bec09215f6e4bc094a73f23e50108f3e)|Win32 EXE|Zbot|2016-03-02 13:43:38|degetereci.exe|
|[e292dd1cc79c924116f86ace7fd5d02f](https://www.virustotal.com/gui/file/e292dd1cc79c924116f86ace7fd5d02f)|ZIP|java|2016-03-02 07:49:42|captioned_transactionutrno_fftt16044002829-dtd02032016imagejpg.jar|
|[73e2f201cbac763327d21bd39470996b](https://www.virustotal.com/gui/file/73e2f201cbac763327d21bd39470996b)|Win32 EXE|Upatre|2016-03-01 23:33:10|run|
|[6723b08d260f825b7d05904af88e6820](https://www.virustotal.com/gui/file/6723b08d260f825b7d05904af88e6820)|Win32 EXE|Upatre|2016-03-01 23:33:05|run|
|[78e69584d5856ee59154d0b4f1ef4fc5](https://www.virustotal.com/gui/file/78e69584d5856ee59154d0b4f1ef4fc5)|Win32 EXE||2016-02-26 00:20:09|svchost.exe|
|[44672aed522fbca90bda3436164c6bdc](https://www.virustotal.com/gui/file/44672aed522fbca90bda3436164c6bdc)|Win32 EXE||2016-02-23 18:07:58|44672aed522fbca90bda3436164c6bdc.png|
|[3033f5f8edd32c50a44c30fc8a0280a0](https://www.virustotal.com/gui/file/3033f5f8edd32c50a44c30fc8a0280a0)|Win32 EXE||2016-02-18 03:34:23|tear.exe|
|[97030af59f7bb39557d0e2853079c62e](https://www.virustotal.com/gui/file/97030af59f7bb39557d0e2853079c62e)|Win32 EXE|Nymaim|2016-02-17 07:36:16| |
|[a19f48cae862d4e550ca2b54b3395374](https://www.virustotal.com/gui/file/a19f48cae862d4e550ca2b54b3395374)|DOC|o97m|2016-02-10 13:30:36|Скарга.doc|
|[80b022b39d91527f6ae5b4834d7c8173](https://www.virustotal.com/gui/file/80b022b39d91527f6ae5b4834d7c8173)|Win32 EXE|ursu|2016-02-05 19:51:10|80b022b39d91527f6ae5b4834d7c8173.virus|
|[943e251febe758304373c7fe2e0c2c03](https://www.virustotal.com/gui/file/943e251febe758304373c7fe2e0c2c03)|Win32 EXE||2016-01-26 00:07:52|Slanguage|
|[fdcff220fb09d1609e86c6eddc12cdf3](https://www.virustotal.com/gui/file/fdcff220fb09d1609e86c6eddc12cdf3)|Win32 EXE||2016-01-25 06:06:15|Divana0|
|[7bda2a6d2a6dbdc990dddb8093c91bd5](https://www.virustotal.com/gui/file/7bda2a6d2a6dbdc990dddb8093c91bd5)|Win32 EXE||2016-01-24 08:46:35|Caracore8|
|[6bf8e083e3b47e85444fd328ec1ca207](https://www.virustotal.com/gui/file/6bf8e083e3b47e85444fd328ec1ca207)|Win32 EXE||2016-01-22 00:48:05|Twicer|
|[5824866edf69a74c0a4b39fe1476fbc3](https://www.virustotal.com/gui/file/5824866edf69a74c0a4b39fe1476fbc3)|Win32 EXE||2016-01-21 13:42:59|Chria3|
|[59ed2be2acfd8501120cd3e04c5fadba](https://www.virustotal.com/gui/file/59ed2be2acfd8501120cd3e04c5fadba)|Win32 EXE|Kryptik|2016-01-19 12:57:54|activex.exe|
|[9b9834748df0bfc45772c0ee1d0dbf32](https://www.virustotal.com/gui/file/9b9834748df0bfc45772c0ee1d0dbf32)|Win32 EXE|Nymaim|2016-01-16 09:03:33| |
|[54fceb41ce3444cf8707d50b4f2bbc32](https://www.virustotal.com/gui/file/54fceb41ce3444cf8707d50b4f2bbc32)|Win32 EXE|kazy|2016-01-06 21:30:37|???? ??????????? ????? ?????? ??????????? ? ???????? ????? ????????? ?????? ???????? ???????? ???????.scr|
|[de50d41d70b8879cdc73e684ad4ebe9f](https://www.virustotal.com/gui/file/de50d41d70b8879cdc73e684ad4ebe9f)|Win32 EXE||2015-12-29 23:28:20|de50d41d70b8879cdc73e684ad4ebe9f.virus|
|[facd37cd76989f45088ae98de8ed7aa0](https://www.virustotal.com/gui/file/facd37cd76989f45088ae98de8ed7aa0)|Win32 EXE|Kryptik|2015-12-19 00:06:35|facd37cd76989f45088ae98de8ed7aa0.virus|
|[37759603c6cd91ebc8a1ea9ac0f2d580](https://www.virustotal.com/gui/file/37759603c6cd91ebc8a1ea9ac0f2d580)|DOC||2015-12-17 09:28:05|37759603c6cd91ebc8a1ea9ac0f2d580.virus|
|[1fbf4f38b0d853e9fff54f92a204a064](https://www.virustotal.com/gui/file/1fbf4f38b0d853e9fff54f92a204a064)|Win32 EXE|Zbot|2015-12-17 02:46:16|1fbf4f38b0d853e9fff54f92a204a064_EeCrnsprWvUFBkN.exE|
|[dad8ebcbb5fa6721ccad45b81874e22c](https://www.virustotal.com/gui/file/dad8ebcbb5fa6721ccad45b81874e22c)|Win32 EXE|razy|2015-12-16 23:03:25|dad8ebcbb5fa6721ccad45b81874e22c.virus|
|[4dc99280459292ef60d6d01ed8ece312](https://www.virustotal.com/gui/file/4dc99280459292ef60d6d01ed8ece312)|Win32 EXE||2015-12-10 19:58:05|coppicing.exe|
|[29fc19c608683f114365b6885d6f5e24](https://www.virustotal.com/gui/file/29fc19c608683f114365b6885d6f5e24)|Win32 EXE|Carbanak|2015-11-10 23:07:16|1c6b0a1eb7ab0c0b43683c3d0486cbba418a6fe94fdb14c749a878dc0065ed3d.bin|
|[70345aa0b970e1198a9267ae4532a11b](https://www.virustotal.com/gui/file/70345aa0b970e1198a9267ae4532a11b)|Win32 EXE|Kryptik|2015-11-05 15:22:18|70345aa0b970e1198a9267ae4532a11b.virus|
|[5de0847326983b01919429fd8eb1e23c](https://www.virustotal.com/gui/file/5de0847326983b01919429fd8eb1e23c)|Win32 EXE|barys|2015-10-30 22:11:50|D603EFF78F7FA50C1C408DA756EC2C7E|
|[9867ce0914c6a074487ffa7523101022](https://www.virustotal.com/gui/file/9867ce0914c6a074487ffa7523101022)|Win32 EXE|barys|2015-10-23 10:11:59| |
|[d11f5faabe6dc2528e8a3d53c97ff843](https://www.virustotal.com/gui/file/d11f5faabe6dc2528e8a3d53c97ff843)|Win32 EXE|Zbot|2015-10-23 10:11:26|DB Browser for SQLite Portable|
|[5cbb0f9dd06d0d89dee6e05abd81f91d](https://www.virustotal.com/gui/file/5cbb0f9dd06d0d89dee6e05abd81f91d)|Win32 EXE|Reconyc|2015-10-21 15:31:44|rnFPGR|
|[9e0b70079e4f1537ca7875afbf068423](https://www.virustotal.com/gui/file/9e0b70079e4f1537ca7875afbf068423)|Win32 EXE|barys|2015-10-14 17:18:45|A14XCFlY.exe|
|[89a9f577677e4116ddc4832a10ad0e18](https://www.virustotal.com/gui/file/89a9f577677e4116ddc4832a10ad0e18)|Win32 EXE|Symmi|2015-10-10 02:23:09|svchost.exe|
|[235bdd385f8792fee3942a3a78e77ecd](https://www.virustotal.com/gui/file/235bdd385f8792fee3942a3a78e77ecd)|Win32 EXE|kazy|2015-09-19 02:06:50|verbalise.exe|
|[851dd641bd27b549363db1632a7ffc3a](https://www.virustotal.com/gui/file/851dd641bd27b549363db1632a7ffc3a)|Win32 EXE||2015-09-12 14:31:00|calibration.exe|
|[14c6bd7009ab6d6bb2ef8da544644936](https://www.virustotal.com/gui/file/14c6bd7009ab6d6bb2ef8da544644936)|Win32 EXE|kazy|2015-09-12 06:31:03|flowed.exe|
|[1ce5aa6f4690c10b90620141b701f211](https://www.virustotal.com/gui/file/1ce5aa6f4690c10b90620141b701f211)|Win32 EXE||2015-09-10 06:39:24|3e3c225ac14e3a6d7fd01e8958e04b9bc0a1279b8a29c4812c6a5f69d89731e2.unpacked.dmp|
|[d2c0e8188e12760a4e46776e186da989](https://www.virustotal.com/gui/file/d2c0e8188e12760a4e46776e186da989)|Win32 EXE||2015-09-08 09:26:14|c:\Windows\system32\mmc.exe|
|[77fd85caf748d66175f9c7527b768911](https://www.virustotal.com/gui/file/77fd85caf748d66175f9c7527b768911)|Win32 EXE|kazy|2015-09-07 14:55:43|77fd85caf748d66175f9c7527b768911.vir|
|[9d22efe60501ddc0605ac8b01db889e5](https://www.virustotal.com/gui/file/9d22efe60501ddc0605ac8b01db889e5)|Win32 EXE||2015-09-07 02:20:37|_00550000.mem|
|[88f7cfb905f252409925e721668bbfe9](https://www.virustotal.com/gui/file/88f7cfb905f252409925e721668bbfe9)|Win32 EXE|injector|2015-09-03 16:35:06| |
|[a9b767e086732268516235883b11b85f](https://www.virustotal.com/gui/file/a9b767e086732268516235883b11b85f)|Win32 EXE|Andromeda|2015-09-01 18:12:29|svchost.exe.364.dr|
|[1c7cdb9ca6451e69e6e8be589c5f2f04](https://www.virustotal.com/gui/file/1c7cdb9ca6451e69e6e8be589c5f2f04)|Win32 EXE|Reconyc|2015-08-31 17:02:44|8Rkzy.exe|
|[682f39be218a29818b27a4a7753fffa9](https://www.virustotal.com/gui/file/682f39be218a29818b27a4a7753fffa9)|Win32 EXE|Reconyc|2015-08-29 14:05:39|Nqh50Mszlnxfgp.exe|
|[b8744bdbfe8dc8804d34e8696ca06b5c](https://www.virustotal.com/gui/file/b8744bdbfe8dc8804d34e8696ca06b5c)|Win32 EXE|Androm|2015-08-29 01:41:17|Запрос Аппарата Совета Федерации РФ материалов для публикации в аналитическом вестнике 11.08.2015.scr|
|[7f1b0127d24551139a44aa3e782e5b08](https://www.virustotal.com/gui/file/7f1b0127d24551139a44aa3e782e5b08)|RTF|CVE-2015-1641|2015-08-26 06:26:16|7f1b0127d24551139a44aa3e782e5b08.bin|
|[243a1a17f9e9ec042861e7242f90a88b](https://www.virustotal.com/gui/file/243a1a17f9e9ec042861e7242f90a88b)|Win32 EXE||2015-08-18 01:40:49| |
|[72df208f7dc60f01abdc2dd8494ca15f](https://www.virustotal.com/gui/file/72df208f7dc60f01abdc2dd8494ca15f)|Win32 EXE||2015-08-12 03:22:45|m:\dailytesters\vl\C\C0010C553EC38E7405E244CF1577C1AA\AFD5932309623B722AC5D67420E18C813A633EF96904ED09650D7851D9AED156.EXE|
|[9ac1d5286ee3d9d5e854b4e8ca6edf02](https://www.virustotal.com/gui/file/9ac1d5286ee3d9d5e854b4e8ca6edf02)|Win32 EXE||2015-08-06 17:03:02|m:\dailytesters\vl\0\066C67F074CE223D77F493EB573FB589\B10E2A6A8BD9709B34D9B296A56C2AA192A8C13BC784FE243AF2CC54B6B498FC.EXE|
|[efe7ca2491d1793c75487b820c32502a](https://www.virustotal.com/gui/file/efe7ca2491d1793c75487b820c32502a)|Win32 EXE|Symmi|2015-07-30 12:42:13|d718503f6403355702d021b08404b47692b2a13d9fd01bd7516f7074b73e9b7b.bin|
|[d5b57e24e40d0b464be6ce0dada4fdbd](https://www.virustotal.com/gui/file/d5b57e24e40d0b464be6ce0dada4fdbd)|Win32 EXE||2015-06-27 09:12:02|m:\dailytesters\vl\4\4AA1C817E1559046F47153DD50DA9489\7B959F6DD7348F1C3C9198DBB0BBA4F263B248273EFDE59E87BC8332212D1377.EXE|
|[d0b7e8e035ede4196ca80217ec0f2c06](https://www.virustotal.com/gui/file/d0b7e8e035ede4196ca80217ec0f2c06)|Win32 EXE|Reconyc|2015-06-22 13:50:07| |
|[42b7a5c2690199e99777915262fcb06d](https://www.virustotal.com/gui/file/42b7a5c2690199e99777915262fcb06d)|Win32 EXE||2015-06-15 19:11:59|svchost.ex|
|[369e15b44262671369b2a6e1f0ca7084](https://www.virustotal.com/gui/file/369e15b44262671369b2a6e1f0ca7084)|Win32 EXE|kazy|2015-06-02 15:00:44|m:\dailytesters\vl\7\758492B6086F33E62CC8FBD1D119F251\8D90C313743D434311C0B4B228F60F8C548E167E3DAE1E9CB6DF6822A7581928.EXE|
|[1fa19e329bd5f2eaf933c39eba13d869](https://www.virustotal.com/gui/file/1fa19e329bd5f2eaf933c39eba13d869)|RTF|CVE-2012-0158|2015-05-27 03:28:53|Instruction.doc|
|[cc215ab0f24d947a0c7ff6c439f0b059](https://www.virustotal.com/gui/file/cc215ab0f24d947a0c7ff6c439f0b059)|Win32 EXE|razy|2015-05-14 23:01:02|opm_ico.exe|
|[507b63f07d1e7b04f62aac8d1306d7a7](https://www.virustotal.com/gui/file/507b63f07d1e7b04f62aac8d1306d7a7)|Win32 EXE||2015-05-14 22:57:09|opm.exe|
|[20a0567cccc35bd49d3576f5d6437547](https://www.virustotal.com/gui/file/20a0567cccc35bd49d3576f5d6437547)|Win32 EXE||2015-05-12 19:34:41|svchost.exe|
|[49f7fdbce30fb8328b3697d36d7a1361](https://www.virustotal.com/gui/file/49f7fdbce30fb8328b3697d36d7a1361)|Win32 EXE|tspy|2015-05-07 00:33:28|svchost.ex|
|[4b44a9c0c2b680518e1b63856eeb4f2d](https://www.virustotal.com/gui/file/4b44a9c0c2b680518e1b63856eeb4f2d)|Win32 EXE|tspy|2015-05-05 01:44:15|svchost.exe|
|[c5d5a32bbe362da269ea9c90b5586c5e](https://www.virustotal.com/gui/file/c5d5a32bbe362da269ea9c90b5586c5e)|Win32 EXE|Symmi|2015-04-07 19:47:13|ntxobj.exe|
|[8614063148237b79f9ef5b054e0f500f](https://www.virustotal.com/gui/file/8614063148237b79f9ef5b054e0f500f)|Win32 EXE||2015-03-09 19:15:58|_00340000.mem|
|[fa32779246b648fb3d212b2142c710c7](https://www.virustotal.com/gui/file/fa32779246b648fb3d212b2142c710c7)|Win32 EXE|kazy|2015-03-07 02:22:42|spoolsv.exe|
|[e86607d06e2b9ae2fd3830e3279ecce7](https://www.virustotal.com/gui/file/e86607d06e2b9ae2fd3830e3279ecce7)|Win32 EXE||2015-03-03 17:01:50| |
|[88e4d3a9a5c9580696de0f424d206463](https://www.virustotal.com/gui/file/88e4d3a9a5c9580696de0f424d206463)|Win32 EXE|Androm|2015-03-02 15:19:49|CommemoratesChambermaidDecommissioned.exe|
|[a52437044cec5c1cbbfed65775f237f7](https://www.virustotal.com/gui/file/a52437044cec5c1cbbfed65775f237f7)|Win32 EXE||2015-02-27 04:40:02|4625675|
|[7e022d178410a448e98dde8144132604](https://www.virustotal.com/gui/file/7e022d178410a448e98dde8144132604)|Win32 EXE||2015-02-23 20:25:22|svchost.exe1|
|[c70cce41ef0e4a206b5b48fa2d460ba4](https://www.virustotal.com/gui/file/c70cce41ef0e4a206b5b48fa2d460ba4)|Win32 EXE|razy|2015-01-26 21:38:26|c70cce41ef0e4a206b5b48fa2d460ba4|
|[be935b4b3c620558422093d643e2edfe](https://www.virustotal.com/gui/file/be935b4b3c620558422093d643e2edfe)|Win32 EXE|foreign|2015-01-22 11:10:19|datacompare.exe|
|[100d516821d99b09718b362d5a4b9a2f](https://www.virustotal.com/gui/file/100d516821d99b09718b362d5a4b9a2f)|Win32 EXE|kazy|2015-01-20 11:28:46|документы.scr|
|[5f95d9936344c9f294d5471ffd53d8aa](https://www.virustotal.com/gui/file/5f95d9936344c9f294d5471ffd53d8aa)|Win32 EXE|Ursu|2015-01-19 13:42:59|lsass.exe|
|[41fb85acedc691bc6033fa2c4cf6a0bc](https://www.virustotal.com/gui/file/41fb85acedc691bc6033fa2c4cf6a0bc)|Win32 EXE|Carbanak|2015-01-19 13:17:57|UQtDXVNT.exe|
|[9ad6e0db5e2f6b59f14dd55ded057b69](https://www.virustotal.com/gui/file/9ad6e0db5e2f6b59f14dd55ded057b69)|Win32 EXE|Carbanak|2015-01-17 07:50:40|9ad6e0db5e2f6b59f14dd55ded057b69|
|[6ae1bb06d10f253116925371c8e3e74b](https://www.virustotal.com/gui/file/6ae1bb06d10f253116925371c8e3e74b)|Win32 EXE|Kryptik|2015-01-14 15:03:00|/home/virustotal/sample/6AE1BB06D10F253116925371C8E3E74B|
|[72eff79f772b4c910259e3716f1acf49](https://www.virustotal.com/gui/file/72eff79f772b4c910259e3716f1acf49)|Win32 EXE|kazy|2015-01-14 13:18:32|_00D50000.mem|
|[85a26581f9aadeaa6415c01de60f932d](https://www.virustotal.com/gui/file/85a26581f9aadeaa6415c01de60f932d)|Win32 EXE|ipatre|2015-01-14 08:45:01|mssetup.tmp|
|[bf41127a2f6f336a3ac06ba51bf90983](https://www.virustotal.com/gui/file/bf41127a2f6f336a3ac06ba51bf90983)|Win32 EXE|Cerber|2014-12-26 11:36:21|b781c934dcf456f0a8c4aeecfb5bf236fd0a9d09|
|[0f35e4a1af76f6d1f29fb7faa790d51e](https://www.virustotal.com/gui/file/0f35e4a1af76f6d1f29fb7faa790d51e)|Win32 EXE||2014-12-25 00:36:32|12773.exe|
|[a70fea1e6eaa77bdfa07848712efa259](https://www.virustotal.com/gui/file/a70fea1e6eaa77bdfa07848712efa259)|Win32 EXE|Carbanak|2014-12-24 08:13:48|sustained.exe|
|[f888b2e05bc9d4f5d6e26c71690761a5](https://www.virustotal.com/gui/file/f888b2e05bc9d4f5d6e26c71690761a5)|Win32 EXE||2014-12-16 19:40:06|svchost.exe|
|[7776c507a403d2277d19c4937bcc0268](https://www.virustotal.com/gui/file/7776c507a403d2277d19c4937bcc0268)|Win32 EXE|kazy|2014-12-16 06:51:03|bide.exe|
|[d1de522652e129c37759158c14d48795](https://www.virustotal.com/gui/file/d1de522652e129c37759158c14d48795)|Win32 EXE|Kryptik|2014-12-16 05:54:52|/home/virustotal/sample/D1DE522652E129C37759158C14D48795|
|[42547bdb010599365c14128cc1e88fc0](https://www.virustotal.com/gui/file/42547bdb010599365c14128cc1e88fc0)|Win32 EXE||2014-12-08 22:16:34|A1tFDFBa.exe_|
|[4147b3225146344ce022c131713fc134](https://www.virustotal.com/gui/file/4147b3225146344ce022c131713fc134)|Win32 EXE|kazy|2014-11-28 18:54:45|crab.exe|
|[b83262100b13e6c08961c2ccae350347](https://www.virustotal.com/gui/file/b83262100b13e6c08961c2ccae350347)|Win32 EXE|Symmi|2014-11-28 00:34:26|1b04f775299e0ddb1573fe4fca0e2a2511c7aa33|
|[dad9c36fae447e865f1c596cbc0d5f9b](https://www.virustotal.com/gui/file/dad9c36fae447e865f1c596cbc0d5f9b)|Win32 EXE|ipatre|2014-11-25 08:35:48|ntxobj.ex|
|[a2965c1e4876af85a74d0f9eb3ab574b](https://www.virustotal.com/gui/file/a2965c1e4876af85a74d0f9eb3ab574b)|Win32 EXE||2014-11-25 05:10:58|vti-rescan|
|[708da24810671a205ea4cb08d4cf5fd5](https://www.virustotal.com/gui/file/708da24810671a205ea4cb08d4cf5fd5)|Win32 EXE||2014-11-25 05:08:32|Nu87G2H1Em.exe|
|[6163103103cdacdc2770bd8e9081cfb4](https://www.virustotal.com/gui/file/6163103103cdacdc2770bd8e9081cfb4)|Win32 EXE|Carbanak|2014-11-24 12:33:15|Tuneup_v46|
|[4e107d20832fff89a41f04c4dff1739b](https://www.virustotal.com/gui/file/4e107d20832fff89a41f04c4dff1739b)|Win32 EXE|dynamer|2014-11-24 12:23:42|wg3J4061QLD.exe|
|[c77331b822ca5b78c31b637984eda029](https://www.virustotal.com/gui/file/c77331b822ca5b78c31b637984eda029)|Win32 EXE|Carbanak|2014-11-24 10:45:08|wg3J4061QLD.exe|
|[e9a1148d4527db566425be0067c81501](https://www.virustotal.com/gui/file/e9a1148d4527db566425be0067c81501)|Win32 EXE|ipatre|2014-11-21 12:53:08|file-7720657_exe|
|[4d3b9708386c3b864cd01afbb8158554](https://www.virustotal.com/gui/file/4d3b9708386c3b864cd01afbb8158554)|Win32 EXE|ipatre|2014-11-20 12:41:49|ntxobj.ex|
|[de7f583011f0025ed9406bbdf90a6587](https://www.virustotal.com/gui/file/de7f583011f0025ed9406bbdf90a6587)|Win32 EXE|Symmi|2014-11-18 20:00:19|1.dec|
|[2e2aa05a217aacf3105b4ba2288ad475](https://www.virustotal.com/gui/file/2e2aa05a217aacf3105b4ba2288ad475)|Win32 EXE|Zbot|2014-11-17 15:01:47|MT Tick|
|[9a3cf4a5ae05a9b6bd8e10a6921b91c6](https://www.virustotal.com/gui/file/9a3cf4a5ae05a9b6bd8e10a6921b91c6)|Win32 EXE|jatif|2014-11-17 08:46:24|/home/support/SAMPLES/svchost.exe|
|[0675b1e43ca1e87e5df43596e3adb252](https://www.virustotal.com/gui/file/0675b1e43ca1e87e5df43596e3adb252)|Win32 EXE|kazy|2014-11-05 00:33:14|ntxobj.ex|
|[a4332aa2ab9b7628114ddac476702ade](https://www.virustotal.com/gui/file/a4332aa2ab9b7628114ddac476702ade)|Win32 EXE|kazy|2014-10-31 03:27:54|yAuAiW.exe|
|[45691956a1ba4a8ecc912aeb9f1f0612](https://www.virustotal.com/gui/file/45691956a1ba4a8ecc912aeb9f1f0612)|Win32 EXE|ipatre|2014-10-23 14:18:25|license.scr_|
|[09c8631c2ba74a92defb31040fe2c45a](https://www.virustotal.com/gui/file/09c8631c2ba74a92defb31040fe2c45a)|Win32 EXE||2014-10-22 12:26:42|vti-rescan|
|[26d6bb7a4e84bec672fc461487344829](https://www.virustotal.com/gui/file/26d6bb7a4e84bec672fc461487344829)|Win32 EXE|ipatre|2014-10-19 00:49:00|efef7dd20fc0f0518fa714277d9c9e3ca1a316ce|
|[3b5705cfd9b524dec69928dec98f3e22](https://www.virustotal.com/gui/file/3b5705cfd9b524dec69928dec98f3e22)|Win32 EXE|Carbanak|2014-10-16 08:46:45|application/clictrl-plug-in|
|[4fed60af9ce8279b7febc60f962486ff](https://www.virustotal.com/gui/file/4fed60af9ce8279b7febc60f962486ff)|Win32 EXE||2014-10-15 22:13:30|Dumped.exe|
|[972092cbe7791d27fc9ff6e9acc12cc3](https://www.virustotal.com/gui/file/972092cbe7791d27fc9ff6e9acc12cc3)|Win32 EXE|Carbanak|2014-10-15 07:57:05|/home/virustotal/sample/972092CBE7791D27FC9FF6E9ACC12CC3.9BB9B764|
|[c687867e2c92448992c0fd00a2468752](https://www.virustotal.com/gui/file/c687867e2c92448992c0fd00a2468752)|Win32 EXE|Kryptik|2014-10-12 13:31:08|/home/virustotal/sample/C687867E2C92448992C0FD00A2468752|
|[92425877eda59a611c105802d75fbde8](https://www.virustotal.com/gui/file/92425877eda59a611c105802d75fbde8)|Win32 EXE|kazy|2014-10-09 16:09:53|IQ9z8v.exe|
|[cd22fa7c9d9e61b4aeac6acd10790d10](https://www.virustotal.com/gui/file/cd22fa7c9d9e61b4aeac6acd10790d10)|Win32 EXE|razy|2014-10-09 09:40:50|cd22fa7c9d9e61b4aeac6acd10790d10.virobj|
|[7d0bbdda98f44a5b73200a2c157077df](https://www.virustotal.com/gui/file/7d0bbdda98f44a5b73200a2c157077df)|Win32 EXE|Carbanak|2014-10-08 19:54:05|application/clictrl-plug-in|
|[5aeecb78181f95829b6eeeefb2ce4975](https://www.virustotal.com/gui/file/5aeecb78181f95829b6eeeefb2ce4975)|Win32 EXE|Carbanak|2014-10-08 06:56:27|vti-rescan|
|[f66992766d8f9204551b3c42336b4f6d](https://www.virustotal.com/gui/file/f66992766d8f9204551b3c42336b4f6d)|Win32 EXE|Kryptik|2014-10-01 11:53:26|/home/virustotal/sample/F66992766D8F9204551B3C42336B4F6D|
|[b400bb2a2f9f0ce176368dc709359d3d](https://www.virustotal.com/gui/file/b400bb2a2f9f0ce176368dc709359d3d)|Win32 EXE|Symmi|2014-09-26 12:46:34|ntxobj.exe|
|[81a3cb16b23b737b69ad830816d7a2b3](https://www.virustotal.com/gui/file/81a3cb16b23b737b69ad830816d7a2b3)|Win32 EXE||2014-09-26 10:09:51|svchost.exe|
|[1e127b92f7102fbd7fa5375e4e5c67d1](https://www.virustotal.com/gui/file/1e127b92f7102fbd7fa5375e4e5c67d1)|Win32 EXE||2014-09-25 07:40:50|_003C0000.mem|
|[10e0699f20e31e89c3becfd8bf24cb4c](https://www.virustotal.com/gui/file/10e0699f20e31e89c3becfd8bf24cb4c)|Win32 EXE||2014-09-23 17:03:14|10e0699f20e31e89c3becfd8bf24cb4c|
|[e613e5252a7172329ee25525758180a4](https://www.virustotal.com/gui/file/e613e5252a7172329ee25525758180a4)|Win32 EXE|Carbanak|2014-09-19 12:31:29|WL-1b553a943e1a5c04bacfb78d275b2329-0|
|[1b9b9c8db7735f1793f981d0be556d88](https://www.virustotal.com/gui/file/1b9b9c8db7735f1793f981d0be556d88)|Win32 EXE||2014-09-19 10:21:03|0B2C_b662ef49.exe_0.ndmp|
|[1713e551b8118e45d6ea3f05ec1be529](https://www.virustotal.com/gui/file/1713e551b8118e45d6ea3f05ec1be529)|Win32 EXE||2014-09-18 09:38:52|ntxobj.exe|
|[b6c08d0db4ca1d9e16f3e164745810ff](https://www.virustotal.com/gui/file/b6c08d0db4ca1d9e16f3e164745810ff)|Win32 EXE||2014-09-17 12:47:46|ntxobj.exe|
|[aa55dedff7f5dbe2cc4a47f2f8d44f94](https://www.virustotal.com/gui/file/aa55dedff7f5dbe2cc4a47f2f8d44f94)|Win32 EXE|Kryptik|2014-09-17 12:45:01|MT Tick|
|[2cba1a82a78f4dcbad1087c1b71588c9](https://www.virustotal.com/gui/file/2cba1a82a78f4dcbad1087c1b71588c9)|Win32 EXE||2014-09-17 12:43:34|ntxobj.exe|
|[1d1ed892f62559c3f8234c287cb3437c](https://www.virustotal.com/gui/file/1d1ed892f62559c3f8234c287cb3437c)|Win32 EXE|Carbanak|2014-09-17 10:23:34|Tuneup_v46|
|[933ab95dbf7eb0e9d9470a9272bfaff3](https://www.virustotal.com/gui/file/933ab95dbf7eb0e9d9470a9272bfaff3)|Win32 EXE|Kryptik|2014-09-17 10:21:57|ntxobj.exe|
|[763e07083887ecb83a87c24542d70dc5](https://www.virustotal.com/gui/file/763e07083887ecb83a87c24542d70dc5)|Win32 EXE|Carbanak|2014-09-16 16:32:12|MT Symbol|
|[95f44f184c0b10998c04fd9c6df61556](https://www.virustotal.com/gui/file/95f44f184c0b10998c04fd9c6df61556)|Win32 EXE||2014-09-16 16:23:35|95f44f184c0b10998c04fd9c6df61556.virobj|
|[1a4635564172393ae9f43eab85652ba5](https://www.virustotal.com/gui/file/1a4635564172393ae9f43eab85652ba5)|Win32 EXE||2014-09-16 16:21:29|ntxobj.exe|
|[ff7fd55796fa66c8245c0b90157c57c7](https://www.virustotal.com/gui/file/ff7fd55796fa66c8245c0b90157c57c7)|Win32 EXE||2014-09-16 16:19:42|sekur1.exe|
|[b328a01f5b82830cc250e0e429fca69f](https://www.virustotal.com/gui/file/b328a01f5b82830cc250e0e429fca69f)|Win32 EXE|Carbanak|2014-09-13 08:45:59|vt-upload-Snckl|
|[acb01930466438d3ee981cb4fc57e196](https://www.virustotal.com/gui/file/acb01930466438d3ee981cb4fc57e196)|Win32 EXE|kazy|2014-09-07 00:56:40|/home/support/SAMPLES/BQ0WCFRT.exe|
|[4f16b33c074f1c31d26d193ec74aaa56](https://www.virustotal.com/gui/file/4f16b33c074f1c31d26d193ec74aaa56)|Win32 EXE|Reconyc|2014-09-03 00:56:13|imm manip softw|
|[20f8e962b2b63170b228ccaff51aeb7d](https://www.virustotal.com/gui/file/20f8e962b2b63170b228ccaff51aeb7d)|Win32 EXE|ipatre|2014-08-26 13:52:22|ntxobj.exe|
|[0ad6da9e62a2c985156a9c53f8494171](https://www.virustotal.com/gui/file/0ad6da9e62a2c985156a9c53f8494171)|Win32 EXE|tspy|2014-08-26 12:48:03|Carbanak_0AD6DA9E62A2C985156A9C53F8494171|
|[1e47e12d11580e935878b0ed78d2294f](https://www.virustotal.com/gui/file/1e47e12d11580e935878b0ed78d2294f)|Win32 EXE|Carbanak|2014-08-25 18:41:52|wpc manager kit|
|[c69ac6fa8298193d4c1652dbf03328f5](https://www.virustotal.com/gui/file/c69ac6fa8298193d4c1652dbf03328f5)|Win32 EXE|Carbanak|2014-08-25 14:41:13|wg3J4061QLD.exe|
|[acb4c5e2f92c84df15faa4846f17ff4e](https://www.virustotal.com/gui/file/acb4c5e2f92c84df15faa4846f17ff4e)|Win32 EXE|Kryptik|2014-08-22 14:44:43|dx_PE_ (62).exe|
|[6e564dadc344cd2d55374dbb00646d1b](https://www.virustotal.com/gui/file/6e564dadc344cd2d55374dbb00646d1b)|Win32 EXE|Carbanak|2014-08-22 09:13:09|vt-upload-rui6T|
|[c1b48ca3066214a8ec988757cc3022b3](https://www.virustotal.com/gui/file/c1b48ca3066214a8ec988757cc3022b3)|Win32 EXE|Kryptik|2014-08-22 08:38:51|1a5ab924018a1cc96c11229802af1b8805fb575c.codex|
|[629f0657e70901e3134dcae2e2027396](https://www.virustotal.com/gui/file/629f0657e70901e3134dcae2e2027396)|Win32 EXE|ipatre|2014-08-22 07:27:09|1.scr|
|[083d9b9d2bd463aaced5653eed17350a](https://www.virustotal.com/gui/file/083d9b9d2bd463aaced5653eed17350a)|Win32 EXE|Carbanak|2014-08-14 22:07:33|1.exe|
|[f88a983fc0ef5bb446ae63250e7236dd](https://www.virustotal.com/gui/file/f88a983fc0ef5bb446ae63250e7236dd)|FPX|CVE-2012-0158|2014-08-14 05:28:55|Приглашение.msg|
|[643c0b9904b32004465b95321bb525eb](https://www.virustotal.com/gui/file/643c0b9904b32004465b95321bb525eb)|Win32 EXE||2014-08-12 15:58:17|0ccb881ae97592dc815d4c6001f9401fb3645e4b|
|[407795b49789c2f9ca6eca1fbab3c73e](https://www.virustotal.com/gui/file/407795b49789c2f9ca6eca1fbab3c73e)|Win32 EXE|CVE-2012-0158|2014-08-11 11:37:44|Ratad|
|[3dc8c4af51c8c367fbe7c7feef4f6744](https://www.virustotal.com/gui/file/3dc8c4af51c8c367fbe7c7feef4f6744)|Win32 EXE|Kryptik|2014-08-11 11:37:43|/favicon.ico|
|[86e48a9be62494bffb3b8e5ecb4a0310](https://www.virustotal.com/gui/file/86e48a9be62494bffb3b8e5ecb4a0310)|RTF|CVE-2012-0158|2014-08-11 10:26:21|41e8f48490897cdaedffa0bf1e755e0f880783ff088aacd7b97ec441bfff6206.rtf|
|[1fd4a01932df638a8c761abacffa0207](https://www.virustotal.com/gui/file/1fd4a01932df638a8c761abacffa0207)|Win32 EXE|Kryptik|2014-08-08 07:19:18|Tuneup_v46|
|[551d41e2a4dd1497b3b27a91922d29cc](https://www.virustotal.com/gui/file/551d41e2a4dd1497b3b27a91922d29cc)|Win32 EXE|Carbanak|2014-08-07 13:09:52|TorBroswer|
|[bddbb91388dd2c01068cde88a5fb939e](https://www.virustotal.com/gui/file/bddbb91388dd2c01068cde88a5fb939e)|Win32 EXE|Carbanak|2014-08-06 11:07:11|EXIT.EXE|
|[763b335abecbd3d9a6d923a13d6c2519](https://www.virustotal.com/gui/file/763b335abecbd3d9a6d923a13d6c2519)|Win32 EXE||2014-08-05 11:32:55|vti-rescan|
|[2c395f211db2d02cb544448729d0f081](https://www.virustotal.com/gui/file/2c395f211db2d02cb544448729d0f081)|RTF|CVE-2012-0158|2014-08-04 11:18:33|50e2886c6bd650711542c631b7a9a17d6e1ce683ef3a4c6bc1d1a1f546407460.rtf|
|[3e90bf845922cf1bf5305e6fdcc14e46](https://www.virustotal.com/gui/file/3e90bf845922cf1bf5305e6fdcc14e46)|Win32 EXE|graftor|2014-08-02 15:48:14|vti-rescan|
|[a4bfd2cfbb235d869d87f5485853edae](https://www.virustotal.com/gui/file/a4bfd2cfbb235d869d87f5485853edae)|Win32 EXE||2014-07-31 23:20:05|vt-upload-QApbe|
|[db3e8d46587d86519f46f912700372e0](https://www.virustotal.com/gui/file/db3e8d46587d86519f46f912700372e0)|Win32 EXE|Carbanak|2014-07-31 13:53:53|avrl framework|
|[db83e301564ff613dd1ca23c30a387f0](https://www.virustotal.com/gui/file/db83e301564ff613dd1ca23c30a387f0)|RTF|CVE-2012-0158|2014-07-23 10:28:06|81a9bd16a53a62878b6223b5a7314da6a8aa6a4e24008872e1368a1caf54974e.rtf|
|[c4a6a111a070856c49905d815f87ab49](https://www.virustotal.com/gui/file/c4a6a111a070856c49905d815f87ab49)|RTF|CVE-2012-0158|2014-07-22 13:55:16|2d51da6e1f7538096ccb22376b6da3ac602c7d557ad44174c7c46ca63eff122d.rtf|
|[cb915d1bd7f21b29edc179092e967331](https://www.virustotal.com/gui/file/cb915d1bd7f21b29edc179092e967331)|Win32 EXE||2014-07-22 13:13:16|ntxobj.exe_virus|
|[56bfe560518896b0535e0e4da44266d6](https://www.virustotal.com/gui/file/56bfe560518896b0535e0e4da44266d6)|Win32 EXE|Carbanak|2014-07-18 04:18:29|svchost.exe--|
|[608bdeb4ce66c96b7a9289f8cf57ce02](https://www.virustotal.com/gui/file/608bdeb4ce66c96b7a9289f8cf57ce02)|Win32 EXE||2014-07-10 14:00:48|Dumped.exe_|
|[0ad4892ead67e65ec3dd4c978fce7d92](https://www.virustotal.com/gui/file/0ad4892ead67e65ec3dd4c978fce7d92)|Win32 EXE|Kryptik|2014-07-08 14:14:56|/home/virustotal/sample/0AD4892EAD67E65EC3DD4C978FCE7D92|
|[2908afb4de41c64a45e1eb2503169108](https://www.virustotal.com/gui/file/2908afb4de41c64a45e1eb2503169108)|Win32 EXE|Kryptik|2014-07-07 18:30:16|vt-upload-TvFCf|
|[36dfd1f3bc58401f7d8b56af682f2c38](https://www.virustotal.com/gui/file/36dfd1f3bc58401f7d8b56af682f2c38)|Win32 EXE|Zbot|2014-07-06 15:01:21|MT Symbol|
|[9f455f0efe8c5ff69adcc456dcf00da6](https://www.virustotal.com/gui/file/9f455f0efe8c5ff69adcc456dcf00da6)|Win32 EXE||2014-07-03 06:20:38|xafon.exe.vir|
|[a1979aa159e0c54212122fd8acb24383](https://www.virustotal.com/gui/file/a1979aa159e0c54212122fd8acb24383)|Win32 EXE|Kryptik|2014-07-03 04:10:25|Ratad|
|[6c7ac8dfd7bc5c2bb1a6d7aec488c298](https://www.virustotal.com/gui/file/6c7ac8dfd7bc5c2bb1a6d7aec488c298)|RTF|CVE-2012-0158|2014-07-02 10:25:39|49609beedcec3274beab10e62d9ef206562aad40adf92af0178da9afe822f972.rtf|
|[b2e6d273a9b32739c9a26f267ab7d198](https://www.virustotal.com/gui/file/b2e6d273a9b32739c9a26f267ab7d198)|Win32 EXE||2014-07-02 10:16:26|vti-rescan|
|[75509b6222ec87284e40994f1a694f64](https://www.virustotal.com/gui/file/75509b6222ec87284e40994f1a694f64)|Win32 EXE|kazy|2014-07-02 03:06:55|EgTEBP62y.exe|
|[4afafa81731f8f02ba1b58073b47abdf](https://www.virustotal.com/gui/file/4afafa81731f8f02ba1b58073b47abdf)|Win32 EXE|Zbot|2014-07-02 02:48:10|MT Tick|
|[665b6cb31d962aefa3037b5849889e06](https://www.virustotal.com/gui/file/665b6cb31d962aefa3037b5849889e06)|RTF|CVE-2012-0158|2014-07-01 22:54:17|ba3a28dc3285db493b2229196d2d2e2bbd0486e62abee1c65ebb2f9febedcfe3.rtf|
|[fc6d9f538cdae19c8c3c662e890af979](https://www.virustotal.com/gui/file/fc6d9f538cdae19c8c3c662e890af979)|Win32 EXE|Symmi|2014-07-01 08:55:15|/home/virustotal/sample/FC6D9F538CDAE19C8C3C662E890AF979|
|[31e16189e9218cb131fdb13e75d0a94f](https://www.virustotal.com/gui/file/31e16189e9218cb131fdb13e75d0a94f)|RTF|CVE-2012-0158|2014-06-27 18:07:51|3210509a3b42c5b8163cfa7f7882753431a09fc4860f92b8b9de3136ce6cb2a8.rtf|
|[8fa296efaf87ff4d9179283d42372c52](https://www.virustotal.com/gui/file/8fa296efaf87ff4d9179283d42372c52)|RTF|CVE-2012-0158|2014-06-25 00:18:25|11d80fc8acf0e1a8d3d3ed9634630b3e860f229ebe9fd8eea4d1632597dc6f55.rtf|
|[8ace0c156eb6f1548b96c593a15cbb25](https://www.virustotal.com/gui/file/8ace0c156eb6f1548b96c593a15cbb25)|Win32 EXE||2014-06-23 12:15:26|%temp%\windows5.1-kb9264605-x86.exe|
|[55040dd42ccf19b5af7802cba91dbd7f](https://www.virustotal.com/gui/file/55040dd42ccf19b5af7802cba91dbd7f)|Win32 EXE|Carbanak|2014-06-22 11:22:22|analysis_subject|
|[7e3253abefa52aeae9b0451cfb273690](https://www.virustotal.com/gui/file/7e3253abefa52aeae9b0451cfb273690)|Win32 EXE||2014-06-16 00:07:29|7e3253abefa52aeae9b0451cfb273690.virobj|
|[fad3a7ea0a0c6cb8e20e43667f560d7f](https://www.virustotal.com/gui/file/fad3a7ea0a0c6cb8e20e43667f560d7f)|Win32 EXE|tspy|2014-06-14 15:10:59|Dumped3.exe|
|[ac5d3fc9da12255759a4a7e4eb3d63e7](https://www.virustotal.com/gui/file/ac5d3fc9da12255759a4a7e4eb3d63e7)|Win32 EXE|Zbot|2014-06-14 08:52:43|/home/virustotal/sample/AC5D3FC9DA12255759A4A7E4EB3D63E7|
|[cc294f8727addc5d363bb23e10be4af2](https://www.virustotal.com/gui/file/cc294f8727addc5d363bb23e10be4af2)|Win32 EXE|Zbot|2014-06-12 10:34:42|/home/virustotal/sample/CC294F8727ADDC5D363BB23E10BE4AF2|
|[2c6112e1e60f083467dc159ffb1ceb6d](https://www.virustotal.com/gui/file/2c6112e1e60f083467dc159ffb1ceb6d)|Win32 EXE||2014-06-10 07:15:45|59080d6ec68eb158c59a23722800ebd58ee5994d|
|[217d8e8be955136b4fd9215cb3e1bdf0](https://www.virustotal.com/gui/file/217d8e8be955136b4fd9215cb3e1bdf0)|Win32 EXE|razy|2014-05-03 04:12:56|Ibode|
|[87dfac39f577e5f52f0724455e8832a8](https://www.virustotal.com/gui/file/87dfac39f577e5f52f0724455e8832a8)|Win32 EXE||2014-04-30 22:17:12|PsExec Service Host|
|[a7f7a0f74c8b48f1699858b3b6c11eda](https://www.virustotal.com/gui/file/a7f7a0f74c8b48f1699858b3b6c11eda)|Win32 EXE||2014-04-30 22:13:46|PsExec.exe|
|[d88e12604dd689f9baab6378fbf897ba](https://www.virustotal.com/gui/file/d88e12604dd689f9baab6378fbf897ba)|Win32 EXE||2014-04-28 14:16:44|svchost.exe|
|[751d2771af1694c0d5db9d894bd134ca](https://www.virustotal.com/gui/file/751d2771af1694c0d5db9d894bd134ca)|Win32 EXE|tspy|2014-04-24 09:26:33|on_2.exe|
|[2ff8f2b3c070165edca43ea4f5bbfe2c](https://www.virustotal.com/gui/file/2ff8f2b3c070165edca43ea4f5bbfe2c)|Win32 EXE|kazy|2014-03-13 15:02:04|svchost._exe|
|[e9468b97665e9af052264e7e7a6cce7c](https://www.virustotal.com/gui/file/e9468b97665e9af052264e7e7a6cce7c)|Win32 EXE|graftor|2014-03-05 12:09:25|C:/Users/seongmin/Documents/VT2/malware/20170825/e9468b97665e9af052264e7e7a6cce7c.vir|
|[9d718e86cacffa39edafbf9c1ebc9754](https://www.virustotal.com/gui/file/9d718e86cacffa39edafbf9c1ebc9754)|Win32 EXE|tspy|2014-02-10 08:56:09|AFxGVlFS.exe|
|[966d9e07d1a75fa6867bbf02748c4212](https://www.virustotal.com/gui/file/966d9e07d1a75fa6867bbf02748c4212)|Win32 DLL|rozena|2013-12-06 13:51:33|реквизиты.doc.cpl|
|[0cf14d472410589c920fb55a97adaab1](https://www.virustotal.com/gui/file/0cf14d472410589c920fb55a97adaab1)|Win32 DLL||2013-09-17 19:04:41|исх.09_42.doc.cpl|
|[bece1545132af25c68777fade707046c](https://www.virustotal.com/gui/file/bece1545132af25c68777fade707046c)|TXT||2020-09-09 05:04:05|runit.bin|
|[1fff28af9e4061f8e3fdaf7ffe53b74a](https://www.virustotal.com/gui/file/1fff28af9e4061f8e3fdaf7ffe53b74a)|TXT||2020-03-30 19:17:41|colorpickerdesk__ex.ini|
|[4204019f999aa1360694a541514f89dc](https://www.virustotal.com/gui/file/4204019f999aa1360694a541514f89dc)|TXT||2020-03-30 19:16:20|colorpickerdesk__co.ini|
|[84d77a3b76ac690ce7a60199c88ceeb5](https://www.virustotal.com/gui/file/84d77a3b76ac690ce7a60199c88ceeb5)|TXT|Nemucod|2020-03-02 19:44:07|prada.txt|
|[718bc1dd6e993208bdaf3d2062e29871](https://www.virustotal.com/gui/file/718bc1dd6e993208bdaf3d2062e29871)|Win64 DLL||2018-06-11 02:07:15|f59e443dcaa2d92277d403ffe57a639cadf46932e61f33297a68be025ec5a137.bin|
