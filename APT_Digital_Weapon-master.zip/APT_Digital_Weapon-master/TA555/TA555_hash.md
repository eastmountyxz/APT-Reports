|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4423c37da26868ec578baa5514b8308a](https://www.virustotal.com/gui/file/4423c37da26868ec578baa5514b8308a)|Email||2019-07-30 10:41:53|__________ _________ ____________.eml|
|[c5661d589ee98e8b370acaceb7f5445e](https://www.virustotal.com/gui/file/c5661d589ee98e8b370acaceb7f5445e)|DOC||2019-07-29 10:16:45|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDcpLmRvYw==?=|
|[1e2b0f55562277fc4f3cfec340397f10](https://www.virustotal.com/gui/file/1e2b0f55562277fc4f3cfec340397f10)|DOC||2019-07-29 09:46:26|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDQpLmRvYw==?=|
|[1d045444d74bc63c8b30d9089c8da24f](https://www.virustotal.com/gui/file/1d045444d74bc63c8b30d9089c8da24f)|DOC||2019-07-29 09:45:50|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDkpLmRvYw==?=|
|[03580beba48ab744b1468459603e715d](https://www.virustotal.com/gui/file/03580beba48ab744b1468459603e715d)|DOC||2019-07-29 09:13:19|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDYpLmRvYw==?=|
|[87c6e0daabe6f71a86f3a9c24a090944](https://www.virustotal.com/gui/file/87c6e0daabe6f71a86f3a9c24a090944)|DOC||2019-07-29 09:11:38|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDExKS5kb2M=?=|
|[30bbf8a8d2c0ad4e2ffbfdc6c5ed476b](https://www.virustotal.com/gui/file/30bbf8a8d2c0ad4e2ffbfdc6c5ed476b)|DOC||2019-07-29 09:07:04|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDEyKS5kb2M=?=|
|[37457ea1d0f093145f8d645779c363ac](https://www.virustotal.com/gui/file/37457ea1d0f093145f8d645779c363ac)|DOC||2019-07-29 09:05:00|=?UTF-8?B?0L/QvtGB0YLQsNC90L7QstCwXzI5XzA3XzIwMTkgKDEwKS5kb2M=?=|
|[770daeca2fbf280fd8d39d0d60920ada](https://www.virustotal.com/gui/file/770daeca2fbf280fd8d39d0d60920ada)|Text||2018-08-23 13:18:30|770daeca2fbf280fd8d39d0d60920ada.virus|
|[733d9102c99787ecef25db845df14d21](https://www.virustotal.com/gui/file/733d9102c99787ecef25db845df14d21)|Win64 DLL||2018-08-23 13:17:09|733d9102c99787ecef25db845df14d21_jBechfBvoI.ExE|
|[a4f80119e61fa5fd0332079466dfb8a8](https://www.virustotal.com/gui/file/a4f80119e61fa5fd0332079466dfb8a8)|DOC||2018-08-15 18:11:33|a4f80119e61fa5fd0332079466dfb8a8_gRQDpagcT.DOc|
|[a487b5f266a5abdca7ebd94c878605ca](https://www.virustotal.com/gui/file/a487b5f266a5abdca7ebd94c878605ca)|DOC||2018-08-11 22:15:40|a487b5f266a5abdca7ebd94c878605ca_KYpJZJZyTCxuTuksN.DOC|
|[148166c4423934a72db2eb5d88c99483](https://www.virustotal.com/gui/file/148166c4423934a72db2eb5d88c99483)|DOC|w2km|2018-06-13 08:57:25|148166c4423934a72db2eb5d88c99483_rgIQSjQHCDdyZHQ.dOC|
|[6c8e800f14f927de051a3788083635e5](https://www.virustotal.com/gui/file/6c8e800f14f927de051a3788083635e5)|Win32 EXE|Emotet|2018-06-06 14:25:07|myfile.exe|
|[54abb22b0b5656540eec35fc5591a324](https://www.virustotal.com/gui/file/54abb22b0b5656540eec35fc5591a324)|DOC|w2km|2018-05-15 14:31:27|54abb22b0b5656540eec35fc5591a324_zmcHXDOfNHPuQ.DOC|
|[4d7471711185364b8d9c8a19bc6ff3d8](https://www.virustotal.com/gui/file/4d7471711185364b8d9c8a19bc6ff3d8)|Win32 EXE|Emotet|2018-05-07 15:55:01|myfile.exe|
