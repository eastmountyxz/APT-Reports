**NAME:**  
TA555  

**Description**:   
TA555 is an attack group that carry out campaigns targeting hotels, restaurants, and telecommunications since May, 2018. There are two related malwares: AdvisorsBot and PoshAdvisor.
  
**References**:  
https://www.proofpoint.com/us/threat-insight/post/new-modular-downloaders-fingerprint-systems-part-2-advisorsbot
