**NAME:**  
CopyKittens  
  
**Alias**  
Slayer Kitten, CopyKittens  
  
**Description**:   
CopyKittens is regarded as an Iranian cyberespionage group that has been operating since at least 2013. It has targeted countries including Israel, Saudi Arabia,Turkey, the U.S., Jordan, and Germany. The group is responsible for the campaign known as Operation Wilted Tulip  

**References**:  
https://www.clearskysec.com/copykitten-jpost/  
https://www.clearskysec.com/wp-content/uploads/2017/07/Operation_Wilted_Tulip.pdf  
https://s3-eu-west-1.amazonaws.com/minervaresearchpublic/CopyKittens/CopyKittens.pdf  
http://www.clearskysec.com/tulip/  
https://blog.domaintools.com/2017/03/hunt-case-study-hunting-campaign-indicators-on-privacy-protected-attack-infrastructure/  
