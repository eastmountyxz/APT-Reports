|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[bcae706c00e07936fc41ac47d671fc40](https://www.virustotal.com/gui/file/bcae706c00e07936fc41ac47d671fc40)|Win32 EXE|bitrep|2017-07-25 09:55:09|ZPP.exe|
|[a60a32f21ac1a2ec33135a650aa8dc71](https://www.virustotal.com/gui/file/a60a32f21ac1a2ec33135a650aa8dc71)|Win32 DLL|bodegun|2017-07-25 09:54:56|vminst.tmp|
|[113ca319e85778b62145019359380a08](https://www.virustotal.com/gui/file/113ca319e85778b62145019359380a08)|Win64 EXE||2017-07-25 09:54:04|winlogin.exe|
|[6ea02f1f13cc39d953e5a3ebcdcfd882](https://www.virustotal.com/gui/file/6ea02f1f13cc39d953e5a3ebcdcfd882)|Win32 EXE||2017-07-25 09:51:48|beacon_stageless_service.exe|
|[e37418ba399a095066845e7829267efe](https://www.virustotal.com/gui/file/e37418ba399a095066845e7829267efe)|Win32 EXE|CobaltStrike|2017-07-25 09:51:40|artifact.exe|
|[bd38cab32b3b8b64e5d5d3df36f7c55a](https://www.virustotal.com/gui/file/bd38cab32b3b8b64e5d5d3df36f7c55a)|Win64 DLL||2017-07-25 09:51:16|svchost64.swp|
|[d9aa197ca2f01a66df248c7a8b582c40](https://www.virustotal.com/gui/file/d9aa197ca2f01a66df248c7a8b582c40)|Win32 DLL||2017-07-25 09:50:50|kernel.dll|
|[8b702ba2b2bd65c3ad47117515f0669c](https://www.virustotal.com/gui/file/8b702ba2b2bd65c3ad47117515f0669c)|FPX|CVE-2017-0199|2017-06-06 08:58:34|~WRD0000.tmp|
|[217b1c2760bcf4838f5e3efb980064d7](https://www.virustotal.com/gui/file/217b1c2760bcf4838f5e3efb980064d7)|unknown||2017-06-06 08:53:47|~WRS{3E1FBC1D-72FA-4EF7-8F96-C89D3DD3D853}.tmp|
|[41466bbb49dd35f9aa3002e546da65eb](https://www.virustotal.com/gui/file/41466bbb49dd35f9aa3002e546da65eb)|RTF|CVE-2017-0199|2017-06-05 09:03:41|da8763f9338de7263f5f0cd58cc2e668c0470b3b4244cd62d506ffe108e4b79c.bin|
|[838fb8d181d52e9b9d212b49f4350739](https://www.virustotal.com/gui/file/838fb8d181d52e9b9d212b49f4350739)|RTF|CVE-2017-0199|2017-05-18 06:21:04|Confidential.rtf|
|[a4dd1c225292014e65edb83f2684f2d5](https://www.virustotal.com/gui/file/a4dd1c225292014e65edb83f2684f2d5)|DOCX|phishing|2017-05-17 15:21:43|The North Korean weapons program now testing USA range.docx|
|[efca6664ad6d29d2df5aaecf99024892](https://www.virustotal.com/gui/file/efca6664ad6d29d2df5aaecf99024892)|Win32 EXE||2017-02-09 00:19:57|AFA563221AAC89F96C383F9F9F4EF81D82C69419F124A80B7F4A8C437D83CE77.zip|
|[752240cddda5acb5e8d026cef82e2b54](https://www.virustotal.com/gui/file/752240cddda5acb5e8d026cef82e2b54)|Win32 EXE||2017-02-08 19:58:10|Wextract|
|[3676914af9fd575deb9901a8b625f032](https://www.virustotal.com/gui/file/3676914af9fd575deb9901a8b625f032)|FPX||2017-02-08 14:54:58|oleObject1.bin|
|[3de91d07ac762b193d5b67dd5138381a](https://www.virustotal.com/gui/file/3de91d07ac762b193d5b67dd5138381a)|DOCX||2017-02-08 12:05:14|ssl.docx|
|[c5a02e984ca3d5ac13cf946d2ba68364](https://www.virustotal.com/gui/file/c5a02e984ca3d5ac13cf946d2ba68364)|Win32 EXE||2017-01-18 02:16:06|vt.zip|
|[435a93978fa50f55a64c788002da58a5](https://www.virustotal.com/gui/file/435a93978fa50f55a64c788002da58a5)|Win32 EXE||2017-01-16 17:28:12|Wextract|
|[d3b9da7c8c54f7f1ea6433ac34b120a1](https://www.virustotal.com/gui/file/d3b9da7c8c54f7f1ea6433ac34b120a1)|Win32 EXE|dynamer|2017-01-16 15:00:56|Wextract|
|[b571c8e0e3768a12794eaf0ce24e6697](https://www.virustotal.com/gui/file/b571c8e0e3768a12794eaf0ce24e6697)|Win32 EXE||2016-12-18 11:08:46|8c8496390c3ad048f2a0a4031edfcdac819ee840d32951b9a1a9337a2dcbea25.bin|
|[f6daab6b8a3253ed5ce576a4251bca3c](https://www.virustotal.com/gui/file/f6daab6b8a3253ed5ce576a4251bca3c)|Win32 EXE||2016-11-27 03:16:39|Wextract|
|[94ba33696cd6ffd6335948a752ec9c19](https://www.virustotal.com/gui/file/94ba33696cd6ffd6335948a752ec9c19)|Win32 DLL||2016-11-07 09:14:46|Kernel.dll|
|[4999967c94a2fb1fa8122f1eea7a0e02](https://www.virustotal.com/gui/file/4999967c94a2fb1fa8122f1eea7a0e02)|Win32 EXE|dynamer|2016-10-11 06:27:31|PDFOPENER_CONSOLE.exe|
|[e319f3fb40957a5ff13695306dd9de25](https://www.virustotal.com/gui/file/e319f3fb40957a5ff13695306dd9de25)|Win32 EXE||2016-10-09 16:03:53|netsrvd.exe|
|[62f8f45c5f10647af0040f965a3ea96d](https://www.virustotal.com/gui/file/62f8f45c5f10647af0040f965a3ea96d)|Win32 EXE|MSILPerseus|2016-09-29 14:50:20|PDFOPENER_CONSOLE.exe|
|[22cabd6715fdc0bc8dda1edfad8a46f4](https://www.virustotal.com/gui/file/22cabd6715fdc0bc8dda1edfad8a46f4)|DOCX|dynamer|2016-09-28 06:09:27|REV162019ISR2.docx|
|[b34721e53599286a1093c90a9dd0b789](https://www.virustotal.com/gui/file/b34721e53599286a1093c90a9dd0b789)|FPX|shell|2016-09-18 10:05:46|oleObject1.bin|
|[871efc9ecd8a446a7aa06351604a9bf4](https://www.virustotal.com/gui/file/871efc9ecd8a446a7aa06351604a9bf4)|DOCX||2016-09-18 08:02:42|סקר שנתי.docx|
|[fb775e900872e01f65e606b722719594](https://www.virustotal.com/gui/file/fb775e900872e01f65e606b722719594)|DOTM|valyria|2016-08-24 14:18:49|Date.dotm|
|[4a3d93c0a74aaabeb801593741587a02](https://www.virustotal.com/gui/file/4a3d93c0a74aaabeb801593741587a02)|XLS|Kryptik|2016-08-24 13:48:29|test_oracle.xls|
|[5e65373a7c6abca7e3f75ce74c6e8143](https://www.virustotal.com/gui/file/5e65373a7c6abca7e3f75ce74c6e8143)|XLS|skeeyah|2016-08-24 13:40:34|test.xls|
|[cf8502b8b67d11fbb0c75ebcf741db15](https://www.virustotal.com/gui/file/cf8502b8b67d11fbb0c75ebcf741db15)|Win32 EXE|Reconyc|2016-08-24 11:34:57|12121212.exe|
|[64c9acc611ef47486ea756aca8e1b3b7](https://www.virustotal.com/gui/file/64c9acc611ef47486ea756aca8e1b3b7)|Win32 EXE|injector|2016-08-23 20:56:44|d5tjo.exe|
|[9846b07bf7265161573392d24543940e](https://www.virustotal.com/gui/file/9846b07bf7265161573392d24543940e)|Win32 EXE|rozena|2016-08-14 08:49:21|1eb91de77656131cb5484d064decb3ec4de46078|
|[3d2885edf1f70ce4eb1e9519f47a669f](https://www.virustotal.com/gui/file/3d2885edf1f70ce4eb1e9519f47a669f)|Win32 EXE||2016-02-11 01:20:35| |
|[32261fe44c368724593fbf65d47fc826](https://www.virustotal.com/gui/file/32261fe44c368724593fbf65d47fc826)|DOC|Banload|2015-10-16 08:25:58|0f3085db3cac1716b8b61eec8e23d07d457a1937e37d5ef32fcf012b6c27fc7e.doc|
|[577577d6df1833629bfd0d612e3dbb05](https://www.virustotal.com/gui/file/577577d6df1833629bfd0d612e3dbb05)|FPX||2015-05-02 09:20:21|oleObject1.bin|
|[da529e0b81625828d52cd70efba50794](https://www.virustotal.com/gui/file/da529e0b81625828d52cd70efba50794)|Win32 EXE||2015-04-22 19:18:42|embedded.exe|
|[1f9910cafe0e5f39887b2d5ab4df0d10](https://www.virustotal.com/gui/file/1f9910cafe0e5f39887b2d5ab4df0d10)|DOCX|o97m|2015-04-22 09:10:03|virussign.com_1f9910cafe0e5f39887b2d5ab4df0d10.vir|
|[9db2719a3dde09ae260def9cd0d46dbe](https://www.virustotal.com/gui/file/9db2719a3dde09ae260def9cd0d46dbe)|Win32 EXE||2015-02-13 01:46:34|Quest‎‮fdp.scr|
|[1cef128513c05837f24796042b8e1cd9](https://www.virustotal.com/gui/file/1cef128513c05837f24796042b8e1cd9)|Win32 DLL||2015-02-12 20:14:37|Kernel.dll|
|[4765369d8ae52f2dd9b318e0c8b27054](https://www.virustotal.com/gui/file/4765369d8ae52f2dd9b318e0c8b27054)|DOC||2015-02-09 11:50:41|__substg1.0_37010102|
|[8734f46d932f179161042ef5b4a7b8a8](https://www.virustotal.com/gui/file/8734f46d932f179161042ef5b4a7b8a8)|FPX||2015-02-09 11:50:18|748d0d0eb211a736553bef4c457b53e99df845e25436448cd7f189351a9efdf8.bin|
|[9853fc1f4d7ba23d728f4ee80842faf9](https://www.virustotal.com/gui/file/9853fc1f4d7ba23d728f4ee80842faf9)|Win32 EXE||2015-02-04 21:04:51|united_nation__fdp.scr|
|[0feb0b50b99f0b303a5081ffb3c4446d](https://www.virustotal.com/gui/file/0feb0b50b99f0b303a5081ffb3c4446d)|Win32 DLL|Ircbot|2014-11-20 07:09:10|isheriff_0feb0b50b99f0b303a5081ffb3c4446d.bin|
|[d2c117d18cb05140373713859803a0d6](https://www.virustotal.com/gui/file/d2c117d18cb05140373713859803a0d6)|Win32 EXE|razy|2014-11-18 10:35:07|config.exe|
|[cfb4be91d8546203ae602c0284126408](https://www.virustotal.com/gui/file/cfb4be91d8546203ae602c0284126408)|DOCM|Banload|2014-11-17 13:02:15|1f76637bdb839db7b43be7284b9b6482827529ac14406659a373ab3521651a2f.bin|
