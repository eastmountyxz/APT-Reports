**NAME:**  
Cloud snooper

  
**Description**:   
Cloud Snooper, named by Sophos, is a sophisticated attack against cloud infrastructure servers hosted in the Amazon Web Services (AWS) cloud. The complexity of the attack and the use of a bespoke APT toolset give them reason to believe that the malware and its operators were possibly state sponsored.

  
**References**:  
https://news.sophos.com/en-us/2020/02/25/cloud-snooper-attack-bypasses-firewall-security-measures/