|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[91a473d3711c28c3c563284dfafe926b](https://www.virustotal.com/gui/file/91a473d3711c28c3c563284dfafe926b)|Win64 DLL||2020-10-17 06:11:03|91a473d3711c28c3c563284dfafe926b.virus|
|[f5b320f7e87cc6f9d02e28350bb87de6](https://www.virustotal.com/gui/file/f5b320f7e87cc6f9d02e28350bb87de6)|Win64 DLL||2020-10-06 21:36:18| |
|[dd8d3718197a10097cd72a94ed223238](https://www.virustotal.com/gui/file/dd8d3718197a10097cd72a94ed223238)|Win64 DLL||2020-10-06 21:36:17|/tmp/detector_sample_586922376|
|[0c136186858fd36080a7066657de81f5](https://www.virustotal.com/gui/file/0c136186858fd36080a7066657de81f5)|Win64 DLL||2020-10-06 21:36:16| |
|[88750b4a3c5e80fd82cf0dd534903fc0](https://www.virustotal.com/gui/file/88750b4a3c5e80fd82cf0dd534903fc0)|Win32 EXE||2020-10-06 17:30:20| |
|[e2f4914e38bb632e975cff14c39d8dcd](https://www.virustotal.com/gui/file/e2f4914e38bb632e975cff14c39d8dcd)|Win64 DLL||2020-10-06 17:30:19|negoexts.dll|
|[b53880397d331c6fe3493a9ef81cd76e](https://www.virustotal.com/gui/file/b53880397d331c6fe3493a9ef81cd76e)|Win32 EXE||2020-10-06 17:30:18| |
|[89527f932188bd73572e2974f4344d46](https://www.virustotal.com/gui/file/89527f932188bd73572e2974f4344d46)|Win32 DLL||2020-10-06 17:30:17| |
|[fa0a874926453e452e3b6ced045d2206](https://www.virustotal.com/gui/file/fa0a874926453e452e3b6ced045d2206)|Win32 DLL||2020-10-06 17:30:15| |
|[c63d3c25abd49ee131004e6401af856c](https://www.virustotal.com/gui/file/c63d3c25abd49ee131004e6401af856c)|Win32 EXE||2020-10-06 17:30:14| |
|[9f13636d5861066835ed5a79819aac28](https://www.virustotal.com/gui/file/9f13636d5861066835ed5a79819aac28)|Win64 DLL||2020-10-06 17:30:13| |
|[72c514c0b96e3a31f6f1a85d8f28403c](https://www.virustotal.com/gui/file/72c514c0b96e3a31f6f1a85d8f28403c)|Win32 EXE||2020-10-06 17:30:13| |
|[7b213a6ce7ab30a62e84d81d455b4dea](https://www.virustotal.com/gui/file/7b213a6ce7ab30a62e84d81d455b4dea)|Win32 DLL||2020-10-06 17:30:12| |
|[36b51d2c0d8f48a7dc834f4b9e477238](https://www.virustotal.com/gui/file/36b51d2c0d8f48a7dc834f4b9e477238)|Win64 DLL||2020-10-06 17:30:00| |
|[1c5377a54cbaa1b86279f63ee226b1df](https://www.virustotal.com/gui/file/1c5377a54cbaa1b86279f63ee226b1df)|Win64 DLL||2020-10-06 17:29:59| |
|[dc14ee862dda3bcc0d2445fdcb3ee5ae](https://www.virustotal.com/gui/file/dc14ee862dda3bcc0d2445fdcb3ee5ae)|Win32 EXE||2020-10-06 17:29:58| |
|[449be89f939f5f909734c0e74a0b9751](https://www.virustotal.com/gui/file/449be89f939f5f909734c0e74a0b9751)|RTF||2020-10-06 00:32:28|dttcodexgigas.5acf1e76ce0f893c7b9f66c097cec7aabf46d0fe|
|[328ad6468f6edb80b3abf97ac39a0721](https://www.virustotal.com/gui/file/328ad6468f6edb80b3abf97ac39a0721)|Win32 EXE||2019-04-21 22:31:55| |
|[9e182d30b070bb14a8922cff4837b94d](https://www.virustotal.com/gui/file/9e182d30b070bb14a8922cff4837b94d)|Win32 EXE||2019-04-02 03:52:24|%APPDATA%\msreg.exe|
|[3d2835c35ba789bd86620f98cbfbf08b](https://www.virustotal.com/gui/file/3d2835c35ba789bd86620f98cbfbf08b)|Win32 EXE||2019-03-26 01:31:46|MSREG.EXE|
|[233b300a58d5236c355afd373dabc48b](https://www.virustotal.com/gui/file/233b300a58d5236c355afd373dabc48b)|DOCX||2019-01-07 07:13:30|1206.doc|
|[7c3c4c4e7273c10dbbab628f6b2336d8](https://www.virustotal.com/gui/file/7c3c4c4e7273c10dbbab628f6b2336d8)|Win32 EXE|strat|2019-01-07 07:07:48|usb3mon.exe|
|[74db88b890054259d2f16ff22c79144d](https://www.virustotal.com/gui/file/74db88b890054259d2f16ff22c79144d)|Win32 EXE||2018-05-17 20:11:08| |
|[61b4e0b1f14d93d7b176981964388291](https://www.virustotal.com/gui/file/61b4e0b1f14d93d7b176981964388291)|Win32 EXE||2018-01-23 18:15:05|%APPDATA%\msreg.exe|
|[92f6c00da977110200b5a3359f5e1462](https://www.virustotal.com/gui/file/92f6c00da977110200b5a3359f5e1462)|DOCX||2018-01-23 18:15:05|C:\Documents and Settings\Administrator\Application Data\6.docx|
|[ae66ed2276336668e793b167b6950040](https://www.virustotal.com/gui/file/ae66ed2276336668e793b167b6950040)|Win32 EXE||2018-01-23 18:14:44|30d9c598136999238f155b592c90dc70416f72d6|
|[12b5fed367db92475b071b6d622e44cd](https://www.virustotal.com/gui/file/12b5fed367db92475b071b6d622e44cd)|Win32 EXE|Blocker|2018-01-08 02:00:38|contract 2018.exe|
|[6e949601ebdd5d50707c0af7d3f3c7a5](https://www.virustotal.com/gui/file/6e949601ebdd5d50707c0af7d3f3c7a5)|DOC||2018-01-08 01:12:31|contract.doc|
|[08ecd8068617c86d7e3a3e810b106dce](https://www.virustotal.com/gui/file/08ecd8068617c86d7e3a3e810b106dce)|Win32 EXE|strat|2018-01-08 01:11:58|winword.exe|
|[0d386ebba1ccf1758a19fb0b25451afe](https://www.virustotal.com/gui/file/0d386ebba1ccf1758a19fb0b25451afe)|DOC||2017-10-05 11:47:38|0927.doc|
|[3b58e122d9e17121416b146daab4db9d](https://www.virustotal.com/gui/file/3b58e122d9e17121416b146daab4db9d)|Win32 EXE|Blocker|2017-10-05 11:47:36|3b58e122d9e17121416b146daab4db9d.vir|
|[1732357d3a0081a87d56ee1ae8b4d205](https://www.virustotal.com/gui/file/1732357d3a0081a87d56ee1ae8b4d205)|Win32 EXE||2017-06-17 02:54:35|dwhost.exe|
|[70def87d180616406e010051ed773749](https://www.virustotal.com/gui/file/70def87d180616406e010051ed773749)|Win32 EXE|Blocker|2017-06-17 02:33:24| |
