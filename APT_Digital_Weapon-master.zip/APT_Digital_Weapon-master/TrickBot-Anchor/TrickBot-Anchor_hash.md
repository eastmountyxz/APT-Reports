|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[000c2072af00874a4fa7d932efd72c75](https://www.virustotal.com/gui/file/000c2072af00874a4fa7d932efd72c75)|TXT||2020-03-18 00:35:26|settings.ini|
|[64574f1a3b4d554322279a238c7943f1](https://www.virustotal.com/gui/file/64574f1a3b4d554322279a238c7943f1)|Win32 DLL|Cridex|2020-03-17 22:14:01|DiskBundleEx|
|[bfa4848b24e4266201aee7a54465a6c3](https://www.virustotal.com/gui/file/bfa4848b24e4266201aee7a54465a6c3)|Win32 EXE|TrickBot|2020-03-17 22:13:46|CronosVir|
|[5ac573a39dbf6b4c6e0ad9a45ae70419](https://www.virustotal.com/gui/file/5ac573a39dbf6b4c6e0ad9a45ae70419)|Win32 EXE|TrickBot|2020-03-17 22:13:34|CronosVir|
|[62ded00158221fd7b3e678b9d9edbd7b](https://www.virustotal.com/gui/file/62ded00158221fd7b3e678b9d9edbd7b)|TXT|sLoad|2020-03-17 17:59:39|c:\netstats\PressTableList.jse|
|[a98c28d9666e6050b2c76d0062342078](https://www.virustotal.com/gui/file/a98c28d9666e6050b2c76d0062342078)|TXT||2020-03-17 14:05:57|C:\netstats\PressTableList.cmd|
|[0c7cecfb65b75141f98a0485c2e9849e](https://www.virustotal.com/gui/file/0c7cecfb65b75141f98a0485c2e9849e)|DOCM|Sagent|2020-03-17 12:45:04|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\08b885ccc3eda61a918bd1887b7669e54d03be79a3accae765c10cd0850ff10d|
|[f87e1e745b74b87d5987ea3d2418fd8c](https://www.virustotal.com/gui/file/f87e1e745b74b87d5987ea3d2418fd8c)|Win32 DLL|TrickBot|2020-02-25 18:58:15|pluralgive.dll|
|[05b07832e9e004f72b0a599ede0dbbcd](https://www.virustotal.com/gui/file/05b07832e9e004f72b0a599ede0dbbcd)|DOCM|TrickBot|2020-02-25 16:11:50|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\533ba6af6fb6a529af62b0af69eff78dfe2478e8e693cd4fa4a3fec01570ddfa|
