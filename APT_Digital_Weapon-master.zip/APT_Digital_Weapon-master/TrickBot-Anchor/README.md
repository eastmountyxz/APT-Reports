**NAME:**  
TrickBot-Anchor

 
**Description**:   
According to IBM, FIN6 has partnered with the malware gang behind one of the most active Trojans (TrickBot) to use its new malware framework dubbed “Anchor” against organizations for financial profit. The Anchor malware framework itself is not new and its origins date back to at least 2018. It appears to be tightly connected to TrickBot and is likely programmed by the same malware authors that work on TrickBot. 

  
**References**:  
https://securityintelligence.com/posts/itg08-aka-fin6-partners-with-trickbot-gang-uses-anchor-framework/
