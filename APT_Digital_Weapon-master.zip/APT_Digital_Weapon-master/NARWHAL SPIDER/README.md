**NAME:**  
NARWHAL SPIDER  

**Description**:   
NARWHAL SPIDER is designated by CrowdStrike for the criminal operator of Cutwail version 2. It primarily provides spam services with a large customer base that has included malware operators such as WIZARD SPIDER (developer of TrickBot), affiliates of BAMBOO SPIDER (developer of Panda Zeus), and many others including URLZone, Nymaim and Gozi ISFB.

**References**:  
https://www.crowdstrike.com/blog/cutwail-spam-campaign-uses-steganography-to-distribute-urlzone/