|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[2e9164174d266a20e4fba498ef81e420](https://www.virustotal.com/gui/file/2e9164174d266a20e4fba498ef81e420)|Win32 EXE|johnnie|2018-11-22 12:12:42|2e9164174d266a20e4fba498ef81e420.virobj|
|[cd74dd88322431441fb1088ac7dd6715](https://www.virustotal.com/gui/file/cd74dd88322431441fb1088ac7dd6715)|RTF||2018-06-09 06:09:17|77bb403d09f2da4ebb22cadbb7606c76659977f4|
|[75a00fcede0b91793a19295a8b9a7060](https://www.virustotal.com/gui/file/75a00fcede0b91793a19295a8b9a7060)|DOCX|CVE-2017-0199|2018-06-08 04:38:04|75a00fcede0b91793a19295a8b9a7060.virobj|
|[adcd2838f9fbc24b31e163a77980d814](https://www.virustotal.com/gui/file/adcd2838f9fbc24b31e163a77980d814)|Win32 EXE|razy|2018-05-28 13:31:14|CalcTape.exe|
|[d1266b75959962ce0eb8e37df561dbcd](https://www.virustotal.com/gui/file/d1266b75959962ce0eb8e37df561dbcd)|Win32 EXE||2018-05-24 12:52:28|BClient.exe|
|[17f98131471bb8e2b484ad6a6ee0a309](https://www.virustotal.com/gui/file/17f98131471bb8e2b484ad6a6ee0a309)|Win32 EXE||2018-05-21 13:34:28|Process Manager.exe|
|[db948cc4a2a4d8bebd6d02c7312e065f](https://www.virustotal.com/gui/file/db948cc4a2a4d8bebd6d02c7312e065f)|Win32 EXE||2018-05-20 14:37:18|QuickTime.exe|
|[85c50cc74763fd76c8f3bba9a5b8f3a1](https://www.virustotal.com/gui/file/85c50cc74763fd76c8f3bba9a5b8f3a1)|Win32 EXE||2018-05-16 04:53:36|BClient.exe|
|[f5e6f8416d0923db7456258b9fc80a6c](https://www.virustotal.com/gui/file/f5e6f8416d0923db7456258b9fc80a6c)|Win32 EXE|scar|2018-05-13 04:50:59|QuickTime.exe|
|[72bc3889c02fdafbc837f4c9b2b77b53](https://www.virustotal.com/gui/file/72bc3889c02fdafbc837f4c9b2b77b53)|Win32 EXE||2018-05-07 04:42:51|Plex.exe|
|[332438c6277d2488b79a5763c7cb48b9](https://www.virustotal.com/gui/file/332438c6277d2488b79a5763c7cb48b9)|Win32 EXE||2018-04-28 16:44:27|Teppo.exe|
|[fb46900b9302ae3138a4f34a76260830](https://www.virustotal.com/gui/file/fb46900b9302ae3138a4f34a76260830)|Win32 EXE||2018-04-25 10:38:39|Player.exe|
|[53f7b4344e5ce78abfefe346ae38859e](https://www.virustotal.com/gui/file/53f7b4344e5ce78abfefe346ae38859e)|Win32 EXE|razy|2018-04-18 12:08:58|53f7b4344e5ce78abfefe346ae38859e.virus|
