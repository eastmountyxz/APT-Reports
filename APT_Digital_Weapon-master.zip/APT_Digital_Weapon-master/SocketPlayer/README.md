**NAME:**  
SocketPlayer  
  
**Alias**  
SocketPlayer, ShadowSnake, 蛇影  
  
**Description**:   
SocketPlayer, named by Tencent, is a backdoor disguised as video player program targeting government and military units of India, Pakistan and South Korea through spear-phishing and watering hole attacks.
  
**References**:  
https://mp.weixin.qq.com/s/e377pVez-o6rJtFlVTVwyw