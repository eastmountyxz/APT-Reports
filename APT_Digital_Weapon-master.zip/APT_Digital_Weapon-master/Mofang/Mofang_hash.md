|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f9c14a8e9ceb143d959743ad8c09fdc4](https://www.virustotal.com/gui/file/f9c14a8e9ceb143d959743ad8c09fdc4)|Win32 EXE||2018-05-08 04:17:37|/home/virustotal/sample/F9C14A8E9CEB143D959743AD8C09FDC4|
|[a4da3b820883e9808bd3ca2e02437a25](https://www.virustotal.com/gui/file/a4da3b820883e9808bd3ca2e02437a25)|Win32 EXE||2018-05-07 12:49:11|/home/virustotal/sample/A4DA3B820883E9808BD3CA2E02437A25|
|[6b126cd9a5f2af30bb048caef92ceb51](https://www.virustotal.com/gui/file/6b126cd9a5f2af30bb048caef92ceb51)|unknown|Korplug|2015-09-09 14:20:42|/home/virustotal/sample/6B126CD9A5F2AF30BB048CAEF92CEB51|
|[4e493a649e2b87ef1a341809dab34a38](https://www.virustotal.com/gui/file/4e493a649e2b87ef1a341809dab34a38)|Win32 DLL|Kryptik|2015-09-09 14:20:17|/home/virustotal/sample/4E493A649E2B87EF1A341809DAB34A38|
|[b43e5988bde7bb03133eec60daaf22d5](https://www.virustotal.com/gui/file/b43e5988bde7bb03133eec60daaf22d5)|Win32 EXE|Zbot|2015-07-02 00:57:06|/home/virustotal/sample/B43E5988BDE7BB03133EEC60DAAF22D5|
|[9a6167cf7c180f15d8ae13f48d549d2e](https://www.virustotal.com/gui/file/9a6167cf7c180f15d8ae13f48d549d2e)|Win32 EXE||2015-06-19 10:42:29|/home/virustotal/sample/9A6167CF7C180F15D8AE13F48D549D2E|
|[582e4adddfd12f7d68035c3b8e2e3378](https://www.virustotal.com/gui/file/582e4adddfd12f7d68035c3b8e2e3378)|Win32 EXE||2015-06-12 16:48:52|/home/virustotal/sample/582E4ADDDFD12F7D68035C3B8E2E3378|
|[f34c6239b7d70f23ce02a8d207176637](https://www.virustotal.com/gui/file/f34c6239b7d70f23ce02a8d207176637)|Win32 DLL||2015-06-04 07:09:35|/home/virustotal/sample/F34C6239B7D70F23CE02A8D207176637|
|[d7a575895b07b007d0daf1f15bfb14a1](https://www.virustotal.com/gui/file/d7a575895b07b007d0daf1f15bfb14a1)|Win32 EXE|archsms|2015-06-01 14:55:24|/home/virustotal/sample/D7A575895B07B007D0DAF1F15BFB14A1|
|[fb80354303a0ff748696baae3d264af4](https://www.virustotal.com/gui/file/fb80354303a0ff748696baae3d264af4)|Win32 EXE|injector|2015-05-29 09:13:26|/home/virustotal/sample/FB80354303A0FF748696BAAE3D264AF4|
|[26ff9e2da06b7e90443d6190388581ab](https://www.virustotal.com/gui/file/26ff9e2da06b7e90443d6190388581ab)|Win32 DLL||2015-05-16 18:22:18|/home/virustotal/sample/26FF9E2DA06B7E90443D6190388581AB|
|[1f330f00510866522f14790398a5be59](https://www.virustotal.com/gui/file/1f330f00510866522f14790398a5be59)|Win32 EXE||2015-04-14 04:25:44|coInst.exe|
|[ca41c19366bee737fe5bc5008250976a](https://www.virustotal.com/gui/file/ca41c19366bee737fe5bc5008250976a)|Win32 EXE|dynamer|2014-11-10 11:28:02|/home/virustotal/sample/CA41C19366BEE737FE5BC5008250976A|
|[c27fb6999a0243f041c5e387280f9442](https://www.virustotal.com/gui/file/c27fb6999a0243f041c5e387280f9442)|Win32 DLL|PlugX|2014-11-07 02:39:49|/home/virustotal/sample/C27FB6999A0243F041C5E387280F9442|
|[d8b95e942993b979fb82c22ea5b5ca18](https://www.virustotal.com/gui/file/d8b95e942993b979fb82c22ea5b5ca18)|unknown||2014-11-07 02:39:36|/home/virustotal/sample/D8B95E942993B979FB82C22EA5B5CA18|
|[23a1a7f0f30f18ba4d0461829eb46766](https://www.virustotal.com/gui/file/23a1a7f0f30f18ba4d0461829eb46766)|unknown||2014-11-04 09:20:39|/home/virustotal/sample/23A1A7F0F30F18BA4D0461829EB46766|
|[b4554c52f708154e529f62ba8e0de084](https://www.virustotal.com/gui/file/b4554c52f708154e529f62ba8e0de084)|Win32 DLL|PlugX|2014-11-04 09:18:55|/home/virustotal/sample/B4554C52F708154E529F62BA8E0DE084|
|[a3f7895fae05fa121a4e23dd3595c366](https://www.virustotal.com/gui/file/a3f7895fae05fa121a4e23dd3595c366)|unknown||2014-10-29 09:05:15|/home/virustotal/sample/A3F7895FAE05FA121A4E23DD3595C366|
|[5965731f2f237a12f7a4873e3e37658a](https://www.virustotal.com/gui/file/5965731f2f237a12f7a4873e3e37658a)|Win32 DLL|Korplug|2014-10-28 09:31:15|/home/virustotal/sample/5965731F2F237A12F7A4873E3E37658A|
|[36e057fa2020c65f2849d718f2bb90ad](https://www.virustotal.com/gui/file/36e057fa2020c65f2849d718f2bb90ad)|Win32 EXE|archsms|2014-09-04 10:32:59|/home/virustotal/sample/36E057FA2020C65F2849D718F2BB90AD|
|[3dab6ff3719ff7fcb01080fc36fe97dc](https://www.virustotal.com/gui/file/3dab6ff3719ff7fcb01080fc36fe97dc)|Win32 EXE||2014-08-28 13:28:17|/home/virustotal/sample/3DAB6FF3719FF7FCB01080FC36FE97DC|
|[484c7f9e6c9233ba6ed4adb79b87ebce](https://www.virustotal.com/gui/file/484c7f9e6c9233ba6ed4adb79b87ebce)|Win32 EXE||2014-05-22 15:05:43|/home/virustotal/sample/484C7F9E6C9233BA6ED4ADB79B87EBCE|
|[e79b2d2934e5525e7a40d74875f9d761](https://www.virustotal.com/gui/file/e79b2d2934e5525e7a40d74875f9d761)|Win32 EXE|archsms|2014-04-23 07:26:22|/home/virustotal/sample/E79B2D2934E5525E7A40D74875F9D761|
|[25e87e846bb969802e8db9b36d6cf67c](https://www.virustotal.com/gui/file/25e87e846bb969802e8db9b36d6cf67c)|Win32 EXE|kazy|2014-02-18 00:51:56|/home/virustotal/sample/25E87E846BB969802E8DB9B36D6CF67C|
|[4e22e8bc3034d0df1e902413c9cfefc9](https://www.virustotal.com/gui/file/4e22e8bc3034d0df1e902413c9cfefc9)|Win64 EXE||2013-12-18 12:28:13|/home/virustotal/sample/4E22E8BC3034D0DF1E902413C9CFEFC9|
|[f4b247a44be362898c4e587545c7653f](https://www.virustotal.com/gui/file/f4b247a44be362898c4e587545c7653f)|Win32 EXE||2013-11-06 08:20:41|/home/virustotal/sample/F4B247A44BE362898C4E587545C7653F|
|[5c00ccf456135514c591478904b146e3](https://www.virustotal.com/gui/file/5c00ccf456135514c591478904b146e3)|Win32 EXE|kazy|2013-11-06 01:39:07|/home/virustotal/sample/5C00CCF456135514C591478904B146E3|
|[916a2a20a447b10e379543a47a60b40f](https://www.virustotal.com/gui/file/916a2a20a447b10e379543a47a60b40f)|Win32 EXE|dynamer|2013-10-05 07:29:23|/home/virustotal/sample/916A2A20A447B10E379543A47A60B40F|
|[888cac09f613db4505c4ee8d01d4291b](https://www.virustotal.com/gui/file/888cac09f613db4505c4ee8d01d4291b)|Win64 EXE||2013-09-10 23:04:32|/home/virustotal/sample/888CAC09F613DB4505C4EE8D01D4291B|
|[2f14d8c3d4815436f806fc1a435e29e3](https://www.virustotal.com/gui/file/2f14d8c3d4815436f806fc1a435e29e3)|Win32 EXE|dynamer|2013-09-10 23:00:11|/home/virustotal/sample/2F14D8C3D4815436F806FC1A435E29E3|
|[b281a2e1457cd5ca8c85700817018902](https://www.virustotal.com/gui/file/b281a2e1457cd5ca8c85700817018902)|Win32 EXE|dynamer|2013-08-25 01:09:29|/home/virustotal/sample/B281A2E1457CD5CA8C85700817018902|
|[cf883d04762b868b450275017ab3ccfa](https://www.virustotal.com/gui/file/cf883d04762b868b450275017ab3ccfa)|Win32 EXE|kazy|2013-08-14 13:58:49|/home/virustotal/sample/CF883D04762B868B450275017AB3CCFA|
|[a326e2abacc72c7a050ffe36e3d3d0eb](https://www.virustotal.com/gui/file/a326e2abacc72c7a050ffe36e3d3d0eb)|Win64 EXE||2013-07-31 17:52:17|/home/virustotal/sample/A326E2ABACC72C7A050FFE36E3D3D0EB|
|[06cca5013175c5a1c8ff89a494e24245](https://www.virustotal.com/gui/file/06cca5013175c5a1c8ff89a494e24245)|Win32 EXE|kazy|2013-07-17 14:48:32|/home/virustotal/sample/06CCA5013175C5A1C8FF89A494E24245|
|[2384febe404ef48d6585f050e3cd51a8](https://www.virustotal.com/gui/file/2384febe404ef48d6585f050e3cd51a8)|Win32 EXE|kazy|2013-04-23 13:16:41|/home/virustotal/sample/2384FEBE404EF48D6585F050E3CD51A8|
|[663e54e686842eb8f8bae2472cf01ba1](https://www.virustotal.com/gui/file/663e54e686842eb8f8bae2472cf01ba1)|Win32 EXE||2013-01-01 06:21:24|/home/virustotal/sample/663E54E686842EB8F8BAE2472CF01BA1|
