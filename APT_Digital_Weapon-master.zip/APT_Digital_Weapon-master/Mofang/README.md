**NAME:**  
Mofang  
  
**Alias**  
Superman, Mofang  

**Description**:   
Mofang is a threat actor named by Foxit. Is reported to be operated out of China and is probably government-affiliated. Mofang’s targets are probably selected based on involvement with investments, or technological advances, including those located in India, Germany, United States, Canada, Singapore and South Korea.
  
**References**:  
https://blog.fox-it.com/2016/06/15/mofang-a-politically-motivated-information-stealing-adversary/  
https://www.threatconnect.com/china-superman-apt/  