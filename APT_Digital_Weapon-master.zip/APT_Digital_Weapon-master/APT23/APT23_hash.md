|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[75b86a01196854919626e87d5bd45a38](https://www.virustotal.com/gui/file/75b86a01196854919626e87d5bd45a38)|PPSX|CVE-2017-8570|2018-12-31 06:58:09| |
|[b21e41de20b4b90db69ca71626f51eaf](https://www.virustotal.com/gui/file/b21e41de20b4b90db69ca71626f51eaf)|Win32 EXE|injector|2018-10-11 06:30:13| |
|[f73dcdbf1238ab626c3736a9d79f2cd5](https://www.virustotal.com/gui/file/f73dcdbf1238ab626c3736a9d79f2cd5)|RTF||2018-10-08 09:07:07|Signed PO.doc|
|[d0a381c6eeb0c741be0380a7b142c474](https://www.virustotal.com/gui/file/d0a381c6eeb0c741be0380a7b142c474)|Rich Text Format||2018-10-02 00:28:39|RFQ550059645679.doc|
|[3f25cccd7d09a7cce963aadab8250f3a](https://www.virustotal.com/gui/file/3f25cccd7d09a7cce963aadab8250f3a)|Win32 EXE|Delf|2018-09-26 15:44:00|arm.exe|
|[8d8e2e876acf09601e4bb7b83bbd5773](https://www.virustotal.com/gui/file/8d8e2e876acf09601e4bb7b83bbd5773)|Win32 DLL|ursu|2018-09-04 13:33:42|rasauto.dll|
|[a056a864d238a2d1355eed95b8e2bef6](https://www.virustotal.com/gui/file/a056a864d238a2d1355eed95b8e2bef6)|Win32 DLL|johnnie|2018-06-27 12:46:28|fdb85d3f08eb70f0d2171d8bd348574139f63f31a788d2ff1b2a28aca6066345.sample|
|[2171f4552858d6648c5b466a7b36dced](https://www.virustotal.com/gui/file/2171f4552858d6648c5b466a7b36dced)|PPSX|CVE-2017-8570|2018-06-27 11:07:44|TR_Rusvet_ve_Yolsuzlukla_Mcd_Egtm|
|[c50f9575695b5363c22989ba14ba7823](https://www.virustotal.com/gui/file/c50f9575695b5363c22989ba14ba7823)|PPSX|CVE-2017-8570|2018-05-31 06:00:12|Interviewer's Information and Points of Interview.ppsx|
|[f43f60b62002d0700ccbcbd9334520b6](https://www.virustotal.com/gui/file/f43f60b62002d0700ccbcbd9334520b6)|Email|CVE-2017-8570|2018-05-31 05:54:07|1.eml|
|[cca8b5e5855698c72b41e6b8ef2e090f](https://www.virustotal.com/gui/file/cca8b5e5855698c72b41e6b8ef2e090f)|PPSX|CVE-2017-8570|2018-05-24 08:39:34|-Passport Message.ppsx|
|[8ecdf40683cb2d1e971b9b62054dfc1e](https://www.virustotal.com/gui/file/8ecdf40683cb2d1e971b9b62054dfc1e)|HTML||2018-05-04 22:04:39|office.sct|
|[124c475d67aa8391f5220efcc64ca5b3](https://www.virustotal.com/gui/file/124c475d67aa8391f5220efcc64ca5b3)|Win32 DLL|KeyBoy|2018-03-12 18:00:09|124c475d67aa8391f5220efcc64ca5b3.virus|
|[058a5d47f8834fccfff8971f0544e387](https://www.virustotal.com/gui/file/058a5d47f8834fccfff8971f0544e387)|Win32 DLL|Andromeda|2018-03-09 15:47:07|C:\Users\user\AppData\Local\Temp\setup.bin|
|[fa5ca764789ece810df3f1536192fb1e](https://www.virustotal.com/gui/file/fa5ca764789ece810df3f1536192fb1e)|Win32 DLL|KeyBoy|2018-03-09 08:51:19|update.dll|
|[67e866c461c285853b225d2b2c850c4f](https://www.virustotal.com/gui/file/67e866c461c285853b225d2b2c850c4f)|Win32 DLL||2018-02-13 05:23:48|osun.dll|
|[11e0f3e1c7d8855ed7f1dcfce4b7702a](https://www.virustotal.com/gui/file/11e0f3e1c7d8855ed7f1dcfce4b7702a)|Win32 DLL|razy|2018-01-24 07:46:17|a.wll|
|[b1c114ae9172a3bacc5c6b30c410f354](https://www.virustotal.com/gui/file/b1c114ae9172a3bacc5c6b30c410f354)|PPSX|CVE-2017-8570|2018-01-23 23:09:25|Greeting Card From Department of Health, CTA.ppsx|
|[88e85fb6074ae50a3ccc9b410805ffe5](https://www.virustotal.com/gui/file/88e85fb6074ae50a3ccc9b410805ffe5)|RTF|Andromeda|2018-01-23 12:41:13|88e85fb6074ae50a3ccc9b410805ffe5.virus|
|[4d85904b15c0adc8664f71bc2c5496bf](https://www.virustotal.com/gui/file/4d85904b15c0adc8664f71bc2c5496bf)|PPSX|CVE-2017-8570|2018-01-23 12:38:00|The PPT For  National Museum Of Tibet.ppsx|
|[91e976f76cc027931fed4cf70702efff](https://www.virustotal.com/gui/file/91e976f76cc027931fed4cf70702efff)|PPSX|CVE-2017-8570|2018-01-17 15:25:30|1000-278e1811b2d9d4043bb82ae674a5b48fc083c518|
|[57ffde3504934e25904bcc57d27f9217](https://www.virustotal.com/gui/file/57ffde3504934e25904bcc57d27f9217)|RTF||2018-01-17 15:20:26|Key Campaign Opportunities for early 2018.rtf|
|[1f4d22e5131a66aa24f44eb0d4f1b54d](https://www.virustotal.com/gui/file/1f4d22e5131a66aa24f44eb0d4f1b54d)|Win32 EXE||2013-06-14 05:12:34|FONTSETUP.EXE|
|[2df60de8cb6b9fe7db1ea10581cfcda4](https://www.virustotal.com/gui/file/2df60de8cb6b9fe7db1ea10581cfcda4)|Win32 DLL|Zbot|2013-06-11 22:21:50|CREDRIVER.dll|
|[2b8c79678fa970ca4e229121e3de206f](https://www.virustotal.com/gui/file/2b8c79678fa970ca4e229121e3de206f)|Win32 DLL|zapchast|2013-06-07 17:14:58|2b8c79678fa970ca4e229121e3de206f.bin|
|[161c840748df9b49fda878394398425a](https://www.virustotal.com/gui/file/161c840748df9b49fda878394398425a)|DOC||2013-06-06 04:17:26|161C840748DF9B49FDA878394398425A.DO$|
|[dff54d302900e323c8988c725bbe2299](https://www.virustotal.com/gui/file/dff54d302900e323c8988c725bbe2299)|RTF|CVE-2012-0158|2013-04-28 13:53:15|1595ea659a87677c59a195a3aeec9e3ef135c808ec353222e8eaa662117c9362.rtf|
|[2a8836c4511e7171f60ddc966a177e75](https://www.virustotal.com/gui/file/2a8836c4511e7171f60ddc966a177e75)|Win32 DLL|Razy|2020-04-27 15:42:16|%APPDATA%\microsoft\corporation\mpsvc.dll|
|[ccacb925e6b307c266691cf6515b486e](https://www.virustotal.com/gui/file/ccacb925e6b307c266691cf6515b486e)|TXT|sLoad|2020-04-27 11:20:41|Cập nhật lịch trực lễ 30_4 và 1_5.eml|
|[208229cd8d0d3d725af1aed73a175145](https://www.virustotal.com/gui/file/208229cd8d0d3d725af1aed73a175145)|XLS|sLoad|2020-04-27 10:42:14|Lich truc le 30-4 và 1-5.xls|
|[b4c5cd5abc0673e6531a973dcf2ffefa](https://www.virustotal.com/gui/file/b4c5cd5abc0673e6531a973dcf2ffefa)|Win32 EXE||2016-11-29 18:27:28|MsMpEng.exe|
|[7498a89572e1a2fcd4a0ff8ceea96f87](https://www.virustotal.com/gui/file/7498a89572e1a2fcd4a0ff8ceea96f87)|Win32 DLL|PoisonIvy|2016-11-28 10:07:11|7498a89572e1a2fcd4a0ff8ceea96f87.virus|
|[1590ff9da2ac7f28f02564d4114a43d2](https://www.virustotal.com/gui/file/1590ff9da2ac7f28f02564d4114a43d2)|Win32 DLL||2016-09-23 11:33:33|CREDRIVER.dll|
|[c0c96e3f268331c0c457895429e1d512](https://www.virustotal.com/gui/file/c0c96e3f268331c0c457895429e1d512)|Win32 DLL|Tspy|2016-09-03 09:13:16|VGX.OCX|
|[53f5b9d9e81612804ddaf15e71d983c7](https://www.virustotal.com/gui/file/53f5b9d9e81612804ddaf15e71d983c7)|Win32 DLL|dynamer|2016-08-02 07:20:02|winsin.dll|
|[7194dcb825f4df1ea78e4cac8582f148](https://www.virustotal.com/gui/file/7194dcb825f4df1ea78e4cac8582f148)|Win32 DLL|PoisonIvy|2015-12-02 06:09:17|winsin.dll|
|[eeada911413c7f7dad76fab9821ada45](https://www.virustotal.com/gui/file/eeada911413c7f7dad76fab9821ada45)|Win64 DLL|bitrep|2015-11-19 04:53:02|Credentials.dll|
|[6d28b55b2ae1f529635dc898c2e3cc34](https://www.virustotal.com/gui/file/6d28b55b2ae1f529635dc898c2e3cc34)|Win32 DLL|Zbot|2015-11-05 16:56:34| |
|[4b7f5a088e43361cf6ce738661c4aa5c](https://www.virustotal.com/gui/file/4b7f5a088e43361cf6ce738661c4aa5c)|Win32 DLL||2015-07-23 07:19:54|VGX.OCX|
|[7337596ee26c28c74f6c20dcd07fe65f](https://www.virustotal.com/gui/file/7337596ee26c28c74f6c20dcd07fe65f)|Win32 DLL|PoisonIvy|2015-06-16 23:39:56| |
|[cd78f95d558fd3e5510298fe3c5b83a0](https://www.virustotal.com/gui/file/cd78f95d558fd3e5510298fe3c5b83a0)|Win32 DLL|KeyBoy|2015-06-04 02:47:57|SystemCertificates.ocx|
|[069d26cd523f1576bbd335141bae8c55](https://www.virustotal.com/gui/file/069d26cd523f1576bbd335141bae8c55)|Win32 DLL|KeyBoy|2015-05-27 11:17:07|SystemCertificates.ocx|
|[231a9766bdc006c36ae1dedb2251c07a](https://www.virustotal.com/gui/file/231a9766bdc006c36ae1dedb2251c07a)|Win32 DLL|KeyBoy|2015-05-26 14:12:50|SystemCertificates.ocx|
|[93fa49f69aa9873c7f19823161bd8406](https://www.virustotal.com/gui/file/93fa49f69aa9873c7f19823161bd8406)|Win32 DLL||2015-05-26 08:33:52|93fa49f69aa9873c7f19823161bd8406_KaIXRQFBImVeRVlS.dll|
|[d723f8bf72451730f48f533b372dddff](https://www.virustotal.com/gui/file/d723f8bf72451730f48f533b372dddff)|Win32 DLL||2015-05-13 08:44:54|Credentials.dll|
|[0c7e55509e0b6d4277b3facf864af018](https://www.virustotal.com/gui/file/0c7e55509e0b6d4277b3facf864af018)|Win32 DLL|graftor|2015-05-05 23:19:24| |
|[af797d920fda253b27f48941a30664bb](https://www.virustotal.com/gui/file/af797d920fda253b27f48941a30664bb)|Win32 DLL|KeyBoy|2015-03-18 12:07:30| |
|[19256544f1f6de323a79631a76898e7c](https://www.virustotal.com/gui/file/19256544f1f6de323a79631a76898e7c)|Win32 DLL||2014-12-29 09:16:07|/home/virustotal/sample/19256544F1F6DE323A79631A76898E7C|
|[bb2d57a1a557908253c96ae43f07a95d](https://www.virustotal.com/gui/file/bb2d57a1a557908253c96ae43f07a95d)|Win32 DLL||2014-12-29 09:06:11|1.dl~|
|[fe0ad2e2c155a3938f4a2f907cae5244](https://www.virustotal.com/gui/file/fe0ad2e2c155a3938f4a2f907cae5244)|Win32 DLL|Banload|2014-12-17 05:30:02|fe0ad2e2c155a3938f4a2f907cae5244_vKJhsNzJIRyPzmrz.DlL|
|[c0177c651dd58e4961d2190ff91c6f44](https://www.virustotal.com/gui/file/c0177c651dd58e4961d2190ff91c6f44)|Win32 DLL|PoisonIvy|2014-12-16 17:32:35|myfile.exe|
|[0043240bebaf921674559ed9f05505f1](https://www.virustotal.com/gui/file/0043240bebaf921674559ed9f05505f1)|Win32 DLL||2014-11-06 06:08:00|0043240bebaf921674559ed9f05505f1_KZdXcTEyVdPMAaYJufdJ.dLl|
|[e20abe1f32aa7ac4f20f8ce24f7d1f62](https://www.virustotal.com/gui/file/e20abe1f32aa7ac4f20f8ce24f7d1f62)|Win32 EXE||2014-10-24 05:14:19|Install_|
|[216702154571022bd17f769ec2484a56](https://www.virustotal.com/gui/file/216702154571022bd17f769ec2484a56)|Win32 DLL||2014-10-08 10:06:34|credentials.dll|
|[7fa40b6a592890c93b06796503f8771d](https://www.virustotal.com/gui/file/7fa40b6a592890c93b06796503f8771d)|Win32 DLL||2014-09-23 02:09:41|vt-upload-5hRZn|
|[d475d1576a5994eb88e44f2dd496b03f](https://www.virustotal.com/gui/file/d475d1576a5994eb88e44f2dd496b03f)|Win32 EXE||2014-08-15 05:45:54|Install_|
|[7cf254d99c34b3e6a10482a471cc3f70](https://www.virustotal.com/gui/file/7cf254d99c34b3e6a10482a471cc3f70)|Win32 DLL|PoisonIvy|2014-06-03 09:29:20|7cf254d99c34b3e6a10482a471cc3f70_fVwhOZwCfLSIQ.DlL|
|[f9de4ccd73275eab6251ed0c736fc433](https://www.virustotal.com/gui/file/f9de4ccd73275eab6251ed0c736fc433)|Win32 DLL||2014-05-02 04:09:34|credriver.dll|
|[1001e79098476cf9f11d35e2d8f6bf11](https://www.virustotal.com/gui/file/1001e79098476cf9f11d35e2d8f6bf11)|Win32 DLL|Banload|2013-11-14 20:39:39|e1480984daab1d275b99b8a2cd4013295b97392a|
|[dcbc2de64289cd13a2ab3fe49dbb5bca](https://www.virustotal.com/gui/file/dcbc2de64289cd13a2ab3fe49dbb5bca)|Win32 EXE||2013-01-08 11:24:33|626f65d4d638437a_626f65d4d638437aaa8352fe06589165d52a91e0963c988348b00734b0a3419f.exe|
