**NAME:**  
APT23  
  
**Alias**  
Pirate Panda, KeyBoy, Tropic Trooper, APT23  

**Description**:   
APT23, also known as Tropic Trooper, focuses on government, healthcare, transportation, and high-tech industries. According to the report from Trend Micro, its operators are believed to be very organized and develop their own cyberespionage tools that they fine-tuned in their campaigns.
  
**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/tropic-trooper-new-strategy/