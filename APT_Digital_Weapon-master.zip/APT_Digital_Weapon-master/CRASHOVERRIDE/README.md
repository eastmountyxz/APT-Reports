**NAME:**  
CRASHOVERRIDE  
  
**Alias**  
Industroyer, CRASHOVERRIDE  

**Description**:   
he CRASHOVERRIDE malware impacted a single transmission level substation in Ukraine on December 17th, 2016. It is the first ever malware framework designed and deployed to attack electric grids. The functionality in the CRASHOVERRIDE framework serves no espionage purpose and the only real feature of the malware is for attacks which would lead to electric outage
  
**References**:  
