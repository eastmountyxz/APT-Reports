|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[dd99d917eb17ddca2fb4460ecf6304b6](https://www.virustotal.com/gui/file/dd99d917eb17ddca2fb4460ecf6304b6)|Win32 DLL||2019-10-30 02:18:55|0d5b26286ffe885809d91ed95fefdf43b920ce86f6cae063d9acaa96fc13da60.bin|
|[0e1ed07bae97d8b1cc4dcfe3d56ea3ee](https://www.virustotal.com/gui/file/0e1ed07bae97d8b1cc4dcfe3d56ea3ee)|Win32 EXE||2019-10-29 10:13:40| |
|[6e95c5c01f94ef7154e30b4b23e81b36](https://www.virustotal.com/gui/file/6e95c5c01f94ef7154e30b4b23e81b36)|Win32 EXE||2019-10-29 09:00:41| |
|[9e7b254df610aefbc5253a646220401e](https://www.virustotal.com/gui/file/9e7b254df610aefbc5253a646220401e)|Win32 DLL||2019-10-29 08:48:57|hpktx32.dll|
|[77100e638dd8ef8db4b3370d066984a9](https://www.virustotal.com/gui/file/77100e638dd8ef8db4b3370d066984a9)|Win32 EXE||2019-10-29 08:19:07| |
|[109d252d24fa3b8b543f01d34b6cbf17](https://www.virustotal.com/gui/file/109d252d24fa3b8b543f01d34b6cbf17)|Win32 EXE||2019-10-14 08:45:36|109d252d24fa3b8b543f01d34b6cbf17.virus|
|[3310304d41f99330c556ba5762c16294](https://www.virustotal.com/gui/file/3310304d41f99330c556ba5762c16294)|Win32 DLL||2019-09-02 07:09:28|billings.dll|
|[8b8c026dac2cfbaf2006316d888632cd](https://www.virustotal.com/gui/file/8b8c026dac2cfbaf2006316d888632cd)|Win32 EXE||2019-09-02 07:08:21|Congratulates Korea on  National Day 70th anniversary.SCR|
|[2e8c34fd5d75a47061cd1e06b8d2a99e](https://www.virustotal.com/gui/file/2e8c34fd5d75a47061cd1e06b8d2a99e)|Win32 EXE||2019-08-29 12:13:09|11111.scr|
|[1e769aa405d41eaeca6b61eb564b9eba](https://www.virustotal.com/gui/file/1e769aa405d41eaeca6b61eb564b9eba)|Win32 EXE||2019-08-09 05:43:16| |
|[c454d7902ba3959335b0ef8e074b50a2](https://www.virustotal.com/gui/file/c454d7902ba3959335b0ef8e074b50a2)|Win32 EXE||2019-08-09 05:43:15| |
|[c9ce24a7561dab524cb5413bf7fec81b](https://www.virustotal.com/gui/file/c9ce24a7561dab524cb5413bf7fec81b)|Win32 EXE||2019-07-22 02:29:55|6666666666|
|[714e6589d253c188209a579ff812f423](https://www.virustotal.com/gui/file/714e6589d253c188209a579ff812f423)|Win32 EXE||2019-07-14 19:05:44| |
|[5fbd4d107c08a3e65804c0edee68a267](https://www.virustotal.com/gui/file/5fbd4d107c08a3e65804c0edee68a267)|Android||2019-07-08 12:30:48|5fbd4d107c08a3e65804c0edee68a267.virus|
|[4b0bc7e723a7dff471aa15cba82f8136](https://www.virustotal.com/gui/file/4b0bc7e723a7dff471aa15cba82f8136)|Win32 EXE|strictor|2019-04-28 07:43:54| |
|[0a11b8f93073833464134aa740a8d70f](https://www.virustotal.com/gui/file/0a11b8f93073833464134aa740a8d70f)|Win32 EXE||2019-04-17 05:37:03|0a11b8f93073833464134aa740a8d70f.virus|
|[9837c85faf3385b5289a671851d5c14c](https://www.virustotal.com/gui/file/9837c85faf3385b5289a671851d5c14c)|Win32 EXE||2019-04-12 20:32:24|myfile.exe|
|[63d3975b9a277730d7432e27ef77202b](https://www.virustotal.com/gui/file/63d3975b9a277730d7432e27ef77202b)|Win32 EXE||2019-04-06 18:42:56|63d3975b9a277730d7432e27ef77202b.virus|
|[8b565dfd7581a72659f7990acbf36804](https://www.virustotal.com/gui/file/8b565dfd7581a72659f7990acbf36804)|Win32 EXE||2019-03-28 20:20:17|8b565dfd7581a72659f7990acbf36804.virus|
|[0796fb3436bb7727cb8d64a2f423f9be](https://www.virustotal.com/gui/file/0796fb3436bb7727cb8d64a2f423f9be)|Win32 EXE||2019-03-04 02:41:37|3er1.exe|
|[6febd1729c49f434b6b062edf8d3e7f3](https://www.virustotal.com/gui/file/6febd1729c49f434b6b062edf8d3e7f3)|Win32 DLL|graftor|2019-02-21 04:19:42|newDll|
|[7c94a0e412cc46db5904080980d993c3](https://www.virustotal.com/gui/file/7c94a0e412cc46db5904080980d993c3)|Win32 EXE||2019-02-21 04:15:50|정월 대보름날 즐겁게 보내세요.scr.exe|
|[cad355de03dc1439be27896c8c378cb9](https://www.virustotal.com/gui/file/cad355de03dc1439be27896c8c378cb9)|Win32 EXE||2019-02-03 13:04:52|card|
|[91b7b9928d20054181caa24f5b9aa839](https://www.virustotal.com/gui/file/91b7b9928d20054181caa24f5b9aa839)|Win32 EXE||2019-01-24 10:12:58|Happy New  Year.scr|
|[26e2a010b4cca084c7c3e9cdf8e05030](https://www.virustotal.com/gui/file/26e2a010b4cca084c7c3e9cdf8e05030)|Win32 EXE|ursu|2019-01-22 04:44:53|26e2a010b4cca084c7c3e9cdf8e05030.virobj|
|[50c86f1de6caeefce7c1d7e2ef39aa79](https://www.virustotal.com/gui/file/50c86f1de6caeefce7c1d7e2ef39aa79)|Win32 EXE||2019-01-22 04:33:19|50c86f1de6caeefce7c1d7e2ef39aa79.virus|
|[ea296441165b0c7f27f0ecac084df21a](https://www.virustotal.com/gui/file/ea296441165b0c7f27f0ecac084df21a)|Win32 EXE||2019-01-18 18:20:29| |
|[f684cd4ba25a36a9331a0dbcc047d1cb](https://www.virustotal.com/gui/file/f684cd4ba25a36a9331a0dbcc047d1cb)|Win32 EXE||2019-01-02 05:33:35|새해를 축하합니다.scr|
|[8d3af3fea7cd5f93823562c1a62e598a](https://www.virustotal.com/gui/file/8d3af3fea7cd5f93823562c1a62e598a)|Android||2018-12-29 18:15:00|c8677692073e70cdac6a1dc842b03dd6ec33e2c913296859236f398f46bfa66b.bin|
|[16dcd7e8c9773c8bef6a9eb78a634dd3](https://www.virustotal.com/gui/file/16dcd7e8c9773c8bef6a9eb78a634dd3)|Win32 EXE||2018-10-08 19:25:23|119b335a4e0925fa25a0f33cdf80836fe99f0d9d3578c445e444a6dd34694ddc.sample|
|[a512a23491611604e05b31c44845fe17](https://www.virustotal.com/gui/file/a512a23491611604e05b31c44845fe17)|Win32 EXE||2018-09-14 22:52:00|NAVAREA XI WARNING.Txt.scr|
|[21fcdf439000b6eb03cc9d1ca6c8a76c](https://www.virustotal.com/gui/file/21fcdf439000b6eb03cc9d1ca6c8a76c)|Win32 DLL||2018-07-04 17:28:01|<SYSTEM32>\magiax32.dll|
|[11a807c699c8e4cc438f9f20e524f61b](https://www.virustotal.com/gui/file/11a807c699c8e4cc438f9f20e524f61b)|Win32 EXE||2018-06-07 07:33:56|Setup.exe|
|[dd954c34ac289118290d65fcb0549743](https://www.virustotal.com/gui/file/dd954c34ac289118290d65fcb0549743)|Win32 DLL|ursu|2018-05-27 13:33:17|Hsdc.Dll|
|[6fb537011718106745d05236ab4fb42a](https://www.virustotal.com/gui/file/6fb537011718106745d05236ab4fb42a)|Win32 EXE||2018-05-18 17:05:30|setup.exe|
|[7bcacd70639e70d8d803cca30c9d9744](https://www.virustotal.com/gui/file/7bcacd70639e70d8d803cca30c9d9744)|Win32 DLL|ursu|2018-05-18 13:43:45|Hsdc.Dll|
|[6633ac6507883244359add02032d15fd](https://www.virustotal.com/gui/file/6633ac6507883244359add02032d15fd)|Win32 DLL||2018-05-08 16:25:09|6633ac6507883244359add02032d15fd.virus|
|[8c25a708ea0e142190e03f5117f046f2](https://www.virustotal.com/gui/file/8c25a708ea0e142190e03f5117f046f2)|Win32 EXE|Ursu|2018-02-13 11:32:52|player.exe|
|[602658138ae185cc219f2a5c6028751e](https://www.virustotal.com/gui/file/602658138ae185cc219f2a5c6028751e)|Win32 EXE||2018-02-08 18:11:22|player.exe|
|[8662935003722d568e856fa054226a12](https://www.virustotal.com/gui/file/8662935003722d568e856fa054226a12)|Win32 EXE||2018-02-08 18:04:13|player.exe|
|[48845bc47bcc337dfe40bebf930649b3](https://www.virustotal.com/gui/file/48845bc47bcc337dfe40bebf930649b3)|Win32 EXE||2018-01-28 04:48:21|setup.exe|
|[fa8c53431746d9ccc550f75f15b14b97](https://www.virustotal.com/gui/file/fa8c53431746d9ccc550f75f15b14b97)|Win32 EXE||2018-01-27 10:42:27|setup.exe|
|[342a0a6b527d3c56a1c248155ad3eef3](https://www.virustotal.com/gui/file/342a0a6b527d3c56a1c248155ad3eef3)|Win32 EXE||2018-01-27 10:39:44|setup.exe|
|[8ed4d39f4fd30e7f9fc91b571612bb43](https://www.virustotal.com/gui/file/8ed4d39f4fd30e7f9fc91b571612bb43)|Win32 EXE||2018-01-17 14:08:24|setup.exe|
|[3e1c1047d599bb579b11cc60f23a2cb2](https://www.virustotal.com/gui/file/3e1c1047d599bb579b11cc60f23a2cb2)|Win32 DLL|Ursu|2018-01-01 16:02:05|Hsdc.Dll|
|[f443e24c183e188ef3b0d8024afd4423](https://www.virustotal.com/gui/file/f443e24c183e188ef3b0d8024afd4423)|Win32 DLL|Ursu|2017-12-28 06:01:40|hpktx32.dll|
|[94b660301590764702c77fb2e5c44daf](https://www.virustotal.com/gui/file/94b660301590764702c77fb2e5c44daf)|Win32 DLL|Ursu|2017-12-18 17:44:16|Hsdc.Dll|
|[fdce7fe4b333e3581ceda6a9ab7fb3be](https://www.virustotal.com/gui/file/fdce7fe4b333e3581ceda6a9ab7fb3be)|Win32 DLL|ursu|2017-10-24 06:38:02|hpktx32.dll|
|[1bea784bdc479243dc9370b50c128c3d](https://www.virustotal.com/gui/file/1bea784bdc479243dc9370b50c128c3d)|Win32 DLL|ursu|2017-10-24 04:28:00|Hsdc.Dll|
|[c291c7a095c81929e0fff2319297cd84](https://www.virustotal.com/gui/file/c291c7a095c81929e0fff2319297cd84)|Win32 EXE|dynamer|2017-10-24 04:24:08|a03045cd22acadeb2e1adce77fc2309ff11e9eba|
|[059c639c9b4afa59267d2d7e5de9fd68](https://www.virustotal.com/gui/file/059c639c9b4afa59267d2d7e5de9fd68)|Win32 DLL|ursu|2017-10-23 18:00:24|Hsdc.Dll|
|[3e17165615e74ba0e937bbce42ed125b](https://www.virustotal.com/gui/file/3e17165615e74ba0e937bbce42ed125b)|Win32 DLL|ursu|2017-10-23 17:02:26|Hsdc.Dll|
|[a3f85e3784d3e544617cc60ab6b387b4](https://www.virustotal.com/gui/file/a3f85e3784d3e544617cc60ab6b387b4)|Win32 EXE|tiggre|2017-10-23 16:57:41|E:/virussign/malware/new_request/20171028/a3f85e3784d3e544617cc60ab6b387b4.vir|
|[4996112daaec54fb53e5d4bbd1735af2](https://www.virustotal.com/gui/file/4996112daaec54fb53e5d4bbd1735af2)|Win32 DLL||2017-10-11 05:14:58|D:/working_board/dataset/unused/malware/vir_VT/20171012/4996112daaec54fb53e5d4bbd1735af2.vir|
|[997ab0b59d865c4bd63cc55b5e9c8b48](https://www.virustotal.com/gui/file/997ab0b59d865c4bd63cc55b5e9c8b48)|LNK||2020-05-30 05:55:04|International English Language Testing System certificate.pdf.lnk|
|[4a4a223893c67b9d34392670002d58d7](https://www.virustotal.com/gui/file/4a4a223893c67b9d34392670002d58d7)|LNK||2020-05-30 05:55:03|Curriculum Vitae_WANG LEI_Hong Kong Polytechnic University.pdf.lnk|
|[278d191d794f84034c90bf9a3068d51e](https://www.virustotal.com/gui/file/278d191d794f84034c90bf9a3068d51e)|RAR||2020-05-30 02:23:35|615400.lnk|
|[b32a91f20a3efdbcfef53a578ae760ce](https://www.virustotal.com/gui/file/b32a91f20a3efdbcfef53a578ae760ce)|LNK||2020-05-29 08:03:54|Curriculum Vitae_WANG LEI_Hong Kong Polytechnic University.pdf.lnk|
|[c657e04141252e39b9fa75489f6320f5](https://www.virustotal.com/gui/file/c657e04141252e39b9fa75489f6320f5)|LNK||2020-05-12 21:30:51|C:\Users\ADMINI~1\AppData\Local\Temp\All tort's projects - Web lnks\Tokbox icon - Odds and Ends - iOS - Zeplin.lnk|
|[45278d4ad4e0f4a891ec99283df153c3](https://www.virustotal.com/gui/file/45278d4ad4e0f4a891ec99283df153c3)|LNK||2020-05-12 21:30:49|C:\Users\ADMINI~1\AppData\Local\Temp\All tort's projects - Web lnks\Conversations - iOS - Swipe Icons - Zeplin.lnk|
|[2ffb817ff7ddcfa216da31f50e199df1](https://www.virustotal.com/gui/file/2ffb817ff7ddcfa216da31f50e199df1)|RAR||2020-05-12 17:59:57|Project link and New copyright policy.rar|
|[390366d02abce50f5bb1df94aa50e928](https://www.virustotal.com/gui/file/390366d02abce50f5bb1df94aa50e928)|Win32 EXE||2020-04-01 08:29:18| |
|[aa67b7141327c0fad9881597c76282c0](https://www.virustotal.com/gui/file/aa67b7141327c0fad9881597c76282c0)|LNK||2020-03-27 02:19:55|aa67b7141327c0fad9881597c76282c0.virobj|
|[59a55c7bbc0ee488ec9e2cf50b792a56](https://www.virustotal.com/gui/file/59a55c7bbc0ee488ec9e2cf50b792a56)|Win32 DLL|occamy|2020-03-05 17:55:12|C:\Users\Administrator\AppData\Roaming\Microsoft\Word\STARTUP\intel.wll|
|[2123bf482c9c80cb1896ff9288ad7d60](https://www.virustotal.com/gui/file/2123bf482c9c80cb1896ff9288ad7d60)|RTF|CVE-2017-11882|2020-03-05 07:36:18|muestras/500b6037ddb5efff0dd91f75b22ccce5b04d996c459d83d1f07fae8780b24e09|
|[4d937035747b4eb7a78083afa06022d3](https://www.virustotal.com/gui/file/4d937035747b4eb7a78083afa06022d3)|Win32 EXE||2020-03-02 01:25:31|4d937035747b4eb7a78083afa06022d3.virus|
|[01b90259a9771d470582073c61773f30](https://www.virustotal.com/gui/file/01b90259a9771d470582073c61773f30)|Win32 DLL||2020-01-14 01:20:48|Duser.dll|
|[37093d3918b0cc2ca9805f8225cccd75](https://www.virustotal.com/gui/file/37093d3918b0cc2ca9805f8225cccd75)|Win32 EXE|occamy|2020-01-14 01:18:21|2020-New-Year-Wishes-For-You.scr|
|[739a40f8c839756a5e6e3c89b2742f8e](https://www.virustotal.com/gui/file/739a40f8c839756a5e6e3c89b2742f8e)|Win32 EXE|Graftor|2020-01-07 08:20:48| |
|[5de5917dcadb2ecacd7ffd69ea27f986](https://www.virustotal.com/gui/file/5de5917dcadb2ecacd7ffd69ea27f986)|Win32 DLL|occamy|2020-01-03 04:21:19|C:\ProgramData\CommonDatas\Duser.dll|
|[2173b589b30ba2b0242c82c9bcb698b2](https://www.virustotal.com/gui/file/2173b589b30ba2b0242c82c9bcb698b2)|Win32 EXE|Skeeyah|2020-01-03 04:18:57|C:\Users\ADMINI~1\AppData\Local\Temp\Happy-new-year-2020.scr|
|[d5e42cc18906f09d5bab62df45b5fcf6](https://www.virustotal.com/gui/file/d5e42cc18906f09d5bab62df45b5fcf6)|Win32 EXE||2019-12-23 00:10:48|C:\ProgramData\TotalSecurity\360ShellPro.exe|
|[082ed4a73761682f897ea1d7f4529f69](https://www.virustotal.com/gui/file/082ed4a73761682f897ea1d7f4529f69)|Win32 EXE||2009-07-21 01:34:30|rekeywiz|
