**NAME:**  
Higaisa  
  
**Alias**  
Higaisa, Higaisa, 黑格莎  

**Description**:   
Higaisa, named by Tencent, is an attack group uses North Korea's important time nodes such as holidays to carry out fishing attacks since at least 2016. The targets include diplomatic entities, government officials, human rights organizations, oversea residents, and trade associates. Affected victims are located in China, North Korea, Japan, Nepal, Singapore, Russia, Poland, and Switzerland. The attack group is reported to be from South Korea.
  
**References**:  
https://www.freebuf.com/news/219001.html
