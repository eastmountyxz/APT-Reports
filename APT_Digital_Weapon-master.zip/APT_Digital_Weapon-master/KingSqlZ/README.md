**NAME:**  
KingSqlZ  
  
**Description**:   
KingSqlZ is a Turkish attack group disclosed by ADLab. It carried out targeted attacks against government agencies and energy companies in the Spanish-speaking region  

**References**:  
https://mp.weixin.qq.com/s/jF1Gg7Lo-2NGti2n6k5zlA
