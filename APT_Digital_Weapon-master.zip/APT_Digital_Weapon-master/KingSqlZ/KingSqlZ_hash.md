|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[1e19266fc9dff1480f126bd211936aac](https://www.virustotal.com/gui/file/1e19266fc9dff1480f126bd211936aac)|Win32 EXE||2019-04-05 09:30:26|919f65801a6065b533554254df39353ab4ef572a864afdfd26bb349717a49a80.bin|
|[262d9c6c0dc9d54726738d264802ccad](https://www.virustotal.com/gui/file/262d9c6c0dc9d54726738d264802ccad)|DOC|sload|2019-03-26 22:26:14|Jose Trujillo.doc|
|[b3c9f98dd07005fccf57842451ce1b33](https://www.virustotal.com/gui/file/b3c9f98dd07005fccf57842451ce1b33)|Win32 EXE|Andromeda|2019-03-12 19:26:33|DatabaseSearch.exe|
|[def105a9452def53d49631af16f6018b](https://www.virustotal.com/gui/file/def105a9452def53d49631af16f6018b)|Win32 EXE|Kryptik|2019-02-28 16:17:32|underreader.exe|
|[048dca20685ecd6b7dbdbf04b9082a54](https://www.virustotal.com/gui/file/048dca20685ecd6b7dbdbf04b9082a54)|Win32 EXE||2019-02-27 18:02:22|Etr739.exe|
|[497566120f1020dbd6df70dd128c0ffb](https://www.virustotal.com/gui/file/497566120f1020dbd6df70dd128c0ffb)|RTF|sload|2019-02-09 01:40:03|Curriculum Vitae Actualizado Daniel Ortiz.doc|
|[99c82f8a07605da4ccc8853c910f7caf](https://www.virustotal.com/gui/file/99c82f8a07605da4ccc8853c910f7caf)|DOC|o97m|2019-02-07 07:19:04| |
