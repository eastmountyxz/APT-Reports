**NAME:**  
Shamoon 3  

**Description**:   
Shamoon 3, discovered by PaloAlto, shares a considerable amount of code with the Disttrack malware used in the Shamoon 2 attacks. It targets 
oil and gas organization in the Middle East.
Unlike past Shamoon attacks, this particular Disttrack wiper would overwrite the MBR partitions, and files on the system with randomly generated data rather than overwriting files with an image.
One of the compromised organization in Saudi Arabia was also hit by Elfin (APT33).

**References**:  
https://researchcenter.paloaltonetworks.com/2018/12/shamoon-3-targets-oil-gas-organization/  
https://www.symantec.com/blogs/threat-intelligence/shamoon-destructive-threat-re-emerges-new-sting-its-tail  
