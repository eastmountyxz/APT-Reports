|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5711ac3dd15b019f558ec29e68d13ca9](https://www.virustotal.com/gui/file/5711ac3dd15b019f558ec29e68d13ca9)|Win64 EXE||2018-12-23 16:19:02|Baidu PC Faster|
|[d0c3852e376423247ae45c24592880b6](https://www.virustotal.com/gui/file/d0c3852e376423247ae45c24592880b6)|Win64 EXE||2018-12-23 16:18:54|PC-Doctor|
|[34506c620697e7dceff320317c95aaef](https://www.virustotal.com/gui/file/34506c620697e7dceff320317c95aaef)|Win64 EXE||2018-12-23 10:57:52|elrawdsk.sys|
|[ecda82069d4349bf492404c369339f71](https://www.virustotal.com/gui/file/ecda82069d4349bf492404c369339f71)|Win64 EXE||2018-12-18 10:50:07|dab3308ab60d0d8acb3611bf364e81b63cfb6b4c1783864ebc515297e2297589.bin|
|[30825f6ef7b1bb5d3de6640c2758fe68](https://www.virustotal.com/gui/file/30825f6ef7b1bb5d3de6640c2758fe68)|Win64 EXE||2018-12-17 23:28:11|mdmzyxlga.exe|
|[92fff1d754faab445e90651dfb0ded4d](https://www.virustotal.com/gui/file/92fff1d754faab445e90651dfb0ded4d)|Win32 EXE||2018-12-13 02:23:28|6985ef5809d0789eeff623cd2436534b818fd2843f09fa2de2b4a6e2c0e1a879.bin|
|[04c68a4fe70ffb3483aa2076b08ca882](https://www.virustotal.com/gui/file/04c68a4fe70ffb3483aa2076b08ca882)|Win32 EXE|wiper|2018-12-12 18:42:09|SlHost.exe|
|[fdf409a9755a4ac20508d903f2325aec](https://www.virustotal.com/gui/file/fdf409a9755a4ac20508d903f2325aec)|Win32 EXE|wiper|2018-12-12 09:22:47|SlHost.exe|
|[785a1c8a78a3e38905078b137c8247ae](https://www.virustotal.com/gui/file/785a1c8a78a3e38905078b137c8247ae)|Win32 EXE||2018-12-12 09:20:17|Spreader.exe|
|[63e8259b60299aab5751e3d82ba3d697](https://www.virustotal.com/gui/file/63e8259b60299aab5751e3d82ba3d697)|Win32 EXE||2018-12-12 09:18:56|OCLC.exe|
|[a4a9100413ebba59cab785d506448093](https://www.virustotal.com/gui/file/a4a9100413ebba59cab785d506448093)|Win64 EXE||2018-12-11 20:37:02|MaintenaceSrv64.exe|
|[a7deb28a52521e5782d5ec367ae20afc](https://www.virustotal.com/gui/file/a7deb28a52521e5782d5ec367ae20afc)|Win32 EXE||2018-12-11 19:36:42|C_\Windows\system32\drivers\ndis.sy_|
|[887c614608e7cd9a691858caf468c28f](https://www.virustotal.com/gui/file/887c614608e7cd9a691858caf468c28f)|Win32 EXE||2018-12-11 19:33:39|C_\Windows\system32\prnlx00ctl.ex_|
|[27d18ff26f88d0f78c5d00138208686a](https://www.virustotal.com/gui/file/27d18ff26f88d0f78c5d00138208686a)|Win32 EXE||2018-12-11 19:31:37|P6_ImportClient|
|[b51fdec78474c52378e9d565b4e5f343](https://www.virustotal.com/gui/file/b51fdec78474c52378e9d565b4e5f343)|Win32 EXE||2018-12-11 19:31:21|P7ReportEngineClient|
|[7145d303065760829ad66887b8feabad](https://www.virustotal.com/gui/file/7145d303065760829ad66887b8feabad)|Win32 DLL||2018-12-11 05:06:59|ksecdd.sys|
|[de07c4ac94a50663851e5dabe6e50d1f](https://www.virustotal.com/gui/file/de07c4ac94a50663851e5dabe6e50d1f)|Win32 EXE||2018-12-10 15:29:30|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Shamoon/MaintenaceSrv32.exDec2018|
|[b41f586fc9c95c66f0967f1592641a85](https://www.virustotal.com/gui/file/b41f586fc9c95c66f0967f1592641a85)|Win32 EXE||2018-12-10 12:08:10|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Shamoon/kscaptur_ibv32.exDec2018|
|[41f8cd9ac3fb6b1771177e5770537518](https://www.virustotal.com/gui/file/41f8cd9ac3fb6b1771177e5770537518)|unknown||2017-01-25 19:34:08|key8854321.pub|
|[28bc925f0411311de6e645e82021e8fa](https://www.virustotal.com/gui/file/28bc925f0411311de6e645e82021e8fa)|Win32 EXE|wiper|2018-12-19 14:41:50|dIIhost.exe|
|[0e7d94c29685e7745a4eac0594d14a60](https://www.virustotal.com/gui/file/0e7d94c29685e7745a4eac0594d14a60)|Win32 EXE||2018-12-19 09:50:16|dIIhost.exe|
|[ac4d91e919a3ef210a59acab0dbb9ab5](https://www.virustotal.com/gui/file/ac4d91e919a3ef210a59acab0dbb9ab5)|Win64 EXE||2017-02-27 08:22:53|Shamoon Disttrack  Communication Components 64 bit|
|[1da4f946eb8080b031e69e0af246df63](https://www.virustotal.com/gui/file/1da4f946eb8080b031e69e0af246df63)|Win64 EXE||2017-01-30 15:17:04|/home/user/Competition/orig data/2017/malware/efd2f4c3fe4e9f2c9ac680a9c670cca378cef6b8776f2362ed278317bfb1fca8|
|[ba170958fd5b01967d5bcde6b1347425](https://www.virustotal.com/gui/file/ba170958fd5b01967d5bcde6b1347425)|Win64 EXE||2017-01-07 14:42:52|c:\users\aadmin\desktop\2work\t\ntertmgr\ntertmgr64.exe|
|[5446f46d89124462ae7aca4fce420423](https://www.virustotal.com/gui/file/5446f46d89124462ae7aca4fce420423)|Win32 EXE||2016-11-23 11:20:10|5446f46d89124462ae7aca4fce420423_PEtWmVCfrdcaXWK.eXe|
|[5bac4381c00044d7f4e4cbfd368ba03b](https://www.virustotal.com/gui/file/5bac4381c00044d7f4e4cbfd368ba03b)|Win32 EXE||2016-11-21 18:01:20|5bac4381c00044d7f4e4cbfd368ba03b_mZxLyVLawvMueNSzThCgECc.EXE|
|[c843046e54b755ec63ccb09d0a689674](https://www.virustotal.com/gui/file/c843046e54b755ec63ccb09d0a689674)|Win64 EXE||2016-11-21 18:00:35|c843046e54b755ec63ccb09d0a689674_PGZkaUYTwOkW.exe|
|[2cd0a5f1e9bcce6807e57ec8477d222a](https://www.virustotal.com/gui/file/2cd0a5f1e9bcce6807e57ec8477d222a)|Win32 EXE||2016-11-21 17:56:09|/home/user/Competition/orig data/2017/malware/128fa5815c6fee68463b18051c1a1ccdf28c599ce321691686b1efa4838a2acd|
|[8fbe990c2d493f58a2afa2b746e49c86](https://www.virustotal.com/gui/file/8fbe990c2d493f58a2afa2b746e49c86)|Win64 EXE||2016-11-21 17:47:37|8fbe990c2d493f58a2afa2b746e49c86_WDbaSOLIkXnKXJIBRU.Exe|
|[76c643ab29d497317085e5db8c799960](https://www.virustotal.com/gui/file/76c643ab29d497317085e5db8c799960)|Win64 EXE||2012-08-20 09:16:03|elrawdsk.sys|
|[1493d342e7a36553c56b2adea150949e](https://www.virustotal.com/gui/file/1493d342e7a36553c56b2adea150949e)|Win32 EXE||2012-08-16 13:20:40|elrawdsk.sys|
