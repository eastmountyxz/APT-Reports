**NAME:**  
PowerSniff  

**Description**:   
PowerSniff, named by PaloAlto, is a malware of the Gozi group developed on the base of isfb. It uses Office Macros and PowerShell in documents distributed in e-mail messages to inject malware directly into memory.
  
**References**:  
https://malpedia.caad.fkie.fraunhofer.de/details/win.powersniff