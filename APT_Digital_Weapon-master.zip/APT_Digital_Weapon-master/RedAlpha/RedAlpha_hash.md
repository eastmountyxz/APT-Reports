|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d08de00e7168a441052672219e717957](https://www.virustotal.com/gui/file/d08de00e7168a441052672219e717957)|ELF executable||2018-07-27 07:30:48|/media/ahmed/0f0b5179-b625-471d-a08b-8cc99742b63c/IoTmalware/Malware/IoTFiltered/d08de00e7168a441052672219e717957|
|[c94a39d58450b81087b4f1f5fd304add](https://www.virustotal.com/gui/file/c94a39d58450b81087b4f1f5fd304add)|Win32 EXE||2018-03-08 17:22:44|c94a39d58450b81087b4f1f5fd304add.virus|
|[e28db08b2326a34958f00d68dfb034b0](https://www.virustotal.com/gui/file/e28db08b2326a34958f00d68dfb034b0)|Win32 EXE||2018-03-08 14:11:54|e28db08b2326a34958f00d68dfb034b0.virus|
|[c74608c70a59371cbf016316bebfab06](https://www.virustotal.com/gui/file/c74608c70a59371cbf016316bebfab06)|Win32 EXE|Disfa|2018-03-06 06:32:42|1967bd2047fd9dab_serverdo.exe|
|[3a2b1a98c0a31ed32759f48df34b4bc8](https://www.virustotal.com/gui/file/3a2b1a98c0a31ed32759f48df34b4bc8)|Win32 EXE|Ursu|2018-03-06 06:30:55|qww.exe|
|[e6c0ac26b473d1e0fa9f74fdf1d01af8](https://www.virustotal.com/gui/file/e6c0ac26b473d1e0fa9f74fdf1d01af8)|Win32 DLL||2018-03-05 06:07:05|02bf5fdb11eee6ede01cc061206fe98f60a6b5c90ffead31e8f0a87ccfa414ef__PEFILE__1.bin|
|[5228914b534a437eb7985702e78772be](https://www.virustotal.com/gui/file/5228914b534a437eb7985702e78772be)|RTF||2018-03-05 00:00:43|02BF5FDB11EEE6EDE01CC061206FE98F60A6B5C90FFEAD31E8F0A87CCFA414EF|
|[6dd1be1e491d5bf9cd14686c185c3009](https://www.virustotal.com/gui/file/6dd1be1e491d5bf9cd14686c185c3009)|Win64 DLL||2017-08-23 10:56:41|nethelp.dll|
|[d4ea9027edca1d01c62d9f43a2975d30](https://www.virustotal.com/gui/file/d4ea9027edca1d01c62d9f43a2975d30)|DOS EXE||2017-07-06 20:52:03|sample|
|[c6e336550bd1c087ee2a211781fd9280](https://www.virustotal.com/gui/file/c6e336550bd1c087ee2a211781fd9280)|Win64 EXE||2017-07-06 12:30:21|7354fd9fdb07f2509f8dab3bb23df53e21dd02ab2a4745d27eddb4caeaf5be14.bin|
|[cb71f3b4f08eba58857532ac90bac77d](https://www.virustotal.com/gui/file/cb71f3b4f08eba58857532ac90bac77d)|Win32 EXE||2017-06-29 15:45:10|cb71f3b4f08eba58857532ac90bac77d.exe|
|[cd32ce54ed94dfbde7fb85930a16597d](https://www.virustotal.com/gui/file/cd32ce54ed94dfbde7fb85930a16597d)|Win64 EXE||2017-06-29 15:37:00|cd32ce54ed94dfbde7fb85930a16597d.exe|
|[8f0fe2620f8dadf93eee285834e35655](https://www.virustotal.com/gui/file/8f0fe2620f8dadf93eee285834e35655)|Win64 DLL||2017-06-28 03:54:38|VirusShare_8f0fe2620f8dadf93eee285834e35655|
|[1412102eda0c2e5a5a85cb193dbb1524](https://www.virustotal.com/gui/file/1412102eda0c2e5a5a85cb193dbb1524)|Win64 EXE|skeeyah|2017-06-28 03:49:54|1412102eda0c2e5a5a85cb193dbb1524.exe|
|[42256b4753724f7feb411bc9912155fd](https://www.virustotal.com/gui/file/42256b4753724f7feb411bc9912155fd)|Win32 DLL||2017-06-19 12:43:34|42256b4753724f7feb411bc9912155fd.dll|
|[6d1d6987d0677f40e473befab121ab1b](https://www.virustotal.com/gui/file/6d1d6987d0677f40e473befab121ab1b)|Win32 EXE|Farfli|2017-06-19 12:41:59|6d1d6987d0677f40e473befab121ab1b.exe|
