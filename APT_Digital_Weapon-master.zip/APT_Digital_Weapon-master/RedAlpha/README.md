**NAME:**  
RedAlpha  
  
**Alias**  
Insikt, RedAlpha  

**Description**:   
RedAlpha, uncovered by Recorded Future, is reported to be a cyberespionage campaign targeting the Tibetan community. It combines light reconnaissance, selective targeting, and diverse malicious tooling.
  
**References**:  
https://aptmap.netlify.com/#RedAlpha  
https://www.recordedfuture.com/redalpha-cyber-campaigns/  