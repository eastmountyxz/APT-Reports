**NAME:**  
Operation Ghoul  

**Description**:   
Operation Ghoul, traced back to 2015, targeted industrial, manufacturing and engineering organizations in more than 30 countries. Over 130 organizations have been identified as victims of this campaign and most of them are Small to Medium size businesses.
  
**References**:  
https://securelist.com/operation-ghoul-targeted-attacks-on-industrial-and-engineering-organizations/75718/