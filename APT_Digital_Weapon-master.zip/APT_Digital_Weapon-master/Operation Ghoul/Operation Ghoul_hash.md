|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f9ef50c53a10db09fc78c123a95e8eec](https://www.virustotal.com/gui/file/f9ef50c53a10db09fc78c123a95e8eec)|7ZIP|Zbot|2016-06-27 13:09:45|emiratesNBD_Advice.7z|
|[55358155f96b67879938fe1a14a00dd6](https://www.virustotal.com/gui/file/55358155f96b67879938fe1a14a00dd6)|Win32 EXE|Zbot|2016-06-27 12:55:02|TeamConnect.exe|
|[8d46ee2d141176e9543dea9bf1c079c8](https://www.virustotal.com/gui/file/8d46ee2d141176e9543dea9bf1c079c8)|Win32 EXE||2016-06-13 19:50:24| |
|[460e18f5ae3e3eb38f8cae911d447590](https://www.virustotal.com/gui/file/460e18f5ae3e3eb38f8cae911d447590)|Email|Zbot|2016-06-11 09:01:12|9b0ff2139c8f5909a7e8f288ffb6fc23d35a6d46b856df76a8359748174dbb4f|
|[5f684750129e83b9b47dc53c96770e09](https://www.virustotal.com/gui/file/5f684750129e83b9b47dc53c96770e09)|FPX|Zbot|2016-06-10 18:32:00|Your payment copy advice from Emirates NBD Banksubsidiary.msg|
|[36a9ae8c6d32599f21c9d1725485f1a3](https://www.virustotal.com/gui/file/36a9ae8c6d32599f21c9d1725485f1a3)|Win32 EXE|strictor|2016-06-08 23:09:05|wn.exe|
|[6e959ccb692668e70780ff92757d2335](https://www.virustotal.com/gui/file/6e959ccb692668e70780ff92757d2335)|Win32 EXE||2016-06-08 23:09:02|centerx.exe|
|[07b105f15010b8c99d7d727ff3a9e70f](https://www.virustotal.com/gui/file/07b105f15010b8c99d7d727ff3a9e70f)|7ZIP|Zbot|2016-06-08 17:00:44|EmiratesNBD_ADVICE.7z|
|[cc6926cde42c6e29e96474f740d12a78](https://www.virustotal.com/gui/file/cc6926cde42c6e29e96474f740d12a78)|Win32 EXE||2016-06-05 03:38:42|cc6926cde42c6e29e96474f740d12a78.virus|
|[3664d7150ac98571e7b5652fd7e44085](https://www.virustotal.com/gui/file/3664d7150ac98571e7b5652fd7e44085)|Win32 EXE||2016-06-04 17:32:22|WN.EXE|
|[d87d26309ef01b162882ee5069dc0bde](https://www.virustotal.com/gui/file/d87d26309ef01b162882ee5069dc0bde)|Win32 EXE||2016-06-04 15:50:33| |
|[dabc47df7ae7d921f18faf685c367889](https://www.virustotal.com/gui/file/dabc47df7ae7d921f18faf685c367889)|Win32 EXE|Athena|2016-05-23 06:38:59|Kabari8|
|[ae2a78473d4544ed2acd46af2e09633d](https://www.virustotal.com/gui/file/ae2a78473d4544ed2acd46af2e09633d)|7ZIP|Zbot|2016-05-04 16:27:19| |
|[b8f6e6a0cb1bcf1f100b8d8ee5cccc4c](https://www.virustotal.com/gui/file/b8f6e6a0cb1bcf1f100b8d8ee5cccc4c)|Win32 EXE|dynamer|2016-05-04 08:44:42|lbloni.exe|
|[21ea64157c84ef6b0451513d0d11d02e](https://www.virustotal.com/gui/file/21ea64157c84ef6b0451513d0d11d02e)|7ZIP|Zbot|2016-04-28 18:25:27|Z:\current projects\AV activity\12-8-2015\EmiratesNBD_Advice.7z|
|[08c18d38809910667bbed747b2746201](https://www.virustotal.com/gui/file/08c18d38809910667bbed747b2746201)|Win32 EXE|Zbot|2016-04-28 11:05:13|feelabove.exe|
|[c3cf7b29426b9749ece1465a4ab4259e](https://www.virustotal.com/gui/file/c3cf7b29426b9749ece1465a4ab4259e)|Win32 EXE||2016-04-28 08:23:31|emag.exe|
|[5a68f149c193715d13a361732f5adaa1](https://www.virustotal.com/gui/file/5a68f149c193715d13a361732f5adaa1)|Win32 EXE|neshta|2016-01-19 01:11:58|javaj.exe|
|[aaee8ba81bee3deb1c95bd3aaa6b13d7](https://www.virustotal.com/gui/file/aaee8ba81bee3deb1c95bd3aaa6b13d7)|Win32 EXE||2016-01-04 16:17:29|v.exe|
|[5a97d62dc84ede64846ea4f3ad4d2f93](https://www.virustotal.com/gui/file/5a97d62dc84ede64846ea4f3ad4d2f93)|Win32 EXE|Alina|2015-12-08 22:21:33|java.exe|
