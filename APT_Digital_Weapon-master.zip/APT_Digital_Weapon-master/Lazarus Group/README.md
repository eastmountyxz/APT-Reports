**NAME:**  
Lazarus Group  
  
**Alias**  
Operation DarkSeoul, Dark Seoul, Hidden Cobra, Hastati Group, Andariel Group, Unit 121, Bureau 121, NewRomanic Cyber Army Team, Bluenoroff, Group 77, Labyrinth Chollima, Operation Troy, Operation GhostSecret, Guardians of Peace, ZINC, NICKEL ACADEMY, APT-C-26, Silent Chollima, Lazarus Group  
    
**Description**:   
Lazarus Group, active since at least 2009, is an APT group that has been attributed to the North Korean. There are lots of campaigns connected, including Operation Blockbuster, Operation Flame, Operation 1Mission, Operation Troy, DarkSeoul, Ten Days of Rain, etc.
In November 2014, it carried out destructive wiping attack against Sony Pictures Entertainment. In 2016, it attacked Bangladesh central banks and stole US$81 million. In the middle of 2017, the WannaCry malware which leverages the leaked EternalBlue exploits affected as many as 300,000 computers worldwide.  

**References**:  
