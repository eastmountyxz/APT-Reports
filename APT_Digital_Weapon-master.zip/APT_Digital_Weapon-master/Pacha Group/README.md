**NAME:**  
Pacha Group  

**Description**:   
Pacha group deploys undetected cryptojacking campaigns on Linux servers. Related malwares are named as Linux.Antd and Linux.GreedyAntd. Malware authors are reported to be from China.  
  
**References**:  
https://www.intezer.com/blog-technical-analysis-pacha-group/