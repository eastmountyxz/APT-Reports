|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[060d13afdb2212a717666b251feda1d3](https://www.virustotal.com/gui/file/060d13afdb2212a717666b251feda1d3)|Win32 DLL|PlugX|2017-01-03 11:34:29| |
|[bffc9f409be33207849207f62622db50](https://www.virustotal.com/gui/file/bffc9f409be33207849207f62622db50)|Win32 DLL||2016-11-20 13:21:48| |
|[fe1eb07a9068c32efd032404a7472e58](https://www.virustotal.com/gui/file/fe1eb07a9068c32efd032404a7472e58)|Win32 DLL|PlugX|2016-11-02 13:05:08|._code|
|[bddb10729acb2dfe28a7017b261d63db](https://www.virustotal.com/gui/file/bddb10729acb2dfe28a7017b261d63db)|Win32 DLL|ursu|2016-10-19 10:31:15|911712.bin|
|[2826c9c6c25368f773c0e448572585d0](https://www.virustotal.com/gui/file/2826c9c6c25368f773c0e448572585d0)|Win32 EXE||2016-10-09 02:26:59|normaldot.exe|
|[0647bac99b6a8407795134f5d67d4590](https://www.virustotal.com/gui/file/0647bac99b6a8407795134f5d67d4590)|Win32 DLL|Zbot|2016-10-01 05:33:55|ChoiceGuard.dll|
|[50b20197c9f9f3a8ded3a42aa6cf5315](https://www.virustotal.com/gui/file/50b20197c9f9f3a8ded3a42aa6cf5315)|Win32 DLL|Zbot|2016-09-29 09:19:45|._code|
|[c4cee8d6f30127938681c93dd19f2af4](https://www.virustotal.com/gui/file/c4cee8d6f30127938681c93dd19f2af4)|RTF||2016-09-29 06:27:54|72aea0644729cadfe668751587a1e6384c49c398580feecefc51385ecc018631.bin|
|[1bbc1549b8fe1ced42e65d8375ff7010](https://www.virustotal.com/gui/file/1bbc1549b8fe1ced42e65d8375ff7010)|RAR|dynamer|2016-09-20 03:30:41|virus.rar|
|[e2bc937f028602dda3fa56ad204ca726](https://www.virustotal.com/gui/file/e2bc937f028602dda3fa56ad204ca726)|Win32 EXE|strictor|2016-09-19 05:49:53|C:\ofmal\SampleUrlMake_1.1.005\_download\673f315388d9c3e47adc280da1ff8b85a0893525.exe|
|[263b6c350cbf7354b99139be17c272d3](https://www.virustotal.com/gui/file/263b6c350cbf7354b99139be17c272d3)|Win32 DLL||2016-09-11 23:25:11|ChoiceGuard.dll|
|[ee4563761247361632046c8966a4c790](https://www.virustotal.com/gui/file/ee4563761247361632046c8966a4c790)|Win32 DLL|Zbot|2016-09-09 20:46:00|ee4563761247361632046c8966a4c790.virus|
|[380cfac90270b45518c17c224aa8e5be](https://www.virustotal.com/gui/file/380cfac90270b45518c17c224aa8e5be)|Win32 DLL|Zbot|2016-09-09 20:40:21|380cfac90270b45518c17c224aa8e5be.virus|
|[d692a057330361f8f58163f9aa7fc3a8](https://www.virustotal.com/gui/file/d692a057330361f8f58163f9aa7fc3a8)|Win32 DLL|Zbot|2016-07-25 04:47:19|ChoiceGuard.dll|
|[f38ffc4bfe7b449389b05d483016625b](https://www.virustotal.com/gui/file/f38ffc4bfe7b449389b05d483016625b)|Win32 EXE|PlugX|2016-07-25 01:00:27| |
|[2801b537960058643dfdb3fc5199246d](https://www.virustotal.com/gui/file/2801b537960058643dfdb3fc5199246d)|Win32 DLL||2016-05-24 18:05:26|Binary.NewBinary19|
|[898812640c2cb691e5d9cdea96fe9599](https://www.virustotal.com/gui/file/898812640c2cb691e5d9cdea96fe9599)|Win32 DLL|Zbot|2016-03-04 07:20:50|898812640c2cb691e5d9cdea96fe9599.virus|
|[a9c07b9fb099f44e7b8f53a74d7f71d0](https://www.virustotal.com/gui/file/a9c07b9fb099f44e7b8f53a74d7f71d0)|Win32 DLL|Zbot|2016-03-04 07:20:28|a9c07b9fb099f44e7b8f53a74d7f71d0.virus|
|[0932b703849364ca1537305761bc3429](https://www.virustotal.com/gui/file/0932b703849364ca1537305761bc3429)|Win32 DLL|Zbot|2016-03-02 23:38:21|ChoiceGuard.dll|
|[9e73734ac2ab5293c0f326245658b50e](https://www.virustotal.com/gui/file/9e73734ac2ab5293c0f326245658b50e)|Win32 EXE|Zbot|2016-03-02 23:22:06| |
|[c27da5a756569012449c479609c3b959](https://www.virustotal.com/gui/file/c27da5a756569012449c479609c3b959)|Win32 DLL|Zbot|2016-02-20 23:36:21| |
|[6c833531eb3c6b97095b45fcc8f2a1e6](https://www.virustotal.com/gui/file/6c833531eb3c6b97095b45fcc8f2a1e6)|Win32 EXE|PlugX|2016-02-20 23:21:04| |
|[65067f8c60cbc4ee459641c3b704e180](https://www.virustotal.com/gui/file/65067f8c60cbc4ee459641c3b704e180)|Win32 EXE||2020-03-19 16:56:11|65067f8c60cbc4ee459641c3b704e180.virobj|
|[0922a6d3d9d9a774eea90853a075056e](https://www.virustotal.com/gui/file/0922a6d3d9d9a774eea90853a075056e)|Win32 EXE|occamy|2020-02-10 09:45:53|0922a6d3d9d9a774eea90853a075056e.virus|
|[30e519573d04a2e1505d8daafb712406](https://www.virustotal.com/gui/file/30e519573d04a2e1505d8daafb712406)|Win32 DLL|Zbot|2019-10-27 03:38:41|libvlc.dll|
|[1e8915ccb433ce0406a98faa94db2237](https://www.virustotal.com/gui/file/1e8915ccb433ce0406a98faa94db2237)|Win32 EXE||2019-10-16 19:35:12| |
|[5a477d4574983c2603c6f05ff5bae01e](https://www.virustotal.com/gui/file/5a477d4574983c2603c6f05ff5bae01e)|Win32 DLL||2019-10-15 17:43:21|shore.exe|
|[f3a7d55ee47f2b6bdf7ed6259a6f9496](https://www.virustotal.com/gui/file/f3a7d55ee47f2b6bdf7ed6259a6f9496)|Win32 DLL||2019-10-15 16:58:17|shore.exe|
|[f3a7d55ee47f2b6bdf7ed6259a6f9496](https://www.virustotal.com/gui/file/f3a7d55ee47f2b6bdf7ed6259a6f9496)|Win32 DLL||2019-10-15 16:58:17|shore.exe|
|[9d7953cd0e67e6ebad049faba242a74b](https://www.virustotal.com/gui/file/9d7953cd0e67e6ebad049faba242a74b)|Win32 EXE||2019-10-12 06:22:50| |
|[9d7953cd0e67e6ebad049faba242a74b](https://www.virustotal.com/gui/file/9d7953cd0e67e6ebad049faba242a74b)|Win32 EXE||2019-10-12 06:22:50| |
|[f946ea7d9640023d06c2751dde195eb8](https://www.virustotal.com/gui/file/f946ea7d9640023d06c2751dde195eb8)|Win32 DLL||2019-10-01 09:54:40|C:\ProgramData\Drivers\Olmapi32.dll|
|[f946ea7d9640023d06c2751dde195eb8](https://www.virustotal.com/gui/file/f946ea7d9640023d06c2751dde195eb8)|Win32 DLL||2019-10-01 09:54:40|C:\ProgramData\Drivers\Olmapi32.dll|
|[7d19f3547dc900eba548ee5ceb84edae](https://www.virustotal.com/gui/file/7d19f3547dc900eba548ee5ceb84edae)|Win32 DLL||2019-09-27 11:04:44|000.out|
|[5024e86b00012a202d6aa55d5502b9e0](https://www.virustotal.com/gui/file/5024e86b00012a202d6aa55d5502b9e0)|Win32 EXE|PlugX|2019-09-15 22:07:06|ymhar|
|[03fa06ac91685e0df4c635339e297e04](https://www.virustotal.com/gui/file/03fa06ac91685e0df4c635339e297e04)|Win32 DLL|Ursu|2019-09-12 15:05:32|dttcodexgigas.713c2885e36caa8a5c33d5ca1732cf7a9979bc57|
|[a469f3f7eda824bafb8e569deb05b07d](https://www.virustotal.com/gui/file/a469f3f7eda824bafb8e569deb05b07d)|Win32 EXE|PlugX|2019-08-25 17:20:53|jjhl|
|[a469f3f7eda824bafb8e569deb05b07d](https://www.virustotal.com/gui/file/a469f3f7eda824bafb8e569deb05b07d)|Win32 EXE|PlugX|2019-08-25 17:20:53|jjhl|
|[6303059930cfb785c5cf0af1512b2cbe](https://www.virustotal.com/gui/file/6303059930cfb785c5cf0af1512b2cbe)|Win32 DLL|PlugX|2019-05-09 08:17:08|Olmapi32.dll|
|[baa12a311b9029f33c4fc6de6fde06b0](https://www.virustotal.com/gui/file/baa12a311b9029f33c4fc6de6fde06b0)|Win32 DLL|Ursu|2019-02-18 20:10:01|baa12a311b9029f33c4fc6de6fde06b0.virobj|
|[baa12a311b9029f33c4fc6de6fde06b0](https://www.virustotal.com/gui/file/baa12a311b9029f33c4fc6de6fde06b0)|Win32 DLL|Ursu|2019-02-18 20:10:01|baa12a311b9029f33c4fc6de6fde06b0.virobj|
|[0490e54e4cce81d2ab24a6e7787fa595](https://www.virustotal.com/gui/file/0490e54e4cce81d2ab24a6e7787fa595)|Win32 DLL|Ursu|2019-02-18 19:26:49| |
|[bac7c5528767d86863532bd31bdd12e2](https://www.virustotal.com/gui/file/bac7c5528767d86863532bd31bdd12e2)|Win32 DLL||2019-02-16 00:56:45|jup64.dat.1077934993.DROPPED|
|[bac7c5528767d86863532bd31bdd12e2](https://www.virustotal.com/gui/file/bac7c5528767d86863532bd31bdd12e2)|Win32 DLL||2019-02-16 00:56:45|jup64.dat.1077934993.DROPPED|
|[fa5ca2cba0dab28fa0fb93a9bd7b1d83](https://www.virustotal.com/gui/file/fa5ca2cba0dab28fa0fb93a9bd7b1d83)|Win32 EXE|PlugX|2019-02-15 01:05:04|myfile.exe|
|[fa5ca2cba0dab28fa0fb93a9bd7b1d83](https://www.virustotal.com/gui/file/fa5ca2cba0dab28fa0fb93a9bd7b1d83)|Win32 EXE|PlugX|2019-02-15 01:05:04|myfile.exe|
|[f8da3eab85def2cdedd4227eec3114bb](https://www.virustotal.com/gui/file/f8da3eab85def2cdedd4227eec3114bb)|Win32 EXE|razy|2019-01-28 08:19:51|WinStore.exe|
|[f8da3eab85def2cdedd4227eec3114bb](https://www.virustotal.com/gui/file/f8da3eab85def2cdedd4227eec3114bb)|Win32 EXE|razy|2019-01-28 08:19:51|WinStore.exe|
|[73eb441bcf27a1ee4b1f5c1f78139b3b](https://www.virustotal.com/gui/file/73eb441bcf27a1ee4b1f5c1f78139b3b)|Win32 EXE|MSILPerseus|2019-01-24 17:36:36|.|
|[e223ff5a6a961a6c3ff30811e8a2ceb5](https://www.virustotal.com/gui/file/e223ff5a6a961a6c3ff30811e8a2ceb5)|Win32 EXE||2018-09-24 18:50:41|rav.exe|
|[e223ff5a6a961a6c3ff30811e8a2ceb5](https://www.virustotal.com/gui/file/e223ff5a6a961a6c3ff30811e8a2ceb5)|Win32 EXE||2018-09-24 18:50:41|rav.exe|
|[0464acc5f3ea3d907ab9592cf5af2ff4](https://www.virustotal.com/gui/file/0464acc5f3ea3d907ab9592cf5af2ff4)|Win32 EXE|MSILPerseus|2018-09-24 10:50:44|rav.exe|
|[517c2c6e5e0f27f6f9c759a04a2bf612](https://www.virustotal.com/gui/file/517c2c6e5e0f27f6f9c759a04a2bf612)|Win32 EXE|MSILPerseus|2018-09-24 10:50:18|MicrosoftRuntimeApplication.exe|
|[b3a2e376a9a1f9e4d597eb8509aed57a](https://www.virustotal.com/gui/file/b3a2e376a9a1f9e4d597eb8509aed57a)|Win32 EXE|MSILPerseus|2018-09-24 10:46:46|rav.exe|
|[b3a2e376a9a1f9e4d597eb8509aed57a](https://www.virustotal.com/gui/file/b3a2e376a9a1f9e4d597eb8509aed57a)|Win32 EXE|MSILPerseus|2018-09-24 10:46:46|rav.exe|
|[c69cd5894bdf4c92fcfb324e7db83ce3](https://www.virustotal.com/gui/file/c69cd5894bdf4c92fcfb324e7db83ce3)|Win32 EXE||2018-07-16 10:53:17|rav.exe|
|[c69cd5894bdf4c92fcfb324e7db83ce3](https://www.virustotal.com/gui/file/c69cd5894bdf4c92fcfb324e7db83ce3)|Win32 EXE||2018-07-16 10:53:17|rav.exe|
|[320e29f867ae579a9db0d04e998e5459](https://www.virustotal.com/gui/file/320e29f867ae579a9db0d04e998e5459)|Win32 DLL|Zbot|2018-04-28 21:31:53|aflup64.dll|
|[af501dfd35e7d04afd42d9178601a143](https://www.virustotal.com/gui/file/af501dfd35e7d04afd42d9178601a143)|Win32 DLL|PlugX|2018-01-19 11:38:05|99fe4b62800f1c2f_libvlc.dll|
|[af501dfd35e7d04afd42d9178601a143](https://www.virustotal.com/gui/file/af501dfd35e7d04afd42d9178601a143)|Win32 DLL|PlugX|2018-01-19 11:38:05|99fe4b62800f1c2f_libvlc.dll|
|[851ea11fa3cf5ca859dacf47d066d6df](https://www.virustotal.com/gui/file/851ea11fa3cf5ca859dacf47d066d6df)|Win32 EXE|Ursu|2018-01-19 11:37:58|Microsoft.exe|
|[8b2b4bed6db31739686531d11c9e98aa](https://www.virustotal.com/gui/file/8b2b4bed6db31739686531d11c9e98aa)|Win32 EXE|shelma|2018-01-19 11:37:49|Mosque Calender 2018.exe|
|[b4db105c90d2f2659fd4e930e0b7ad5b](https://www.virustotal.com/gui/file/b4db105c90d2f2659fd4e930e0b7ad5b)|Win32 EXE||2017-09-29 16:26:17|b4db105c90d2f2659fd4e930e0b7ad5b|
|[b4db105c90d2f2659fd4e930e0b7ad5b](https://www.virustotal.com/gui/file/b4db105c90d2f2659fd4e930e0b7ad5b)|Win32 EXE||2017-09-29 16:26:17|b4db105c90d2f2659fd4e930e0b7ad5b|
|[b5c1b0137181cf818a46126ca613365e](https://www.virustotal.com/gui/file/b5c1b0137181cf818a46126ca613365e)|Win32 EXE|PlugX|2016-09-11 19:52:01|b5c1b0137181cf818a46126ca613365e.virus|
|[b5c1b0137181cf818a46126ca613365e](https://www.virustotal.com/gui/file/b5c1b0137181cf818a46126ca613365e)|Win32 EXE|PlugX|2016-09-11 19:52:01|b5c1b0137181cf818a46126ca613365e.virus|
|[b692a0f56d2462ba0ec50374c653b6e8](https://www.virustotal.com/gui/file/b692a0f56d2462ba0ec50374c653b6e8)|Win32 EXE|dynamer|2016-05-16 19:52:42|VirusShare_e4a12a6b30ae5ebf8e9256bb758dfac8|
|[b692a0f56d2462ba0ec50374c653b6e8](https://www.virustotal.com/gui/file/b692a0f56d2462ba0ec50374c653b6e8)|Win32 EXE|dynamer|2016-05-16 19:52:42|VirusShare_e4a12a6b30ae5ebf8e9256bb758dfac8|
|[b3286791b22f515ab8d7f8866a154e9c](https://www.virustotal.com/gui/file/b3286791b22f515ab8d7f8866a154e9c)|Win32 EXE|dynamer|2016-05-16 17:29:12|VirusShare_b22182053b0322f0fe31fab5a49239fb|
|[b3286791b22f515ab8d7f8866a154e9c](https://www.virustotal.com/gui/file/b3286791b22f515ab8d7f8866a154e9c)|Win32 EXE|dynamer|2016-05-16 17:29:12|VirusShare_b22182053b0322f0fe31fab5a49239fb|
|[423dbab9d632a1fc318f66dfc370ac28](https://www.virustotal.com/gui/file/423dbab9d632a1fc318f66dfc370ac28)|Win32 EXE|Ursu|2016-05-16 06:58:18|VirusShare_151fbd6a20a9954fbf72f79b3dbd5ec6|
