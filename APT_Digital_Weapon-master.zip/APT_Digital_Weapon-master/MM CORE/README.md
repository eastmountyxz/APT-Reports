**NAME:**  
MM CORE  

**Description**:   
MM Core is a file-less Trojan discovered by FireEye in 2013 and typically used by APT actors to collect information from the infected device and establish a backdoor for remote access.

**References**:  
https://www.cyber.nj.gov/threat-profiles/trojan-variants/mm-core