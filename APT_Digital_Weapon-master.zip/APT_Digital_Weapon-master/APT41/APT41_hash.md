|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d898f22ca7b36c18103138227e1d52b8](https://www.virustotal.com/gui/file/d898f22ca7b36c18103138227e1d52b8)|Win64 DLL||2019-12-06 22:34:24|d77bee3ac8b5e9120dc89ec922b40440e39ecb26428e662c533c58a901506a20.sample|
|[f71198ff68979d356d0777f6e6336baa](https://www.virustotal.com/gui/file/f71198ff68979d356d0777f6e6336baa)|Win64 DLL||2019-12-06 22:34:20|bb4d326e5f6fc24fc9359c255f77b543f74838799a07f5774bed70e3e878d60b.sample|
|[849ab91e93116ae420d2fe2136d24a87](https://www.virustotal.com/gui/file/849ab91e93116ae420d2fe2136d24a87)|Win64 DLL|winnti|2019-08-07 17:00:02|7cd17fc948eb5fa398b8554fea036bdb3c0045880e03acbe532f4082c271e3c5.bin|
|[04fb0ccf3ef309b1cd587f609ab0e81e](https://www.virustotal.com/gui/file/04fb0ccf3ef309b1cd587f609ab0e81e)|Win32 EXE||2019-04-26 17:30:07| |
|[ee5b707249c562dc916b125e32950c8d](https://www.virustotal.com/gui/file/ee5b707249c562dc916b125e32950c8d)|Win64 DLL||2019-03-28 03:13:27|PatchWrapPS|
|[650a3dce1380f9194361e0c7be9ffb97](https://www.virustotal.com/gui/file/650a3dce1380f9194361e0c7be9ffb97)|Win64 DLL|winnti|2019-03-28 02:36:24|PatchWrapPS|
|[64e09cf2894d6e5ac50207edff787ed7](https://www.virustotal.com/gui/file/64e09cf2894d6e5ac50207edff787ed7)|Win64 DLL||2019-03-27 08:10:19|PatchWrapPS|
|[ffd0f34739c1568797891b9961111464](https://www.virustotal.com/gui/file/ffd0f34739c1568797891b9961111464)|Win64 DLL||2019-03-27 07:49:10|ma_lockdown_service.dll|
|[7dc6bbc202e039dd989e1e2a93d2ec2d](https://www.virustotal.com/gui/file/7dc6bbc202e039dd989e1e2a93d2ec2d)|Win64 DLL||2019-02-12 06:43:36|TSMSISrv.DLL|
|[d49c186b1bfd7c9233e5815c2572eb98](https://www.virustotal.com/gui/file/d49c186b1bfd7c9233e5815c2572eb98)|Win64 DLL||2019-02-12 06:37:04|TSMSISrv.DLL|
|[ff8d92dfbcda572ef97c142017eec658](https://www.virustotal.com/gui/file/ff8d92dfbcda572ef97c142017eec658)|Win64 DLL|razy|2019-02-12 05:04:48|TSMSISrv.DLL|
|[a919b4454679ef60b39c82bd686ed141](https://www.virustotal.com/gui/file/a919b4454679ef60b39c82bd686ed141)|unknown||2019-01-15 16:32:12|F64.data|
|[846cdb921841ac671c86350d494abf9c](https://www.virustotal.com/gui/file/846cdb921841ac671c86350d494abf9c)|Win64 EXE||2019-01-10 05:38:23|C64.exe|
|[8d3b3d5b68a1d08485773d70c186d877](https://www.virustotal.com/gui/file/8d3b3d5b68a1d08485773d70c186d877)|ELF executable||2018-12-04 01:32:49|mtlserver|
|[b0877494d36fab1f9f4219c3defbfb19](https://www.virustotal.com/gui/file/b0877494d36fab1f9f4219c3defbfb19)|Win64 DLL|razy|2018-11-28 10:10:46|TSMSISrv.DLL|
|[e42555b218248d1a2ba92c1532ef6786](https://www.virustotal.com/gui/file/e42555b218248d1a2ba92c1532ef6786)|Win64 EXE||2018-11-27 11:52:32| |
|[557ff68798c71652db8a85596a4bab72](https://www.virustotal.com/gui/file/557ff68798c71652db8a85596a4bab72)|Win64 DLL||2018-11-23 09:32:25|TSMSISrv.DLL|
|[37e100dd8b2ad8b301b130c2bca3f1ea](https://www.virustotal.com/gui/file/37e100dd8b2ad8b301b130c2bca3f1ea)|Win64 DLL|razy|2018-11-22 14:52:56|TSMSISrv.DLL|
|[e58d4072c56a5dd3cc5cf768b8f37e5e](https://www.virustotal.com/gui/file/e58d4072c56a5dd3cc5cf768b8f37e5e)|unknown||2018-11-22 13:55:01|racsvc.dll.mui|
|[48e00515cfad7f1ffb45982a8d190648](https://www.virustotal.com/gui/file/48e00515cfad7f1ffb45982a8d190648)|Win64 EXE||2017-10-20 18:19:32|web1.exe|
|[11c476c7db48f1b02ecc5ae93f63e46d](https://www.virustotal.com/gui/file/11c476c7db48f1b02ecc5ae93f63e46d)|Win32 EXE|winnti|2017-08-15 12:07:02|300519fa1af5c36371ab438405eb641f184bd2f491bdf24f04e5ca9b86d1b39c.exe|
|[334cc0be79082859cfb7f3913c761da1](https://www.virustotal.com/gui/file/334cc0be79082859cfb7f3913c761da1)|Win32 EXE|winnti|2017-08-14 18:07:32|config.exe|
|[97363d50a279492fda14cbab53429e75](https://www.virustotal.com/gui/file/97363d50a279492fda14cbab53429e75)|Win32 DLL||2017-07-18 03:59:42|nssock|
|[84d6e4ba1f4268e50810dacc7bbc3935](https://www.virustotal.com/gui/file/84d6e4ba1f4268e50810dacc7bbc3935)|Text||2016-09-28 09:40:39| |
|[ba08b593250c3ca5c13f56e2ca97d85e](https://www.virustotal.com/gui/file/ba08b593250c3ca5c13f56e2ca97d85e)|Win64 EXE|winnti|2016-09-13 14:02:06| |
|[830a09ff05eac9a5f42897ba5176a36a](https://www.virustotal.com/gui/file/830a09ff05eac9a5f42897ba5176a36a)|Win32 EXE||2016-08-21 20:40:27|BARLAIY-70c03ce5c80aca2d35a5555b0532eedede24d4cc6bdb32a2c8f7e630bba5f26e|
|[5e87b09f9a3f1b728c9797560a38764b](https://www.virustotal.com/gui/file/5e87b09f9a3f1b728c9797560a38764b)|7ZIP|Zxshell|2015-06-19 07:22:18|=?utf-8?B?5Lit5p2x5ZG85ZC45Zmo55eH5YCZ576kKE1FUlMp44Gu5LqI6ZiyLjd6?=|
|[f8c89ccd8937f2b760e6706738210744](https://www.virustotal.com/gui/file/f8c89ccd8937f2b760e6706738210744)|Win64 DLL|winnti|2014-12-01 17:47:29|C:\Analysis\_Baddies\_Dirty\InterMune\Winnti Samples\f8c89ccd8937f2b760e6706738210744.f3c222606f890573e6128fbeb389f37bd6f6bda3.primary_analysis_subject|
|[77c60e5d2d99c3f63f2aea1773ed4653](https://www.virustotal.com/gui/file/77c60e5d2d99c3f63f2aea1773ed4653)|Win64 DLL|winnti|2012-05-17 09:51:06|7566558469ede04efc665212b45786a730055770f6ea8f924d8c1e324cae8691.vir|
|[7d51ea0230d4692eeedc2d5a4cd66d2d](https://www.virustotal.com/gui/file/7d51ea0230d4692eeedc2d5a4cd66d2d)|Win64 EXE|winnti|2012-04-23 10:42:24|63e8ed9692810d562adb80f27bb1aeaf48849e468bf5fd157bc83ca83139b6d7.bin|
|[36711896cfeb67f599305b590f195aec](https://www.virustotal.com/gui/file/36711896cfeb67f599305b590f195aec)|Win32 DLL|winnti|2012-04-16 06:22:28|490c3e4af829e85751a44d21b25de1781cfe4961afdef6bb5759d9451f530994.bin|
|[a0a96138b57ee24eed31b652ddf60d4e](https://www.virustotal.com/gui/file/a0a96138b57ee24eed31b652ddf60d4e)|Win32 DLL|winnti|2012-03-23 06:20:12|79190925bd1c3fae65b0d11db40ac8e61fb9326ccfed9b7e09084b891089602d.bin|
|[659bd19b562059f3f0cc978e15624fd9](https://www.virustotal.com/gui/file/659bd19b562059f3f0cc978e15624fd9)|unknown||2020-05-22 18:08:19| |
|[c0c467c8e9b2046d7053642cc9bdd57d](https://www.virustotal.com/gui/file/c0c467c8e9b2046d7053642cc9bdd57d)|TXT||2020-03-09 21:48:12|56544329|
|[3e856162c36b532925c8226b4ed3481c](https://www.virustotal.com/gui/file/3e856162c36b532925c8226b4ed3481c)|Win32 EXE||2020-03-09 15:02:57|./KISA_dataset_2020_train/d854f775ab1071eebadc0eb44d8571c387567c233a71d2e26242cd9a80e67309.vir|
|[5909983db4d9023e4098e56361c96a6f](https://www.virustotal.com/gui/file/5909983db4d9023e4098e56361c96a6f)|Win64 DLL||2020-03-09 13:47:20|./KISA_dataset_2020_train/f91f2a7e1944734371562f18b066f193605e07223aab90bd1e8925e23bbeaa1c.vir|
|[7966c2c546b71e800397a67f942858d0](https://www.virustotal.com/gui/file/7966c2c546b71e800397a67f942858d0)|TXT||2020-03-09 12:39:51|de9ef08a148305963accb8a64eb22117916aa42ab0eddf60ccb8850468a194fc.bin|
|[c33754d068954ec9a61cc9165334a57e](https://www.virustotal.com/gui/file/c33754d068954ec9a61cc9165334a57e)|ELF executable|Omni|2020-02-03 18:14:09|bsd2|
|[6edb5def1d82d09bf827d85cb42ab07e](https://www.virustotal.com/gui/file/6edb5def1d82d09bf827d85cb42ab07e)|ELF executable|Omni|2020-02-03 18:13:00|bsd|
|[c4471e977dcce55f05da188406d38da7](https://www.virustotal.com/gui/file/c4471e977dcce55f05da188406d38da7)|ELF executable||2019-08-19 01:57:39|autoipv6|
|[382e1eb5eb4028584e802420612977cb](https://www.virustotal.com/gui/file/382e1eb5eb4028584e802420612977cb)|Android||2019-02-28 08:37:25|GPS_TEST.apk|
|[2079d0dd8d4039e3ac1de00bfffe9cd9](https://www.virustotal.com/gui/file/2079d0dd8d4039e3ac1de00bfffe9cd9)|Win32 EXE||2018-10-15 12:24:12|lancer.exe|
|[4906401f2d80465732073771f2fc4dbf](https://www.virustotal.com/gui/file/4906401f2d80465732073771f2fc4dbf)|Win32 EXE||2018-10-12 03:10:40|OnLineTestBox.exe|
|[f7062294fd3132d52a7dda63d92fd4e4](https://www.virustotal.com/gui/file/f7062294fd3132d52a7dda63d92fd4e4)|ELF object file||2018-03-21 07:52:22|d29254ab907c9ef54349de3ec0dd8b22b4692c58ed7a7b340afbc6e44363f96a.bin|
|[d88f2fda2b22d363207264ccb2c3bc08](https://www.virustotal.com/gui/file/d88f2fda2b22d363207264ccb2c3bc08)|ELF executable|Tsunami|2018-02-23 10:02:20|08f29e234f0ce3bded1771d702f8b5963b144141727e48b8a0594f58317aac75.bin|
|[ea78869555018cdab3699e2df5d7e7f8](https://www.virustotal.com/gui/file/ea78869555018cdab3699e2df5d7e7f8)|ELF executable|Omni|2017-12-23 01:17:37|python26|
|[dfd2cf91627783e7128c373e91c089f3](https://www.virustotal.com/gui/file/dfd2cf91627783e7128c373e91c089f3)|Android|androidos|2016-05-20 17:29:39|64424a7c5f0d8e1c5d64c4c6fa9bdc2987dbdcf1bafdb6f45df9e783712c5187.bin|
|[87370de697847a69a9a90ba567c10f9e](https://www.virustotal.com/gui/file/87370de697847a69a9a90ba567c10f9e)|ELF executable||2015-12-10 17:06:47|dhcp.xxx|
|[27fde2d6dbd43dedd5909747faab40d6](https://www.virustotal.com/gui/file/27fde2d6dbd43dedd5909747faab40d6)|ELF object file||2015-07-27 09:47:12|ipmi_devintf.ko|
