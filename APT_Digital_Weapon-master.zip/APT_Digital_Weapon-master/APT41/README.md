**NAME:**  
APT41  
  
**Description**:   
APT41, active since as early as 2012, is reported to carry out espionage activities sponsored by Chinese government. It has financial motivations as well and has been observed targeting healthcare, telecom, technology, and video game industries in 14 countries.
  
**References**:  
https://www.fireeye.com/blog/threat-research/2019/08/apt41-dual-espionage-and-cyber-crime-operation.html