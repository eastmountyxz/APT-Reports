**NAME:**  
APT17  
  
**Alias**  
Aurora Panda, APT 17, Deputy Dog, Group 8, Hidden Lynx, Tailgater Team, Axiom, Winnti Group, Group 72, Group72, Tailgater, Ragebeast, Blackfly, Lead, Wicked Spider, APT 17, Dogfish, Wicked Panda, Barium, APT17  
  
**Description**:   
  APT17 is said to be a China-based threat group that has conducted network intrusions against U.S. government entities, the defense industry, law firms, information technology companies, mining companies, and non-government organizations.

**References**:  
http://www.fireeye.com/blog/technical/cyber-exploits/2013/09/operation-deputydog-zero-day-cve-2013-3893-attack-against-japanese-targets.html
http://www.symantec.com/content/en/us/enterprise/media/security_response/whitepapers/hidden_lynx.pdf
https://www2.fireeye.com/rs/fireye/images/APT17_Report.pdf
