**NAME:**  
APT3  
  
**Alias**  
UPS, Gothic Panda, TG-0110, Group 6, UPS Team, APT 3, Buckeye, Pirpi, Threat Group-0110, APT3  
  
**Description**: 
It is reported that APT3 has traditionally targeted a wide-range of companies and technologies, likely to fulfill intelligence collection requirements on behalf of the MSS. This group is responsible for the campaigns known as Operation Clandestine Fox, Operation Clandestine Wolf, and Operation Double Tap.  
  
**References**:  
https://www.fireeye.com/blog/threat-research/2015/06/operation-clandestine-wolf-adobe-flash-zero-day.html  
https://www.fireeye.com/blog/threat-research/2014/11/operation_doubletap.html