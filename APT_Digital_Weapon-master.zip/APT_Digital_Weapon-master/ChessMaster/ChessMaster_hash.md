|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d68272ad1a13dd2ad5e0bcd29cdef637](https://www.virustotal.com/gui/file/d68272ad1a13dd2ad5e0bcd29cdef637)|Win32 DLL||2018-07-02 02:53:58|d68272ad1a13dd2ad5e0bcd29cdef637.vir|
|[868bae53ff5ba6f909bb32ae54377b2f](https://www.virustotal.com/gui/file/868bae53ff5ba6f909bb32ae54377b2f)|unknown||2018-01-30 05:47:25|myvtfile.exe|
|[1ee6f8b5153b4c8c95f9b5dd0194ad14](https://www.virustotal.com/gui/file/1ee6f8b5153b4c8c95f9b5dd0194ad14)|DOCX|CVE-2017-11882|2018-01-18 04:58:25|=?UTF-8?B?44CQ5b+F6KaB6YOo5pWw44Gu6Kq/5p+744CR5YWa5ZOh44G444Gu6YWN5biD55So44CO44Od44K544K/44O85Z6L44Kr44Os44Oz44OA44O877yI5bmz5oiQMzDlubTvvInjgI8uZG9jeA==?=|
|[b275ca64935ae5cfe7bea5fa7f53bdd2](https://www.virustotal.com/gui/file/b275ca64935ae5cfe7bea5fa7f53bdd2)|Win32 EXE|Gandcrab|2017-11-10 04:48:09|myfile.exe|
|[c4881f4e315ec531c57e5e3d2a274a9d](https://www.virustotal.com/gui/file/c4881f4e315ec531c57e5e3d2a274a9d)|FPX||2017-11-02 02:40:43|「日米対話」非公開会議 報告.msg|
