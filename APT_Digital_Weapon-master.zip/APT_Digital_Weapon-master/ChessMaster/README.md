**NAME:**  
ChessMaster  

**Description**:   
A campaign targeting Japanese academe, technology enterprises, media outfits, managed service providers, and government agencies. It employs various poisoned pawns in the form of malware-laden spear-phishing emails containing decoy documents.  


**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/chessmaster-cyber-espionage-campaign/