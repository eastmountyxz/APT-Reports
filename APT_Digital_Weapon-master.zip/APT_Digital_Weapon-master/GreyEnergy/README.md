**NAME:**  
GreyEnergy  

**Description**:   
GreyEnergy, named by ESET, exhibits many conceptual similarities with BlackEnergy. It is an important part of the arsenal of one of the most dangerous APT groups that has been terrorizing Ukraine for the past several years, and is deemed as the successor of the BlackEnergy toolkit. There are links that suggest the group behind GreyEnergy has been working together with the TeleBots group, known in connection with many destructive attacks.
  
**References**:  
https://www.welivesecurity.com/2018/10/17/greyenergy-updated-arsenal-dangerous-threat-actors/  
https://www.welivesecurity.com/wp-content/uploads/2018/10/ESET_GreyEnergy.pdf  
https://github.com/eset/malware-ioc/tree/master/greyenergy  
