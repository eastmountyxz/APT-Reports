|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[ca2a53ad706fe27bdb37f23a6cbd0d73](https://www.virustotal.com/gui/file/ca2a53ad706fe27bdb37f23a6cbd0d73)|Win32 EXE|Emotet|2019-01-21 15:54:26|c:\windows\winexesvc.exe|
|[8080acc8e13079998851e60217544397](https://www.virustotal.com/gui/file/8080acc8e13079998851e60217544397)|Win32 DLL||2019-01-07 20:25:27|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/module.1620.3e25bb98.58d10000.dll.bin|
|[9f5309b5960b00f9dc75c6d544b454d2](https://www.virustotal.com/gui/file/9f5309b5960b00f9dc75c6d544b454d2)|Win32 DLL||2018-10-24 00:07:40|WSTDECOD|
|[446d226cedf08866dbe528868cba2007](https://www.virustotal.com/gui/file/446d226cedf08866dbe528868cba2007)|Win32 EXE||2018-10-18 10:41:40|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergyDropper2.bin|
|[815a60e33e51b713bd37431c98d34bc5](https://www.virustotal.com/gui/file/815a60e33e51b713bd37431c98d34bc5)|DOS EXE|Zbot|2018-10-16 17:25:23|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergyImplant2018.bin|
|[78734cd268e5c9ab4184e1bbe21a6eb9](https://www.virustotal.com/gui/file/78734cd268e5c9ab4184e1bbe21a6eb9)|Win32 EXE|FELIXROOT|2018-07-29 15:12:54|78734cd268e5c9ab4184e1bbe21a6eb9.virus|
|[4de5adb865b5198b4f2593ad436fceff](https://www.virustotal.com/gui/file/4de5adb865b5198b4f2593ad436fceff)|RTF|CVE-2017-11882|2018-07-06 11:33:28|4de5adb865b5198b4f2593ad436fceff.virus|
|[1cb35f4340a37e75aff1f901629b59f3](https://www.virustotal.com/gui/file/1cb35f4340a37e75aff1f901629b59f3)|Win32 EXE|FELIXROOT|2018-06-21 17:46:05|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergymini.bin|
|[92f63b1227a6b37335495f9bcb939ea2](https://www.virustotal.com/gui/file/92f63b1227a6b37335495f9bcb939ea2)|Win32 DLL|FELIXROOT|2018-06-21 12:05:37|WSTDECOD|
|[11227eca89cc053fb189fac3ebf27497](https://www.virustotal.com/gui/file/11227eca89cc053fb189fac3ebf27497)|RTF|CVE-2017-0199|2018-06-21 06:08:14|11227eca89cc053fb189fac3ebf27497.virus|
|[21ddf41d3de484da579d97e86a5df02d](https://www.virustotal.com/gui/file/21ddf41d3de484da579d97e86a5df02d)|RTF|CVE-2017-11882|2018-06-04 08:50:32|Artykul.rtf.bin|
|[a541295eca38eaa4fde122468d633083](https://www.virustotal.com/gui/file/a541295eca38eaa4fde122468d633083)|RTF|CVE-2017-11882|2018-05-30 04:16:29|Seminar.rtf|
|[0ee32e77be711eca116c9910228773a9](https://www.virustotal.com/gui/file/0ee32e77be711eca116c9910228773a9)|Win64 EXE||2018-03-16 10:00:58|winexesvc.exe|
|[5865fa4ed2a15381eb21160049793df5](https://www.virustotal.com/gui/file/5865fa4ed2a15381eb21160049793df5)|PHP||2018-02-10 09:40:38|ajax.php|
|[462ed68d9de5db6785307be9640c6229](https://www.virustotal.com/gui/file/462ed68d9de5db6785307be9640c6229)|PHP||2018-02-08 08:30:17|audio.php|
|[b590277f0e9ad91dd743d5be29de541b](https://www.virustotal.com/gui/file/b590277f0e9ad91dd743d5be29de541b)|Win32 EXE||2018-01-15 18:22:17|winexesvc.exe|
|[275f821b328c06a2ef7b5ebb22af9cb6](https://www.virustotal.com/gui/file/275f821b328c06a2ef7b5ebb22af9cb6)|Win32 DLL|zapchast|2017-12-29 04:36:38|Telephony Service|
|[73676711f838906a9a64e6528e0481f6](https://www.virustotal.com/gui/file/73676711f838906a9a64e6528e0481f6)|Win32 EXE||2017-09-15 15:01:15|myfile.exe|
|[e3a2c3a025d1aee589026d09e2a0ca50](https://www.virustotal.com/gui/file/e3a2c3a025d1aee589026d09e2a0ca50)|DOCM|o97m|2017-09-13 12:24:40|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergyDropper.doc|
|[0b67e662d2fd348b5360ecac6943d69c](https://www.virustotal.com/gui/file/0b67e662d2fd348b5360ecac6943d69c)|Win64 EXE||2017-04-18 22:00:08|myfile.exe|
|[cd5eadaeba08af4b61de06c080790b40](https://www.virustotal.com/gui/file/cd5eadaeba08af4b61de06c080790b40)|Win32 EXE||2017-01-19 05:47:15|854e63d079bf78f779c8254b99ef0f54de2b3c931476d6657e28f626b8c058a6.bin|
|[cc2c79933a0b80df29a8a0cc6058da50](https://www.virustotal.com/gui/file/cc2c79933a0b80df29a8a0cc6058da50)|Win64 EXE||2017-01-17 17:06:06|winexesvc.exe|
|[5525af1a03e3ae4fc75e4f5c1d66e07a](https://www.virustotal.com/gui/file/5525af1a03e3ae4fc75e4f5c1d66e07a)|Win64 EXE||2016-12-08 10:21:19|winexesvc3.exe|
|[e420d6e25bc6a01216de80237460f565](https://www.virustotal.com/gui/file/e420d6e25bc6a01216de80237460f565)|Win32 DLL||2016-10-28 16:21:32|e420d6e25bc6a01216de80237460f565_blQaCD.DlL|
|[5f58059d894e8aaf58b2da6be6f97aa8](https://www.virustotal.com/gui/file/5f58059d894e8aaf58b2da6be6f97aa8)|Win32 DLL||2016-10-24 09:16:58|5f58059d894e8aaf58b2da6be6f97aa8_uaaWldsyQgAwtTpDssi.DlL|
|[16bb9def4fabfa2ccb3efc1ca5bfc2fa](https://www.virustotal.com/gui/file/16bb9def4fabfa2ccb3efc1ca5bfc2fa)|Win32 DLL||2016-10-19 08:18:42|myfile.exe|
|[224c2d888bce0c3d19fbef41cb20b45a](https://www.virustotal.com/gui/file/224c2d888bce0c3d19fbef41cb20b45a)|Win32 DLL||2016-10-18 09:29:53|224c2d888bce0c3d19fbef41cb20b45a_SckhPIHOrPJbaBB.DLl|
|[7552b4c677048caeb0112d9b8225459b](https://www.virustotal.com/gui/file/7552b4c677048caeb0112d9b8225459b)|Win32 DLL||2016-10-17 13:32:51|ssdpsrv.dll|
|[c9d46876d5ab346e8921973b719aff58](https://www.virustotal.com/gui/file/c9d46876d5ab346e8921973b719aff58)|Win32 DLL||2016-10-17 07:36:39|c9d46876d5ab346e8921973b719aff58_NMtxAmIisGt.dLL|
|[549ace2711a324a977be83887f10ed9c](https://www.virustotal.com/gui/file/549ace2711a324a977be83887f10ed9c)|Win32 DLL||2016-10-15 09:58:27|WIASERVC|
|[6826a2cb61b501a086c8997a5f786c25](https://www.virustotal.com/gui/file/6826a2cb61b501a086c8997a5f786c25)|Win64 EXE||2016-09-17 07:04:26|winexesvc.exe|
|[2bff6b87ee4b4d1d4f9468939797e8a9](https://www.virustotal.com/gui/file/2bff6b87ee4b4d1d4f9468939797e8a9)|Win32 DLL||2015-11-27 12:11:48|2bff6b87ee4b4d1d4f9468939797e8a9_mSDAVHhTBkzlhgqauQp.dll|
|[6ede63d6f216affbb57a26200fd31608](https://www.virustotal.com/gui/file/6ede63d6f216affbb57a26200fd31608)|Win32 DLL||2015-11-27 11:28:31|ALRSVC.DLL|
|[bb67537d0f6103c009f1450f19951042](https://www.virustotal.com/gui/file/bb67537d0f6103c009f1450f19951042)|Win32 EXE||2015-11-10 14:26:40|winexesvc.exe|
|[7a7103a5fc1cf7c4b6eef1a6935554b7](https://www.virustotal.com/gui/file/7a7103a5fc1cf7c4b6eef1a6935554b7)|Win32 EXE||2015-09-10 12:20:07|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergyDropper.bin|
