**NAME:**  
KONNI  
  
**Alias**  
Nokki, Moneyholic, KONNI  
  
**Description**:   
KONNI is a malware captured and named by Talos, related activities could trace back to as early as 2014. Related victims are members of official organizations such as United Nations, UNICEF, and Embassies linked to North Korea.  
  
**References**:  
https://blog.talosintelligence.com/2017/05/konni-malware-under-radar-for-years.html
