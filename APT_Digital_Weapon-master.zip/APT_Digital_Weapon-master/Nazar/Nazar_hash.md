|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[eb33d9c2289030d1e3e53580f355ae9e](https://www.virustotal.com/gui/file/eb33d9c2289030d1e3e53580f355ae9e)|Win32 DLL||2018-12-19 11:14:54|./KISA_dataset_2020_train/8fb9a22b20a338d90c7ceb9424d079a61ca7ccb7f78ffb7d74d2f403ae9fbeec.vir|
|[8dcbe6a13da094afe5ed5978c1fb9e5e](https://www.virustotal.com/gui/file/8dcbe6a13da094afe5ed5978c1fb9e5e)|Win32 DLL||2018-12-10 20:45:10|0091e2101f00751c4020ef8e115cfe12a284c9abacc886f549b40a62574a7510.bin|
|[de3e24f150510b7857cdfe9306a7d187](https://www.virustotal.com/gui/file/de3e24f150510b7857cdfe9306a7d187)|Win32 DLL|Ursu|2017-08-20 05:26:39|Filesystem|
|[53e64335a7c265e97b80e2592d647417](https://www.virustotal.com/gui/file/53e64335a7c265e97b80e2592d647417)|Win32 EXE||2013-05-15 09:59:17|./KISA_dataset_2020_train/d34a996826ea5a028f5b4713c797247913f036ca0063cc4c18d8b04736fa0b65.vir|
|[61dfd8e9d0df201d9e74adbfcd35516f](https://www.virustotal.com/gui/file/61dfd8e9d0df201d9e74adbfcd35516f)|Win32 EXE|Razy|2013-02-04 08:43:33|./KISA_dataset_2020_train/d9801b4da1dbc5264e83029abb93e800d3c9971c650ecc2df5f85bcc10c7bd61.vir|
|[c1ab32afb0e2d7b7b1cad3fb831e9373](https://www.virustotal.com/gui/file/c1ab32afb0e2d7b7b1cad3fb831e9373)|Win32 EXE|Zapchast|2013-02-04 04:26:29|%TEMP%\ckz_xhff\distribute.exe|
|[6b3116580d29020b9c259877ac18a7fd](https://www.virustotal.com/gui/file/6b3116580d29020b9c259877ac18a7fd)|Win32 EXE||2013-02-04 04:23:00|./KISA_dataset_2020_train/4d0ab3951df93589a874192569cac88f7107f595600e274f52e2b75f68593bca.vir|
|[01ac5016624191163b0201d57d1c104b](https://www.virustotal.com/gui/file/01ac5016624191163b0201d57d1c104b)|Win32 DLL||2012-07-15 11:36:50|Filesystem|
|[a9ff31c8db6d4e70829bf5db062d1b9c](https://www.virustotal.com/gui/file/a9ff31c8db6d4e70829bf5db062d1b9c)|Win32 EXE||2012-07-15 11:28:45|svchost.exe|
|[86f3f267fd540b212fa7f0d1c6637dea](https://www.virustotal.com/gui/file/86f3f267fd540b212fa7f0d1c6637dea)|Win32 EXE||2011-02-26 10:48:41|./KISA_dataset_2020_train/75e4d73252c753cd8e177820eb261cd72fecd7360cc8ec3feeab7bd129c01ff6.vir|
|[c3dd32551450e15e7e81bb523dba7124](https://www.virustotal.com/gui/file/c3dd32551450e15e7e81bb523dba7124)|Win32 EXE||2011-02-26 10:48:38|./KISA_dataset_2020_train/6b8ea9a156d495ec089710710ce3f4b1e19251c1d0e5b2c21bbeeab05e7b331f.vir|
|[ecc0695b78d43e015bfe630e7ab3d3b6](https://www.virustotal.com/gui/file/ecc0695b78d43e015bfe630e7ab3d3b6)|Win32 DLL||2011-02-26 10:45:58|Godown|
|[497b3103f7c3a2a604817896d8dd7532](https://www.virustotal.com/gui/file/497b3103f7c3a2a604817896d8dd7532)|Win32 EXE||2011-02-26 10:45:51|c:\windows\system32\l8oxdbpi7.dll|
|[ed96cb057e19819dbc79f261d88e6ab4](https://www.virustotal.com/gui/file/ed96cb057e19819dbc79f261d88e6ab4)|Win32 DLL||2011-02-26 10:45:49|%WINDIR%\syswow64\viewscreen.dll|
|[ce54a3a42a67d3e02e2d245d60611052](https://www.virustotal.com/gui/file/ce54a3a42a67d3e02e2d245d60611052)|Win32 DLL||2011-02-26 10:45:34|Filesystem|
|[f489336797003f62e87f58e6a02519dd](https://www.virustotal.com/gui/file/f489336797003f62e87f58e6a02519dd)|Win32 DLL||2011-02-26 10:45:23|%WINDIR%\syswow64\hodll.dll|
|[9edf2e69b2c0a9bfd392a988003b0ec2](https://www.virustotal.com/gui/file/9edf2e69b2c0a9bfd392a988003b0ec2)|Win32 EXE||2011-02-22 11:59:02|./KISA_dataset_2020_train/eb705459c2b37fba5747c73ce4870497aa1d4de22c97aaea4af38cdc899b51d3.vir|
|[0c234a4a2fbab98e5e1bafaf3e3e403a](https://www.virustotal.com/gui/file/0c234a4a2fbab98e5e1bafaf3e3e403a)|Win32 EXE||2009-02-13 15:13:22|pssdk8632.sys|
|[3c0ac9f753dd0c4ad3d46f5f6aa36aa9](https://www.virustotal.com/gui/file/3c0ac9f753dd0c4ad3d46f5f6aa36aa9)|Win32 DLL||2007-04-16 04:03:17|lame_enc.dll|
