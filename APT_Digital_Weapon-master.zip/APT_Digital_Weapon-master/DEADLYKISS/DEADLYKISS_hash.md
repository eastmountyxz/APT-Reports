|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f010b0b7681ede24f96c88670784fc89](https://www.virustotal.com/gui/file/f010b0b7681ede24f96c88670784fc89)|Win32 DLL||2018-12-18 10:37:20|vc_runtime|
|[8f41f09a0b6869ac697e40ceecf47315](https://www.virustotal.com/gui/file/8f41f09a0b6869ac697e40ceecf47315)|Win64 DLL||2016-10-25 20:23:31|mzuad|
|[608f3f7f117daf1dc9378c4f56d5946f](https://www.virustotal.com/gui/file/608f3f7f117daf1dc9378c4f56d5946f)|Win32 DLL|dynamer|2016-10-25 20:23:30|mzuad|
|[d9dfc6c75d43fca64cb764cda9d1ce84](https://www.virustotal.com/gui/file/d9dfc6c75d43fca64cb764cda9d1ce84)|Win64 DLL||2016-10-13 20:13:54|mzuad|
|[9c41ab80f6a969dbf7274acbc0176b76](https://www.virustotal.com/gui/file/9c41ab80f6a969dbf7274acbc0176b76)|Win32 DLL|dynamer|2016-04-16 22:03:30|mssql60|
