**NAME:**  
DEADLYKISS  

**Description**:   
DeadlyKiss, named by Telsy Cyber Threat Intelligence Unit, for expected conjunction of two different modules during its infection chain. The identified targets belong to the world of Internet Service Provider (ISP) and Asian region is the main targets pool.
  
**References**:  
https://blog.telsy.com/wp-content/uploads/2019/09/DeadlyKiss_TAAR.pdf
