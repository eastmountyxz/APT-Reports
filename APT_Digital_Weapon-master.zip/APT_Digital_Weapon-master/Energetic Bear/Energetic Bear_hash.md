|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[122543722bbbeb4cec9ee977157a59da](https://www.virustotal.com/gui/file/122543722bbbeb4cec9ee977157a59da)|Win32 EXE||2018-11-11 12:59:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EnergeticBear/Temp.IsotopeImplant.bin|
|[67b1d64f669eabd6f843a163edeb88a2](https://www.virustotal.com/gui/file/67b1d64f669eabd6f843a163edeb88a2)|Win32 EXE||2018-10-29 14:20:53|wsmprovav.exe|
|[815a60e33e51b713bd37431c98d34bc5](https://www.virustotal.com/gui/file/815a60e33e51b713bd37431c98d34bc5)|DOS EXE|Zbot|2018-10-16 17:25:23|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GreyEnergyAPT/GreyEnergyImplant2018.bin|
|[8aeacf3fde1b49940fb4d08226dccbc4](https://www.virustotal.com/gui/file/8aeacf3fde1b49940fb4d08226dccbc4)|Win32 EXE|injector|2018-08-29 00:12:59| |
|[f7c5d117c91bd22fa17d2d5444ff7ab7](https://www.virustotal.com/gui/file/f7c5d117c91bd22fa17d2d5444ff7ab7)|Win32 EXE|Ursu|2018-07-27 03:03:45|myfile.exe|
|[418e58b78731546089eb1b7fa6e1d99f](https://www.virustotal.com/gui/file/418e58b78731546089eb1b7fa6e1d99f)|Win32 EXE|karagany|2018-06-20 08:29:06|00a1b9fd9af9c5e366ef19908f028e9cca0462ec16adab9763e8c8b017b0f6bc.bin|
|[4ad06a76e1ad423b13e03587a887ede0](https://www.virustotal.com/gui/file/4ad06a76e1ad423b13e03587a887ede0)|Win32 EXE||2018-06-06 16:39:23|4ad06a76e1ad423b13e03587a887ede0.virobj|
|[fff6dc1216fe549fa1d700f1ccfcd754](https://www.virustotal.com/gui/file/fff6dc1216fe549fa1d700f1ccfcd754)|Win32 EXE||2018-06-06 16:38:07|%APPDATA%\intel corporation\iastoricon.exe|
|[f901c645188f9c80afa8f49174f065ce](https://www.virustotal.com/gui/file/f901c645188f9c80afa8f49174f065ce)|Win64 EXE||2018-05-06 13:29:31|myfile.exe|
|[eef5dc4c54e187d14f2e9435a31878d2](https://www.virustotal.com/gui/file/eef5dc4c54e187d14f2e9435a31878d2)|DOCX|groooboor|2017-10-13 15:55:10|eef5dc4c54e187d14f2e9435a31878d2.virus|
|[db07e1740152e09610ea826655d27e8d](https://www.virustotal.com/gui/file/db07e1740152e09610ea826655d27e8d)|Win32 EXE||2017-09-11 16:47:44|screen.exe|
|[da9d8c78efe0c6c8be70e6b857400fb1](https://www.virustotal.com/gui/file/da9d8c78efe0c6c8be70e6b857400fb1)|Win32 EXE|Banload|2017-06-21 03:00:07| |
|[fd6145bbc722ef52eed6b94dd520170c](https://www.virustotal.com/gui/file/fd6145bbc722ef52eed6b94dd520170c)|Win32 EXE|karagany|2017-06-07 19:43:54|pic.exe|
|[fca1fa07afa1b3ff9f67f2a377de51ae](https://www.virustotal.com/gui/file/fca1fa07afa1b3ff9f67f2a377de51ae)|Win32 EXE||2017-05-26 14:44:18|C:\SAMPLES\34095\svchost.exe|
|[20ec7658254eddd917e1b351e1728534](https://www.virustotal.com/gui/file/20ec7658254eddd917e1b351e1728534)|Win32 EXE|Kryptik|2017-05-09 18:17:37|20ec7658254eddd917e1b351e1728534.virus|
|[a4cf567f27f3b2f8b73ae15e2e487f00](https://www.virustotal.com/gui/file/a4cf567f27f3b2f8b73ae15e2e487f00)|Win64 EXE||2017-04-06 08:53:19|a4cf567f27f3b2f8b73ae15e2e487f00_PtaeiMUGMNEaFwm.Exe|
|[e02603178c8c47d198f7d34bcf2d68b8](https://www.virustotal.com/gui/file/e02603178c8c47d198f7d34bcf2d68b8)|Win32 DLL||2016-09-17 21:04:05|~tmp132356.dll|
|[1560f68403c5a41e96b28d3f882de7f1](https://www.virustotal.com/gui/file/1560f68403c5a41e96b28d3f882de7f1)|Win32 EXE|Banload|2016-09-05 18:30:02|1560f68403c5a41e96b28d3f882de7f1_rzsjQCAkYzEvRovdoCDkOaEt.ExE|
|[b3b5d67f5bbf5a043f5bf5d079dbcb56](https://www.virustotal.com/gui/file/b3b5d67f5bbf5a043f5bf5d079dbcb56)|Win32 EXE|rozena|2016-08-05 02:01:00|b3b5d67f5bbf5a043f5bf5d079dbcb56_RGDCKKWmCBLJlNsLeyO.eXE|
|[141e78d16456a072c9697454fc6d5f58](https://www.virustotal.com/gui/file/141e78d16456a072c9697454fc6d5f58)|DOCX||2016-04-28 14:50:11|141e78d16456a072c9697454fc6d5f58_yisHQGSNZD.DoCX|
|[7ec514bbdc6dd8f606f803d39af8883f](https://www.virustotal.com/gui/file/7ec514bbdc6dd8f606f803d39af8883f)|Text||2016-03-18 16:04:16|sma (1).php|
|[c76470e85b7f3da46539b40e5c552712](https://www.virustotal.com/gui/file/c76470e85b7f3da46539b40e5c552712)|PHP||2015-11-20 12:59:14|conf.php|
|[155385cc19e3092765bcfed034b82ccb](https://www.virustotal.com/gui/file/155385cc19e3092765bcfed034b82ccb)|PHP||2015-09-24 06:50:48|error_log|
|[f3e3e25a822012023c6e81b206711865](https://www.virustotal.com/gui/file/f3e3e25a822012023c6e81b206711865)|PHP||2015-03-26 11:04:53|/var/sentora/hostdata/divicun/public_html/divicun_com/wp-content/plugins/wp_module/wp_msg.php|
|[4102f370aaf46629575daffbd5a0b3c9](https://www.virustotal.com/gui/file/4102f370aaf46629575daffbd5a0b3c9)|Win32 DLL||2014-06-23 10:40:22|VTDLEFE9462BFA3564FE031B5FF0F2E4F8DB8EF22882.danger|
|[6bfc42f7cb1364ef0bfd749776ac6d38](https://www.virustotal.com/gui/file/6bfc42f7cb1364ef0bfd749776ac6d38)|Win32 DLL||2014-06-23 10:39:04|db8ed2922ba5f81a4d25edb7331ea8c0f0f349ae.bin|
|[ba8da708b8784afd36c44bb5f1f436bc](https://www.virustotal.com/gui/file/ba8da708b8784afd36c44bb5f1f436bc)|Win32 DLL||2014-06-23 10:38:35|VTDL1C90ECF995A70AF8F1D15E9C355B075B4800B4DE.danger|
|[1d6b11f85debdda27e873662e721289e](https://www.virustotal.com/gui/file/1d6b11f85debdda27e873662e721289e)|Win32 EXE||2014-04-17 20:02:28|mbCHECK|
|[4bfdda1a5f21d56afdc2060b9ce5a170](https://www.virustotal.com/gui/file/4bfdda1a5f21d56afdc2060b9ce5a170)|Win32 EXE|karagany|2013-07-21 05:37:32|AnSoftware|
|[708ceccae2c27e32637fd29451aef4a5](https://www.virustotal.com/gui/file/708ceccae2c27e32637fd29451aef4a5)|Win32 EXE|tspy|2011-09-18 13:05:57|708ceccae2c27e32637fd29451aef4a5|
