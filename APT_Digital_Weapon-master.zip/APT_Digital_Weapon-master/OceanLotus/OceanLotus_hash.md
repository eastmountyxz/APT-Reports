|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[8e2b5b95980cf52e99acfa95f5e1570b](https://www.virustotal.com/gui/file/8e2b5b95980cf52e99acfa95f5e1570b)|Win32 DLL||2019-11-11 15:22:00|C:\Users\<USER>\AppData\Local\Temp\~$doc-ad9b812a-88b2-454c-989f-7bb5fe98717e.ole|
|[3c3b2cc9ff5d7030fb01496510ac75f2](https://www.virustotal.com/gui/file/3c3b2cc9ff5d7030fb01496510ac75f2)|DOC||2019-11-11 11:13:02|?-????2019?????????????????.doc|
|[3a8c80d73f9beebd828c3aa172c747fa](https://www.virustotal.com/gui/file/3a8c80d73f9beebd828c3aa172c747fa)|RAR||2019-11-07 01:23:39|Noi dung don cau cuu.rar|
|[82990e2c0432e579a00ab1f75da0dd65](https://www.virustotal.com/gui/file/82990e2c0432e579a00ab1f75da0dd65)|TXT||2019-10-26 11:05:08|lang.ps1|
|[a87ada040f7250b59910345ee0b339b4](https://www.virustotal.com/gui/file/a87ada040f7250b59910345ee0b339b4)|RAR||2019-10-23 09:20:16|Thu moi.rar|
|[ff99f8bc1ec0d77843b9d5384a422780](https://www.virustotal.com/gui/file/ff99f8bc1ec0d77843b9d5384a422780)|ACE||2019-10-21 23:32:40|CV_NguyenVanA.rar|
|[dbdbcd220475678c4becdc57a9233e20](https://www.virustotal.com/gui/file/dbdbcd220475678c4becdc57a9233e20)|Win32 EXE||2019-10-18 07:28:19|AcroRd32.exe|
|[e7de9a64266f07168def534852349957](https://www.virustotal.com/gui/file/e7de9a64266f07168def534852349957)|RAR|Kryptik|2019-09-16 00:18:57|Don khieu nai.rar|
|[90c66c76095ef1ad5a79e63a544c1bba](https://www.virustotal.com/gui/file/90c66c76095ef1ad5a79e63a544c1bba)|Win32 DLL|Kryptik|2019-09-13 06:02:21|123456|
|[31064883832730d5d0562f403f388d2b](https://www.virustotal.com/gui/file/31064883832730d5d0562f403f388d2b)|Win32 EXE|oceanlotus|2019-09-03 21:41:28|WinWord|
|[10753d568ef33cad858dc8c28d1a8905](https://www.virustotal.com/gui/file/10753d568ef33cad858dc8c28d1a8905)|Win32 DLL|oceanlotus|2019-09-03 13:48:35| |
|[aec52688154ecfbebaa813429d911c2c](https://www.virustotal.com/gui/file/aec52688154ecfbebaa813429d911c2c)|DOC|foretype|2019-08-31 12:59:09| |
|[3662e7a249e328ee7a0b59fe2f9f8d78](https://www.virustotal.com/gui/file/3662e7a249e328ee7a0b59fe2f9f8d78)|Win32 DLL|Ursu|2019-08-26 13:07:29|wwlib.dll|
|[451fcb8c73cb350a38cfa759117a11c0](https://www.virustotal.com/gui/file/451fcb8c73cb350a38cfa759117a11c0)|ACE|CVE-2018-20250|2019-08-22 17:21:44|test.rar|
|[4ddae25966dec1421d53a9b1d0b1c055](https://www.virustotal.com/gui/file/4ddae25966dec1421d53a9b1d0b1c055)|RAR|graftor|2019-08-22 03:42:53|Google_Install.rar|
|[0e84ac6b10b60303fd3c79cb9e181079](https://www.virustotal.com/gui/file/0e84ac6b10b60303fd3c79cb9e181079)|RAR|ursu|2019-08-21 16:04:02|=?UTF-8?B?5bm05bqm5a6h6K6h6YCa55+l5LmmLnJhcg==?=|
|[9eb55481a0b5fcd255c8fb8de1042f88](https://www.virustotal.com/gui/file/9eb55481a0b5fcd255c8fb8de1042f88)|Win32 DLL||2019-08-21 11:58:22|wwlib.dll|
|[9efc7ee0d13642e8aec46d3c2e72e1d5](https://www.virustotal.com/gui/file/9efc7ee0d13642e8aec46d3c2e72e1d5)|RAR|Ursu|2019-08-21 07:39:40|zhangwei.rar|
|[b3b3b0ef59ffe5b1a53499b4dd7ec344](https://www.virustotal.com/gui/file/b3b3b0ef59ffe5b1a53499b4dd7ec344)|Android||2019-08-18 06:23:23|com.sailmedia.supcodec-1.1.3-sameapk.com.apk|
|[5ed9995e8a82e37ee6061555e3dbc686](https://www.virustotal.com/gui/file/5ed9995e8a82e37ee6061555e3dbc686)|Win32 EXE||2019-08-16 03:36:08|=?UTF-8?B?NWVkOTk5NWU4YTgyZTM3ZWU2MDYxNTU1ZTNkYmM2ODZf5YWz5LqO5Y+C5LiO6LSt5Lmw6K6+5aSH5oub5qCH5Zue5Ye9LmV4ZQ==?=|
|[3061f320d47a6c985bd219f5ac14ff8a](https://www.virustotal.com/gui/file/3061f320d47a6c985bd219f5ac14ff8a)|RAR|Kryptik|2019-08-15 18:22:32|=?UTF-8?B?VGjDtG5nIHRpbiBjaOG7pyDEkeG7gSBj4bqnbiB0cmFvIMSR4buVaSB4aW4ga8OtbmggZ+G7rWkgxJHhur9uIFRp4bq/biBzxKkucmFy?=|
|[788989f7f39296eb7016f9c19c74d0ca](https://www.virustotal.com/gui/file/788989f7f39296eb7016f9c19c74d0ca)|RAR|graftor|2019-08-14 09:07:01|Firefox_Install.rar|
|[e3d881a6b4941aca14e2829a303a9476](https://www.virustotal.com/gui/file/e3d881a6b4941aca14e2829a303a9476)|ZIP|Ursu|2019-08-07 14:23:30|nguyenvananh-virus.zip|
|[300ec6bc4d8b00f7f42f0165172b9606](https://www.virustotal.com/gui/file/300ec6bc4d8b00f7f42f0165172b9606)|Android||2019-08-05 10:35:11| |
|[c2b5fa706c1077aeb29cab14c863cc1a](https://www.virustotal.com/gui/file/c2b5fa706c1077aeb29cab14c863cc1a)|Android||2019-08-05 00:53:03| |
|[76023ce8024204eba2ae9eea18e7b0b1](https://www.virustotal.com/gui/file/76023ce8024204eba2ae9eea18e7b0b1)|Win32 EXE||2019-08-03 03:56:28|AcroRd32.exe|
|[4095b9682af13ca1e897ca9cc097ec69](https://www.virustotal.com/gui/file/4095b9682af13ca1e897ca9cc097ec69)|CHM||2019-07-31 01:21:51|32323.chm|
|[d5588e434e0300573f7d93fc447341e7](https://www.virustotal.com/gui/file/d5588e434e0300573f7d93fc447341e7)|unknown||2019-07-28 02:18:07|Wi65CItwiDm53a2.bin|
|[4531cc6f4c730dd92aa289eeba71a850](https://www.virustotal.com/gui/file/4531cc6f4c730dd92aa289eeba71a850)|ZIP|oceanlotus|2019-07-26 13:36:26|FlashUpdate.app.zip|
|[a7c7b68ab26c10e56a85fc09b8c2e497](https://www.virustotal.com/gui/file/a7c7b68ab26c10e56a85fc09b8c2e497)|ACE|CVE-2018-20250|2019-07-24 05:28:38| |
|[dbf9ef06d26ee74d149495a57e0cc086](https://www.virustotal.com/gui/file/dbf9ef06d26ee74d149495a57e0cc086)|Win32 DLL||2019-07-23 08:40:16|\Users\Petra\AppData\Local\Temp\RarSFX0\Wi65CItwiDm53a2.pkg|
|[d87e12458839514f1425243075cfc078](https://www.virustotal.com/gui/file/d87e12458839514f1425243075cfc078)|Win32 EXE||2019-07-22 10:49:18|WinWord|
|[3374042859c9fa152175c4641e8de7f1](https://www.virustotal.com/gui/file/3374042859c9fa152175c4641e8de7f1)|Win32 DLL|Kryptik|2019-07-19 03:32:47|goopdate.dll|
|[0a82e1eb9531c5a3d06dc3b9f6688a31](https://www.virustotal.com/gui/file/0a82e1eb9531c5a3d06dc3b9f6688a31)|Android||2019-07-03 16:28:59|/home/develop/almacen/C8/c8e78a4fbc26c78110259dd1e1d7330443935a406731a38715e5e84ec613e3cd|
|[75644f07d885ad5fadf18febe734c70e](https://www.virustotal.com/gui/file/75644f07d885ad5fadf18febe734c70e)|Win32 DLL|Ursu|2019-06-30 18:11:12| |
|[5c00063b11c4710fe5a5a1adaf208b12](https://www.virustotal.com/gui/file/5c00063b11c4710fe5a5a1adaf208b12)|Win32 DLL||2019-06-27 10:03:23|wwlib.dll|
|[b104798a1f1c04c75e1c4d573020feb7](https://www.virustotal.com/gui/file/b104798a1f1c04c75e1c4d573020feb7)|Win32 DLL|Ursu|2019-06-27 07:19:37|wwlib.dll|
|[886d0dd67e4cf132a1aed84263d661e3](https://www.virustotal.com/gui/file/886d0dd67e4cf132a1aed84263d661e3)|RAR||2019-06-27 06:08:40|a.rar|
|[2b3c5c831eb6b921ac128c4d44d70a7a](https://www.virustotal.com/gui/file/2b3c5c831eb6b921ac128c4d44d70a7a)|ZIP||2019-06-24 15:44:37|=?UTF-8?B?5L+h55So5pWw5o2u5pON5L2c5a6J5YWo546w54q25qKz55CG5Y+K5a6M5ZaE5pa55qGILWJkLnppcA==?=|
|[d30bc57624d233d94dc53a62908ef2df](https://www.virustotal.com/gui/file/d30bc57624d233d94dc53a62908ef2df)|Win32 DLL|Ursu|2019-06-24 10:41:07| |
|[befeabc9087e73c47234e01ed15feb33](https://www.virustotal.com/gui/file/befeabc9087e73c47234e01ed15feb33)|Win32 DLL|Kryptik|2019-06-23 14:58:25|dttcodexgigas.c9f9321e99649142115635acacc40bb286fc1a9b|
|[dc72e300397a29e4960440bd6439586e](https://www.virustotal.com/gui/file/dc72e300397a29e4960440bd6439586e)|Win32 DLL|Kryptik|2019-06-21 06:43:26| |
|[4ecf3caa71a60b06515a33957bd7f000](https://www.virustotal.com/gui/file/4ecf3caa71a60b06515a33957bd7f000)|Win32 DLL|Ursu|2019-06-20 12:32:53|4ecf3caa71a60b06515a33957bd7f000.virobj|
|[bbf25d126b57d19f7ac6084ebb275a74](https://www.virustotal.com/gui/file/bbf25d126b57d19f7ac6084ebb275a74)|Win32 DLL|Ursu|2019-06-19 18:35:37| |
|[3e1f4b34e5753e6e10437ce76d1e4fe3](https://www.virustotal.com/gui/file/3e1f4b34e5753e6e10437ce76d1e4fe3)|Win32 DLL|Ursu|2019-06-18 14:43:32|chrome_elf.dll|
|[b96de3d0023542f8624b82b9773373e9](https://www.virustotal.com/gui/file/b96de3d0023542f8624b82b9773373e9)|Win32 DLL||2019-06-18 07:29:39|test|
|[f28c8cd466e8a0f1ccb123bfe50bd33b](https://www.virustotal.com/gui/file/f28c8cd466e8a0f1ccb123bfe50bd33b)|Win32 DLL||2019-06-17 14:57:12|wwlib.dll|
|[43b1feb961ba00fed0b678087cc83613](https://www.virustotal.com/gui/file/43b1feb961ba00fed0b678087cc83613)|Win32 DLL||2019-06-17 13:05:25|wwlib.dll|
|[18758651e5044259003b81dc80a5b988](https://www.virustotal.com/gui/file/18758651e5044259003b81dc80a5b988)|RAR||2019-06-17 09:35:52|Thu%20moi%20tham%20du%202019.rar|
|[ddcff2a448a3d07fb83c58b8f6d8a406](https://www.virustotal.com/gui/file/ddcff2a448a3d07fb83c58b8f6d8a406)|RAR||2019-06-17 08:25:03|Thu moi tham du 2019.rar|
|[cf5d6d28c388edf58e55412983cf804a](https://www.virustotal.com/gui/file/cf5d6d28c388edf58e55412983cf804a)|Win32 DLL||2019-06-14 09:41:43| |
|[0dd468ee3a4ec0f6f84473bd8428a1e1](https://www.virustotal.com/gui/file/0dd468ee3a4ec0f6f84473bd8428a1e1)|ZIP||2019-06-14 08:49:32|=?UTF-8?B?VGhvzIJuZyB0aW4gdmXMgsyAIGNodXllzIJuIMSRZcyCzIAgbW/MgmkgdHJ1zJtvzJvMgG5nX05ob8ybzIAgYW5oIMSQYcyjzIZuZyBWdcyDIEx1zJtvzJvMo25nIHR1zJsgdmHMgsyBbiB0aGXMgm0uemlw?=|
|[1dfb41e5919af80c7d0fa163a90e21e5](https://www.virustotal.com/gui/file/1dfb41e5919af80c7d0fa163a90e21e5)|ZIP||2019-06-14 06:44:10|=?UTF-8?B?MjAxOTA0MTDkuLvku7vkvJrnrKwy5pyf5Zue5aSNLnppcA==?=|
|[e5c0f9f67e7d1ae16f986172b767faa1](https://www.virustotal.com/gui/file/e5c0f9f67e7d1ae16f986172b767faa1)|Win32 DLL||2019-06-13 06:24:13| |
|[dd3b58d3746739fd5d87678ee7bec7f6](https://www.virustotal.com/gui/file/dd3b58d3746739fd5d87678ee7bec7f6)|Win32 EXE||2019-06-13 03:46:20|QQi.exe|
|[c6310f9e4890a2bbdeb4c4452391c352](https://www.virustotal.com/gui/file/c6310f9e4890a2bbdeb4c4452391c352)|ZIP||2019-06-13 03:07:15|Noi_dung_tren_web.zip|
|[1ea74fdfa2d066b20ec2caac566ecbc3](https://www.virustotal.com/gui/file/1ea74fdfa2d066b20ec2caac566ecbc3)|Win32 DLL|Kryptik|2019-06-11 10:07:57|ldvptask.ocx|
|[dbb8dc265026a7305b33884610f5ba5b](https://www.virustotal.com/gui/file/dbb8dc265026a7305b33884610f5ba5b)|Win32 EXE||2019-06-11 04:41:08|dbb8dc265026a7305b33884610f5ba5b.virus|
|[c9d78c25b5b09c9614ccbf34ebc0b1fe](https://www.virustotal.com/gui/file/c9d78c25b5b09c9614ccbf34ebc0b1fe)|Win32 DLL|oceanlotus|2019-06-07 07:53:53|{bb31f5a0-a119-4667-ba38-3cf4ceee97bf}.ocx|
|[9d28133921b5f0322749d74664e32a14](https://www.virustotal.com/gui/file/9d28133921b5f0322749d74664e32a14)|Win32 EXE|oceanlotus|2019-06-06 02:23:11| |
|[3850fe6b3002c36c2eac72796dfd50ba](https://www.virustotal.com/gui/file/3850fe6b3002c36c2eac72796dfd50ba)|Win32 DLL|Kryptik|2019-06-03 07:48:18|FaultRep.dll|
|[73f38e4d002ec254e49b7f1fdde939b5](https://www.virustotal.com/gui/file/73f38e4d002ec254e49b7f1fdde939b5)|Win32 DLL|Ursu|2019-06-02 11:41:29|73f38e4d002ec254e49b7f1fdde939b5.virus|
|[e5602808c0d41b8cca72fad68486884e](https://www.virustotal.com/gui/file/e5602808c0d41b8cca72fad68486884e)|Win32 DLL|Zbot|2019-05-31 12:50:50|e5602808c0d41b8cca72fad68486884e.virus|
|[1b58a12e6e6eeccd7f64dd9a034503ee](https://www.virustotal.com/gui/file/1b58a12e6e6eeccd7f64dd9a034503ee)|Win32 DLL|Kryptik|2019-05-31 12:00:44| |
|[071bf3efe160bb12962935c20e9fbce8](https://www.virustotal.com/gui/file/071bf3efe160bb12962935c20e9fbce8)|Win32 DLL|Ursu|2019-05-31 11:52:36| |
|[5130950101bc4842a041235dcb87d17e](https://www.virustotal.com/gui/file/5130950101bc4842a041235dcb87d17e)|DOC|Chanitor|2019-05-31 03:34:57|Danh sach thuong tet.doc|
|[5a9da4d8bf063d9c54f55a7161faf106](https://www.virustotal.com/gui/file/5a9da4d8bf063d9c54f55a7161faf106)|Win32 DLL|Ursu|2019-05-26 07:55:04|2.dll|
|[b1daa757de094412fb6dc0c08a1f3d31](https://www.virustotal.com/gui/file/b1daa757de094412fb6dc0c08a1f3d31)|Win32 DLL|Ursu|2019-05-26 06:15:50|1.dll|
|[9d0cce87c2f6885e4424732d240b5a67](https://www.virustotal.com/gui/file/9d0cce87c2f6885e4424732d240b5a67)|Win32 DLL|Ursu|2019-05-24 12:30:53|9d0cce87c2f6885e4424732d240b5a67.virus|
|[4ca32edbc160a4450525ae6402f308f0](https://www.virustotal.com/gui/file/4ca32edbc160a4450525ae6402f308f0)|Win32 EXE|oceanlotus|2019-05-20 20:51:17|dttcodexgigas.ea8455402225b529438c70dfeacdf3a43138b631|
|[d317c64c174ee18b890354477d89ade3](https://www.virustotal.com/gui/file/d317c64c174ee18b890354477d89ade3)|DOC||2019-05-20 10:35:17|Danh%20sach%20dinh%20chi%20cong%20tac.doc|
|[940c5e43701c7e79926f119b50f7eadb](https://www.virustotal.com/gui/file/940c5e43701c7e79926f119b50f7eadb)|Win32 EXE|oceanlotus|2019-05-20 08:28:16|dttcodexgigas.96205f2ebd97632031bfbb0acdd746ddc4b50aa1|
|[1623b27435f7150a1c1f6c09bff05bff](https://www.virustotal.com/gui/file/1623b27435f7150a1c1f6c09bff05bff)|Win32 DLL||2019-05-18 17:41:36|1623b27435f7150a1c1f6c09bff05bff.virus|
|[1f6db57b1e06be1ac274c0b48ed41d32](https://www.virustotal.com/gui/file/1f6db57b1e06be1ac274c0b48ed41d32)|Win32 DLL||2019-05-16 20:36:58|1f6db57b1e06be1ac274c0b48ed41d32.virus|
|[480d76b0b2a8fdd0bbeb46f36b183ec3](https://www.virustotal.com/gui/file/480d76b0b2a8fdd0bbeb46f36b183ec3)|Win32 DLL|Kryptik|2019-05-16 20:26:48|480d76b0b2a8fdd0bbeb46f36b183ec3.virus|
|[8da286109ad06cc23671bd59867e3bdc](https://www.virustotal.com/gui/file/8da286109ad06cc23671bd59867e3bdc)|Win32 EXE|dynamer|2019-05-16 19:44:00|.|
|[d8daa03bf10460d513bb47a352ca1366](https://www.virustotal.com/gui/file/d8daa03bf10460d513bb47a352ca1366)|Win32 DLL||2019-05-16 18:17:58|{7c1d6a86-94ff-4113-a04d-84251023012a}.ocx|
|[3f2eced611670f4df1d566f90c72ed05](https://www.virustotal.com/gui/file/3f2eced611670f4df1d566f90c72ed05)|Win32 DLL|oceanlotus|2019-05-16 17:44:44|{07959185-524a-4d92-9652-f25f83d1e95a}.ocx|
|[426723b0eaf682f198e1f4fc434b9dd3](https://www.virustotal.com/gui/file/426723b0eaf682f198e1f4fc434b9dd3)|Win32 DLL||2019-05-16 17:32:49|{bb31f5a0-a119-4667-ba38-3cf4ceee97bf}.ocx|
|[2463c8f67dc1f2fd4eb15b9dfd20b94d](https://www.virustotal.com/gui/file/2463c8f67dc1f2fd4eb15b9dfd20b94d)|Win32 DLL||2019-05-14 16:56:54|.|
|[8cfac8fdc7ec06c9a1f5d1af739e0328](https://www.virustotal.com/gui/file/8cfac8fdc7ec06c9a1f5d1af739e0328)|DOC|sagent|2019-05-14 09:11:27|cbd060ad934fc7fae940eae0e512f503973c40478224d3de77e27ead2daa0851.doc|
|[bee06e9c1965c72eb0314b9eeb4a8792](https://www.virustotal.com/gui/file/bee06e9c1965c72eb0314b9eeb4a8792)|Win32 EXE|oceanlotus|2019-05-10 03:16:50| |
|[ff6f5fd3c7c381803d50f880162147f2](https://www.virustotal.com/gui/file/ff6f5fd3c7c381803d50f880162147f2)|Win32 DLL|Kryptik|2019-05-08 08:05:11|wwlib.dll|
|[c45ab6dbeab56bce0e30e13d22758f53](https://www.virustotal.com/gui/file/c45ab6dbeab56bce0e30e13d22758f53)|DOTM||2019-05-08 07:47:00|find_jobs.png|
|[eb5bb9000b9da517107282125ef0edae](https://www.virustotal.com/gui/file/eb5bb9000b9da517107282125ef0edae)|Win32 DLL|Ursu|2019-05-07 14:30:13|dttcodexgigas.7eaa2d114b2d829c2e06d7ade95ddf1a03317b89|
|[fe6fb7ba3b140dc15abc2355fd8542f7](https://www.virustotal.com/gui/file/fe6fb7ba3b140dc15abc2355fd8542f7)|DOCX||2019-05-07 11:32:00|CV TENG ZHENYA.docx|
|[f27905d86819395927a87fbdefd59518](https://www.virustotal.com/gui/file/f27905d86819395927a87fbdefd59518)|ZIP||2019-05-06 00:38:14|=?UTF-8?B?MjAxOSDlubTnrKzkuIDlraPluqblt6XkvZzmlrnlkJHpmYTooaguemlw?=|
|[58dfd42874a59faee38d258160e82b68](https://www.virustotal.com/gui/file/58dfd42874a59faee38d258160e82b68)|Win32 EXE||2019-05-05 23:35:15| |
|[e7397f3ecc6025310dc9046465841689](https://www.virustotal.com/gui/file/e7397f3ecc6025310dc9046465841689)|Win32 EXE|oceanlotus|2019-05-04 06:16:07|3.tmp|
|[be937efaaa21a8c06a7f30fcd6a9af69](https://www.virustotal.com/gui/file/be937efaaa21a8c06a7f30fcd6a9af69)|Win32 DLL|Ursu|2019-04-30 09:50:16|be937efaaa21a8c06a7f30fcd6a9af69.virus|
|[d421e0b159a35b8fcb0d90ba04be1a85](https://www.virustotal.com/gui/file/d421e0b159a35b8fcb0d90ba04be1a85)|Win32 DLL||2019-04-28 08:53:55|McUtil.dll|
|[999df75c81c168fbb330f55690a04a13](https://www.virustotal.com/gui/file/999df75c81c168fbb330f55690a04a13)|Win32 DLL|oceanlotus|2019-04-26 20:16:38| |
|[b25b7eb9c004acac78d116be9bd0df8c](https://www.virustotal.com/gui/file/b25b7eb9c004acac78d116be9bd0df8c)|Win32 DLL|Kryptik|2019-04-25 17:42:30|wwlib.dll|
|[208e984792e322d401602d45a043c9db](https://www.virustotal.com/gui/file/208e984792e322d401602d45a043c9db)|Win32 DLL|Kryptik|2019-04-25 09:17:24|dttcodexgigas.99a1491fd67acba56b12a7e10c15dddd540a8ec1|
|[ec125c6fb9bb2d9e19fdfa5ac77ec037](https://www.virustotal.com/gui/file/ec125c6fb9bb2d9e19fdfa5ac77ec037)|Win32 DLL|Ursu|2019-04-25 08:39:41|chrome_elf.dll.bin|
|[dade969b00cbc4a0c1b58eeb0e740b63](https://www.virustotal.com/gui/file/dade969b00cbc4a0c1b58eeb0e740b63)|Win32 DLL|Geodo|2019-04-25 06:35:22|{1888B763-A56C-4D4B-895C-2092993ECCBA}.dll|
|[4e9892a102bd474c6fc82c42fb1840cd](https://www.virustotal.com/gui/file/4e9892a102bd474c6fc82c42fb1840cd)|Win32 EXE||2019-04-25 03:24:26|WinWord|
|[9551b9b69feeb30713dd1d0c8502492e](https://www.virustotal.com/gui/file/9551b9b69feeb30713dd1d0c8502492e)|ZIP||2019-04-24 15:20:33|=?UTF-8?B?MjAxOeW5tOesrOS4gOWto+W6puW3peS9nOaWueWQkemZhOihqC56aXA=?=|
|[3b132e407474bc1c830d5a173428a6e1](https://www.virustotal.com/gui/file/3b132e407474bc1c830d5a173428a6e1)|Win32 DLL|Ursu|2019-04-24 09:05:53| |
|[d4a737974a80aef94184dacbb4a7079b](https://www.virustotal.com/gui/file/d4a737974a80aef94184dacbb4a7079b)|Win32 DLL|Ursu|2019-04-24 07:23:54|chrome_elf.dll|
|[c3d83147fae5a42f08cff1728d15eea0](https://www.virustotal.com/gui/file/c3d83147fae5a42f08cff1728d15eea0)|Win32 EXE|oceanlotus|2019-04-23 08:10:45|CocCocUpdated.exe|
|[097978b6d22be6b2ed739e6c7b4d567a](https://www.virustotal.com/gui/file/097978b6d22be6b2ed739e6c7b4d567a)|Win32 DLL|Kryptik|2019-04-22 10:58:48|goopdate.dll|
|[4e893ea0874f70f4972fa93fed96e77c](https://www.virustotal.com/gui/file/4e893ea0874f70f4972fa93fed96e77c)|Win32 EXE||2019-04-21 07:41:24|test.bin.ex_|
|[56b5a96b8582b32ad50d6b6d9e980ce7](https://www.virustotal.com/gui/file/56b5a96b8582b32ad50d6b6d9e980ce7)|DOC|o97m|2019-04-19 15:18:39|Request Comment on UYFC.doc|
|[c7931fa4c144c1c4dc19ad4c41c1e17f](https://www.virustotal.com/gui/file/c7931fa4c144c1c4dc19ad4c41c1e17f)|DOC|o97m|2019-04-19 07:45:00|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Oceanlotus/Report-No.0162.doc|
|[635e563c8620dff00176df7efdd74dfe](https://www.virustotal.com/gui/file/635e563c8620dff00176df7efdd74dfe)|Win32 DLL|injector|2019-04-18 08:09:39|1st.exe|
|[4be5f2323b070d5546c16d3327e5a932](https://www.virustotal.com/gui/file/4be5f2323b070d5546c16d3327e5a932)|Win32 DLL|Kryptik|2019-04-17 15:47:13|%PROGRAMDATA%\officeblogdns\wwlib.dll|
|[6690c168744f22e3f907f9f165e293ba](https://www.virustotal.com/gui/file/6690c168744f22e3f907f9f165e293ba)|Win32 DLL|Ursu|2019-04-17 10:17:10|{9FBAA883-1709-4DE3-8C1B-48683F740A5F}.clsid|
|[e60c35dd36c9f525007955e6b3a88b82](https://www.virustotal.com/gui/file/e60c35dd36c9f525007955e6b3a88b82)|Win32 EXE||2019-04-17 10:10:05|test.exe_|
|[9af9be96c14ef18e641486f51f840bc2](https://www.virustotal.com/gui/file/9af9be96c14ef18e641486f51f840bc2)|Win64 DLL||2019-04-17 07:35:00|download2.bin|
|[c81bac80b928f489bdd02b02cf4fcac5](https://www.virustotal.com/gui/file/c81bac80b928f489bdd02b02cf4fcac5)|Win32 DLL|injector|2019-04-17 07:32:28|download.bin|
|[7b0e819bd8304773c3648ab03c9f182a](https://www.virustotal.com/gui/file/7b0e819bd8304773c3648ab03c9f182a)|ACE|CVE-2018-20250|2019-04-16 10:01:05|TUT_Photoshop_scan_Bank_ID.rar|
|[07f25f0fe7fc3851f8365c19f7a51b25](https://www.virustotal.com/gui/file/07f25f0fe7fc3851f8365c19f7a51b25)|Win32 DLL|Kryptik|2019-04-16 06:02:26|goopdate.dll|
|[f5978aab68abe95bd00c77a6e2d07627](https://www.virustotal.com/gui/file/f5978aab68abe95bd00c77a6e2d07627)|DOCX|o97m|2019-04-16 04:07:08|Qian Zemin CV.docx|
|[ff3558a84d5ef614c40dc00dca1ec80b](https://www.virustotal.com/gui/file/ff3558a84d5ef614c40dc00dca1ec80b)|Win32 DLL|Zbot|2019-04-15 08:39:14|dttcodexgigas.1c868cc4876de1a6b1c6b1f858b0edf3090085c2|
|[ba4c49379ef68be5406c996d33a5a292](https://www.virustotal.com/gui/file/ba4c49379ef68be5406c996d33a5a292)|Win32 DLL||2019-04-15 04:39:31|chrome_elf.dll|
|[56e507301681fdaaea95db2b16feeac1](https://www.virustotal.com/gui/file/56e507301681fdaaea95db2b16feeac1)|Win32 DLL||2019-04-14 11:18:01|c7d3c3f4d3c237c41144641bee48a97aa5d2ab7a97dc4e34deaab9fff40a0d49.dll|
|[3d7cd531d17799832e262eb7995abde6](https://www.virustotal.com/gui/file/3d7cd531d17799832e262eb7995abde6)|Mach-O executable|oceanlotus|2019-04-13 09:01:39|3723aacfab4f0f3c35d86265c566b71002041ff1d7822d1444fd5df596bc1d5e.bin|
|[5bb2a74e135fedf0997484a1a8a14976](https://www.virustotal.com/gui/file/5bb2a74e135fedf0997484a1a8a14976)|Win64 DLL||2019-04-12 08:43:40|base64-decoded-64.bin|
|[b8d588e9b272d262dbd12e849833f888](https://www.virustotal.com/gui/file/b8d588e9b272d262dbd12e849833f888)|Win32 DLL|injector|2019-04-12 08:43:34|base64-decoded-32.bin|
|[05e513c612b0384804db9bda5277087c](https://www.virustotal.com/gui/file/05e513c612b0384804db9bda5277087c)|Win32 DLL|Ursu|2019-04-10 11:20:49|wwlib.dll|
|[ae3c759c49745190e6c9c48c34be2da9](https://www.virustotal.com/gui/file/ae3c759c49745190e6c9c48c34be2da9)|RAR|Ursu|2019-04-10 07:28:02|=?UTF-8?B?MjAxOeW5tOesrOS4gOWto+W6puW3peS9nOaWueWQkemZhOihqC5yYXI=?=|
|[14b6fbf7e774090d9166e6c559be7206](https://www.virustotal.com/gui/file/14b6fbf7e774090d9166e6c559be7206)|Win32 DLL|Kryptik|2019-04-09 08:26:04|myfile.exe|
|[b69e3e07bb742bb9afb92354a32a47a8](https://www.virustotal.com/gui/file/b69e3e07bb742bb9afb92354a32a47a8)|Win32 DLL|oceanlotus|2019-04-09 08:13:06|{b09bfc49-afe6-47d4-b2ec-4b806f44bf7b}.ocx|
|[9eb63353207d0ffd8e9509b3778f21d1](https://www.virustotal.com/gui/file/9eb63353207d0ffd8e9509b3778f21d1)|ZIP||2019-04-09 05:12:15|Tinh dau can mua.zip";filename*=UTF-8''Tinh%20dau%20can%20mua.zip|
|[56a33d845bcfaa983910a3a853dd07be](https://www.virustotal.com/gui/file/56a33d845bcfaa983910a3a853dd07be)|Win32 EXE||2019-04-09 04:40:00|AcroRd32.exe|
|[88eae0d31a6c38cfb615dd75918b47b1](https://www.virustotal.com/gui/file/88eae0d31a6c38cfb615dd75918b47b1)|Win32 DLL|agentwdcr|2019-04-06 19:42:12|myfile.exe|
|[fdcc96ea1bbdba9947b2e1a023d4a47d](https://www.virustotal.com/gui/file/fdcc96ea1bbdba9947b2e1a023d4a47d)|Win32 DLL|Kryptik|2019-04-04 07:32:52|wsc.dll|
|[35b4f04dd3df5defb3bd3040be880320](https://www.virustotal.com/gui/file/35b4f04dd3df5defb3bd3040be880320)|Win32 DLL|injector|2019-04-02 19:35:32|.|
|[b9af036686b5745bec438d2f7c9dc3d6](https://www.virustotal.com/gui/file/b9af036686b5745bec438d2f7c9dc3d6)|Win32 DLL|Zbot|2019-04-01 23:51:30|b0fb18c99859b75decb956a8c12732e7c918e0b39c645eb5eab57da28a196b7c.bin|
|[4a667522c379ed469e1ef0e72268d4cf](https://www.virustotal.com/gui/file/4a667522c379ed469e1ef0e72268d4cf)|RAR|Zbot|2019-04-01 18:28:58|.|
|[6e12bd357f2c530a529e94d74c4a6d5e](https://www.virustotal.com/gui/file/6e12bd357f2c530a529e94d74c4a6d5e)|Win32 DLL|Ursu|2019-04-01 13:19:37|wwlib.dll|
|[fd128b9f0cbdc374227cf5564371aacc](https://www.virustotal.com/gui/file/fd128b9f0cbdc374227cf5564371aacc)|RAR||2019-04-01 09:15:03|Hop dong sungroup.rar|
|[d8a5a375da7798be781cf3ea689ae7ab](https://www.virustotal.com/gui/file/d8a5a375da7798be781cf3ea689ae7ab)|DOC|o97m|2019-04-01 05:57:20|Program Retreat.doc|
|[6af1625b7f9a4b3fe934f52714a46afb](https://www.virustotal.com/gui/file/6af1625b7f9a4b3fe934f52714a46afb)|Win32 DLL|Kryptik|2019-03-29 10:19:25|wwlib.dll|
|[4a0144c7436e3ff67cf2d935d82d1743](https://www.virustotal.com/gui/file/4a0144c7436e3ff67cf2d935d82d1743)|RAR||2019-03-29 06:05:15|31f03164ecca276a0c8c72aeebe964d10f287437eef1c4501a6f7630c0ae140f.bin|
|[725aaac9b92f6d60f0cf26bd04894b98](https://www.virustotal.com/gui/file/725aaac9b92f6d60f0cf26bd04894b98)|unknown||2019-03-26 02:15:40|=?UTF-8?B?MjAxOeW5tDLmnIjkuqTku5jkvJrmnZDmlpkubWh0?=|
|[bcbc1bef20d2befdd290e31269e0174a](https://www.virustotal.com/gui/file/bcbc1bef20d2befdd290e31269e0174a)|RAR||2019-03-22 19:36:46|60982849-c8e4-4039-8f59-dfb78d8bab0d|
|[6aa3115fa1f3adb8f0539e93d2cf21ca](https://www.virustotal.com/gui/file/6aa3115fa1f3adb8f0539e93d2cf21ca)|Win32 DLL|Zbot|2019-03-22 16:03:21|wwlib.dll|
|[4c30e792218d5526f6499d235448bdd9](https://www.virustotal.com/gui/file/4c30e792218d5526f6499d235448bdd9)|DOC|o97m|2019-03-22 07:28:59|Form_Provisional Agenda of the ASEAN Senior Officials Preparatory Meeting.doc|
|[1a8a89d8d2622948fdc8ca3d062bfce7](https://www.virustotal.com/gui/file/1a8a89d8d2622948fdc8ca3d062bfce7)|Win32 DLL|oceanlotus|2019-03-22 02:47:54|{7026ce06-ee00-4ebd-b00e-f5150d86c13e}.ocx|
|[d615664668a80d6031cd7550ac9a9448](https://www.virustotal.com/gui/file/d615664668a80d6031cd7550ac9a9448)|Win32 DLL|Kryptik|2019-03-21 21:58:16|wwlib.dll|
|[8f47c0ef3a8cfa47fa1a7d430b6b64f2](https://www.virustotal.com/gui/file/8f47c0ef3a8cfa47fa1a7d430b6b64f2)|Win32 DLL|oceanlotus|2019-03-21 15:17:55|{5d706adc-0933-4af8-be59-a14ab73a8bc4}.ocx|
|[dfaa343552e8d470096a0a09a018930f](https://www.virustotal.com/gui/file/dfaa343552e8d470096a0a09a018930f)|RAR|ursu|2019-03-19 18:34:17|4052d2e7-ca42-4cd4-8841-52f782bba411|
|[ddd161a6bb63ca46e8cb0663587920fe](https://www.virustotal.com/gui/file/ddd161a6bb63ca46e8cb0663587920fe)|Win32 DLL|Zbot|2019-03-19 14:18:28|wwlib.dll|
|[a76be0181705809898d5d7d9aed86ee8](https://www.virustotal.com/gui/file/a76be0181705809898d5d7d9aed86ee8)|ZIP|oceanlotus|2019-03-16 23:27:19|84c1dcd922ddcf6257e74aeb6154b81b78b24dd24ae27b75d4948ec186ff8b63.bin|
|[5bff246eb66eda703bcb7742f658ce36](https://www.virustotal.com/gui/file/5bff246eb66eda703bcb7742f658ce36)|Win32 DLL|Zbot|2019-03-15 08:22:40|wwlib.dll|
|[9d4c0bd0b4025cbea9100db4863bc2ff](https://www.virustotal.com/gui/file/9d4c0bd0b4025cbea9100db4863bc2ff)|Win32 DLL|Kryptik|2019-03-12 10:25:26|myfile.exe|
|[9b1ce9df321ce88ade4ff3b0ada5d414](https://www.virustotal.com/gui/file/9b1ce9df321ce88ade4ff3b0ada5d414)|RAR|Ursu|2019-03-11 22:17:54|ffea6446-ab7a-4e47-b7ff-e461f9775177|
|[2e645c7971436417a2a6b4774bce59df](https://www.virustotal.com/gui/file/2e645c7971436417a2a6b4774bce59df)|Win32 DLL|Zbot|2019-03-11 18:52:37|wwlib.dll|
|[190db4e6de3a96955502f3e450428217](https://www.virustotal.com/gui/file/190db4e6de3a96955502f3e450428217)|Win32 DLL||2019-03-10 16:46:17|be6d5973452248cb18949711645990b6a56e7442dc30cc48a607a2afe7d8ec66.sample|
|[94823e75f54f5ec69ede7e15951c9c60](https://www.virustotal.com/gui/file/94823e75f54f5ec69ede7e15951c9c60)|GZIP|oceanlotus|2019-03-08 17:59:46|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT32/OceanLotusBackDoor.bin.gz|
|[6a750942923a9add04c225c273a7fb20](https://www.virustotal.com/gui/file/6a750942923a9add04c225c273a7fb20)|DOC|o97m|2019-03-08 06:47:27| |
|[115f3cb5bdfb2ffe5168ecb36b9aed54](https://www.virustotal.com/gui/file/115f3cb5bdfb2ffe5168ecb36b9aed54)|DOC|o97m|2019-03-07 04:44:06|2018年公司总结报告补充建议.doc|
|[684eff3d9723542cc9c2a999f011fe6e](https://www.virustotal.com/gui/file/684eff3d9723542cc9c2a999f011fe6e)|RAR|o97m|2019-03-07 01:02:28|=?UTF-8?B?MjAxOOW5tOWFrOWPuOaAu+e7k+aKpeWRiuihpeWFheW7uuiuri5yYXI=?=|
|[51bc54636cb45d0159ee2f25df305d42](https://www.virustotal.com/gui/file/51bc54636cb45d0159ee2f25df305d42)|Win32 DLL|PlugX|2019-03-06 20:33:18|rastls.dll|
|[c53536da2d6d75410e813e7839a7b0bc](https://www.virustotal.com/gui/file/c53536da2d6d75410e813e7839a7b0bc)|Win32 EXE||2019-03-06 20:30:33|mcoemcpy|
|[a0689c035eda37fa4827572bc9d22a64](https://www.virustotal.com/gui/file/a0689c035eda37fa4827572bc9d22a64)|Win32 DLL|PlugX|2019-03-06 20:28:31|McUtil.dll|
|[03af6b33bda1f78cb2c6bf67bca3649c](https://www.virustotal.com/gui/file/03af6b33bda1f78cb2c6bf67bca3649c)|Win32 DLL|PlugX|2019-03-06 02:02:11|rastls.dll|
|[13324fd1aa2edc18113658c8a25df4c4](https://www.virustotal.com/gui/file/13324fd1aa2edc18113658c8a25df4c4)|Win32 DLL|Kryptik|2019-03-05 09:50:18|wwlib.dll|
|[d70073cf5f1a9a5249e5e0854339f4d7](https://www.virustotal.com/gui/file/d70073cf5f1a9a5249e5e0854339f4d7)|Win32 EXE||2019-03-05 06:38:20|WinWord|
|[06334cb14c1512bf2794af8dae5ab357](https://www.virustotal.com/gui/file/06334cb14c1512bf2794af8dae5ab357)|Mach-O executable||2019-03-05 06:32:34|flashlightd|
|[60190ab01b53602bcf1ffad71eb8f385](https://www.virustotal.com/gui/file/60190ab01b53602bcf1ffad71eb8f385)|Win32 DLL|Kryptik|2019-03-05 03:42:44|myfile.exe|
|[da14eece6191551a31d37d1e96681cd1](https://www.virustotal.com/gui/file/da14eece6191551a31d37d1e96681cd1)|RAR|Ursu|2019-03-01 18:56:34|5d47e097-c3bc-401e-8c0f-e877280b368a|
|[0deb78c1edae349f6ff0e9c3ff5bc561](https://www.virustotal.com/gui/file/0deb78c1edae349f6ff0e9c3ff5bc561)|Win32 DLL|Zbot|2019-03-01 14:45:40|wwlib.dll|
|[0a5a26bf55f82559a80b1b77cb0c9501](https://www.virustotal.com/gui/file/0a5a26bf55f82559a80b1b77cb0c9501)|Win32 EXE|occamy|2019-03-01 11:14:12|dttcodexgigas.124ee590bb19f10f58f4e66346c328165d408179|
|[2785311085b6ca782b476d9c2530259c](https://www.virustotal.com/gui/file/2785311085b6ca782b476d9c2530259c)|ZIP|oceanlotus|2019-03-01 09:16:21|2413ca86e1c6ceac62b4f1c911dfffae37e8c25af9f688476f4c220a023ac3bd.bin|
|[dd8b36f8f967a26314820c35632fa0d0](https://www.virustotal.com/gui/file/dd8b36f8f967a26314820c35632fa0d0)|Win32 DLL|Zbot|2019-03-01 08:32:47|wwlib.dll|
|[76289f02a0b31143d87d5e35839fb24a](https://www.virustotal.com/gui/file/76289f02a0b31143d87d5e35839fb24a)|RAR|Zbot|2019-03-01 01:49:05|Thu moi 2019.rar|
|[2984dd7d51595c54575c470c7fe44545](https://www.virustotal.com/gui/file/2984dd7d51595c54575c470c7fe44545)|ZIP||2019-02-28 18:37:40|b188622f-4630-4e18-b168-2a90909da729|
|[6aab0ff5cb3189505ca9aaf1d602ab28](https://www.virustotal.com/gui/file/6aab0ff5cb3189505ca9aaf1d602ab28)|Win32 DLL|Kryptik|2019-02-28 10:37:49| |
|[9020db586f060b0301039ca2b5afc05c](https://www.virustotal.com/gui/file/9020db586f060b0301039ca2b5afc05c)|Win32 DLL||2019-02-27 10:18:13| |
|[c7772d7b9421ceae8bb82a98cf0cbfab](https://www.virustotal.com/gui/file/c7772d7b9421ceae8bb82a98cf0cbfab)|Win32 DLL|Kryptik|2019-02-23 04:00:45|hik.png|
|[d24eae68d6785c56b8a88ff36e53fbd8](https://www.virustotal.com/gui/file/d24eae68d6785c56b8a88ff36e53fbd8)|Win64 DLL||2019-02-21 08:00:59|main_background.png|
|[3d67fe89663a372c2ab4fab4aa5cb33e](https://www.virustotal.com/gui/file/3d67fe89663a372c2ab4fab4aa5cb33e)|Win32 DLL|Zbot|2019-02-20 11:53:04|g2.png|
|[74731674920c51668c36cc3c16f30553](https://www.virustotal.com/gui/file/74731674920c51668c36cc3c16f30553)|ZIP||2019-02-20 01:16:11|KBLibprivate.jar|
|[dfc78da5202a70066eba124660fd5085](https://www.virustotal.com/gui/file/dfc78da5202a70066eba124660fd5085)|ZIP||2019-02-20 01:15:50|KBLib.jar|
|[c08e0efedc606048588be02a4f0cf752](https://www.virustotal.com/gui/file/c08e0efedc606048588be02a4f0cf752)|Win32 DLL|Zbot|2019-02-20 01:15:13|goopdate.dll|
|[96795ea3b442682e49fffd1305d42496](https://www.virustotal.com/gui/file/96795ea3b442682e49fffd1305d42496)|Win32 DLL||2019-02-18 21:29:57|dttcodexgigas.0f74478f0bac8d41fd2aae29772c1f636e4b3ada|
|[f6abb3c0fc88ff388bbad68626ed2747](https://www.virustotal.com/gui/file/f6abb3c0fc88ff388bbad68626ed2747)|Win32 EXE||2019-02-17 18:10:30|WinWord|
|[c7fa341cc31edc175d877ce244e30ab9](https://www.virustotal.com/gui/file/c7fa341cc31edc175d877ce244e30ab9)|Win32 EXE||2019-02-17 17:57:05|WinWord|
|[bb08a4b4c3a33a756ea8e7a11dcca7ae](https://www.virustotal.com/gui/file/bb08a4b4c3a33a756ea8e7a11dcca7ae)|Win32 DLL|Ursu|2019-02-16 16:08:46|Geogle Update|
|[f41f0cc3a609d3ae1d6ef22c01519e66](https://www.virustotal.com/gui/file/f41f0cc3a609d3ae1d6ef22c01519e66)|Win32 DLL||2019-02-15 01:18:02|goopdate.dll|
|[34c7f65414374be5cd09565e6ecab7d5](https://www.virustotal.com/gui/file/34c7f65414374be5cd09565e6ecab7d5)|Win32 DLL|Ursu|2019-02-13 08:56:41|wwlib.dll|
|[cd3c1d50efd3736cf26c4d08ab9ad073](https://www.virustotal.com/gui/file/cd3c1d50efd3736cf26c4d08ab9ad073)|Win32 DLL|Zbot|2019-02-13 03:34:04|%PROGRAMDATA%\office\wwlib.dll|
|[2f9af6b9d73218c578653d6d9bd02d4d](https://www.virustotal.com/gui/file/2f9af6b9d73218c578653d6d9bd02d4d)|Win32 DLL|Kryptik|2019-02-13 00:38:02|wwlib.dll|
|[9af5a3bf5be2deb0c0f0701fc66691ef](https://www.virustotal.com/gui/file/9af5a3bf5be2deb0c0f0701fc66691ef)|Win32 DLL|Zbot|2019-02-02 20:42:02| |
|[5f1bc795aa784f781d91acc97bec6644](https://www.virustotal.com/gui/file/5f1bc795aa784f781d91acc97bec6644)|Win32 DLL|Zbot|2019-02-02 19:42:13| |
|[1f86a5a573e3c4481ce8b3c6cfcca099](https://www.virustotal.com/gui/file/1f86a5a573e3c4481ce8b3c6cfcca099)|Win32 DLL|Kryptik|2019-02-02 13:06:25|wwlib.dll|
|[05f6a46cadf9e26cb52774475f80908c](https://www.virustotal.com/gui/file/05f6a46cadf9e26cb52774475f80908c)|Win32 DLL|Kryptik|2019-02-01 15:54:42|dttcodexgigas.4963fea2696ed05d302a44e5a17edb20aadc22b0|
|[fb29e133d96f449a6b480d74624c4d01](https://www.virustotal.com/gui/file/fb29e133d96f449a6b480d74624c4d01)|Win32 DLL|Kryptik|2019-02-01 15:42:06|dttcodexgigas.40a7ae216cde729eaaf8da458abf0b93e80c58cb|
|[c9d29501410e19938cd8e01630dc677b](https://www.virustotal.com/gui/file/c9d29501410e19938cd8e01630dc677b)|Win64 DLL||2019-02-01 12:01:56|main_background.png_|
|[779c62925b8338fcb3e36bfb9311c6ef](https://www.virustotal.com/gui/file/779c62925b8338fcb3e36bfb9311c6ef)|Win32 DLL|Kryptik|2019-02-01 12:00:09|goopdate.dll_|
|[93e18eab6244724129d7a4f97b792938](https://www.virustotal.com/gui/file/93e18eab6244724129d7a4f97b792938)|Win32 DLL||2019-02-01 11:57:16|ldvptask.ocx_|
|[1d7206a2a02200e3562b8d10db355e75](https://www.virustotal.com/gui/file/1d7206a2a02200e3562b8d10db355e75)|Win32 DLL||2019-02-01 10:07:07|wwlib.dll|
|[b1df440e5dd64ffae9f7e792993f2f4c](https://www.virustotal.com/gui/file/b1df440e5dd64ffae9f7e792993f2f4c)|DOCX|injector|2019-02-01 09:57:19|CV-AnthonyWei-CustomerService.docx|
|[c74a24dea88999797aaceeecd63efaff](https://www.virustotal.com/gui/file/c74a24dea88999797aaceeecd63efaff)|Win64 DLL||2019-02-01 09:20:25|main_background.png|
|[d497bd06b34a046841bb63d3bf20e605](https://www.virustotal.com/gui/file/d497bd06b34a046841bb63d3bf20e605)|DOTM|Chanitor|2019-01-31 13:07:23|fdsw.png|
|[25b9d324d9be10ed99057b5769d2ac6d](https://www.virustotal.com/gui/file/25b9d324d9be10ed99057b5769d2ac6d)|Win32 EXE||2019-01-28 14:01:16|dttcodexgigas.b79411e82318db71857f61d461edb93669215d74|
|[71b95a84463e75f04cece06c320bf539](https://www.virustotal.com/gui/file/71b95a84463e75f04cece06c320bf539)|Win32 DLL|Kryptik|2019-01-28 05:36:46|%PROGRAMDATA%\office\wwlib.dll|
|[9003100ee7f9493b142f6a575fb31474](https://www.virustotal.com/gui/file/9003100ee7f9493b142f6a575fb31474)|Win32 DLL|Ursu|2019-01-28 05:26:12|dttcodexgigas.57f8088c40f1f2caf73d14881440260c5f311e43|
|[ecb9cafd509549f8f91ca91ab94f9356](https://www.virustotal.com/gui/file/ecb9cafd509549f8f91ca91ab94f9356)|Win32 DLL||2019-01-28 04:46:50|dttcodexgigas.ed4b748ea29b8a5ee953316211c5763b80174c61|
|[cd0517ed45ca78fe3dfb008f27801e48](https://www.virustotal.com/gui/file/cd0517ed45ca78fe3dfb008f27801e48)|Win32 DLL|Kryptik|2019-01-27 03:21:57|dttcodexgigas.5dbfd48e0425134fd49541be466f06e3e2fa5b5f|
|[a8ad332725b26ceba05b873a7b92f8df](https://www.virustotal.com/gui/file/a8ad332725b26ceba05b873a7b92f8df)|Win32 DLL|Kryptik|2019-01-25 14:32:05|wwlib.dll|
|[accd0b7998ea57465da5eebc54897553](https://www.virustotal.com/gui/file/accd0b7998ea57465da5eebc54897553)|Win32 DLL||2019-01-24 17:30:39|WsmanClient.bin|
|[6830b1abd38c3f086435c418703b7057](https://www.virustotal.com/gui/file/6830b1abd38c3f086435c418703b7057)|Win32 DLL||2019-01-24 17:27:54|ACE.bin|
|[8dffe4850438125dde8e18e78cf83644](https://www.virustotal.com/gui/file/8dffe4850438125dde8e18e78cf83644)|Win32 DLL||2019-01-24 16:42:02|GmsCommon.bin|
|[3b36fb3a8cf15b0c5a288329e357e916](https://www.virustotal.com/gui/file/3b36fb3a8cf15b0c5a288329e357e916)|Win64 DLL||2019-01-24 13:08:02|main_background.png|
|[686b61c2d1274c81db691866c8646e2d](https://www.virustotal.com/gui/file/686b61c2d1274c81db691866c8646e2d)|Win32 DLL||2019-01-24 08:17:51|myfile.exe|
|[6b1908bc8cdae9646febbd8574dce523](https://www.virustotal.com/gui/file/6b1908bc8cdae9646febbd8574dce523)|Win32 EXE||2019-01-24 08:15:12|WinWord|
|[6e0ce271ea2872eeaab5f126058df3ca](https://www.virustotal.com/gui/file/6e0ce271ea2872eeaab5f126058df3ca)|Win32 DLL|oceanlotus|2019-01-24 03:28:41|myfile.exe|
|[655c536462944d0f3c9fcf4ec19d2015](https://www.virustotal.com/gui/file/655c536462944d0f3c9fcf4ec19d2015)|Win32 DLL|Zbot|2019-01-23 03:48:31|Z:\arvi\Новая папка\100\655c53.exe|
|[2d3fb8d5b4cefc9660d98e0ad46ff91a](https://www.virustotal.com/gui/file/2d3fb8d5b4cefc9660d98e0ad46ff91a)|RAR|Zbot|2019-01-23 00:01:10|/var/www/clean-mx/virusesevidence/output.127392422.txt|
|[baee6b3ff4435bb6a79a5b54faa88861](https://www.virustotal.com/gui/file/baee6b3ff4435bb6a79a5b54faa88861)|Win32 DLL|Kryptik|2019-01-22 07:04:26|goopdate.dll|
|[8c3adb7a89400f491f42770e9280be0d](https://www.virustotal.com/gui/file/8c3adb7a89400f491f42770e9280be0d)|Win32 DLL|Zbot|2019-01-22 05:00:37|8c3adb7a89400f491f42770e9280be0d.virus|
|[e14c293bcb84df002414e7869f165dfb](https://www.virustotal.com/gui/file/e14c293bcb84df002414e7869f165dfb)|Win32 DLL|Zbot|2019-01-22 04:42:02|e14c293bcb84df002414e7869f165dfb.virus|
|[438d692161157737b78fd6ca4f2a2cb5](https://www.virustotal.com/gui/file/438d692161157737b78fd6ca4f2a2cb5)|Win32 DLL|Zbot|2019-01-19 18:47:14|.|
|[fb2b48d856b9c3db882fb4026d5b056b](https://www.virustotal.com/gui/file/fb2b48d856b9c3db882fb4026d5b056b)|Win32 DLL|oceanlotus|2019-01-19 15:01:36|myfile.exe|
|[e33fce35e3fd7bb2241190f2cafc5acf](https://www.virustotal.com/gui/file/e33fce35e3fd7bb2241190f2cafc5acf)|Win32 EXE|oceanlotus|2019-01-19 10:51:17|AcroRd32.exe|
|[27425360d18feea54860420006ea9833](https://www.virustotal.com/gui/file/27425360d18feea54860420006ea9833)|DOCX|o97m|2019-01-18 12:30:30|Danh Sach Nhan Vien Bien Thu Tien Cong Ty.docx|
|[bf7c5bc086694a6e909013d63fccf6d6](https://www.virustotal.com/gui/file/bf7c5bc086694a6e909013d63fccf6d6)|Win32 DLL||2019-01-18 01:03:42|myfile.exe|
|[f3551be56b9f72374787442453bf0428](https://www.virustotal.com/gui/file/f3551be56b9f72374787442453bf0428)|Win32 DLL|Zbot|2019-01-17 19:43:37|.|
|[c83042299cda4180c720bbaa0af8c442](https://www.virustotal.com/gui/file/c83042299cda4180c720bbaa0af8c442)|Win32 DLL|Zbot|2019-01-17 12:20:38|wwlib.dll|
|[a97c76167617a39912912d482491760d](https://www.virustotal.com/gui/file/a97c76167617a39912912d482491760d)|Win32 DLL|Zbot|2019-01-16 01:56:34| |
|[8ccfd46a24d3bcbee934af91dda8483d](https://www.virustotal.com/gui/file/8ccfd46a24d3bcbee934af91dda8483d)|Win32 DLL|Zbot|2019-01-15 14:49:02|Kopie von wwlib.dll$|
|[6aa22d6c51ea5abe9a9af3a3fb51721b](https://www.virustotal.com/gui/file/6aa22d6c51ea5abe9a9af3a3fb51721b)|Win32 DLL|Zbot|2019-01-15 07:12:54|wwlib.dll|
|[2974e2e897e2a844d89ef2ce2b71df10](https://www.virustotal.com/gui/file/2974e2e897e2a844d89ef2ce2b71df10)|Win32 DLL|Kryptik|2019-01-15 03:23:34|RasTls.dll|
|[cb39e2138af92c32e53c97c0aa590d48](https://www.virustotal.com/gui/file/cb39e2138af92c32e53c97c0aa590d48)|unknown|oceanlotus|2019-01-15 01:28:53|d1901f0b6266e4be23d805daaed7a10e1d0abcc5e30ed7c38803d13b80caf74d.bin|
|[a35fe875629efea879e38a1810a572a5](https://www.virustotal.com/gui/file/a35fe875629efea879e38a1810a572a5)|Win32 DLL||2019-01-14 05:50:29|ACE.dll|
|[d801c315332dc8aef0387e7a323b77d4](https://www.virustotal.com/gui/file/d801c315332dc8aef0387e7a323b77d4)|Win32 DLL||2019-01-11 09:31:29|1.exe|
|[cf0142da12509f544a59093495c3a6dd](https://www.virustotal.com/gui/file/cf0142da12509f544a59093495c3a6dd)|DOCX|o97m|2019-01-11 02:13:33|Danh Sach Nhan Vien Bien Thu Tien Cong Ty.docx|
|[c3bb2b1eabfb34181a9a052e4f06397c](https://www.virustotal.com/gui/file/c3bb2b1eabfb34181a9a052e4f06397c)|Win32 DLL|Zbot|2019-01-08 08:30:11|wwlib.dll|
|[f78be074f6bc67a712e751254df5f166](https://www.virustotal.com/gui/file/f78be074f6bc67a712e751254df5f166)|HTML|injector|2019-01-06 05:12:06| |
|[8e13895504e643cd8e0e87377b25bd6b](https://www.virustotal.com/gui/file/8e13895504e643cd8e0e87377b25bd6b)|DOCX|sagent|2019-01-05 01:55:54|CV Nguyen Minh Duc.docx|
|[f8d2acdbc74b06b741cbbfebee515b54](https://www.virustotal.com/gui/file/f8d2acdbc74b06b741cbbfebee515b54)|Win32 DLL|Zbot|2019-01-02 15:42:20|wwlib.dll|
|[905dba5ba8ff0a9950d5d1d84c50bfc9](https://www.virustotal.com/gui/file/905dba5ba8ff0a9950d5d1d84c50bfc9)|RAR|ursu|2019-01-02 12:09:30|143bb061-7199-4564-9e60-8653779cb50a|
|[2212624471c956202a6f68f5708615f0](https://www.virustotal.com/gui/file/2212624471c956202a6f68f5708615f0)|Win32 DLL|Ursu|2019-01-02 03:20:13|2212624471c956202a6f68f5708615f0.virobj|
|[827c61d58432bd6631ddd694c89c458e](https://www.virustotal.com/gui/file/827c61d58432bd6631ddd694c89c458e)|Win32 EXE||2018-12-28 17:19:24|WinWord|
|[e2a5a1e7791f8acc8bae11f4d86567e0](https://www.virustotal.com/gui/file/e2a5a1e7791f8acc8bae11f4d86567e0)|DOC||2018-12-27 07:50:08|dttcodexgigas.9560bd6422b6f9397af1aaea0c48bc4ffbbb4001|
|[02cec2f17a7910b6fa994f340bbbc297](https://www.virustotal.com/gui/file/02cec2f17a7910b6fa994f340bbbc297)|unknown|injector|2018-12-27 07:12:11|=?UTF-8?Q?L=C3=9D_ANH_TRUNG_CV=2Edoc?=|
|[e04594ba7e2c63d4f48d92cc99246cce](https://www.virustotal.com/gui/file/e04594ba7e2c63d4f48d92cc99246cce)|Win32 DLL|Zbot|2018-12-26 12:20:56|wwlib.dll|
|[4bdada3dea9b6bb14418e584c1b6af08](https://www.virustotal.com/gui/file/4bdada3dea9b6bb14418e584c1b6af08)|Win32 DLL|Zbot|2018-12-26 08:37:52|wwlib.dll|
|[4973d4d95b17150153fddc07bbdb6575](https://www.virustotal.com/gui/file/4973d4d95b17150153fddc07bbdb6575)|Win32 DLL|Zbot|2018-12-26 08:35:33|wwlib.dll|
|[ce0afd0b440e25267a96e181d3d9ec5a](https://www.virustotal.com/gui/file/ce0afd0b440e25267a96e181d3d9ec5a)|Win64 DLL||2018-12-26 03:05:30|f62f21ee7e642f272b881827b45ceb643c999a742e1d3eac13d1ba014d1e7f67.bin|
|[43c03994e843164625794f4ac727811e](https://www.virustotal.com/gui/file/43c03994e843164625794f4ac727811e)|Win32 DLL|Zbot|2018-12-25 15:05:52|wwlib.dll|
|[d568d10f3e66b89159abf402b31a37b8](https://www.virustotal.com/gui/file/d568d10f3e66b89159abf402b31a37b8)|Win32 DLL||2018-12-25 08:15:25|wwlib.dll|
|[d1bef2da4a8a7811add4606dc94678bc](https://www.virustotal.com/gui/file/d1bef2da4a8a7811add4606dc94678bc)|Win32 DLL|Zbot|2018-12-22 10:07:36|wwlib.dll|
|[5f7f60e9fcc992794feb2d6e9908d1c3](https://www.virustotal.com/gui/file/5f7f60e9fcc992794feb2d6e9908d1c3)|Win32 DLL|injector|2018-12-21 16:56:06|.|
|[85dc4f704ee017844e84b42d4b17a1c3](https://www.virustotal.com/gui/file/85dc4f704ee017844e84b42d4b17a1c3)|Win32 DLL||2018-12-21 05:25:51|85dc4f704ee017844e84b42d4b17a1c3.virus|
|[50c6e221e5cd4f41973f3d6779ae1c4c](https://www.virustotal.com/gui/file/50c6e221e5cd4f41973f3d6779ae1c4c)|Win32 DLL|Zbot|2018-12-20 16:54:32|wwlib.dll|
|[43b57414a07f69aa87ad3ec85fb06b6d](https://www.virustotal.com/gui/file/43b57414a07f69aa87ad3ec85fb06b6d)|Win32 DLL||2018-12-20 07:37:49|dbghelp.dll|
|[b75bf1c32bcbe5dfd9261dd558b63277](https://www.virustotal.com/gui/file/b75bf1c32bcbe5dfd9261dd558b63277)|Win32 DLL|Zbot|2018-12-20 06:50:10|wwlib.dll|
|[473fdfefa92725099ca87e992edbc92c](https://www.virustotal.com/gui/file/473fdfefa92725099ca87e992edbc92c)|unknown|Chanitor|2018-12-20 06:10:29|doc.doc|
|[e0e15fa6ac800ed8511ed775cf59bfc6](https://www.virustotal.com/gui/file/e0e15fa6ac800ed8511ed775cf59bfc6)|GZIP||2018-12-18 07:34:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT32/WinWord.bin.gz|
|[189a078150b12baff608fc18af4bb837](https://www.virustotal.com/gui/file/189a078150b12baff608fc18af4bb837)|PNG||2018-12-18 03:56:09|gwpvrjhv.Exif|
|[f6c672a15b2c5101279a6420f8d4ecc7](https://www.virustotal.com/gui/file/f6c672a15b2c5101279a6420f8d4ecc7)|Win32 DLL||2018-12-18 03:53:31|dbghelp.dll|
|[2756b2f6ba5bcf811c8baced5e98b79f](https://www.virustotal.com/gui/file/2756b2f6ba5bcf811c8baced5e98b79f)|Win32 DLL|Zbot|2018-12-12 17:49:01|.|
|[7952a4ba4bd88b64a68ebe0ee2b277b4](https://www.virustotal.com/gui/file/7952a4ba4bd88b64a68ebe0ee2b277b4)|Win32 DLL||2018-12-12 06:53:11|AFUtil.dll|
|[de409b2fe935ca61066908a92e80be29](https://www.virustotal.com/gui/file/de409b2fe935ca61066908a92e80be29)|Win32 DLL|Zbot|2018-12-10 07:31:11|wwlib.dll|
|[a530410bca453c93b65d0de465c428e4](https://www.virustotal.com/gui/file/a530410bca453c93b65d0de465c428e4)|Win32 DLL|Zbot|2018-12-07 04:50:35|wwlib.dll|
|[7338852de96796d7f733123f04dd1ae9](https://www.virustotal.com/gui/file/7338852de96796d7f733123f04dd1ae9)|Win32 DLL|Zbot|2018-12-06 17:40:33|.|
|[89e3f31c6261f4725b891c8fd29049c9](https://www.virustotal.com/gui/file/89e3f31c6261f4725b891c8fd29049c9)|RAR|Zbot|2018-12-06 06:39:33|d21d9c66e8b23946b022678c78db324e53b8ad70fd97907bdc0674b154c1e060.bin|
|[906a6898d099eb50c570a4014c1760f5](https://www.virustotal.com/gui/file/906a6898d099eb50c570a4014c1760f5)|Win32 DLL|Zbot|2018-12-06 01:43:22|wwlib.dll|
|[611f35b485bf2b79db911842bb9d4e8f](https://www.virustotal.com/gui/file/611f35b485bf2b79db911842bb9d4e8f)|Win32 DLL|injector|2018-12-04 17:19:07|.|
|[c313f8a5fd8ca391fc85193bc879ab02](https://www.virustotal.com/gui/file/c313f8a5fd8ca391fc85193bc879ab02)|TXT|cometer|2018-12-04 02:51:49|Content marketing Kaspersky.doc|
|[ac5f18f1c20901472d4708bd06a2d191](https://www.virustotal.com/gui/file/ac5f18f1c20901472d4708bd06a2d191)|Win32 DLL|Zbot|2018-12-02 17:18:30|.|
|[db81a7e405822be63634001ec0503620](https://www.virustotal.com/gui/file/db81a7e405822be63634001ec0503620)|Win32 DLL|Zbot|2018-12-02 12:27:01|wwlib.dll|
|[9bcd0b2590c53e4c0ed5614b127c6ba7](https://www.virustotal.com/gui/file/9bcd0b2590c53e4c0ed5614b127c6ba7)|Win32 DLL|Zbot|2018-12-01 10:48:10|wwlib.dll|
|[60501717f81eacd54facecf3ebadc306](https://www.virustotal.com/gui/file/60501717f81eacd54facecf3ebadc306)|ZIP|oceanlotus|2018-11-30 11:26:36|ACB_report_transfer_ID_82568249.zip|
|[865a7e3cd87b5bc5feec9d61313f2944](https://www.virustotal.com/gui/file/865a7e3cd87b5bc5feec9d61313f2944)|Win32 DLL|Zbot|2018-11-29 19:31:49|.|
|[aad445e7ffc5ce463996e5db13350c5b](https://www.virustotal.com/gui/file/aad445e7ffc5ce463996e5db13350c5b)|Win32 DLL|Zbot|2018-11-29 11:00:52|wwlib.dll|
|[f7c9f97bf23938ce89f99b5684fcb147](https://www.virustotal.com/gui/file/f7c9f97bf23938ce89f99b5684fcb147)|Win32 EXE|Zbot|2018-11-28 18:50:11|.|
|[878fa022bd5e5caf678fe8d728ce42ee](https://www.virustotal.com/gui/file/878fa022bd5e5caf678fe8d728ce42ee)|DOCX|sagent|2018-11-25 01:29:24|7760f14ec37ddc36cd034724486d918cea39825a79c0df80cf59e046b96722f2.bin|
|[1211dea7b68129d48513662e546c6e21](https://www.virustotal.com/gui/file/1211dea7b68129d48513662e546c6e21)|Win32 DLL|Zbot|2018-11-23 00:48:14|1211dea7b68129d48513662e546c6e21.virus|
|[305d992821740a9cbbda9b3a2b50a67c](https://www.virustotal.com/gui/file/305d992821740a9cbbda9b3a2b50a67c)|Win32 DLL|Zbot|2018-11-23 00:46:02|305d992821740a9cbbda9b3a2b50a67c.virus|
|[5bc6fb202698bad5d9d0b0b4ea65e402](https://www.virustotal.com/gui/file/5bc6fb202698bad5d9d0b0b4ea65e402)|GZIP|ursu|2018-11-21 02:45:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT32/rastls.dll.bin.gz|
|[260293cb1f54dada4f4b1664ad7a76aa](https://www.virustotal.com/gui/file/260293cb1f54dada4f4b1664ad7a76aa)|Win32 EXE||2018-11-20 21:04:29| |
|[7e5fff83654c434724f3f73b5cab3071](https://www.virustotal.com/gui/file/7e5fff83654c434724f3f73b5cab3071)|Win32 DLL|Ursu|2018-11-20 02:43:06|mcvsocfg.dll|
|[a43b3af9c88bf86e0f285563cf4f38c2](https://www.virustotal.com/gui/file/a43b3af9c88bf86e0f285563cf4f38c2)|Win32 DLL|Ursu|2018-11-19 12:53:47|mcvsocfg.dll|
|[7b14d6c5194fab75e23f12ab4afa989b](https://www.virustotal.com/gui/file/7b14d6c5194fab75e23f12ab4afa989b)|Win32 EXE||2018-11-18 09:44:20|7zS.sfx|
|[9b4c57e61f4df3b546aedf58b2f299cf](https://www.virustotal.com/gui/file/9b4c57e61f4df3b546aedf58b2f299cf)|Win32 DLL||2018-11-17 17:34:00|.|
|[2e780e2ff20a28d4248582f11d245d78](https://www.virustotal.com/gui/file/2e780e2ff20a28d4248582f11d245d78)|DEX||2018-11-16 11:37:31|015d5b3d5d2e968a36dfec32dfaba68a83807d7ab3a683c7123b716fc7024668.bin|
|[41f717eda9bc37de6ea584597f60521f](https://www.virustotal.com/gui/file/41f717eda9bc37de6ea584597f60521f)|Win32 DLL|Zbot|2018-11-15 16:59:54|.|
|[e94db0411f1445098d081eef53808607](https://www.virustotal.com/gui/file/e94db0411f1445098d081eef53808607)|Win32 DLL|oceanlotus|2018-11-15 16:40:22|{9FBAA883-1709-4DE3-8C1B-48683F740A5F}.clsid|
|[bd53932f7358cef94c85ff341d9277a5](https://www.virustotal.com/gui/file/bd53932f7358cef94c85ff341d9277a5)|Win32 EXE|oceanlotus|2018-11-15 16:36:58|rstrui.exe|
|[3c04352c5230b8cbaa12f262dc01d335](https://www.virustotal.com/gui/file/3c04352c5230b8cbaa12f262dc01d335)|Win32 DLL|Zbot|2018-11-15 09:56:29|goopdate.dll|
|[399e61f3799bd4cb99fc0ec35952d321](https://www.virustotal.com/gui/file/399e61f3799bd4cb99fc0ec35952d321)|Win32 DLL||2018-11-13 07:09:57|product_info.dll|
|[b858c08cf7807e462ca335233bd83fe7](https://www.virustotal.com/gui/file/b858c08cf7807e462ca335233bd83fe7)|unknown|Chanitor|2018-11-12 09:33:38|Scan_Mau_Ao_Thun.doc|
|[e2aed850c18449a43886fc79b342132f](https://www.virustotal.com/gui/file/e2aed850c18449a43886fc79b342132f)|DOCX|o97m|2018-11-12 02:59:20|Ho Chi Minh.docx|
|[2ef800fc1070b7920fb63231189c431a](https://www.virustotal.com/gui/file/2ef800fc1070b7920fb63231189c431a)|Win64 DLL||2018-11-09 16:40:54|myfile.exe|
|[87a421dcf17d40d8157a0d8f1dca6585](https://www.virustotal.com/gui/file/87a421dcf17d40d8157a0d8f1dca6585)|RTF|CVE-2017-11882|2018-11-07 09:42:05|a.txt|
|[d65287550672dac1a89b804c90e7accf](https://www.virustotal.com/gui/file/d65287550672dac1a89b804c90e7accf)|Win32 DLL||2018-11-06 13:36:28|c30198e0b0e470d4ac8821bd14bb754466e7974f1c20be8b300961e9e89ed1ea.bin|
|[5c9ef8b5263651a08ea1b79057a5ee28](https://www.virustotal.com/gui/file/5c9ef8b5263651a08ea1b79057a5ee28)|unknown|Chanitor|2018-11-06 07:53:48|test.doc|
|[2d6a6597f99de1ccde96cc1ff9e780a6](https://www.virustotal.com/gui/file/2d6a6597f99de1ccde96cc1ff9e780a6)|Win64 DLL||2018-11-06 07:45:46|main_background.png|
|[dca697a6641827b229859d6101c75291](https://www.virustotal.com/gui/file/dca697a6641827b229859d6101c75291)|Win32 DLL||2018-11-05 09:11:31|ldl32.jpg.txt|
|[71f512da26deeeceb7e41fbb6a5e3267](https://www.virustotal.com/gui/file/71f512da26deeeceb7e41fbb6a5e3267)|Win32 DLL||2018-11-03 08:53:36|71f512da26deeeceb7e41fbb6a5e3267.virus|
|[877138e47a77e20bffb058e8f94faf1e](https://www.virustotal.com/gui/file/877138e47a77e20bffb058e8f94faf1e)|DEX||2018-11-01 20:48:53| |
|[313b354f5a181f73cdae97703e577071](https://www.virustotal.com/gui/file/313b354f5a181f73cdae97703e577071)|Win32 DLL||2018-10-25 09:33:44|product_info.dll|
|[df4c45a072eb97740d3f5aefd1231fab](https://www.virustotal.com/gui/file/df4c45a072eb97740d3f5aefd1231fab)|Win32 EXE||2018-10-25 08:38:37|rapidashrotomheat-{4D86795A-31C8-4607-A331-CB784D142D24}-v551.exe|
|[7df61bc3a146fcf56fe1bbd3c26ea8c0](https://www.virustotal.com/gui/file/7df61bc3a146fcf56fe1bbd3c26ea8c0)|Win32 DLL|Zbot|2018-10-22 19:56:25|7df61bc3a146fcf56fe1bbd3c26ea8c0.virobj|
|[cee866b07dab5d9b1e35ee06917cab6d](https://www.virustotal.com/gui/file/cee866b07dab5d9b1e35ee06917cab6d)|Win32 EXE||2018-10-19 15:45:33|WinWord|
|[d40b4277e0d417e2e0cff47458ddd62d](https://www.virustotal.com/gui/file/d40b4277e0d417e2e0cff47458ddd62d)|Win32 DLL|Zbot|2018-10-19 11:08:21|wwlib.dll|
|[446b694b1db4b5245dc1d2081c8b0ffd](https://www.virustotal.com/gui/file/446b694b1db4b5245dc1d2081c8b0ffd)|Win32 DLL|Ursu|2018-10-14 09:50:52|rastls.dll|
|[c55f1145ecc9ea52b2872a99a3f04eb4](https://www.virustotal.com/gui/file/c55f1145ecc9ea52b2872a99a3f04eb4)|Win32 DLL||2018-10-11 07:44:16|mcvsocfg.dll|
|[49a2e438309e219fa4d9c51dfb7ffcb1](https://www.virustotal.com/gui/file/49a2e438309e219fa4d9c51dfb7ffcb1)|PNG||2018-10-11 07:43:56|x5j3trra.Png|
|[c69195864e4e02fa2cb5f1a5bd299852](https://www.virustotal.com/gui/file/c69195864e4e02fa2cb5f1a5bd299852)|Win32 DLL|Ursu|2018-10-10 09:37:08|rastls.dll|
|[74b456adf2ae708789fb2d34ecccb954](https://www.virustotal.com/gui/file/74b456adf2ae708789fb2d34ecccb954)|DOCX|injector|2018-10-09 01:06:02|DS-Card-ChienThang-TraVinh.docx|
|[70a64ae401c0a5f091b5382dea2432df](https://www.virustotal.com/gui/file/70a64ae401c0a5f091b5382dea2432df)|Win32 DLL|Zbot|2018-10-05 18:28:54|wwlib.dll|
|[7a6ba3e26c86f3366f544f4553c9d00a](https://www.virustotal.com/gui/file/7a6ba3e26c86f3366f544f4553c9d00a)|Win32 DLL||2018-10-03 00:38:35| |
|[f6068b672a19ce14981df011a55081e4](https://www.virustotal.com/gui/file/f6068b672a19ce14981df011a55081e4)|TXT|Chanitor|2018-10-01 07:37:14|=?UTF-8?B?RGFuaCBzw6FjaCBjw6FjIG5ow6AgxJHhuqV1IHRyYW5oIGLhu4sgYuG6r3QgMi45LmRvYw==?=|
|[6db450c4c756071ecafff425d6183d7d](https://www.virustotal.com/gui/file/6db450c4c756071ecafff425d6183d7d)|unknown|Chanitor|2018-10-01 05:58:48|df8210d20c5eb80d44ba8fa4c41c26c8421dcb20168e4f796e4955e01ebc9e13.bin|
|[240d2c285678f650645b4b810a6d3b1b](https://www.virustotal.com/gui/file/240d2c285678f650645b4b810a6d3b1b)|Win32 EXE||2018-09-30 19:30:29|WinWord|
|[0f877ad5464fcbb12e1c019adf7065cc](https://www.virustotal.com/gui/file/0f877ad5464fcbb12e1c019adf7065cc)|Win32 DLL|Zbot|2018-09-28 19:13:08| |
|[77390c852addc3581d14acf06991982e](https://www.virustotal.com/gui/file/77390c852addc3581d14acf06991982e)|Win32 DLL|Zbot|2018-09-28 03:00:46|wwlib.dll|
|[789780196266f27c5506fa7531f24ee4](https://www.virustotal.com/gui/file/789780196266f27c5506fa7531f24ee4)|Win32 EXE|oceanlotus|2018-09-26 19:13:52|WinWord|
|[90e5ff68bf06cb930ed8c040139c4650](https://www.virustotal.com/gui/file/90e5ff68bf06cb930ed8c040139c4650)|unknown|injector|2018-09-26 07:29:00|90e5ff68bf06cb930ed8c040139c4650.virobj|
|[518f52aabd9a059d181bfe864097091e](https://www.virustotal.com/gui/file/518f52aabd9a059d181bfe864097091e)|Win32 DLL|Zbot|2018-09-26 07:22:02|wwlib.dll|
|[bbeba6edfea62c34ab92a60e86fd7ce7](https://www.virustotal.com/gui/file/bbeba6edfea62c34ab92a60e86fd7ce7)|Win32 DLL||2018-09-26 06:46:01|mcvsocfg.dll|
|[08c984ac6b0e0a291f16d0c249310a14](https://www.virustotal.com/gui/file/08c984ac6b0e0a291f16d0c249310a14)|Win32 DLL||2018-09-23 03:24:53|cd67415dd634fd202fa1f05aa26233c74dc85332f70e11469e02b370f3943b1d.bin|
|[5be415e4b8b6bc4df8fa0a1cbf91c423](https://www.virustotal.com/gui/file/5be415e4b8b6bc4df8fa0a1cbf91c423)|Win32 EXE||2018-09-20 01:53:29|persis32.exe|
|[cab262b84dbd319f3df84f221e5c451f](https://www.virustotal.com/gui/file/cab262b84dbd319f3df84f221e5c451f)|Win32 DLL|Zbot|2018-09-19 08:21:01|wwlib.dll|
|[07ff4f943b202f4e16c227679d9b598a](https://www.virustotal.com/gui/file/07ff4f943b202f4e16c227679d9b598a)|Win32 DLL|Zbot|2018-09-19 07:27:04|wwlib.dll|
|[6b8fc8c9fe4f4ef90b2fcbcc0d24cfc9](https://www.virustotal.com/gui/file/6b8fc8c9fe4f4ef90b2fcbcc0d24cfc9)|Win32 DLL|Zbot|2018-09-19 03:35:52|wwlib.dll|
|[97eeb7d4e8b05709302462a90616b60b](https://www.virustotal.com/gui/file/97eeb7d4e8b05709302462a90616b60b)|Win32 EXE||2018-09-18 16:45:36|WinWord|
|[2f1f8142d479a1daf3cbd404c7c22f9f](https://www.virustotal.com/gui/file/2f1f8142d479a1daf3cbd404c7c22f9f)|Win32 DLL|Zbot|2018-09-18 09:58:28|wwlib.dll|
|[e667b20d107adb25eedc90c185192480](https://www.virustotal.com/gui/file/e667b20d107adb25eedc90c185192480)|Win64 DLL||2018-09-17 14:05:51|SecurityAndMaintenance_Error.bin|
|[dd5ae0c0a7e17d101f570812fec4e5e4](https://www.virustotal.com/gui/file/dd5ae0c0a7e17d101f570812fec4e5e4)|unknown|Chanitor|2018-09-17 10:49:44|94fab926b73a6a5bc71d655c8d611b40e80464da9f1134bfce7b930e23e273ab.bin|
|[72263750df84e24fe645206a51772c88](https://www.virustotal.com/gui/file/72263750df84e24fe645206a51772c88)|DOCX||2018-09-17 06:57:10|HopDong-XXX-TP-092018.docx|
|[aff67ad9c813dc14c35bdcc427c5b417](https://www.virustotal.com/gui/file/aff67ad9c813dc14c35bdcc427c5b417)|Win32 DLL|Ursu|2018-09-15 08:12:14|rastls.dll|
|[8a346bca691b8cf2cd18100f59f3352f](https://www.virustotal.com/gui/file/8a346bca691b8cf2cd18100f59f3352f)|Win32 EXE||2018-09-15 08:10:02|7zS.sfx|
|[8dedd426a43b7b012b215ac08ead4dcc](https://www.virustotal.com/gui/file/8dedd426a43b7b012b215ac08ead4dcc)|Win32 DLL||2018-09-14 12:02:52|mcvsocfg.dll|
|[e296f14ca16cfcaae853f59cc9e08c54](https://www.virustotal.com/gui/file/e296f14ca16cfcaae853f59cc9e08c54)|Win32 DLL|PlugX|2018-09-14 11:26:51|adobe_caps.dll|
|[56142bbd9a218b2f6ce56350c0a88d43](https://www.virustotal.com/gui/file/56142bbd9a218b2f6ce56350c0a88d43)|Win32 DLL|oceanlotus|2018-09-13 09:55:33|3019f9c7763644bc0159ce433199b2b12f04843c3c8e231557c4f732317f4223.bin|
|[7a81a6fdaee15162a3a231751bdd0259](https://www.virustotal.com/gui/file/7a81a6fdaee15162a3a231751bdd0259)|PNG||2018-09-13 03:31:44|ummrzhwp.Emf|
|[ec52a11625bdb4aad3740ff8cc6d8c0f](https://www.virustotal.com/gui/file/ec52a11625bdb4aad3740ff8cc6d8c0f)|Win32 DLL||2018-09-13 03:30:38|wsc.dll|
|[ee836e0f7a40571523bf56dba59898f6](https://www.virustotal.com/gui/file/ee836e0f7a40571523bf56dba59898f6)|DOTM|Chanitor|2018-09-13 02:20:00|indo.docx|
|[2aa2d2cc63122b498c82f76244646199](https://www.virustotal.com/gui/file/2aa2d2cc63122b498c82f76244646199)|Win32 EXE||2018-09-12 11:14:52|THICH-THONG-LAC-HANH-THAP-THIEN-VIET-NAM (1).EXE|
|[3a574c28beca4f3c94d30e3cf3979f4c](https://www.virustotal.com/gui/file/3a574c28beca4f3c94d30e3cf3979f4c)|DOCX|sagent|2018-09-11 10:21:11|BBLV_ASC_DG_092018.docx|
|[93c3d6cffdcb0a2f29844ff130a920be](https://www.virustotal.com/gui/file/93c3d6cffdcb0a2f29844ff130a920be)|Win32 DLL|Zbot|2018-09-08 22:16:36|wwlib.dll|
|[a406626173132c8bd6fe52672deacbe7](https://www.virustotal.com/gui/file/a406626173132c8bd6fe52672deacbe7)|Win32 DLL|Zbot|2018-09-08 18:03:41|.|
|[ab1a68bbbedee58a4eeb575d0f7ef6fa](https://www.virustotal.com/gui/file/ab1a68bbbedee58a4eeb575d0f7ef6fa)|Win32 EXE||2018-09-08 17:22:56|.|
|[f5ad93917cd5b119f82b52a0d62f4a93](https://www.virustotal.com/gui/file/f5ad93917cd5b119f82b52a0d62f4a93)|Win32 DLL|Zbot|2018-09-07 03:43:17|wwlib.dll|
|[cc7b9ee1b026e16a9d37e3988a714479](https://www.virustotal.com/gui/file/cc7b9ee1b026e16a9d37e3988a714479)|Win32 EXE|Zbot|2018-09-07 01:19:24|WinWord|
|[9a10292157ac3748212fb77769873f6c](https://www.virustotal.com/gui/file/9a10292157ac3748212fb77769873f6c)|Win32 DLL|Zbot|2018-09-06 09:54:28|wwlib.dll|
|[6291eabf6a8c58cad6a04879b7ba229f](https://www.virustotal.com/gui/file/6291eabf6a8c58cad6a04879b7ba229f)|Win32 DLL|Zbot|2018-09-06 04:55:26|6291eabf6a8c58cad6a04879b7ba229f.vir|
|[49e969a9312ee2ae639002716276073f](https://www.virustotal.com/gui/file/49e969a9312ee2ae639002716276073f)|Win32 DLL||2018-09-03 10:48:05| |
|[5079cb166df41233a1017d5e0150c17a](https://www.virustotal.com/gui/file/5079cb166df41233a1017d5e0150c17a)|ZIP||2018-09-01 05:18:23|192e059ead09d51992197b659f1ae90144a175d1b84570588712b360e76cd1b2.bin|
|[553a59d669305f916282235e055e1d2e](https://www.virustotal.com/gui/file/553a59d669305f916282235e055e1d2e)|Win32 DLL||2018-09-01 04:18:20|1a0277554bfbc0e6cad417e8916bbec033d2fae6556a9cf498144eb317edacce.sample|
|[e692406fe916f5417cb7219316089e3a](https://www.virustotal.com/gui/file/e692406fe916f5417cb7219316089e3a)|Win32 DLL|Zbot|2018-09-01 01:43:17|wwlib.dll|
|[05fe6e258ebb0c38e40e23680132c86a](https://www.virustotal.com/gui/file/05fe6e258ebb0c38e40e23680132c86a)|Win32 DLL|PlugX|2018-08-31 17:15:19| |
|[425a30d849f8aac6a7bc066fecb4cf8f](https://www.virustotal.com/gui/file/425a30d849f8aac6a7bc066fecb4cf8f)|Win32 EXE|Zbot|2018-08-31 00:54:56|WinWord|
|[80934c70c9bbc05173ea911dcf7a68ae](https://www.virustotal.com/gui/file/80934c70c9bbc05173ea911dcf7a68ae)|Win32 DLL||2018-08-30 12:41:23|0830(24).dll|
|[c94f6b7047e40e572b4e0b0574b64821](https://www.virustotal.com/gui/file/c94f6b7047e40e572b4e0b0574b64821)|Win32 EXE|oceanlotus|2018-08-27 10:40:25|c94f6b7047e40e572b4e0b0574b64821.virus|
|[d2ae8034157eda6a004324981ceabf5c](https://www.virustotal.com/gui/file/d2ae8034157eda6a004324981ceabf5c)|Mach-O executable|oceanlotus|2018-08-25 04:15:10| |
|[cf0b74fe79156694a2e3ea81e3bb1f85](https://www.virustotal.com/gui/file/cf0b74fe79156694a2e3ea81e3bb1f85)|Win32 DLL|Zbot|2018-08-23 17:30:07|.|
|[7cf0c09c8f5c46a32cf2ec29e9e1e88f](https://www.virustotal.com/gui/file/7cf0c09c8f5c46a32cf2ec29e9e1e88f)|Win32 DLL|oceanlotus|2018-08-23 10:52:13|{9FBAA883-1709-4DE3-8C1B-48683F740A5F}.clsid|
|[4aa7016e9dfa67ed6ff0dee0e62cd81e](https://www.virustotal.com/gui/file/4aa7016e9dfa67ed6ff0dee0e62cd81e)|Win32 EXE|oceanlotus|2018-08-23 10:52:11|rstrui.exe|
|[2ea902abe453b70cf77e402cc16eb552](https://www.virustotal.com/gui/file/2ea902abe453b70cf77e402cc16eb552)|Win32 EXE|Zbot|2018-08-23 10:49:39|WinWord|
|[546bb6ef89bebfb053999777f6930d7e](https://www.virustotal.com/gui/file/546bb6ef89bebfb053999777f6930d7e)|Win32 DLL|graftor|2018-08-22 19:53:49|.|
|[c78fd680494b505525d706c285d5ebce](https://www.virustotal.com/gui/file/c78fd680494b505525d706c285d5ebce)|Win32 DLL|Zbot|2018-08-22 05:31:01| |
|[4e7e56be0fdea72564ba761916897895](https://www.virustotal.com/gui/file/4e7e56be0fdea72564ba761916897895)|Win32 DLL||2018-08-21 10:23:03| |
|[c28abdfe45590af0ef5c4e7a96d4b979](https://www.virustotal.com/gui/file/c28abdfe45590af0ef5c4e7a96d4b979)|Win32 DLL|Zbot|2018-08-21 08:16:02|wwlib.dll|
|[4d6eb6f2c2e8350d87321802468d99a7](https://www.virustotal.com/gui/file/4d6eb6f2c2e8350d87321802468d99a7)|Win32 DLL|Ursu|2018-08-19 19:50:13| |
|[21ec7f19f7073341234274808b1a2689](https://www.virustotal.com/gui/file/21ec7f19f7073341234274808b1a2689)|Win32 DLL||2018-08-19 13:20:13|codexgigas_1977be8c3a8db8ffa0b215022436511feede37c4|
|[24b9ad44aa122a6036a1044d065e6a91](https://www.virustotal.com/gui/file/24b9ad44aa122a6036a1044d065e6a91)|Win32 DLL||2018-08-19 13:20:07|codexgigas_2eb0eeae3cb9c1f56549c11436a3c84820250ff2|
|[b45c2960bd2b1527eb67908a359fbe8d](https://www.virustotal.com/gui/file/b45c2960bd2b1527eb67908a359fbe8d)|Win32 DLL||2018-08-19 13:20:04|codexgigas_187542f858f53f7e904faf62b54f1df2f189d9c2|
|[b9711f43cd199c7c08421fbb3f867f2f](https://www.virustotal.com/gui/file/b9711f43cd199c7c08421fbb3f867f2f)|Win32 EXE||2018-08-19 10:27:02| |
|[fb03b51d867360c300edd9267b70a22f](https://www.virustotal.com/gui/file/fb03b51d867360c300edd9267b70a22f)|Mach-O executable|oceanlotus|2018-08-17 06:09:06|Scanned Investment Report-July 2018|
|[a3d09d969df1742a7cc9511f07e9b44b](https://www.virustotal.com/gui/file/a3d09d969df1742a7cc9511f07e9b44b)|ZIP|oceanlotus|2018-08-16 15:59:42|Scanned Investment Report-July 2018.zip|
|[4bb4d19b42e74bd11459c9358c1a6f01](https://www.virustotal.com/gui/file/4bb4d19b42e74bd11459c9358c1a6f01)|Win32 DLL|Zbot|2018-08-16 01:15:58|wwlib.dll|
|[f42611ac0ea2c66d9f27ae14706c1b00](https://www.virustotal.com/gui/file/f42611ac0ea2c66d9f27ae14706c1b00)|Win32 DLL|Zbot|2018-08-15 20:37:57|.|
|[90448ea72f85ccc5565d700725ae9aed](https://www.virustotal.com/gui/file/90448ea72f85ccc5565d700725ae9aed)|Win32 EXE||2018-08-15 20:36:33|.|
|[b4041b514c7b415ec0c71ea6daee0b90](https://www.virustotal.com/gui/file/b4041b514c7b415ec0c71ea6daee0b90)|Win32 DLL||2018-08-15 18:20:20|b4041b514c7b415ec0c71ea6daee0b90.virobj|
|[b123f9151c5e7057f061f3e03c1e8416](https://www.virustotal.com/gui/file/b123f9151c5e7057f061f3e03c1e8416)|TXT|CVE-2017-11882|2018-08-14 21:28:46| |
|[8c9fb42dd4569d90f70e60e250526061](https://www.virustotal.com/gui/file/8c9fb42dd4569d90f70e60e250526061)|Win32 DLL|Kryptik|2018-08-13 13:15:32|%WINDIR%\syswow64\dssvccleanup.cpl|
|[d3c27f779d615a1d3a35dff5e9561eb0](https://www.virustotal.com/gui/file/d3c27f779d615a1d3a35dff5e9561eb0)|unknown|Chanitor|2018-08-12 07:18:23|d3c27f779d615a1d3a35dff5e9561eb0.virobj|
|[3679911b0566259a1e5255eec7511c0e](https://www.virustotal.com/gui/file/3679911b0566259a1e5255eec7511c0e)|Win32 DLL||2018-08-11 06:19:28|aaf3d294e9103cdbf33fe5ab1e28a7bffa181b5d9faa690c98816535e50dc8c3.bin|
|[bc69b67f2bbbcff982a1f1531c8be1d3](https://www.virustotal.com/gui/file/bc69b67f2bbbcff982a1f1531c8be1d3)|Win32 DLL|Zbot|2018-08-11 05:05:15| |
|[c9093362a83b0e7672a161fd9ef9498a](https://www.virustotal.com/gui/file/c9093362a83b0e7672a161fd9ef9498a)|Win32 DLL|Zbot|2018-08-10 18:55:20| |
|[38f9655c72474b6c97dc9db9b3609677](https://www.virustotal.com/gui/file/38f9655c72474b6c97dc9db9b3609677)|Win32 DLL|Zbot|2018-08-10 18:07:00| |
|[4282c6633122dce395de35c05159282d](https://www.virustotal.com/gui/file/4282c6633122dce395de35c05159282d)|Win32 EXE||2018-08-10 08:08:49|WinWord|
|[baaaf5d1b48bbfc40581863c0865c69d](https://www.virustotal.com/gui/file/baaaf5d1b48bbfc40581863c0865c69d)|Win32 EXE||2018-08-09 19:00:10|fontview|
|[d7360ea8b1c41a77f75fa00a72d6bf26](https://www.virustotal.com/gui/file/d7360ea8b1c41a77f75fa00a72d6bf26)|Win32 EXE||2018-08-05 15:20:55|.|
|[6c2a8612c6511df2876bdb124c33d3e1](https://www.virustotal.com/gui/file/6c2a8612c6511df2876bdb124c33d3e1)|Win32 DLL|Zbot|2018-08-01 16:29:07|7be613237b57fbc3cb83d001efadeed9936a2f519c514ab80de8285bdc5a666c.bin|
|[1bcd3dae242631dee8a68507ab66a2bd](https://www.virustotal.com/gui/file/1bcd3dae242631dee8a68507ab66a2bd)|Win32 DLL|Zbot|2018-08-01 14:04:29|hp6000.dll|
|[50ce0766945f5f954bdb4e4f26dd4cd8](https://www.virustotal.com/gui/file/50ce0766945f5f954bdb4e4f26dd4cd8)|Win32 EXE|oceanlotus|2018-08-01 13:59:53|7zS.sfx|
|[399fb777ab7954d1a743c89bf6057588](https://www.virustotal.com/gui/file/399fb777ab7954d1a743c89bf6057588)|Win32 EXE||2018-08-01 13:59:39|INSTALL.ROBOTOFONT.EXE|
|[9972111cc944d20c9b315fd56eb3a177](https://www.virustotal.com/gui/file/9972111cc944d20c9b315fd56eb3a177)|Win32 DLL|Zbot|2018-07-31 23:20:36| |
|[be59eeefd4053707d87927f3d81aa6a2](https://www.virustotal.com/gui/file/be59eeefd4053707d87927f3d81aa6a2)|LNK||2018-07-31 15:01:52| |
|[1a1c8d7fe98620c91eb1059f8c8f1bf6](https://www.virustotal.com/gui/file/1a1c8d7fe98620c91eb1059f8c8f1bf6)|Win32 DLL|Ursu|2018-07-31 07:44:05|myfile.exe|
|[d001cc57871403e783efc22076b119de](https://www.virustotal.com/gui/file/d001cc57871403e783efc22076b119de)|Win32 DLL|Ursu|2018-07-31 07:13:10|mcvsocfg.dll|
|[bf040c081ad1b051fdf3e8ba458d3a9c](https://www.virustotal.com/gui/file/bf040c081ad1b051fdf3e8ba458d3a9c)|Win32 DLL|Zbot|2018-07-28 17:43:04|77805a46f73e118ae2428f8c22ba28f79f7c60aeb6305d41c0bf3ebb9ce70f94.bin|
|[554ff0fe41522341a0aa8afcb2f2a2d2](https://www.virustotal.com/gui/file/554ff0fe41522341a0aa8afcb2f2a2d2)|Win32 DLL||2018-07-28 11:47:11|FaultRep.dll|
|[0e80ea3183aace55705fa7b040f4b431](https://www.virustotal.com/gui/file/0e80ea3183aace55705fa7b040f4b431)|Win32 DLL|Ursu|2018-07-27 20:04:52| |
|[90db0c5196727ed62516e67d6923cba9](https://www.virustotal.com/gui/file/90db0c5196727ed62516e67d6923cba9)|Win32 DLL||2018-07-27 01:41:59|goopdate.dll|
|[65a1b77b6e718260194aeeb50c7352e6](https://www.virustotal.com/gui/file/65a1b77b6e718260194aeeb50c7352e6)|Win32 DLL|Ursu|2018-07-26 20:25:09| |
|[7dace8f91a35766e9c66dd6258552b02](https://www.virustotal.com/gui/file/7dace8f91a35766e9c66dd6258552b02)|Win32 DLL||2018-07-26 07:16:26|wwlib.dll|
|[200033d043c13b88d121f2c1d8d2dfdf](https://www.virustotal.com/gui/file/200033d043c13b88d121f2c1d8d2dfdf)|Win32 DLL|Zbot|2018-07-25 04:32:35|wwlib.dll|
|[26ea45578e05040deb0cc46ea3103184](https://www.virustotal.com/gui/file/26ea45578e05040deb0cc46ea3103184)|Win32 DLL|Zbot|2018-07-25 04:05:08|wwlib.dll|
|[c117f8fd4399932627b83fe3ad481e86](https://www.virustotal.com/gui/file/c117f8fd4399932627b83fe3ad481e86)|Win32 DLL|Ursu|2018-07-23 18:50:20| |
|[ebf6a950b26261cd353015ed567c6ac6](https://www.virustotal.com/gui/file/ebf6a950b26261cd353015ed567c6ac6)|Win32 DLL||2018-07-21 01:15:14|{7c1d6a86-94ff-4113-a04d-84251023012a}.ocx|
|[3dfc49add45ad35a7c6e21054a53a351](https://www.virustotal.com/gui/file/3dfc49add45ad35a7c6e21054a53a351)|Win32 EXE||2018-07-20 03:04:43|WinWord|
|[1675afb65f32c7b148f5d8acbeed2acc](https://www.virustotal.com/gui/file/1675afb65f32c7b148f5d8acbeed2acc)|Win32 DLL||2018-07-19 06:54:22|123.dll.bak|
|[9453f31cdb02533d509948cc4fd0c44f](https://www.virustotal.com/gui/file/9453f31cdb02533d509948cc4fd0c44f)|TXT|o97m|2018-07-17 07:12:05|FW Report on demonstration of former CNRP in Republic of Korea.doc|
|[760024b35e51a06dcde2128843b1bfdb](https://www.virustotal.com/gui/file/760024b35e51a06dcde2128843b1bfdb)|Win32 DLL|Zbot|2018-07-12 22:46:42|wwlib.dll|
|[09b821f50272322d0410560bb41331f0](https://www.virustotal.com/gui/file/09b821f50272322d0410560bb41331f0)|Win32 DLL|Ursu|2018-07-12 03:11:17|McUtil.dll|
|[221e9962c9e7da3646619ccc47338ee8](https://www.virustotal.com/gui/file/221e9962c9e7da3646619ccc47338ee8)|Win32 DLL||2018-07-11 08:28:24| |
|[ca954cd8fc2298ba32900187cb5d391f](https://www.virustotal.com/gui/file/ca954cd8fc2298ba32900187cb5d391f)|Win32 DLL|PlugX|2018-07-03 06:03:44|rastls.dll|
|[3163e1a5b60621232f47bfe90ef0526d](https://www.virustotal.com/gui/file/3163e1a5b60621232f47bfe90ef0526d)|Win32 EXE||2018-07-03 05:55:10|Auto Report By NQT_.exe|
|[62b4e883e87da2a0fd4265a69133d32a](https://www.virustotal.com/gui/file/62b4e883e87da2a0fd4265a69133d32a)|Win32 EXE||2018-06-22 04:21:30| |
|[7cbdb33a65244b98eac4499b35ce77a3](https://www.virustotal.com/gui/file/7cbdb33a65244b98eac4499b35ce77a3)|Win32 DLL||2018-06-20 16:31:07|codexgigas_e3ef90c4a4114562d34525851da1e87992f74398|
|[031a9dd69241ab6cbb052dcaa4cb75cc](https://www.virustotal.com/gui/file/031a9dd69241ab6cbb052dcaa4cb75cc)|RTF|CVE-2017-8570|2018-06-20 13:17:41|333.doc|
|[e9b2763cf4940c285c5396db7b0b55bd](https://www.virustotal.com/gui/file/e9b2763cf4940c285c5396db7b0b55bd)|RTF|CVE-2017-8570|2018-06-20 13:14:54|666.doc|
|[f64e2a40c0da47f05d9320b80a07cda2](https://www.virustotal.com/gui/file/f64e2a40c0da47f05d9320b80a07cda2)|Win32 DLL|Kryptik|2018-06-20 06:40:48|NetworkStateChangeTask.cpl|
|[3a869e8a7b7022082d5a8661ed2fb602](https://www.virustotal.com/gui/file/3a869e8a7b7022082d5a8661ed2fb602)|Win32 DLL|cometer|2018-06-13 18:57:36|3|
|[ac72f556dbeca2ba52ee848f3a3a7b1c](https://www.virustotal.com/gui/file/ac72f556dbeca2ba52ee848f3a3a7b1c)|Win32 DLL|Ursu|2018-06-13 18:47:29| |
|[f198ab61bc0bf8e5ae8c237d93c7b95d](https://www.virustotal.com/gui/file/f198ab61bc0bf8e5ae8c237d93c7b95d)|Win32 DLL||2018-06-13 02:10:23|FaultRep.dll|
|[1459ddff4db04887e348271df706ddbb](https://www.virustotal.com/gui/file/1459ddff4db04887e348271df706ddbb)|Win32 DLL|Ursu|2018-06-11 04:49:14| |
|[f82798567913257770efd7d40ec5995f](https://www.virustotal.com/gui/file/f82798567913257770efd7d40ec5995f)|Win32 DLL|Zbot|2018-06-09 06:28:53|wwlib.dll|
|[e3e99f6d1333ca76a80ba2899a4e2587](https://www.virustotal.com/gui/file/e3e99f6d1333ca76a80ba2899a4e2587)|Rich Text Format|o97m|2018-06-08 07:27:37|cb8c176a29003a0474837a6c6dbb871b9f20a520a9232c4705fbd5a87ead1380.bin|
|[279971ef916c66c77be32cf6a7915802](https://www.virustotal.com/gui/file/279971ef916c66c77be32cf6a7915802)|Win32 DLL|PlugX|2018-06-01 03:05:26|rastls.dll|
|[25369433299d553fb4c84321649d4d5c](https://www.virustotal.com/gui/file/25369433299d553fb4c84321649d4d5c)|Win32 DLL||2018-06-01 01:25:10|wwlib.dll|
|[a91e0c32ea93465b80d1bab41193ea4f](https://www.virustotal.com/gui/file/a91e0c32ea93465b80d1bab41193ea4f)|Win32 DLL|graftor|2018-05-29 09:23:41|wwlib.dll|
|[58b366b07b12c8cc8b4cbcd9a1905f33](https://www.virustotal.com/gui/file/58b366b07b12c8cc8b4cbcd9a1905f33)|unknown||2018-05-28 10:55:11|Don khieu nai.doc|
|[2adbd508ab4c256bbbfee9f4acb5f56d](https://www.virustotal.com/gui/file/2adbd508ab4c256bbbfee9f4acb5f56d)|Win32 EXE|Ursu|2018-05-28 09:56:53|WinWord|
|[a56858df2a815c6023f5debb6a003ed4](https://www.virustotal.com/gui/file/a56858df2a815c6023f5debb6a003ed4)|Win32 EXE||2018-05-25 08:09:55|WinWord|
|[ce5bae8714ddfca9eb3bb24ee60f042d](https://www.virustotal.com/gui/file/ce5bae8714ddfca9eb3bb24ee60f042d)|Android||2018-05-20 14:11:40| |
|[c83f5589dfdfb07b8b7966202188dee5](https://www.virustotal.com/gui/file/c83f5589dfdfb07b8b7966202188dee5)|DEX||2018-05-20 02:59:08| |
|[b1990e19efaf88206f7bffe9df0d9419](https://www.virustotal.com/gui/file/b1990e19efaf88206f7bffe9df0d9419)|Win32 DLL|agentwdcr|2018-05-19 08:05:54|a8f776bd3a9593e963b567ce790033fec2804ea0afb40a92d40e21d8f33d066f.bin|
|[4b8140e7b82ac4d0ab662da4eb487ff0](https://www.virustotal.com/gui/file/4b8140e7b82ac4d0ab662da4eb487ff0)|Win32 EXE|Ursu|2018-05-18 14:09:39|CAJVieweru.exe|
|[2941e87ffe0d850af6e337c18672b35d](https://www.virustotal.com/gui/file/2941e87ffe0d850af6e337c18672b35d)|Win32 EXE|oceanlotus|2018-05-15 00:12:43|Google Update Setup|
|[751c735585fdff7cb1bf2ae2f281393c](https://www.virustotal.com/gui/file/751c735585fdff7cb1bf2ae2f281393c)|Win32 DLL|Zbot|2018-05-08 07:09:50|wwlib.dll|
|[d2d332fd3e0aa7b7745d32756e704e12](https://www.virustotal.com/gui/file/d2d332fd3e0aa7b7745d32756e704e12)|Win32 DLL||2018-05-08 06:14:15|{db646ea2-5d7a-4f27-b7e1-642bd9555af5}.ocx|
|[8bf63f758356c2b40f1249c108c37257](https://www.virustotal.com/gui/file/8bf63f758356c2b40f1249c108c37257)|Win32 EXE|oceanlotus|2018-05-08 06:09:21|Excel|
|[f775cc387a55831386e44dd00ef9723e](https://www.virustotal.com/gui/file/f775cc387a55831386e44dd00ef9723e)|Win32 DLL|PlugX|2018-05-02 11:48:54|rastls.dll|
|[302c937cc16ee48db4dac3c1ce4f892f](https://www.virustotal.com/gui/file/302c937cc16ee48db4dac3c1ce4f892f)|Win32 DLL|Ursu|2018-05-02 10:42:02| |
|[d6955b482cb67558e2152f6cdd0a2c91](https://www.virustotal.com/gui/file/d6955b482cb67558e2152f6cdd0a2c91)|Win32 DLL|Zbot|2018-04-27 02:07:43|wwlib.dll|
|[d6748b09a7d2c1d0b3979ae2a8e915ca](https://www.virustotal.com/gui/file/d6748b09a7d2c1d0b3979ae2a8e915ca)|Win32 DLL|PlugX|2018-04-24 10:39:27|McUtil.dll|
|[70db1f36fd33ae0d25ba6d19c450f2c1](https://www.virustotal.com/gui/file/70db1f36fd33ae0d25ba6d19c450f2c1)|Win32 EXE|Ursu|2018-04-24 10:34:14|mcoemcpy|
|[2300886ddf8671ed45bcbd8abd7a11c3](https://www.virustotal.com/gui/file/2300886ddf8671ed45bcbd8abd7a11c3)|Win32 DLL|Zbot|2018-04-19 12:08:56|wwlib.dll|
|[f49bc1f08936fad0ff633d927ca1cfba](https://www.virustotal.com/gui/file/f49bc1f08936fad0ff633d927ca1cfba)|Win32 DLL|Zbot|2018-04-18 15:58:05|wwlib.dll.bin|
|[f393fd9046c3b0a90521d637e85d3723](https://www.virustotal.com/gui/file/f393fd9046c3b0a90521d637e85d3723)|Win32 EXE||2018-04-18 10:51:30|WinWord|
|[77b1f47f1a35613568a35996501623cb](https://www.virustotal.com/gui/file/77b1f47f1a35613568a35996501623cb)|Win32 EXE|Ursu|2018-04-17 20:06:37|fontview|
|[e58f436a95f967a324c6df506c76b5a7](https://www.virustotal.com/gui/file/e58f436a95f967a324c6df506c76b5a7)|TXT|CVE-2017-11882|2018-04-13 21:24:53|0d1577802d4560b9ba184a2d13570ba28ed0318eee520f2f7a6c5ef238671dd9.bin|
|[a907cb142ff5b2b789b7cb3bd5a307bc](https://www.virustotal.com/gui/file/a907cb142ff5b2b789b7cb3bd5a307bc)|RTF|CVE-2017-8570|2018-04-13 20:44:02|a907cb142ff5b2b789b7cb3bd5a307bc|
|[a6c2213802846d20b32b2e737b7c3421](https://www.virustotal.com/gui/file/a6c2213802846d20b32b2e737b7c3421)|Win32 DLL|Zbot|2018-04-08 08:40:17|assd|
|[72bebba3542bd86dc68a36fda5dbae76](https://www.virustotal.com/gui/file/72bebba3542bd86dc68a36fda5dbae76)|RTF|CVE-2017-8570|2018-04-05 06:53:22|/home/virustotal/sample/72BEBBA3542BD86DC68A36FDA5DBAE76|
|[3ba092052587122d8072c7249a9f0b44](https://www.virustotal.com/gui/file/3ba092052587122d8072c7249a9f0b44)|Win32 EXE||2018-03-29 21:26:52|%TEMP%\123d393.tmp|
|[2509813a8158fa2603793b085c04c735](https://www.virustotal.com/gui/file/2509813a8158fa2603793b085c04c735)|Win32 EXE|oceanlotus|2018-03-24 00:21:01|2509813a8158fa2603793b085c04c735.virus|
|[cb045406ceec9c368dcaeff6590e3628](https://www.virustotal.com/gui/file/cb045406ceec9c368dcaeff6590e3628)|Win32 EXE||2018-03-23 09:21:26|WinWord|
|[85ae9f9715bb48ec3279edf0e8f38f47](https://www.virustotal.com/gui/file/85ae9f9715bb48ec3279edf0e8f38f47)|Win32 DLL|PlugX|2018-03-23 07:54:07|97ef25ab2dba91324f787298479e82e540cc3ca1|
|[de8f6cbe58e8cd484580798776063c15](https://www.virustotal.com/gui/file/de8f6cbe58e8cd484580798776063c15)|Win32 DLL|Ursu|2018-03-17 21:10:42|McUtil.dll|
|[a08b9a984b28e520cbde839d83db2d14](https://www.virustotal.com/gui/file/a08b9a984b28e520cbde839d83db2d14)|Win32 EXE|ipatre|2018-03-17 20:57:52|AcroRd32.exe|
|[306d3ed0a7c899b5ef9d0e3c91f05193](https://www.virustotal.com/gui/file/306d3ed0a7c899b5ef9d0e3c91f05193)|Mach-O executable|oceanlotus|2018-03-17 03:53:57|306d3ed0a7c899b5ef9d0e3c91f05193.virus|
|[93da064e3fc4422c63fecca93ee1b157](https://www.virustotal.com/gui/file/93da064e3fc4422c63fecca93ee1b157)|unknown||2018-03-14 11:17:16|SyLog.bin|
|[ddcd8a9e925505a426da53ce8c9ec0e3](https://www.virustotal.com/gui/file/ddcd8a9e925505a426da53ce8c9ec0e3)|Win32 DLL|Ursu|2018-03-11 22:20:42|rastls.dll|
|[877ecaa43243f6b57745f72278965467](https://www.virustotal.com/gui/file/877ecaa43243f6b57745f72278965467)|Win32 EXE||2018-03-11 22:17:14|WinWord|
|[0a8f6f8094e77ca1e754b19dcb8a5451](https://www.virustotal.com/gui/file/0a8f6f8094e77ca1e754b19dcb8a5451)|Win32 EXE|strictor|2018-03-07 23:07:01|WinWord|
|[98759cbbb5563335745b70d291da186f](https://www.virustotal.com/gui/file/98759cbbb5563335745b70d291da186f)|Win32 DLL|PlugX|2018-03-07 07:25:53|rastls.dll|
|[f1400c201b590a02597ebfc91b561876](https://www.virustotal.com/gui/file/f1400c201b590a02597ebfc91b561876)|Win32 DLL|PlugX|2018-03-07 07:22:42|rastls.dll|
|[6ecb19b51d50af36179c870f3504c623](https://www.virustotal.com/gui/file/6ecb19b51d50af36179c870f3504c623)|Win32 EXE||2018-03-07 07:22:27|WinWord|
|[109cd896f8e13f925584dbbad400b338](https://www.virustotal.com/gui/file/109cd896f8e13f925584dbbad400b338)|Win32 EXE||2018-03-07 07:20:49|Excel|
|[ab51ce992e4c739f5b47a8e0bc2786ce](https://www.virustotal.com/gui/file/ab51ce992e4c739f5b47a8e0bc2786ce)|Win32 EXE||2018-03-01 09:54:46|fontview|
|[e45d3c493cc0547d70f8de6c019e93a2](https://www.virustotal.com/gui/file/e45d3c493cc0547d70f8de6c019e93a2)|Win32 DLL|PlugX|2018-02-26 10:23:32|c1af2f9a2a274fce21e4de6fac04c011b0e463024f43f5a0b5121c517605a587.sample|
|[e9daf2126f8597b33afbea221ac06395](https://www.virustotal.com/gui/file/e9daf2126f8597b33afbea221ac06395)|Win32 EXE||2018-02-24 09:15:13|Adobe Download Manager|
|[6ed0205b35c7b4fe3fbcd628de779547](https://www.virustotal.com/gui/file/6ed0205b35c7b4fe3fbcd628de779547)|Win32 EXE||2018-02-20 18:28:02|WinWord|
|[c212074b43b6ef811f2a8fb72e670e0c](https://www.virustotal.com/gui/file/c212074b43b6ef811f2a8fb72e670e0c)|Win32 DLL|PlugX|2018-02-18 18:42:07|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT32/McUtil.dll|
|[da71b64e77ad45bab56cf71ecd4f55d4](https://www.virustotal.com/gui/file/da71b64e77ad45bab56cf71ecd4f55d4)|Mach-O executable|oceanlotus|2018-02-14 09:58:54|da71b64e77ad45bab56cf71ecd4f55d4.virus|
|[fd4e2b72bbd5f0f27eb5788cc6a7dedd](https://www.virustotal.com/gui/file/fd4e2b72bbd5f0f27eb5788cc6a7dedd)|DOCM|oceanlotus|2018-02-13 20:52:01|fd4e2b72bbd5f0f27eb5788cc6a7dedd.virus|
|[d3ab84916449601843ad36f3ea8f387a](https://www.virustotal.com/gui/file/d3ab84916449601843ad36f3ea8f387a)|Win32 DLL|PlugX|2018-02-08 05:01:40|70d152f70adb0e906218f6a0504c385478245419|
|[c6704cb2e30c08e40cf4550e516fbb97](https://www.virustotal.com/gui/file/c6704cb2e30c08e40cf4550e516fbb97)|Win32 DLL|PlugX|2018-02-04 10:49:10|rastls.dll|
|[cd36bbd7f949cf017edba0e6aaadf28c](https://www.virustotal.com/gui/file/cd36bbd7f949cf017edba0e6aaadf28c)|Win32 DLL||2018-01-24 01:04:37|NavShExt|
|[f12fc711529b48bcef52c5ca0a52335a](https://www.virustotal.com/gui/file/f12fc711529b48bcef52c5ca0a52335a)|RTF||2018-01-23 08:46:47|/home/virustotal/sample/F12FC711529B48BCEF52C5CA0A52335A|
|[4288921d1eb7a86cd0e4eb44f732138a](https://www.virustotal.com/gui/file/4288921d1eb7a86cd0e4eb44f732138a)|Win32 EXE||2018-01-19 11:28:16|fontview|
|[fd5793a48310c65702f624936565d335](https://www.virustotal.com/gui/file/fd5793a48310c65702f624936565d335)|Win32 EXE||2018-01-18 08:07:38|WinWord|
|[8cf472d807a5034530a4080403f9306e](https://www.virustotal.com/gui/file/8cf472d807a5034530a4080403f9306e)|Win32 EXE||2018-01-17 07:22:35|Adobe Download Manager|
|[a5facd2acc00060f0f98d02265c333a1](https://www.virustotal.com/gui/file/a5facd2acc00060f0f98d02265c333a1)|Win32 DLL|Ursu|2018-01-15 01:24:15|myfile.exe|
|[6cc87b958d02315f6ccdc2272b494161](https://www.virustotal.com/gui/file/6cc87b958d02315f6ccdc2272b494161)|Win32 DLL|PlugX|2018-01-10 14:21:49| |
|[06d1e4feb6766e556512609a174f7785](https://www.virustotal.com/gui/file/06d1e4feb6766e556512609a174f7785)|Win32 EXE||2018-01-10 11:52:10|06d1e4feb6766e556512609a174f7785|
|[1f4561fdf13a45a32e28929dc28ac763](https://www.virustotal.com/gui/file/1f4561fdf13a45a32e28929dc28ac763)|Win32 DLL|oceanlotus|2018-01-09 17:20:20|product_info.dll|
|[f3c3a5661a48e54021962add7c8b57ab](https://www.virustotal.com/gui/file/f3c3a5661a48e54021962add7c8b57ab)|Win32 DLL|Ursu|2018-01-08 16:26:18|wwlib.dll|
|[0ca3be2b8e0973fabb4a7d78d3ae9804](https://www.virustotal.com/gui/file/0ca3be2b8e0973fabb4a7d78d3ae9804)|Win32 DLL|CobaltStrike|2017-12-22 16:47:10|4ec55a20512fe50f4f87902426f8923886239aa4|
|[95a85454593426d42e45d11959801d58](https://www.virustotal.com/gui/file/95a85454593426d42e45d11959801d58)|Win32 EXE|Denis|2017-12-22 01:50:45|Volume Control Applet|
|[b107945f4789079e04014f39a8726c9c](https://www.virustotal.com/gui/file/b107945f4789079e04014f39a8726c9c)|Win32 DLL||2017-12-20 10:49:59|%ProgramFiles(x86)%\intel\perfhost_1702874162\mcutil.dll|
|[29692a9de12f55394912aeb7d0fb5e16](https://www.virustotal.com/gui/file/29692a9de12f55394912aeb7d0fb5e16)|Win32 EXE||2017-12-20 10:46:06|wmploc.dll|
|[f9c820264597d8f649d88522dd66f222](https://www.virustotal.com/gui/file/f9c820264597d8f649d88522dd66f222)|Win32 DLL||2017-12-19 12:20:38|rastls.dll|
|[a01fda63947b9b0bb29e8dd8e258e5c8](https://www.virustotal.com/gui/file/a01fda63947b9b0bb29e8dd8e258e5c8)|Win32 EXE|Ursu|2017-12-19 12:17:17|WinWord|
|[49f72b916b9db4ea8298cb214c96e35b](https://www.virustotal.com/gui/file/49f72b916b9db4ea8298cb214c96e35b)|Win32 DLL|PlugX|2017-12-17 11:15:47|5e58b68787bceab5_rastls.dll|
|[4cb3fcc942a346218b3b590bdbcb7ddd](https://www.virustotal.com/gui/file/4cb3fcc942a346218b3b590bdbcb7ddd)|Win32 EXE|Ursu|2017-12-17 11:11:18|et|
|[6b6c6f51a491bbab2dff1c604c36c309](https://www.virustotal.com/gui/file/6b6c6f51a491bbab2dff1c604c36c309)|Win32 DLL||2017-12-15 11:34:44|bff4d8cf99db6c50ea761e77581730f408a28f86|
|[b4bc65ada934a3e32c5e243b0f0c0770](https://www.virustotal.com/gui/file/b4bc65ada934a3e32c5e243b0f0c0770)|Win32 EXE|strictor|2017-12-12 02:09:22|HEV|
|[ca1d603703de97f3a2057948e162e356](https://www.virustotal.com/gui/file/ca1d603703de97f3a2057948e162e356)|Win32 EXE|Upatre|2017-12-08 07:54:06|AcroRd32.exe|
|[417a0ecf6459edf56ea704a9b5783208](https://www.virustotal.com/gui/file/417a0ecf6459edf56ea704a9b5783208)|Text||2017-12-07 20:28:31|aea41f0fe65b8d414fb0130089ffd84662e94062bbded7fcdfb144a8dc9156b3.ps1.bin|
|[c0cbae7d85aae0fc962fc1bcddd0fa37](https://www.virustotal.com/gui/file/c0cbae7d85aae0fc962fc1bcddd0fa37)|Win32 EXE||2017-12-04 12:17:00|WinWord|
|[88f79d2dbdeb6d4cdacd7a618907aa30](https://www.virustotal.com/gui/file/88f79d2dbdeb6d4cdacd7a618907aa30)|Win32 DLL||2017-12-03 14:01:03|2fea3f0ce5fa381e_rastls.dll|
|[8735751096de66db7838ed03d286ee5b](https://www.virustotal.com/gui/file/8735751096de66db7838ed03d286ee5b)|Win32 EXE|Denis|2017-12-03 13:59:26|AcroRd32.exe|
|[f62836e7e9834ab6e28e7fabae9d1113](https://www.virustotal.com/gui/file/f62836e7e9834ab6e28e7fabae9d1113)|Win32 EXE||2017-12-03 09:16:34|1000-c28cf7c894b7cbcfbb5217d15e89130d56a9c40e|
|[317d959d0ea2ba06789255301c32032d](https://www.virustotal.com/gui/file/317d959d0ea2ba06789255301c32032d)|Win32 DLL||2017-12-03 07:17:17|1059-a3635aa7614171050476dc323ff666b2cfc30ea1|
|[87d108b2763ce08d3f611f7d240597ec](https://www.virustotal.com/gui/file/87d108b2763ce08d3f611f7d240597ec)|Win32 EXE||2017-12-03 07:13:29|Google Update Setup|
|[6f7bf33399bce46a910ba2616b7201e5](https://www.virustotal.com/gui/file/6f7bf33399bce46a910ba2616b7201e5)|Win32 EXE||2017-11-30 14:44:06|icons.exe|
|[8de7d600d83bb3a6d2dd42932eed6f92](https://www.virustotal.com/gui/file/8de7d600d83bb3a6d2dd42932eed6f92)|Win32 DLL|Ursu|2017-11-27 02:51:39|rastls.dll|
|[8d6e7c359776cdb16aaf9630b63c535f](https://www.virustotal.com/gui/file/8d6e7c359776cdb16aaf9630b63c535f)|Win32 EXE|Gandcrab|2017-11-26 18:35:43|FontExt|
|[d9e33be278ff7581ff92572849afa511](https://www.virustotal.com/gui/file/d9e33be278ff7581ff92572849afa511)|Win32 DLL|PlugX|2017-11-26 05:20:52|McUtil.dll|
|[afb16b631533a040d9816541cf4815a2](https://www.virustotal.com/gui/file/afb16b631533a040d9816541cf4815a2)|Win32 EXE||2017-11-26 05:10:23|WinWord|
|[77aea9e8e9a8c23d51ad40991823c61d](https://www.virustotal.com/gui/file/77aea9e8e9a8c23d51ad40991823c61d)|Win32 DLL|CobaltStrike|2017-11-24 14:25:34|coccocpdate.dll|
|[e7d9789e82929702205a4ee360d94ab2](https://www.virustotal.com/gui/file/e7d9789e82929702205a4ee360d94ab2)|Win32 EXE|skeeyah|2017-11-23 10:47:41|Inside.exe|
|[0f79519584347ef20a6324f1e40002a5](https://www.virustotal.com/gui/file/0f79519584347ef20a6324f1e40002a5)|Win32 DLL|PlugX|2017-11-22 18:48:38|McUtil.dll|
|[959c82b646454ce3e5570e92e0578333](https://www.virustotal.com/gui/file/959c82b646454ce3e5570e92e0578333)|Win32 EXE||2017-11-22 18:28:09|WinWord|
|[457a4d1bd4b2661d75cb9cd9a6f9d136](https://www.virustotal.com/gui/file/457a4d1bd4b2661d75cb9cd9a6f9d136)|Win32 EXE||2017-11-21 14:01:50|/home/virustotal/sample/457A4D1BD4B2661D75CB9CD9A6F9D136|
|[88d18d051a1dec797e6579dccf882555](https://www.virustotal.com/gui/file/88d18d051a1dec797e6579dccf882555)|Win32 EXE||2017-11-20 03:47:01|Inside.exe|
|[75e485a0d91d0ecc578d33f78a03cee4](https://www.virustotal.com/gui/file/75e485a0d91d0ecc578d33f78a03cee4)|Win32 EXE||2017-11-20 03:39:54|Inside.exe|
|[b574571ed8c9c6bc6cfcbbb4899fd5cd](https://www.virustotal.com/gui/file/b574571ed8c9c6bc6cfcbbb4899fd5cd)|Win32 DLL|Zbot|2017-11-18 20:23:44|ragui32.dll|
|[f0be949e85e5c4e8a6bd4d94c90ab9b3](https://www.virustotal.com/gui/file/f0be949e85e5c4e8a6bd4d94c90ab9b3)|Win32 DLL||2017-11-17 06:19:31|rastls.dll|
|[5bc2b316311c3d8104506795d843ca9d](https://www.virustotal.com/gui/file/5bc2b316311c3d8104506795d843ca9d)|Win32 EXE||2017-11-13 09:55:56|mscorsvw.exe|
|[3f1b8327153bda27cc92b3ba5e61fb09](https://www.virustotal.com/gui/file/3f1b8327153bda27cc92b3ba5e61fb09)|Win32 EXE||2017-11-08 22:02:19|Inside.exe|
|[29a807b64777ea215b1953e091e8ea1c](https://www.virustotal.com/gui/file/29a807b64777ea215b1953e091e8ea1c)|Text||2017-11-08 00:32:31|underwears.png|
|[6a7e994f4cf664337112108c5c0b65a5](https://www.virustotal.com/gui/file/6a7e994f4cf664337112108c5c0b65a5)|Win32 EXE||2017-11-02 04:42:37|8008c3e259999b668cdbe95e0ca450da28e66e26|
|[f4bfa228b1d0aefc32a688454a37cd1e](https://www.virustotal.com/gui/file/f4bfa228b1d0aefc32a688454a37cd1e)|Win32 EXE|tiggre|2017-10-31 10:43:11|Inside.exe|
|[132038e7d74463009f25f39ecbf46cf4](https://www.virustotal.com/gui/file/132038e7d74463009f25f39ecbf46cf4)|Win32 DLL|Zbot|2017-10-18 00:19:45|hp6000.dll|
|[cd734e153e61f775a26aff5568e7d537](https://www.virustotal.com/gui/file/cd734e153e61f775a26aff5568e7d537)|Win32 EXE|dynamer|2017-10-17 23:21:49|Google Update Setup|
|[90b5c98db38c6bdfc02ef5bb4a65b899](https://www.virustotal.com/gui/file/90b5c98db38c6bdfc02ef5bb4a65b899)|Win32 DLL|Ursu|2017-10-15 08:35:52|rastls.dll|
|[fcd7227891271a65b729a27de962c0cb](https://www.virustotal.com/gui/file/fcd7227891271a65b729a27de962c0cb)|Win32 EXE||2017-10-15 06:47:23|FontExt|
|[c4d35f3263fef4a533e7403682a034c3](https://www.virustotal.com/gui/file/c4d35f3263fef4a533e7403682a034c3)|DOC|o97m|2017-10-13 02:04:40|=?UTF-8?B?THXhuq10IHPGsCBUcuG6p24gVsWpIEjhuqNpICBr4bq7IMSR4buZaSBs4buRdCBsdeG6rXQgc8awIGTDom4gY2jhu6cgxJHhu4MgdHLhu6VjIGzhu6NpIGPDoSBuaMOibi5kb2M=?=|
|[6552a447380286c9c38517ac28696d04](https://www.virustotal.com/gui/file/6552a447380286c9c38517ac28696d04)|Win32 EXE|Ursu|2017-10-11 07:05:31|fontview|
|[7c3a65b0f1d24be419de382e80c4c63c](https://www.virustotal.com/gui/file/7c3a65b0f1d24be419de382e80c4c63c)|Win32 EXE||2017-10-10 11:23:46|myfile.exe|
|[a69c31b0b86f43c7f7bf7a45d22f246f](https://www.virustotal.com/gui/file/a69c31b0b86f43c7f7bf7a45d22f246f)|Win32 DLL|Ursu|2017-10-09 18:55:31|D:/Download/MAL/malware/new_request/20171014/a69c31b0b86f43c7f7bf7a45d22f246f.vir|
|[b45203c7cbc35a092e7e8749bf17e4a7](https://www.virustotal.com/gui/file/b45203c7cbc35a092e7e8749bf17e4a7)|Win32 EXE||2017-10-09 15:03:16|FontExt|
|[b65b82eddcecd719c55d6d222926e648](https://www.virustotal.com/gui/file/b65b82eddcecd719c55d6d222926e648)|Win32 DLL|Ursu|2017-10-05 18:18:33|b65b82eddcecd719c55d6d222926e648.virus|
|[96b971c9ac868c8d9ae98618b9a9bddc](https://www.virustotal.com/gui/file/96b971c9ac868c8d9ae98618b9a9bddc)|Win32 EXE||2017-10-05 10:38:10|FontExt|
|[a7f98d3b7b7e2a7d1c194c2f26045618](https://www.virustotal.com/gui/file/a7f98d3b7b7e2a7d1c194c2f26045618)|Win32 EXE||2017-10-05 04:54:59|FontExt|
|[e07ce38a0e6da5ca974f87006de2e826](https://www.virustotal.com/gui/file/e07ce38a0e6da5ca974f87006de2e826)|Win32 DLL|Ursu|2017-09-30 03:38:34|rastls.dll|
|[c31151d0d923d812e4d69d33ccde3b50](https://www.virustotal.com/gui/file/c31151d0d923d812e4d69d33ccde3b50)|Win32 EXE||2017-09-30 02:30:40|c31151d0d923d812e4d69d33ccde3b50.vir|
|[e58b03501d940d0bec867209bf551362](https://www.virustotal.com/gui/file/e58b03501d940d0bec867209bf551362)|Win32 EXE||2017-09-29 21:30:59|f21e1fb8e603ef7903425dcd31743c9e49fb7cbe|
|[90a9df6643a8976883e7f5a473ce8349](https://www.virustotal.com/gui/file/90a9df6643a8976883e7f5a473ce8349)|Win32 DLL|Ursu|2017-09-29 07:37:06|rastls.dll|
|[215b4fcfab980f934968c95f552e3532](https://www.virustotal.com/gui/file/215b4fcfab980f934968c95f552e3532)|Win32 EXE||2017-09-28 20:22:26|fontview|
|[eb2b52ed27346962c4b7b26df51ebafa](https://www.virustotal.com/gui/file/eb2b52ed27346962c4b7b26df51ebafa)|Win32 EXE|oceanlotus|2017-09-28 12:23:55|7zS.sfx|
|[05bc07fc6265e6affa8478118c02942a](https://www.virustotal.com/gui/file/05bc07fc6265e6affa8478118c02942a)|Win32 EXE||2017-09-27 09:53:38|7zS.sfx|
|[2d9d166b4d40c220df895235c06777b0](https://www.virustotal.com/gui/file/2d9d166b4d40c220df895235c06777b0)|Win32 DLL|Ursu|2017-09-23 13:51:35|rastls.dll|
|[75a9d759678834ade92e6ed8c6de5699](https://www.virustotal.com/gui/file/75a9d759678834ade92e6ed8c6de5699)|Win32 EXE|strictor|2017-09-21 12:33:28|WinWord|
|[4926fe0bf75bd8b8494bff097035d6fe](https://www.virustotal.com/gui/file/4926fe0bf75bd8b8494bff097035d6fe)|Win32 DLL||2017-09-20 18:42:22|loader.dll|
|[a2b45cae93603d04592a684285ebe7b9](https://www.virustotal.com/gui/file/a2b45cae93603d04592a684285ebe7b9)|Win32 DLL|Ursu|2017-09-15 19:29:09|C:/Users/seongmin/Documents/VT2/malware/20170927/a2b45cae93603d04592a684285ebe7b9.vir|
|[1fa011e6a692ee95452c626e61b5263a](https://www.virustotal.com/gui/file/1fa011e6a692ee95452c626e61b5263a)|Win32 EXE||2017-09-15 16:44:32|7zS.sfx|
|[a04be5ca8df86ee9b93974f4da88548e](https://www.virustotal.com/gui/file/a04be5ca8df86ee9b93974f4da88548e)|Win32 DLL||2017-09-13 04:37:14|C:\Users\John\AppData\Roaming\Symantec\Officewordtask\rastls.dll|
|[d592b06f9d112c8650091166c19ea05a](https://www.virustotal.com/gui/file/d592b06f9d112c8650091166c19ea05a)|Win32 EXE||2017-09-13 03:50:36|WinWord|
|[d19b48f663b4a8b13d8a670389178811](https://www.virustotal.com/gui/file/d19b48f663b4a8b13d8a670389178811)|Win32 DLL|Zbot|2017-09-10 14:19:59|usrv42a.dll|
|[d95bbf9645994e891f3a8156eee9cbee](https://www.virustotal.com/gui/file/d95bbf9645994e891f3a8156eee9cbee)|Win32 EXE||2017-09-08 10:55:11|WinWord|
|[b424c855a9494409b6e0e70d87ffd558](https://www.virustotal.com/gui/file/b424c855a9494409b6e0e70d87ffd558)|Win32 DLL||2017-09-08 09:12:58|E:/byeongal/virustotal_public/malware/20170918/b424c855a9494409b6e0e70d87ffd558.vir|
|[88152846c45924d5706a11523942c82b](https://www.virustotal.com/gui/file/88152846c45924d5706a11523942c82b)|Win32 EXE||2017-09-08 09:11:04|Excel|
|[f769ac32c8550a27fd77a664103fcc4b](https://www.virustotal.com/gui/file/f769ac32c8550a27fd77a664103fcc4b)|Win32 DLL|Ursu|2017-09-02 06:45:35|rastls.dll|
|[ba4268f8694be7a252b917a692d157c3](https://www.virustotal.com/gui/file/ba4268f8694be7a252b917a692d157c3)|Win32 EXE||2017-09-02 06:43:04|/home/virustotal/sample/BA4268F8694BE7A252B917A692D157C3|
|[05fb8bb25d02c96d17e8a4564f255252](https://www.virustotal.com/gui/file/05fb8bb25d02c96d17e8a4564f255252)|Win32 EXE||2017-08-30 02:59:45|icons.exe|
|[251a4f1c20842d9a336b8a978007c73d](https://www.virustotal.com/gui/file/251a4f1c20842d9a336b8a978007c73d)|unknown||2017-08-29 16:44:14|251a4f1c20842d9a336b8a978007c73d_info.icns|
|[e9e147503e0a7281551dc745b39bb659](https://www.virustotal.com/gui/file/e9e147503e0a7281551dc745b39bb659)|PLIST||2017-08-29 16:44:14|e9e147503e0a7281551dc745b39bb659_Info.plist|
|[3cae5e446f99dd66d247ec7546e76297](https://www.virustotal.com/gui/file/3cae5e446f99dd66d247ec7546e76297)|Win32 EXE|Ursu|2017-08-29 03:53:32|rstrui.exe|
|[b28c80ca9a3b7deb09b275af1076eb55](https://www.virustotal.com/gui/file/b28c80ca9a3b7deb09b275af1076eb55)|Win32 DLL|zapchast|2017-08-26 07:37:06|L.dll|
|[4185f19a957f870ce6b511c4f86d7c06](https://www.virustotal.com/gui/file/4185f19a957f870ce6b511c4f86d7c06)|Win32 DLL|Ursu|2017-08-15 03:42:11|rastls.dll|
|[627e3ff5659b9a0ab9dc4b283c3288dd](https://www.virustotal.com/gui/file/627e3ff5659b9a0ab9dc4b283c3288dd)|Win32 EXE||2017-08-15 03:40:00|WinWord|
|[13f74e660edcbd4e4e8bf92d7980dcea](https://www.virustotal.com/gui/file/13f74e660edcbd4e4e8bf92d7980dcea)|Win32 DLL|Zbot|2017-08-10 04:33:15|D:/vt/malware/20170811/13f74e660edcbd4e4e8bf92d7980dcea.vir|
|[764c7863592f8e49833f71850aba9489](https://www.virustotal.com/gui/file/764c7863592f8e49833f71850aba9489)|Win32 EXE|skeeyah|2017-08-10 04:29:24|WinWord|
|[58febe3cdd3a523bc2a5162ad302c49f](https://www.virustotal.com/gui/file/58febe3cdd3a523bc2a5162ad302c49f)|Win32 DLL|Ursu|2017-08-03 19:48:25|rastls.dll|
|[2f5a12c23e90f769b388d1edace2371d](https://www.virustotal.com/gui/file/2f5a12c23e90f769b388d1edace2371d)|Win32 EXE|occamy|2017-08-03 19:10:41|WinWord|
|[df27265d6808e8b359e43e62988f0410](https://www.virustotal.com/gui/file/df27265d6808e8b359e43e62988f0410)|Win32 DLL|Zbot|2017-08-02 22:03:31|hp6000.dll|
|[bc1ccc120d185a0c36b191ec6b74397c](https://www.virustotal.com/gui/file/bc1ccc120d185a0c36b191ec6b74397c)|Win32 EXE|dynamer|2017-08-02 21:49:15|Google Update Setup|
|[6a7abc717abb17ce60a922057a2e9386](https://www.virustotal.com/gui/file/6a7abc717abb17ce60a922057a2e9386)|Win32 DLL|Ursu|2017-07-28 10:14:38|rastls.dll|
|[58d2907361f6414742dcc5071ca20980](https://www.virustotal.com/gui/file/58d2907361f6414742dcc5071ca20980)|Win32 EXE||2017-07-28 10:12:54|Adobe Download Manager|
|[662535022d14c5fdbe9988c212aa42b3](https://www.virustotal.com/gui/file/662535022d14c5fdbe9988c212aa42b3)|Win32 EXE|CobaltStrike|2017-07-27 07:53:39|Adobe® Flash® Player 12.1|
|[306ff58e105c4a06149a6a19b2f0669f](https://www.virustotal.com/gui/file/306ff58e105c4a06149a6a19b2f0669f)|Win32 DLL|Zbot|2017-07-23 04:50:28|ep7res01.dll|
|[7edcae7740ee7e7c75699cfbb4d89310](https://www.virustotal.com/gui/file/7edcae7740ee7e7c75699cfbb4d89310)|Win32 EXE|Palevo|2017-07-23 04:45:26|Excel|
|[97beee1a5f967d8a9ca5d01e544346f7](https://www.virustotal.com/gui/file/97beee1a5f967d8a9ca5d01e544346f7)|Win32 EXE|Ursu|2017-07-19 03:03:29|Adobe® Flash® Player 12.1|
|[5475d81ce3b3e018c33fbc83bdc0aa68](https://www.virustotal.com/gui/file/5475d81ce3b3e018c33fbc83bdc0aa68)|FPX||2017-07-14 07:03:19|/home/virustotal/sample/5475D81CE3B3E018C33FBC83BDC0AA68|
|[ba844b09524aea077f6a175da10a6bf0](https://www.virustotal.com/gui/file/ba844b09524aea077f6a175da10a6bf0)|FPX||2017-07-14 07:03:17|/home/virustotal/sample/BA844B09524AEA077F6A175DA10A6BF0|
|[7a14231cbf7b62d393cc587f73c384e0](https://www.virustotal.com/gui/file/7a14231cbf7b62d393cc587f73c384e0)|Win32 DLL|Zbot|2017-07-11 05:22:31|cnbxrf5.dll|
|[3bd041ef488806c55fbc40b4af24eabb](https://www.virustotal.com/gui/file/3bd041ef488806c55fbc40b4af24eabb)|Win32 EXE||2017-07-09 17:13:17|7zS.sfx|
|[3217a69d3db7f73a6ad808ee9adb5574](https://www.virustotal.com/gui/file/3217a69d3db7f73a6ad808ee9adb5574)|Win32 DLL|Zbot|2017-07-09 03:33:24|QtCore4.dll|
|[139f7dd7b672287bb9363c5781e12482](https://www.virustotal.com/gui/file/139f7dd7b672287bb9363c5781e12482)|Win32 EXE||2017-07-09 03:28:07|KB3033929.exe|
|[bc23d00cb48a90ebf37d0c9430618688](https://www.virustotal.com/gui/file/bc23d00cb48a90ebf37d0c9430618688)|Win32 EXE|Kryptik|2017-07-08 20:05:32| |
|[92e523f52d93640793a476b8be7dda38](https://www.virustotal.com/gui/file/92e523f52d93640793a476b8be7dda38)|Win32 DLL|Zbot|2017-07-06 06:19:01|cnbxrf5.dll|
|[591eb8f1c25a76fc7bba4df82ae37c79](https://www.virustotal.com/gui/file/591eb8f1c25a76fc7bba4df82ae37c79)|Win32 EXE|oceanlotus|2017-07-04 07:12:24|WinRAR|
|[fc77ec976f871a7b1a9c18d3dd644d7d](https://www.virustotal.com/gui/file/fc77ec976f871a7b1a9c18d3dd644d7d)|Win32 EXE||2017-07-04 07:08:35|WinRAR|
|[bfc98464ea3ee3370ecccaeadc95a4cb](https://www.virustotal.com/gui/file/bfc98464ea3ee3370ecccaeadc95a4cb)|Win32 DLL|Zbot|2017-07-04 06:53:20|cnbxrf5.dll|
|[55dfc53e373e9ac08290784e0ab2f76b](https://www.virustotal.com/gui/file/55dfc53e373e9ac08290784e0ab2f76b)|Win32 EXE||2017-07-04 06:51:22|{21E3EE4B-2584-25D8-BFB2-D4E9B7EF5708}.exe|
|[d31fb0880af458341c82f842f7f0575e](https://www.virustotal.com/gui/file/d31fb0880af458341c82f842f7f0575e)|Text|rozena|2017-06-28 09:58:00|ssman.ps1.txt|
|[26eb86f886406912beef33b767d2e3c7](https://www.virustotal.com/gui/file/26eb86f886406912beef33b767d2e3c7)|Win32 EXE|Banload|2017-06-26 10:30:42|fontview|
|[9eed9619eac172fa0b29de755907759c](https://www.virustotal.com/gui/file/9eed9619eac172fa0b29de755907759c)|Win32 EXE||2017-06-24 05:19:27|WinWorld|
|[9cfb2c1bd981952deca640e4100fa311](https://www.virustotal.com/gui/file/9cfb2c1bd981952deca640e4100fa311)|Win32 DLL|Zbot|2017-06-23 10:10:14|ep7res01.dll|
|[e71f3dc106852cd4648c41376204af9f](https://www.virustotal.com/gui/file/e71f3dc106852cd4648c41376204af9f)|Win32 EXE||2017-06-23 10:08:39|/home/virustotal/sample/E71F3DC106852CD4648C41376204AF9F|
|[c4dbc10104f058fcc5500d61cd48746a](https://www.virustotal.com/gui/file/c4dbc10104f058fcc5500d61cd48746a)|Win32 EXE|CobaltStrike|2017-06-19 09:04:42|Adobe® Flash® Player 11.1|
|[a4d3d2a565a8858a4134a72ae9a9fcfb](https://www.virustotal.com/gui/file/a4d3d2a565a8858a4134a72ae9a9fcfb)|Win32 EXE||2017-06-12 04:48:29|WinWord|
|[67b8d21e79018f1ab1b31e1aba16d201](https://www.virustotal.com/gui/file/67b8d21e79018f1ab1b31e1aba16d201)|Win32 DLL||2017-06-11 12:22:34|hp6000.dll|
|[46745e29f15eedfabba7e080f6295200](https://www.virustotal.com/gui/file/46745e29f15eedfabba7e080f6295200)|Win32 EXE||2017-06-11 11:31:28|/home/virustotal/sample/46745E29F15EEDFABBA7E080F6295200|
|[e969caa97294a8b6c0b77cc9266da251](https://www.virustotal.com/gui/file/e969caa97294a8b6c0b77cc9266da251)|ZIP|Symmi|2017-06-11 11:01:05|08bf66a7-f732-406b-889e-87c75db89729|
|[c117ea93410ad849e7a3ff9293bcd9ab](https://www.virustotal.com/gui/file/c117ea93410ad849e7a3ff9293bcd9ab)|Win32 DLL|Zbot|2017-06-11 06:42:40|/home/virustotal/sample/C117EA93410AD849E7A3FF9293BCD9AB|
|[3b53e66f34beb3cd30e6a7da457e86c8](https://www.virustotal.com/gui/file/3b53e66f34beb3cd30e6a7da457e86c8)|Win32 EXE||2017-06-11 06:42:29|/home/virustotal/sample/3B53E66F34BEB3CD30E6A7DA457E86C8|
|[155b82b8ca47244baa2006814d51ee80](https://www.virustotal.com/gui/file/155b82b8ca47244baa2006814d51ee80)|Win32 EXE||2017-06-09 14:54:25|Adobe® Flash® Player 11.1|
|[b70410cc622d1bbd3828e497cbe43698](https://www.virustotal.com/gui/file/b70410cc622d1bbd3828e497cbe43698)|Win32 EXE|CobaltStrike|2017-06-02 08:16:41|Adobe® Flash® Player 11.1|
|[f2badfabc99aeac9051b883684a93fe7](https://www.virustotal.com/gui/file/f2badfabc99aeac9051b883684a93fe7)|Win32 DLL|Zbot|2017-06-01 04:53:18|hp6000.dll|
|[42123d2493598c9ac9803fe1b92ed032](https://www.virustotal.com/gui/file/42123d2493598c9ac9803fe1b92ed032)|Win32 EXE||2017-06-01 04:50:07|Google Update Setup|
|[e0fe26e37ebf32ecec130a93dfc01af2](https://www.virustotal.com/gui/file/e0fe26e37ebf32ecec130a93dfc01af2)|Win32 DLL|Zbot|2017-05-25 11:04:26|ragui32.dll|
|[40f644f1957d0a30ba76470279e1463a](https://www.virustotal.com/gui/file/40f644f1957d0a30ba76470279e1463a)|Text||2017-05-23 21:04:00| |
|[fa6d09f010f11351a92c409fef7ba263](https://www.virustotal.com/gui/file/fa6d09f010f11351a92c409fef7ba263)|FPX||2017-05-23 10:09:45|/home/virustotal/sample/FA6D09F010F11351A92C409FEF7BA263|
|[d1e614479fee318904442c16c5ef4877](https://www.virustotal.com/gui/file/d1e614479fee318904442c16c5ef4877)|Win32 DLL|redleaves|2017-05-23 00:43:48|/home/virustotal/sample/D1E614479FEE318904442C16C5EF4877|
|[1f8ade068ba6fbfe8605e0946bf2d79f](https://www.virustotal.com/gui/file/1f8ade068ba6fbfe8605e0946bf2d79f)|Win32 DLL||2017-05-23 00:43:28|/home/virustotal/sample/1F8ADE068BA6FBFE8605E0946BF2D79F|
|[e02e37ea705f1066798f285836a6fc46](https://www.virustotal.com/gui/file/e02e37ea705f1066798f285836a6fc46)|Win32 EXE|tiggre|2017-05-23 00:42:00|/home/virustotal/sample/E02E37EA705F1066798F285836A6FC46|
|[fbd96ee03328af76dd6ffe161544e2ed](https://www.virustotal.com/gui/file/fbd96ee03328af76dd6ffe161544e2ed)|Win32 EXE|Virut|2017-05-18 17:37:34|OpenCL SDK|
|[f7af180d088f6b86509c2bea2d5cca6a](https://www.virustotal.com/gui/file/f7af180d088f6b86509c2bea2d5cca6a)|Win32 EXE|Kryptik|2017-05-17 04:14:32|WerFault|
|[8df881253483e8644b97f4fa939538bc](https://www.virustotal.com/gui/file/8df881253483e8644b97f4fa939538bc)|Win32 EXE||2017-05-12 03:27:07|VNTimes.ttf|
|[a532040810d0e34a28f20347807eb89f](https://www.virustotal.com/gui/file/a532040810d0e34a28f20347807eb89f)|Win32 EXE||2017-05-11 14:29:00|OpenCL SDK|
|[5bcf16810c7ef5bce3023d0bbefb4391](https://www.virustotal.com/gui/file/5bcf16810c7ef5bce3023d0bbefb4391)|Win32 EXE||2017-05-11 02:12:06|f:\sand-box\files_by_list\C$~$Recycle.Bin~S-1-5-21-259361288-3341279269-3490585568-1001~$RX4XJB7.exe|
|[f806cb19a3ef0e4c0aedd5107093454a](https://www.virustotal.com/gui/file/f806cb19a3ef0e4c0aedd5107093454a)|Win32 EXE|Zbot|2017-05-10 01:19:03|template0905h.png|
|[c38cf38218624879524415161c525edf](https://www.virustotal.com/gui/file/c38cf38218624879524415161c525edf)|Win32 EXE|Zbot|2017-04-28 08:23:39|/home/jiman/Downloads/malware6/bd00d2bf20c15f5137ebc21069b4431e715546d93a9eb447f254526d2896520a|
|[9fd66b9ee64ea7af3b69a4104e5aed21](https://www.virustotal.com/gui/file/9fd66b9ee64ea7af3b69a4104e5aed21)|Win32 EXE||2017-04-20 02:23:18|/home/jiman/Downloads/malware3/5df351d978a0f493beca220c1550a75e7418e3d1409ccc738e56c14384ed853c|
|[456385a5fa3b37b36a1054f3d0a9e3ef](https://www.virustotal.com/gui/file/456385a5fa3b37b36a1054f3d0a9e3ef)|Win32 EXE|skeeyah|2017-04-19 16:31:40|logo.exe01~Rip.exe|
|[e5fd5e6b75894ed03af8a3bbadcbef66](https://www.virustotal.com/gui/file/e5fd5e6b75894ed03af8a3bbadcbef66)|Win32 DLL||2017-04-18 09:59:29|sqlite.dll|
|[a4ae6e1cca7e1411b2dc9bf680e2b1b1](https://www.virustotal.com/gui/file/a4ae6e1cca7e1411b2dc9bf680e2b1b1)|Win32 EXE||2017-04-17 10:05:21|DpiScaling|
|[4e3bea69b0ea8f711b26bd1419a87ad5](https://www.virustotal.com/gui/file/4e3bea69b0ea8f711b26bd1419a87ad5)|Win32 DLL|skeeyah|2017-04-17 10:05:18|salgorea_ (3)|
|[c3d495bb065e8f3690efc50c70fc8c67](https://www.virustotal.com/gui/file/c3d495bb065e8f3690efc50c70fc8c67)|Win32 EXE|dynamer|2017-04-17 10:03:47|WinWord|
|[406dbee627ad8777d28ae2234a9e7c68](https://www.virustotal.com/gui/file/406dbee627ad8777d28ae2234a9e7c68)|XLS||2017-04-13 03:26:06|/home/virustotal/sample/406DBEE627AD8777D28AE2234A9E7C68|
|[54bb003b233a2249bcd3f79fd8406727](https://www.virustotal.com/gui/file/54bb003b233a2249bcd3f79fd8406727)|DOC||2017-04-13 03:23:26|VirusShare_54bb003b233a2249bcd3f79fd8406727|
|[49a5101de7a94820665634d34d459ceb](https://www.virustotal.com/gui/file/49a5101de7a94820665634d34d459ceb)|Win32 EXE|graftor|2017-04-12 18:21:42|DevicePairing|
|[20c4d34b35aae2359b0224a085f9b2f7](https://www.virustotal.com/gui/file/20c4d34b35aae2359b0224a085f9b2f7)|Win32 EXE||2017-04-12 18:01:00|DevicePairing|
|[90c3b5bcb26d83b34a81b302787933ba](https://www.virustotal.com/gui/file/90c3b5bcb26d83b34a81b302787933ba)|Text|rozena|2017-04-05 09:17:29|/home/virustotal/sample/90C3B5BCB26D83B34A81B302787933BA|
|[f1af6bb36cdf3cff768faee7919f0733](https://www.virustotal.com/gui/file/f1af6bb36cdf3cff768faee7919f0733)|unknown|o97m|2017-04-03 09:23:26|/home/virustotal/sample/F1AF6BB36CDF3CFF768FAEE7919F0733|
|[ffe1b4d0537cdf849a9bfbe6b74e94cc](https://www.virustotal.com/gui/file/ffe1b4d0537cdf849a9bfbe6b74e94cc)|Win32 EXE|Zbot|2017-03-24 21:50:51|WinWord|
|[aea9fbb5b3cd8fcd48add7d9ca6ed639](https://www.virustotal.com/gui/file/aea9fbb5b3cd8fcd48add7d9ca6ed639)|Win32 EXE|dynamer|2017-03-24 08:48:00|csc.exe|
|[f3fe2a40949619cd0a6ea05b0ce91ece](https://www.virustotal.com/gui/file/f3fe2a40949619cd0a6ea05b0ce91ece)|Win32 EXE||2017-03-21 04:31:47|f3fe2a40949619cd0a6ea05b0ce91ece.virus|
|[471a2e7341f2614b715dc89e803ffcac](https://www.virustotal.com/gui/file/471a2e7341f2614b715dc89e803ffcac)|unknown|o97m|2017-03-16 15:38:02|/home/virustotal/sample/471A2E7341F2614B715DC89E803FFCAC|
|[1ff1263633b46e662504c3fc5889c7fc](https://www.virustotal.com/gui/file/1ff1263633b46e662504c3fc5889c7fc)|Win32 EXE||2017-03-15 17:22:32|tzutil.exe|
|[facec411b6d6aa23ff80d1366633ea7a](https://www.virustotal.com/gui/file/facec411b6d6aa23ff80d1366633ea7a)|Win32 EXE|Denis|2017-03-10 22:48:17|mdnsNSP.exe|
|[27ac632a3a270900986d7afef67317a2](https://www.virustotal.com/gui/file/27ac632a3a270900986d7afef67317a2)|Win32 EXE|Denis|2017-03-10 08:55:55|msprivs.exee|
|[9b7b0060229c6e3fd8a6c6599867b866](https://www.virustotal.com/gui/file/9b7b0060229c6e3fd8a6c6599867b866)|Win32 EXE|Denis|2017-03-09 20:21:37|WerFault|
|[5180a8d9325a417f2d8066f9226a5154](https://www.virustotal.com/gui/file/5180a8d9325a417f2d8066f9226a5154)|unknown|Banload|2017-03-09 09:23:39|/home/virustotal/sample/5180A8D9325A417F2D8066F9226A5154|
|[5421781c2c05e64ef20be54e2ee32e37](https://www.virustotal.com/gui/file/5421781c2c05e64ef20be54e2ee32e37)|Win32 EXE||2017-03-08 17:01:46|NetplwizExe|
|[1a4d58e281103fea2a4ccbfab93f74d2](https://www.virustotal.com/gui/file/1a4d58e281103fea2a4ccbfab93f74d2)|Win32 EXE|Denis|2017-03-03 06:08:00|Cisco EAP-FAST Module|
|[5458a2e4d784abb1a1127263bd5006b5](https://www.virustotal.com/gui/file/5458a2e4d784abb1a1127263bd5006b5)|unknown|Banload|2017-03-02 07:01:01|5458a2e4d784abb1a1127263bd5006b5_c161134bf3330c82eb0278fe54b2975c26301bdfdc4fc35d5344f9becf5574c7|
|[e9abe54162ba4572c770ab043f576784](https://www.virustotal.com/gui/file/e9abe54162ba4572c770ab043f576784)|unknown|o97m|2017-03-01 03:58:08|/home/virustotal/sample/E9ABE54162BA4572C770AB043F576784|
|[b7b990fe7884b1ec0998ac465b936b8c](https://www.virustotal.com/gui/file/b7b990fe7884b1ec0998ac465b936b8c)|Win32 EXE|Denis|2017-02-28 16:37:12|Cisco EAP-FAST Module|
|[8ff134b6cb1e10746fa394b9e88b9d5b](https://www.virustotal.com/gui/file/8ff134b6cb1e10746fa394b9e88b9d5b)|Win32 EXE|strictor|2017-02-25 17:31:18|Adobe Download Manager|
|[18dde939dd712165fc71b35175869697](https://www.virustotal.com/gui/file/18dde939dd712165fc71b35175869697)|Win32 EXE|Kryptik|2017-02-24 06:49:12|18dde939dd712165fc71b35175869697.virus|
|[fba089444c769700e47c6b44c362f96b](https://www.virustotal.com/gui/file/fba089444c769700e47c6b44c362f96b)|unknown|o97m|2017-02-22 07:30:52|/home/virustotal/sample/FBA089444C769700E47C6B44C362F96B|
|[27fd84f2f0f7cfa1a615ff8d9add61ad](https://www.virustotal.com/gui/file/27fd84f2f0f7cfa1a615ff8d9add61ad)|Win32 EXE|Symmi|2017-02-21 08:40:15|Live Traffic.exe|
|[77d9fe2fcf7235e132d657ffcfbb75f9](https://www.virustotal.com/gui/file/77d9fe2fcf7235e132d657ffcfbb75f9)|Win32 EXE|dynamer|2017-02-21 02:58:19|D:\MONITER\Mau Mon\HIPS_DaPV_21-2-2017\New folder\New folder\7C06.tmp|
|[f6ee4b72d6d42d0c7be9172be2b817c1](https://www.virustotal.com/gui/file/f6ee4b72d6d42d0c7be9172be2b817c1)|unknown|o97m|2017-02-17 00:51:23|/home/virustotal/sample/F6EE4B72D6D42D0C7BE9172BE2B817C1|
|[ac8b9e5c35e134da9ec701bcd9bcf760](https://www.virustotal.com/gui/file/ac8b9e5c35e134da9ec701bcd9bcf760)|Win32 EXE|Denis|2017-01-18 19:00:41|Adobe® Flash® Player Installler/Uninstalller 11.1|
|[ce50e544430e7265a45fab5a1f31e529](https://www.virustotal.com/gui/file/ce50e544430e7265a45fab5a1f31e529)|unknown|o97m|2017-01-17 10:21:31|/home/virustotal/sample/CE50E544430E7265A45FAB5A1F31E529|
|[2435f021bf0ab9a791d4ea26f84d4f73](https://www.virustotal.com/gui/file/2435f021bf0ab9a791d4ea26f84d4f73)|Win32 EXE||2017-01-11 09:40:31|WinWord|
|[e2e4b2f28d29fd19bb28287a4d99ede2](https://www.virustotal.com/gui/file/e2e4b2f28d29fd19bb28287a4d99ede2)|Win32 EXE|Denis|2016-12-28 09:51:13|Adobe® Flash® Player Installler/Uninstalller 11.1|
|[b44de5560d57fb4e0e225c496f8c29fc](https://www.virustotal.com/gui/file/b44de5560d57fb4e0e225c496f8c29fc)|Win32 EXE||2016-12-25 08:55:25|b44de5560d57fb4e0e225c496f8c29fc.virus|
|[d3434f4e54292a205479f2aac6339e81](https://www.virustotal.com/gui/file/d3434f4e54292a205479f2aac6339e81)|Win32 EXE||2016-12-24 21:41:10|d3434f4e54292a205479f2aac6339e81.virus|
|[0eb2c47fdd5aada4640c0c6e06589b7f](https://www.virustotal.com/gui/file/0eb2c47fdd5aada4640c0c6e06589b7f)|Win32 DLL||2016-12-19 03:35:53|Bundle.bin|
|[5d0431db51b6516842419443ce0fda84](https://www.virustotal.com/gui/file/5d0431db51b6516842419443ce0fda84)|Win32 EXE|graftor|2016-12-14 01:41:19|QQi.exe|
|[07a3539115ea63e67891afb3bfebc56d](https://www.virustotal.com/gui/file/07a3539115ea63e67891afb3bfebc56d)|Win32 DLL||2016-12-10 06:21:07|radarrs.dll|
|[5c6a072ca1d9886e72b4789debcee8ad](https://www.virustotal.com/gui/file/5c6a072ca1d9886e72b4789debcee8ad)|Win32 EXE|dynamer|2016-12-10 06:20:58|GfxUIEx.exe|
|[f36497ec9039d1dc2d6516d3b905dcb0](https://www.virustotal.com/gui/file/f36497ec9039d1dc2d6516d3b905dcb0)|Win32 EXE|dynamer|2016-12-10 06:07:32|AcroRd32.exe|
|[aaa231054888d2708af1ad1b7faa5d7a](https://www.virustotal.com/gui/file/aaa231054888d2708af1ad1b7faa5d7a)|Win32 DLL||2016-12-08 07:13:42|comuid.dll|
|[d481b5efc8fb2354280b80828d7b0535](https://www.virustotal.com/gui/file/d481b5efc8fb2354280b80828d7b0535)|Win32 EXE|dynamer|2016-12-08 07:11:44|WinWord|
|[402394662e65efb53e6b4db838f19e69](https://www.virustotal.com/gui/file/402394662e65efb53e6b4db838f19e69)|Win32 EXE|Ursu|2016-12-02 07:10:17|DpiScaling|
|[87b16b7764dd2cd5593797051ca09efa](https://www.virustotal.com/gui/file/87b16b7764dd2cd5593797051ca09efa)|Win32 DLL||2016-12-02 07:10:15|comuid.dll|
|[ca0b642005c1d2aded4b2334810a5e99](https://www.virustotal.com/gui/file/ca0b642005c1d2aded4b2334810a5e99)|Win32 EXE|Zbot|2016-12-02 07:07:54|WinWord|
|[c42b9a7e480f1c750d1bbacecec47812](https://www.virustotal.com/gui/file/c42b9a7e480f1c750d1bbacecec47812)|Win32 EXE||2016-12-02 03:45:21|Adobe® Flash® Player Installler/Uninstalller 11.1|
|[fec1cab81600d04851f6aa5f13e712c2](https://www.virustotal.com/gui/file/fec1cab81600d04851f6aa5f13e712c2)|Win32 EXE|Zbot|2016-11-09 01:15:24|WinWord|
|[775c8b9369e6b8e4d06f2b4bbe65b236](https://www.virustotal.com/gui/file/775c8b9369e6b8e4d06f2b4bbe65b236)|Win32 DLL||2016-11-04 23:26:24|dsound.dll|
|[8fbc7a4f2713707ff8b1d3153af66250](https://www.virustotal.com/gui/file/8fbc7a4f2713707ff8b1d3153af66250)|Win32 EXE|dynamer|2016-11-04 23:26:13|DevicePairing|
|[e5d1109ac80fa028447167d25a9491a6](https://www.virustotal.com/gui/file/e5d1109ac80fa028447167d25a9491a6)|Win32 EXE|barys|2016-11-04 23:00:28|e5d1109ac80fa028447167d25a9491a6.virus|
|[f0e88d5fa0bcd1e47ce814314258f98b](https://www.virustotal.com/gui/file/f0e88d5fa0bcd1e47ce814314258f98b)|Win32 EXE||2016-11-04 09:16:22|Adobe® Flash® Player Installler/Uninstalller 11.1|
|[b4b52bf8c89b2a6e5439850350639f9b](https://www.virustotal.com/gui/file/b4b52bf8c89b2a6e5439850350639f9b)|Win32 EXE||2016-11-02 16:30:37|KBDHEPT_extract_from_shellcode_adobe.exe|
|[49a2872b0c74fb7156768ccf0298f6ad](https://www.virustotal.com/gui/file/49a2872b0c74fb7156768ccf0298f6ad)|Win32 DLL|dynamer|2016-10-27 01:29:55|dsound.dll|
|[71b2637ac4b08efc0a8ce8dba8c51ff3](https://www.virustotal.com/gui/file/71b2637ac4b08efc0a8ce8dba8c51ff3)|Win32 EXE|dynamer|2016-10-27 01:23:57|71b2637ac4b08efc0a8ce8dba8c51ff3.virus|
|[4f761095ca51bfbbf4496a4964e41d4f](https://www.virustotal.com/gui/file/4f761095ca51bfbbf4496a4964e41d4f)|unknown|o97m|2016-10-22 14:42:58|/home/virustotal/sample/4F761095CA51BFBBF4496A4964E41D4F|
|[910a95a133a8f0496f6abcca9ac9ab2c](https://www.virustotal.com/gui/file/910a95a133a8f0496f6abcca9ac9ab2c)|Win32 DLL|Zbot|2016-10-18 08:33:03|AeroGlass.theme|
|[b588fe8ac2e4985ccad953f29081acbc](https://www.virustotal.com/gui/file/b588fe8ac2e4985ccad953f29081acbc)|Win32 EXE|strictor|2016-10-18 08:30:55|Adobe Download Manager|
|[404624b821edfa99b028cf3787653a58](https://www.virustotal.com/gui/file/404624b821edfa99b028cf3787653a58)|Win32 EXE|dynamer|2016-10-18 08:06:08|Windows Desktop Gadgets|
|[ce7ec74f86cce6107b6c2c3281b5e37d](https://www.virustotal.com/gui/file/ce7ec74f86cce6107b6c2c3281b5e37d)|Win32 DLL|Zbot|2016-10-18 08:06:06|AeroGlass.theme|
|[69fc4f19aca2ba6d648d6f92571f1e45](https://www.virustotal.com/gui/file/69fc4f19aca2ba6d648d6f92571f1e45)|Win32 EXE||2016-10-18 08:04:17|WinWord|
|[0d1ab1818fffbe41e36d647efdbbcba4](https://www.virustotal.com/gui/file/0d1ab1818fffbe41e36d647efdbbcba4)|Win32 EXE|dynamer|2016-10-11 05:40:09|Windows Desktop Gadgets|
|[1b2afd7bf96c4fd7826d497504a947bb](https://www.virustotal.com/gui/file/1b2afd7bf96c4fd7826d497504a947bb)|Win32 DLL|Zbot|2016-10-11 05:40:07|AeroGlass.theme|
|[e2f83deffdff410d4eb2855457df70ed](https://www.virustotal.com/gui/file/e2f83deffdff410d4eb2855457df70ed)|Win32 EXE|strictor|2016-10-11 04:26:55|Adobe Download Manager|
|[3610485c708da600743ded9ee76e09d0](https://www.virustotal.com/gui/file/3610485c708da600743ded9ee76e09d0)|Win32 EXE|Ursu|2016-10-09 10:55:56|3610485c708da600743ded9ee76e09d0.virobj|
|[b15563b02ba483cc51636054dc5ceb6c](https://www.virustotal.com/gui/file/b15563b02ba483cc51636054dc5ceb6c)|Win32 DLL|Zbot|2016-10-09 10:55:54|AeroGlass.theme|
|[d709fee7f0cf3e4148773af84a1b483d](https://www.virustotal.com/gui/file/d709fee7f0cf3e4148773af84a1b483d)|Win32 EXE|dynamer|2016-10-09 10:16:09|GfxUIEx.exe|
|[bc598a6f23c1eff2785feb10a4789759](https://www.virustotal.com/gui/file/bc598a6f23c1eff2785feb10a4789759)|Win32 EXE|strictor|2016-10-09 08:50:35|Adobe Download Manager|
|[3741002219551088e3897dd98b4eecbb](https://www.virustotal.com/gui/file/3741002219551088e3897dd98b4eecbb)|Win32 EXE|Dorkbot|2016-10-07 06:43:50|WinWord|
|[aa1f85de3e4d33f31b4f78968b29f175](https://www.virustotal.com/gui/file/aa1f85de3e4d33f31b4f78968b29f175)|unknown|Banload|2016-10-06 11:03:54|/home/virustotal/sample/AA1F85DE3E4D33F31B4F78968B29F175|
|[c72a792cb80462304de2340e9de08bc6](https://www.virustotal.com/gui/file/c72a792cb80462304de2340e9de08bc6)|Win32 EXE||2016-10-05 09:05:26|WinWord|
|[7f0ac1b4e169edc62856731953dad126](https://www.virustotal.com/gui/file/7f0ac1b4e169edc62856731953dad126)|Win32 EXE||2016-09-23 07:15:47|javaw|
|[78497b8577f034d1aef23b282434cc7c](https://www.virustotal.com/gui/file/78497b8577f034d1aef23b282434cc7c)|Win32 DLL|Zbot|2016-09-12 06:49:47|AeroGlass.theme|
|[6c5c2692597b5bb0f2ecee9c9f667134](https://www.virustotal.com/gui/file/6c5c2692597b5bb0f2ecee9c9f667134)|Win32 EXE||2016-09-12 06:03:14|WinWord|
|[506cbfe687aad4666286dd6ee478ab00](https://www.virustotal.com/gui/file/506cbfe687aad4666286dd6ee478ab00)|Win32 EXE|dynamer|2016-09-09 13:56:06|69a14e0466702f2b929fffd800caa8dbec62975e0527e70df0d664613a8cbfb4.bin|
|[de3952026a06a71b1721f172a96e89be](https://www.virustotal.com/gui/file/de3952026a06a71b1721f172a96e89be)|Win32 EXE|Symmi|2016-09-08 08:27:25|WinWord|
|[23d57de85a7455063806d94df6036f08](https://www.virustotal.com/gui/file/23d57de85a7455063806d94df6036f08)|Win32 DLL||2016-09-08 08:26:53|AeroGlass.theme|
|[e648adcb6ab5a381afdac7aa0f055448](https://www.virustotal.com/gui/file/e648adcb6ab5a381afdac7aa0f055448)|Win32 EXE|Dorkbot|2016-09-07 11:11:27|WinWord|
|[9f84aebc9ec442dd0b0bdadc401bd97c](https://www.virustotal.com/gui/file/9f84aebc9ec442dd0b0bdadc401bd97c)|Win32 EXE|dynamer|2016-09-07 04:24:26|WinWord|
|[c8eaa7653991bb8eccbd436442f95003](https://www.virustotal.com/gui/file/c8eaa7653991bb8eccbd436442f95003)|Win32 EXE|Denis|2016-09-07 02:45:15|SwUSB.exe|
|[6baafffa7bf960dec821b627f9653e44](https://www.virustotal.com/gui/file/6baafffa7bf960dec821b627f9653e44)|unknown|Banload|2016-09-06 10:20:51|1fc1bc4d004ab51398070d8e3025fecf8878229cda8befdbc9a2faf592b8d876.doc|
|[8d90d10b0297c26b352969c0666629a5](https://www.virustotal.com/gui/file/8d90d10b0297c26b352969c0666629a5)|Win32 EXE||2016-08-31 03:43:47|xwizard.exe|
|[cf8d4728a093ce412d0477a2eadc2955](https://www.virustotal.com/gui/file/cf8d4728a093ce412d0477a2eadc2955)|Win32 EXE|Denis|2016-08-30 06:59:21|SwUSB.exe|
|[be58bf076bff74c48e900b0f0d1822ed](https://www.virustotal.com/gui/file/be58bf076bff74c48e900b0f0d1822ed)|Win32 EXE||2016-08-26 17:08:48|WinWord|
|[adee9169ca54c2d64ff5a7b5fb6995e4](https://www.virustotal.com/gui/file/adee9169ca54c2d64ff5a7b5fb6995e4)|Win32 EXE|dynamer|2016-08-24 09:45:25|Windows Desktop Gadgets|
|[f91b7b7cc99cc46f8a0ba3e6d5820a66](https://www.virustotal.com/gui/file/f91b7b7cc99cc46f8a0ba3e6d5820a66)|Win32 EXE||2016-08-24 09:43:16|Adobe Download Manager|
|[2891f2320ddd1a80073312187ce70ccc](https://www.virustotal.com/gui/file/2891f2320ddd1a80073312187ce70ccc)|Win32 EXE|Symmi|2016-08-21 05:06:45|WinRAR|
|[c629dbf38977d682702f607c089e1b89](https://www.virustotal.com/gui/file/c629dbf38977d682702f607c089e1b89)|Win32 EXE|dynamer|2016-08-17 20:32:59|c629dbf38977d682702f607c089e1b89.virus|
|[5a248172eb61f00b616fe7cc500790f0](https://www.virustotal.com/gui/file/5a248172eb61f00b616fe7cc500790f0)|Win32 EXE|dynamer|2016-08-16 10:05:08|699e30e652279c8718a20ca547ade35b5d6e9dfb1d45b5b670c228850ae0810d.bin|
|[66e896001442d2cd6cdb6ea2ccbad830](https://www.virustotal.com/gui/file/66e896001442d2cd6cdb6ea2ccbad830)|Win32 EXE|Symmi|2016-08-16 10:02:15|WinWord|
|[d802aa9938e87dc33cf2c7a07e920b0b](https://www.virustotal.com/gui/file/d802aa9938e87dc33cf2c7a07e920b0b)|Mach-O executable|oceanlotus|2016-08-16 10:01:24|d802aa9938e87dc33cf2c7a07e920b0b_Noi dung chi tiet|
|[4e2752dbe4a3a4b9dbe499ce9c1a43ed](https://www.virustotal.com/gui/file/4e2752dbe4a3a4b9dbe499ce9c1a43ed)|ZIP|oceanlotus|2016-08-16 06:29:50|Noi dung chi tiet.zip|
|[dc1e8e868c347d310f24235eb4391559](https://www.virustotal.com/gui/file/dc1e8e868c347d310f24235eb4391559)|Win32 DLL|CobaltStrike|2016-08-15 04:04:46|tx32.dll|
|[e38fbec43075e9eb48c46cb9b215a3dd](https://www.virustotal.com/gui/file/e38fbec43075e9eb48c46cb9b215a3dd)|Win32 EXE||2016-08-13 18:58:16|Excel|
|[c781b4cde28609ff2d7b217671e1f110](https://www.virustotal.com/gui/file/c781b4cde28609ff2d7b217671e1f110)|Win32 EXE|dynamer|2016-08-13 17:15:48|c781b4cde28609ff2d7b217671e1f110.virobj|
|[ba49eb3b3b5b747b7e0331855eba83f5](https://www.virustotal.com/gui/file/ba49eb3b3b5b747b7e0331855eba83f5)|Win32 EXE|Denis|2016-08-12 20:37:28|CSRSS.Exe|
|[601be696b87b0661c399c7c3e26d6231](https://www.virustotal.com/gui/file/601be696b87b0661c399c7c3e26d6231)|Win32 EXE|dynamer|2016-08-10 16:23:11|Windows Desktop Gadgets|
|[f76511b9f0a68857da2f68b4c7cfeee4](https://www.virustotal.com/gui/file/f76511b9f0a68857da2f68b4c7cfeee4)|Win32 EXE||2016-08-10 04:35:45|WinRAR|
|[b2f8c9ce955d4155d466fbbb7836e08b](https://www.virustotal.com/gui/file/b2f8c9ce955d4155d466fbbb7836e08b)|Win32 EXE||2016-08-06 04:30:16|javaw|
|[516ad28f8fa161f086be7ca122351edf](https://www.virustotal.com/gui/file/516ad28f8fa161f086be7ca122351edf)|Win32 EXE||2016-08-05 07:57:31|javaw|
|[5181ef6ebea06dd7e14366ad03ec331c](https://www.virustotal.com/gui/file/5181ef6ebea06dd7e14366ad03ec331c)|Win32 EXE|dynamer|2016-08-04 07:59:54|csc.exe|
|[d94a443219375c895faffbf2044bd48f](https://www.virustotal.com/gui/file/d94a443219375c895faffbf2044bd48f)|Win32 EXE|Symmi|2016-08-02 17:27:47|WinRAR|
|[5394b09cf2a0b3d1caaecc46c0e502e3](https://www.virustotal.com/gui/file/5394b09cf2a0b3d1caaecc46c0e502e3)|Win32 EXE|Denis|2016-08-01 09:03:58|Volume Control Applet|
|[80322cf12de0da08a201c128f96834eb](https://www.virustotal.com/gui/file/80322cf12de0da08a201c128f96834eb)|Win32 EXE|dynamer|2016-07-28 22:00:42|80322cf12de0da08a201c128f96834eb.virus|
|[d11b77bc1cc7b173c9eda38ab1c4c9cf](https://www.virustotal.com/gui/file/d11b77bc1cc7b173c9eda38ab1c4c9cf)|Win32 EXE||2016-07-23 21:20:25|Windows Desktop Gadgets|
|[57b9973f487f2a2ebb4328a49f9b953d](https://www.virustotal.com/gui/file/57b9973f487f2a2ebb4328a49f9b953d)|Win32 EXE|dynamer|2016-07-15 09:10:06|Windows Desktop Gadgets|
|[48b13341fb62f0b986f76eb7e530fea5](https://www.virustotal.com/gui/file/48b13341fb62f0b986f76eb7e530fea5)|Win32 EXE|Symmi|2016-07-15 09:08:18|WinWord|
|[c901d6644af3c533dd50fafc75965d79](https://www.virustotal.com/gui/file/c901d6644af3c533dd50fafc75965d79)|Win32 EXE|Dorkbot|2016-06-25 10:36:24|WinWord|
|[72c65bcdac820be73b29d530e16ae211](https://www.virustotal.com/gui/file/72c65bcdac820be73b29d530e16ae211)|Win32 DLL||2016-06-20 10:51:09| |
|[2613164c2e8b68785ad31acdae1d11a0](https://www.virustotal.com/gui/file/2613164c2e8b68785ad31acdae1d11a0)|Win32 EXE|Ursu|2016-06-17 11:16:35|DpiScaling|
|[08b60ac93e8163662f12c1e753cecb00](https://www.virustotal.com/gui/file/08b60ac93e8163662f12c1e753cecb00)|Win32 DLL||2016-06-17 11:16:32|08b60ac93e8163662f12c1e753cecb00.virobj|
|[64bbd73b153723d573cec34b277cedd4](https://www.virustotal.com/gui/file/64bbd73b153723d573cec34b277cedd4)|Win32 EXE|Dorkbot|2016-06-17 11:13:12|WinWord|
|[7bbe686f4d19687c6a9010b253ca9a23](https://www.virustotal.com/gui/file/7bbe686f4d19687c6a9010b253ca9a23)|Win32 DLL|Ursu|2016-06-05 17:53:21|disk1.img|
|[43d70115f300195126400ab127332bfa](https://www.virustotal.com/gui/file/43d70115f300195126400ab127332bfa)|Win32 EXE||2016-06-05 17:53:19|Defrag.EXE|
|[1d5899b04a3d30a7018c0bd26a0e240a](https://www.virustotal.com/gui/file/1d5899b04a3d30a7018c0bd26a0e240a)|Win32 EXE||2016-06-05 17:48:03|WinWord|
|[a9c4232b34836337a7168a90261da410](https://www.virustotal.com/gui/file/a9c4232b34836337a7168a90261da410)|DEX||2016-06-01 18:30:29|classes.dex|
|[d1eb52ef6c2445c848157beaba54044f](https://www.virustotal.com/gui/file/d1eb52ef6c2445c848157beaba54044f)|Android||2016-06-01 14:51:11|org.adaway-2.9.2.apk|
|[ad5a20d49dd6cf5635e48da750dd971f](https://www.virustotal.com/gui/file/ad5a20d49dd6cf5635e48da750dd971f)|Win32 EXE|Symmi|2016-05-22 07:38:56|Adobe Download Manager|
|[88bd6de713d45e38021b6ac9515968ca](https://www.virustotal.com/gui/file/88bd6de713d45e38021b6ac9515968ca)|Win32 EXE|dynamer|2016-05-21 22:25:49|Windows Desktop Gadgets|
|[bd33869f98ccef8f6ba554f8d61bddf7](https://www.virustotal.com/gui/file/bd33869f98ccef8f6ba554f8d61bddf7)|Win32 EXE|Symmi|2016-05-21 22:23:09|WinRAR|
|[a5d479c88a489461d7f55732a057d4e6](https://www.virustotal.com/gui/file/a5d479c88a489461d7f55732a057d4e6)|Win32 DLL||2016-05-21 22:21:42|dsound.dll|
|[3dfe254663ed69e4a302bc4f4f8eea07](https://www.virustotal.com/gui/file/3dfe254663ed69e4a302bc4f4f8eea07)|Win32 EXE||2016-05-21 22:19:27| |
|[2df2b9f9a6d02b652f1de61f30bae493](https://www.virustotal.com/gui/file/2df2b9f9a6d02b652f1de61f30bae493)|Win32 EXE|Dorkbot|2016-05-17 14:03:51|WinWord|
|[b784d22d1636d6296d182c2deea99898](https://www.virustotal.com/gui/file/b784d22d1636d6296d182c2deea99898)|Win32 EXE||2016-04-18 02:07:37|WinRAR|
|[b40fa8d7c7b304ab9e96742118520eae](https://www.virustotal.com/gui/file/b40fa8d7c7b304ab9e96742118520eae)|Win32 EXE||2016-04-17 10:06:18|WinWord|
|[74646df14970ff356f33978a6b7fd59d](https://www.virustotal.com/gui/file/74646df14970ff356f33978a6b7fd59d)|DEX||2016-04-09 05:01:25|classes.dex|
|[f3b53417280b53ac2d937277dfecbd84](https://www.virustotal.com/gui/file/f3b53417280b53ac2d937277dfecbd84)|Win32 DLL|dynamer|2016-04-08 16:57:32|radarrs.dll|
|[d240e5f561a4a11d085eef95bb2aaa4d](https://www.virustotal.com/gui/file/d240e5f561a4a11d085eef95bb2aaa4d)|Win32 EXE|strictor|2016-04-08 16:42:06|WinWord|
|[900d376f9ab5459e7d505e767e285711](https://www.virustotal.com/gui/file/900d376f9ab5459e7d505e767e285711)|Win32 EXE||2016-04-03 22:06:13|WinRAR|
|[a1ff27aabb1b19c0347b2486cd1a39b6](https://www.virustotal.com/gui/file/a1ff27aabb1b19c0347b2486cd1a39b6)|Win32 EXE|dynamer|2016-03-28 22:52:22|WinWord|
|[df845b9cae7c396cde34c5d0c764360a](https://www.virustotal.com/gui/file/df845b9cae7c396cde34c5d0c764360a)|DEX||2016-03-22 01:54:18|classes.dex|
|[c630ab7b51f0c0fa38a4a0f45c793e24](https://www.virustotal.com/gui/file/c630ab7b51f0c0fa38a4a0f45c793e24)|Android||2016-03-22 01:30:56|com.android.GoogleServices.apk|
|[bad17c3770d9346fa52921d2cdb56514](https://www.virustotal.com/gui/file/bad17c3770d9346fa52921d2cdb56514)|Win32 EXE|dynamer|2016-03-18 10:49:27|QQi.exe|
|[193ce209617d206fb4d183b0a4e78dd3](https://www.virustotal.com/gui/file/193ce209617d206fb4d183b0a4e78dd3)|Win32 EXE|Dorkbot|2016-03-18 07:30:40|WinWord|
|[6acae521c7c333cb3af1dfcc8317e293](https://www.virustotal.com/gui/file/6acae521c7c333cb3af1dfcc8317e293)|Win32 EXE|graftor|2016-03-14 08:51:58|Windows Desktop Gadgets|
|[a01233568a0c4b14b3ba58ccb4f8f52c](https://www.virustotal.com/gui/file/a01233568a0c4b14b3ba58ccb4f8f52c)|Win32 EXE|Symmi|2016-03-14 08:50:16|Adobe Download Manager|
|[47bfb6d840c4fa545db35110af8f10d6](https://www.virustotal.com/gui/file/47bfb6d840c4fa545db35110af8f10d6)|Win32 EXE||2016-03-10 15:35:38|Windows Desktop Gadgets|
|[0ba55a52e55e8cecc4fa92254444145b](https://www.virustotal.com/gui/file/0ba55a52e55e8cecc4fa92254444145b)|Win32 DLL|Zbot|2016-03-10 15:35:36|AeroGlass.theme|
|[71c6e2abcdecfc0078173345539852c1](https://www.virustotal.com/gui/file/71c6e2abcdecfc0078173345539852c1)|Win32 EXE|Symmi|2016-03-10 15:33:59|Adobe Download Manager|
|[65ae890de5b9ce888c4fd4c12f4f94d0](https://www.virustotal.com/gui/file/65ae890de5b9ce888c4fd4c12f4f94d0)|unknown|oceanlotus|2016-02-18 18:50:13|65ae890de5b9ce888c4fd4c12f4f94d0_.en_icon|
|[d4db451fca87638b589b306e666825ff](https://www.virustotal.com/gui/file/d4db451fca87638b589b306e666825ff)|unknown|oceanlotus|2016-02-18 18:45:45|d4db451fca87638b589b306e666825ff_.DS_Stores|
|[d6b76d7ac9b08ceaeecb43513db37bc0](https://www.virustotal.com/gui/file/d6b76d7ac9b08ceaeecb43513db37bc0)|Win32 EXE||2016-02-18 08:00:48|GfxUIEx.exe|
|[2eeba9031d88002bcebddde787d35a3a](https://www.virustotal.com/gui/file/2eeba9031d88002bcebddde787d35a3a)|Win32 EXE|strictor|2016-02-18 07:37:57|WinWord|
|[315f8e3da94920248676b095786e26ad](https://www.virustotal.com/gui/file/315f8e3da94920248676b095786e26ad)|Android||2016-02-13 18:38:20|8363d20b7e0ed942b0f281b1eadeb8bd0baf120ce2f85f06d9c5f5524a2da60a.bin|
|[e2d7d0021fd414349cbd95cd6a62f930](https://www.virustotal.com/gui/file/e2d7d0021fd414349cbd95cd6a62f930)|Win32 EXE|Denis|2016-02-04 03:03:02|Excel|
|[4f5a64c35d7b19a3143d2ca7b1c3264f](https://www.virustotal.com/gui/file/4f5a64c35d7b19a3143d2ca7b1c3264f)|Win32 EXE||2016-02-04 03:02:56|csc.exe|
|[77a5676fd677e8b2de61b2cd81169183](https://www.virustotal.com/gui/file/77a5676fd677e8b2de61b2cd81169183)|Win32 EXE|oceanlotus|2016-01-29 09:49:40|DevicePairing|
|[5d989342565d53f518177407be6e4100](https://www.virustotal.com/gui/file/5d989342565d53f518177407be6e4100)|Win32 EXE||2016-01-29 09:47:25|5d989342565d53f518177407be6e4100.virobj|
|[dc664680199cb27fb3629888dfd00ebd](https://www.virustotal.com/gui/file/dc664680199cb27fb3629888dfd00ebd)|Win32 EXE|dynamer|2016-01-27 06:32:21|WinWord|
|[5ae03ccbabb3dc92b2b4a2729a7c9c3f](https://www.virustotal.com/gui/file/5ae03ccbabb3dc92b2b4a2729a7c9c3f)|Text||2016-01-26 13:48:22|syscheck.vbs|
|[229a39860d1ebeafc0e1cef5880605fa](https://www.virustotal.com/gui/file/229a39860d1ebeafc0e1cef5880605fa)|DEX||2016-01-12 17:44:15|classes.dex|
|[6a6b749a641f7ab2e7215e5b9704864a](https://www.virustotal.com/gui/file/6a6b749a641f7ab2e7215e5b9704864a)|Win32 EXE|Ursu|2016-01-12 09:40:26|DpiScaling|
|[b580f8d7af6704bf82298eb4b0eb74c3](https://www.virustotal.com/gui/file/b580f8d7af6704bf82298eb4b0eb74c3)|Win32 DLL||2016-01-12 09:40:22|comuid.dll|
|[6a42a99691059c224731752ed8f7a272](https://www.virustotal.com/gui/file/6a42a99691059c224731752ed8f7a272)|Win32 EXE|Dorkbot|2016-01-12 09:38:37|WinWord|
|[50bfd62721b4f3813c2d20b59642f022](https://www.virustotal.com/gui/file/50bfd62721b4f3813c2d20b59642f022)|Android||2016-01-12 07:41:35|Google Play services.apk|
|[2ad58d7d74a562b7aeffed0f296b1d51](https://www.virustotal.com/gui/file/2ad58d7d74a562b7aeffed0f296b1d51)|Win32 EXE|Dorkbot|2016-01-09 08:26:06|0 (408).exe|
|[5bf7bbe6bf75b6e1eb60ff601f097bd2](https://www.virustotal.com/gui/file/5bf7bbe6bf75b6e1eb60ff601f097bd2)|Win32 EXE||2016-01-08 22:31:04|1.tmp|
|[cedb069533582bfa5d86b8137035b793](https://www.virustotal.com/gui/file/cedb069533582bfa5d86b8137035b793)|Win32 EXE||2016-01-08 16:02:48|filename|
|[4046ff080673cffac6529512b8d3bdbb](https://www.virustotal.com/gui/file/4046ff080673cffac6529512b8d3bdbb)|FPX||2016-01-08 02:33:14|4046ff080673cffac6529512b8d3bdbb_.CFUserEncoding|
|[31b9c979ebbd46abe28334014b17c4ad](https://www.virustotal.com/gui/file/31b9c979ebbd46abe28334014b17c4ad)|Win32 EXE||2016-01-05 03:32:21|Windows Desktop Gadgets|
|[2d54d6a601b5a27205a997c9a752a0fd](https://www.virustotal.com/gui/file/2d54d6a601b5a27205a997c9a752a0fd)|Win32 EXE|Symmi|2016-01-05 03:30:44|WinWord|
|[6379267df2c0bc6fce171c2e53c743a7](https://www.virustotal.com/gui/file/6379267df2c0bc6fce171c2e53c743a7)|Mach-O fat binary executable|oceanlotus|2016-01-04 16:41:18|45fddc73c9d8e1351e6940dd8916aa65a3abfb9f_.en_icon_decr|
|[3d0936455e69cc8b8e49ad5ad3366bae](https://www.virustotal.com/gui/file/3d0936455e69cc8b8e49ad5ad3366bae)|Win32 EXE|Symmi|2015-12-18 20:30:17|WinRAR|
|[2838ecec7740d7fa80b73da74992ddb3](https://www.virustotal.com/gui/file/2838ecec7740d7fa80b73da74992ddb3)|Win32 EXE||2015-12-01 04:13:17|DevicePairing|
|[a9b520959bd59d1e6e1805a5ad2c74d7](https://www.virustotal.com/gui/file/a9b520959bd59d1e6e1805a5ad2c74d7)|Win32 EXE|graftor|2015-11-26 02:43:54|GfxUIEx.exe|
|[fbfc66310679565995ff5fad4472af3e](https://www.virustotal.com/gui/file/fbfc66310679565995ff5fad4472af3e)|Win32 EXE|ipatre|2015-11-26 02:39:38|AcroRd32.exe|
|[211a9ac4e8ae628aa0cbcf34d547dc44](https://www.virustotal.com/gui/file/211a9ac4e8ae628aa0cbcf34d547dc44)|Win32 DLL|Ursu|2015-10-22 03:56:36| |
|[0e7c2adda3bc65242a365ef72b91f3a8](https://www.virustotal.com/gui/file/0e7c2adda3bc65242a365ef72b91f3a8)|ZIP||2015-10-20 12:51:49|ab84c15b254d101bb5b49d9017b2cb67a21efdf14bc8f4d5fef9fc1a27aadf93.bin|
|[f29dffd9817f7fda040c9608c14351d3](https://www.virustotal.com/gui/file/f29dffd9817f7fda040c9608c14351d3)|Android||2015-10-20 02:46:28|com.android.wps-1.apk|
|[76185b7e5b984a3b1672a55de073ad71](https://www.virustotal.com/gui/file/76185b7e5b984a3b1672a55de073ad71)|Win32 EXE||2015-10-03 07:15:58|WinWord|
|[80ac35fc7aa612a5e6c1df67592cdd8d](https://www.virustotal.com/gui/file/80ac35fc7aa612a5e6c1df67592cdd8d)|Win32 EXE||2015-09-28 10:15:36|WinWord|
|[a8a3d82ae821f15bc2a2223a65af75e1](https://www.virustotal.com/gui/file/a8a3d82ae821f15bc2a2223a65af75e1)|ZIP|oceanlotus|2015-09-28 10:01:08|d522f520938bdad10ea107a73dba90d15d4dfd3b_FlashPlayer.jar|
|[9831a7bfcf595351206a2ea5679fa65e](https://www.virustotal.com/gui/file/9831a7bfcf595351206a2ea5679fa65e)|Mach-O fat binary executable|oceanlotus|2015-09-28 09:26:23|9831a7bfcf595351206a2ea5679fa65e_EmptyApplication|
|[9dc9d82fc30c44ebac9348ffc7a26678](https://www.virustotal.com/gui/file/9dc9d82fc30c44ebac9348ffc7a26678)|Win32 EXE||2015-09-28 03:53:11|WinWord|
|[b5c8e0f0a9186827f0677b2dd5c9ed0a](https://www.virustotal.com/gui/file/b5c8e0f0a9186827f0677b2dd5c9ed0a)|Win32 EXE||2015-09-22 07:19:48|Windows Desktop Gadgets|
|[3d677c956bc9a9ede80e38134af20a5c](https://www.virustotal.com/gui/file/3d677c956bc9a9ede80e38134af20a5c)|Win32 EXE||2015-09-22 07:18:08|Adobe Download Manager|
|[a580f990489183df6ebc9a40b82c2648](https://www.virustotal.com/gui/file/a580f990489183df6ebc9a40b82c2648)|Win32 EXE|dynamer|2015-09-11 04:03:21|Windows Desktop Gadgets|
|[b959fd4a3bb6bae8e5df02a8892d8531](https://www.virustotal.com/gui/file/b959fd4a3bb6bae8e5df02a8892d8531)|Win32 EXE||2015-09-11 04:01:46|WinWord|
|[197a4f2ffed178d3ccdf866e8de0354d](https://www.virustotal.com/gui/file/197a4f2ffed178d3ccdf866e8de0354d)|Win32 EXE||2015-09-10 21:07:03| |
|[84c1eed8a55176bc9dca977bffb9f8e3](https://www.virustotal.com/gui/file/84c1eed8a55176bc9dca977bffb9f8e3)|Win32 EXE||2015-09-01 01:08:37|Adobe Download Manager|
|[268b19e39223680b3b6101864293df45](https://www.virustotal.com/gui/file/268b19e39223680b3b6101864293df45)|Win32 DLL|Zbot|2015-08-23 12:33:25|AeroGlass.theme|
|[dd5f4b30ce573c950b5d3dc5adf34757](https://www.virustotal.com/gui/file/dd5f4b30ce573c950b5d3dc5adf34757)|Win32 EXE|Zbot|2015-08-23 12:19:47|WinWord|
|[bc5a1f9ed84f9f40cc5e488abdad7326](https://www.virustotal.com/gui/file/bc5a1f9ed84f9f40cc5e488abdad7326)|Win32 EXE||2015-08-14 18:35:17|Adobe Download Manager|
|[df2e4ce8cc68c86b92d0d02e44315cc1](https://www.virustotal.com/gui/file/df2e4ce8cc68c86b92d0d02e44315cc1)|Android||2015-08-06 03:44:21|d2c94a079624e30fa0297d675ed960f58be2b4fabca68a0886b253391e41ca45.bin|
|[6c5844b546c4e61b81a0b49f7716416a](https://www.virustotal.com/gui/file/6c5844b546c4e61b81a0b49f7716416a)|Win32 DLL||2015-07-31 16:14:04|AeroGlass.theme|
|[05c7b84f03193804946ba587e7e1d4df](https://www.virustotal.com/gui/file/05c7b84f03193804946ba587e7e1d4df)|Win32 EXE|Dorkbot|2015-07-31 16:03:58|WinWord|
|[3b798095d8ddcc657bd3db7c702d8a0d](https://www.virustotal.com/gui/file/3b798095d8ddcc657bd3db7c702d8a0d)|Win32 EXE|dynamer|2015-07-31 12:14:25|Windows Desktop Gadgets|
|[07dbc752d96bb377b00246b506528147](https://www.virustotal.com/gui/file/07dbc752d96bb377b00246b506528147)|Win32 EXE|Dorkbot|2015-07-31 12:09:18|WinWord|
|[2564969d1487a91d6945f05eb2ca7258](https://www.virustotal.com/gui/file/2564969d1487a91d6945f05eb2ca7258)|Win32 EXE|Dorkbot|2015-07-25 21:45:40|setup.exe|
|[37e6fb30284bae58094a81f7394bb31b](https://www.virustotal.com/gui/file/37e6fb30284bae58094a81f7394bb31b)|Win32 DLL||2015-07-23 01:46:47|radarrs.dll|
|[360e4fc0cc199f44f2be5aa1ab7934fb](https://www.virustotal.com/gui/file/360e4fc0cc199f44f2be5aa1ab7934fb)|Win32 EXE|Zbot|2015-07-23 01:40:56| |
|[2c28e6e9221e22ae45920b9772f77aa0](https://www.virustotal.com/gui/file/2c28e6e9221e22ae45920b9772f77aa0)|Win32 EXE|Dorkbot|2015-07-09 12:58:45|Adobe Download Manager|
|[3b6ba05d5d0f236cf0867f1d7fe1a25e](https://www.virustotal.com/gui/file/3b6ba05d5d0f236cf0867f1d7fe1a25e)|Win32 EXE|oceanlotus|2015-06-29 23:21:20| |
|[bf1ca2dab5df0546aacc02abf40c2f19](https://www.virustotal.com/gui/file/bf1ca2dab5df0546aacc02abf40c2f19)|Android||2015-06-24 14:50:07|4ABC3EECE7F22CF5F4B4BB1B9A3AEA50|
|[9bc79fa5220e43ac31bd8393042f3873](https://www.virustotal.com/gui/file/9bc79fa5220e43ac31bd8393042f3873)|Mach-O fat binary executable|oceanlotus|2015-06-22 12:04:34|/Users/user1/client/tmp/dcebdb45436e4ccc3e7445d26a61759a86ac848743f86d6f9ff183d8132b07c9/FlashUpdate.app/Contents/MacOS/EmptyApplication|
|[d915731301dd2671f7567d638e081d8a](https://www.virustotal.com/gui/file/d915731301dd2671f7567d638e081d8a)|ZIP|oceanlotus|2015-06-22 12:03:57|aaffec74c294f9e2711b0dfec3d0231c6f0dff8a_install_flashplayer.jar|
|[1458bd9ab1a6117ff061a458f2cf1627](https://www.virustotal.com/gui/file/1458bd9ab1a6117ff061a458f2cf1627)|Win32 EXE||2015-06-14 05:31:11|WinWord|
|[fa936a8b7bad78179f2e86a83c154a62](https://www.virustotal.com/gui/file/fa936a8b7bad78179f2e86a83c154a62)|Win32 EXE|Dorkbot|2015-06-13 21:52:26|POWERPNT|
|[c5dcedf167579cb43415a2f2930c4119](https://www.virustotal.com/gui/file/c5dcedf167579cb43415a2f2930c4119)|Win32 DLL||2015-06-13 21:49:40|AeroGlass.theme|
|[3e1d41e5649e584b4e7a6845687e4e45](https://www.virustotal.com/gui/file/3e1d41e5649e584b4e7a6845687e4e45)|Win32 EXE||2015-06-13 21:40:34| |
|[48d6aa5393d68d91df4b020ba06c9889](https://www.virustotal.com/gui/file/48d6aa5393d68d91df4b020ba06c9889)|Win32 EXE|Dorkbot|2015-06-13 19:03:57|WinWord|
|[3ee085da7296a5cdebdddc3a5b41f709](https://www.virustotal.com/gui/file/3ee085da7296a5cdebdddc3a5b41f709)|Win32 EXE|Dorkbot|2015-06-13 01:03:48| |
|[3821937a2630970ffbdac045eeed1a13](https://www.virustotal.com/gui/file/3821937a2630970ffbdac045eeed1a13)|Win32 EXE|Dorkbot|2015-06-13 00:59:28|Google Update Setup|
|[64f05636d98e3bb9d27880801c734d0a](https://www.virustotal.com/gui/file/64f05636d98e3bb9d27880801c734d0a)|Win32 EXE||2015-06-04 18:36:49|QQi.exe|
|[f3a12eefb1e89bc82f60f2645ac77fe8](https://www.virustotal.com/gui/file/f3a12eefb1e89bc82f60f2645ac77fe8)|Win32 EXE|Dorkbot|2015-05-26 18:43:37|Adobe Download Manager|
|[bf9a7f5f043f134f2b0d6179b8f6fae1](https://www.virustotal.com/gui/file/bf9a7f5f043f134f2b0d6179b8f6fae1)|Win32 EXE||2015-05-18 01:29:09|Windows Desktop Gadgets|
|[04696313d4882ad7ce83c7947e95327d](https://www.virustotal.com/gui/file/04696313d4882ad7ce83c7947e95327d)|Win32 EXE|Dorkbot|2015-05-18 01:27:17|host.exe|
|[d6efafc0cc100370168d09cec6608697](https://www.virustotal.com/gui/file/d6efafc0cc100370168d09cec6608697)|Win32 EXE|graftor|2015-05-12 14:50:45|GfxUIEx.exe|
|[ba4843cd520da83acf56604c36c318ab](https://www.virustotal.com/gui/file/ba4843cd520da83acf56604c36c318ab)|Win32 EXE||2015-05-12 06:38:11|WinWord|
|[822fa7290f55313dafcd86f71d1fe224](https://www.virustotal.com/gui/file/822fa7290f55313dafcd86f71d1fe224)|Win32 EXE|Dorkbot|2015-05-12 03:00:25|Adobe Download Manager|
|[0863589a50a05686cbf87a8dc9eb417a](https://www.virustotal.com/gui/file/0863589a50a05686cbf87a8dc9eb417a)|Win32 EXE|Dorkbot|2015-05-11 21:47:34|WinWord|
|[13e917ab290607944402bef2afa343d4](https://www.virustotal.com/gui/file/13e917ab290607944402bef2afa343d4)|Win32 EXE||2015-04-29 00:18:33|WinRAR|
|[d13830e0d3e4aab8677691b79ac6eee1](https://www.virustotal.com/gui/file/d13830e0d3e4aab8677691b79ac6eee1)|Win32 EXE||2015-04-11 14:46:16|DevicePairing|
|[f5bd3fc326d55e05f332fd28c3d839a6](https://www.virustotal.com/gui/file/f5bd3fc326d55e05f332fd28c3d839a6)|Win32 EXE||2015-04-11 14:42:55|WinWord|
|[197fa72fb6d1e6d88ad77e655d345e11](https://www.virustotal.com/gui/file/197fa72fb6d1e6d88ad77e655d345e11)|Win32 EXE||2015-04-07 05:44:46|WinWord|
|[a8df30679d5805057877cb7ccca3b240](https://www.virustotal.com/gui/file/a8df30679d5805057877cb7ccca3b240)|Win32 EXE||2015-03-31 02:11:43|Windows Desktop Gadgets|
|[44baa53c3e994e2807eafe637160ee5e](https://www.virustotal.com/gui/file/44baa53c3e994e2807eafe637160ee5e)|Win32 DLL|Ursu|2015-03-31 02:11:41|AeroGlass.theme|
|[780a7f9446f62dd23b87b59b67624887](https://www.virustotal.com/gui/file/780a7f9446f62dd23b87b59b67624887)|Android||2015-03-30 21:53:10|1da8576c8e67c5f283ac841eb9a958e8507262e205be592edee0406359ef75f6.bin|
|[0529b1d393f405bc2b2b33709dd57153](https://www.virustotal.com/gui/file/0529b1d393f405bc2b2b33709dd57153)|Win32 EXE||2015-03-25 00:42:24|0529b1d393f405bc2b2b33709dd57153.0|
|[9dc940bc63ce5d2a5950659d3738210c](https://www.virustotal.com/gui/file/9dc940bc63ce5d2a5950659d3738210c)|Win32 EXE|Dorkbot|2015-03-24 02:06:40|host.exe|
|[642b9267d4d51f76436ce93f0b8dc79e](https://www.virustotal.com/gui/file/642b9267d4d51f76436ce93f0b8dc79e)|Win32 DLL|Ursu|2015-03-17 08:29:49|AeroGlass.theme|
|[c684d53ca578568cb5c093e7d66f4398](https://www.virustotal.com/gui/file/c684d53ca578568cb5c093e7d66f4398)|Win32 EXE||2015-03-17 08:28:02|WinWord|
|[0671cb2194daa86483a75a747eba09c2](https://www.virustotal.com/gui/file/0671cb2194daa86483a75a747eba09c2)|Win32 EXE||2015-03-16 04:44:34| |
|[0e1dec7175a474b17683cb5b76efdd2e](https://www.virustotal.com/gui/file/0e1dec7175a474b17683cb5b76efdd2e)|Win32 DLL|Ursu|2015-03-10 06:15:16|dsound.dll|
|[f7eec078a0c25881be798326c6994d65](https://www.virustotal.com/gui/file/f7eec078a0c25881be798326c6994d65)|Win32 EXE||2015-03-10 06:13:30|WinWord|
|[9c4adbf937a8c13e023665a2bfc3558f](https://www.virustotal.com/gui/file/9c4adbf937a8c13e023665a2bfc3558f)|Win32 DLL|graftor|2015-03-09 02:22:54|radarrs.dll|
|[c08c52f1ec1de202a2f4fa4823b48642](https://www.virustotal.com/gui/file/c08c52f1ec1de202a2f4fa4823b48642)|Win32 EXE|graftor|2015-03-09 02:22:45|GfxUIEx.exe|
|[a8acf762418c4017e162d556ba467f02](https://www.virustotal.com/gui/file/a8acf762418c4017e162d556ba467f02)|Win32 EXE||2015-03-09 02:19:50|WinWord|
|[83dfb42eaeb5ada36299c546dd71272e](https://www.virustotal.com/gui/file/83dfb42eaeb5ada36299c546dd71272e)|Win32 DLL||2015-02-25 13:31:27|radarrs.dll|
|[f2ad4795827d50690474cb82255dc6ca](https://www.virustotal.com/gui/file/f2ad4795827d50690474cb82255dc6ca)|Win32 EXE||2015-02-25 04:30:52| |
|[641f0cc057e2ab43f5444c5547e80976](https://www.virustotal.com/gui/file/641f0cc057e2ab43f5444c5547e80976)|Android||2015-02-24 19:03:37|TOS_Multi_Backup_V1.1.apk|
|[8cc691623c30639f14200382afe6b1c2](https://www.virustotal.com/gui/file/8cc691623c30639f14200382afe6b1c2)|Win32 EXE||2015-02-17 18:52:27|WinRAR|
|[670da3c322e76e98336315889f1c28a7](https://www.virustotal.com/gui/file/670da3c322e76e98336315889f1c28a7)|Win32 EXE|Dorkbot|2015-02-17 18:10:28|host.exe|
|[c9f9d83af561ddbb3b0499e4086999f5](https://www.virustotal.com/gui/file/c9f9d83af561ddbb3b0499e4086999f5)|Win32 EXE|graftor|2015-02-06 19:30:20|Windows Desktop Gadgets|
|[d337b39ae27dec545fbe13a99fdcc40b](https://www.virustotal.com/gui/file/d337b39ae27dec545fbe13a99fdcc40b)|Win32 EXE|Dorkbot|2015-02-06 19:25:48|host.exe|
|[5ed90e72117b39189f0ab2da682f51f1](https://www.virustotal.com/gui/file/5ed90e72117b39189f0ab2da682f51f1)|Win32 EXE||2015-02-04 08:58:49|WinWord|
|[dabf05376c4ef5c1386ea8cecf3acd5b](https://www.virustotal.com/gui/file/dabf05376c4ef5c1386ea8cecf3acd5b)|Android||2015-02-03 09:50:18|NhacCuaTuiDownloader.apk|
|[41bced8c65c5822d43cadad7d1dc49fd](https://www.virustotal.com/gui/file/41bced8c65c5822d43cadad7d1dc49fd)|Win32 EXE||2015-02-02 20:44:14|41bced8c65c5822d43cadad7d1dc49fd.exe.tmp|
|[9785eb85b797288057876ba147b8ce90](https://www.virustotal.com/gui/file/9785eb85b797288057876ba147b8ce90)|Win32 EXE||2015-01-31 07:19:08|9785eb85b797288057876ba147b8ce90|
|[b765d03db60326cb9b51774cdc78d298](https://www.virustotal.com/gui/file/b765d03db60326cb9b51774cdc78d298)|Win32 EXE||2015-01-30 07:03:37|WinWord|
|[6a6909bba396f9b4c7302e4fb6facef5](https://www.virustotal.com/gui/file/6a6909bba396f9b4c7302e4fb6facef5)|Win32 EXE|Dorkbot|2015-01-25 23:19:56|host.exe|
|[2600375e98507f8abdbd7233e6be2c80](https://www.virustotal.com/gui/file/2600375e98507f8abdbd7233e6be2c80)|Win32 DLL|Ursu|2015-01-25 21:10:51|2600375e98507f8abdbd7233e6be2c80|
|[508ecca673570f7212a0d251a7ae2485](https://www.virustotal.com/gui/file/508ecca673570f7212a0d251a7ae2485)|Win32 EXE|Dorkbot|2015-01-24 13:21:15|508ecca673570f7212a0d251a7ae2485|
|[80b18a58c3d225ce7bb6d2d36ff1aa2a](https://www.virustotal.com/gui/file/80b18a58c3d225ce7bb6d2d36ff1aa2a)|Win32 EXE||2015-01-19 03:32:40|Excel|
|[04df6786ad8d218d6c0a00d3abd52a5b](https://www.virustotal.com/gui/file/04df6786ad8d218d6c0a00d3abd52a5b)|Win32 EXE||2015-01-12 09:43:09|WinWord|
|[eca665e7d5fbe1e19d1b4f98d166ebde](https://www.virustotal.com/gui/file/eca665e7d5fbe1e19d1b4f98d166ebde)|Win32 EXE||2014-12-26 01:01:55|host.exe|
|[fa89e5b508be58a7f7379b8ce232e861](https://www.virustotal.com/gui/file/fa89e5b508be58a7f7379b8ce232e861)|Win32 EXE||2014-12-23 07:12:57|NOTEPAD.EXE|
|[70ca42bb9c3b6e49663fc532833874c3](https://www.virustotal.com/gui/file/70ca42bb9c3b6e49663fc532833874c3)|Win32 EXE||2014-12-19 04:47:51|WinWord|
|[0de53bf164d7675816a5466941cfc111](https://www.virustotal.com/gui/file/0de53bf164d7675816a5466941cfc111)|Win32 EXE|Dorkbot|2014-12-05 07:56:42|host.exe|
|[ce7e862ffe1d21f6c1fb95e97c470444](https://www.virustotal.com/gui/file/ce7e862ffe1d21f6c1fb95e97c470444)|Win32 EXE||2014-12-03 15:51:13|host.exe|
|[986e8802d8d50ba2cdc9674a81614e96](https://www.virustotal.com/gui/file/986e8802d8d50ba2cdc9674a81614e96)|Win32 EXE||2014-12-01 21:23:29|986e8802d8d50ba2cdc9674a81614e96|
|[241f4a69ee1aa5b06eb116d0ed5d49d1](https://www.virustotal.com/gui/file/241f4a69ee1aa5b06eb116d0ed5d49d1)|Win32 EXE|Dorkbot|2014-11-21 00:04:15|host.exe|
|[64862bd19fed4f0cd26276d9396ea700](https://www.virustotal.com/gui/file/64862bd19fed4f0cd26276d9396ea700)|Win32 EXE||2014-11-12 13:15:06|DevicePairing|
|[95443ca91981d10352eaf6a659048427](https://www.virustotal.com/gui/file/95443ca91981d10352eaf6a659048427)|Win32 EXE||2014-10-31 23:12:26|Setup|
|[35e08f0cb80a294bf2b12828bbe0a4dd](https://www.virustotal.com/gui/file/35e08f0cb80a294bf2b12828bbe0a4dd)|Win32 EXE||2014-10-29 00:18:46|WinWord|
|[f7c98de7a4549f8e7a934790f70cb19c](https://www.virustotal.com/gui/file/f7c98de7a4549f8e7a934790f70cb19c)|Win32 DLL|Ursu|2014-10-24 08:23:56|AeroGlass.theme|
|[ed5921926191ff4dc1d2d0f2df51a4ac](https://www.virustotal.com/gui/file/ed5921926191ff4dc1d2d0f2df51a4ac)|Win32 EXE|Dorkbot|2014-10-24 06:36:55|WinWord|
|[9095ee93152e1cdf2c2a01f016f501d6](https://www.virustotal.com/gui/file/9095ee93152e1cdf2c2a01f016f501d6)|Win32 EXE||2014-10-23 17:40:13|WinWord|
|[47816e1918c0c530b70e39d5db7435e0](https://www.virustotal.com/gui/file/47816e1918c0c530b70e39d5db7435e0)|Win32 EXE|Dorkbot|2014-10-20 07:02:30|host.exe|
|[cb22835b642d4be24898a995fe3f2789](https://www.virustotal.com/gui/file/cb22835b642d4be24898a995fe3f2789)|Win32 EXE||2014-10-09 17:57:16|Human Rights Watch reporting on VietNam 2014                                               .exe|
|[f5fde512685c0ae23d5d05d5c454d5a6](https://www.virustotal.com/gui/file/f5fde512685c0ae23d5d05d5c454d5a6)|Win32 EXE||2014-10-08 19:46:00|WinWord|
|[61d5d59de194f221a87a6adc50686608](https://www.virustotal.com/gui/file/61d5d59de194f221a87a6adc50686608)|Win32 EXE|Dorkbot|2014-10-08 08:19:12|host.exe|
|[3ebd3fa9bb4dc2a1ac88d1397706888d](https://www.virustotal.com/gui/file/3ebd3fa9bb4dc2a1ac88d1397706888d)|Win32 EXE||2014-10-06 09:56:40|host.exe|
|[4ae1df1c6b871bd71ba0fed9ec689879](https://www.virustotal.com/gui/file/4ae1df1c6b871bd71ba0fed9ec689879)|Win32 DLL|Ursu|2014-10-03 08:40:50|vti-rescan|
|[078e44e3c07ab26988b9ec8024ec5aeb](https://www.virustotal.com/gui/file/078e44e3c07ab26988b9ec8024ec5aeb)|Win32 EXE||2014-09-30 03:28:19|WinWord|
|[604bbf50778c5ddc4a8ff974d12c9296](https://www.virustotal.com/gui/file/604bbf50778c5ddc4a8ff974d12c9296)|Win32 DLL|Ursu|2014-09-28 06:55:13|dsound.dll|
|[0ad88657f0f89a5a1686266f7466c7af](https://www.virustotal.com/gui/file/0ad88657f0f89a5a1686266f7466c7af)|Win32 EXE||2014-09-28 06:23:22|WinWord|
|[53e823ab57fdd9dc4af19fcb653d225e](https://www.virustotal.com/gui/file/53e823ab57fdd9dc4af19fcb653d225e)|Win32 EXE||2014-09-27 05:11:23|1.tmp|
|[6640ddaeda4fb8549745557a2749cfda](https://www.virustotal.com/gui/file/6640ddaeda4fb8549745557a2749cfda)|Win32 EXE||2014-09-26 08:41:11|WinWord|
|[33d83354da004b7ab5bfe645e508bc2f](https://www.virustotal.com/gui/file/33d83354da004b7ab5bfe645e508bc2f)|Win32 EXE|Dorkbot|2014-09-25 17:29:12|host.exe|
|[38914e9ae49b2ada0d05e3c45b7b1ab2](https://www.virustotal.com/gui/file/38914e9ae49b2ada0d05e3c45b7b1ab2)|Win32 DLL|Ursu|2014-09-25 16:49:45|AeroGlass.theme|
|[e9647474dd5aa49011b6484f25ff3f72](https://www.virustotal.com/gui/file/e9647474dd5aa49011b6484f25ff3f72)|Win32 EXE||2014-09-25 16:48:01|WinWord|
|[555f7f51c330704f8436d56c4024640d](https://www.virustotal.com/gui/file/555f7f51c330704f8436d56c4024640d)|Win32 EXE||2014-09-18 23:30:37|host.exe|
|[14fb05827c79fbb490a5a3c00894a4e9](https://www.virustotal.com/gui/file/14fb05827c79fbb490a5a3c00894a4e9)|Win32 EXE||2014-09-18 21:14:33|host.exe|
|[a9b7937a3c9483e8f89c8ab8c449fdc9](https://www.virustotal.com/gui/file/a9b7937a3c9483e8f89c8ab8c449fdc9)|Win32 EXE|dynamer|2014-09-18 06:47:51|TODO: <Internal name>|
|[32a5347397990ece5d97f17c537e5e46](https://www.virustotal.com/gui/file/32a5347397990ece5d97f17c537e5e46)|Win32 EXE||2014-09-12 11:04:10|WinWord|
|[57c229375f8bac32e616c1eba81b5550](https://www.virustotal.com/gui/file/57c229375f8bac32e616c1eba81b5550)|Win32 EXE||2014-09-12 08:08:48|WinWord|
|[fe4fe6294fe79c2b9fe42b201af9d2b4](https://www.virustotal.com/gui/file/fe4fe6294fe79c2b9fe42b201af9d2b4)|Win32 EXE|Dorkbot|2014-08-29 17:41:24|host.exe|
|[9cdd38047d8f48c70fd6efadc505e81b](https://www.virustotal.com/gui/file/9cdd38047d8f48c70fd6efadc505e81b)|Win32 EXE|Dorkbot|2014-08-19 01:06:14|Excel|
|[e8884ab5b3d42eb9b6cea8ffa10b652b](https://www.virustotal.com/gui/file/e8884ab5b3d42eb9b6cea8ffa10b652b)|Win32 EXE|Dorkbot|2014-08-19 00:58:53|WinWord|
|[dd9ce9fba30ba9d94dd474b83abf5256](https://www.virustotal.com/gui/file/dd9ce9fba30ba9d94dd474b83abf5256)|Win32 DLL|Ursu|2014-08-19 00:45:02|AeroGlass.theme|
|[4036184f71bfc5dc93c0449ed7cc2668](https://www.virustotal.com/gui/file/4036184f71bfc5dc93c0449ed7cc2668)|Win32 EXE|Dorkbot|2014-08-19 00:43:30|WinWord|
|[36c14600100a8d4bff941332d062abf6](https://www.virustotal.com/gui/file/36c14600100a8d4bff941332d062abf6)|Win32 EXE|dynamer|2014-08-18 18:32:48|Defrag.EXE|
|[8ab646993de7fe9ef98d959a550414b6](https://www.virustotal.com/gui/file/8ab646993de7fe9ef98d959a550414b6)|Win32 DLL|Ursu|2014-08-18 06:04:32|dsound.dll|
|[82c4831a0298836e7e9ee2ddad63fad5](https://www.virustotal.com/gui/file/82c4831a0298836e7e9ee2ddad63fad5)|Win32 EXE||2014-08-18 06:04:31|DevicePairing|
|[2d5bd9dd78bbd63f4eda6ed04be1e55a](https://www.virustotal.com/gui/file/2d5bd9dd78bbd63f4eda6ed04be1e55a)|Win32 EXE||2014-08-18 05:44:48|WinWord|
|[8b512d0134366bdc00991a10559f5b9d](https://www.virustotal.com/gui/file/8b512d0134366bdc00991a10559f5b9d)|Win32 EXE|Dorkbot|2014-08-12 16:00:06|Excel|
|[f6fb6e0d42523fb0b762084fb07337c3](https://www.virustotal.com/gui/file/f6fb6e0d42523fb0b762084fb07337c3)|Win32 EXE|Dorkbot|2014-08-12 15:58:47|Excel|
|[2fce620acc6f6f6cb433431171350eb1](https://www.virustotal.com/gui/file/2fce620acc6f6f6cb433431171350eb1)|Win32 EXE|Dorkbot|2014-08-11 22:42:48|host.exe|
|[a2623e9099e2cddb97a061d6ab4f6038](https://www.virustotal.com/gui/file/a2623e9099e2cddb97a061d6ab4f6038)|Win32 EXE|Dorkbot|2014-08-08 02:00:44|host.exe|
|[ccdad17022c40a9f63cd2aa12e9a57f9](https://www.virustotal.com/gui/file/ccdad17022c40a9f63cd2aa12e9a57f9)|Win32 DLL|Ursu|2014-08-08 01:53:27|AeroGlass.theme|
|[24242d1f6ce7ffdb24f484f5b1ffc260](https://www.virustotal.com/gui/file/24242d1f6ce7ffdb24f484f5b1ffc260)|Win32 EXE|Dorkbot|2014-08-05 11:15:44|WinWord|
|[a19078f7481f917418a2baa9a29f64e6](https://www.virustotal.com/gui/file/a19078f7481f917418a2baa9a29f64e6)|Win32 EXE||2014-08-03 14:33:13|WinWord|
|[db12f90f1b1d8a258b140ffe1526878a](https://www.virustotal.com/gui/file/db12f90f1b1d8a258b140ffe1526878a)|Win32 DLL|Ursu|2014-08-01 06:59:24|dsound.dll|
|[05b5a9cf693ab3510a271da3eb21e120](https://www.virustotal.com/gui/file/05b5a9cf693ab3510a271da3eb21e120)|Win32 EXE||2014-08-01 05:57:48|WinWord|
|[39bbd9b5f26a99fcf9b091afed8481e3](https://www.virustotal.com/gui/file/39bbd9b5f26a99fcf9b091afed8481e3)|Win32 EXE||2014-07-23 10:06:23|WinWord|
|[0fcae64e272699b4b7e94b865434cd50](https://www.virustotal.com/gui/file/0fcae64e272699b4b7e94b865434cd50)|Win32 EXE||2014-07-22 19:32:19|0fcae64e272699b4b7e94b865434cd50|
|[1643fdaf7da838a2d2f0430a40374996](https://www.virustotal.com/gui/file/1643fdaf7da838a2d2f0430a40374996)|Win32 EXE||2014-07-21 14:42:29|vt-upload-FnGMI|
|[42e9fb3caa27ffe2a010e1e064239f66](https://www.virustotal.com/gui/file/42e9fb3caa27ffe2a010e1e064239f66)|Win32 EXE|skeeyah|2014-07-10 16:50:58|26827f0eb2ba9e4a1e6880cf71852223ff290544|
|[ee39893b114d0ef128c4a1ff7d08fd2c](https://www.virustotal.com/gui/file/ee39893b114d0ef128c4a1ff7d08fd2c)|Win32 EXE||2014-07-07 16:58:26|WinWord|
|[b8fa7c645833a336064c4cd8873e1739](https://www.virustotal.com/gui/file/b8fa7c645833a336064c4cd8873e1739)|Win32 DLL||2014-07-04 16:20:10|Bundle.rdb|
|[5548cd41f300129769e6289198c34704](https://www.virustotal.com/gui/file/5548cd41f300129769e6289198c34704)|Win32 EXE||2014-07-04 16:15:33|WinWord|
|[9508d1a0f54b205112b8ee5e838d347f](https://www.virustotal.com/gui/file/9508d1a0f54b205112b8ee5e838d347f)|Win32 EXE||2014-07-04 08:07:42|Windows Desktop Gadgets|
|[4c35a9578d017dd7a6abf785ac6f9884](https://www.virustotal.com/gui/file/4c35a9578d017dd7a6abf785ac6f9884)|Win32 DLL|Ursu|2014-07-04 08:07:40|AeroGlass.theme|
|[9773b233f11a46961f454bee949e52c2](https://www.virustotal.com/gui/file/9773b233f11a46961f454bee949e52c2)|Win32 EXE||2014-07-04 08:01:43|Binary.G4_NoCheckVm_Raw_2008_09_12_022012.exe|
|[5bc195062723cdc300fa6274fadbba26](https://www.virustotal.com/gui/file/5bc195062723cdc300fa6274fadbba26)|Win32 DLL||2014-06-24 07:50:33|ab04ae2e8c8ec4bec80ae9d96dfd8acc23cd7f57a9225959633aaffbcb5a062d.vir|
|[d3943db3c46bf9b07625da9d8bf28a3e](https://www.virustotal.com/gui/file/d3943db3c46bf9b07625da9d8bf28a3e)|Win32 EXE|Dorkbot|2014-06-24 07:48:59|WinWord|
|[a5fbf94f9d43a8e1690c76019ddf6d24](https://www.virustotal.com/gui/file/a5fbf94f9d43a8e1690c76019ddf6d24)|Win32 EXE||2014-06-23 11:54:46|WinWord|
|[67ce93aff99864c118cb93824742d0fe](https://www.virustotal.com/gui/file/67ce93aff99864c118cb93824742d0fe)|Win32 EXE||2014-06-19 12:46:03|WinWord|
|[1734aee9190d256fc6cb2314f35d3a59](https://www.virustotal.com/gui/file/1734aee9190d256fc6cb2314f35d3a59)|Win64 EXE||2014-06-12 16:04:36|gpx64.exe|
|[887a4680ba30c78720a12bb04e452ef0](https://www.virustotal.com/gui/file/887a4680ba30c78720a12bb04e452ef0)|Win32 EXE||2014-06-07 15:35:28|Windows Desktop Gadgets|
|[0a10c6c3429ae442264a415a4961b0b3](https://www.virustotal.com/gui/file/0a10c6c3429ae442264a415a4961b0b3)|Win32 EXE||2014-06-05 09:45:03|myfile.exe|
|[72241354d11f2d7842e8fc019240a92f](https://www.virustotal.com/gui/file/72241354d11f2d7842e8fc019240a92f)|Win32 EXE||2014-05-29 12:44:25|WinWord|
|[804a43546a2731b236dd557ed5785c37](https://www.virustotal.com/gui/file/804a43546a2731b236dd557ed5785c37)|Win32 DLL||2014-05-22 14:11:39|804a43546a2731b236dd557ed5785c37|
|[810ef71bb52ea5c3cfe58b8e003520dc](https://www.virustotal.com/gui/file/810ef71bb52ea5c3cfe58b8e003520dc)|Android||2014-05-06 07:59:47|17d16530c9e5504dd216bca083ec5435f9fa705600526dec48c51ab5b89cd699.bin|
|[aee1d02a167f2871568498c967140e40](https://www.virustotal.com/gui/file/aee1d02a167f2871568498c967140e40)|Win32 EXE||2014-04-27 06:13:39|WinWord|
|[2607e42b04cb1d2a49ba6d5bb79ea61d](https://www.virustotal.com/gui/file/2607e42b04cb1d2a49ba6d5bb79ea61d)|Win32 EXE||2014-04-26 03:33:26|WinWord|
|[ad32e5198c33aa5a7e4aef97b7a7c09e](https://www.virustotal.com/gui/file/ad32e5198c33aa5a7e4aef97b7a7c09e)|Android||2014-04-13 10:14:29|44bbeb4031b186e01f422dc09e16412accd3e799420f2de3881395e755574b9a.bin|
|[05df610e1fad148c6558b7a2d9d229c2](https://www.virustotal.com/gui/file/05df610e1fad148c6558b7a2d9d229c2)|Win32 EXE||2014-03-31 18:34:13|vti-rescan|
|[6a6adda21284218fc65eb65d7198af34](https://www.virustotal.com/gui/file/6a6adda21284218fc65eb65d7198af34)|Win32 EXE||2014-03-30 19:58:53|nc|
|[270ea871328add9a6d3eedc5f404b47a](https://www.virustotal.com/gui/file/270ea871328add9a6d3eedc5f404b47a)|Win32 DLL||2014-03-11 03:52:16|vt-upload-p5y4q|
|[26c0af2fdf2702e4680f4736cae9a138](https://www.virustotal.com/gui/file/26c0af2fdf2702e4680f4736cae9a138)|Win32 EXE|Dorkbot|2014-01-30 06:30:04|iexplore|
|[524f0c0ba74d64e2ca20b11b955eff01](https://www.virustotal.com/gui/file/524f0c0ba74d64e2ca20b11b955eff01)|Win32 EXE||2014-01-27 02:33:50|WinWord|
|[5436d8c936136446edcf411465dcab66](https://www.virustotal.com/gui/file/5436d8c936136446edcf411465dcab66)|Win32 DLL||2014-01-27 02:28:33|Bundle.rdb|
|[e9b74f9a2a78c0ea9f892de242728b4f](https://www.virustotal.com/gui/file/e9b74f9a2a78c0ea9f892de242728b4f)|Win32 EXE|Dorkbot|2014-01-16 09:09:52|WinWord|
|[156d3f9063f86e51923814361010bbdf](https://www.virustotal.com/gui/file/156d3f9063f86e51923814361010bbdf)|Win32 DLL||2014-01-12 00:07:27|e28680cf2130ba278e10427bc3d67ca230519c32|
|[74be817380e9343e774d5b5c63b7947a](https://www.virustotal.com/gui/file/74be817380e9343e774d5b5c63b7947a)|Win32 DLL|Ursu|2014-01-05 23:19:23|74be817380e9343e774d5b5c63b7947a|
|[02b4e57dc30c20e54918862146e159fa](https://www.virustotal.com/gui/file/02b4e57dc30c20e54918862146e159fa)|Win32 DLL|Ursu|2014-01-05 23:02:07|53d4fce5b2b2bf22737b72c1c215a7d5297c9afa|
|[f143595b3c5f7f90373690a04f18554f](https://www.virustotal.com/gui/file/f143595b3c5f7f90373690a04f18554f)|Win32 DLL||2013-12-25 17:01:30|Bundle.rdb|
|[86c5495b048878ec903e6250600ec308](https://www.virustotal.com/gui/file/86c5495b048878ec903e6250600ec308)|Android||2013-12-17 06:46:29|/mnt_pe/86/C5/86C5495B048878EC903E6250600EC308|
|[2ff99125be513fb8d98163a8a843d5ae](https://www.virustotal.com/gui/file/2ff99125be513fb8d98163a8a843d5ae)|Win32 DLL||2013-12-16 04:00:44|isheriff_2ff99125be513fb8d98163a8a843d5ae.bin|
|[1b37f04b16ddd31095ca48ed6a7aa865](https://www.virustotal.com/gui/file/1b37f04b16ddd31095ca48ed6a7aa865)|Win32 EXE|Dorkbot|2013-12-05 07:41:28|Google Update Setup|
|[9ccf5f76c6445841d7a40ac2affd572b](https://www.virustotal.com/gui/file/9ccf5f76c6445841d7a40ac2affd572b)|Win32 EXE||2013-11-18 20:36:12|WinWord|
|[af170750a8228c9e5f21bfc35fc67721](https://www.virustotal.com/gui/file/af170750a8228c9e5f21bfc35fc67721)|DOC||2013-11-05 21:18:24|4e2d1e15666c32311c9b4014ce5ac6d86dcf5255_351813270729b78fb2fe33be9c57fcd6f3828576171c7f404ed53af77cd91206|
|[0b02e53a03006ad65412ea75b292f901](https://www.virustotal.com/gui/file/0b02e53a03006ad65412ea75b292f901)|Win32 EXE||2013-10-15 03:54:05|WinWord|
|[423b60ed7e22c63a999f9af46cb05aa2](https://www.virustotal.com/gui/file/423b60ed7e22c63a999f9af46cb05aa2)|Win32 DLL||2013-10-15 03:33:24|Bundle.rdb|
|[dfb252371e6ed0527cf7f3ef6456fd7e](https://www.virustotal.com/gui/file/dfb252371e6ed0527cf7f3ef6456fd7e)|Win32 DLL||2013-09-28 14:55:33|Bundle.rbd|
|[a6d08a322b32721ca11aaa208f7a5b62](https://www.virustotal.com/gui/file/a6d08a322b32721ca11aaa208f7a5b62)|Win32 DLL||2013-09-27 06:49:22|Bundle.rdb|
|[1a60715c51da0caa8a5ebff6fdc9d472](https://www.virustotal.com/gui/file/1a60715c51da0caa8a5ebff6fdc9d472)|DOC|CVE-2012-0158|2013-09-12 17:47:53|vti-rescan|
|[96651e9502a1ca55eb4d3ceca731cc0b](https://www.virustotal.com/gui/file/96651e9502a1ca55eb4d3ceca731cc0b)|Win32 EXE||2013-08-27 08:49:32|a3f42f2e5d52c05e65e573e5d8e4bd8d58b5f9bd|
|[8fb9b017149ebaec7f64e35cb66c4bfd](https://www.virustotal.com/gui/file/8fb9b017149ebaec7f64e35cb66c4bfd)|Win32 EXE||2013-08-26 18:36:40|WinWord|
|[c85d90eae97e8e62e4a13e386292ff48](https://www.virustotal.com/gui/file/c85d90eae97e8e62e4a13e386292ff48)|Win32 DLL|Ursu|2013-08-06 12:52:44|c85d90eae97e8e62e4a13e386292ff48|
|[0e01a30ee81b3837e8355c792baea65f](https://www.virustotal.com/gui/file/0e01a30ee81b3837e8355c792baea65f)|Win32 EXE||2013-07-03 07:54:31|WinWord|
|[1ee014ddeddf9912efd6bb5f45bef443](https://www.virustotal.com/gui/file/1ee014ddeddf9912efd6bb5f45bef443)|Win32 DLL|Ursu|2013-06-02 07:43:35|\sonas\share\samples\1e\e0\14\dd\1ee014ddeddf9912efd6bb5f45bef443.bbe09d0738ecb07849ee7027cff361245d9876e0|
|[3dee4060d65db4d7822b3cf0cf240e56](https://www.virustotal.com/gui/file/3dee4060d65db4d7822b3cf0cf240e56)|Win32 DLL|Ursu|2013-05-31 02:03:36|vt-upload-qGqPD|
|[858ab7b47c8c989ac965d3fbecafbd9d](https://www.virustotal.com/gui/file/858ab7b47c8c989ac965d3fbecafbd9d)|Win32 DLL|Ursu|2013-05-31 00:55:18|vt-upload-Dx7do|
|[30cde4eeb36b57683d1cc182983110c8](https://www.virustotal.com/gui/file/30cde4eeb36b57683d1cc182983110c8)|Win32 DLL|Ursu|2013-05-29 08:42:32|AeroGlass.theme|
|[e7e53b219c302b3de01d19c51ee55811](https://www.virustotal.com/gui/file/e7e53b219c302b3de01d19c51ee55811)|Win32 DLL|tiggre|2013-05-22 14:21:21|MediaCodec.ax|
|[9dd8a2edf4c9788afa44153612753ea7](https://www.virustotal.com/gui/file/9dd8a2edf4c9788afa44153612753ea7)|Win32 DLL|Ursu|2013-04-04 12:59:42|\sonas\share\samples\9d\d8\a2\ed\9dd8a2edf4c9788afa44153612753ea7.ca4cb79d1c143237722e0d566db115ffff435484|
|[09e62ba3ff421b6813f6588fa144d6ad](https://www.virustotal.com/gui/file/09e62ba3ff421b6813f6588fa144d6ad)|Win32 EXE||2013-03-17 16:43:08|Windows Desktop Gadgets|
|[d33a9365a7e71f728b993a4a3ae58335](https://www.virustotal.com/gui/file/d33a9365a7e71f728b993a4a3ae58335)|Win32 DLL|Ursu|2013-03-15 04:04:53|d33a9365a7e71f728b993a4a3ae58335.bin|
|[f38d0fb4f1ac3571f07006fb85130a0d](https://www.virustotal.com/gui/file/f38d0fb4f1ac3571f07006fb85130a0d)|Win32 EXE||2013-03-11 10:38:19|vti-rescan|
|[62646ea0a4ce1e6d955cbaef8c4a510d](https://www.virustotal.com/gui/file/62646ea0a4ce1e6d955cbaef8c4a510d)|Win32 DLL||2013-03-11 10:38:19|cb4c23e3c9b8d155_disk1.img|
|[90f5bbba8760f964b933c5f0007592d2](https://www.virustotal.com/gui/file/90f5bbba8760f964b933c5f0007592d2)|Win32 EXE||2013-03-11 10:38:18|Defrag.EXE|
|[2ed103e5bda1a7a68d3b138e7726b1c0](https://www.virustotal.com/gui/file/2ed103e5bda1a7a68d3b138e7726b1c0)|Win32 EXE||2013-03-07 02:05:45|WinWord|
|[382a2802a676355a9b532672032f0f60](https://www.virustotal.com/gui/file/382a2802a676355a9b532672032f0f60)|Win32 EXE||2013-03-06 02:32:28|PwSafe|
|[616d32151c907fdd4e718bde2163cc40](https://www.virustotal.com/gui/file/616d32151c907fdd4e718bde2163cc40)|DOC||2013-03-05 06:24:21|2|
|[61bb7bc823ce614fbae222a96adff6eb](https://www.virustotal.com/gui/file/61bb7bc823ce614fbae222a96adff6eb)|Win32 DLL|Ursu|2013-03-03 19:35:58|AeroGlass.theme|
|[6e667d6c9e527ada1a3284aa333d954d](https://www.virustotal.com/gui/file/6e667d6c9e527ada1a3284aa333d954d)|DOC||2013-02-24 01:07:00|1089a4db6a15e8ed605cd5be0ffde44fcd81f35c_exe.ex|
|[f76cea9b7fa42d487c7d90a30a77b7ba](https://www.virustotal.com/gui/file/f76cea9b7fa42d487c7d90a30a77b7ba)|Win32 EXE||2013-02-05 08:50:23|WinWord|
|[23b7d7d024abb0f558420e098800bf27](https://www.virustotal.com/gui/file/23b7d7d024abb0f558420e098800bf27)|Text||2009-04-25 20:17:20|PkgInfo|
|[03e0a5b4e142ce94a34926f9f600cbf4](https://www.virustotal.com/gui/file/03e0a5b4e142ce94a34926f9f600cbf4)|Win32 DLL||2020-04-07 11:34:12|AhnI2.dll|
|[a7d7cde4a86089d58b254d23c026df8c](https://www.virustotal.com/gui/file/a7d7cde4a86089d58b254d23c026df8c)|Win32 DLL|cometer|2020-11-06 19:37:38|goopdate.dll|
|[bd628b4f887070d9f014c3fb72859739](https://www.virustotal.com/gui/file/bd628b4f887070d9f014c3fb72859739)|RAR|cometer|2020-11-06 16:06:28|Adobe_Flash_Install.rar|
|[c5adf43a4043c88e79f0520c6763589e](https://www.virustotal.com/gui/file/c5adf43a4043c88e79f0520c6763589e)|RAR||2020-10-12 13:45:18|Kien nghi ve cong tac can bo.rar|
|[e2511f009b1ef8843e527f765fd875a7](https://www.virustotal.com/gui/file/e2511f009b1ef8843e527f765fd875a7)|TXT||2020-07-29 07:38:50| |
|[cc2027319a878ee18550e35d9b522706](https://www.virustotal.com/gui/file/cc2027319a878ee18550e35d9b522706)|TXT||2020-07-29 07:34:16| |
|[0e7b59b601a1c7ecd6f2f54b5cd8416a](https://www.virustotal.com/gui/file/0e7b59b601a1c7ecd6f2f54b5cd8416a)|Android||2020-07-26 17:04:26| |
|[32218286a3ed33541c4aa31722c8d2c2](https://www.virustotal.com/gui/file/32218286a3ed33541c4aa31722c8d2c2)|TXT|o97m|2020-07-15 07:43:06|Report_tiecuoi.doc|
|[ba75bbf3f3f62af61bf6f677d0d98d86](https://www.virustotal.com/gui/file/ba75bbf3f3f62af61bf6f677d0d98d86)|TXT||2020-07-09 12:59:21| |
|[5993d2a1e7a218c0faab417addd48450](https://www.virustotal.com/gui/file/5993d2a1e7a218c0faab417addd48450)|TXT||2020-07-09 10:24:21| |
|[0ddc57d188bd0cebe5c71a14a53fb4bd](https://www.virustotal.com/gui/file/0ddc57d188bd0cebe5c71a14a53fb4bd)|TXT||2020-07-09 10:22:30| |
|[a4808a329b071a1a37b8d03b1305b0cb](https://www.virustotal.com/gui/file/a4808a329b071a1a37b8d03b1305b0cb)|unknown||2020-06-14 16:27:50|krpt.dll_78144_589391.bin|
|[721254f41286717aa1cd9d7d652a9fa1](https://www.virustotal.com/gui/file/721254f41286717aa1cd9d7d652a9fa1)|Win32 DLL|cometer|2020-06-03 10:34:07|yULB|
|[bb12cc42243ca325a7fe27f88f5b1e1b](https://www.virustotal.com/gui/file/bb12cc42243ca325a7fe27f88f5b1e1b)|unknown|Bitrep|2020-05-13 03:11:59|bb12cc42243ca325a7fe27f88f5b1e1b.virus|
|[49d1c82a6b73551743a12faec0c9e8b1](https://www.virustotal.com/gui/file/49d1c82a6b73551743a12faec0c9e8b1)|Android|Wacatac|2020-04-05 11:25:42|d011d96311e57bcd5a3920d4ff9068b9d044a470116a708b10568cd207426e13.bin|
|[c5b98b77810c5619d20b71791b820529](https://www.virustotal.com/gui/file/c5b98b77810c5619d20b71791b820529)|RTF||2020-03-26 04:12:06|c:\windows\system32\pjk6uc.exe|
|[94a3ca93f1500b5bd7fd020569e46589](https://www.virustotal.com/gui/file/94a3ca93f1500b5bd7fd020569e46589)|Android||2020-03-16 10:39:39|ae7efaece7cfc4fae1d8d384d13cc082aabc6d19d743dd719857acab7d231dcd.bin|
|[d739f10933c11bd6bd9677f91893986c](https://www.virustotal.com/gui/file/d739f10933c11bd6bd9677f91893986c)|Win32 DLL|Qrypter|2020-03-04 14:32:38|C:\Users\ADMINI~1\AppData\Local\Temp\krpt.dll|
|[c8ea645fc5ac975af53e568566b90131](https://www.virustotal.com/gui/file/c8ea645fc5ac975af53e568566b90131)|Win32 DLL||2020-03-04 14:31:55|./KISA_dataset_2020_train/c0d295d414ccd0b84a0e6c9f8c42083355a92ba97182d3aed9d5e8a99e3a99b1.vir|
|[0d5c03da348dce513bf575545493f3e3](https://www.virustotal.com/gui/file/0d5c03da348dce513bf575545493f3e3)|Android||2020-01-20 16:20:06|c66f2395552c700ced300e1c7e0c56940b7f6fa3673227d685c3c4d6f6e9cff7.bin|
|[b107c35b4ca3e549bdf102de918749ba](https://www.virustotal.com/gui/file/b107c35b4ca3e549bdf102de918749ba)|Android||2020-01-17 07:24:33|04fe6084440633810cdda6ff6e89d6bfac0bcaacbdadbccc0732e6f00452cc33.bin|
|[79f06cb9281177a51278b2a33090c867](https://www.virustotal.com/gui/file/79f06cb9281177a51278b2a33090c867)|Android||2020-01-14 02:35:56|53b3c943b82211a6afd94e9da1f0e301bce7501d188288357d2f29254bbcafda.bin|
|[d23472f47833049034011cad68958b46](https://www.virustotal.com/gui/file/d23472f47833049034011cad68958b46)|Android||2020-01-06 14:05:11|57c55b4ff3b2c3595156cf714cd1eb9695036580086cd3e7960ae417a20d3389.bin|
|[a795f662d10040728e916e1fd7570c1d](https://www.virustotal.com/gui/file/a795f662d10040728e916e1fd7570c1d)|Android||2020-01-05 21:42:32|bb1fb71eae1c51f2233fcbca6bb4493edf1ed5fe920fdc3213b5180e30d4b068.bin|
|[b4706f171cf98742413d642b6ae728dc](https://www.virustotal.com/gui/file/b4706f171cf98742413d642b6ae728dc)|Android||2020-01-03 08:28:11|f9d4b223ace4d8c8f2e2d32aae2d090c0dee8017d6f3df3b0b966c6a56071eb6.bin|
|[af44bb0dd464680395230ade0d6414cd](https://www.virustotal.com/gui/file/af44bb0dd464680395230ade0d6414cd)|Android||2020-01-03 08:19:51|99eba5020158332510da7732473142492010ce7a3ae2f0e4749212764f9f4528.bin|
|[2e49775599942815ab84d9de13e338b3](https://www.virustotal.com/gui/file/2e49775599942815ab84d9de13e338b3)|Android||2019-11-28 02:13:36|50e5da38fc44cc603e7e74bd5534a3947ecedaf19c268fadc01eebe746052837.bin|
|[83c423c36ecda310375e8a1f4348a35e](https://www.virustotal.com/gui/file/83c423c36ecda310375e8a1f4348a35e)|Android||2019-11-27 02:16:20|07507ab765b73351f786f1b9a059c2d834bfd65023fbf43df3346acdc8cbcf78.bin|
|[7285f44fa75c3c7a27bbb4870fc0cdca](https://www.virustotal.com/gui/file/7285f44fa75c3c7a27bbb4870fc0cdca)|Android||2019-11-26 14:06:13|ed0fffd76bbd0098fc60fc772bb7c2a228236ac1cc3cae0e084852579c2c647b.bin|
|[2e06bbc26611305b28b40349a600f95c](https://www.virustotal.com/gui/file/2e06bbc26611305b28b40349a600f95c)|Android||2019-11-11 01:08:14|f34ab020ebecefb6cbec2b9f119e8919262df1bc0bdb53c019c4c437ecf1289f.bin|
|[8d5c64fdaae76bb74831c0543a7865c3](https://www.virustotal.com/gui/file/8d5c64fdaae76bb74831c0543a7865c3)|Android||2019-10-28 17:09:23|data/data/com.sailmedia.supcodec/files/1562779497778.apk|
|[3285ae59877c6241200f784b62531694](https://www.virustotal.com/gui/file/3285ae59877c6241200f784b62531694)|Android|Wacatac|2019-08-05 00:54:49|8449cd744f1b40b487ee2c9ed2ea368b805b98bfa8cc92aa48fc3bd24607dcde.bin|
|[8008bedaaebc1284b1b834c5fd9a7a71](https://www.virustotal.com/gui/file/8008bedaaebc1284b1b834c5fd9a7a71)|Android||2019-07-29 01:17:23|2c6586d3df2712314f7c3ed1b8e278a02424c30efcb445d086e4eda895afff10.bin|
|[e648a2cc826707aec33208408b882e31](https://www.virustotal.com/gui/file/e648a2cc826707aec33208408b882e31)|Android||2019-07-06 12:40:08|data/data/com.physlane.opengl/files/1562348459145.apk|
|[fe15c0eacdbf5a46bc9b2af9c551f86a](https://www.virustotal.com/gui/file/fe15c0eacdbf5a46bc9b2af9c551f86a)|Android||2019-05-19 17:44:53|00cb026d3de6e68662423880cf9eb8f2fefe7513f2a732703add40d284e0a810.bin|
|[c334bade6aa52db3eccf0167a591966a](https://www.virustotal.com/gui/file/c334bade6aa52db3eccf0167a591966a)|Android|occamy|2019-04-12 01:11:34|5e4fc37292377b722050e122e500768495e2e8190b778e459761184f7d4caf34.bin|
|[3fe46408a43259e400f7088c211a16a3](https://www.virustotal.com/gui/file/3fe46408a43259e400f7088c211a16a3)|Android||2019-04-11 01:44:17|d9df3d919095b830f7c49266a9a265da128ede167fc9db11c2f1cd971b850e47.bin|
|[d61c18e577cfc046a6252775da12294f](https://www.virustotal.com/gui/file/d61c18e577cfc046a6252775da12294f)|Android|androidos|2019-01-15 08:39:09|182a089c9ab1ef0c162afc04bd8ce27c47393fd1726526e98c2383a04fe82e3c.bin|
|[6bf9b834d841b13348851f2dc033773e](https://www.virustotal.com/gui/file/6bf9b834d841b13348851f2dc033773e)|Android||2019-01-10 05:08:11|8a5e0722566c2638b7d01d71e29ec7cd4c532e0e53ccd20379e48dd925daabfd.bin|
|[76265edd8c8c91ad449f9f30c02d2e0b](https://www.virustotal.com/gui/file/76265edd8c8c91ad449f9f30c02d2e0b)|Android||2019-01-06 11:34:09|ea278e1f2bf3b3738ca57ea6d2f7c52fa54f504a0920b63a908ef8e7746c6592.bin|
|[1fb9d7122107b3c048a4a201d0da54cd](https://www.virustotal.com/gui/file/1fb9d7122107b3c048a4a201d0da54cd)|Android|Wacatac|2019-01-06 10:16:11|8fbbd66309e020cc1650fcf5d4eed748241b52c222af9b8bcd3df13b376398e1.bin|
|[a57bac46c5690a6896374c68aa44d7b3](https://www.virustotal.com/gui/file/a57bac46c5690a6896374c68aa44d7b3)|Android||2018-12-22 00:31:46|81f9f82af300298eebae3078200326104aba678df9cec6d2f0b130623a02dd59.bin|
|[f0ea1a4d81f8970b0a1f4d5c41f728d8](https://www.virustotal.com/gui/file/f0ea1a4d81f8970b0a1f4d5c41f728d8)|Android||2018-11-07 01:56:52|4c5f40775434115f81fa3713420275f41da69866c9553be87c57b07c4dbebee6.bin|
|[2e1ed1f4a5c9149c241856fb07b8216b](https://www.virustotal.com/gui/file/2e1ed1f4a5c9149c241856fb07b8216b)|Android||2018-10-13 17:08:53|0fb3f5b2aabe00671fa174d1594f05be12164f50f06a34dd0ba6a0b66f1b17c1.bin|
|[6b323840d7cb55bb5c9287fc7b137e83](https://www.virustotal.com/gui/file/6b323840d7cb55bb5c9287fc7b137e83)|Android||2018-09-24 12:53:41|611acd5e7e26f6ef28fa02d00d7f890dbba51a5d380493fd92b8d72d687e3f77.bin|
|[872a3dd2cd5e01633b57fa5b9ac4648d](https://www.virustotal.com/gui/file/872a3dd2cd5e01633b57fa5b9ac4648d)|Android||2018-09-23 08:06:04|ac5b5292da27f10b8b0de3be893d1f75edee15999c58a5f1f99e0b99d3d565bd.bin|
|[65d399e6a77acf7e63ba771877f96f8e](https://www.virustotal.com/gui/file/65d399e6a77acf7e63ba771877f96f8e)|Android||2018-08-19 11:48:40|11bde4e3d2b5da5f4b94161cfe257330289cd8ab8248a60a457886b10aef740d.bin|
|[a330456d7ca25c88060dc158049f3298](https://www.virustotal.com/gui/file/a330456d7ca25c88060dc158049f3298)|Android||2018-08-10 09:28:24|804cb3a22eae0b8b371004110d218cfc5ff85a501b18f13b9f6e2d1b68fa5d69.bin|
|[a097b8d49386c8aab0bb38bbfdf315b2](https://www.virustotal.com/gui/file/a097b8d49386c8aab0bb38bbfdf315b2)|Android||2018-08-05 11:18:40|2f10dfc5a34e3684f49b6db69b8f3a827dff7f9c7c4e8fc6c113501d8b0245fd.bin|
|[54777021c34b0aed226145fde8424991](https://www.virustotal.com/gui/file/54777021c34b0aed226145fde8424991)|Android||2018-03-26 18:21:36|cb5077bd6118a40940cdf270cea286e640a739b2d28698d5d4e1c8a3e8ca9508.bin|
|[1e5213e02dd6f7152f4146e14ba7aa36](https://www.virustotal.com/gui/file/1e5213e02dd6f7152f4146e14ba7aa36)|Android||2017-05-20 03:00:29|8c107508d831b009883cb53bf0711a9aa51a879e6406c281caa9e74f835ee2d2.bin|
|[243e2c6433815f2ecc204ada4821e7d6](https://www.virustotal.com/gui/file/243e2c6433815f2ecc204ada4821e7d6)|Android||2017-05-15 22:22:43|b5532ac47f89c0aa9f79c57b38492b4c023c71437b0936e512ae0f66f0fcba87.bin|
|[3d4373015fd5473e0af73bdb3d65fe6a](https://www.virustotal.com/gui/file/3d4373015fd5473e0af73bdb3d65fe6a)|Android||2016-06-06 15:47:05|da27655193a82b1fc5fc8892fa92842962ea8aa098b764065298d23a6711222a.bin|
|[320e2283c8751851362b858ad5b7b49c](https://www.virustotal.com/gui/file/320e2283c8751851362b858ad5b7b49c)|Android||2015-12-29 05:46:05|41b4535b9242f9db9bd3e1f643bfd034543b4f211f88f7952511b01d8dc69119.bin|
|[08663152d9e9083d7be46eb2a16d374c](https://www.virustotal.com/gui/file/08663152d9e9083d7be46eb2a16d374c)|Android||2015-04-23 10:55:27|ad471a2f26c29336076821d7297f2299aebd65aeaeb359f85a4ff87d7855cd4f.bin|
|[07e01c2fa020724887fc39e5c97eccee](https://www.virustotal.com/gui/file/07e01c2fa020724887fc39e5c97eccee)|Android|Wacatac|2015-03-15 05:35:00|f2d97b508d6f51c9f15175a44a162a05985054610a38c3df3e70cd72eae9449c.bin|
|[f449cca2bc85b09e9bf4d3c4afa707b6](https://www.virustotal.com/gui/file/f449cca2bc85b09e9bf4d3c4afa707b6)|Android|Wacatac|2014-07-18 21:34:48|c99e4e35fc5ce364a6abcfd501a6871b6602beaee54b3d2b0c400ad1ff94ec5f.bin|
