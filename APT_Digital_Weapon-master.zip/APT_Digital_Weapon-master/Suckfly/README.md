**NAME:**  
Suckfly  

**Description**:   
Suckfly, uncovered by Symantec, is an advanced cyberespionage group that conducted attacks against a number of South Korean organizations to steal digital certificates since 2014. The attacks targeted high-profile targets, including government and commercial organizations.

Large corporations that play a major role in India’s economy were also affected, including one of India’s largest e-commerce companies, a major Indian shipping company, one of India’s largest financial organizations, and an IT firm that provides support for India’s largest stock exchange. Saudi Arabian government organizations were compromised as well.
  
**References**:  
http://www.symantec.com/connect/blogs/suckfly-revealing-secret-life-your-code-signing-certificates  
http://www.symantec.com/connect/blogs/indian-organizations-targeted-suckfly-attacks
