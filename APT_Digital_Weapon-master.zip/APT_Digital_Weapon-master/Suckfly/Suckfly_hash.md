|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[05edd53508c55b9dd64129e944662c0d](https://www.virustotal.com/gui/file/05edd53508c55b9dd64129e944662c0d)|Win32 DLL|razy|2015-11-09 17:31:36|Microsoft Corporation|
|[ba7b1392b799c8761349e7728c2656dd](https://www.virustotal.com/gui/file/ba7b1392b799c8761349e7728c2656dd)|Win32 DLL||2015-09-16 17:23:23|Microsoft Corporation|
|[e7d92039ffc2f07496fe7657d982c80f](https://www.virustotal.com/gui/file/e7d92039ffc2f07496fe7657d982c80f)|Win32 DLL|graftor|2015-05-06 22:17:56|Microsoft Corporation|
|[4709395fb143c212891138b98460e958](https://www.virustotal.com/gui/file/4709395fb143c212891138b98460e958)|Win32 EXE|injector|2015-01-07 13:29:36|ac7d7c676f58ebfa5def9b84553f00f283c61e4a310459178ea9e7164004e734.bin|
|[96c317b0b1b14aadfb5a20a03771f85f](https://www.virustotal.com/gui/file/96c317b0b1b14aadfb5a20a03771f85f)|Win32 DLL||2014-08-23 07:58:27|Microsoft Corporation|
|[de5057e579be9e3c53e50f97a9b1832b](https://www.virustotal.com/gui/file/de5057e579be9e3c53e50f97a9b1832b)|Win32 DLL||2014-08-14 18:31:25|Microsoft Corporation|
