|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[eb4e47353e0e0ed95e65c90e59e19644](https://www.virustotal.com/gui/file/eb4e47353e0e0ed95e65c90e59e19644)|Android||2019-07-19 07:07:34| |
|[b22585b5d0d5776c8914308882b23199](https://www.virustotal.com/gui/file/b22585b5d0d5776c8914308882b23199)|Android||2019-07-04 02:23:03| |
|[64b7c2247455f378f95710175c1771ee](https://www.virustotal.com/gui/file/64b7c2247455f378f95710175c1771ee)|Android||2019-07-04 02:21:35|64b7c2247455f378f95710175c1771ee.virus|
|[94c528df4f9a0c2f7fc7f9e513766aaf](https://www.virustotal.com/gui/file/94c528df4f9a0c2f7fc7f9e513766aaf)|RAR|Kryptik|2019-06-21 16:53:50| |
|[a89b8db281372ff61fc95783e5d0d421](https://www.virustotal.com/gui/file/a89b8db281372ff61fc95783e5d0d421)|Android||2019-05-13 19:51:52| |
|[bf531276e344f30133d1434010fcb9da](https://www.virustotal.com/gui/file/bf531276e344f30133d1434010fcb9da)|Android||2019-05-07 20:46:14|bf531276e344f30133d1434010fcb9da.virus|
|[c23673fd2f058781776d926d1c7e9532](https://www.virustotal.com/gui/file/c23673fd2f058781776d926d1c7e9532)|Win32 EXE|Farseer|2019-05-06 22:12:02| |
|[b4438bfe7ef7ac53a3204eaacc65e905](https://www.virustotal.com/gui/file/b4438bfe7ef7ac53a3204eaacc65e905)|Android||2019-04-26 02:51:36|b4438bfe7ef7ac53a3204eaacc65e905.virus|
|[21266cbc15b4974e83ea5ab0d83ee8d1](https://www.virustotal.com/gui/file/21266cbc15b4974e83ea5ab0d83ee8d1)|Android||2019-04-12 03:04:58| |
|[6e80f081ff2b44862d35fb372939faf0](https://www.virustotal.com/gui/file/6e80f081ff2b44862d35fb372939faf0)|Android||2019-04-12 02:29:47| |
|[aa0a7b5dc25f43dbd7ac515808af519a](https://www.virustotal.com/gui/file/aa0a7b5dc25f43dbd7ac515808af519a)|Android||2019-04-09 03:03:52| |
|[6420b2c746869d1f24a0eff773017edb](https://www.virustotal.com/gui/file/6420b2c746869d1f24a0eff773017edb)|Android||2019-04-03 04:15:30| |
|[97905fd55e4708afbb06b21d3501f5f5](https://www.virustotal.com/gui/file/97905fd55e4708afbb06b21d3501f5f5)|Win32 EXE||2019-04-02 09:05:24| |
|[1ba0cb768e49a80d793a9121c78e45e2](https://www.virustotal.com/gui/file/1ba0cb768e49a80d793a9121c78e45e2)|Win32 EXE||2019-03-26 04:22:11| |
|[77f54b13e566cb9137686612dff74222](https://www.virustotal.com/gui/file/77f54b13e566cb9137686612dff74222)|Android||2019-03-19 13:13:31|cspwiqTr2foUs99v92iyeihSpaR7Zl4kzqiVM2tqlohYO54z3Fyg|
|[6750c95cbc98a136d316158a30139ce7](https://www.virustotal.com/gui/file/6750c95cbc98a136d316158a30139ce7)|Win32 EXE||2019-02-27 20:19:15|dttcodexgigas.798a120201fdcb4a4cc4859e75fae01cd58dd4bf|
|[0cb046268059bf4b11ef4f8fe2dfdb36](https://www.virustotal.com/gui/file/0cb046268059bf4b11ef4f8fe2dfdb36)|Win32 EXE|dynamer|2019-02-27 20:08:34|dttcodexgigas.7adafdc243639fa6f7792d371f12a5e2f606b0e6|
|[fdf4480f99a21cf1bf180eaf62e6a12c](https://www.virustotal.com/gui/file/fdf4480f99a21cf1bf180eaf62e6a12c)|Android||2019-02-25 15:24:35|fdf4480f99a21cf1bf180eaf62e6a12c.virus|
|[f876433ec16845b16718ddac25c59a6c](https://www.virustotal.com/gui/file/f876433ec16845b16718ddac25c59a6c)|Android||2019-02-25 15:24:21|f876433ec16845b16718ddac25c59a6c.virus|
|[bd6b556b7542ee72aec5e9b3350f5979](https://www.virustotal.com/gui/file/bd6b556b7542ee72aec5e9b3350f5979)|Android||2019-02-17 16:33:50| |
|[f01b0a2eb26ce27fcae6427129d97a98](https://www.virustotal.com/gui/file/f01b0a2eb26ce27fcae6427129d97a98)|Android||2019-02-10 17:01:42| |
|[07ab8185835062a851178eff88ac9cdc](https://www.virustotal.com/gui/file/07ab8185835062a851178eff88ac9cdc)|Android||2019-01-16 00:01:12| |
|[e15c64c1e0e1e422ec6896f18330908c](https://www.virustotal.com/gui/file/e15c64c1e0e1e422ec6896f18330908c)|Android||2018-12-24 06:16:46|e15c64c1e0e1e422ec6896f18330908c.virus|
|[ba5c0e3741f166c7bdf482b1bf684b58](https://www.virustotal.com/gui/file/ba5c0e3741f166c7bdf482b1bf684b58)|Android||2018-12-01 19:36:45|ba5c0e3741f166c7bdf482b1bf684b58.virus|
|[4ef44b185397bda35fe9463e5bbae566](https://www.virustotal.com/gui/file/4ef44b185397bda35fe9463e5bbae566)|Android||2018-12-01 19:35:06|4ef44b185397bda35fe9463e5bbae566.virus|
|[15d4b8e6d3a0907a7593e34d5b7d0834](https://www.virustotal.com/gui/file/15d4b8e6d3a0907a7593e34d5b7d0834)|Android||2018-12-01 19:31:51|15d4b8e6d3a0907a7593e34d5b7d0834.virus|
|[08311668de1cba7a09192f1d608b1678](https://www.virustotal.com/gui/file/08311668de1cba7a09192f1d608b1678)|Android||2018-11-28 01:09:51|tlrEIY7EmTn6nGvp5D4JGTd30PNpeclGrgaolep4wjxbPKrAcbwHe49MjM2SNzx7sS|
|[da4e06996a1f242539e74ca06263192c](https://www.virustotal.com/gui/file/da4e06996a1f242539e74ca06263192c)|Win32 EXE|dynamer|2018-11-18 04:59:15|myfile.exe|
|[dd5d0b4cc69af071ca598f581d34b81c](https://www.virustotal.com/gui/file/dd5d0b4cc69af071ca598f581d34b81c)|Android|androidos|2018-11-05 13:46:15|dd5d0b4cc69af071ca598f581d34b81c.virus|
|[56c3b41802e489c15ecb22f1a21be96d](https://www.virustotal.com/gui/file/56c3b41802e489c15ecb22f1a21be96d)|Android||2018-11-05 10:10:58|56c3b41802e489c15ecb22f1a21be96d.virus|
|[d33fb8defc8c7dc236ddfc4951b627f4](https://www.virustotal.com/gui/file/d33fb8defc8c7dc236ddfc4951b627f4)|Android||2018-11-05 10:10:41|d33fb8defc8c7dc236ddfc4951b627f4.virus|
|[9384ad32177c5cd6eb255ac90e9714dd](https://www.virustotal.com/gui/file/9384ad32177c5cd6eb255ac90e9714dd)|Android||2018-11-05 09:53:26|9384ad32177c5cd6eb255ac90e9714dd.virus|
|[7c4056e7951f79c4dde08df41b6f0b3e](https://www.virustotal.com/gui/file/7c4056e7951f79c4dde08df41b6f0b3e)|Android||2018-11-05 09:52:53|7c4056e7951f79c4dde08df41b6f0b3e.virus|
|[880e5be026d27cf4c09eea0a1fb03e52](https://www.virustotal.com/gui/file/880e5be026d27cf4c09eea0a1fb03e52)|Android||2018-11-05 09:51:05|880e5be026d27cf4c09eea0a1fb03e52.virus|
|[d0a59a7c4727f10f5ef144eb53871739](https://www.virustotal.com/gui/file/d0a59a7c4727f10f5ef144eb53871739)|Android||2018-11-02 02:51:30|d0a59a7c4727f10f5ef144eb53871739.virus|
|[f3953c12073ac80f6fa2e7481c7d2d9c](https://www.virustotal.com/gui/file/f3953c12073ac80f6fa2e7481c7d2d9c)|Android||2018-11-02 02:39:45|f3953c12073ac80f6fa2e7481c7d2d9c.virus|
|[b310c09849e9809f9c5a8764a05f3ce5](https://www.virustotal.com/gui/file/b310c09849e9809f9c5a8764a05f3ce5)|Android||2018-11-02 02:36:29|b310c09849e9809f9c5a8764a05f3ce5.virus|
|[dfc4748216f3fba79537cfa44f8a6ae9](https://www.virustotal.com/gui/file/dfc4748216f3fba79537cfa44f8a6ae9)|Android||2018-11-02 02:25:19|dfc4748216f3fba79537cfa44f8a6ae9.virus|
|[73a08d5cb918653117b45b33bdbd7833](https://www.virustotal.com/gui/file/73a08d5cb918653117b45b33bdbd7833)|Android||2018-11-02 02:19:57|73a08d5cb918653117b45b33bdbd7833.virus|
|[2a5462e0c8aaa110e7a071e2e2831494](https://www.virustotal.com/gui/file/2a5462e0c8aaa110e7a071e2e2831494)|Android||2018-10-20 22:47:42| |
|[959a963dda29293df2686d051b964d61](https://www.virustotal.com/gui/file/959a963dda29293df2686d051b964d61)|Android||2018-10-13 00:06:35| |
|[7ab668ed909afb8e65eae08550171878](https://www.virustotal.com/gui/file/7ab668ed909afb8e65eae08550171878)|Android||2018-10-03 18:40:44|7ab668ed909afb8e65eae08550171878.virus|
|[8f000204858e60bf61f7419377adf008](https://www.virustotal.com/gui/file/8f000204858e60bf61f7419377adf008)|Android||2018-09-24 18:47:27|8f000204858e60bf61f7419377adf008.virus|
|[0e6cb5f5c31c4789b368ab52743bb17b](https://www.virustotal.com/gui/file/0e6cb5f5c31c4789b368ab52743bb17b)|Android||2018-09-01 22:59:27|0e6cb5f5c31c4789b368ab52743bb17b.virus|
|[c3db6759192dcd1802738ff461710925](https://www.virustotal.com/gui/file/c3db6759192dcd1802738ff461710925)|Android||2018-08-24 19:11:39|c3db6759192dcd1802738ff461710925.virus|
|[5f72c69f3992bfb6258cc3d29e6b6cce](https://www.virustotal.com/gui/file/5f72c69f3992bfb6258cc3d29e6b6cce)|Android||2018-08-24 19:11:35|5f72c69f3992bfb6258cc3d29e6b6cce.virus|
|[47097d3a8978ab51b583e14955b8c540](https://www.virustotal.com/gui/file/47097d3a8978ab51b583e14955b8c540)|Android||2018-08-24 19:10:17|47097d3a8978ab51b583e14955b8c540.virus|
|[07ae5d41db6ffbda3ec5e7125ac54e31](https://www.virustotal.com/gui/file/07ae5d41db6ffbda3ec5e7125ac54e31)|Android||2018-08-24 19:09:31|07ae5d41db6ffbda3ec5e7125ac54e31.virus|
|[659f55e9e84bf7764e33d0bf5ae596ba](https://www.virustotal.com/gui/file/659f55e9e84bf7764e33d0bf5ae596ba)|Android||2018-08-24 19:09:17|659f55e9e84bf7764e33d0bf5ae596ba.virus|
|[a964579ac353bf560664688f637540bc](https://www.virustotal.com/gui/file/a964579ac353bf560664688f637540bc)|Android||2018-08-24 19:08:57|a964579ac353bf560664688f637540bc.virus|
|[17507bac16bb3eb20b282748af04d17f](https://www.virustotal.com/gui/file/17507bac16bb3eb20b282748af04d17f)|Android||2018-08-24 19:06:55|17507bac16bb3eb20b282748af04d17f.virus|
|[cbb8a21f3fe86f536a35c32229cf0349](https://www.virustotal.com/gui/file/cbb8a21f3fe86f536a35c32229cf0349)|Android||2018-08-24 19:05:30|cbb8a21f3fe86f536a35c32229cf0349.virus|
|[67c83598aec05e28822777d678d3ec8e](https://www.virustotal.com/gui/file/67c83598aec05e28822777d678d3ec8e)|Android||2018-08-24 19:04:58|67c83598aec05e28822777d678d3ec8e.virus|
|[5e45af41d3983b6437c3fb29d7d7b277](https://www.virustotal.com/gui/file/5e45af41d3983b6437c3fb29d7d7b277)|Android||2018-08-17 22:23:02|5e45af41d3983b6437c3fb29d7d7b277.virus|
|[511bbca1e3cec6bde6a2870a00c94739](https://www.virustotal.com/gui/file/511bbca1e3cec6bde6a2870a00c94739)|Android||2018-08-14 23:22:07|511bbca1e3cec6bde6a2870a00c94739.virus|
|[1562cec686fa65ca1aaff126c555cbd6](https://www.virustotal.com/gui/file/1562cec686fa65ca1aaff126c555cbd6)|Android||2018-08-14 23:21:58|1562cec686fa65ca1aaff126c555cbd6.virus|
|[0a6fea7dc6bca6a53c80f404ab04c99d](https://www.virustotal.com/gui/file/0a6fea7dc6bca6a53c80f404ab04c99d)|Android||2018-08-14 23:20:10|0a6fea7dc6bca6a53c80f404ab04c99d.virus|
|[90e0c226f43d39e0903700e2784b8437](https://www.virustotal.com/gui/file/90e0c226f43d39e0903700e2784b8437)|Android||2018-08-14 23:17:13|90e0c226f43d39e0903700e2784b8437.virus|
|[0f5f4c65c011df038ea50e6bedc8eb1e](https://www.virustotal.com/gui/file/0f5f4c65c011df038ea50e6bedc8eb1e)|Android||2018-08-14 23:15:49|0f5f4c65c011df038ea50e6bedc8eb1e.virus|
|[f6a35820a1a1f50d3eb5a3dd2f5a5c5d](https://www.virustotal.com/gui/file/f6a35820a1a1f50d3eb5a3dd2f5a5c5d)|Android||2018-08-14 23:14:58|f6a35820a1a1f50d3eb5a3dd2f5a5c5d.virus|
|[4430eba39904df5da9997fb7ce92b121](https://www.virustotal.com/gui/file/4430eba39904df5da9997fb7ce92b121)|Android||2018-08-14 23:14:37|4430eba39904df5da9997fb7ce92b121.virus|
|[1fdd56b2724c64a922f70b10eb6e4162](https://www.virustotal.com/gui/file/1fdd56b2724c64a922f70b10eb6e4162)|Android||2018-08-14 23:14:14|1fdd56b2724c64a922f70b10eb6e4162.virus|
|[3152d79ef01ad379c53c8fe2c9f6923e](https://www.virustotal.com/gui/file/3152d79ef01ad379c53c8fe2c9f6923e)|Android||2018-08-14 23:14:06|3152d79ef01ad379c53c8fe2c9f6923e.virus|
|[a5123fd61e7755b6ab534c2bde5002a4](https://www.virustotal.com/gui/file/a5123fd61e7755b6ab534c2bde5002a4)|Android||2018-08-14 23:11:27|a5123fd61e7755b6ab534c2bde5002a4.virus|
|[302b2d9c9078dd78908bc0a6de0e1ca2](https://www.virustotal.com/gui/file/302b2d9c9078dd78908bc0a6de0e1ca2)|Android|androidos|2018-08-09 03:28:40|302b2d9c9078dd78908bc0a6de0e1ca2.virus|
|[41a54d16492fc0060d2c55dea3099f3f](https://www.virustotal.com/gui/file/41a54d16492fc0060d2c55dea3099f3f)|Android||2018-08-09 03:28:34|41a54d16492fc0060d2c55dea3099f3f.virus|
|[7de5d43c1960c815809adca1d9f16cc5](https://www.virustotal.com/gui/file/7de5d43c1960c815809adca1d9f16cc5)|Android||2018-08-09 03:28:24|7de5d43c1960c815809adca1d9f16cc5.virus|
|[b0a0a6d2a991d75b88b8da2f545c067b](https://www.virustotal.com/gui/file/b0a0a6d2a991d75b88b8da2f545c067b)|Android||2018-08-09 03:27:12|b0a0a6d2a991d75b88b8da2f545c067b.virus|
|[595982cbf51427706bac027d564ca30b](https://www.virustotal.com/gui/file/595982cbf51427706bac027d564ca30b)|Android||2018-08-09 03:26:54|595982cbf51427706bac027d564ca30b.virus|
|[efca39450cf756269541a0e5f067d53f](https://www.virustotal.com/gui/file/efca39450cf756269541a0e5f067d53f)|Android|androidos|2018-08-09 03:26:34|efca39450cf756269541a0e5f067d53f.virus|
|[928859d33f2f4fee3a049be490181b95](https://www.virustotal.com/gui/file/928859d33f2f4fee3a049be490181b95)|Android||2018-08-09 03:26:16|928859d33f2f4fee3a049be490181b95.virus|
|[a3b85da230b59e890c8103e07ad81e01](https://www.virustotal.com/gui/file/a3b85da230b59e890c8103e07ad81e01)|Android|androidos|2018-08-09 03:25:46|a3b85da230b59e890c8103e07ad81e01.virus|
|[0790e3dfb665c72399c7ff9f077629b1](https://www.virustotal.com/gui/file/0790e3dfb665c72399c7ff9f077629b1)|Android||2018-08-09 03:22:12|0790e3dfb665c72399c7ff9f077629b1.virus|
|[a9983a4dbdde4a89c4814e488ab7a818](https://www.virustotal.com/gui/file/a9983a4dbdde4a89c4814e488ab7a818)|Android||2018-08-09 03:22:06|a9983a4dbdde4a89c4814e488ab7a818.virus|
|[ffd968941d843d9985d1bd9a2cead78f](https://www.virustotal.com/gui/file/ffd968941d843d9985d1bd9a2cead78f)|Android||2018-08-09 03:21:24|ffd968941d843d9985d1bd9a2cead78f.virus|
|[bde8efa1d31ee78604cc611ea7dada47](https://www.virustotal.com/gui/file/bde8efa1d31ee78604cc611ea7dada47)|Android|androidos|2018-08-09 03:20:14|bde8efa1d31ee78604cc611ea7dada47.virus|
|[0dc18260228c3b9d2d6dc39cf1f96023](https://www.virustotal.com/gui/file/0dc18260228c3b9d2d6dc39cf1f96023)|Android||2018-08-09 03:17:05|0dc18260228c3b9d2d6dc39cf1f96023.virus|
|[2546c42ad87c73e4d6240378611286ba](https://www.virustotal.com/gui/file/2546c42ad87c73e4d6240378611286ba)|Android||2018-08-09 03:15:26|2546c42ad87c73e4d6240378611286ba.virus|
|[dfe2ea00ef6e33d0e1ba1bd5181e623c](https://www.virustotal.com/gui/file/dfe2ea00ef6e33d0e1ba1bd5181e623c)|Android|androidos|2018-08-09 03:15:22|dfe2ea00ef6e33d0e1ba1bd5181e623c.virus|
|[9b4fcd06366065d73831c0178c5bf379](https://www.virustotal.com/gui/file/9b4fcd06366065d73831c0178c5bf379)|Android|androidos|2018-08-09 03:13:34|9b4fcd06366065d73831c0178c5bf379.virus|
|[4da23ed11de21360bd1a03ac5fa88df9](https://www.virustotal.com/gui/file/4da23ed11de21360bd1a03ac5fa88df9)|Android||2018-08-09 03:13:33|4da23ed11de21360bd1a03ac5fa88df9.virus|
|[c325c2e885380a06b4bb16554cb8128f](https://www.virustotal.com/gui/file/c325c2e885380a06b4bb16554cb8128f)|Android|androidos|2018-08-09 02:26:49|c325c2e885380a06b4bb16554cb8128f.virus|
|[a808ca35e951132625717456ea9fb11a](https://www.virustotal.com/gui/file/a808ca35e951132625717456ea9fb11a)|Android||2018-08-03 23:22:28|a808ca35e951132625717456ea9fb11a.virus|
|[aec575621c860f570fbdfa2a991cd48f](https://www.virustotal.com/gui/file/aec575621c860f570fbdfa2a991cd48f)|Android|androidos|2018-08-03 23:15:56|aec575621c860f570fbdfa2a991cd48f.virus|
|[cdb43d01c039b62694fe047b57e859cb](https://www.virustotal.com/gui/file/cdb43d01c039b62694fe047b57e859cb)|Android||2018-08-03 23:15:35|cdb43d01c039b62694fe047b57e859cb.virus|
|[1e950333748a73e70ecbf0591a1dc4c3](https://www.virustotal.com/gui/file/1e950333748a73e70ecbf0591a1dc4c3)|Android||2018-08-03 23:14:35|1e950333748a73e70ecbf0591a1dc4c3.virus|
|[4fecc453751aff74be1b2e3689a1bb5a](https://www.virustotal.com/gui/file/4fecc453751aff74be1b2e3689a1bb5a)|Android||2018-08-03 23:12:24|4fecc453751aff74be1b2e3689a1bb5a.virus|
|[9fe2f20de98ce9eb80007e7bb83ea3f7](https://www.virustotal.com/gui/file/9fe2f20de98ce9eb80007e7bb83ea3f7)|Android||2018-08-03 14:31:40|9fe2f20de98ce9eb80007e7bb83ea3f7.virus|
|[d90e93f3e0f224135b97bf942457f13a](https://www.virustotal.com/gui/file/d90e93f3e0f224135b97bf942457f13a)|Android||2018-07-27 21:06:26|d90e93f3e0f224135b97bf942457f13a.virus|
|[9c6168b7165f8439ddbe481e61f17d7c](https://www.virustotal.com/gui/file/9c6168b7165f8439ddbe481e61f17d7c)|Android||2018-07-27 20:58:46|9c6168b7165f8439ddbe481e61f17d7c.virus|
|[1680484220e32d8516814ba657c62efe](https://www.virustotal.com/gui/file/1680484220e32d8516814ba657c62efe)|Android||2018-07-27 20:58:33|1680484220e32d8516814ba657c62efe.virus|
|[f415228282f8ded5518d13451be84301](https://www.virustotal.com/gui/file/f415228282f8ded5518d13451be84301)|Android||2018-07-27 20:56:17|f415228282f8ded5518d13451be84301.virus|
|[68dfe238f7556c7f7419b0e625b8cfbc](https://www.virustotal.com/gui/file/68dfe238f7556c7f7419b0e625b8cfbc)|Android||2018-07-27 20:51:17|68dfe238f7556c7f7419b0e625b8cfbc.virus|
|[24771373aabe6e7ebe154bf42bcf75da](https://www.virustotal.com/gui/file/24771373aabe6e7ebe154bf42bcf75da)|Android||2018-07-24 03:22:52|24771373aabe6e7ebe154bf42bcf75da.virus|
|[9841fd0e83875d1e26ca1d28275d25fd](https://www.virustotal.com/gui/file/9841fd0e83875d1e26ca1d28275d25fd)|Android||2018-07-24 03:21:50|9841fd0e83875d1e26ca1d28275d25fd.virus|
|[4b064f476247e6b58c3084b7c67247eb](https://www.virustotal.com/gui/file/4b064f476247e6b58c3084b7c67247eb)|Android|androidos|2018-07-24 03:21:39|4b064f476247e6b58c3084b7c67247eb.virus|
|[c460c19c061dcb8c332455b51a0ca8c1](https://www.virustotal.com/gui/file/c460c19c061dcb8c332455b51a0ca8c1)|Android||2018-07-24 02:35:02|c460c19c061dcb8c332455b51a0ca8c1.virus|
|[83ca79883851d05c071e049e9841146c](https://www.virustotal.com/gui/file/83ca79883851d05c071e049e9841146c)|Android||2018-07-12 19:33:55|83ca79883851d05c071e049e9841146c.virus|
|[50105e670ae55dd22c2dfda00b03606e](https://www.virustotal.com/gui/file/50105e670ae55dd22c2dfda00b03606e)|Android||2018-07-12 19:33:22| |
|[5dc434492b7e6b3cd651e13d5f212283](https://www.virustotal.com/gui/file/5dc434492b7e6b3cd651e13d5f212283)|Android|androidos|2018-07-12 19:26:16|5dc434492b7e6b3cd651e13d5f212283.virus|
|[cedecd2b7bebded2453319e90d6756b1](https://www.virustotal.com/gui/file/cedecd2b7bebded2453319e90d6756b1)|Android||2018-07-12 18:27:16|cedecd2b7bebded2453319e90d6756b1.virus|
|[5dad63f5f5925c6ed3fd8523adeeb04e](https://www.virustotal.com/gui/file/5dad63f5f5925c6ed3fd8523adeeb04e)|Android||2018-07-07 18:25:15|5dad63f5f5925c6ed3fd8523adeeb04e.virus|
|[0e729bbd087b4125b1c5cfdd96ad03d1](https://www.virustotal.com/gui/file/0e729bbd087b4125b1c5cfdd96ad03d1)|Android||2018-07-07 18:13:27|0e729bbd087b4125b1c5cfdd96ad03d1.virus|
|[2ce404c565ffd46978dc6690f03b4e41](https://www.virustotal.com/gui/file/2ce404c565ffd46978dc6690f03b4e41)|Android||2018-07-07 18:13:21|2ce404c565ffd46978dc6690f03b4e41.virus|
|[7f5138e729ff64488e44562e635e173d](https://www.virustotal.com/gui/file/7f5138e729ff64488e44562e635e173d)|Android||2018-07-07 18:10:54|7f5138e729ff64488e44562e635e173d.virus|
|[a2d4daf2d280078e20c0e1d228af9ceb](https://www.virustotal.com/gui/file/a2d4daf2d280078e20c0e1d228af9ceb)|Android||2018-07-07 18:00:33|a2d4daf2d280078e20c0e1d228af9ceb.virus|
|[792dee45e6ba579b6b3e4b61bab4f3ac](https://www.virustotal.com/gui/file/792dee45e6ba579b6b3e4b61bab4f3ac)|Android||2018-07-07 15:57:31|792dee45e6ba579b6b3e4b61bab4f3ac.virus|
|[edec36e0aee818087270010c5843e043](https://www.virustotal.com/gui/file/edec36e0aee818087270010c5843e043)|Android||2018-07-07 15:50:16|edec36e0aee818087270010c5843e043.virus|
|[f1f6ad5cced4e3cd9aa95b74ac21234d](https://www.virustotal.com/gui/file/f1f6ad5cced4e3cd9aa95b74ac21234d)|Android||2018-07-07 15:47:20|f1f6ad5cced4e3cd9aa95b74ac21234d.virus|
|[6b9de5f4ee8a9423ef308496f3a100c0](https://www.virustotal.com/gui/file/6b9de5f4ee8a9423ef308496f3a100c0)|Android||2018-07-07 15:36:03|6b9de5f4ee8a9423ef308496f3a100c0.virus|
|[c9a914b6ee2f6237a908db3790a35fcf](https://www.virustotal.com/gui/file/c9a914b6ee2f6237a908db3790a35fcf)|Android||2018-07-07 15:30:00|c9a914b6ee2f6237a908db3790a35fcf.virus|
|[ef552bfd5767d436916688da2e07b072](https://www.virustotal.com/gui/file/ef552bfd5767d436916688da2e07b072)|Android||2018-07-07 15:21:06|ef552bfd5767d436916688da2e07b072.virus|
|[9c01f873af37746b5e4ea4e2bf9bda75](https://www.virustotal.com/gui/file/9c01f873af37746b5e4ea4e2bf9bda75)|Android||2018-06-29 11:41:27|9c01f873af37746b5e4ea4e2bf9bda75.virus|
|[40954fa5448fb3351c4fb2a4bb409b3b](https://www.virustotal.com/gui/file/40954fa5448fb3351c4fb2a4bb409b3b)|Android||2018-06-29 11:15:57|40954fa5448fb3351c4fb2a4bb409b3b.virus|
|[e334c726a8bee40303d2de5de292f73d](https://www.virustotal.com/gui/file/e334c726a8bee40303d2de5de292f73d)|Android||2018-06-29 11:15:51|e334c726a8bee40303d2de5de292f73d.virus|
|[51f9abc000089a85384a17f62989a272](https://www.virustotal.com/gui/file/51f9abc000089a85384a17f62989a272)|Android||2018-06-29 10:37:47|51f9abc000089a85384a17f62989a272.virus|
|[332480f111195b0065921f0af2416b09](https://www.virustotal.com/gui/file/332480f111195b0065921f0af2416b09)|Android||2018-06-23 15:37:33|332480f111195b0065921f0af2416b09.virus|
|[f8585941ec30713ad2b44200781f5de5](https://www.virustotal.com/gui/file/f8585941ec30713ad2b44200781f5de5)|Android||2018-06-23 15:36:39|f8585941ec30713ad2b44200781f5de5.virus|
|[0ca999164ce7034611b88add6bf5b611](https://www.virustotal.com/gui/file/0ca999164ce7034611b88add6bf5b611)|Android||2018-06-23 15:34:00|0ca999164ce7034611b88add6bf5b611.virus|
|[cd45992f4b9a60977b71038f126af178](https://www.virustotal.com/gui/file/cd45992f4b9a60977b71038f126af178)|Android||2018-06-22 22:24:48|cd45992f4b9a60977b71038f126af178.virus|
|[15f081d4694425df0fe7ba3c5d049c9d](https://www.virustotal.com/gui/file/15f081d4694425df0fe7ba3c5d049c9d)|Android||2018-06-09 13:52:22|15f081d4694425df0fe7ba3c5d049c9d.virus|
|[5f7f53f465d7900b6ced6322d08aa093](https://www.virustotal.com/gui/file/5f7f53f465d7900b6ced6322d08aa093)|Android||2018-06-09 13:48:48|5f7f53f465d7900b6ced6322d08aa093.virus|
|[1c03d4ba959901929d9b338d2c44d5f4](https://www.virustotal.com/gui/file/1c03d4ba959901929d9b338d2c44d5f4)|Android||2018-06-09 13:00:49|1c03d4ba959901929d9b338d2c44d5f4.virus|
|[6bb287a06812073331eba5f0d08abbdc](https://www.virustotal.com/gui/file/6bb287a06812073331eba5f0d08abbdc)|Android||2018-06-01 19:36:55| |
|[6e4aad0f90cad74e7c310b9122f7c0df](https://www.virustotal.com/gui/file/6e4aad0f90cad74e7c310b9122f7c0df)|Android||2018-06-01 18:35:31| |
|[b94dec2c14a14b856e4998aca4e17e35](https://www.virustotal.com/gui/file/b94dec2c14a14b856e4998aca4e17e35)|Android||2018-06-01 16:17:55| |
|[bb8fad2fce8996afc19917792dbc4531](https://www.virustotal.com/gui/file/bb8fad2fce8996afc19917792dbc4531)|Android||2018-05-27 08:31:28|bb8fad2fce8996afc19917792dbc4531.virus|
|[0abc3bff0555c65715ee7ca028d4f4fa](https://www.virustotal.com/gui/file/0abc3bff0555c65715ee7ca028d4f4fa)|Android||2018-05-27 04:24:01|0abc3bff0555c65715ee7ca028d4f4fa.virus|
|[ca03b685cf799ef2b5cd47f7895abe7c](https://www.virustotal.com/gui/file/ca03b685cf799ef2b5cd47f7895abe7c)|Android||2018-05-26 23:14:11|ca03b685cf799ef2b5cd47f7895abe7c.virus|
|[fe5a9c65475f931792f07c56b84af749](https://www.virustotal.com/gui/file/fe5a9c65475f931792f07c56b84af749)|Android||2018-05-26 12:47:03|fe5a9c65475f931792f07c56b84af749.virus|
|[f577a92d1696a7d39db86f8ea5f513e0](https://www.virustotal.com/gui/file/f577a92d1696a7d39db86f8ea5f513e0)|Android||2018-05-25 02:59:01|=?UTF-8?B?5aSH5Lu95pyN5YqhLmFwaw==?=|
|[645a9d41f1d6bcf1bab4cbce2c9c370f](https://www.virustotal.com/gui/file/645a9d41f1d6bcf1bab4cbce2c9c370f)|Android||2018-05-23 11:32:21|645a9d41f1d6bcf1bab4cbce2c9c370f.virus|
|[ce63e6d1c6b196c47fa4bc09dafbba69](https://www.virustotal.com/gui/file/ce63e6d1c6b196c47fa4bc09dafbba69)|Android||2018-05-23 06:25:15| |
|[8823f5ebc124888e708c4676b9697c3e](https://www.virustotal.com/gui/file/8823f5ebc124888e708c4676b9697c3e)|Android||2018-05-22 03:49:27|=?UTF-8?B?5aSH5Lu9LmFwaw==?=|
|[33ed44a7e45b809ff0df5aad337110ce](https://www.virustotal.com/gui/file/33ed44a7e45b809ff0df5aad337110ce)|Android||2018-05-21 12:41:19|33ed44a7e45b809ff0df5aad337110ce.virus|
|[86e5958bcd9a6022ff2a95498e49349d](https://www.virustotal.com/gui/file/86e5958bcd9a6022ff2a95498e49349d)|Android||2018-05-21 02:25:38|86e5958bcd9a6022ff2a95498e49349d.virus|
|[dce1f629458bb7a92c6344207ca837c2](https://www.virustotal.com/gui/file/dce1f629458bb7a92c6344207ca837c2)|Android||2018-05-19 06:52:08|dce1f629458bb7a92c6344207ca837c2.virus|
|[7e830046b6a83fa36585fc39ed484c86](https://www.virustotal.com/gui/file/7e830046b6a83fa36585fc39ed484c86)|Android||2018-05-15 11:01:21|7e830046b6a83fa36585fc39ed484c86.virus|
|[9267ba3973aa3ea54089960874033076](https://www.virustotal.com/gui/file/9267ba3973aa3ea54089960874033076)|Android||2018-05-15 10:55:14|9267ba3973aa3ea54089960874033076.virus|
|[f23e643122e114fe356a14091139db6e](https://www.virustotal.com/gui/file/f23e643122e114fe356a14091139db6e)|Android||2018-05-15 10:50:06|f23e643122e114fe356a14091139db6e.virus|
|[38fc25ceedc91ac2e5c249a2a81ae141](https://www.virustotal.com/gui/file/38fc25ceedc91ac2e5c249a2a81ae141)|Android||2018-05-15 10:42:43|38fc25ceedc91ac2e5c249a2a81ae141.virus|
|[359cd6ee60e4f507456416109cf17b87](https://www.virustotal.com/gui/file/359cd6ee60e4f507456416109cf17b87)|Android||2018-05-15 10:42:43|359cd6ee60e4f507456416109cf17b87.virus|
|[e02940b02581126075364fb05e5943d5](https://www.virustotal.com/gui/file/e02940b02581126075364fb05e5943d5)|Android||2018-05-15 10:41:02|e02940b02581126075364fb05e5943d5.virus|
|[39989c413bde690649b3bfb7f975e8b2](https://www.virustotal.com/gui/file/39989c413bde690649b3bfb7f975e8b2)|Android||2018-05-15 10:33:06|39989c413bde690649b3bfb7f975e8b2.virus|
|[395eb170c3d72861cbdc8ac775e95310](https://www.virustotal.com/gui/file/395eb170c3d72861cbdc8ac775e95310)|Android||2018-05-15 10:31:23|395eb170c3d72861cbdc8ac775e95310.virus|
|[811222cbf612dd5853e5dd94730a5b85](https://www.virustotal.com/gui/file/811222cbf612dd5853e5dd94730a5b85)|Android||2018-05-15 10:30:30|811222cbf612dd5853e5dd94730a5b85.virus|
|[4d113eb77b2ed956f88f6f0885a12601](https://www.virustotal.com/gui/file/4d113eb77b2ed956f88f6f0885a12601)|Android||2018-05-15 10:24:12|4d113eb77b2ed956f88f6f0885a12601.virus|
|[36ce0077e6fd168c1461b2f5c46fe693](https://www.virustotal.com/gui/file/36ce0077e6fd168c1461b2f5c46fe693)|Android||2018-05-15 10:20:41|36ce0077e6fd168c1461b2f5c46fe693.virus|
|[b578b3c68871795709fd5f3b6e76a876](https://www.virustotal.com/gui/file/b578b3c68871795709fd5f3b6e76a876)|Android||2018-05-11 23:16:21|b578b3c68871795709fd5f3b6e76a876.virus|
|[a7cdd62fbfaa06deb95c9f7e791bc747](https://www.virustotal.com/gui/file/a7cdd62fbfaa06deb95c9f7e791bc747)|Android||2018-05-11 23:14:14|a7cdd62fbfaa06deb95c9f7e791bc747.virus|
|[85f28009806ffb86ad99b0a1509d77d9](https://www.virustotal.com/gui/file/85f28009806ffb86ad99b0a1509d77d9)|Android||2018-05-11 22:50:57|85f28009806ffb86ad99b0a1509d77d9.virus|
|[109afe870fc2e8ef2cd324d4e4e283c3](https://www.virustotal.com/gui/file/109afe870fc2e8ef2cd324d4e4e283c3)|Android||2018-05-11 22:24:04|109afe870fc2e8ef2cd324d4e4e283c3.virus|
|[de071e8b33cbffdee49e98d83c7ddaf5](https://www.virustotal.com/gui/file/de071e8b33cbffdee49e98d83c7ddaf5)|Android||2018-05-11 03:42:16|de071e8b33cbffdee49e98d83c7ddaf5.virus|
|[65aea86370774a5f88d9b70c2cde89ad](https://www.virustotal.com/gui/file/65aea86370774a5f88d9b70c2cde89ad)|Android||2018-05-11 03:26:17|65aea86370774a5f88d9b70c2cde89ad.virus|
|[b605237d6ba02abef56d431309b03d2f](https://www.virustotal.com/gui/file/b605237d6ba02abef56d431309b03d2f)|Android||2018-05-11 03:25:24|b605237d6ba02abef56d431309b03d2f.virus|
|[bb2f42a0ba94fe25b41523c4f3f0633b](https://www.virustotal.com/gui/file/bb2f42a0ba94fe25b41523c4f3f0633b)|Android||2018-05-11 03:22:54|bb2f42a0ba94fe25b41523c4f3f0633b.virus|
|[c39e72b56e84eb14a50af72a878f205e](https://www.virustotal.com/gui/file/c39e72b56e84eb14a50af72a878f205e)|Android||2018-05-11 02:56:37|c39e72b56e84eb14a50af72a878f205e.virus|
|[250046c07475502853e13325eb462dda](https://www.virustotal.com/gui/file/250046c07475502853e13325eb462dda)|Android||2018-05-11 02:30:28|250046c07475502853e13325eb462dda.virus|
|[29306b9a10491aebfb6a7c91f846cca5](https://www.virustotal.com/gui/file/29306b9a10491aebfb6a7c91f846cca5)|Android||2018-05-10 00:05:24| |
|[b907e51d29457b6bc4b8c2a016641622](https://www.virustotal.com/gui/file/b907e51d29457b6bc4b8c2a016641622)|Android||2018-05-09 07:16:49|QQ.apk|
|[5ed7151b7a8be470390b4288e48c3cd9](https://www.virustotal.com/gui/file/5ed7151b7a8be470390b4288e48c3cd9)|Android||2018-05-09 07:09:56|=?UTF-8?B?5LqR5qih5Z2XLmFwaw==?=|
|[ee00dfe5b460a8b52f49c05fa57a6f0b](https://www.virustotal.com/gui/file/ee00dfe5b460a8b52f49c05fa57a6f0b)|Android||2018-05-09 03:24:07|ee00dfe5b460a8b52f49c05fa57a6f0b.virus|
|[ac365f1862a955fe5e47d30f71f3956d](https://www.virustotal.com/gui/file/ac365f1862a955fe5e47d30f71f3956d)|Android||2018-05-09 03:21:10|ac365f1862a955fe5e47d30f71f3956d.virus|
|[be894303fed258a413fa4fd072e1c815](https://www.virustotal.com/gui/file/be894303fed258a413fa4fd072e1c815)|Android||2018-05-09 02:32:12|be894303fed258a413fa4fd072e1c815.virus|
|[4b31ab15dcbd06fe46b5e0b2f97cec0f](https://www.virustotal.com/gui/file/4b31ab15dcbd06fe46b5e0b2f97cec0f)|Android||2018-05-08 14:46:44|4b31ab15dcbd06fe46b5e0b2f97cec0f.virus|
|[282c676645d859e5b5537907a040c3bd](https://www.virustotal.com/gui/file/282c676645d859e5b5537907a040c3bd)|Android||2018-05-08 14:41:09|282c676645d859e5b5537907a040c3bd.virus|
|[1cdd016f83e692434c41de6e92e7f9db](https://www.virustotal.com/gui/file/1cdd016f83e692434c41de6e92e7f9db)|Android||2018-05-08 14:23:37|1cdd016f83e692434c41de6e92e7f9db.virus|
|[1c7dde90025ada371375867ec5a78c1a](https://www.virustotal.com/gui/file/1c7dde90025ada371375867ec5a78c1a)|Android||2018-05-08 12:26:45|1c7dde90025ada371375867ec5a78c1a.virus|
|[7cb972dc7913592d314cb1dc4a176fe0](https://www.virustotal.com/gui/file/7cb972dc7913592d314cb1dc4a176fe0)|Android||2018-05-08 11:11:28| |
|[4453f419d06fc9bb307e75f96b95908e](https://www.virustotal.com/gui/file/4453f419d06fc9bb307e75f96b95908e)|Android||2018-05-02 10:42:31|4453f419d06fc9bb307e75f96b95908e.virus|
|[1fec740d2dad6c7eff93b2af48850e29](https://www.virustotal.com/gui/file/1fec740d2dad6c7eff93b2af48850e29)|Android||2018-05-02 10:32:12|1fec740d2dad6c7eff93b2af48850e29.virus|
|[c683afd7746659747a1b58d100ecaf01](https://www.virustotal.com/gui/file/c683afd7746659747a1b58d100ecaf01)|Android||2018-05-02 10:27:15|c683afd7746659747a1b58d100ecaf01.virus|
|[9bd888f3b47f905de144b291ad4a7a2d](https://www.virustotal.com/gui/file/9bd888f3b47f905de144b291ad4a7a2d)|Android||2018-04-29 01:45:56| |
|[ec77737f68a806ba6bc8abb095909b72](https://www.virustotal.com/gui/file/ec77737f68a806ba6bc8abb095909b72)|Android||2018-04-29 00:17:05| |
|[803bd1a617188af6f8f4cc56dbc57d3f](https://www.virustotal.com/gui/file/803bd1a617188af6f8f4cc56dbc57d3f)|Android||2018-04-28 00:19:27| |
|[77a5cab8d3ce3126b25252b0966e2bf6](https://www.virustotal.com/gui/file/77a5cab8d3ce3126b25252b0966e2bf6)|Android||2018-04-27 10:50:12|77a5cab8d3ce3126b25252b0966e2bf6.virus|
|[e79a6ad5f25b9c88117aaa5bdd672181](https://www.virustotal.com/gui/file/e79a6ad5f25b9c88117aaa5bdd672181)|Android||2018-04-24 19:44:28| |
|[cfd11b46c7dc553bbf3b9ab7efd32a94](https://www.virustotal.com/gui/file/cfd11b46c7dc553bbf3b9ab7efd32a94)|Android|androidos|2018-04-24 18:37:04| |
|[6e8afd7cb2dcb263918776ea679e485f](https://www.virustotal.com/gui/file/6e8afd7cb2dcb263918776ea679e485f)|Android||2018-04-24 03:16:27| |
|[b2da1fa4e9ba950a3dd8ff9e7a862a5d](https://www.virustotal.com/gui/file/b2da1fa4e9ba950a3dd8ff9e7a862a5d)|Android||2018-04-24 02:56:55| |
|[22485c08388db9a7605306b46ea6313d](https://www.virustotal.com/gui/file/22485c08388db9a7605306b46ea6313d)|Android||2018-04-24 02:32:09|22485c08388db9a7605306b46ea6313d.virus|
|[fefd3f8fb52a1cf4c2641cd543aac2da](https://www.virustotal.com/gui/file/fefd3f8fb52a1cf4c2641cd543aac2da)|Android||2018-04-18 07:07:50|fefd3f8fb52a1cf4c2641cd543aac2da.virus|
|[1bcb651b7a0d2e2625c1f2def9e99842](https://www.virustotal.com/gui/file/1bcb651b7a0d2e2625c1f2def9e99842)|Android||2018-04-18 07:05:40|1bcb651b7a0d2e2625c1f2def9e99842.virus|
|[3061b75427db23ae9e4d91d820551555](https://www.virustotal.com/gui/file/3061b75427db23ae9e4d91d820551555)|Android||2018-04-18 06:50:33|3061b75427db23ae9e4d91d820551555.virus|
|[32bc1208d51730d02b5f7e540028a5cc](https://www.virustotal.com/gui/file/32bc1208d51730d02b5f7e540028a5cc)|Android||2018-04-18 06:45:05|32bc1208d51730d02b5f7e540028a5cc.virus|
|[a0161cd1accd0ab9ac847fa825188bf9](https://www.virustotal.com/gui/file/a0161cd1accd0ab9ac847fa825188bf9)|Android||2018-04-18 06:40:32|a0161cd1accd0ab9ac847fa825188bf9.virus|
|[894eca4c1b8073fc8395d95ad05fd3a5](https://www.virustotal.com/gui/file/894eca4c1b8073fc8395d95ad05fd3a5)|Android||2018-04-05 11:33:38|894eca4c1b8073fc8395d95ad05fd3a5.virus|
|[47c96342515121091ac0e8146a5a02df](https://www.virustotal.com/gui/file/47c96342515121091ac0e8146a5a02df)|Android||2018-04-05 06:43:55|47c96342515121091ac0e8146a5a02df.virus|
|[daaea32a4f1a02b78119f68190006544](https://www.virustotal.com/gui/file/daaea32a4f1a02b78119f68190006544)|Android||2018-04-05 06:30:13|daaea32a4f1a02b78119f68190006544.virus|
|[dba4409901d23bdee5d3cb605049e218](https://www.virustotal.com/gui/file/dba4409901d23bdee5d3cb605049e218)|Android||2018-04-05 06:24:20|dba4409901d23bdee5d3cb605049e218.virus|
|[0c40e504329ab713137d149b1d8a61c1](https://www.virustotal.com/gui/file/0c40e504329ab713137d149b1d8a61c1)|Android||2018-04-05 06:20:55|0c40e504329ab713137d149b1d8a61c1.virus|
|[073156f1ad809c3b8632d8a33c10a25f](https://www.virustotal.com/gui/file/073156f1ad809c3b8632d8a33c10a25f)|Android||2018-04-03 23:15:32|073156f1ad809c3b8632d8a33c10a25f.virus|
|[d99187a35438e451914c79e2a2ba329e](https://www.virustotal.com/gui/file/d99187a35438e451914c79e2a2ba329e)|Android||2018-04-03 22:42:14|d99187a35438e451914c79e2a2ba329e.virus|
|[5c983c19c95d693cd9c0993a91c9104b](https://www.virustotal.com/gui/file/5c983c19c95d693cd9c0993a91c9104b)|Android||2018-04-03 22:33:25|5c983c19c95d693cd9c0993a91c9104b.virus|
|[b78563d16f35aea73a417185144ca09d](https://www.virustotal.com/gui/file/b78563d16f35aea73a417185144ca09d)|Win32 EXE||2018-04-03 02:17:46|myfile.exe|
|[c4534421f1020a56f52f24638eb2d54a](https://www.virustotal.com/gui/file/c4534421f1020a56f52f24638eb2d54a)|Android||2018-04-01 18:37:19|c4534421f1020a56f52f24638eb2d54a.virus|
|[295e9f73b0c890d12c64de1bb8888290](https://www.virustotal.com/gui/file/295e9f73b0c890d12c64de1bb8888290)|Android||2018-04-01 17:44:49|295e9f73b0c890d12c64de1bb8888290.virus|
|[b4a8990bb8bf74d83f4a117265dfa26a](https://www.virustotal.com/gui/file/b4a8990bb8bf74d83f4a117265dfa26a)|Android||2018-04-01 17:04:37|b4a8990bb8bf74d83f4a117265dfa26a.virus|
|[b78a9724c88c811d1002f958b7b437f9](https://www.virustotal.com/gui/file/b78a9724c88c811d1002f958b7b437f9)|Android||2018-03-27 23:02:57|b78a9724c88c811d1002f958b7b437f9.virus|
|[72b348b8e3efee00151cb0e5f957ef8f](https://www.virustotal.com/gui/file/72b348b8e3efee00151cb0e5f957ef8f)|Android||2018-03-27 23:01:58|72b348b8e3efee00151cb0e5f957ef8f.virus|
|[dccd4143bfc619ad6e76117254fd017c](https://www.virustotal.com/gui/file/dccd4143bfc619ad6e76117254fd017c)|Android||2018-03-27 16:59:28|dccd4143bfc619ad6e76117254fd017c.virus|
|[9eaa2df68827fa3f782120fbcacc48f8](https://www.virustotal.com/gui/file/9eaa2df68827fa3f782120fbcacc48f8)|Android||2018-03-26 23:17:19|9eaa2df68827fa3f782120fbcacc48f8.virus|
|[eb90a820159651af5aca6104fc0f3551](https://www.virustotal.com/gui/file/eb90a820159651af5aca6104fc0f3551)|Android||2018-03-26 23:16:25|eb90a820159651af5aca6104fc0f3551.virus|
|[ef170edc3889f30d3bd0edec1be3a50a](https://www.virustotal.com/gui/file/ef170edc3889f30d3bd0edec1be3a50a)|Android||2018-03-26 23:11:42|ef170edc3889f30d3bd0edec1be3a50a.virus|
|[a29014e84d7089d077ffa94a92843a2a](https://www.virustotal.com/gui/file/a29014e84d7089d077ffa94a92843a2a)|Android||2018-03-26 22:41:07|a29014e84d7089d077ffa94a92843a2a.virus|
|[84042d63668064ce55efcb48d452b9b6](https://www.virustotal.com/gui/file/84042d63668064ce55efcb48d452b9b6)|Android||2018-03-26 22:22:42|84042d63668064ce55efcb48d452b9b6.virus|
|[16b4842794253000f08821098db058db](https://www.virustotal.com/gui/file/16b4842794253000f08821098db058db)|Android||2018-03-10 02:23:53|16b4842794253000f08821098db058db.virus|
|[bffab5d0aca03a61c4b7774d4416e386](https://www.virustotal.com/gui/file/bffab5d0aca03a61c4b7774d4416e386)|Android||2018-03-08 15:20:30|bffab5d0aca03a61c4b7774d4416e386.virus|
|[22bc1885a41e01d0397f4127a79041ae](https://www.virustotal.com/gui/file/22bc1885a41e01d0397f4127a79041ae)|Android||2018-03-04 01:24:18|22bc1885a41e01d0397f4127a79041ae.virus|
|[821ebf1248fdec2c05a20862d07c41b0](https://www.virustotal.com/gui/file/821ebf1248fdec2c05a20862d07c41b0)|Android||2018-03-04 01:22:18|821ebf1248fdec2c05a20862d07c41b0.virus|
|[18d3ce6c475e1647fd8f37ce80fc10bd](https://www.virustotal.com/gui/file/18d3ce6c475e1647fd8f37ce80fc10bd)|Android||2018-03-04 01:10:24|18d3ce6c475e1647fd8f37ce80fc10bd.virus|
|[d55021086a00fada4cde270cadc427e8](https://www.virustotal.com/gui/file/d55021086a00fada4cde270cadc427e8)|Android||2018-03-04 00:45:23|d55021086a00fada4cde270cadc427e8.virus|
|[651cee346e48a2ca02a081f22242652a](https://www.virustotal.com/gui/file/651cee346e48a2ca02a081f22242652a)|Android||2018-02-22 07:25:43|651cee346e48a2ca02a081f22242652a.virus|
|[04e63a3197f7b9a1cb18451d4b9d68cb](https://www.virustotal.com/gui/file/04e63a3197f7b9a1cb18451d4b9d68cb)|Android||2018-02-22 07:20:47|181aa49f5dd6565f004043e83ff02a016fa9aebd0173889081b7aa0004227064|
|[101d6eb88aaaa9df566944561210e8e8](https://www.virustotal.com/gui/file/101d6eb88aaaa9df566944561210e8e8)|Android||2018-02-22 02:16:10|101d6eb88aaaa9df566944561210e8e8.virus|
|[d1530eeb231338f9fc02eac92a12fd44](https://www.virustotal.com/gui/file/d1530eeb231338f9fc02eac92a12fd44)|Android||2018-02-16 10:30:14|d1530eeb231338f9fc02eac92a12fd44.virus|
|[12e60c8ae85adb92aae7d64b5088b3f9](https://www.virustotal.com/gui/file/12e60c8ae85adb92aae7d64b5088b3f9)|Android||2018-02-12 04:12:08|12e60c8ae85adb92aae7d64b5088b3f9.virus|
|[a60cb1f1db48dcc6a6d271b4902fc884](https://www.virustotal.com/gui/file/a60cb1f1db48dcc6a6d271b4902fc884)|Android||2018-02-12 03:25:53|a60cb1f1db48dcc6a6d271b4902fc884.virus|
|[6d99beb475a723ff016635ff2ee0adce](https://www.virustotal.com/gui/file/6d99beb475a723ff016635ff2ee0adce)|Android||2018-02-09 08:02:13|6d99beb475a723ff016635ff2ee0adce.virus|
|[ca6127e923ad2cf5a9b1a18ac2edc615](https://www.virustotal.com/gui/file/ca6127e923ad2cf5a9b1a18ac2edc615)|Android||2018-01-17 08:43:33|ca6127e923ad2cf5a9b1a18ac2edc615.virus|
|[bfb44458d236dc79888ff50cc4a3801a](https://www.virustotal.com/gui/file/bfb44458d236dc79888ff50cc4a3801a)|Android||2018-01-10 16:10:58|bfb44458d236dc79888ff50cc4a3801a.virus|
|[c38f2862a43736dc244b01e486dcd0af](https://www.virustotal.com/gui/file/c38f2862a43736dc244b01e486dcd0af)|Android||2018-01-10 16:00:12|c38f2862a43736dc244b01e486dcd0af.virus|
|[4af0dbff99c6c4168d97ce7c3bb0d774](https://www.virustotal.com/gui/file/4af0dbff99c6c4168d97ce7c3bb0d774)|Android||2018-01-10 15:41:01|4af0dbff99c6c4168d97ce7c3bb0d774.virus|
|[b3920ac72f03ba925b90e31b93bba018](https://www.virustotal.com/gui/file/b3920ac72f03ba925b90e31b93bba018)|Android||2018-01-10 15:35:07|b3920ac72f03ba925b90e31b93bba018.virus|
|[213c1eacb63eefd411049a7e264d8dbd](https://www.virustotal.com/gui/file/213c1eacb63eefd411049a7e264d8dbd)|Android||2018-01-05 11:24:59|213c1eacb63eefd411049a7e264d8dbd.virus|
|[0d129e5e471a8d1163a57b06ff84735b](https://www.virustotal.com/gui/file/0d129e5e471a8d1163a57b06ff84735b)|Android||2018-01-03 16:01:16|0d129e5e471a8d1163a57b06ff84735b.virus|
|[63a56f3867ef4b4a3cf469e81496aee7](https://www.virustotal.com/gui/file/63a56f3867ef4b4a3cf469e81496aee7)|Android||2017-12-19 11:33:56|63a56f3867ef4b4a3cf469e81496aee7.virus|
|[10f8097ef0db6adbed3b314055491ca4](https://www.virustotal.com/gui/file/10f8097ef0db6adbed3b314055491ca4)|Android||2017-12-12 12:56:49|874d6b4bc17842f6b7c8991bafd6ee05ed064c12|
|[60bc3fdf15ab92fef44183740c69239c](https://www.virustotal.com/gui/file/60bc3fdf15ab92fef44183740c69239c)|Android||2017-12-06 17:18:26|60bc3fdf15ab92fef44183740c69239c|
|[647f6b2503205dd1f1da5ea490b6c71f](https://www.virustotal.com/gui/file/647f6b2503205dd1f1da5ea490b6c71f)|Android|androidos|2017-12-06 17:17:07|647f6b2503205dd1f1da5ea490b6c71f.virus|
|[d6a202baeef9a30f49b4624f93edcf5e](https://www.virustotal.com/gui/file/d6a202baeef9a30f49b4624f93edcf5e)|Android||2017-12-06 17:12:51|d6a202baeef9a30f49b4624f93edcf5e.virus|
|[03a3a4fec4af8cebf2eb7f39ec5e1b9d](https://www.virustotal.com/gui/file/03a3a4fec4af8cebf2eb7f39ec5e1b9d)|Android||2017-12-06 17:12:16|03a3a4fec4af8cebf2eb7f39ec5e1b9d.virus|
|[41090e46a80de84a5589c16a298b021b](https://www.virustotal.com/gui/file/41090e46a80de84a5589c16a298b021b)|Android||2017-12-01 00:19:32|41090e46a80de84a5589c16a298b021b.virus|
|[e6649bfaa9faaabda39b712585dc8b28](https://www.virustotal.com/gui/file/e6649bfaa9faaabda39b712585dc8b28)|Android||2017-12-01 00:09:21|e6649bfaa9faaabda39b712585dc8b28.virus|
|[4d489996114b287c01601421e8e355dd](https://www.virustotal.com/gui/file/4d489996114b287c01601421e8e355dd)|Android||2017-11-30 11:22:59|4d489996114b287c01601421e8e355dd.virus|
|[4379460e416f7edf669d47def1479341](https://www.virustotal.com/gui/file/4379460e416f7edf669d47def1479341)|Android||2017-11-30 11:22:22|4379460e416f7edf669d47def1479341.virus|
|[a53b8812b7f6e8ab2cc0df604bb5b738](https://www.virustotal.com/gui/file/a53b8812b7f6e8ab2cc0df604bb5b738)|Android||2017-11-30 11:21:43|a53b8812b7f6e8ab2cc0df604bb5b738.virus|
|[d6882dc3544556911fd02d0933ab4d06](https://www.virustotal.com/gui/file/d6882dc3544556911fd02d0933ab4d06)|Android||2017-11-26 06:15:51|d6882dc3544556911fd02d0933ab4d06.virus|
|[efa81231937b5203ed8c1132f65eef57](https://www.virustotal.com/gui/file/efa81231937b5203ed8c1132f65eef57)|Android||2017-11-24 05:47:51|efa81231937b5203ed8c1132f65eef57.virus|
|[38163232a3542c4006370bb81aaac9eb](https://www.virustotal.com/gui/file/38163232a3542c4006370bb81aaac9eb)|Android||2017-11-23 19:54:16|38163232a3542c4006370bb81aaac9eb.virus|
|[b66db14ec83ec3a5f757eeed99119684](https://www.virustotal.com/gui/file/b66db14ec83ec3a5f757eeed99119684)|Android||2017-11-21 16:10:54|b66db14ec83ec3a5f757eeed99119684.virus|
|[b79df812b43fe7ebcb276fc5e9bf55d4](https://www.virustotal.com/gui/file/b79df812b43fe7ebcb276fc5e9bf55d4)|Android||2017-11-13 10:04:07|b79df812b43fe7ebcb276fc5e9bf55d4.virus|
|[dd8ec719bab2917157411c5ff8b0e33e](https://www.virustotal.com/gui/file/dd8ec719bab2917157411c5ff8b0e33e)|Win32 EXE|PlugX|2017-11-05 11:36:55|a999489d95e5a94f75de4695c9579ffc88bae02048838e3523f089d970a35abb.bin|
|[4c3536ee91c1b8357285eb042403555b](https://www.virustotal.com/gui/file/4c3536ee91c1b8357285eb042403555b)|Android||2017-11-04 11:30:09|4c3536ee91c1b8357285eb042403555b.virus|
|[b4c37ee6c57415ccd4811a6550ba1760](https://www.virustotal.com/gui/file/b4c37ee6c57415ccd4811a6550ba1760)|Win32 EXE|johnnie|2017-11-04 03:29:45|b4c37ee6c57415ccd4811a6550ba1760.virobj|
|[8d32c691a136f81a9b9cf50db56f47fb](https://www.virustotal.com/gui/file/8d32c691a136f81a9b9cf50db56f47fb)|Android||2017-11-02 03:04:32|8d32c691a136f81a9b9cf50db56f47fb.virus|
|[ce6a8dd4c38d076fae35d4bc4a0cbd46](https://www.virustotal.com/gui/file/ce6a8dd4c38d076fae35d4bc4a0cbd46)|Android||2017-10-27 17:40:52|ce6a8dd4c38d076fae35d4bc4a0cbd46.virus|
|[2484d8512e4d62965051a70e79f13576](https://www.virustotal.com/gui/file/2484d8512e4d62965051a70e79f13576)|Android||2017-10-14 02:21:11|2484d8512e4d62965051a70e79f13576.virus|
|[c26bf0c4564c1bd6ad54a809a848430d](https://www.virustotal.com/gui/file/c26bf0c4564c1bd6ad54a809a848430d)|Android||2017-10-09 16:25:33|c26bf0c4564c1bd6ad54a809a848430d.virus|
|[727bec9f566c971fbc6f1270f3d815ab](https://www.virustotal.com/gui/file/727bec9f566c971fbc6f1270f3d815ab)|Android||2017-10-09 16:21:38|727bec9f566c971fbc6f1270f3d815ab.virus|
|[98563107955be3f4ee6e4a546665c4cc](https://www.virustotal.com/gui/file/98563107955be3f4ee6e4a546665c4cc)|Android||2017-10-09 16:08:14|98563107955be3f4ee6e4a546665c4cc.virus|
|[6c23c3e2cd092b024a2f20988dbc20e7](https://www.virustotal.com/gui/file/6c23c3e2cd092b024a2f20988dbc20e7)|Android||2017-10-08 02:20:26|6c23c3e2cd092b024a2f20988dbc20e7.virus|
|[25dd9b2341f156306e876f08016b0d7a](https://www.virustotal.com/gui/file/25dd9b2341f156306e876f08016b0d7a)|Android||2017-09-23 11:10:07|25dd9b2341f156306e876f08016b0d7a.virus|
|[e6148289675bbb6225ac8334a8b286a9](https://www.virustotal.com/gui/file/e6148289675bbb6225ac8334a8b286a9)|Android||2017-09-19 15:22:49|e6148289675bbb6225ac8334a8b286a9.virus|
|[768822c37d1f4f8b4aa33944766d4d06](https://www.virustotal.com/gui/file/768822c37d1f4f8b4aa33944766d4d06)|Android||2017-09-19 14:54:52|768822c37d1f4f8b4aa33944766d4d06.virus|
|[555a040239a3602abd605778fdaa2212](https://www.virustotal.com/gui/file/555a040239a3602abd605778fdaa2212)|Android||2017-09-15 16:37:12|555a040239a3602abd605778fdaa2212.virus|
|[4248e15314d62cb2de951d8d4b5910da](https://www.virustotal.com/gui/file/4248e15314d62cb2de951d8d4b5910da)|Android||2017-09-15 16:35:10|4248e15314d62cb2de951d8d4b5910da.virus|
|[c13ce8e52b2256b844a9d2516fd4e7d6](https://www.virustotal.com/gui/file/c13ce8e52b2256b844a9d2516fd4e7d6)|Android||2017-09-15 16:00:12|c13ce8e52b2256b844a9d2516fd4e7d6.virus|
|[f7f82b7fd7d2000e608a2595dbec68c3](https://www.virustotal.com/gui/file/f7f82b7fd7d2000e608a2595dbec68c3)|Android||2017-09-14 15:39:33|f7f82b7fd7d2000e608a2595dbec68c3|
|[24a34c65efef441b62f915274ff86a58](https://www.virustotal.com/gui/file/24a34c65efef441b62f915274ff86a58)|Android||2017-09-14 07:53:04|24a34c65efef441b62f915274ff86a58.virus|
|[d6838de8794e312946b5b1433f463a28](https://www.virustotal.com/gui/file/d6838de8794e312946b5b1433f463a28)|Android||2017-09-14 07:37:16|d6838de8794e312946b5b1433f463a28.virus|
|[89b39fcd1085ecf06da8bd3d5e3e8b3d](https://www.virustotal.com/gui/file/89b39fcd1085ecf06da8bd3d5e3e8b3d)|Android||2017-09-14 07:32:36|89b39fcd1085ecf06da8bd3d5e3e8b3d.virus|
|[ba535d1b32334690594bbdbc45f281d2](https://www.virustotal.com/gui/file/ba535d1b32334690594bbdbc45f281d2)|Android||2017-09-11 03:46:30|ba535d1b32334690594bbdbc45f281d2.virus|
|[1a78a2f495e2f2006e8795d9500660e7](https://www.virustotal.com/gui/file/1a78a2f495e2f2006e8795d9500660e7)|Android||2017-09-11 03:41:54|1a78a2f495e2f2006e8795d9500660e7.virus|
|[eb9ad7240d15ab6eaf9c05ec2fc86312](https://www.virustotal.com/gui/file/eb9ad7240d15ab6eaf9c05ec2fc86312)|Android||2017-09-11 03:35:07|eb9ad7240d15ab6eaf9c05ec2fc86312.virus|
|[8cea52cd8d27138398cbd4ace0aa6191](https://www.virustotal.com/gui/file/8cea52cd8d27138398cbd4ace0aa6191)|Android||2017-09-11 03:30:29|_HxTdRzJYcUEnzoyHbTw20180429-5130-1f19xx7|
|[f37e8d7ad9196547695683bc896c2e77](https://www.virustotal.com/gui/file/f37e8d7ad9196547695683bc896c2e77)|Android||2017-09-11 03:19:47|f37e8d7ad9196547695683bc896c2e77.virus|
|[6d13a60c6b79793ee7f7f8b6eabb6fb0](https://www.virustotal.com/gui/file/6d13a60c6b79793ee7f7f8b6eabb6fb0)|Android||2017-09-11 03:09:22|6d13a60c6b79793ee7f7f8b6eabb6fb0.virus|
|[b3d7091b903b0fcc2ac72671af74c7ae](https://www.virustotal.com/gui/file/b3d7091b903b0fcc2ac72671af74c7ae)|Android||2017-09-11 03:06:20|b3d7091b903b0fcc2ac72671af74c7ae.virus|
|[a175ff5d88d83b57cb855b80bb2d74bd](https://www.virustotal.com/gui/file/a175ff5d88d83b57cb855b80bb2d74bd)|Android||2017-09-11 03:05:31|a175ff5d88d83b57cb855b80bb2d74bd.virus|
|[fecb8307a1675afeb14a4a5093d9d306](https://www.virustotal.com/gui/file/fecb8307a1675afeb14a4a5093d9d306)|Android||2017-09-11 03:00:33|fecb8307a1675afeb14a4a5093d9d306.virus|
|[5776d0a49dfe3b5c7784fe866a501ab9](https://www.virustotal.com/gui/file/5776d0a49dfe3b5c7784fe866a501ab9)|Android||2017-09-11 02:40:24|5776d0a49dfe3b5c7784fe866a501ab9.virus|
|[a7ce1f4218189cc488402fdb3f3501c4](https://www.virustotal.com/gui/file/a7ce1f4218189cc488402fdb3f3501c4)|Android||2017-09-11 02:31:23|a7ce1f4218189cc488402fdb3f3501c4.virus|
|[dc3ad69a163c503d78a20f45dcaf5c12](https://www.virustotal.com/gui/file/dc3ad69a163c503d78a20f45dcaf5c12)|Android||2017-08-29 13:35:32|a6c7351b09a733a1b3ff8a0901c5bdefdc3b566bfcedcdf5a338c3a97c9f249b|
|[c15f82afbb1466884fec136c1f58a77f](https://www.virustotal.com/gui/file/c15f82afbb1466884fec136c1f58a77f)|Win32 EXE||2017-08-20 10:56:54|10bd4507eb12bebc17e216e16950bf77e56c2aad01be7033bf0d5c235f2ad6e5.bin|
|[d3590942b8626127225fc56ce4e3ce03](https://www.virustotal.com/gui/file/d3590942b8626127225fc56ce4e3ce03)|Android||2017-08-18 17:19:50|d3590942b8626127225fc56ce4e3ce03.virus|
|[1fef765067c61478fee9dd8a5338d6fb](https://www.virustotal.com/gui/file/1fef765067c61478fee9dd8a5338d6fb)|Android||2017-08-18 17:07:07|1fef765067c61478fee9dd8a5338d6fb.virus|
|[76343095d8b36059788fc51a43ea9955](https://www.virustotal.com/gui/file/76343095d8b36059788fc51a43ea9955)|Android||2017-08-18 17:04:12|76343095d8b36059788fc51a43ea9955.virus|
|[9bbcbcb62d917dcdf9b91bca71b685e0](https://www.virustotal.com/gui/file/9bbcbcb62d917dcdf9b91bca71b685e0)|Android||2017-08-18 17:03:09|9bbcbcb62d917dcdf9b91bca71b685e0.virus|
|[fb12cbaeb32de0cbda609c3e0aa4df27](https://www.virustotal.com/gui/file/fb12cbaeb32de0cbda609c3e0aa4df27)|Android||2017-08-18 17:01:35|fb12cbaeb32de0cbda609c3e0aa4df27.virus|
|[0db49dfb0ff336720346a463ca4be8c0](https://www.virustotal.com/gui/file/0db49dfb0ff336720346a463ca4be8c0)|Win32 EXE|Redsip|2017-08-16 05:15:28|shell.exe|
|[291908b10816513525347af6145aadb1](https://www.virustotal.com/gui/file/291908b10816513525347af6145aadb1)|ZIP||2017-08-10 16:42:21|291908b10816513525347af6145aadb1|
|[f085c5629548e522f31c198d9a217346](https://www.virustotal.com/gui/file/f085c5629548e522f31c198d9a217346)|Android||2017-08-09 16:55:16|f085c5629548e522f31c198d9a217346.virus|
|[f0962c521ecb91cd3bb5c95b122a5af2](https://www.virustotal.com/gui/file/f0962c521ecb91cd3bb5c95b122a5af2)|Win32 EXE||2017-08-09 16:45:51|D:/vt/malware/20170813/f0962c521ecb91cd3bb5c95b122a5af2.vir|
|[f08bd6bc3e21a2f6fd2beff42b81c495](https://www.virustotal.com/gui/file/f08bd6bc3e21a2f6fd2beff42b81c495)|Win32 EXE|graftor|2017-08-08 00:40:08|D:/vt/malware/20170811/f08bd6bc3e21a2f6fd2beff42b81c495.vir|
|[72c634ebba4035758b398b6129a34a53](https://www.virustotal.com/gui/file/72c634ebba4035758b398b6129a34a53)|Android||2017-07-28 01:21:04|72c634ebba4035758b398b6129a34a53.virus|
|[85fbfb99ff2b7a8e848e137ac94810c0](https://www.virustotal.com/gui/file/85fbfb99ff2b7a8e848e137ac94810c0)|Android||2017-07-28 01:14:19|85fbfb99ff2b7a8e848e137ac94810c0.virus|
|[7b78b35af8716307e81f2b32c54d6ddd](https://www.virustotal.com/gui/file/7b78b35af8716307e81f2b32c54d6ddd)|Android||2017-07-27 01:38:52|7b78b35af8716307e81f2b32c54d6ddd.virus|
|[ba611062fc9b26d53fdec5895b57268d](https://www.virustotal.com/gui/file/ba611062fc9b26d53fdec5895b57268d)|Android||2017-07-27 00:35:14|ba611062fc9b26d53fdec5895b57268d.virus|
|[eec41c2327c24870c956188e7b6d995a](https://www.virustotal.com/gui/file/eec41c2327c24870c956188e7b6d995a)|Win32 EXE||2017-07-26 04:39:10|8890a06d3233ecf661c040ca5c03393c3afd620ccce49fbe08477bbf6b7d9b04.bin|
|[bb9614bcdf3f42ab13ac720c5390a3ff](https://www.virustotal.com/gui/file/bb9614bcdf3f42ab13ac720c5390a3ff)|Android||2017-07-21 19:57:20|bb9614bcdf3f42ab13ac720c5390a3ff.virus|
|[707e50537ca550fa741d146d106511b4](https://www.virustotal.com/gui/file/707e50537ca550fa741d146d106511b4)|Android||2017-07-19 15:00:08|707e50537ca550fa741d146d106511b4.virus|
|[7c09332893eb33f983010afb05ba0cf3](https://www.virustotal.com/gui/file/7c09332893eb33f983010afb05ba0cf3)|Android||2017-07-19 15:00:03|7c09332893eb33f983010afb05ba0cf3.virus|
|[02fcd5014abff1d073226d3fee064648](https://www.virustotal.com/gui/file/02fcd5014abff1d073226d3fee064648)|Android||2017-07-16 02:21:44|02fcd5014abff1d073226d3fee064648.virus|
|[8e739699b2ed514d456b95d9f425eb34](https://www.virustotal.com/gui/file/8e739699b2ed514d456b95d9f425eb34)|Android||2017-07-16 02:20:43|8e739699b2ed514d456b95d9f425eb34.virus|
|[5b52105824906be9334e7debcf51911c](https://www.virustotal.com/gui/file/5b52105824906be9334e7debcf51911c)|Android||2017-07-15 11:15:50|5b52105824906be9334e7debcf51911c.virus|
|[4d9d135be3a7bbf22780b7786f7bab9c](https://www.virustotal.com/gui/file/4d9d135be3a7bbf22780b7786f7bab9c)|Android||2017-07-15 10:42:59|4d9d135be3a7bbf22780b7786f7bab9c.virus|
|[f93901bca3dfb9f040bfd1677d70e70f](https://www.virustotal.com/gui/file/f93901bca3dfb9f040bfd1677d70e70f)|Android||2017-07-12 21:02:02|6a518d29232d3f68aa5c78df4a8d212f924e03379dc2be0a388b3118779fe583|
|[d65f7dd8af2bdfaa0efd01830579797a](https://www.virustotal.com/gui/file/d65f7dd8af2bdfaa0efd01830579797a)|Android||2017-07-11 06:26:31|d65f7dd8af2bdfaa0efd01830579797a.virus|
|[1ea7e1c198e98eafdbaac8096c2ad2cf](https://www.virustotal.com/gui/file/1ea7e1c198e98eafdbaac8096c2ad2cf)|Android||2017-07-11 06:25:12|1ea7e1c198e98eafdbaac8096c2ad2cf.virus|
|[97ab409471d655a5d78d14b3ac40f523](https://www.virustotal.com/gui/file/97ab409471d655a5d78d14b3ac40f523)|Android||2017-07-10 10:32:32|97ab409471d655a5d78d14b3ac40f523.virus|
|[1101e784bb9e3a081c93ab3efe6e7fa3](https://www.virustotal.com/gui/file/1101e784bb9e3a081c93ab3efe6e7fa3)|Android||2017-07-02 06:27:24|/home/develop/almacen/B4/b48edd2270b1aeb014291eb3ac2aaa1d4b7ee4694965d0de2c0978b2feae946d|
|[69c24a4f58bb9151595e936cb0780848](https://www.virustotal.com/gui/file/69c24a4f58bb9151595e936cb0780848)|Android||2017-07-01 03:23:33|/home/develop/almacen/45/45e7dc9c0e33d4754384365a60604c66d72356a994cbed8e8eab8796cf1579e2|
|[76b22a5a1b62b3f5362bf808a5a67025](https://www.virustotal.com/gui/file/76b22a5a1b62b3f5362bf808a5a67025)|Android||2017-06-27 22:22:00|76b22a5a1b62b3f5362bf808a5a67025.virus|
|[b35452472382ba15508d8279de9bcbd9](https://www.virustotal.com/gui/file/b35452472382ba15508d8279de9bcbd9)|Android||2017-05-29 23:18:06| |
|[e6eaa75ab77ee28814a7efd4ed3b17af](https://www.virustotal.com/gui/file/e6eaa75ab77ee28814a7efd4ed3b17af)|Win32 EXE|johnnie|2017-05-28 21:02:19|e6eaa75ab77ee28814a7efd4ed3b17af.virus|
|[4c38c6b52b485f5561e8f551df889439](https://www.virustotal.com/gui/file/4c38c6b52b485f5561e8f551df889439)|Android||2017-05-20 02:26:13|4c38c6b52b485f5561e8f551df889439.virus|
|[42c4c7331913185fd425af0a239782e4](https://www.virustotal.com/gui/file/42c4c7331913185fd425af0a239782e4)|Android||2017-05-15 06:55:09|42c4c7331913185fd425af0a239782e4.virus|
|[8c61ddc6422e630550fb63cfa769c6b4](https://www.virustotal.com/gui/file/8c61ddc6422e630550fb63cfa769c6b4)|Android||2017-05-15 02:21:12|8c61ddc6422e630550fb63cfa769c6b4.virus|
|[ae9aab4f50a24a3be3833427e99b0859](https://www.virustotal.com/gui/file/ae9aab4f50a24a3be3833427e99b0859)|Android||2017-05-12 23:26:28| |
|[9b8c852dc1d01825b81da3a9b2335a6c](https://www.virustotal.com/gui/file/9b8c852dc1d01825b81da3a9b2335a6c)|Android||2017-05-11 00:58:10|9b8c852dc1d01825b81da3a9b2335a6c.virus|
|[3cee8bc7cb146be9941664592bb2dccb](https://www.virustotal.com/gui/file/3cee8bc7cb146be9941664592bb2dccb)|Android||2017-05-06 09:35:52|3cee8bc7cb146be9941664592bb2dccb.virus|
|[87bccdfe1d9d3a0a5bedd1be055c948b](https://www.virustotal.com/gui/file/87bccdfe1d9d3a0a5bedd1be055c948b)|Android||2017-05-06 09:32:27|87bccdfe1d9d3a0a5bedd1be055c948b.virus|
|[2472efb451985abb6bd8fe54152f6a94](https://www.virustotal.com/gui/file/2472efb451985abb6bd8fe54152f6a94)|Android||2017-05-02 16:41:06|2472efb451985abb6bd8fe54152f6a94.virus|
|[cddab63e25332629ed0eaec6272b7640](https://www.virustotal.com/gui/file/cddab63e25332629ed0eaec6272b7640)|Android||2017-05-02 16:07:00|BindedClient.apk|
|[0f694304e0ef795ac1b715629e1f4a54](https://www.virustotal.com/gui/file/0f694304e0ef795ac1b715629e1f4a54)|Android||2017-05-01 03:10:47|0f694304e0ef795ac1b715629e1f4a54.virus|
|[b9ebd2c7db0d1ab25e9f6ddffbb77ebf](https://www.virustotal.com/gui/file/b9ebd2c7db0d1ab25e9f6ddffbb77ebf)|Android||2017-05-01 03:03:10|b9ebd2c7db0d1ab25e9f6ddffbb77ebf.virus|
|[2b979df2d0336629f30af055a1feda4c](https://www.virustotal.com/gui/file/2b979df2d0336629f30af055a1feda4c)|Android||2017-05-01 02:40:04|2b979df2d0336629f30af055a1feda4c.virus|
|[14c33f0762700e10d5d1305af45bbe36](https://www.virustotal.com/gui/file/14c33f0762700e10d5d1305af45bbe36)|Win32 EXE|dynamer|2017-04-21 05:01:13|form-g28.pdp.             .                     .      .   .   .   .    .  .  .  .   .  .    .  .    .    .    .                                        ..exe|
|[537e4eba4968a0b100008180f32ca68c](https://www.virustotal.com/gui/file/537e4eba4968a0b100008180f32ca68c)|Win32 EXE||2017-04-10 04:43:05|c8b2232360d5d6f56cd6b1076e5e21f0d501f5cb725e0a9b32a0ab661b4c38dd.bin|
|[d4eed55896993d928cb647d8d41a6079](https://www.virustotal.com/gui/file/d4eed55896993d928cb647d8d41a6079)|Win32 EXE||2017-04-06 21:22:03|d4eed55896993d928cb647d8d41a6079.virus|
|[4ff7b43853ae6099f1999d8a8cddd17b](https://www.virustotal.com/gui/file/4ff7b43853ae6099f1999d8a8cddd17b)|Android||2017-04-05 21:29:10|4ff7b43853ae6099f1999d8a8cddd17b.virus|
|[33ef31f73d726b118a234571bbb48ce9](https://www.virustotal.com/gui/file/33ef31f73d726b118a234571bbb48ce9)|Android||2017-04-02 11:04:59|33ef31f73d726b118a234571bbb48ce9.virus|
|[05805e224cac2657dfcc69b9adb4539f](https://www.virustotal.com/gui/file/05805e224cac2657dfcc69b9adb4539f)|Android||2017-04-02 10:23:17|05805e224cac2657dfcc69b9adb4539f.virus|
|[b250f138eb6dc7104b9e9898da25ab3d](https://www.virustotal.com/gui/file/b250f138eb6dc7104b9e9898da25ab3d)|Android||2017-03-30 06:41:09|b250f138eb6dc7104b9e9898da25ab3d.virus|
|[ecdb310840a73072e8cd732c7dc75698](https://www.virustotal.com/gui/file/ecdb310840a73072e8cd732c7dc75698)|Win32 EXE|Kryptik|2017-03-23 00:28:16|ecdb310840a73072e8cd732c7dc75698.virus|
|[2b9edb83c3e0215c6a77dc789898b36e](https://www.virustotal.com/gui/file/2b9edb83c3e0215c6a77dc789898b36e)|Android||2017-03-20 06:52:43|2b9edb83c3e0215c6a77dc789898b36e.virus|
|[494397a92a828c13f347447d9a1f7ad4](https://www.virustotal.com/gui/file/494397a92a828c13f347447d9a1f7ad4)|Android||2017-03-19 15:50:29|494397a92a828c13f347447d9a1f7ad4.virus|
|[2349f113cf7013a97aa086d428c622b7](https://www.virustotal.com/gui/file/2349f113cf7013a97aa086d428c622b7)|Android||2017-03-19 15:25:04|2349f113cf7013a97aa086d428c622b7.virus|
|[45b169532b04f3d4f3cd05aafd5591c5](https://www.virustotal.com/gui/file/45b169532b04f3d4f3cd05aafd5591c5)|Android||2017-03-19 15:20:24|45b169532b04f3d4f3cd05aafd5591c5.virus|
|[4a5af9f32696300f109117532ef57ff8](https://www.virustotal.com/gui/file/4a5af9f32696300f109117532ef57ff8)|Android||2017-03-19 05:45:18|4a5af9f32696300f109117532ef57ff8.virus|
|[15c395355f7fc09f489e40ae4992be8b](https://www.virustotal.com/gui/file/15c395355f7fc09f489e40ae4992be8b)|Android||2017-03-16 19:50:31|15c395355f7fc09f489e40ae4992be8b.virus|
|[42f0f65a2d2cb7c49b2dc4aeacd5c028](https://www.virustotal.com/gui/file/42f0f65a2d2cb7c49b2dc4aeacd5c028)|Android||2017-03-16 02:06:25|42f0f65a2d2cb7c49b2dc4aeacd5c028.virus|
|[724d3d74eeb8d702a65643252e84bbf7](https://www.virustotal.com/gui/file/724d3d74eeb8d702a65643252e84bbf7)|Android||2017-03-15 09:13:03|724d3d74eeb8d702a65643252e84bbf7.virus|
|[6f54fdb492dcbd59a7fdc6b748c8d322](https://www.virustotal.com/gui/file/6f54fdb492dcbd59a7fdc6b748c8d322)|Android||2017-03-14 20:55:04|6f54fdb492dcbd59a7fdc6b748c8d322.virus|
|[8644b3392aca2c802bd7f39b230ab68f](https://www.virustotal.com/gui/file/8644b3392aca2c802bd7f39b230ab68f)|Android||2017-03-14 20:17:49|8644b3392aca2c802bd7f39b230ab68f.virus|
|[661d4e056c8c0f6804cac7e6b24a79ec](https://www.virustotal.com/gui/file/661d4e056c8c0f6804cac7e6b24a79ec)|DOS EXE|PoisonIvy|2017-03-14 10:57:27|stupid-shellcode.exe|
|[a3881bce21d894b2ee2f3d06207968c1](https://www.virustotal.com/gui/file/a3881bce21d894b2ee2f3d06207968c1)|Android||2017-03-13 07:20:18|a3881bce21d894b2ee2f3d06207968c1.virus|
|[e0616474c0191ec299ab4d3a2ab6c9bc](https://www.virustotal.com/gui/file/e0616474c0191ec299ab4d3a2ab6c9bc)|Android||2017-03-13 06:30:11|e0616474c0191ec299ab4d3a2ab6c9bc.virus|
|[971aa865a9d88c0c145c7792329ec784](https://www.virustotal.com/gui/file/971aa865a9d88c0c145c7792329ec784)|Android||2017-03-10 16:04:09|971aa865a9d88c0c145c7792329ec784.virus|
|[3c2c5910fa613640a2c12ca5a984a345](https://www.virustotal.com/gui/file/3c2c5910fa613640a2c12ca5a984a345)|Android||2017-03-10 15:51:42|3c2c5910fa613640a2c12ca5a984a345.virus|
|[904430fc6b4ce06126ce6142580828af](https://www.virustotal.com/gui/file/904430fc6b4ce06126ce6142580828af)|Android||2017-03-07 03:53:10|904430fc6b4ce06126ce6142580828af.virus|
|[9392578507e9cf3cea116c54ac777983](https://www.virustotal.com/gui/file/9392578507e9cf3cea116c54ac777983)|Android||2017-03-07 03:35:37|9392578507e9cf3cea116c54ac777983.virus|
|[c20ecab3b3d0658f9f71003afa376900](https://www.virustotal.com/gui/file/c20ecab3b3d0658f9f71003afa376900)|Android||2017-03-04 12:44:39|c20ecab3b3d0658f9f71003afa376900.virus|
|[7cf505d36aa224725c251abe05050471](https://www.virustotal.com/gui/file/7cf505d36aa224725c251abe05050471)|Android||2017-03-03 12:45:11|7cf505d36aa224725c251abe05050471.virus|
|[45f58ff79e37daf1025ead0904f209c5](https://www.virustotal.com/gui/file/45f58ff79e37daf1025ead0904f209c5)|Android||2017-03-03 11:35:34|45f58ff79e37daf1025ead0904f209c5.virus|
|[a211d0d8f77b2592955400b9f996b911](https://www.virustotal.com/gui/file/a211d0d8f77b2592955400b9f996b911)|Android||2017-03-03 11:34:27|a211d0d8f77b2592955400b9f996b911.virus|
|[629c53b39638a4b9c2c36ac373155649](https://www.virustotal.com/gui/file/629c53b39638a4b9c2c36ac373155649)|Android||2017-03-01 15:17:04|629c53b39638a4b9c2c36ac373155649.virus|
|[cdd6ceb54bd613c159166842c2877b2f](https://www.virustotal.com/gui/file/cdd6ceb54bd613c159166842c2877b2f)|Android|androidos|2017-02-28 03:00:35|cdd6ceb54bd613c159166842c2877b2f.virus|
|[9c4bbd598bcad2f5d48b68c54e64cf05](https://www.virustotal.com/gui/file/9c4bbd598bcad2f5d48b68c54e64cf05)|Android||2017-02-28 01:10:46|9c4bbd598bcad2f5d48b68c54e64cf05.virus|
|[6eff031fd4c0c15adb85447a6f74804b](https://www.virustotal.com/gui/file/6eff031fd4c0c15adb85447a6f74804b)|Android||2017-02-28 01:03:50|6eff031fd4c0c15adb85447a6f74804b.virus|
|[5cfae0d09f9743f369606db18f832b2c](https://www.virustotal.com/gui/file/5cfae0d09f9743f369606db18f832b2c)|Android|androidos|2017-02-28 00:24:24|5cfae0d09f9743f369606db18f832b2c.virus|
|[858403cbc95381fb78d898515bc87691](https://www.virustotal.com/gui/file/858403cbc95381fb78d898515bc87691)|Android||2017-02-24 00:30:27|858403cbc95381fb78d898515bc87691.virus|
|[ca1bd893c1aa78bf8b46468a52abb2be](https://www.virustotal.com/gui/file/ca1bd893c1aa78bf8b46468a52abb2be)|Android||2017-02-24 00:12:38|ca1bd893c1aa78bf8b46468a52abb2be.virus|
|[bc259f5239fe4e056fad759984d0b92b](https://www.virustotal.com/gui/file/bc259f5239fe4e056fad759984d0b92b)|Android||2017-02-23 23:55:29|bc259f5239fe4e056fad759984d0b92b.virus|
|[c5d5204daf667c0f6ba3d1878bb13c1f](https://www.virustotal.com/gui/file/c5d5204daf667c0f6ba3d1878bb13c1f)|Android||2017-02-23 23:31:05|c5d5204daf667c0f6ba3d1878bb13c1f.virus|
|[34710847ac23a9b9d2e0b04f7c5317e1](https://www.virustotal.com/gui/file/34710847ac23a9b9d2e0b04f7c5317e1)|Android||2017-02-23 00:10:52|34710847ac23a9b9d2e0b04f7c5317e1.virus|
|[807cdccab1c11ed015835de1e3b3abb8](https://www.virustotal.com/gui/file/807cdccab1c11ed015835de1e3b3abb8)|Android||2017-02-20 20:08:44|807cdccab1c11ed015835de1e3b3abb8.virus|
|[47372b385f2bbabafe8fd6ca7f23a70a](https://www.virustotal.com/gui/file/47372b385f2bbabafe8fd6ca7f23a70a)|Android||2017-02-18 00:32:12|47372b385f2bbabafe8fd6ca7f23a70a.virus|
|[fd382af6dba2d211e22b1df090ddf5a5](https://www.virustotal.com/gui/file/fd382af6dba2d211e22b1df090ddf5a5)|Android||2017-02-18 00:25:13|fd382af6dba2d211e22b1df090ddf5a5.virus|
|[62b74d33f71ff7802b6fc2b766ff2ffc](https://www.virustotal.com/gui/file/62b74d33f71ff7802b6fc2b766ff2ffc)|Android||2017-02-18 00:21:00|62b74d33f71ff7802b6fc2b766ff2ffc.virus|
|[60eeafe1638fe28b75aeecc238703d7d](https://www.virustotal.com/gui/file/60eeafe1638fe28b75aeecc238703d7d)|Android||2017-02-18 00:13:49|60eeafe1638fe28b75aeecc238703d7d.virus|
|[5bbbaeba1c61d7367af5771db35ec326](https://www.virustotal.com/gui/file/5bbbaeba1c61d7367af5771db35ec326)|Android||2017-02-17 23:54:12|5bbbaeba1c61d7367af5771db35ec326.virus|
|[ca92f6c38f3c077035184dbb315724e0](https://www.virustotal.com/gui/file/ca92f6c38f3c077035184dbb315724e0)|Android||2017-02-17 23:46:17|ca92f6c38f3c077035184dbb315724e0.virus|
|[ddaaf15dee5d5139a3be949c8a8f3868](https://www.virustotal.com/gui/file/ddaaf15dee5d5139a3be949c8a8f3868)|Android||2017-02-17 23:22:41|ddaaf15dee5d5139a3be949c8a8f3868.virus|
|[9ea4c142b5f5b5c1de9f9f2ec2311bc8](https://www.virustotal.com/gui/file/9ea4c142b5f5b5c1de9f9f2ec2311bc8)|Android||2017-02-16 00:40:45|9ea4c142b5f5b5c1de9f9f2ec2311bc8.virus|
|[2e510879c21a2b790480a2abc966d3b5](https://www.virustotal.com/gui/file/2e510879c21a2b790480a2abc966d3b5)|Android||2017-02-16 00:12:35|2e510879c21a2b790480a2abc966d3b5.virus|
|[0e20805429535d5b8e85cf14ee8e5604](https://www.virustotal.com/gui/file/0e20805429535d5b8e85cf14ee8e5604)|Android||2017-02-15 23:33:58|0e20805429535d5b8e85cf14ee8e5604.virus|
|[3ce8ed94c7a38900b48b379831806168](https://www.virustotal.com/gui/file/3ce8ed94c7a38900b48b379831806168)|Android||2017-02-14 23:30:23|3ce8ed94c7a38900b48b379831806168.virus|
|[f9168ca271d6e40e7e9014941e891bee](https://www.virustotal.com/gui/file/f9168ca271d6e40e7e9014941e891bee)|Android||2017-02-10 07:50:53|f9168ca271d6e40e7e9014941e891bee.virus|
|[81b372d2f21eedf530a46bb0bb4fcb9f](https://www.virustotal.com/gui/file/81b372d2f21eedf530a46bb0bb4fcb9f)|Android||2017-02-08 16:40:15|81b372d2f21eedf530a46bb0bb4fcb9f.virus|
|[dc745aa4ab1e3c3dd5254c99dac2bfe9](https://www.virustotal.com/gui/file/dc745aa4ab1e3c3dd5254c99dac2bfe9)|Android||2017-02-08 15:23:14|dc745aa4ab1e3c3dd5254c99dac2bfe9.virus|
|[a372f685e37e03750daf3c82d66e82e8](https://www.virustotal.com/gui/file/a372f685e37e03750daf3c82d66e82e8)|Android||2017-02-03 13:15:50|a372f685e37e03750daf3c82d66e82e8.virus|
|[fb8a10a86ac447b7f46b3768d4c96f3d](https://www.virustotal.com/gui/file/fb8a10a86ac447b7f46b3768d4c96f3d)|Android||2017-01-04 09:27:17|fb8a10a86ac447b7f46b3768d4c96f3d.virus|
|[f0e0ccd9b66978566a5fb605ebfe319a](https://www.virustotal.com/gui/file/f0e0ccd9b66978566a5fb605ebfe319a)|Android||2016-12-23 13:53:39|f0e0ccd9b66978566a5fb605ebfe319a.virus|
|[5a2928817acf9bbf2d71f979202dc0ac](https://www.virustotal.com/gui/file/5a2928817acf9bbf2d71f979202dc0ac)|Android||2016-12-02 16:23:18|5a2928817acf9bbf2d71f979202dc0ac.virus|
|[af4fb232a67b03cdb6161ff7658076f2](https://www.virustotal.com/gui/file/af4fb232a67b03cdb6161ff7658076f2)|Android||2016-11-22 16:44:18| |
|[217a99a86a0afc0c0e8a0b46e3b01cc4](https://www.virustotal.com/gui/file/217a99a86a0afc0c0e8a0b46e3b01cc4)|Win32 EXE||2016-11-10 13:23:20|1e62b7dcb503f47a6330c4dcfc49ea9d921b7d2f8c508769d27df04e61b9471d.bin|
|[e48b4468af0b1c54a257cd29aefb925b](https://www.virustotal.com/gui/file/e48b4468af0b1c54a257cd29aefb925b)|Win32 EXE|stration|2016-10-27 18:21:40|e48b4468af0b1c54a257cd29aefb925b.virus|
|[ee592ff259297a1c5e6840f430822c37](https://www.virustotal.com/gui/file/ee592ff259297a1c5e6840f430822c37)|Win32 EXE||2016-10-17 00:56:23|ee592ff259297a1c5e6840f430822c37.virus|
|[fc2df15893239399d7dd854f0de83cbe](https://www.virustotal.com/gui/file/fc2df15893239399d7dd854f0de83cbe)|Win32 EXE|graftor|2016-10-16 18:39:13|fc2df15893239399d7dd854f0de83cbe.virus|
|[2204add24c8581acf6f2b4fd6bb7284e](https://www.virustotal.com/gui/file/2204add24c8581acf6f2b4fd6bb7284e)|Android||2016-10-13 00:01:54|2204add24c8581acf6f2b4fd6bb7284e.virus|
|[e1a29ae1b0036497d9ac83dfe2f877cb](https://www.virustotal.com/gui/file/e1a29ae1b0036497d9ac83dfe2f877cb)|Win32 EXE||2016-09-17 16:47:07|e1a29ae1b0036497d9ac83dfe2f877cb.virus|
|[770e55b711389c6100afa302bb959ea9](https://www.virustotal.com/gui/file/770e55b711389c6100afa302bb959ea9)|Win32 EXE|strictor|2016-09-13 10:10:43|d11d871b07520f43437183fa44bd118c01a3c4c86cffe0cc7343ae9038565cf1.bin|
|[ae3f414fd53f5f10b591f68d821c30a1](https://www.virustotal.com/gui/file/ae3f414fd53f5f10b591f68d821c30a1)|Win32 DLL||2016-09-02 16:36:45|sys.dll|
|[ee708e6cd0371cd15fe7dd7aeb4bd953](https://www.virustotal.com/gui/file/ee708e6cd0371cd15fe7dd7aeb4bd953)|Win32 EXE|Zbot|2016-09-02 16:30:12|ee708e6cd0371cd15fe7dd7aeb4bd953.virus|
|[b22e90cb4f60c16958bea7bff69bf4a4](https://www.virustotal.com/gui/file/b22e90cb4f60c16958bea7bff69bf4a4)|Win32 EXE||2016-08-30 20:30:55|257VMaUrIq|
|[fcd4048d1714a6849f12963d7b440e92](https://www.virustotal.com/gui/file/fcd4048d1714a6849f12963d7b440e92)|Win32 EXE|Zbot|2016-08-29 20:37:28|2085fca368af15a1bd54f7809dfee7cdd4d73df7af88fa53fe5341f0523ca7ea.bin|
|[bca52689065a5469d381368ec4db6bd4](https://www.virustotal.com/gui/file/bca52689065a5469d381368ec4db6bd4)|Win32 EXE||2016-08-15 17:30:30|bca52689065a5469d381368ec4db6bd4.virus|
|[a9ed66c55cbddd4199eb785716d17c0b](https://www.virustotal.com/gui/file/a9ed66c55cbddd4199eb785716d17c0b)|Win32 EXE|Zbot|2016-08-14 17:53:07|a9ed66c55cbddd4199eb785716d17c0b.virus|
|[a0156e8c0505ad01cd599b9c09a9c649](https://www.virustotal.com/gui/file/a0156e8c0505ad01cd599b9c09a9c649)|Win32 EXE|dynamer|2016-08-14 08:32:21|a0156e8c0505ad01cd599b9c09a9c649.virus|
|[1b30ad71e2b3811b22c2d08f991423e1](https://www.virustotal.com/gui/file/1b30ad71e2b3811b22c2d08f991423e1)|Android||2016-08-07 22:52:04|1b30ad71e2b3811b22c2d08f991423e1.virus|
|[22672eeb15ab0d07a3dfe4d03c5f0990](https://www.virustotal.com/gui/file/22672eeb15ab0d07a3dfe4d03c5f0990)|Win32 EXE|dynamer|2016-07-18 11:50:16|22672eeb15ab0d07a3dfe4d03c5f0990.virobj|
|[e29f8b035288e659168cdb986858b9fa](https://www.virustotal.com/gui/file/e29f8b035288e659168cdb986858b9fa)|ZIP|dynamer|2016-07-18 08:09:59|e29f8b035288e659168cdb986858b9fa.virus|
|[7dc8ceb66a2e28f27dd7c71a51c8429f](https://www.virustotal.com/gui/file/7dc8ceb66a2e28f27dd7c71a51c8429f)|Android||2016-07-13 00:07:52|7dc8ceb66a2e28f27dd7c71a51c8429f.virus|
|[e6460319419e2d949e5550fdf6122bfa](https://www.virustotal.com/gui/file/e6460319419e2d949e5550fdf6122bfa)|Android||2016-07-13 00:01:12|e6460319419e2d949e5550fdf6122bfa.virus|
|[88824c5030e8481fc52b492965a4b9ba](https://www.virustotal.com/gui/file/88824c5030e8481fc52b492965a4b9ba)|Android||2016-07-12 23:51:20|88824c5030e8481fc52b492965a4b9ba.virus|
|[3773327e0960bf1203a7afbec59d0dcb](https://www.virustotal.com/gui/file/3773327e0960bf1203a7afbec59d0dcb)|Android||2016-07-12 23:15:06|3773327e0960bf1203a7afbec59d0dcb.virus|
|[67fe1449acb9ee824d346eb36c1d55f1](https://www.virustotal.com/gui/file/67fe1449acb9ee824d346eb36c1d55f1)|Android||2016-07-11 23:06:14|67fe1449acb9ee824d346eb36c1d55f1.virus|
|[a23351c469fb453532a483b9e5272d92](https://www.virustotal.com/gui/file/a23351c469fb453532a483b9e5272d92)|Android||2016-07-07 13:33:19|a23351c469fb453532a483b9e5272d92.virus|
|[48a78449a5d0e2629c693968bfbdad09](https://www.virustotal.com/gui/file/48a78449a5d0e2629c693968bfbdad09)|Android||2016-07-07 11:25:01|48a78449a5d0e2629c693968bfbdad09.virus|
|[7372a680f0a1ddf0b0da059592b12df6](https://www.virustotal.com/gui/file/7372a680f0a1ddf0b0da059592b12df6)|Android||2016-06-28 00:25:07|7372a680f0a1ddf0b0da059592b12df6.virus|
|[50b67999b5e7719155036a17a0030d5e](https://www.virustotal.com/gui/file/50b67999b5e7719155036a17a0030d5e)|Android||2016-06-27 23:27:42|50b67999b5e7719155036a17a0030d5e.virus|
|[6fbce8802d11dc8b9f056cddc89ee3a9](https://www.virustotal.com/gui/file/6fbce8802d11dc8b9f056cddc89ee3a9)|Android||2016-05-23 06:52:54|6fbce8802d11dc8b9f056cddc89ee3a9.virus|
|[59fe6d0922b82f540844d61df783027f](https://www.virustotal.com/gui/file/59fe6d0922b82f540844d61df783027f)|Win32 EXE|Zegost|2016-05-17 04:38:01|還我公營街市大遊行签到表.exe|
|[239302a4d4e4e35a2b610ef61ab3ca68](https://www.virustotal.com/gui/file/239302a4d4e4e35a2b610ef61ab3ca68)|Win32 EXE|Zegost|2016-04-28 09:23:22|「近期亞太情勢評估及中共對臺政策走向」座談會邀請函 %E2%80%AEcod.scr|
|[4a3358f092f47ce5bc8e33184e82dd06](https://www.virustotal.com/gui/file/4a3358f092f47ce5bc8e33184e82dd06)|Win32 EXE|PlugX|2016-04-19 05:53:57|院總第1379號(行政院大陸委員會第239次諮詢委員會議重點及重大決策) _cod.scr|
|[5e85307ce65d8cb2577d6ba498137b1d](https://www.virustotal.com/gui/file/5e85307ce65d8cb2577d6ba498137b1d)|Win32 EXE|dynamer|2016-04-12 04:16:03|9e08efc73dc9145358898d2735c5f31d45a2571663c7f4963abd217ae979c7ca.apk|
|[9dd6fb40a7ace992bedc283dee79f50b](https://www.virustotal.com/gui/file/9dd6fb40a7ace992bedc283dee79f50b)|Win32 EXE|graftor|2016-04-11 21:36:39|9dd6fb40a7ace992bedc283dee79f50b.virus|
|[ff2d8383925721d32b6ea167ff6c8971](https://www.virustotal.com/gui/file/ff2d8383925721d32b6ea167ff6c8971)|Android||2016-04-09 16:30:04|ff2d8383925721d32b6ea167ff6c8971.virus|
|[dac3c712616d0033d94c205e784253a7](https://www.virustotal.com/gui/file/dac3c712616d0033d94c205e784253a7)|Win32 EXE|Zbot|2016-04-06 07:38:53|中華民國行政院(Executive Yuan)-臺灣生物經濟產業發展方案(2).doc.exe|
|[49ec001ca50199a29f46ed3e477968a4](https://www.virustotal.com/gui/file/49ec001ca50199a29f46ed3e477968a4)|Android||2016-04-01 07:55:25|49ec001ca50199a29f46ed3e477968a4.virus|
|[68ba87beeed5591f020fe6f406c7a45b](https://www.virustotal.com/gui/file/68ba87beeed5591f020fe6f406c7a45b)|Android||2016-03-31 07:03:00|68ba87beeed5591f020fe6f406c7a45b.virus|
|[045fb652f4a5f2c1bee8b55c7bfc55fc](https://www.virustotal.com/gui/file/045fb652f4a5f2c1bee8b55c7bfc55fc)|Android||2016-03-30 07:44:35|045fb652f4a5f2c1bee8b55c7bfc55fc.virus|
|[0cb6fd43d5d29ce891454a510ff38bd5](https://www.virustotal.com/gui/file/0cb6fd43d5d29ce891454a510ff38bd5)|Win32 EXE|PlugX|2016-03-29 09:14:24|孩子在大陸走丢，报警无助，望帮忙(孩子及個人資料).doc.exe|
|[b54f014cf491589998787e6b96a67e06](https://www.virustotal.com/gui/file/b54f014cf491589998787e6b96a67e06)|Win32 EXE|Zbot|2016-03-25 07:40:13|行政院大陸委員會(Mainland Affairs Council)2016.03.24.doc.exe|
|[eb0fc1be33fe9dfce42544e0a07ef04e](https://www.virustotal.com/gui/file/eb0fc1be33fe9dfce42544e0a07ef04e)|Win32 EXE|graftor|2016-03-20 21:59:17|eb0fc1be33fe9dfce42544e0a07ef04e.virus|
|[f576916cde47cff28be6e4a7e21e5a74](https://www.virustotal.com/gui/file/f576916cde47cff28be6e4a7e21e5a74)|Android||2016-03-18 08:05:31|f576916cde47cff28be6e4a7e21e5a74.virus|
|[1aacd7b6b0ffd6a25aeebe88c3162115](https://www.virustotal.com/gui/file/1aacd7b6b0ffd6a25aeebe88c3162115)|Win32 DLL|PlugX|2016-03-12 18:02:35|MsUpdate.dll|
|[0cf6e7f978cde1385fa70e0e0411a867](https://www.virustotal.com/gui/file/0cf6e7f978cde1385fa70e0e0411a867)|Android||2016-03-11 21:35:25|0cf6e7f978cde1385fa70e0e0411a867.virus|
|[11eccf2c247dd4f9df730354b3e0947d](https://www.virustotal.com/gui/file/11eccf2c247dd4f9df730354b3e0947d)|Win32 EXE|graftor|2016-03-11 05:25:02|2016.02.29-03.04 -ASEM Weekly.docx.rar^2016.02.29-03.04 -ASEM Weekly.docx.exe|
|[272901f9a01a79f2dec27b73936ceee0](https://www.virustotal.com/gui/file/272901f9a01a79f2dec27b73936ceee0)|Win32 EXE|PlugX|2016-03-04 14:18:54|sk.exe|
|[d302b9ef61c9f2baabcb8894e4292d42](https://www.virustotal.com/gui/file/d302b9ef61c9f2baabcb8894e4292d42)|Android||2015-12-14 15:27:14|d302b9ef61c9f2baabcb8894e4292d42.virus|
|[9399b8474ff3c606e26e161652a90494](https://www.virustotal.com/gui/file/9399b8474ff3c606e26e161652a90494)|Android||2015-11-26 13:28:16|9399b8474ff3c606e26e161652a90494.virus|
|[d2a4c1f91b2535cfe20c486fcdad907b](https://www.virustotal.com/gui/file/d2a4c1f91b2535cfe20c486fcdad907b)|Win32 EXE|graftor|2015-11-25 02:10:38|STEP Democracy Year 1 Acheivements_25112015.exe|
|[15a4fc049fdfdaeb1ea5b9da3cb458af](https://www.virustotal.com/gui/file/15a4fc049fdfdaeb1ea5b9da3cb458af)|Win32 EXE|PlugX|2015-11-19 02:05:02|Election result-16-11-2015 Correction included.exe|
|[69d018908450f43c68c65092ca4504e0](https://www.virustotal.com/gui/file/69d018908450f43c68c65092ca4504e0)|Android||2015-11-05 02:40:18|180174E86B2173FA743175ECA8D075A0|
|[3743e218206cdd048971c374fea56211](https://www.virustotal.com/gui/file/3743e218206cdd048971c374fea56211)|Android||2015-08-06 10:43:50|690165034127B868925C659A676EF253|
|[07c2da7a28cda7bd3ceda2503cd4ec93](https://www.virustotal.com/gui/file/07c2da7a28cda7bd3ceda2503cd4ec93)|Android||2015-07-29 06:11:41|07c2da7a28cda7bd3ceda2503cd4ec93.virus|
|[d1760a9db6d3cd342640788f063e5577](https://www.virustotal.com/gui/file/d1760a9db6d3cd342640788f063e5577)|Android||2015-07-10 02:32:17|d1760a9db6d3cd342640788f063e5577.virus|
|[cc1a806d25982acdb35dd196ab8171bc](https://www.virustotal.com/gui/file/cc1a806d25982acdb35dd196ab8171bc)|Win32 EXE||2013-09-01 03:30:12|/home/vega/CONTAGIO/malware/8-30 Plugx_the translation_D0D2079E1AB0E93C68DA9C293918A376/created files/DW20.exe|
|[d0d2079e1ab0e93c68da9c293918a376](https://www.virustotal.com/gui/file/d0d2079e1ab0e93c68da9c293918a376)|unknown|CVE-2012-0158|2013-08-30 12:01:03|_the translation.doc|
