|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[dbc26d553af41e2ec076b4bc29bc531e](https://www.virustotal.com/gui/file/dbc26d553af41e2ec076b4bc29bc531e)|HTML||2019-03-12 19:23:41| |
|[ac4859ab0e5c18c94749b1913cb2fd5e](https://www.virustotal.com/gui/file/ac4859ab0e5c18c94749b1913cb2fd5e)|HTML||2018-10-30 23:22:20|VirusShare_ac4859ab0e5c18c94749b1913cb2fd5e|
|[f59f4375b19b67945e11e156ef266fe9](https://www.virustotal.com/gui/file/f59f4375b19b67945e11e156ef266fe9)|HTML||2018-10-30 23:20:46|VirusShare_f59f4375b19b67945e11e156ef266fe9|
|[e8eaec1f021a564b82b824af1dbe6c4d](https://www.virustotal.com/gui/file/e8eaec1f021a564b82b824af1dbe6c4d)|Win64 DLL||2015-06-10 07:20:00|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DoquAPT/DoquDropper.bin|
|[984c857ca2979af776647061c8ae3acc](https://www.virustotal.com/gui/file/984c857ca2979af776647061c8ae3acc)|LNK||2010-10-01 10:30:14|Copy of Shortcut to.lnk|
|[ca55b1d741a1eb19c9517fb001866fc2](https://www.virustotal.com/gui/file/ca55b1d741a1eb19c9517fb001866fc2)|Win32 DLL|Zbot|2010-08-26 00:34:46|~WTR4132.tmp|
|[4589ef6876e9c8c05dcf4db00a54887b](https://www.virustotal.com/gui/file/4589ef6876e9c8c05dcf4db00a54887b)|Win32 DLL|Zbot|2010-06-07 07:06:54|~WTR4141.tmp|
|[f8153747bae8b4ae48837ee17172151e](https://www.virustotal.com/gui/file/f8153747bae8b4ae48837ee17172151e)|Win32 EXE||2010-05-16 06:08:06|A0055521.sys|
