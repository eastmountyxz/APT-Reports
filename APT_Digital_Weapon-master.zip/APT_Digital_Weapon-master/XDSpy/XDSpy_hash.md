|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4aca8298c6068a5765740d5aca870422](https://www.virustotal.com/gui/file/4aca8298c6068a5765740d5aca870422)|Win64 EXE||2020-09-23 11:33:23|c:\users\admini~1\appdata\local\temp\user ms service.exe|
|[27f99b28e81b76f20e712a12b5262652](https://www.virustotal.com/gui/file/27f99b28e81b76f20e712a12b5262652)|VBA||2020-09-01 20:53:40|rospotrebnadzor-rekomendatsii.wsf|
|[18a530db028194c138f9f546f7b6c77d](https://www.virustotal.com/gui/file/18a530db028194c138f9f546f7b6c77d)|Win64 EXE||2020-08-05 08:55:37|Usermode COM Manager.exe|
|[6e6a56ac77360aaca57c706a4e34c7be](https://www.virustotal.com/gui/file/6e6a56ac77360aaca57c706a4e34c7be)|LNK|Banload|2020-03-12 08:06:30|f44de9ab07e40123c4884556dbca2edbd7b20172cd70ab6328b71f5bf95140b7.bin|
|[e93ae776c615f53b1b49f0a820ab6ccc](https://www.virustotal.com/gui/file/e93ae776c615f53b1b49f0a820ab6ccc)|Win64 EXE||2020-02-21 07:09:22| |
|[8d9e15c6be9159b2d1b0024f906dcef0](https://www.virustotal.com/gui/file/8d9e15c6be9159b2d1b0024f906dcef0)|Win64 DLL||2020-01-31 01:22:17| |
|[b2fa5ce497355d3f8b11fbd152b84ea3](https://www.virustotal.com/gui/file/b2fa5ce497355d3f8b11fbd152b84ea3)|Win64 DLL|Tiggre|2020-01-31 01:21:06| |
|[46de4d507f54e65f5e3f10b470cb2109](https://www.virustotal.com/gui/file/46de4d507f54e65f5e3f10b470cb2109)|Win64 DLL||2020-01-17 14:21:33|archset.dat|
|[c6ed160688d8cbbbd5c8b8a2afe849d9](https://www.virustotal.com/gui/file/c6ed160688d8cbbbd5c8b8a2afe849d9)|Win32 EXE||2015-10-28 15:58:30|82c08697466ef64866af6d41936d6231307e09bc75eace4e7fee371ebc2eb1ef.bin|
|[55c22b278bd407a0acd4b85017dc627c](https://www.virustotal.com/gui/file/55c22b278bd407a0acd4b85017dc627c)|TXT||2015-08-25 12:33:01|Сотрудники склада находок ГУВД обнаружили ваш емайл адрес.eml|
|[432af428b011a488d0f2f62efe195bd4](https://www.virustotal.com/gui/file/432af428b011a488d0f2f62efe195bd4)|Win32 EXE|Fareit|2011-08-25 14:39:35|/data/modqi/samples/sum/1529a6791da28a19f306d008b5dd13aa0341c7586b0b8b056db7f9e3c79b31c1|
