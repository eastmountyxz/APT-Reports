**NAME:**  
XDSpy

 
**Description**:   
XDSpy, uncovered by ESET researchers, is an APT group that has been stealing sensitive documents from several governments in the Eastern Europe and the Balkans since 2011. Targets are primarily government entities, including militaries, Ministries of Foreign Affairs, and private companies. The developers might be working in the UTC+2 or UTC+3 time zone and the operators seem to use spear phishing emails in order to compromise their targets.

  
**References**:  
https://www.welivesecurity.com/2020/10/02/xdspy-stealing-government-secrets-since-2011/ 
