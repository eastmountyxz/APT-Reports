|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c9a0e0c04b27276fcce552cf175b2c82](https://www.virustotal.com/gui/file/c9a0e0c04b27276fcce552cf175b2c82)|Win32 EXE|Kryptik|2017-11-12 17:56:38|c9a0e0c04b27276fcce552cf175b2c82.virus|
|[9416cc6841ad0b373b81af87586ec0e4](https://www.virustotal.com/gui/file/9416cc6841ad0b373b81af87586ec0e4)|Win32 EXE|Kryptik|2017-10-29 17:35:39|Application v1.6.exe|
|[85ed0701b55c59337bd7df9b921841dc](https://www.virustotal.com/gui/file/85ed0701b55c59337bd7df9b921841dc)|Win32 EXE|Kryptik|2017-10-25 12:34:57|E:/virussign/malware/new_request/20171028/85ed0701b55c59337bd7df9b921841dc.vir|
|[bc6baf7a1d420d226a7a157b412a51d9](https://www.virustotal.com/gui/file/bc6baf7a1d420d226a7a157b412a51d9)|Win32 EXE|dynamer|2016-05-11 06:42:50|Internet Log.exe|
|[6e66ed5d8c7d4ca9c2e96f2cc045eb94](https://www.virustotal.com/gui/file/6e66ed5d8c7d4ca9c2e96f2cc045eb94)|Win32 EXE||2016-05-04 13:13:53|News.exe|
|[e5500274853f77be6ffba610dac2cae4](https://www.virustotal.com/gui/file/e5500274853f77be6ffba610dac2cae4)|Win32 EXE||2016-05-02 09:07:46|/home/virustotal/sample/E5500274853F77BE6FFBA610DAC2CAE4|
|[ffa1bdc105013e1cbb00483b412b98b8](https://www.virustotal.com/gui/file/ffa1bdc105013e1cbb00483b412b98b8)|Win32 EXE|dynamer|2016-04-30 12:12:01|Updata.exe|
|[8655af063090ef192a7f1e0c05c7883f](https://www.virustotal.com/gui/file/8655af063090ef192a7f1e0c05c7883f)|Win32 EXE||2016-04-29 19:47:52|News.exe|
|[b4ab538f592082373e9ab96373561713](https://www.virustotal.com/gui/file/b4ab538f592082373e9ab96373561713)|Win32 EXE||2016-04-27 06:03:23|MusicLogs.exe|
|[b85c17f92629fec41502b44cf86ba859](https://www.virustotal.com/gui/file/b85c17f92629fec41502b44cf86ba859)|Win32 EXE|Upatre|2016-04-26 17:56:46|MusicLogs.exe|
|[923844dfc3d5b21f288df9beaa958baf](https://www.virustotal.com/gui/file/923844dfc3d5b21f288df9beaa958baf)|Win32 EXE|dynamer|2016-04-18 05:25:48|Office 2016.exe|
|[b8c6c8eeb9a18b1d4632bc8191db5517](https://www.virustotal.com/gui/file/b8c6c8eeb9a18b1d4632bc8191db5517)|Win32 EXE|Upatre|2016-04-17 12:09:18|Folder.exe|
|[d01848a20e0f5c4a7a7243bb98a7b26c](https://www.virustotal.com/gui/file/d01848a20e0f5c4a7a7243bb98a7b26c)|Win32 EXE|razy|2016-04-17 12:08:12|שישה הרוגים וכ-15 פצועים בהתנגשות אוטובוס ומשאית.exe|
|[b11b7b7b5bd80779dd885628d65e02e5](https://www.virustotal.com/gui/file/b11b7b7b5bd80779dd885628d65e02e5)|Win32 EXE|Upatre|2016-03-31 06:38:09|Folder.exe|
|[cc24cd17fa93fce7ea1128edeb9ee40b](https://www.virustotal.com/gui/file/cc24cd17fa93fce7ea1128edeb9ee40b)|Win32 EXE|Upatre|2016-03-31 06:37:26|israel_s_cellebrite_linked_to_fbi_s_iphone_hack_attempt.exe.bin|
|[ddff0a7643f4ff2fe777e768e7bae004](https://www.virustotal.com/gui/file/ddff0a7643f4ff2fe777e768e7bae004)|Win32 EXE|MSILPerseus|2016-03-29 16:23:02|log file.exe|
|[8ba38899a6446366724d98761dd10d46](https://www.virustotal.com/gui/file/8ba38899a6446366724d98761dd10d46)|Win32 EXE|razy|2016-03-22 23:00:21|HWORKS|
|[6f08808d0be510698563d3b0443fe5a4](https://www.virustotal.com/gui/file/6f08808d0be510698563d3b0443fe5a4)|Win32 EXE|ursu|2016-02-25 09:29:21|MusicLogs.exe|
|[a5b3fb5119fad72ac321d8d6416b6b92](https://www.virustotal.com/gui/file/a5b3fb5119fad72ac321d8d6416b6b92)|RAR|razy|2016-02-10 23:50:28|Report-Palestinian-President.rar";filename*=UTF-8''Report-Palestinian-President.rar|
|[77fd78042407a7318dba388da00700cc](https://www.virustotal.com/gui/file/77fd78042407a7318dba388da00700cc)|Win32 EXE|Upatre|2016-02-10 16:01:32|/home/virustotal/sample/77FD78042407A7318DBA388DA00700CC|
|[a50da199db97abb2dfd6fd62b5a00f02](https://www.virustotal.com/gui/file/a50da199db97abb2dfd6fd62b5a00f02)|Win32 EXE|MSILPerseus|2016-02-10 13:54:57|log file.exe|
|[d538e50df25e30f3c4252ce523507d23](https://www.virustotal.com/gui/file/d538e50df25e30f3c4252ce523507d23)|Win32 EXE|dynamer|2016-02-10 03:52:47|????? ???????? ???? ??????? ???? ??????? ?? ??? ?????? .exe|
