**NAME:**  
Operation Dustysky  
 
**Description**:   
Most of the targets are from the Middle East: Israel, Egypt, Saudi Arabia, United Arab Emirates and Iraq. The United States and countries in Europe are targeted as well. Targeted sectors include governmental and diplomatic institutions, including embassies; companies from the aerospace and defense Industries; financial institutions; journalists; software developers.
  
**References**:  
https://www.clearskysec.com/wp-content/uploads/2016/01/Operation%20DustySky_TLP_WHITE.pdf
