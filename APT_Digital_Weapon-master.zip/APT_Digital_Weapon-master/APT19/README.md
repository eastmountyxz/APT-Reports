**NAME:**  
APT19  
  
**Alias**  
Shell Crew, WebMasters, APT 19, KungFu Kittens, Black Vine, Group 13, PinkPanther, Sh3llCr3w, TEMP.Avengers, Hurricane Panda, Codoso, C0d0so0, Deep Panda, Sunshop Group, APT19  
  
**Description**:   
APT19 is reported to be Chinese-based threat group that has targeted a variety of industries, including defense, finance, energy, pharmaceutical, telecommunications, high tech, education, manufacturing, and legal services.
  
**References**:  
https://www.crowdstrike.com/blog/deep-thought-chinese-targeting-national-security-think-tanks/
http://www.crowdstrike.com/blog/cyber-deterrence-in-action-a-story-of-one-long-hurricane-panda-campaign/

