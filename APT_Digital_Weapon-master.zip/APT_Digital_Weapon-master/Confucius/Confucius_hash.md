|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[1517f59002b6cc98e3f74f97fb4caa70](https://www.virustotal.com/gui/file/1517f59002b6cc98e3f74f97fb4caa70)|DOCX||2019-09-12 04:15:17|Modis Hindutava Policy.docx|
|[f27e6a256b85b80a48069c193fc244b0](https://www.virustotal.com/gui/file/f27e6a256b85b80a48069c193fc244b0)|ZIP||2019-08-03 10:47:29|AppsSLoader.ipa|
|[d6a5e6b77914db9a161037f796bb90e2](https://www.virustotal.com/gui/file/d6a5e6b77914db9a161037f796bb90e2)|Win32 EXE||2019-07-03 05:55:17|5dd080b9ad4bc5c58c0ced31829ccada.ex_|
|[ccb18f9c47636134e3483dc86369204a](https://www.virustotal.com/gui/file/ccb18f9c47636134e3483dc86369204a)|Win32 EXE||2019-07-03 04:00:55|14197b5d1cc4789edabe976a844cd98a1464bae1cf0899e2f7ae7657f67d085b.sample|
|[303f01e8ce9488ca7c1b265a8768cce0](https://www.virustotal.com/gui/file/303f01e8ce9488ca7c1b265a8768cce0)|FPX||2019-07-02 10:59:17|Court_Notice.inp|
|[5dd080b9ad4bc5c58c0ced31829ccada](https://www.virustotal.com/gui/file/5dd080b9ad4bc5c58c0ced31829ccada)|FPX||2019-07-02 10:58:58|Press_Note.inp|
|[d7dba7a0106306136ad86d01e204fe35](https://www.virustotal.com/gui/file/d7dba7a0106306136ad86d01e204fe35)|Android||2019-05-10 23:44:06|all_samples/gapps_split/warn_spyware/cdd03568a2672f65380f179a6412fd9a24a8198d4059a2990024431d7cbfb76c.apk|
|[adb95c629f95190bbf6d3f954de6057e](https://www.virustotal.com/gui/file/adb95c629f95190bbf6d3f954de6057e)|Android||2019-02-26 17:34:25|Philions_v1.0.4_apkpure.com.apk|
|[2c3b9984be2d8609f83d10171a4f1059](https://www.virustotal.com/gui/file/2c3b9984be2d8609f83d10171a4f1059)|Win32 EXE|Delf|2018-09-11 02:26:35|ispecsr|
|[e92b08da49b59536be55c26090988af2](https://www.virustotal.com/gui/file/e92b08da49b59536be55c26090988af2)|Win32 EXE||2018-08-06 15:04:12|Track System Report|
|[c23a633570caed8e47f1a141b1d56d8f](https://www.virustotal.com/gui/file/c23a633570caed8e47f1a141b1d56d8f)|ZIP||2018-07-31 11:06:11|Sample_5b6a44a270c09e11ca01c11f.bin.rename|
|[ae8031cb4758b24d3b8c812c916e7c89](https://www.virustotal.com/gui/file/ae8031cb4758b24d3b8c812c916e7c89)|Win32 EXE|Delf|2018-07-06 14:54:06|grphsrv|
|[2e6f5d21a40ab1a2c59312c54fb337b0](https://www.virustotal.com/gui/file/2e6f5d21a40ab1a2c59312c54fb337b0)|Win32 EXE|Delf|2018-06-22 06:22:07|fgftech.exe|
|[cffaed62dc2d24e716af4d486248538b](https://www.virustotal.com/gui/file/cffaed62dc2d24e716af4d486248538b)|Win32 EXE|Delf|2018-06-16 23:07:41|srstech|
|[8b836df25ca7e33ecbe9944446368df4](https://www.virustotal.com/gui/file/8b836df25ca7e33ecbe9944446368df4)|Win32 EXE||2018-06-16 09:00:37|ststech.exe|
|[9d9ddca359e1036d67dd5db7c9b8a875](https://www.virustotal.com/gui/file/9d9ddca359e1036d67dd5db7c9b8a875)|RTF|Delf|2018-06-16 06:20:37|press release.doc|
|[f9ad3d4c90528e654de20159859ca15b](https://www.virustotal.com/gui/file/f9ad3d4c90528e654de20159859ca15b)|Win32 EXE|Delf|2018-05-26 15:14:56|sscvc|
|[2de1b9e39768c6a0c59e6a0413c157a6](https://www.virustotal.com/gui/file/2de1b9e39768c6a0c59e6a0413c157a6)|Win32 EXE|Delf|2018-05-15 21:25:38|jnktech.exe|
|[ed9bc3e8dd9c6484c94090e703523d8b](https://www.virustotal.com/gui/file/ed9bc3e8dd9c6484c94090e703523d8b)|Win32 EXE|strictor|2018-05-15 17:32:31|Winctrls|
|[ea282085064e443e58a2e562e2c4b51e](https://www.virustotal.com/gui/file/ea282085064e443e58a2e562e2c4b51e)|RTF|Delf|2018-05-14 07:10:53| |
|[80e0f7776c3f853302e60a692ab9d895](https://www.virustotal.com/gui/file/80e0f7776c3f853302e60a692ab9d895)|RTF||2018-05-14 06:12:25|80e0f7776c3f853302e60a692ab9d895.doc|
|[b65ae51ce74d4971185a1502fec59cb8](https://www.virustotal.com/gui/file/b65ae51ce74d4971185a1502fec59cb8)|Win32 EXE|Delf|2018-05-10 04:19:09|microfest|
|[3e9ea168c4a3c935591089e05b344413](https://www.virustotal.com/gui/file/3e9ea168c4a3c935591089e05b344413)|RTF||2018-05-07 13:37:48|e31c74162e4877fdb1ada8bc6eb3997550e85df5|
|[933ad57c6d860c6b675cf459893e7542](https://www.virustotal.com/gui/file/933ad57c6d860c6b675cf459893e7542)|RTF||2018-04-30 16:13:59|ac49ff8784bf36b8dfb3f5bfbf5f857876c06dc7|
|[bf27bbcf6f92c3935e0f8515e90a5da1](https://www.virustotal.com/gui/file/bf27bbcf6f92c3935e0f8515e90a5da1)|Win32 EXE|Delf|2018-04-29 09:17:26|wctrls|
|[11a34f484f9b44778397b6e02ef05244](https://www.virustotal.com/gui/file/11a34f484f9b44778397b6e02ef05244)|Android||2018-04-02 12:29:04|Fuddi Duniya.apk|
|[cd07f7597a216f930834b0ccc50a0520](https://www.virustotal.com/gui/file/cd07f7597a216f930834b0ccc50a0520)|Win32 EXE|Delf|2018-02-23 13:18:33|winsctrls|
|[f7c8dd1979ca1405514d95c300831e8f](https://www.virustotal.com/gui/file/f7c8dd1979ca1405514d95c300831e8f)|RTF||2018-02-23 09:04:13|7be2628f1cfba974979208cace745561e0403c639df8e87238938c8afae30788.bin|
|[dc8a682d34c2b4a9cdbdfb3f4862a751](https://www.virustotal.com/gui/file/dc8a682d34c2b4a9cdbdfb3f4862a751)|Win32 EXE||2018-02-14 13:40:06|dc8a682d34c2b4a9cdbdfb3f4862a751.virus|
|[b797a0eec597deb3ecef7891a9756f5d](https://www.virustotal.com/gui/file/b797a0eec597deb3ecef7891a9756f5d)|Win64 EXE||2018-02-14 03:10:20|Wextract|
|[73f53f565993602062c945d17b743d64](https://www.virustotal.com/gui/file/73f53f565993602062c945d17b743d64)|Win32 EXE||2018-02-10 20:03:28|73f53f565993602062c945d17b743d64.virus|
|[0667fa0c988be98c69bea88fdbca1146](https://www.virustotal.com/gui/file/0667fa0c988be98c69bea88fdbca1146)|Win32 EXE|graftor|2018-02-09 09:06:51|winsctrls|
|[0683dd2830f66e60acdc67444a405778](https://www.virustotal.com/gui/file/0683dd2830f66e60acdc67444a405778)|RTF|graftor|2018-02-09 05:45:39|0683dd2830f66e60acdc67444a405778.exe|
|[17ca049d206a0273e267ba9490cbf243](https://www.virustotal.com/gui/file/17ca049d206a0273e267ba9490cbf243)|Win32 EXE|Delf|2018-02-08 10:04:38|svctrls|
|[f56d2aa7437cce76ba9e5d70f0756a3c](https://www.virustotal.com/gui/file/f56d2aa7437cce76ba9e5d70f0756a3c)|RTF||2018-02-08 06:52:35|doc.rtf|
|[c1ef0f1f16f34417c002e5124d00a5f1](https://www.virustotal.com/gui/file/c1ef0f1f16f34417c002e5124d00a5f1)|Win32 EXE|graftor|2018-02-06 16:38:42|winsctrls|
|[cb7c71fd2ae770a029a32fd4477b8df5](https://www.virustotal.com/gui/file/cb7c71fd2ae770a029a32fd4477b8df5)|RTF|graftor|2018-02-06 13:27:42|FFE9B86BBC2298BA003796BD18283FB4FBA78962AE5AEFD213A78B3494FD5708|
|[a707feb2046997f1ca98619f95f036f8](https://www.virustotal.com/gui/file/a707feb2046997f1ca98619f95f036f8)|Win32 EXE|starter|2018-02-04 07:25:23|a707feb2046997f1ca98619f95f036f8.virus|
|[54c123c0da9c9c44d7b9fa4a40206e4e](https://www.virustotal.com/gui/file/54c123c0da9c9c44d7b9fa4a40206e4e)|Android|androidos|2018-01-30 12:14:26|54c123c0da9c9c44d7b9fa4a40206e4e.virus|
|[52e665a956da0a70227b03e7af0a0294](https://www.virustotal.com/gui/file/52e665a956da0a70227b03e7af0a0294)|Win32 EXE||2018-01-29 23:38:26|vcsrss|
|[9f83e6689f4c68022ddcb6d29cee55c5](https://www.virustotal.com/gui/file/9f83e6689f4c68022ddcb6d29cee55c5)|Win32 EXE||2018-01-22 11:27:48|svctrls|
|[666143a29e5355d1ee26dd9746fe7732](https://www.virustotal.com/gui/file/666143a29e5355d1ee26dd9746fe7732)|Win32 EXE|razy|2018-01-15 06:09:50|xvxxxvc|
|[055aac7c28db19485401c43b39c041b7](https://www.virustotal.com/gui/file/055aac7c28db19485401c43b39c041b7)|Android|androidos|2018-01-12 07:13:44|055aac7c28db19485401c43b39c041b7.virus|
|[72aebfe40892fa7f7d7312b01d3046e5](https://www.virustotal.com/gui/file/72aebfe40892fa7f7d7312b01d3046e5)|Win32 EXE|razy|2018-01-07 02:35:39|oiuoioiu|
|[d83d354edfbe52b8828f4b90f192f47d](https://www.virustotal.com/gui/file/d83d354edfbe52b8828f4b90f192f47d)|Targa|Delf|2017-12-21 20:12:52|cpt.jpg|
|[f8ea490deeb13bf515a0a1d33bd5b6bb](https://www.virustotal.com/gui/file/f8ea490deeb13bf515a0a1d33bd5b6bb)|Win32 EXE||2017-12-21 16:46:01|usctrls|
|[c1d19c9d4acd67f741acb92a383dc317](https://www.virustotal.com/gui/file/c1d19c9d4acd67f741acb92a383dc317)|Win32 EXE||2017-12-21 16:44:57|6322383a5cedc8e5de5f689c0fc4df7f96fc0e1ccf1d508e836a3e5842d05a73.exe.bin|
|[368b21ff54e5a3e956f8d2b4f70e9bc8](https://www.virustotal.com/gui/file/368b21ff54e5a3e956f8d2b4f70e9bc8)|Win32 EXE||2017-12-21 16:24:33|3f4e884bd33032b6e0daab91d50a96c3e8f88938971accf7948e1da76a45704d.exe.bin|
|[d1718ce033169b7ed11991f045d7d1ab](https://www.virustotal.com/gui/file/d1718ce033169b7ed11991f045d7d1ab)|Win32 EXE||2017-12-21 16:21:39|svctrls|
|[9700e43a8211582b6c3c6ebb5482ffca](https://www.virustotal.com/gui/file/9700e43a8211582b6c3c6ebb5482ffca)|Win32 EXE||2017-12-21 16:19:53|da2ffe73cefd2ebbe0efa415da6eab91dacdc87dd46110d6aa0871f75a45bd2a.exe.bin|
|[2a1866fc3aaa2084ce5c87e10857672a](https://www.virustotal.com/gui/file/2a1866fc3aaa2084ce5c87e10857672a)|Win32 EXE||2017-12-21 16:17:43|syspdaci.exe|
|[c0c81c7e2a5c742a91f37f9493f766ee](https://www.virustotal.com/gui/file/c0c81c7e2a5c742a91f37f9493f766ee)|Win32 EXE||2017-12-21 16:06:59|localfile~|
|[4f65bee3c859ed995c5b5a2bca35e14a](https://www.virustotal.com/gui/file/4f65bee3c859ed995c5b5a2bca35e14a)|Text||2017-12-21 15:55:31|4f65bee3c859ed995c5b5a2bca35e14a.virus|
|[8b2742ed3ae15b7a9eaa900f28d21c5d](https://www.virustotal.com/gui/file/8b2742ed3ae15b7a9eaa900f28d21c5d)|Win32 EXE||2017-12-21 15:46:03|/var/www/clean-mx/virusesevidence/output.112627056.txt|
|[b8f28bb444f4567336f83037172a3164](https://www.virustotal.com/gui/file/b8f28bb444f4567336f83037172a3164)|Win32 EXE||2017-12-21 15:19:50|dbsk.exe|
|[1cd356ab1943f120b04ad21afd9dcdb3](https://www.virustotal.com/gui/file/1cd356ab1943f120b04ad21afd9dcdb3)|Win32 EXE||2017-12-21 15:15:20|sip_agents.exe|
|[e2d136bb63edc092d2f3d26885b239d9](https://www.virustotal.com/gui/file/e2d136bb63edc092d2f3d26885b239d9)|Win32 EXE||2017-12-21 15:09:02|e2d136bb63edc092d2f3d26885b239d9.virus|
|[e0f801d18f264014b83c128232161f90](https://www.virustotal.com/gui/file/e0f801d18f264014b83c128232161f90)|RTF|CVE-2017-11882|2017-12-21 14:47:21|e0f801d18f264014b83c128232161f90.virus|
|[c3d93db2aa5aaf4f821548e15d79946e](https://www.virustotal.com/gui/file/c3d93db2aa5aaf4f821548e15d79946e)|RTF|CVE-2017-11882|2017-12-21 05:01:45|c3d93db2aa5aaf4f821548e15d79946e.virus|
|[611302b8a9e4d0bb0eb655e0734498c6](https://www.virustotal.com/gui/file/611302b8a9e4d0bb0eb655e0734498c6)|Android|androidos|2017-12-05 01:43:42|611302b8a9e4d0bb0eb655e0734498c6.virus|
|[63c2bc55a032eef24d0746158727e373](https://www.virustotal.com/gui/file/63c2bc55a032eef24d0746158727e373)|Android|androidos|2017-08-31 04:32:44|Khuai Translator_v1.3_apkpure.com.apk|
|[94a6aba63c9d2d9587e424acfde41bcb](https://www.virustotal.com/gui/file/94a6aba63c9d2d9587e424acfde41bcb)|Win32 EXE|msilperseus|2017-08-31 04:22:13|mxiupdate.exe|
|[eef02e1d71bb82ede4803d7032b1cc95](https://www.virustotal.com/gui/file/eef02e1d71bb82ede4803d7032b1cc95)|Win32 EXE|dynamer|2017-08-28 09:59:55|E:/vt/malware/20170902/eef02e1d71bb82ede4803d7032b1cc95.vir|
|[146335f1c4ffaae9cf3d48e767a1c66b](https://www.virustotal.com/gui/file/146335f1c4ffaae9cf3d48e767a1c66b)|Android|androidos|2017-08-26 00:54:24|146335f1c4ffaae9cf3d48e767a1c66b.virus|
|[c2806da263932d5cd157e0c58429fc21](https://www.virustotal.com/gui/file/c2806da263932d5cd157e0c58429fc21)|Win32 EXE|Buterat|2017-08-24 23:05:52|C:/Users/seongmin/Documents/VT2/malware/20170830/c2806da263932d5cd157e0c58429fc21.vir|
|[b886ba5d0eec4187cea1e78daabd2a42](https://www.virustotal.com/gui/file/b886ba5d0eec4187cea1e78daabd2a42)|Win32 EXE|Zbot|2017-08-17 04:28:11|52e3a31baf1e2e8fffd1c363aa5f24a7e3644535|
|[9aa59bb95632ba6331d0dd34acf0ef07](https://www.virustotal.com/gui/file/9aa59bb95632ba6331d0dd34acf0ef07)|Win32 EXE|Delf|2017-08-16 04:57:04|winframe|
|[da56bedde599a9c6b60fb67d740e4879](https://www.virustotal.com/gui/file/da56bedde599a9c6b60fb67d740e4879)|Win32 EXE|Buterat|2017-07-04 10:35:21|payload.exe|
|[1109cc4685a4ec131111f315995b1780](https://www.virustotal.com/gui/file/1109cc4685a4ec131111f315995b1780)|Win32 EXE||2017-06-14 14:18:32|ab.exe|
|[67302526092ce19043cdb79aab701883](https://www.virustotal.com/gui/file/67302526092ce19043cdb79aab701883)|Win32 EXE|razy|2017-06-13 22:35:24|hmnss|
|[f23cae2385bcafc70012b6d63025ad71](https://www.virustotal.com/gui/file/f23cae2385bcafc70012b6d63025ad71)|Win32 EXE|Delf|2017-04-13 05:51:46|myfile.exe|
|[d257f1daa83938999907380d864ecdce](https://www.virustotal.com/gui/file/d257f1daa83938999907380d864ecdce)|RTF|program|2017-04-13 01:08:44|d257f1daa83938999907380d864ecdce.virus|
|[e5011fdcf4502f019f3b6e1e44d73036](https://www.virustotal.com/gui/file/e5011fdcf4502f019f3b6e1e44d73036)|Win32 EXE|Zbot|2017-03-26 11:27:01|PuTTY|
|[fdf9a4355c75f3a00911226f4b6fe561](https://www.virustotal.com/gui/file/fdf9a4355c75f3a00911226f4b6fe561)|Win32 EXE|razy|2017-01-24 22:20:34|/var/www/clean-mx/virusesevidence/output.106667114.txt|
|[9aa18d8d965b7ae33e9943d3c4d52db9](https://www.virustotal.com/gui/file/9aa18d8d965b7ae33e9943d3c4d52db9)|Win32 EXE|Androm|2017-01-13 05:14:04|winsys-restore.exe|
|[272b295e3a9d356bf717a94f4787fe13](https://www.virustotal.com/gui/file/272b295e3a9d356bf717a94f4787fe13)|Win32 EXE||2017-01-09 11:41:11|igxupd0.txt|
|[b8982ee383e14ea6d73c3c1243648747](https://www.virustotal.com/gui/file/b8982ee383e14ea6d73c3c1243648747)|Win32 EXE||2016-12-18 09:28:12|visit.exe|
|[79ff33226fcb60282b6d14b7de3a10ba](https://www.virustotal.com/gui/file/79ff33226fcb60282b6d14b7de3a10ba)|Win32 EXE||2016-12-15 19:44:58|7d344a9572396563657de395355f3b105f01c83f|
|[b42015dacced2172884adb3ef8258d3c](https://www.virustotal.com/gui/file/b42015dacced2172884adb3ef8258d3c)|Win32 EXE||2016-12-14 19:05:46|igxupd.txt|
|[e4d5499e5f4a78244a4694f493492a14](https://www.virustotal.com/gui/file/e4d5499e5f4a78244a4694f493492a14)|Win32 EXE|Zbot|2016-12-14 19:05:41|e4d5499e5f4a78244a4694f493492a14.virus|
|[cfa27503eb37b1c94966d7ac3a5c28c0](https://www.virustotal.com/gui/file/cfa27503eb37b1c94966d7ac3a5c28c0)|Win32 EXE|dynamer|2016-09-30 20:03:35|cfa27503eb37b1c94966d7ac3a5c28c0.virus|
|[79df1c2995524c456d3f699f77a64452](https://www.virustotal.com/gui/file/79df1c2995524c456d3f699f77a64452)|Win32 EXE||2016-08-25 04:02:25|winsys-restore.exe|
|[524408c02c11d3410b554edcde51f9cb](https://www.virustotal.com/gui/file/524408c02c11d3410b554edcde51f9cb)|Win32 EXE|Reconyc|2016-08-18 14:24:13|olympics‮xspp.scr|
|[5fc8af63b2a1872b2e250cef1649cdb3](https://www.virustotal.com/gui/file/5fc8af63b2a1872b2e250cef1649cdb3)|Win32 EXE|dynamer|2016-08-08 15:26:45|vstax86.dat|
|[9d275e33b8284fae7027bb4b7c6d9152](https://www.virustotal.com/gui/file/9d275e33b8284fae7027bb4b7c6d9152)|Win32 EXE||2016-08-02 23:07:23|rcs.exe|
|[1daaf244b8d9a9cd5c452b15ae7f1797](https://www.virustotal.com/gui/file/1daaf244b8d9a9cd5c452b15ae7f1797)|Win32 EXE||2016-07-22 00:37:42|PuTTY|
|[94da91def54db4c1895eb7ba99eb75a6](https://www.virustotal.com/gui/file/94da91def54db4c1895eb7ba99eb75a6)|ZIP||2016-07-15 05:51:24|94da91def54db4c1895eb7ba99eb75a6.virus|
|[eec26ee59a6fc0f4b7a2a82b13fe6b05](https://www.virustotal.com/gui/file/eec26ee59a6fc0f4b7a2a82b13fe6b05)|Android||2016-06-02 00:27:44|Devoted To Humanity_v1.0_apkpure.com.apk|
|[6ada0824811ebf5097060249e08792b3](https://www.virustotal.com/gui/file/6ada0824811ebf5097060249e08792b3)|Win32 EXE||2016-04-29 12:17:06|sample.exe|
|[f53301fc1ab2bc4a62f387cc0131a71e](https://www.virustotal.com/gui/file/f53301fc1ab2bc4a62f387cc0131a71e)|Win32 EXE||2016-04-26 08:30:56|MS Security Suite|
|[3cda4e8defa728d7fbea43eb2a1b0353](https://www.virustotal.com/gui/file/3cda4e8defa728d7fbea43eb2a1b0353)|Win32 EXE|strictor|2016-04-06 02:08:32|MS Security Suite|
|[0a6306a2b0ab61e32105223f10eee58b](https://www.virustotal.com/gui/file/0a6306a2b0ab61e32105223f10eee58b)|Win32 EXE||2016-04-05 23:37:08|Enigma Player Release|
|[8e0fbee4adc0675a4f42aa3ea64efe09](https://www.virustotal.com/gui/file/8e0fbee4adc0675a4f42aa3ea64efe09)|Win32 EXE||2016-04-05 15:19:28|Invitation_p‮cod.scr|
|[c716eb7cb270cd7d19bd30b99e65152e](https://www.virustotal.com/gui/file/c716eb7cb270cd7d19bd30b99e65152e)|Win32 EXE||2016-04-04 20:27:37|MS Security Suite|
|[44bd97623cee4698a85ad50282cdbff4](https://www.virustotal.com/gui/file/44bd97623cee4698a85ad50282cdbff4)|Win32 EXE|strictor|2016-04-04 19:20:23|MS Security Suite|
|[82de046d4109fdc9bc490602594ff21e](https://www.virustotal.com/gui/file/82de046d4109fdc9bc490602594ff21e)|Win32 EXE|dynamer|2016-03-22 04:41:13|winlog32.txt|
|[b1c11ebd82ff4942f61217bfcdf71255](https://www.virustotal.com/gui/file/b1c11ebd82ff4942f61217bfcdf71255)|Win32 EXE||2016-02-07 08:23:53| |
|[89e1c433e65dd364aa95eaa7a24c0a24](https://www.virustotal.com/gui/file/89e1c433e65dd364aa95eaa7a24c0a24)|Win32 EXE||2016-01-21 14:27:04|SmartScreen.txt|
|[ad462e126d40ad25ba066349eaadc76d](https://www.virustotal.com/gui/file/ad462e126d40ad25ba066349eaadc76d)|Win32 EXE||2015-11-23 10:27:00|ad462e126d40ad25ba066349eaadc76d.virus|
|[5dd58964a4963b61ed2a2ed7d9344d04](https://www.virustotal.com/gui/file/5dd58964a4963b61ed2a2ed7d9344d04)|Win32 EXE||2015-11-23 10:22:37|rundll.exe|
|[b07c50fd6372b9126102fffd6945f602](https://www.virustotal.com/gui/file/b07c50fd6372b9126102fffd6945f602)|Win32 EXE||2015-10-31 07:08:00| |
|[95c9cd7518ce1eaef14b8266dca659ea](https://www.virustotal.com/gui/file/95c9cd7518ce1eaef14b8266dca659ea)|Win32 EXE|kazy|2015-09-04 19:26:03|wscsvcem.exe|
|[79288c360181298f47036c2200eb32ac](https://www.virustotal.com/gui/file/79288c360181298f47036c2200eb32ac)|Win32 EXE||2015-08-27 20:01:31|Word|
|[6361ae35be80ecbdf27714ccde233c7b](https://www.virustotal.com/gui/file/6361ae35be80ecbdf27714ccde233c7b)|Win32 EXE||2015-08-13 18:05:14| |
|[d26372f17d72ef9faf3aceb054e89d45](https://www.virustotal.com/gui/file/d26372f17d72ef9faf3aceb054e89d45)|Win32 EXE||2015-08-13 17:18:18|WscSvce_w.txt|
|[446719d33304b57424801f967f7692c2](https://www.virustotal.com/gui/file/446719d33304b57424801f967f7692c2)|Win32 EXE||2015-06-18 07:55:18| |
|[bec23eaec3bc7a82467b244d5624c4fc](https://www.virustotal.com/gui/file/bec23eaec3bc7a82467b244d5624c4fc)|Win32 EXE||2015-05-23 14:20:34|c:\drivers\windows\mmcsle.exe|
|[c5068c3d3b72fa8b3b113f462bb30f6b](https://www.virustotal.com/gui/file/c5068c3d3b72fa8b3b113f462bb30f6b)|Win32 EXE||2015-05-12 06:00:04|SYSLOG.EXE|
|[5c6ed994f898b5689e6dd4d516ac4896](https://www.virustotal.com/gui/file/5c6ed994f898b5689e6dd4d516ac4896)|Win32 EXE||2015-04-19 16:51:09|m:\dailytesters\##\_ESET\A\a variant of Win32.Agent.WQR trojan\487d43f38006a609715f95d2e8dd605446de820cafcc453d57a452bc67972a7a.exe|
|[1ff517fb0f45cf09acdad03cd5a2fa63](https://www.virustotal.com/gui/file/1ff517fb0f45cf09acdad03cd5a2fa63)|Win32 EXE||2015-04-10 10:39:13|VirusShare_1ff517fb0f45cf09acdad03cd5a2fa63|
|[8f300d700433b4629c31323f49ebca48](https://www.virustotal.com/gui/file/8f300d700433b4629c31323f49ebca48)|Win32 EXE||2015-01-16 22:23:16|ajitdovalspeech-uncut.scr|
|[cd9efef2977d2da073057183b758db84](https://www.virustotal.com/gui/file/cd9efef2977d2da073057183b758db84)|Win32 EXE||2015-01-02 06:31:24|2015 Calendar.scr|
|[c7af8d1aa8f4780be45883edb8cb0e07](https://www.virustotal.com/gui/file/c7af8d1aa8f4780be45883edb8cb0e07)|Win32 EXE|Dynamer|2014-11-27 02:58:44|c7af8d1aa8f4780be45883edb8cb0e07|
|[d97e2f58687e310634994cd3c5c29844](https://www.virustotal.com/gui/file/d97e2f58687e310634994cd3c5c29844)|Win32 EXE||2014-10-29 04:30:11|815ba75ac821b7c656c9c9bc0e663f9570f71bf247e374d60f9142fcc380efad.vir|
|[ce788e585db4d417b92d8bdb345468e5](https://www.virustotal.com/gui/file/ce788e585db4d417b92d8bdb345468e5)|Win32 EXE||2014-09-27 08:23:34|WUApp.exe|
|[e5243155594c994fb11727767f6ef2d6](https://www.virustotal.com/gui/file/e5243155594c994fb11727767f6ef2d6)|Win32 EXE|Sisron|2014-09-06 23:41:34|Adobe PDF|
|[9a3677dec3d17f8d876c1f85fe3a9603](https://www.virustotal.com/gui/file/9a3677dec3d17f8d876c1f85fe3a9603)|Win32 EXE|Symmi|2014-03-19 17:45:59|flsys32.exe|
|[b1e5a284b0064758d65c5fc0e201db35](https://www.virustotal.com/gui/file/b1e5a284b0064758d65c5fc0e201db35)|Win32 EXE||2014-03-08 06:38:29|Barely Legal|
|[56cc03c421ab4d639fa3bfc2a3058ad4](https://www.virustotal.com/gui/file/56cc03c421ab4d639fa3bfc2a3058ad4)|Win32 EXE||2014-03-05 16:46:06|winsys-restore.exe|
|[27790c50a6ddc9b4835973f33d1d5371](https://www.virustotal.com/gui/file/27790c50a6ddc9b4835973f33d1d5371)|Win32 EXE||2014-02-17 17:36:38|Adobe PDF|
|[47f72949407838e0d3bfb15a275b6ef7](https://www.virustotal.com/gui/file/47f72949407838e0d3bfb15a275b6ef7)|Win32 EXE||2014-02-07 12:16:26|6a46ec0f3a3ad4f73bb5557651278588eaf62e72|
|[cab163e740e10b9572a6424e69cce1d5](https://www.virustotal.com/gui/file/cab163e740e10b9572a6424e69cce1d5)|Win32 EXE|Ursu|2020-01-06 05:45:23|Policy_update.exe|
