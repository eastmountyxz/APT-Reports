|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[e54b370d96ca0e2ecc083c2d42f05210](https://www.virustotal.com/gui/file/e54b370d96ca0e2ecc083c2d42f05210)|Win32 DLL||2019-12-03 05:13:03|C:\Users\<USER>\AppData\Roaming\Microsoft\NewACt.dat|
|[35d60d2723c649c97b414b3cb701df1c](https://www.virustotal.com/gui/file/35d60d2723c649c97b414b3cb701df1c)|Win32 EXE||2019-12-03 05:12:41|C:\Users\<USER>\AppData\Local\Temp\35d60d2723c649c97b414b3cb701df1c.exe|
|[85613007c632173c5178541e1d6b717e](https://www.virustotal.com/gui/file/85613007c632173c5178541e1d6b717e)|TXT||2019-11-20 15:06:37|%APPDATA%\roaming\microsoft\alyacmonitor.db_ini|
|[a5a96397c646fb3143c0b61564f541a7](https://www.virustotal.com/gui/file/a5a96397c646fb3143c0b61564f541a7)|FPX||2019-11-04 07:48:45|C:\Users\admin\Desktop\악성파일샘플\[spyware]UFJKE1.hwp|
|[03da25ae8b98ae05b2a18e61ebb88d08](https://www.virustotal.com/gui/file/03da25ae8b98ae05b2a18e61ebb88d08)|FPX||2019-10-30 12:20:19|김민관 부부장 토론문.hwp|
|[42ae424f27d83fa132b2967b64f6ba21](https://www.virustotal.com/gui/file/42ae424f27d83fa132b2967b64f6ba21)|FPX||2019-10-16 08:33:55|=?UTF-8?B?S0lOVSDsoITrrLjqsIAg7J6Q66y4IOyalOyyreyCrO2VrSjtlZzrr7jrj5nrp7nqs7wg7ZWc7KSR6rSA6rOEKS5od3Bf?=|
|[8d35abc4b7073015c5cd2ceab9ba3419](https://www.virustotal.com/gui/file/8d35abc4b7073015c5cd2ceab9ba3419)|FPX||2019-10-16 02:21:06|1 (5).hwp|
|[d1dfe1e10e1606b99dd7580c0cac05e8](https://www.virustotal.com/gui/file/d1dfe1e10e1606b99dd7580c0cac05e8)|FPX||2019-10-16 02:21:03|1 (4).hwp|
|[fc6f10e86e64aa349df9187c36665839](https://www.virustotal.com/gui/file/fc6f10e86e64aa349df9187c36665839)|FPX||2019-10-16 02:20:55|1 (3).hwp|
|[c8294148f1d9f268cb4d1fa5cf1c500f](https://www.virustotal.com/gui/file/c8294148f1d9f268cb4d1fa5cf1c500f)|FPX||2019-10-16 02:20:51|1 (2).hwp|
|[3562042936d0125451dde96cb4e54783](https://www.virustotal.com/gui/file/3562042936d0125451dde96cb4e54783)|FPX||2019-10-16 02:20:49|1 (1).hwp|
|[54094084273f46186ee9ac9b207fdab7](https://www.virustotal.com/gui/file/54094084273f46186ee9ac9b207fdab7)|Win32 EXE||2019-10-06 12:53:13| |
|[db6edf104261faad52291b30c19ba148](https://www.virustotal.com/gui/file/db6edf104261faad52291b30c19ba148)|Win32 DLL||2019-09-29 20:46:42|fontchk.dll|
|[5c5bf32736a852c1a1c40d0ae5b8ec33](https://www.virustotal.com/gui/file/5c5bf32736a852c1a1c40d0ae5b8ec33)|DOCM||2019-09-26 05:28:15|North_Korea.docm|
|[25998781ca4930f770eeac4aab0f9fab](https://www.virustotal.com/gui/file/25998781ca4930f770eeac4aab0f9fab)|FPX||2019-09-13 11:57:52|nopass.hwp|
|[7f52bcbb695941ebde367f45bc4d4e89](https://www.virustotal.com/gui/file/7f52bcbb695941ebde367f45bc4d4e89)|FPX||2019-08-20 05:37:49| |
|[3dca9a5b0e1623a7a816cde7de5a4183](https://www.virustotal.com/gui/file/3dca9a5b0e1623a7a816cde7de5a4183)|DOCM|o97m|2019-08-20 02:28:26|111.doc|
|[2a5755bf71c10d1b1d5fc9c8446f937f](https://www.virustotal.com/gui/file/2a5755bf71c10d1b1d5fc9c8446f937f)|DOCM|o97m|2019-08-20 00:24:49|111.doc|
|[d452e2e26ee2be4335bf16e9514f1437](https://www.virustotal.com/gui/file/d452e2e26ee2be4335bf16e9514f1437)|DOCX||2019-08-19 11:36:43|NK%20new%20SSB%20shown%20with%20Kim%20%20%2022-7-2019.docx|
|[12385fb3c5b05426c945c5928253975a](https://www.virustotal.com/gui/file/12385fb3c5b05426c945c5928253975a)|DOCM|o97m|2019-08-19 08:20:45|2.doc|
|[07e8cbcf0b6c8651db24da23816166a5](https://www.virustotal.com/gui/file/07e8cbcf0b6c8651db24da23816166a5)|FPX|o97m|2019-08-07 05:27:53| |
|[a4a0003d01d383a4ff11f5449f4be99c](https://www.virustotal.com/gui/file/a4a0003d01d383a4ff11f5449f4be99c)|DOCM|o97m|2019-08-07 02:09:24|111.doc|
|[0c6324c72c45ad8b8c2159747d30a46d](https://www.virustotal.com/gui/file/0c6324c72c45ad8b8c2159747d30a46d)|DOC|o97m|2019-08-05 06:38:18|1.doc|
|[b695d985e813b938ec8488b8632ef603](https://www.virustotal.com/gui/file/b695d985e813b938ec8488b8632ef603)|Win64 DLL||2019-08-01 15:35:56|e6d78233990eb8e1b5fc6eda2e8d507abcfc99f9f47e4f5376a0bf3796faa96d.sample|
|[838e985aef46c6b22e738a1c52c6d916](https://www.virustotal.com/gui/file/838e985aef46c6b22e738a1c52c6d916)|Win32 EXE|Konni|2019-07-23 23:33:39| |
|[e074edcf76e1228422b34d2fd75e90db](https://www.virustotal.com/gui/file/e074edcf76e1228422b34d2fd75e90db)|FPX||2019-07-23 12:19:39|vbaProject.bin|
|[3cd67d99bcc8f3b959c255c9e8702e9f](https://www.virustotal.com/gui/file/3cd67d99bcc8f3b959c255c9e8702e9f)|DOCM||2019-07-23 08:14:32|1.doc|
|[d8249f33e07479ce9c0e44be73d3deac](https://www.virustotal.com/gui/file/d8249f33e07479ce9c0e44be73d3deac)|DOCM|o97m|2019-07-23 08:13:29|1.doc|
|[0def51118a28987a929ba26c7413da29](https://www.virustotal.com/gui/file/0def51118a28987a929ba26c7413da29)|DOCM||2019-07-23 08:12:04|1.doc|
|[a6588c10d9c4c2b3837cd7ce6c43f72e](https://www.virustotal.com/gui/file/a6588c10d9c4c2b3837cd7ce6c43f72e)|DOCM||2019-07-23 08:11:09|1.doc|
|[a75196b7629e3af03056c75af37f37cf](https://www.virustotal.com/gui/file/a75196b7629e3af03056c75af37f37cf)|DOCM||2019-07-23 08:02:58|1.doc|
|[ab75a54c3d6ed01ba9478d9fecd443af](https://www.virustotal.com/gui/file/ab75a54c3d6ed01ba9478d9fecd443af)|DOCM||2019-07-23 07:56:18|1.doc|
|[b591cbd3f585dbb1b55f243d5a5982bc](https://www.virustotal.com/gui/file/b591cbd3f585dbb1b55f243d5a5982bc)|DOCM||2019-07-23 07:52:10|1.doc|
|[adb30d4dd9e1bbe82392b4c01f561e46](https://www.virustotal.com/gui/file/adb30d4dd9e1bbe82392b4c01f561e46)|DOCM||2019-07-23 07:47:15|1.doc|
|[1b2a58dcbc4ca6dddd5ad213012243b7](https://www.virustotal.com/gui/file/1b2a58dcbc4ca6dddd5ad213012243b7)|FPX|o97m|2019-06-27 01:14:06|=?UTF-8?B?7J2067Kk7Yq4IOuLueyyqOyekCDqsJzsnbjsoJXrs7Qg7IiY7KeRIOuwjyDsnbTsmqkg64+Z7J2YIOyViOuCtOyEnC5od3A=?=|
|[658a8856d48aabc0ecfeb685d836621b](https://www.virustotal.com/gui/file/658a8856d48aabc0ecfeb685d836621b)|DOCM||2019-06-20 06:26:08|doc.doc|
|[2fdff6b5d437ee118429025ca55456cf](https://www.virustotal.com/gui/file/2fdff6b5d437ee118429025ca55456cf)|FPX|o97m|2019-06-09 15:32:37|vbaProject.bin|
|[6ead104743be6575e767986a71cf4bd9](https://www.virustotal.com/gui/file/6ead104743be6575e767986a71cf4bd9)|DOCM|o97m|2019-06-09 11:58:13|1.doc|
|[2757804fa25eaf79b4b44ccf50792405](https://www.virustotal.com/gui/file/2757804fa25eaf79b4b44ccf50792405)|ZIP|o97m|2019-06-09 07:43:45|1.zip|
|[19eefb9ad7a5b8af6028f61f0e2d3f08](https://www.virustotal.com/gui/file/19eefb9ad7a5b8af6028f61f0e2d3f08)|FPX||2019-05-28 01:58:15|=?UTF-8?B?7J2067Kk7Yq4IOuLueyyqOyekCDqsJzsnbjsoJXrs7Qg7IiY7KeRIOuwjyDsnbTsmqkg64+Z7J2YIOyViOuCtOyEnC5od3A=?=|
|[147edf8b805d042a132c37f15acfe950](https://www.virustotal.com/gui/file/147edf8b805d042a132c37f15acfe950)|Email||2019-05-28 01:52:26|1234.eml|
|[75892ed0a26593b90246c0856501a74e](https://www.virustotal.com/gui/file/75892ed0a26593b90246c0856501a74e)|FPX||2019-05-19 11:12:52|=?UTF-8?B?7LC46rOg7J6Q66OMLmh3cA==?=|
|[bee7c64608ba6fc8ac19f3f1fbd99b82](https://www.virustotal.com/gui/file/bee7c64608ba6fc8ac19f3f1fbd99b82)|FPX||2019-05-02 23:49:47|=?UTF-8?B?W+uMgOyZuOu5hF3rtoHrn6zsoJXsg4Htmozri7Qg64K067aA67O06rOg7IScLmh3cA==?=|
|[f3d27c9e0af3d049af5d35c6fd81ed49](https://www.virustotal.com/gui/file/f3d27c9e0af3d049af5d35c6fd81ed49)|Win32 DLL||2019-04-28 14:46:15|33ce9bcaeb0733a77ff0d85263ce03502ac20873bf58a118d1810861caced254.sample|
|[eeff23f238742d318b1058da1ca79786](https://www.virustotal.com/gui/file/eeff23f238742d318b1058da1ca79786)|FPX||2019-04-27 13:27:46|=?UTF-8?B?67aB65+sIOygleyDge2ajOuLtCDspIDruYQg64+Z7ZalLmh3cA==?=|
|[41bdd6a38cefe28896fd417928cdde2c](https://www.virustotal.com/gui/file/41bdd6a38cefe28896fd417928cdde2c)|FPX||2019-04-27 12:27:32|a.hwp|
|[b87960ee5fd0218e4ec2b966debef99e](https://www.virustotal.com/gui/file/b87960ee5fd0218e4ec2b966debef99e)|FPX||2019-04-26 09:32:05|C:\Users\Joins\Desktop\북러 정상회담 준비 동향.hwp|
|[03dbc1b3d79a4ff70f06fd6e67e00985](https://www.virustotal.com/gui/file/03dbc1b3d79a4ff70f06fd6e67e00985)|DOCM|Banload|2019-04-09 17:00:06|75917cc1bd9ecd7ef57b7ef428107778b19f46e8c38c00f1c70efc118cb8aab5.bin|
|[03dbc1b3d79a4ff70f06fd6e67e00985](https://www.virustotal.com/gui/file/03dbc1b3d79a4ff70f06fd6e67e00985)|DOCM|Banload|2019-04-09 17:00:06|75917cc1bd9ecd7ef57b7ef428107778b19f46e8c38c00f1c70efc118cb8aab5.bin|
|[6590830061f85c0acc5259013555d079](https://www.virustotal.com/gui/file/6590830061f85c0acc5259013555d079)|Win32 EXE||2019-04-05 08:26:23| |
|[60973af3b8ecbbb0ab659124409b7df1](https://www.virustotal.com/gui/file/60973af3b8ecbbb0ab659124409b7df1)|DOCX||2019-04-03 22:44:05|Speaking notes-ExMon Deterrence Summit-24Mar-rev26Mar19.doc|
|[c71a3d526c54fee6b7d73f03a18d6b0a](https://www.virustotal.com/gui/file/c71a3d526c54fee6b7d73f03a18d6b0a)|FPX||2019-04-02 08:38:29|=?UTF-8?B?6rWt67Cp6rO87ZWZ6riw7IigIOuwjyDrsKnsnITsgrDsl4Ug7KeE7Z2l7J2EIOychO2VnCDrspXroLkg7KCV67mEIOuwqeyViC5od3A=?=|
|[68eb2acab42c69aefb8a4c266762c560](https://www.virustotal.com/gui/file/68eb2acab42c69aefb8a4c266762c560)|unknown||2019-04-02 04:45:26|68eb2acab42c69aefb8a4c266762c560.ex_|
|[d400adcd06e0a07549e2465c9c500c45](https://www.virustotal.com/gui/file/d400adcd06e0a07549e2465c9c500c45)|DOCM||2019-04-01 09:00:09|TaskForceReport.doc|
|[a0748e19b043ffe9bdf04c5d2df26689](https://www.virustotal.com/gui/file/a0748e19b043ffe9bdf04c5d2df26689)|FPX||2019-04-01 04:20:36|=?UTF-8?B?My4xNyDrr7jqta3snZgg7Y647YOA6rOkIOu5hOuwgCDqta3qsIDslYjrs7TtmozsnZguaHdw?=|
|[105a0a190a8b6ea9d719960be0438269](https://www.virustotal.com/gui/file/105a0a190a8b6ea9d719960be0438269)|unknown||2019-04-01 02:19:24|105a0a190a8b6ea9d719960be0438269.ex_|
|[2ff911b042e5d94dd78f744109851326](https://www.virustotal.com/gui/file/2ff911b042e5d94dd78f744109851326)|DOCX||2019-03-29 12:44:56|Speaking notes-ExMon Deterrence Summit-24Mar-rev26Mar19.doc|
|[aa41e4883a9c5c91cdab225a0e82d86a](https://www.virustotal.com/gui/file/aa41e4883a9c5c91cdab225a0e82d86a)|DOTM||2019-03-28 21:55:18|Normal.src|
|[c7b25ad70aa577d4f70efd5d7728d68f](https://www.virustotal.com/gui/file/c7b25ad70aa577d4f70efd5d7728d68f)|RAR|Banload|2019-03-27 15:26:21|Speaking notes-ExMon Deterrence Summit-18Mar-rev19Mar19.rar|
|[7ca1a603a7440f1031c666afbe44afc8](https://www.virustotal.com/gui/file/7ca1a603a7440f1031c666afbe44afc8)|DOCM|o97m|2019-03-26 16:13:18|Speaking notes-ExMon Deterrence Summit-24Mar-rev26Mar19.doc|
|[599ef2988141d251c3f4ce991a9b5cd2](https://www.virustotal.com/gui/file/599ef2988141d251c3f4ce991a9b5cd2)|Win32 DLL||2019-03-24 04:05:32|explorer.tmp|
|[29fbf69e72c0daac57d2cbba11bbfaa5](https://www.virustotal.com/gui/file/29fbf69e72c0daac57d2cbba11bbfaa5)|DOCM||2019-03-23 10:40:14|Schedule_.doc|
|[b74909e14e25d2e9d1452b77f9927bf6](https://www.virustotal.com/gui/file/b74909e14e25d2e9d1452b77f9927bf6)|Win32 EXE||2019-03-18 07:25:47|update.exe|
|[397ba1d0601558dfe34cd5aafaedd18e](https://www.virustotal.com/gui/file/397ba1d0601558dfe34cd5aafaedd18e)|DOCM||2019-03-17 23:02:11|xCryptoCrash_Schedule.doc|
|[10a120f573874c2af6b9172a26fdc597](https://www.virustotal.com/gui/file/10a120f573874c2af6b9172a26fdc597)|Win32 EXE||2019-03-13 00:45:58|111.scr|
|[e68b11bef48e8e88cba7e3c93fac5eab](https://www.virustotal.com/gui/file/e68b11bef48e8e88cba7e3c93fac5eab)|DOTM||2019-03-09 11:05:56| |
|[0f77143ce98d0b9f69c802789e3b1713](https://www.virustotal.com/gui/file/0f77143ce98d0b9f69c802789e3b1713)|DOCM||2019-03-05 12:39:43|Task_Force_report.doc|
|[49bac05068a79314e00c28b163889263](https://www.virustotal.com/gui/file/49bac05068a79314e00c28b163889263)|DOCM||2019-02-27 12:32:17|white_paper.doc|
|[a3f3bdfae1aef85b0006aedc52342311](https://www.virustotal.com/gui/file/a3f3bdfae1aef85b0006aedc52342311)|Win32 DLL||2019-02-21 06:11:21|631e6644bce549ce71b0c757b0423046fb60f40b00a62a2e363db2955a70c785.sample|
|[f2e936ff1977d123809d167a2a51cdeb](https://www.virustotal.com/gui/file/f2e936ff1977d123809d167a2a51cdeb)|FPX||2019-02-21 02:54:47|a.hwp|
|[4118b251c977a682ebb4993601b9a7e3](https://www.virustotal.com/gui/file/4118b251c977a682ebb4993601b9a7e3)|DOCM||2019-02-19 13:06:36|white_paper.doc|
|[f816a9c4a3415e8bae807c09e0f80b38](https://www.virustotal.com/gui/file/f816a9c4a3415e8bae807c09e0f80b38)|DOCM||2019-02-18 12:35:22|bot spec.docm|
|[60efecf4e1b5b2c580329e9afa05db15](https://www.virustotal.com/gui/file/60efecf4e1b5b2c580329e9afa05db15)|Win32 DLL||2019-02-18 00:32:43|desktop.r3u|
|[304d86463a1fff5183aacc17ef2b3730](https://www.virustotal.com/gui/file/304d86463a1fff5183aacc17ef2b3730)|DOCM||2019-02-16 01:37:36|OFT.docm|
|[57ef27823865c8f7784b0d37fd2c4aa8](https://www.virustotal.com/gui/file/57ef27823865c8f7784b0d37fd2c4aa8)|Win32 EXE||2019-02-12 02:19:09|convert|
|[cf264f9bca2f2fbcc2c1e7a4a491afec](https://www.virustotal.com/gui/file/cf264f9bca2f2fbcc2c1e7a4a491afec)|Win32 EXE||2019-02-08 06:46:25|AltcoinMiningBot.exe|
|[48d9e625ea3efbcbef3963c8714544a7](https://www.virustotal.com/gui/file/48d9e625ea3efbcbef3963c8714544a7)|FPX||2019-02-06 07:24:19|2.hwp|
|[eacd631d6acbd36542ff4349626b06a6](https://www.virustotal.com/gui/file/eacd631d6acbd36542ff4349626b06a6)|unknown||2019-02-04 14:36:08|22327047|
|[eacd631d6acbd36542ff4349626b06a6](https://www.virustotal.com/gui/file/eacd631d6acbd36542ff4349626b06a6)|unknown||2019-02-04 14:36:08|22327047|
|[f8b9ac484b82cba3f67766a7f20e588c](https://www.virustotal.com/gui/file/f8b9ac484b82cba3f67766a7f20e588c)|Text||2019-02-02 05:52:50|2.wsf|
|[f8b9ac484b82cba3f67766a7f20e588c](https://www.virustotal.com/gui/file/f8b9ac484b82cba3f67766a7f20e588c)|Text||2019-02-02 05:52:50|2.wsf|
|[12f1189bda56956ba5e6a332da5e078c](https://www.virustotal.com/gui/file/12f1189bda56956ba5e6a332da5e078c)|unknown||2019-02-01 03:30:10|22327045|
|[12f1189bda56956ba5e6a332da5e078c](https://www.virustotal.com/gui/file/12f1189bda56956ba5e6a332da5e078c)|unknown||2019-02-01 03:30:10|22327045|
|[a89eb2dbf497e21d19ba7f94afcb11b6](https://www.virustotal.com/gui/file/a89eb2dbf497e21d19ba7f94afcb11b6)|unknown||2019-01-31 14:38:30|22327041|
|[a89eb2dbf497e21d19ba7f94afcb11b6](https://www.virustotal.com/gui/file/a89eb2dbf497e21d19ba7f94afcb11b6)|unknown||2019-01-31 14:38:30|22327041|
|[74c3011b6980bea23d119822d979a364](https://www.virustotal.com/gui/file/74c3011b6980bea23d119822d979a364)|Win32 EXE||2019-01-31 07:49:36|dttcodexgigas.447f08c1fd35a517004987dcbae264cf744a5721|
|[96d8f2c61af12ea18d18e5deaaacb586](https://www.virustotal.com/gui/file/96d8f2c61af12ea18d18e5deaaacb586)|unknown||2019-01-31 05:48:14|22327046|
|[96d8f2c61af12ea18d18e5deaaacb586](https://www.virustotal.com/gui/file/96d8f2c61af12ea18d18e5deaaacb586)|unknown||2019-01-31 05:48:14|22327046|
|[b08d27a0ad17a89614f02fcbd70609d9](https://www.virustotal.com/gui/file/b08d27a0ad17a89614f02fcbd70609d9)|Win64 DLL||2019-01-30 16:16:51|myfile.exe|
|[b08d27a0ad17a89614f02fcbd70609d9](https://www.virustotal.com/gui/file/b08d27a0ad17a89614f02fcbd70609d9)|Win64 DLL||2019-01-30 16:16:51|myfile.exe|
|[de9dcc0ab3a1901ab849b8118d322df1](https://www.virustotal.com/gui/file/de9dcc0ab3a1901ab849b8118d322df1)|Win32 DLL||2019-01-30 16:16:50|kakao.a|
|[de9dcc0ab3a1901ab849b8118d322df1](https://www.virustotal.com/gui/file/de9dcc0ab3a1901ab849b8118d322df1)|Win32 DLL||2019-01-30 16:16:50|kakao.a|
|[7f3a6fa75c1a12f99f41444a15d4ae9b](https://www.virustotal.com/gui/file/7f3a6fa75c1a12f99f41444a15d4ae9b)|Win32 DLL||2019-01-30 16:16:04|Cookie.a|
|[7f3a6fa75c1a12f99f41444a15d4ae9b](https://www.virustotal.com/gui/file/7f3a6fa75c1a12f99f41444a15d4ae9b)|Win32 DLL||2019-01-30 16:16:04|Cookie.a|
|[a744b23123ae7c6fb50b54fd3bf2e38e](https://www.virustotal.com/gui/file/a744b23123ae7c6fb50b54fd3bf2e38e)|Win32 DLL|Ursu|2019-01-30 16:16:02|f.a|
|[a744b23123ae7c6fb50b54fd3bf2e38e](https://www.virustotal.com/gui/file/a744b23123ae7c6fb50b54fd3bf2e38e)|Win32 DLL|Ursu|2019-01-30 16:16:02|f.a|
|[ad2cb80af73b53345c06a3135b114a0d](https://www.virustotal.com/gui/file/ad2cb80af73b53345c06a3135b114a0d)|Win64 DLL||2019-01-30 16:15:17|myfile.exe|
|[b4909a2b4d4a59c15a5f69f5e5161aca](https://www.virustotal.com/gui/file/b4909a2b4d4a59c15a5f69f5e5161aca)|Win32 DLL||2019-01-30 16:15:17|AppContainer32.a|
|[ad2cb80af73b53345c06a3135b114a0d](https://www.virustotal.com/gui/file/ad2cb80af73b53345c06a3135b114a0d)|Win64 DLL||2019-01-30 16:15:17|myfile.exe|
|[b4909a2b4d4a59c15a5f69f5e5161aca](https://www.virustotal.com/gui/file/b4909a2b4d4a59c15a5f69f5e5161aca)|Win32 DLL||2019-01-30 16:15:17|AppContainer32.a|
|[1a6f9190e7c53cd4e9ca4532547131af](https://www.virustotal.com/gui/file/1a6f9190e7c53cd4e9ca4532547131af)|DOCM|o97m|2019-01-25 00:36:06|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/Oct_Bld_full_view.docm2.doc|
|[1a6f9190e7c53cd4e9ca4532547131af](https://www.virustotal.com/gui/file/1a6f9190e7c53cd4e9ca4532547131af)|DOCM|o97m|2019-01-25 00:36:06|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/Oct_Bld_full_view.docm2.doc|
|[093ecb712d438ab01b3f07718428dcc7](https://www.virustotal.com/gui/file/093ecb712d438ab01b3f07718428dcc7)|DOCM||2019-01-24 17:50:51|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/doc4.doc|
|[66b73fba4e47b3184edd75b0ce9cf928](https://www.virustotal.com/gui/file/66b73fba4e47b3184edd75b0ce9cf928)|Win32 DLL|occamy|2019-01-20 05:40:08|%APPDATA%\roaming\microsoft\alyacmonitor.db|
|[66b73fba4e47b3184edd75b0ce9cf928](https://www.virustotal.com/gui/file/66b73fba4e47b3184edd75b0ce9cf928)|Win32 DLL|occamy|2019-01-20 05:40:08|%APPDATA%\roaming\microsoft\alyacmonitor.db|
|[20301fdd013c836039b8cfe0d100a1d7](https://www.virustotal.com/gui/file/20301fdd013c836039b8cfe0d100a1d7)|Win32 EXE|occamy|2019-01-20 05:39:43|=?UTF-8?B?QzpcVXNlcnNcZ3JlZW53ZWJcRGVza3RvcFzspJHqta0t7Jew6rWs7J6Q66OMLmh3cCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc2Ny?=|
|[20301fdd013c836039b8cfe0d100a1d7](https://www.virustotal.com/gui/file/20301fdd013c836039b8cfe0d100a1d7)|Win32 EXE|occamy|2019-01-20 05:39:43|=?UTF-8?B?QzpcVXNlcnNcZ3JlZW53ZWJcRGVza3RvcFzspJHqta0t7Jew6rWs7J6Q66OMLmh3cCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc2Ny?=|
|[0eb739c8faf77dae0546ff447ad06038](https://www.virustotal.com/gui/file/0eb739c8faf77dae0546ff447ad06038)|Win32 EXE|sagent|2019-01-18 06:47:36|kkkkk.exe|
|[cd705902ea42d0de2a8456b055c3bb87](https://www.virustotal.com/gui/file/cd705902ea42d0de2a8456b055c3bb87)|Win32 EXE|sagent|2019-01-17 07:53:48|1.exe|
|[15de7c404993391070b0ed538528d877](https://www.virustotal.com/gui/file/15de7c404993391070b0ed538528d877)|Text||2019-01-09 22:13:35|3.wsf|
|[15de7c404993391070b0ed538528d877](https://www.virustotal.com/gui/file/15de7c404993391070b0ed538528d877)|Text||2019-01-09 22:13:35|3.wsf|
|[71ec829db01818d305552ec4ebb1c258](https://www.virustotal.com/gui/file/71ec829db01818d305552ec4ebb1c258)|Win32 DLL||2019-01-08 10:30:18|myfile.exe|
|[71ec829db01818d305552ec4ebb1c258](https://www.virustotal.com/gui/file/71ec829db01818d305552ec4ebb1c258)|Win32 DLL||2019-01-08 10:30:18|myfile.exe|
|[6106449779d453be4ae28d89f207e921](https://www.virustotal.com/gui/file/6106449779d453be4ae28d89f207e921)|Win64 DLL||2019-01-08 10:24:42| |
|[6106449779d453be4ae28d89f207e921](https://www.virustotal.com/gui/file/6106449779d453be4ae28d89f207e921)|Win64 DLL||2019-01-08 10:24:42| |
|[1dfe826f71c20ff04987a9160c177e46](https://www.virustotal.com/gui/file/1dfe826f71c20ff04987a9160c177e46)|Win32 DLL||2019-01-08 10:19:56| |
|[1dfe826f71c20ff04987a9160c177e46](https://www.virustotal.com/gui/file/1dfe826f71c20ff04987a9160c177e46)|Win32 DLL||2019-01-08 10:19:56| |
|[242c31d0ce2109fdface788663e90f49](https://www.virustotal.com/gui/file/242c31d0ce2109fdface788663e90f49)|Win32 DLL||2019-01-08 10:19:20| |
|[242c31d0ce2109fdface788663e90f49](https://www.virustotal.com/gui/file/242c31d0ce2109fdface788663e90f49)|Win32 DLL||2019-01-08 10:19:20| |
|[9d685308d3125e14287ecb7fbe5fcd37](https://www.virustotal.com/gui/file/9d685308d3125e14287ecb7fbe5fcd37)|Win32 DLL||2019-01-08 10:19:06| |
|[9d685308d3125e14287ecb7fbe5fcd37](https://www.virustotal.com/gui/file/9d685308d3125e14287ecb7fbe5fcd37)|Win32 DLL||2019-01-08 10:19:06| |
|[5df830baf8a063d5c99f6d51d12956e0](https://www.virustotal.com/gui/file/5df830baf8a063d5c99f6d51d12956e0)|Text||2019-01-08 07:51:06|brave.ct|
|[5df830baf8a063d5c99f6d51d12956e0](https://www.virustotal.com/gui/file/5df830baf8a063d5c99f6d51d12956e0)|Text||2019-01-08 07:51:06|brave.ct|
|[1f1f44a01d5784028302d6ad5e7133aa](https://www.virustotal.com/gui/file/1f1f44a01d5784028302d6ad5e7133aa)|DOCM|o97m|2019-01-08 06:44:13|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/Oct_Bld_full_view.docm.doc|
|[9c3396aa94083916227201bf1396a2ca](https://www.virustotal.com/gui/file/9c3396aa94083916227201bf1396a2ca)|Win32 EXE||2019-01-07 01:21:52|=?UTF-8?B?66+465SU7Ja0IOq2jOugpeydtOuPmeKRpS3rhLftlIzroInsiqQsIOycoO2KnOu4jC5od3AgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZXhl?=|
|[9c3396aa94083916227201bf1396a2ca](https://www.virustotal.com/gui/file/9c3396aa94083916227201bf1396a2ca)|Win32 EXE||2019-01-07 01:21:52|=?UTF-8?B?66+465SU7Ja0IOq2jOugpeydtOuPmeKRpS3rhLftlIzroInsiqQsIOycoO2KnOu4jC5od3AgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZXhl?=|
|[61f42c2dc1da18b046c6b274abe6f4ca](https://www.virustotal.com/gui/file/61f42c2dc1da18b046c6b274abe6f4ca)|Win32 EXE||2018-12-31 01:43:20|1.exe|
|[d40c20a77371309045f5123af76637b2](https://www.virustotal.com/gui/file/d40c20a77371309045f5123af76637b2)|DOCM||2018-12-26 14:11:21|RoK Trip Report BHR Dec 2018.docm|
|[9f76d2f73020064374efe67dc28fa006](https://www.virustotal.com/gui/file/9f76d2f73020064374efe67dc28fa006)|Win32 EXE||2018-12-21 08:30:28|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/1.exe|
|[056b178bbeea109d705439aa4e203d09](https://www.virustotal.com/gui/file/056b178bbeea109d705439aa4e203d09)|DOCM|o97m|2018-12-19 17:33:18|Task Force on US Policy To China HR Memo.docm.doc|
|[dfe2f5fc4579f5cb56a76702a61e692a](https://www.virustotal.com/gui/file/dfe2f5fc4579f5cb56a76702a61e692a)|FPX||2018-11-30 02:33:00|=?UTF-8?B?7Yq465+87ZSEIOKAmOu2ge2VnCDqtIDroKgg6rCA7J6lIO2emOuToCDqsrDsoJUsIOqwiOq4uCDqsIDqsqDri6TigJkuaHdw?=|
|[76e71cf45e99d03a92c8271998a1caee](https://www.virustotal.com/gui/file/76e71cf45e99d03a92c8271998a1caee)|DOCM|o97m|2018-11-28 08:02:06|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/Hamre-re-NK-deterrence-CWIR-19-Nov18.docm.doc|
|[711eb1d89764d45f4ff2622143f744c2](https://www.virustotal.com/gui/file/711eb1d89764d45f4ff2622143f744c2)|DOCM|o97m|2018-11-12 01:36:43|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/doc1.docm.doc|
|[6b116d471a787eb520869ed5c6965fa8](https://www.virustotal.com/gui/file/6b116d471a787eb520869ed5c6965fa8)|DOCM|o97m|2018-11-12 01:13:21|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/doc2.docm.doc|
|[404ab5a93767a986b47c9fec33eb8be9](https://www.virustotal.com/gui/file/404ab5a93767a986b47c9fec33eb8be9)|DOCM|o97m|2018-11-12 00:12:01|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DPRK/BabyShark/doc3.docm.doc|
|[c616893e73cfa2a5456deb578725f1e7](https://www.virustotal.com/gui/file/c616893e73cfa2a5456deb578725f1e7)|C++||2018-07-29 12:36:20|575606c03d3775cd8880c76a3ef7c014cfcab08411a01f07fc3fcb60166be50b.vir|
|[c616893e73cfa2a5456deb578725f1e7](https://www.virustotal.com/gui/file/c616893e73cfa2a5456deb578725f1e7)|C++||2018-07-29 12:36:20|575606c03d3775cd8880c76a3ef7c014cfcab08411a01f07fc3fcb60166be50b.vir|
|[7d7e34aaaa5dbc470c6bf9302b348524](https://www.virustotal.com/gui/file/7d7e34aaaa5dbc470c6bf9302b348524)|Win32 DLL||2018-07-26 10:41:20|9481b2f26f6c8a8fa6dc509f925e6da95606a5fb190c3153646357b04464505f.vir|
|[7d7e34aaaa5dbc470c6bf9302b348524](https://www.virustotal.com/gui/file/7d7e34aaaa5dbc470c6bf9302b348524)|Win32 DLL||2018-07-26 10:41:20|9481b2f26f6c8a8fa6dc509f925e6da95606a5fb190c3153646357b04464505f.vir|
|[87e00dede257d234d2558ed2ae0d7ec2](https://www.virustotal.com/gui/file/87e00dede257d234d2558ed2ae0d7ec2)|Win32 DLL|blocker|2018-07-21 16:17:59|C:\Users\hi7763\AppData\Local\svchow.dll|
|[87e00dede257d234d2558ed2ae0d7ec2](https://www.virustotal.com/gui/file/87e00dede257d234d2558ed2ae0d7ec2)|Win32 DLL|blocker|2018-07-21 16:17:59|C:\Users\hi7763\AppData\Local\svchow.dll|
|[8f9bd7a47728546405d90c00c2d6b050](https://www.virustotal.com/gui/file/8f9bd7a47728546405d90c00c2d6b050)|Text||2018-07-18 02:23:47|=?UTF-8?B?6rO17KeA7IKs7ZWtLnBuZy52YnM=?=|
|[8f9bd7a47728546405d90c00c2d6b050](https://www.virustotal.com/gui/file/8f9bd7a47728546405d90c00c2d6b050)|Text||2018-07-18 02:23:47|=?UTF-8?B?6rO17KeA7IKs7ZWtLnBuZy52YnM=?=|
|[f22db1e3ea74af791e34ad5aa0297664](https://www.virustotal.com/gui/file/f22db1e3ea74af791e34ad5aa0297664)|C++||2018-06-08 00:58:22|%APPDATA%\roaming\microsoft\windows\start menu\programs\startup\fontchk.jse|
|[f22db1e3ea74af791e34ad5aa0297664](https://www.virustotal.com/gui/file/f22db1e3ea74af791e34ad5aa0297664)|C++||2018-06-08 00:58:22|%APPDATA%\roaming\microsoft\windows\start menu\programs\startup\fontchk.jse|
|[4de21c3af64b3b605446278de92dfff4](https://www.virustotal.com/gui/file/4de21c3af64b3b605446278de92dfff4)|Win32 DLL||2018-05-25 05:01:56|core.dll.DROPPED|
|[4de21c3af64b3b605446278de92dfff4](https://www.virustotal.com/gui/file/4de21c3af64b3b605446278de92dfff4)|Win32 DLL||2018-05-25 05:01:56|core.dll.DROPPED|
|[8332be776617364c16868c1ad6b4efe7](https://www.virustotal.com/gui/file/8332be776617364c16868c1ad6b4efe7)|FPX||2018-05-23 00:52:17|D:\분석\종전선언.hwp|
|[8332be776617364c16868c1ad6b4efe7](https://www.virustotal.com/gui/file/8332be776617364c16868c1ad6b4efe7)|FPX||2018-05-23 00:52:17|D:\분석\종전선언.hwp|
|[ea5369f1b911ac3e79aa76aabd26399b](https://www.virustotal.com/gui/file/ea5369f1b911ac3e79aa76aabd26399b)|Win32 EXE||2018-04-19 06:52:30|happy.exe|
|[aea8d3002132094a58d5189a8e886cf8](https://www.virustotal.com/gui/file/aea8d3002132094a58d5189a8e886cf8)|FPX||2017-07-31 07:05:48|aea8d3002132094a58d5189a8e886cf8.virus|
|[06a3182c09badffbc1eb3e03cb985bcb](https://www.virustotal.com/gui/file/06a3182c09badffbc1eb3e03cb985bcb)|Win32 DLL||2017-07-17 08:53:10|twain.dll|
|[06a3182c09badffbc1eb3e03cb985bcb](https://www.virustotal.com/gui/file/06a3182c09badffbc1eb3e03cb985bcb)|Win32 DLL||2017-07-17 08:53:10|twain.dll|
|[ba89337af43f0b07a35cc892ac95112a](https://www.virustotal.com/gui/file/ba89337af43f0b07a35cc892ac95112a)|Win32 DLL||2017-07-16 17:35:06|ba89337af43f0b07a35cc892ac95112a|
|[874c0ec36be15fe3403f3abad6ecea75](https://www.virustotal.com/gui/file/874c0ec36be15fe3403f3abad6ecea75)|Win32 DLL||2017-06-19 01:49:46|1.dll|
|[750924d47a75cc3310a4fea02c94a1ea](https://www.virustotal.com/gui/file/750924d47a75cc3310a4fea02c94a1ea)|Win32 DLL|Bublik|2017-06-09 02:14:01|750924d47a75cc3310a4fea02c94a1ea.virus|
|[750924d47a75cc3310a4fea02c94a1ea](https://www.virustotal.com/gui/file/750924d47a75cc3310a4fea02c94a1ea)|Win32 DLL|Bublik|2017-06-09 02:14:01|750924d47a75cc3310a4fea02c94a1ea.virus|
|[b417238213efb0d2a23562674406cdf9](https://www.virustotal.com/gui/file/b417238213efb0d2a23562674406cdf9)|Win64 EXE||2016-05-23 15:02:02|NirCmd|
|[b417238213efb0d2a23562674406cdf9](https://www.virustotal.com/gui/file/b417238213efb0d2a23562674406cdf9)|Win64 EXE||2016-05-23 15:02:02|NirCmd|
|[54783422cfd7029a26a3f3f5e9087d8a](https://www.virustotal.com/gui/file/54783422cfd7029a26a3f3f5e9087d8a)|FPX||2015-09-04 09:28:44|54783422cfd7029a26a3f3f5e9087d8a.virus|
|[b02f3881321f0912b2ae3f27498c448f](https://www.virustotal.com/gui/file/b02f3881321f0912b2ae3f27498c448f)|Win32 EXE|Zbot|2014-03-25 01:00:32|wscript.exe|
|[11fc4829c2fff9fb240acbd71c60fc67](https://www.virustotal.com/gui/file/11fc4829c2fff9fb240acbd71c60fc67)|Win32 EXE||2014-03-25 00:55:23|xpsp2.exe|
|[ab73b1395938c48d62b7eeb5c9f3409d](https://www.virustotal.com/gui/file/ab73b1395938c48d62b7eeb5c9f3409d)|Win32 EXE||2013-09-11 08:44:11|Goldstager|
|[cc5afacbbdd11959c0a527e3513d21a1](https://www.virustotal.com/gui/file/cc5afacbbdd11959c0a527e3513d21a1)|DOCX|o97m|2020-04-08 09:59:26|21대 국회의원 선거 관련.docx|
|[71bbfbe21518c8a314a9137c05256a3a](https://www.virustotal.com/gui/file/71bbfbe21518c8a314a9137c05256a3a)|FPX||2020-03-30 09:37:56|71bbfbe21518c8a314a9137c05256a3a.hwp|
|[07d0be79be38ecb8c7b1c80ab0bd8344](https://www.virustotal.com/gui/file/07d0be79be38ecb8c7b1c80ab0bd8344)|DOCM|o97m|2020-03-18 01:47:59|1fcd9892532813a27537f4e1a1c21ec0c110d6b3929602750ed77bbba7caa426.bin|
|[01e64c99ee3c4256529df63f08c8ca4c](https://www.virustotal.com/gui/file/01e64c99ee3c4256529df63f08c8ca4c)|DOCM|o97m|2020-03-03 04:29:36|비건 미국무부 부장관 서신 20200302.doc|
|[5f2d3ed67a577526fcbd9a154f522cce](https://www.virustotal.com/gui/file/5f2d3ed67a577526fcbd9a154f522cce)|DOCM|o97m|2020-03-03 04:20:21|7c0f8d6cf4f908cce8b7f65f2b5ee06a311d28ee6d8f1b32e90af4d08c2ab327.bin|
|[6711f4b4f0c7e022feff0e2d5afaac59](https://www.virustotal.com/gui/file/6711f4b4f0c7e022feff0e2d5afaac59)|DOC||2019-12-19 07:01:02|out|
|[3fb0cfe3cc84fc9bb54c894e05ebbb92](https://www.virustotal.com/gui/file/3fb0cfe3cc84fc9bb54c894e05ebbb92)|FPX||2020-11-03 08:58:20|미국 대선 예측 - 미주중앙일보.hwp|
|[537b319927c0a7fbfaa0d411283069e3](https://www.virustotal.com/gui/file/537b319927c0a7fbfaa0d411283069e3)|Win64 DLL||2020-10-16 07:56:01|%ALLUSERSPROFILE%\software\estsoft\common\estcommon.dll|
|[3d235aa8f66ddeec5dc4268806c22229](https://www.virustotal.com/gui/file/3d235aa8f66ddeec5dc4268806c22229)|Win32 DLL|Nukesped|2020-10-16 07:52:21|%ALLUSERSPROFILE%\software\microsoft\windows\defender\autoupdate.dll|
|[4ba6baf75625bddc5e1bc3fd40d04b1e](https://www.virustotal.com/gui/file/4ba6baf75625bddc5e1bc3fd40d04b1e)|Android||2020-10-13 05:07:37| |
|[b30a72d5fb9c8f3358580169c60cba42](https://www.virustotal.com/gui/file/b30a72d5fb9c8f3358580169c60cba42)|Win32 EXE||2020-09-17 10:08:36|nw_exe|
|[ce8e463fefaa6634f535f5b63313d381](https://www.virustotal.com/gui/file/ce8e463fefaa6634f535f5b63313d381)|Win32 EXE||2020-08-31 23:13:32|/data/modqi/samples/sum/7fa4d0985ab3815937955768756e954d33a26c2c230399bbf0a547495764f11e|
|[ae7e565d8c3c54be4342ce63a6838796](https://www.virustotal.com/gui/file/ae7e565d8c3c54be4342ce63a6838796)|Win64 DLL|Nukesped|2020-05-19 02:10:18|ESTCommon.dll|
|[c39509c0f4ad502cdcab98f1287ba3ea](https://www.virustotal.com/gui/file/c39509c0f4ad502cdcab98f1287ba3ea)|Win32 EXE|occamy|2020-04-15 02:20:24|C:\Users\<USER>\AppData\Local\Temp\c39509c0f4ad502cdcab98f1287ba3ea.exe|
|[30f821a3738dd520f3bc879915eb72dd](https://www.virustotal.com/gui/file/30f821a3738dd520f3bc879915eb72dd)|ZIP|o97m|2020-04-08 06:40:48|21대 국회의원 선거 관련.zip|
|[027cece935454a2d535fea22baf71b57](https://www.virustotal.com/gui/file/027cece935454a2d535fea22baf71b57)|DOCX|o97m|2020-04-01 06:10:15|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\02ee67cc545bc6355c4a907e18330d95b990c6a606b95fe608b7e36e672216ae|
|[163911824defe23439237b6d460e8dad](https://www.virustotal.com/gui/file/163911824defe23439237b6d460e8dad)|HTML||2020-03-20 01:55:21|f58f748f6ed27e7e50b2bb030793404dedf1f2626d1d381d0ecbf26541b30785.bin|
|[1b6d8837c21093e4b1c92d5d98a40ed4](https://www.virustotal.com/gui/file/1b6d8837c21093e4b1c92d5d98a40ed4)|DOTM|o97m|2020-03-19 12:15:18|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\144242e42335b015145100dbaebf902df3403244921cf81402f67778959c642e|
|[a4388c4d0588cd3d8a607594347663e0](https://www.virustotal.com/gui/file/a4388c4d0588cd3d8a607594347663e0)|DOCX|o97m|2020-03-19 11:04:09|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\7d2b9f391588cc07d9ba78d652819d32d3d79e5a74086b527c32126ad88b5015|
|[9f85509f94c4c28bb2d3fd4e205de857](https://www.virustotal.com/gui/file/9f85509f94c4c28bb2d3fd4e205de857)|HTML||2020-03-03 06:39:11|85a14d9cda70bc79e5b796cc2d685c9db712f3b0f9e1c4cf83e807ce68c91290.bin|
|[ac7bb8137e14921f38fab63ab564e85a](https://www.virustotal.com/gui/file/ac7bb8137e14921f38fab63ab564e85a)|Win32 DLL||2020-02-27 19:42:18|%APPDATA%\microsoft\windows\defender\autoupdate.dll|
|[7348d1f1f1ca3b7ff25b362231365904](https://www.virustotal.com/gui/file/7348d1f1f1ca3b7ff25b362231365904)|Win64 DLL|Nukesped|2020-02-27 19:18:41|C:\Users\Administrator\AppData\Local\Temp\FBF4.tmp.db|
|[47c95f19ebd745d588bb208ff89c90ba](https://www.virustotal.com/gui/file/47c95f19ebd745d588bb208ff89c90ba)|Win32 EXE|Andromeda|2020-02-27 19:16:41|C:\Users\Administrator\AppData\Local\Temp\47c95f19ebd745d588bb208ff89c90ba.exe|
|[a9dac36efd7c99dc5ef8e1bf24c2d747](https://www.virustotal.com/gui/file/a9dac36efd7c99dc5ef8e1bf24c2d747)|DOCM|o97m|2020-02-27 08:52:50|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\2cd5f1852ac6d3ed481394ea0abc49f16789c12fb81bcdf9988762730fb0aa8f|
|[8ad471517e7457eb6eea5e3039a3334f](https://www.virustotal.com/gui/file/8ad471517e7457eb6eea5e3039a3334f)|FPX|o97m|2020-02-19 08:20:16|(첨부2)20-0206_법인_운영상황_평가표_서식(법인작성용).hwp|
|[1305506bc1777f82315412c9faf71b63](https://www.virustotal.com/gui/file/1305506bc1777f82315412c9faf71b63)|Win64 DLL|Ursu|2020-02-12 14:43:28|'IEMonitor0164'|
|[8bac633f24d21e9f88425e0d3fbaf5c5](https://www.virustotal.com/gui/file/8bac633f24d21e9f88425e0d3fbaf5c5)|Win32 DLL|Ursu|2020-02-12 14:43:28|%APPDATA%\microsoft\msofficeupdate.sd|
|[cf87475a87cb2172e73ee6afa7eb6384](https://www.virustotal.com/gui/file/cf87475a87cb2172e73ee6afa7eb6384)|Win32 EXE|occamy|2020-02-12 14:39:34|out|
|[20add5eb5fbe527a8b6090a08e7636a6](https://www.virustotal.com/gui/file/20add5eb5fbe527a8b6090a08e7636a6)|Win32 EXE|Scar|2020-02-06 08:34:48|C:\Users\<USER>\AppData\Local\Temp\20add5eb5fbe527a8b6090a08e7636a6.exe|
|[de6c38eb3859bc4d5369e5454281f875](https://www.virustotal.com/gui/file/de6c38eb3859bc4d5369e5454281f875)|TXT|sLoad|2020-01-27 16:38:35|071d5c44d21c365c13133d46b93a94bc.js|
|[dfcf6054daaf730cd70e377023537cb9](https://www.virustotal.com/gui/file/dfcf6054daaf730cd70e377023537cb9)|TXT|sLoad|2020-01-27 16:36:46|071d5c44d21c365c13133d46b93a94bc.js|
|[b409ab27db450341cf8ba586d4069f17](https://www.virustotal.com/gui/file/b409ab27db450341cf8ba586d4069f17)|TXT|sLoad|2020-01-27 06:44:13| |
|[5cbd1da5414186b538a0258fda6688d9](https://www.virustotal.com/gui/file/5cbd1da5414186b538a0258fda6688d9)|TXT|sLoad|2020-01-27 06:42:14| |
|[2ddcdf689e49d27bc18fdc9645d967bc](https://www.virustotal.com/gui/file/2ddcdf689e49d27bc18fdc9645d967bc)|TXT|sLoad|2020-01-23 00:49:28|071d5c44d21c365c13133d46b93a94bc.js|
|[033d513a6bd5f9ffad3a9a60fd8a295b](https://www.virustotal.com/gui/file/033d513a6bd5f9ffad3a9a60fd8a295b)|TXT|sLoad|2020-01-23 00:27:08|071d5c44d21c365c13133d46b93a94bc.js|
|[e3baa1677777921eaeff6821b75afb15](https://www.virustotal.com/gui/file/e3baa1677777921eaeff6821b75afb15)|TXT|sLoad|2020-01-22 19:08:54|071d5c44d21c365c13133d46b93a94bc.js|
|[9a29edd98bb9cbea56f1ac9e1a7a1599](https://www.virustotal.com/gui/file/9a29edd98bb9cbea56f1ac9e1a7a1599)|Win32 EXE||2020-01-22 12:37:49|dttcodexgigas.0f127ed88cd82db863dc08b3c55b14cd001a7297|
|[e8effd3ad2069ff8ff6344b85fc12dd6](https://www.virustotal.com/gui/file/e8effd3ad2069ff8ff6344b85fc12dd6)|Win32 EXE||2020-01-22 12:29:16|80fb33854bf54ceac731aed91c677d8fb933d1593eb95447b06bd9b80f562ed2.sample|
|[c315de8ac15b51163a3bc075063a58aa](https://www.virustotal.com/gui/file/c315de8ac15b51163a3bc075063a58aa)|Win64 DLL|Scar|2020-01-19 05:37:52|%PROGRAMDATA%\hero.dll|
|[da799d16aed24cf4f8ec62d5048afd1a](https://www.virustotal.com/gui/file/da799d16aed24cf4f8ec62d5048afd1a)|Win32 EXE|Scar|2020-01-19 05:36:23|C:\Users\<USER>\AppData\Local\Temp\da799d16aed24cf4f8ec62d5048afd1a.exe|
|[50416931926754d867c9e5f418a4d08a](https://www.virustotal.com/gui/file/50416931926754d867c9e5f418a4d08a)|DOCM|sLoad|2020-01-13 06:00:53|문정인 대통령 통일외교안보특보 미국 국익센터 세미나.doc|
|[b654f7f7d59b093baab3eec9e1636643](https://www.virustotal.com/gui/file/b654f7f7d59b093baab3eec9e1636643)|FPX||2020-01-06 04:49:58|중국 지식인들의 북한 관을 살펴보면서.hwp|
|[0a269b0053ff178e0881fde3685b65b4](https://www.virustotal.com/gui/file/0a269b0053ff178e0881fde3685b65b4)|Win32 DLL|Bublik|2019-11-17 10:00:21|0a269b0053ff178e0881fde3685b65b4.virus|
