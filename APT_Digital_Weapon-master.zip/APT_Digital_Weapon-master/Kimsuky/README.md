**NAME:**  
Kimsuky  
  
**Alias**  
Mystery Baby, Baby Coin, Smoke Screen, Kimsuky, BabyShark, Cobra Venom  

**Description**:   
The Kimsuky operators carry out ongoing cyber-espionage campaign against South Korean think-tanks. Following the intense diplomatic activity around the North Korea peace talks and the subsequent summit with the U.S. president in Singapore, Kimsuky decided to take advantage of this theme to distribute its malware in a new campaign. A massive update to its arsenal in late 2017 and early 2018 was mobilized in a new wave of spear-phishing emails.
  
**References**:  
https://securelist.com/apt-trends-report-q2-2018/86487/  
https://securelist.com/the-kimsuky-operation-a-north-korean-apt/57915/  
http://blog.alyac.co.kr/1536  
http://asec.ahnlab.com/993  
https://blog.alyac.co.kr/2243  
https://blog.alyac.co.kr/2315?category=957259  
