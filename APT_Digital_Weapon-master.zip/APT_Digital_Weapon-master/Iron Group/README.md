**NAME:**  
Iron Group  
  
**Description**:   
Iron Group is a threat actor group known for ransomware attacks in the past. Palo Alto found a new malware family tie to the Iron Group that targets Linux and Microsoft Windows servers named XBash with ransomware and coin mining capabilities.
  
**References**:  
https://researchcenter.paloaltonetworks.com/2018/09/unit42-xbash-combines-botnet-ransomware-coinmining-worm-targets-linux-windows
