|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[3b5baecd61190e12a526c51d5ecccbbe](https://www.virustotal.com/gui/file/3b5baecd61190e12a526c51d5ecccbbe)|HTML||2018-09-17 14:51:55|3b5baecd61190e12a526c51d5ecccbbe.virus|
|[3a3ae909caee915af927c29a6025d16c](https://www.virustotal.com/gui/file/3a3ae909caee915af927c29a6025d16c)|Win32 EXE|razy|2018-09-17 14:20:28|Visual Studio setup bootstrapper|
|[56303f9c9b3ec89f4a883a4d7b079f65](https://www.virustotal.com/gui/file/56303f9c9b3ec89f4a883a4d7b079f65)|ELF executable||2018-09-06 06:58:40|56303f9c9b3ec89f4a883a4d7b079f65.virus|
|[50ab7c696ca74e8ae322855d445e0613](https://www.virustotal.com/gui/file/50ab7c696ca74e8ae322855d445e0613)|bash script|shell|2018-08-30 02:13:16|VirusShare_50ab7c696ca74e8ae322855d445e0613.sh|
|[f8c7e23c71478aa99dc3627da989b2ca](https://www.virustotal.com/gui/file/f8c7e23c71478aa99dc3627da989b2ca)|ELF executable||2018-08-29 13:39:31|f8c7e23c71478aa99dc3627da989b2ca.virus|
|[a6484c6e007b1277164dd49115e5e271](https://www.virustotal.com/gui/file/a6484c6e007b1277164dd49115e5e271)|bash script|shell|2018-08-29 13:33:05|a6484c6e007b1277164dd49115e5e271.virus|
|[33357485c5c92f087bd53602d6d8a48b](https://www.virustotal.com/gui/file/33357485c5c92f087bd53602d6d8a48b)|ELF executable||2018-08-16 07:27:52|33357485c5c92f087bd53602d6d8a48b.virus|
|[601080e36cd6a757684e0996afd9a0e6](https://www.virustotal.com/gui/file/601080e36cd6a757684e0996afd9a0e6)|PNG||2018-08-07 22:20:39|601080e36cd6a757684e0996afd9a0e6.virus|
|[9d080aa27da74e146a45b56c86476f20](https://www.virustotal.com/gui/file/9d080aa27da74e146a45b56c86476f20)|bash script|shell|2018-07-20 10:56:58|9d080aa27da74e146a45b56c86476f20.virus|
|[e158c98a90cc7b14d026443cbcd8b520](https://www.virustotal.com/gui/file/e158c98a90cc7b14d026443cbcd8b520)|bash script|shell|2018-07-17 09:10:18|VirusShare_e158c98a90cc7b14d026443cbcd8b520.sh|
|[2d39b1792b263eba084e10c54e053d84](https://www.virustotal.com/gui/file/2d39b1792b263eba084e10c54e053d84)|ELF executable||2018-07-06 04:51:24|2d39b1792b263eba084e10c54e053d84.virus|
|[55142f1d393c5ba7405239f232a6c059](https://www.virustotal.com/gui/file/55142f1d393c5ba7405239f232a6c059)|ELF executable||2018-07-02 03:04:05|XbashX|
|[1ef7d145bf7153292ea33fe7c900ece9](https://www.virustotal.com/gui/file/1ef7d145bf7153292ea33fe7c900ece9)|Win64 DLL||2018-06-26 05:11:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Coinminers/msxml.exe|
|[1de7ceb3434243aa94296393165f89e7](https://www.virustotal.com/gui/file/1de7ceb3434243aa94296393165f89e7)|HTML||2018-06-12 19:14:37|1de7ceb3434243aa94296393165f89e7.virus|
|[7b5008d312465307905d96b4b8366326](https://www.virustotal.com/gui/file/7b5008d312465307905d96b4b8366326)|ELF executable||2018-06-10 02:08:40|7b5008d312465307905d96b4b8366326.virus|
