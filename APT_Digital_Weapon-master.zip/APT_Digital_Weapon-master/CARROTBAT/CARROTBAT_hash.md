|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[cfac51f1a10d6a176617ffd3a3a261cb](https://www.virustotal.com/gui/file/cfac51f1a10d6a176617ffd3a3a261cb)|Win32 DLL||2019-05-24 13:23:19|Hancom Update|
|[715051f5028dc793e06b20b4048f33a6](https://www.virustotal.com/gui/file/715051f5028dc793e06b20b4048f33a6)|DOC|o97m|2019-05-24 10:14:44|Huobi Research Weekly (Vol.62) 2019.05.13-2019.05.19.doc|
|[a9bd8c69ba5ea70002e776c9f618157b](https://www.virustotal.com/gui/file/a9bd8c69ba5ea70002e776c9f618157b)|Win32 EXE|Kryptik|2019-05-15 10:13:32|dttcodexgigas.4b9c223824ce5d08508ec1be43d57509b313b654|
|[a59dbf872d4d275415caed24f93a4d02](https://www.virustotal.com/gui/file/a59dbf872d4d275415caed24f93a4d02)|unknown||2019-05-15 07:53:56|payload_1.exe|
|[9768b1208506e7f026625be173cdb2ee](https://www.virustotal.com/gui/file/9768b1208506e7f026625be173cdb2ee)|DOC|o97m|2019-05-15 07:18:17|%TEMP%\20190513-8.doc|
|[eb800f555ad690d99d34b1a3b05f610a](https://www.virustotal.com/gui/file/eb800f555ad690d99d34b1a3b05f610a)|TXT|Kryptik|2019-05-15 07:18:17|%TEMP%\3.txt|
|[43cbadadaead6f11295bf8843bd909ed](https://www.virustotal.com/gui/file/43cbadadaead6f11295bf8843bd909ed)|Win64 EXE||2019-05-15 07:18:17|%TEMP%\sp.exe|
|[c0c007ce1a2d9fb8420c421d419f9f87](https://www.virustotal.com/gui/file/c0c007ce1a2d9fb8420c421d419f9f87)|DOC|o97m|2019-05-15 05:22:20|20190513_8.doc|
|[282f3f17d7d6dc68e220fe328adc66c5](https://www.virustotal.com/gui/file/282f3f17d7d6dc68e220fe328adc66c5)|Win32 DLL||2019-04-04 07:42:49|udpconn.dll|
|[63dc47d134d7dade7fa3e290d879eba4](https://www.virustotal.com/gui/file/63dc47d134d7dade7fa3e290d879eba4)|unknown||2019-01-24 05:53:57|dttcodexgigas.8f4cdf5aca03a075801766112f88b1154f3de186|
|[68b080cdc748e9357e75a65fba30eaa7](https://www.virustotal.com/gui/file/68b080cdc748e9357e75a65fba30eaa7)|DOC|sagent|2019-01-23 12:57:34|8da5b75b6380a41eee3a399c43dfe0d99eeefaa1fd21027a07b1ecaa4cd96fdd.bin|
|[5968b80e0567a25909273ccf3527dd83](https://www.virustotal.com/gui/file/5968b80e0567a25909273ccf3527dd83)|Win64 DLL||2019-01-22 16:15:49|compwjd.dll|
|[a5406729bf6acda782022ac5486436c3](https://www.virustotal.com/gui/file/a5406729bf6acda782022ac5486436c3)|Win64 DLL||2019-01-22 16:15:21|compvgk.dll|
|[2df5a0be61f9b09f380a3fc20945afc0](https://www.virustotal.com/gui/file/2df5a0be61f9b09f380a3fc20945afc0)|Win32 DLL|razy|2019-01-22 16:14:36|compwjd.dll|
|[46f3540f9a850d3114261e9f1c88100d](https://www.virustotal.com/gui/file/46f3540f9a850d3114261e9f1c88100d)|Win32 DLL|Konni|2019-01-22 16:13:52|compvgk.dll|
|[25dd8c4965b09df082968ad4f92ffe5f](https://www.virustotal.com/gui/file/25dd8c4965b09df082968ad4f92ffe5f)|Win32 EXE|Kryptik|2018-12-13 17:51:34|25dd8c4965b09df082968ad4f92ffe5f.virus|
|[e658b8b7136a112c62ffcc8a3b00b9a9](https://www.virustotal.com/gui/file/e658b8b7136a112c62ffcc8a3b00b9a9)|Text|Kryptik|2018-12-05 01:10:25|2.txt|
|[ff8f9a20c00d9d41836bfa4fac3244a9](https://www.virustotal.com/gui/file/ff8f9a20c00d9d41836bfa4fac3244a9)|unknown||2018-12-03 04:49:01|dttcodexgigas.9ee53e3f4273508b2d3fcdbc8b192037d8bb55c0|
|[1dcaf6c62c65b4594a27259bd8bc31ea](https://www.virustotal.com/gui/file/1dcaf6c62c65b4594a27259bd8bc31ea)|Win64 DLL||2018-12-03 01:54:30|udpconn.dll|
|[2bfbf8ce47585aa86b1ab90ff109fd57](https://www.virustotal.com/gui/file/2bfbf8ce47585aa86b1ab90ff109fd57)|DOC|o97m|2018-12-03 01:42:25|0_2bfbf8ce47585aa86b1ab90ff109fd57|
|[cf0b41063e3619b77fe3d31224603738](https://www.virustotal.com/gui/file/cf0b41063e3619b77fe3d31224603738)|Win32 EXE|Ursu|2018-11-27 21:15:29|CLI.exe|
|[0eb6090397c74327cd4d47819f724953](https://www.virustotal.com/gui/file/0eb6090397c74327cd4d47819f724953)|DOC||2018-11-10 03:04:21|요청주신 정책 관련 자료.doc|
|[967c518fc0cb561bebe9973770b136cf](https://www.virustotal.com/gui/file/967c518fc0cb561bebe9973770b136cf)|Win32 EXE||2018-10-12 03:02:59|9fa69bdc731015aa7bdd86cd311443e6f829fa27a9ba0adcd49fa773fb5e7fa9.bin|
|[7d842177155e20b7b42b0a68ba9081e3](https://www.virustotal.com/gui/file/7d842177155e20b7b42b0a68ba9081e3)|Win32 EXE||2018-09-26 12:20:38|e527ade24beacb2ef940210ba9acb21073e2b0dadcd92f1b8f6acd72b523c828.bin|
|[d896402609e63fc48c7f2433b10c1038](https://www.virustotal.com/gui/file/d896402609e63fc48c7f2433b10c1038)|Win32 EXE||2018-09-21 03:51:45|ba78f0a6ce53682942e97b5ad7ec76a2383468a8b6cd5771209812b6410f10cb.bin|
|[f2d2a2ea4654b2369378fae0b4b9574d](https://www.virustotal.com/gui/file/f2d2a2ea4654b2369378fae0b4b9574d)|Win32 EXE||2018-09-21 03:49:54|dca9bd1c2d068fc9c84a754e4dcf703629fbe2aa33a089cb50a7e33e073f5cea.bin|
|[6c13f88ff4f0deba8e39d315c2e84216](https://www.virustotal.com/gui/file/6c13f88ff4f0deba8e39d315c2e84216)|Win32 EXE||2018-09-21 03:49:33| |
|[113873536aa7ee7076d9af082dbf1d99](https://www.virustotal.com/gui/file/113873536aa7ee7076d9af082dbf1d99)|Win32 EXE||2018-09-21 03:48:25| |
|[1ba1bf1de639077f838d73ad55bf97b7](https://www.virustotal.com/gui/file/1ba1bf1de639077f838d73ad55bf97b7)|Win32 EXE||2018-09-21 03:22:02| |
|[3283d1d34d1ddf4cf2a1b0f257965398](https://www.virustotal.com/gui/file/3283d1d34d1ddf4cf2a1b0f257965398)|Win32 EXE||2018-09-20 04:59:39|3283d1d34d1ddf4cf2a1b0f257965398.virus|
|[f38d61237d4ecfb87b58cfcd4fd9dd44](https://www.virustotal.com/gui/file/f38d61237d4ecfb87b58cfcd4fd9dd44)|Win32 EXE||2018-09-20 04:55:03|f38d61237d4ecfb87b58cfcd4fd9dd44.virus|
|[d324c31337f307fbf745d95d763f7ec7](https://www.virustotal.com/gui/file/d324c31337f307fbf745d95d763f7ec7)|Win32 EXE||2018-09-20 04:46:17|d324c31337f307fbf745d95d763f7ec7.virus|
|[4d0786dbc8693199f7a32cd306058573](https://www.virustotal.com/gui/file/4d0786dbc8693199f7a32cd306058573)|Win32 EXE||2018-09-20 04:40:51|4D0786DBC8693199F7A32CD306058573.EXE|
|[ec6558e404f199c369d074f0d35b3334](https://www.virustotal.com/gui/file/ec6558e404f199c369d074f0d35b3334)|Win32 DLL||2018-09-19 18:31:43|.|
|[268fb8da9c7d4c18d0ea1e9a3cbbc449](https://www.virustotal.com/gui/file/268fb8da9c7d4c18d0ea1e9a3cbbc449)|Win32 EXE||2018-09-16 05:29:26|268fb8da9c7d4c18d0ea1e9a3cbbc449.virus|
|[bdfba59df2ac091ffcc2d237d9e5f824](https://www.virustotal.com/gui/file/bdfba59df2ac091ffcc2d237d9e5f824)|Win32 EXE||2018-09-16 01:11:04| |
|[c2c2a8e9c5b8298d77a225bf3476b7ae](https://www.virustotal.com/gui/file/c2c2a8e9c5b8298d77a225bf3476b7ae)|Win32 EXE||2018-09-15 09:09:02|c2c2a8e9c5b8298d77a225bf3476b7ae.virus|
|[3e4015366126dcdbdcc8b5c508a6d25c](https://www.virustotal.com/gui/file/3e4015366126dcdbdcc8b5c508a6d25c)|Win32 EXE|Konni|2018-09-13 04:46:40| |
|[dabccfdd50e593a8cb961a39296f0edf](https://www.virustotal.com/gui/file/dabccfdd50e593a8cb961a39296f0edf)|Win32 EXE||2018-09-07 04:33:57|7d443434c302431734caf1d034c054ad80493c4c703d5aaeafa4a931a496b2ae.bin|
|[eb459b47be479b61375d7b3c7c568425](https://www.virustotal.com/gui/file/eb459b47be479b61375d7b3c7c568425)|Win64 EXE||2018-09-02 04:36:16|eb459b47be479b61375d7b3c7c568425.virus|
|[4c17ecd10146e7fb4cbc3b35b037d7b5](https://www.virustotal.com/gui/file/4c17ecd10146e7fb4cbc3b35b037d7b5)|Win64 DLL|starter|2018-09-01 04:53:03|4c17ecd10146e7fb4cbc3b35b037d7b5.virus|
|[2730e5e390cb1f579e73911edf91b04b](https://www.virustotal.com/gui/file/2730e5e390cb1f579e73911edf91b04b)|DOC||2018-08-30 08:34:31|Pompeo tells China continued North Korea sanctions enforcement needed.doc|
|[6c7f74eac286d11db696ed334cd367d6](https://www.virustotal.com/gui/file/6c7f74eac286d11db696ed334cd367d6)|Win32 EXE||2018-08-18 09:50:00| |
|[db3e7c45d37a9bc6719fd7acf78d72ac](https://www.virustotal.com/gui/file/db3e7c45d37a9bc6719fd7acf78d72ac)|Win64 EXE||2018-08-02 04:06:07| |
|[468f0d5e987430384e4e8220df2e8584](https://www.virustotal.com/gui/file/468f0d5e987430384e4e8220df2e8584)|DOC||2018-08-01 07:53:13|article.doc|
|[3483b332f47b0df8cfa2cd97120d9ab8](https://www.virustotal.com/gui/file/3483b332f47b0df8cfa2cd97120d9ab8)|Win64 EXE||2018-07-22 16:10:08| |
|[197dc4c92d7ebf2fc825cb617d78338f](https://www.virustotal.com/gui/file/197dc4c92d7ebf2fc825cb617d78338f)|Win64 DLL||2018-06-21 23:53:55|2f84398d72a1c247a1c1674627c4c3cc.tmp|
|[5d7e4700e293870ff438659bcc0d6cb2](https://www.virustotal.com/gui/file/5d7e4700e293870ff438659bcc0d6cb2)|Win32 EXE||2018-06-19 01:17:31|document|
|[f8ea94c4c7502fd82bf5ee485a8ec5e3](https://www.virustotal.com/gui/file/f8ea94c4c7502fd82bf5ee485a8ec5e3)|Win32 EXE||2018-06-11 16:24:29|document|
|[af1e9ce5fac9180dd8eb8f21b13da9e8](https://www.virustotal.com/gui/file/af1e9ce5fac9180dd8eb8f21b13da9e8)|Win32 EXE||2018-06-11 16:16:49|document|
|[fb42ddf48bc581fb9aa8d13f1e4636d1](https://www.virustotal.com/gui/file/fb42ddf48bc581fb9aa8d13f1e4636d1)|Win64 EXE||2018-05-31 16:45:34|8b6b4a0e0945c6daf3ebc8870e3bd37e54751f95162232d85dc0a0cc8bead9aa.bin|
|[dc4b68285265cdf9890e6396253d8509](https://www.virustotal.com/gui/file/dc4b68285265cdf9890e6396253d8509)|Win64 EXE||2018-05-31 16:37:13| |
|[2614bd5b8177ef93efaa9b06beda2398](https://www.virustotal.com/gui/file/2614bd5b8177ef93efaa9b06beda2398)|DOC||2018-04-14 09:15:09|_확인 자료.doc|
