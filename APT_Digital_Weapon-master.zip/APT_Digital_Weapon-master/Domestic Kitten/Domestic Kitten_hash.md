|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[470de3ae73f0cc51036c1b929a29d687](https://www.virustotal.com/gui/file/470de3ae73f0cc51036c1b929a29d687)|DEX||2019-09-01 10:59:05| |
|[219a0f97ff2e6b13ef289772cc495113](https://www.virustotal.com/gui/file/219a0f97ff2e6b13ef289772cc495113)|DEX||2019-09-01 10:58:34| |
|[316080748ea3dc878d59f55af9e1070d](https://www.virustotal.com/gui/file/316080748ea3dc878d59f55af9e1070d)|DEX||2019-09-01 10:58:33| |
|[ac32ffaa379aed78dcc11ea74fbdfcfe](https://www.virustotal.com/gui/file/ac32ffaa379aed78dcc11ea74fbdfcfe)|Android||2019-08-31 23:45:05|کوروش بزرگ 4.5.8.apk|
|[50a9624b74624f99284b417b732b82af](https://www.virustotal.com/gui/file/50a9624b74624f99284b417b732b82af)|Android||2019-08-31 23:44:53|شاهنامه فردوسی.apk|
|[e94ed62a28a9fd6f714c3e29b3636788](https://www.virustotal.com/gui/file/e94ed62a28a9fd6f714c3e29b3636788)|Android||2019-08-31 23:44:18|بانو مریم رجوی.apk|
|[ad2c4e777ec787f044d006b0b7387fc7](https://www.virustotal.com/gui/file/ad2c4e777ec787f044d006b0b7387fc7)|7ZIP||2019-08-31 19:09:41|=?UTF-8?B?2KjYsdin24wgICDahtqpLjd6?=|
|[235b010b14ed607b76c6b98fcf0c3086](https://www.virustotal.com/gui/file/235b010b14ed607b76c6b98fcf0c3086)|Android|program|2019-08-31 16:02:29| |
|[12bea094932da9fa51853740fcaa68a1](https://www.virustotal.com/gui/file/12bea094932da9fa51853740fcaa68a1)|Android||2019-08-31 08:01:47|=?UTF-8?B?2LPZh9ix2KfYqCDYs9m+2YfYsduMIDMuMi5hcGs=?=|
|[25a65cbfc9d34f5367acb5ea2a32e3ef](https://www.virustotal.com/gui/file/25a65cbfc9d34f5367acb5ea2a32e3ef)|Android||2019-08-27 15:43:01|=?UTF-8?B?2LnZhdixINmB2KfYsdmI2YIuYXBr?=|
|[86da3a7378e17b51ba83ba3333e86a32](https://www.virustotal.com/gui/file/86da3a7378e17b51ba83ba3333e86a32)|Android||2019-08-25 02:20:24|86da3a7378e17b51ba83ba3333e86a32.virus|
|[9d3ca081e7fe27e44707d8634c22fc95](https://www.virustotal.com/gui/file/9d3ca081e7fe27e44707d8634c22fc95)|Android||2019-07-28 02:20:27|9d3ca081e7fe27e44707d8634c22fc95.virus|
|[4567824a45a818bc389d7eeae3c7b678](https://www.virustotal.com/gui/file/4567824a45a818bc389d7eeae3c7b678)|Android||2019-07-18 02:20:45|4567824a45a818bc389d7eeae3c7b678.virus|
|[cc88f21406eaeed70a890f53e57c98b6](https://www.virustotal.com/gui/file/cc88f21406eaeed70a890f53e57c98b6)|Android||2019-06-11 14:02:10|=?UTF-8?B?2LXZiNixINi02YfYsSDYsdmF2LbYp9mGIDEuMS5hcGs=?=|
|[fbd0afe5bd3d0d61feb21680b304d7ae](https://www.virustotal.com/gui/file/fbd0afe5bd3d0d61feb21680b304d7ae)|Android||2019-06-10 12:42:31|=?UTF-8?B?2YbYr9in2Kbbktit2YIg2KfZhtqI2LHYp9im24zaiCDYp9uM2b7ZhNuM2qnbjNi02YYuYXBr?=|
|[81281261132fba4c8ec70322250965b7](https://www.virustotal.com/gui/file/81281261132fba4c8ec70322250965b7)|Android||2019-05-09 10:39:16|nasimhagh(azaan Sunni).apk|
|[8bccbae2f4533a0a0faffd56fc1c9027](https://www.virustotal.com/gui/file/8bccbae2f4533a0a0faffd56fc1c9027)|Android||2019-04-30 18:18:04|ابو سعيد.apk|
|[5698d86c6b6b391350c8052a8f0b0782](https://www.virustotal.com/gui/file/5698d86c6b6b391350c8052a8f0b0782)|Android||2019-04-14 15:02:51|5_6165725226161143926.apk|
|[96c879435be742de467dbf90e2107e38](https://www.virustotal.com/gui/file/96c879435be742de467dbf90e2107e38)|Android||2019-03-30 21:40:56|Sahih Farsi2.apk|
|[43bd113a0952172bcba57055f5a707bb](https://www.virustotal.com/gui/file/43bd113a0952172bcba57055f5a707bb)|Android||2019-01-27 08:39:52|=?UTF-8?B?2YHYsduM2K/ZiNmGINmF2LTbjNix24wgMy4zLmFwaw==?=|
|[d199c202beb4380e2f675e93c36cf0f4](https://www.virustotal.com/gui/file/d199c202beb4380e2f675e93c36cf0f4)|Android||2019-01-27 08:38:48|=?UTF-8?B?2LPZh9ix2KfYqCDYs9m+2YfYsduMIDMuMi5hcGs=?=|
|[e2e5867dd22b2c9a875b24c48f931af8](https://www.virustotal.com/gui/file/e2e5867dd22b2c9a875b24c48f931af8)|Android||2018-12-10 18:33:46|.|
|[34be434996b9bc19112f875f0a3711d2](https://www.virustotal.com/gui/file/34be434996b9bc19112f875f0a3711d2)|Android||2018-10-23 16:27:13|34be434996b9bc19112f875f0a3711d2.virus|
|[97beeed9d767119846b227d8a280e27c](https://www.virustotal.com/gui/file/97beeed9d767119846b227d8a280e27c)|Android||2018-10-12 16:10:33| |
|[05eaa04bc27db3af51215d68a1d32d05](https://www.virustotal.com/gui/file/05eaa04bc27db3af51215d68a1d32d05)|Android||2018-10-07 07:46:30|Exotic Flowers 1.2.apk|
|[e272df5c9abd7d4c03982bb506922428](https://www.virustotal.com/gui/file/e272df5c9abd7d4c03982bb506922428)|Android||2018-08-29 21:44:16|=?UTF-8?B?2K/ZiNmE2Kkg2K7ZhNin2YHYqSDYp9mE2KfYs9mE2KfZhduM2KkuYXBr?=|
|[fd735cfab42437334d20309584663c57](https://www.virustotal.com/gui/file/fd735cfab42437334d20309584663c57)|Android||2018-08-29 08:32:07|ANFPISHMARGAKURDRASAN.apk|
|[d0a155f29034dd913fdcf2b1631b2805](https://www.virustotal.com/gui/file/d0a155f29034dd913fdcf2b1631b2805)|Android|monitor|2018-08-29 07:58:55|ANFKURDICHAT2000.apk|
|[10c9ff8200b6f9233f36323609c47fc2](https://www.virustotal.com/gui/file/10c9ff8200b6f9233f36323609c47fc2)|Android||2018-08-25 08:36:03|/home/ubuntu/site_disks/jsa.live/files/21682490.apk|
|[3c0011dd7f6c9474cda5ffd52415d4a8](https://www.virustotal.com/gui/file/3c0011dd7f6c9474cda5ffd52415d4a8)|Android||2018-04-24 23:57:46|BOOK%200.apk|
|[2a0394da1639aab6b9fea26c93eebe07](https://www.virustotal.com/gui/file/2a0394da1639aab6b9fea26c93eebe07)|Android||2018-04-21 11:31:43|/1/3/5/3547224113e8a2f5e8eedbc46494769adf750962507a5a2cf153ebfe391b1350.file|
|[8607e6328cbd970bc87d63fdf53c5e1b](https://www.virustotal.com/gui/file/8607e6328cbd970bc87d63fdf53c5e1b)|Android||2018-04-04 02:52:35|8607e6328cbd970bc87d63fdf53c5e1b.virus|
|[4134cb97b2446654347ab2e1ca2c050f](https://www.virustotal.com/gui/file/4134cb97b2446654347ab2e1ca2c050f)|Android||2017-08-08 10:36:51|بلوچ بلوچستان.apk|
|[26f655d19358ba5c124bbb705c3778a7](https://www.virustotal.com/gui/file/26f655d19358ba5c124bbb705c3778a7)|Android||2017-04-19 14:47:11|/1/4/5/45ab522d313f52e5521c8675a8427e7671f096a6296a73a877d709049e4ed074.file|
|[59c11c8bb4ec4db662d29ab095f6b3e1](https://www.virustotal.com/gui/file/59c11c8bb4ec4db662d29ab095f6b3e1)|Android||2017-04-15 19:02:05|/1/9/5/953c2ce6cc1f013cb9de527a28f8068f4a5c6dabab07701b139dfa661904a8db.file|
|[8e53166ffb47300d9b2401cfe2e07022](https://www.virustotal.com/gui/file/8e53166ffb47300d9b2401cfe2e07022)|Android|bitrep|2017-04-13 19:01:11|/1/3/1/319c499932badf0b51fa4401d6cdc97b3a677299ebb2c80e53078ae1b5ca236f.file|
|[b6d16b6d40dfec8bfbb8925bf30cc6db](https://www.virustotal.com/gui/file/b6d16b6d40dfec8bfbb8925bf30cc6db)|Android||2017-03-26 02:17:05|/1/7/6/76332cd87db67c15f536a911a4a58d5bf4e1130655dcfa00f2a6273ad315626d.file|
