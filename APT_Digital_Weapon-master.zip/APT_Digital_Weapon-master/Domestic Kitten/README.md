**NAME:**  
Domestic Kitten  
 
**Description**:   
Domestic Kitten is an Iranian Surveillance Operation that has been taking place since 2016 and, until now, has remained under the radar due to the artful deception of its attackers towards their targets.
Through the use of mobile applications, those behind the attack use fake decoy content to entice their victims to download such applications, which are in fact loaded with spyware to steal sensitive information. Interestingly, these targets include Kurdish and Turkish natives and ISIS supporters. All these targets are actually Iranians citizens.
The malware collects data including contact lists stored on the victim’s mobile device, phone call records, SMS messages, browser history and bookmarks, geo-location of the victim, photos, surrounding voice recordings and more

  
**References**:  
https://research.checkpoint.com/domestic-kitten-an-iranian-surveillance-operation/ 