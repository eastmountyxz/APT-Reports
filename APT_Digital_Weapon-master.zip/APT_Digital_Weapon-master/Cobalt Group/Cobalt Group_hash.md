|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[fce9fcd5fa337d020bd6758008221b81](https://www.virustotal.com/gui/file/fce9fcd5fa337d020bd6758008221b81)|unknown||2019-12-20 07:52:00|attachment20191222-2070-1nnm3ql.vhd|
|[6ec0edd1889897ff9b4673600f40f92f](https://www.virustotal.com/gui/file/6ec0edd1889897ff9b4673600f40f92f)|Win32 EXE||2019-12-20 07:29:38|Statement.scr|
|[600154fcb03e775f007ef7b1547b169c](https://www.virustotal.com/gui/file/600154fcb03e775f007ef7b1547b169c)|Win32 EXE||2019-12-20 07:24:54|Documents.scr|
|[72497130c829430d247a3c7a8143df92](https://www.virustotal.com/gui/file/72497130c829430d247a3c7a8143df92)|PDF||2019-12-06 22:23:28|onedrive.pdf|
|[f8c29e77db2b1ed69d7eb04552291058](https://www.virustotal.com/gui/file/f8c29e77db2b1ed69d7eb04552291058)|Win32 EXE||2019-12-06 16:48:58|notepad.exe|
|[6d55252fad0207756c671de8d5f97e7f](https://www.virustotal.com/gui/file/6d55252fad0207756c671de8d5f97e7f)|RTF||2019-12-06 07:31:56|Documents.rtf|
|[8510cf9a962d813e368f79c28cb4be9d](https://www.virustotal.com/gui/file/8510cf9a962d813e368f79c28cb4be9d)|Win32 EXE||2019-12-05 01:30:16|winlogon.exe|
|[44edea7af0276d3b7426ad6bb9ec0c12](https://www.virustotal.com/gui/file/44edea7af0276d3b7426ad6bb9ec0c12)|DOCX||2019-11-22 03:31:24|output.docx|
|[9a723a58130313a40d764a4f7787cc71](https://www.virustotal.com/gui/file/9a723a58130313a40d764a4f7787cc71)|DOC||2019-11-22 02:37:10|SWIFT MT101.doc|
|[f64e5fb92d4e57a091ec78665db34d43](https://www.virustotal.com/gui/file/f64e5fb92d4e57a091ec78665db34d43)|Win32 EXE||2019-11-22 00:00:35|9f3e650e5e69afcfeff0f776f721ce992100a2227ad968599e0b5b289146a12d.sample|
|[553280fa1bb530bf1e6311f6c24a7266](https://www.virustotal.com/gui/file/553280fa1bb530bf1e6311f6c24a7266)|FPX||2019-11-21 11:57:57|Запрос по акционерам.docx|
|[f13ee2d1408a4b0566a8eb0186aa51d2](https://www.virustotal.com/gui/file/f13ee2d1408a4b0566a8eb0186aa51d2)|Win32 EXE||2019-11-21 10:12:22|Screenshoot_21_11_19.scr|
|[7d339ee10e6561f1fb9de3ab05dd4fb8](https://www.virustotal.com/gui/file/7d339ee10e6561f1fb9de3ab05dd4fb8)|Win32 EXE||2019-11-11 08:24:50|admin32.exe|
|[b372fd09864d839112b79b7f0675f7df](https://www.virustotal.com/gui/file/b372fd09864d839112b79b7f0675f7df)|Win32 EXE||2019-11-01 20:04:21|putty.exe|
|[85df6688b4b533781075350ba193eb76](https://www.virustotal.com/gui/file/85df6688b4b533781075350ba193eb76)|RTF||2019-10-22 11:17:25|решение.rtf|
|[ed1c36673c90a5b041e2078ad4f2e520](https://www.virustotal.com/gui/file/ed1c36673c90a5b041e2078ad4f2e520)|Win32 EXE||2019-10-21 18:36:01|file.exe|
|[56a96172dd606a5d0d1ba735c9bc2f12](https://www.virustotal.com/gui/file/56a96172dd606a5d0d1ba735c9bc2f12)|Win32 EXE||2019-10-17 13:00:56|dllhost.exe|
|[0ae698795cf4f1799c08e377f8a40310](https://www.virustotal.com/gui/file/0ae698795cf4f1799c08e377f8a40310)|Win32 EXE||2019-10-17 07:24:08|screenshot_17_10_2019.scr|
|[6ef835a8ac1cc70d4b478c7c45efa5db](https://www.virustotal.com/gui/file/6ef835a8ac1cc70d4b478c7c45efa5db)|Win32 EXE||2019-10-15 12:51:40|avatar.hlpv|
|[8e8e7b25a0df0dfed26d726cb1c01567](https://www.virustotal.com/gui/file/8e8e7b25a0df0dfed26d726cb1c01567)|DOC||2019-10-15 09:36:35|PFD-19-010.doc|
|[75d8cb1292c25e10fa189f1af69b4413](https://www.virustotal.com/gui/file/75d8cb1292c25e10fa189f1af69b4413)|Win32 EXE||2019-10-04 13:24:30|avatar.hlpv|
|[32955a8252db8eb1c1e9cb155e67d375](https://www.virustotal.com/gui/file/32955a8252db8eb1c1e9cb155e67d375)|Win32 EXE||2019-10-02 17:31:33|avatar.hlpv|
|[406451a97cc4f963ecfe25aa9f813d43](https://www.virustotal.com/gui/file/406451a97cc4f963ecfe25aa9f813d43)|Win32 EXE||2019-09-27 00:30:23|dwm.exe|
|[8204a65766523bb0fd42585dc0cdc24f](https://www.virustotal.com/gui/file/8204a65766523bb0fd42585dc0cdc24f)|TXT||2019-08-23 14:53:08|1.ps1|
|[111d0a38dcdb3f7df6f528cfcf3b726b](https://www.virustotal.com/gui/file/111d0a38dcdb3f7df6f528cfcf3b726b)|LNK||2019-08-23 14:36:41|mySWIFT.txt.lnk|
|[da54fd035f0edb62c45cf1f58cebbeed](https://www.virustotal.com/gui/file/da54fd035f0edb62c45cf1f58cebbeed)|unknown||2019-08-23 13:33:17|Login_Details.img|
|[a26722fc7e5882b5a273239cddfe755f](https://www.virustotal.com/gui/file/a26722fc7e5882b5a273239cddfe755f)|Win32 EXE|Kryptik|2019-05-28 11:41:32|payload_1.exe|
|[7f0f3689b728d12a00ca258c688bf034](https://www.virustotal.com/gui/file/7f0f3689b728d12a00ca258c688bf034)|DOCM|o97m|2019-05-28 09:22:46|T47188445.doc|
|[09a2d195d39df6231b1b41458fead2ab](https://www.virustotal.com/gui/file/09a2d195d39df6231b1b41458fead2ab)|RTF|CVE-2017-8570|2018-10-30 12:02:06|/data/cfs/malshare/09a2d195d39df6231b1b41458fead2ab|
|[44508daddb1e5bc0f853e0f8223fa309](https://www.virustotal.com/gui/file/44508daddb1e5bc0f853e0f8223fa309)|Win32 EXE|Zbot|2018-10-30 07:03:05|/var/vb100/rep_file_pool///000219/9011/44508daddb1e5bc0f853e0f8223fa309|
|[bf4004c1181386d77ef0db0dc5f6e574](https://www.virustotal.com/gui/file/bf4004c1181386d77ef0db0dc5f6e574)|PDF||2018-10-18 07:59:03|myfile.exe|
|[63ada2e84d1426c582fc48a7006b4202](https://www.virustotal.com/gui/file/63ada2e84d1426c582fc48a7006b4202)|DOC|o97m|2018-10-17 15:15:26|Doc102018.doc|
|[e9a335cd86f18ae60eb852e014fbec07](https://www.virustotal.com/gui/file/e9a335cd86f18ae60eb852e014fbec07)|FPX|Banload|2018-10-17 01:12:27|Confirmations on October 16 2018  (46.9 KB).msg|
|[2659b2c4ef4736ed0a5c6e4c9553f420](https://www.virustotal.com/gui/file/2659b2c4ef4736ed0a5c6e4c9553f420)|FPX|Banload|2018-10-17 01:02:57|phisingemail.msg|
|[aff7431e666a2849d1000d0212c9dca2](https://www.virustotal.com/gui/file/aff7431e666a2849d1000d0212c9dca2)|DOC||2018-10-16 18:20:15| |
|[49a64838968e596db7b80d5cbbe025c4](https://www.virustotal.com/gui/file/49a64838968e596db7b80d5cbbe025c4)|DOC||2018-10-16 17:56:22|/data/cfs/malshare/49a64838968e596db7b80d5cbbe025c4|
|[075e462ff078e883b7d59e29950640c4](https://www.virustotal.com/gui/file/075e462ff078e883b7d59e29950640c4)|FPX|Banload|2018-10-16 13:23:59|Confirmations on October 16 2018 .msg|
|[136de83fe46061fc24359b662f8cc6e6](https://www.virustotal.com/gui/file/136de83fe46061fc24359b662f8cc6e6)|FPX||2018-10-16 07:56:29|Confirmations on October 16 2018 .msg|
|[92d66a5f165c57fe24e23dfe526da0bf](https://www.virustotal.com/gui/file/92d66a5f165c57fe24e23dfe526da0bf)|DOC||2018-10-16 07:54:51|/data/cfs/malshare/92d66a5f165c57fe24e23dfe526da0bf|
|[33970523d9c40fc59fdd8d98a4b7fa43](https://www.virustotal.com/gui/file/33970523d9c40fc59fdd8d98a4b7fa43)|PDF|Banload|2018-10-16 06:39:49|Remittance_final_settlements_citi.pdf|
|[97810210cc93244ef8117907752ee922](https://www.virustotal.com/gui/file/97810210cc93244ef8117907752ee922)|DOC|o97m|2018-10-15 17:11:13|test|
|[4a60fcc9188fd4c571f73f263973bd91](https://www.virustotal.com/gui/file/4a60fcc9188fd4c571f73f263973bd91)|DOC||2018-10-12 03:20:04|Document082018.doc|
|[1ded730be82850f1a78304be76ac7f4f](https://www.virustotal.com/gui/file/1ded730be82850f1a78304be76ac7f4f)|DOC|o97m|2018-10-09 16:56:09|/data/cfs/malshare/1ded730be82850f1a78304be76ac7f4f|
|[471a89249fadd4bf0c28941ac29b6815](https://www.virustotal.com/gui/file/471a89249fadd4bf0c28941ac29b6815)|DOC||2018-10-09 02:46:58|VirusShare_471a89249fadd4bf0c28941ac29b6815|
|[1ca60c0dd514d53946d2b777793daa1a](https://www.virustotal.com/gui/file/1ca60c0dd514d53946d2b777793daa1a)|DOC|o97m|2018-10-08 14:54:58|/data/cfs/malshare/1ca60c0dd514d53946d2b777793daa1a|
|[1e51b38c8eae14c74c21cb6e51b45219](https://www.virustotal.com/gui/file/1e51b38c8eae14c74c21cb6e51b45219)|PDF|phishing|2018-10-08 14:54:05|myfile.exe|
|[514965bee82ce1c708966e4af4e58540](https://www.virustotal.com/gui/file/514965bee82ce1c708966e4af4e58540)|PDF||2018-09-24 12:55:59|/data/cfs/malshare/514965bee82ce1c708966e4af4e58540|
|[b0684e4a309bcfa6e7bd6b0c633b78b7](https://www.virustotal.com/gui/file/b0684e4a309bcfa6e7bd6b0c633b78b7)|DOC||2018-09-24 05:59:00|/data/cfs/malshare/b0684e4a309bcfa6e7bd6b0c633b78b7|
|[85fe6932218236db4dbf9bedbf9a9dd6](https://www.virustotal.com/gui/file/85fe6932218236db4dbf9bedbf9a9dd6)|PDF||2018-09-24 04:50:06|myfile.exe|
|[d1e4e2845046554f5e4b215e600bdac3](https://www.virustotal.com/gui/file/d1e4e2845046554f5e4b215e600bdac3)|PDF||2018-09-21 15:35:10|Proof of payment 19.09.2018 A.pdf|
|[1936e6bcaf88c17b0e6cbe5149e19de7](https://www.virustotal.com/gui/file/1936e6bcaf88c17b0e6cbe5149e19de7)|PDF||2018-09-21 13:48:39|Proof of payment 19.09.2018 A.pdf|
|[f7fa36050c9ff62d5adbeb9d4b8b502b](https://www.virustotal.com/gui/file/f7fa36050c9ff62d5adbeb9d4b8b502b)|PDF||2018-09-21 12:20:52|Proof of payment 19.09.2018.pdf|
|[0483948841eff7c23fd8930ace8bfff9](https://www.virustotal.com/gui/file/0483948841eff7c23fd8930ace8bfff9)|PDF|phishing|2018-09-18 02:20:34|Query _S-170526-005399.pdf|
|[92541446cb5163d4c5fbf3b34c6fb180](https://www.virustotal.com/gui/file/92541446cb5163d4c5fbf3b34c6fb180)|PDF||2018-09-17 12:11:21|/data/cfs/malshare/92541446cb5163d4c5fbf3b34c6fb180|
|[10250b373378217fe919f6b9dba2fd52](https://www.virustotal.com/gui/file/10250b373378217fe919f6b9dba2fd52)|PDF|Banload|2018-09-16 01:22:51|TT_SWTARC_S-180521-000080.pdf|
|[599a10daf86f88dd2ed6151399aabce6](https://www.virustotal.com/gui/file/599a10daf86f88dd2ed6151399aabce6)|PDF||2018-09-15 08:46:56|TT_SWTARC_S-180521-000080.pdf|
|[87d2d108b6083cf4cf3a470287dfe6e1](https://www.virustotal.com/gui/file/87d2d108b6083cf4cf3a470287dfe6e1)|PDF|Banload|2018-09-14 18:14:55|myfile.exe|
|[9da89a3c06b501fe1dec98009489be4e](https://www.virustotal.com/gui/file/9da89a3c06b501fe1dec98009489be4e)|DOC|o97m|2018-09-14 11:19:02|Document092018.doc|
|[46b6f3d23ec4a07e7a56b537a2fd8fa5](https://www.virustotal.com/gui/file/46b6f3d23ec4a07e7a56b537a2fd8fa5)|PDF||2018-09-14 10:56:09|TT_SWTARC_S-180521-000080.pdf|
|[0e01a700ab4255045e3d29c1fd977600](https://www.virustotal.com/gui/file/0e01a700ab4255045e3d29c1fd977600)|Win32 DLL||2018-09-10 18:18:26|myfile.exe|
|[ec9d45b695f98bfbf3b7cdc1dc02f83d](https://www.virustotal.com/gui/file/ec9d45b695f98bfbf3b7cdc1dc02f83d)|Win32 DLL||2018-09-10 18:17:33|myfile.exe|
|[a983d2ae308fc03f4548f4cab7d608b1](https://www.virustotal.com/gui/file/a983d2ae308fc03f4548f4cab7d608b1)|HTML|CVE-2018-8174|2018-09-04 14:24:08|a983d2ae308fc03f4548f4cab7d608b1_VdVSrGqPzuDyqxmKqTEJSa.hTMl|
|[2f98a491258b6606b7d9ad2a662a5513](https://www.virustotal.com/gui/file/2f98a491258b6606b7d9ad2a662a5513)|XML|CVE-2017-0199|2018-09-04 11:50:39|2f98a491258b6606b7d9ad2a662a5513_VaQxiXLMORdj.xML|
|[87725b247eef1a96e31b56cf86ba600e](https://www.virustotal.com/gui/file/87725b247eef1a96e31b56cf86ba600e)|PDF||2018-08-29 07:33:37|Bank Ref_Cancellation_Incorrect AC.pdf|
|[499b720ee80159804679f0009465916b](https://www.virustotal.com/gui/file/499b720ee80159804679f0009465916b)|PDF|Banload|2018-08-20 08:08:58|Bank Ref_Cancellation_Incorrect AC.pdf|
|[bf97e09016e5e6a65968933f94d10a1d](https://www.virustotal.com/gui/file/bf97e09016e5e6a65968933f94d10a1d)|Win32 EXE|Zbot|2018-08-16 11:22:00|ServicesPainter|
|[9e60c89cc58b3e47d93864433622ae32](https://www.virustotal.com/gui/file/9e60c89cc58b3e47d93864433622ae32)|RTF|CVE-2017-0199|2018-08-16 10:09:10|9e60c89cc58b3e47d93864433622ae32_DuYrAuDBGZcXa.Rtf|
|[1999a718fb9bcf3c5b3e41bf88be9067](https://www.virustotal.com/gui/file/1999a718fb9bcf3c5b3e41bf88be9067)|Win32 EXE||2018-08-15 13:54:33|Flatbed923027|
|[616199072a11d95373b3c38626ad4c93](https://www.virustotal.com/gui/file/616199072a11d95373b3c38626ad4c93)|Win32 DLL|Ursu|2018-08-14 16:47:31|616199072a11d95373b3c38626ad4c93_iOfcxBRiNVCEopEbSjDFM.dlL|
|[eb93c912e4d3ecf52615b198c44771f4](https://www.virustotal.com/gui/file/eb93c912e4d3ecf52615b198c44771f4)|Email||2018-08-14 12:10:39|3e6691ea3965f9776b14d010d8abf03976e9fb2d0b0759611062069017839df6.bin|
|[a3b705ce3d677361a7a9b2b0bdf04a04](https://www.virustotal.com/gui/file/a3b705ce3d677361a7a9b2b0bdf04a04)|RTF|Kryptik|2018-08-14 11:35:53|a3b705ce3d677361a7a9b2b0bdf04a04_LMcCdWePiWQWQAibbWckBG.Rtf|
|[9270ac1e013a3b33c44666a66795d0c0](https://www.virustotal.com/gui/file/9270ac1e013a3b33c44666a66795d0c0)|Win32 EXE||2018-08-14 10:00:38|Flatbed923027|
|[d3ac921038773c9b59fa6b229baa6469](https://www.virustotal.com/gui/file/d3ac921038773c9b59fa6b229baa6469)|Email||2018-08-03 06:35:55|1fdd305ef94a94283ad0f7a8ec81be4c484e2b20e2a3bc42000a401b56d52279.bin|
|[9a87da405a53eaf32f8a24d3abb085af](https://www.virustotal.com/gui/file/9a87da405a53eaf32f8a24d3abb085af)|Win32 EXE|Kryptik|2018-08-02 21:18:11|ChinasYoffset|
|[3452903fc857fb98f4339d7ce1884099](https://www.virustotal.com/gui/file/3452903fc857fb98f4339d7ce1884099)|Win32 DLL|Ursu|2018-08-02 20:23:31|decoded.dll|
|[e368365bece9fb5b0bc8de1209bab694](https://www.virustotal.com/gui/file/e368365bece9fb5b0bc8de1209bab694)|Win32 DLL||2018-08-02 16:39:41|Scintilla|
|[61e3207a3ea674c2ae012f44f2f5618b](https://www.virustotal.com/gui/file/61e3207a3ea674c2ae012f44f2f5618b)|DOC||2018-08-02 12:06:52|61e3207a3ea674c2ae012f44f2f5618b_wMdbCLJuHheK.doC|
|[f3bb3e2c03f3976c107de88b43a22655](https://www.virustotal.com/gui/file/f3bb3e2c03f3976c107de88b43a22655)|Win32 EXE||2018-08-02 11:04:43|ChinasYoffset|
|[bde2a50090ee0e71e7f1d36bd8c2b7b0](https://www.virustotal.com/gui/file/bde2a50090ee0e71e7f1d36bd8c2b7b0)|PDF||2018-08-02 06:24:13|DOC-0636452456.pdf|
|[f739fa9409eed447c39d703bb5427e8b](https://www.virustotal.com/gui/file/f739fa9409eed447c39d703bb5427e8b)|DOCM||2018-07-11 15:52:16|doc0067181.doc|
|[156a9e46abb613eb6d046fb8be05571c](https://www.virustotal.com/gui/file/156a9e46abb613eb6d046fb8be05571c)|PDF|Banload|2018-07-10 17:23:29|VirusShare_156a9e46abb613eb6d046fb8be05571c|
|[e8f306f9dc48973dcfa9e4bf903c9522](https://www.virustotal.com/gui/file/e8f306f9dc48973dcfa9e4bf903c9522)|PDF||2018-07-10 04:23:00|e8f306f9dc48973dcfa9e4bf903c9522.virus|
|[94a5b2d52d93f0c897c4b8aeca17789a](https://www.virustotal.com/gui/file/94a5b2d52d93f0c897c4b8aeca17789a)|RTF||2018-07-10 01:02:41|94a5b2d52d93f0c897c4b8aeca17789a.virus|
|[c7f8a7d1398a95a2f7048bb7564d8830](https://www.virustotal.com/gui/file/c7f8a7d1398a95a2f7048bb7564d8830)|Win32 EXE|Symmi|2018-07-09 19:55:45|c7f8a7d1398a95a2f7048bb7564d8830.virus|
|[2edde0e13c93824a3bbf947c08918570](https://www.virustotal.com/gui/file/2edde0e13c93824a3bbf947c08918570)|DOCM|o97m|2018-07-09 14:28:22|2edde0e13c93824a3bbf947c08918570.virus|
|[d017bf9f6039445bfefd95a853b2e4c4](https://www.virustotal.com/gui/file/d017bf9f6039445bfefd95a853b2e4c4)|Win32 DLL|Ursu|2018-07-06 15:32:57|c:\windows\system32\drprov.dll|
|[ec265b27983c1d83430158ff91caa7a6](https://www.virustotal.com/gui/file/ec265b27983c1d83430158ff91caa7a6)|RTF|CVE-2017-8570|2018-07-04 23:09:01|ec265b27983c1d83430158ff91caa7a6.virus|
|[3ac125ca48adf1c4f3c63431032c44ff](https://www.virustotal.com/gui/file/3ac125ca48adf1c4f3c63431032c44ff)|PDF|phishing|2018-06-29 10:13:17|3ac125ca48adf1c4f3c63431032c44ff.virus|
|[38242fb29d7cb82a4ffd651189d9821e](https://www.virustotal.com/gui/file/38242fb29d7cb82a4ffd651189d9821e)|Win32 DLL||2018-06-19 08:59:28|OLESS.dll|
|[92f1bb5aa4a1c6c8ac81cbfdc2b3698a](https://www.virustotal.com/gui/file/92f1bb5aa4a1c6c8ac81cbfdc2b3698a)|DOC|o97m|2018-06-19 07:14:32|92f1bb5aa4a1c6c8ac81cbfdc2b3698a.virus|
|[1b7ff3f73963459e27beccc6eae7fa60](https://www.virustotal.com/gui/file/1b7ff3f73963459e27beccc6eae7fa60)|Text||2018-06-08 19:06:52|scriptlet.sct.1585834953.DROPPED.rename|
|[4e504b0b50340807766d0f9584ab9a01](https://www.virustotal.com/gui/file/4e504b0b50340807766d0f9584ab9a01)|HTML||2018-06-08 19:05:49|4e504b0b50340807766d0f9584ab9a01.virus|
|[5c179acb4765eaf2940496894d27c6e4](https://www.virustotal.com/gui/file/5c179acb4765eaf2940496894d27c6e4)|RTF|CVE-2017-8570|2018-06-07 12:11:07|5c179acb4765eaf2940496894d27c6e4.virus|
|[4ae5e21641eb8685fca60510bdb07a52](https://www.virustotal.com/gui/file/4ae5e21641eb8685fca60510bdb07a52)|PDF|phishing|2018-06-07 11:17:18|/data/cfs/malshare/4ae5e21641eb8685fca60510bdb07a52|
|[f0645bd9367faf4e21a9c5e8c132bed7](https://www.virustotal.com/gui/file/f0645bd9367faf4e21a9c5e8c132bed7)|Win32 DLL||2018-06-03 11:33:15|f0645bd9367faf4e21a9c5e8c132bed7.virus|
|[0fd5bf6ad8e6857b7800d3c4de66486f](https://www.virustotal.com/gui/file/0fd5bf6ad8e6857b7800d3c4de66486f)|RTF|CVE-2017-8570|2018-06-02 11:15:22|0fd5bf6ad8e6857b7800d3c4de66486f.virus|
|[ec742366f68c56f2b91636bd81a6a03c](https://www.virustotal.com/gui/file/ec742366f68c56f2b91636bd81a6a03c)|PDF||2018-05-31 13:15:43|ec742366f68c56f2b91636bd81a6a03c.virus|
|[49d1a6f2b6b9e67c314a65fcf64911c5](https://www.virustotal.com/gui/file/49d1a6f2b6b9e67c314a65fcf64911c5)|Win32 DLL|ursu|2018-05-30 13:04:38|jj|
|[123db52ae79f0262e52cf674cc1b75fa](https://www.virustotal.com/gui/file/123db52ae79f0262e52cf674cc1b75fa)|RTF|CVE-2017-8570|2018-05-30 12:33:23|123db52ae79f0262e52cf674cc1b75fa.virus|
|[34a58e62866e5c17db61ee5f95d52c58](https://www.virustotal.com/gui/file/34a58e62866e5c17db61ee5f95d52c58)|Win32 DLL|malagent|2018-05-29 07:47:39|OLESS.dll|
|[9c7e75b8ba4e37ed5e6947048f3d0c85](https://www.virustotal.com/gui/file/9c7e75b8ba4e37ed5e6947048f3d0c85)|DOC||2018-05-28 14:41:09|f1004c0d6bf312ed8696c364d94bf6e63a907c80348ebf257ceae8ed5340536b.bin.rename|
|[e5795f4418b28888a287e976f741dfbe](https://www.virustotal.com/gui/file/e5795f4418b28888a287e976f741dfbe)|RTF|CVE-2017-8570|2018-05-28 10:31:09|e5795f4418b28888a287e976f741dfbe.virus|
|[7b55c7ae346efb428aaf63d25ca0fcc7](https://www.virustotal.com/gui/file/7b55c7ae346efb428aaf63d25ca0fcc7)|Win32 EXE|Kryptik|2018-05-23 11:37:18|SemiconductorStore.exe|
|[fa354151a3fc6d0dce69e8eeaa8cd197](https://www.virustotal.com/gui/file/fa354151a3fc6d0dce69e8eeaa8cd197)|unknown|CVE-2017-8570|2018-05-23 10:55:37|Complaint.doc.1|
|[d68b4431e2dc4ae89345504977160563](https://www.virustotal.com/gui/file/d68b4431e2dc4ae89345504977160563)|RTF|CVE-2017-0199|2018-05-22 19:07:41|d68b4431e2dc4ae89345504977160563.virus|
|[298774c49ee2a1e823f8049a34c09609](https://www.virustotal.com/gui/file/298774c49ee2a1e823f8049a34c09609)|RTF|TrickBot|2018-05-21 12:27:58|Details Acess.doc|
|[1fef1fd4fed5a3019bb970c9eccd8fd6](https://www.virustotal.com/gui/file/1fef1fd4fed5a3019bb970c9eccd8fd6)|DOC|Banload|2018-05-17 14:48:59|1fef1fd4fed5a3019bb970c9eccd8fd6.virus|
|[d117c73e353193118a6383c30e42a95f](https://www.virustotal.com/gui/file/d117c73e353193118a6383c30e42a95f)|RTF|CVE-2017-8570|2018-05-09 14:39:49|d117c73e353193118a6383c30e42a95f.virus|
|[4beded532ce7c72036dca6eb4f3e035b](https://www.virustotal.com/gui/file/4beded532ce7c72036dca6eb4f3e035b)|Win32 DLL||2018-04-24 02:40:43|myfile.exe|
|[33cd8c06a1bc8eff1e003935069d120a](https://www.virustotal.com/gui/file/33cd8c06a1bc8eff1e003935069d120a)|DOC||2018-04-23 22:59:23|DOC00481950.doc|
|[5616ee6b38f151086cc2b1f59c6cba9a](https://www.virustotal.com/gui/file/5616ee6b38f151086cc2b1f59c6cba9a)|RTF|CVE-2017-8570|2018-04-16 15:01:02|97f13bdaa952a897b55c8c29711c0b5ec4477059|
|[2e0cc6890fbf7a469d6c0ae70b5859e7](https://www.virustotal.com/gui/file/2e0cc6890fbf7a469d6c0ae70b5859e7)|RTF|CVE-2017-11882|2018-01-16 10:29:10|8a57464c93d4f6d85e51e07748d4ffcc0b9e6b5a64642aec859040d1606fd0f8 (1)|
|[10d044bc5b8ae607501304e61b2efecb](https://www.virustotal.com/gui/file/10d044bc5b8ae607501304e61b2efecb)|Win32 DLL|Ursu|2017-12-27 19:59:32|8135a9a23b0a206d289b262ed56fcb5aa7bff257b589ca3d4a79d4658da91fc1.bin|
|[ab13a8fa6d5e4a5fd917d1695bf594fa](https://www.virustotal.com/gui/file/ab13a8fa6d5e4a5fd917d1695bf594fa)|Win32 DLL|occamy|2020-02-03 16:40:37|decoded.dll|
|[6b10b2b307d88b74c07d68cbf76152eb](https://www.virustotal.com/gui/file/6b10b2b307d88b74c07d68cbf76152eb)|Win32 EXE||2020-02-03 05:08:23|lsm.e_e|
|[43c1e0cce9500e8b16f655dba120c112](https://www.virustotal.com/gui/file/43c1e0cce9500e8b16f655dba120c112)|Win32 DLL||2019-12-20 15:09:35|decoded.dll|
|[8811328f990e79ebb840c44954b322e0](https://www.virustotal.com/gui/file/8811328f990e79ebb840c44954b322e0)|Win32 EXE|occamy|2019-12-09 15:36:51|%APPDATA%\putty.exe|
|[3fae007e6fcded0b60b30cd7e18ef55f](https://www.virustotal.com/gui/file/3fae007e6fcded0b60b30cd7e18ef55f)|Win32 DLL||2019-12-06 22:19:41|decoded.dll|
|[82fc2a2b268a43b842cf5c0666633642](https://www.virustotal.com/gui/file/82fc2a2b268a43b842cf5c0666633642)|Win32 DLL|Tiggre|2019-11-27 18:05:44|cdd87d3cc8807c18d7fb2f67768f4db76506deaabfc57a47ff2f5f5c798e9951.bin|
|[93f4356cb0e96cb9e4f3caae8af70a11](https://www.virustotal.com/gui/file/93f4356cb0e96cb9e4f3caae8af70a11)|Win32 DLL||2019-11-27 17:48:11|6908941580bfa5759ff93c0f2807ebec8cf110e7630dea9c5267b835e52083de.bin|
|[7901f9317baa81dc6cef72809d003929](https://www.virustotal.com/gui/file/7901f9317baa81dc6cef72809d003929)|Win32 EXE||2019-11-27 15:34:01|List of transactions.scr|
|[72db8baf32cd1101ad9c427e5f46c744](https://www.virustotal.com/gui/file/72db8baf32cd1101ad9c427e5f46c744)|Win32 DLL||2019-11-01 21:34:18|decoded.dll|
|[88921c119f409b6db12e7559b0a64066](https://www.virustotal.com/gui/file/88921c119f409b6db12e7559b0a64066)|Win32 EXE|occamy|2019-10-24 11:57:29|Statement.scr|
|[28bfbdec4c9631d4fbef39a460fef5ad](https://www.virustotal.com/gui/file/28bfbdec4c9631d4fbef39a460fef5ad)|Win32 DLL|occamy|2019-10-23 18:56:15|65a5c5fa49c8709924f14486843de8bdee764340c7892492c3a03f610ecf3823.bin|
|[fd6e378ee8e518113893e4f157efe74e](https://www.virustotal.com/gui/file/fd6e378ee8e518113893e4f157efe74e)|Win32 EXE||2019-10-23 16:18:48|Statement.xls                                                                                                            .scr|
|[feb0fc8429f843d79fa1f4da1eea5a1c](https://www.virustotal.com/gui/file/feb0fc8429f843d79fa1f4da1eea5a1c)|Win32 EXE|occamy|2019-10-23 08:21:44|VirusShare_feb0fc8429f843d79fa1f4da1eea5a1c|
|[418ab6be4016d851eff94b086e22bc9e](https://www.virustotal.com/gui/file/418ab6be4016d851eff94b086e22bc9e)|Win32 EXE||2019-10-22 14:37:30|________.scr|
|[08692f325be00d7c2b7f898d40092001](https://www.virustotal.com/gui/file/08692f325be00d7c2b7f898d40092001)|Win32 DLL|Graftor|2019-10-21 00:05:58| |
|[1c549aaaa02e1061fbeeacb1641b231a](https://www.virustotal.com/gui/file/1c549aaaa02e1061fbeeacb1641b231a)|Win32 DLL||2019-10-17 19:36:12|decoded.dll|
|[616911e4312343c46da94d0eb6950742](https://www.virustotal.com/gui/file/616911e4312343c46da94d0eb6950742)|Win32 DLL|occamy|2019-10-17 13:54:46|decoded.dll|
|[746d2860097db33796d3aee500abb245](https://www.virustotal.com/gui/file/746d2860097db33796d3aee500abb245)|Win32 DLL|occamy|2019-10-16 19:31:29|decoded.dll|
|[349473f33c43a27a260b39cb68ae2412](https://www.virustotal.com/gui/file/349473f33c43a27a260b39cb68ae2412)|Win32 EXE||2019-10-16 12:13:53|report%20cyber%20security.scr|
|[fe703d6b2694209fd9958aed5b6eee38](https://www.virustotal.com/gui/file/fe703d6b2694209fd9958aed5b6eee38)|Win32 DLL||2019-10-15 12:55:44|decoded.dll|
|[025c3faf48a4b66cba9257ed68bbd834](https://www.virustotal.com/gui/file/025c3faf48a4b66cba9257ed68bbd834)|Win32 EXE||2019-10-11 12:13:25|avatar.hlpv|
|[eb28c065b956f3d5c8919714f5d110f9](https://www.virustotal.com/gui/file/eb28c065b956f3d5c8919714f5d110f9)|Win32 DLL||2019-10-09 13:28:20|decoded.dll|
|[ab2c0d36529119e91fa84562a03307f7](https://www.virustotal.com/gui/file/ab2c0d36529119e91fa84562a03307f7)|Win32 EXE||2019-10-09 12:53:38|avatar.hlpv|
|[ce760d0eb1738cc2de55876eef808647](https://www.virustotal.com/gui/file/ce760d0eb1738cc2de55876eef808647)|Win32 DLL|occamy|2019-10-04 13:40:16|decoded.dll|
|[88ac6f94f0351f34c5237a7b9298879a](https://www.virustotal.com/gui/file/88ac6f94f0351f34c5237a7b9298879a)|Win32 DLL||2019-10-03 13:08:26|decoded.dll|
|[f2d2562f1ef3e36c0ebd090fe913c25e](https://www.virustotal.com/gui/file/f2d2562f1ef3e36c0ebd090fe913c25e)|Win32 DLL||2019-07-10 21:38:41|decoded.dll|
