**NAME:**  
Cobalt Group  
  
**Alias**  
Cobalt Gang, COBALT SPIDER, TEMP.Metastrike, GOLD KINGSWOOD, Cobalt Group  
 
**Description**:   
Cobalt Group is a financially motivated threat group that has primarily targeted financial institutions. The group has conducted intrusions to steal money via targeting ATM systems, card processing, payment systems and even SWIFT systems. It mainly targeted banks in Eastern Europe, Central Asia, and Southeast Asia. Reporting indicates there may be links between Cobalt Group and Carbanak/Anunak
  
**References**:  
https://www.helpnetsecurity.com/2016/11/22/cobalt-hackers-synchronized-atm-heists/  
https://researchcenter.paloaltonetworks.com/2018/10/unit42-new-techniques-uncover-attribute-cobalt-gang-commodity-builders-infrastructure-revealed/  
