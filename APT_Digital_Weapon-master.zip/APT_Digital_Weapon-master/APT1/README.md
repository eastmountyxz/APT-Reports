**NAME:**  
APT1  
  
**Alias**  
Comment Panda, PLA Unit 61398, APT 1, Advanced Persistent Threat 1, Byzantine Candor, Group 3, TG-8223, Comment Group, Brown Fox, Comment Crew, APT1  
   
**Description**:  
 Attacks carried out by APT1 could trace back to 2006. This attack group is attributed to PLA Unit by FireEye. According to the report, more than 100 organizations are affected and hundreds of terabytes of data get stolen.
  
**References**:  
https://www.fireeye.com/content/dam/fireeye-www/services/pdfs/mandiant-apt1-report.pdf