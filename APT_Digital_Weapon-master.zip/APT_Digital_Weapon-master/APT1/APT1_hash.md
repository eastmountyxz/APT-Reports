|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[523f56515221161579ee6090c962e5b1](https://www.virustotal.com/gui/file/523f56515221161579ee6090c962e5b1)|Win32 EXE||2013-02-19 10:38:42|myfile.exe|
|[7fde05eda7ae46ec42982f4c0e1bd01b](https://www.virustotal.com/gui/file/7fde05eda7ae46ec42982f4c0e1bd01b)|Win32 EXE|Godin|2013-01-13 04:55:31|a058287ad385361f_ctfmon.exe|
|[6f9992c486195edcf0bf2f6ee6c3ec74](https://www.virustotal.com/gui/file/6f9992c486195edcf0bf2f6ee6c3ec74)|Win32 EXE||2012-12-19 14:12:28|VirusShare_6f9992c486195edcf0bf2f6ee6c3ec74|
