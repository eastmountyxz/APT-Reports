|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[8ac035756d3a3b0659c8253a8292dc79](https://www.virustotal.com/gui/file/8ac035756d3a3b0659c8253a8292dc79)|Win32 DLL||2019-12-29 11:52:52|out|
|[4657e8128ce3e4f8f3b913f363e64a2e](https://www.virustotal.com/gui/file/4657e8128ce3e4f8f3b913f363e64a2e)|Win32 DLL||2019-12-28 17:07:43|out|
|[6941fee7d03ba75dbfcbf130109e3299](https://www.virustotal.com/gui/file/6941fee7d03ba75dbfcbf130109e3299)|JPEG||2019-11-13 15:47:15|093.turla.jpeg|
|[e587ec82958f9f96a7ec7e0144c65547](https://www.virustotal.com/gui/file/e587ec82958f9f96a7ec7e0144c65547)|Win32 EXE||2019-10-24 00:56:05|58970724ebe794e4f03d2cecb390153f21820a05f25b71b1d768418921d984c2.bin|
|[903789933d84b993ec8cf2d0c767c2c1](https://www.virustotal.com/gui/file/903789933d84b993ec8cf2d0c767c2c1)|Win32 EXE||2019-10-24 00:55:44|903789933d84b993ec8cf2d0c767c2c1.virus|
|[c78b80e60d3ed14147b8474cafdc6611](https://www.virustotal.com/gui/file/c78b80e60d3ed14147b8474cafdc6611)|Win32 EXE||2019-10-23 03:37:20|C:\Users\<USER>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\krHi9Z07.exe|
|[9573f452004b16eabd20fa65a6c2c1c4](https://www.virustotal.com/gui/file/9573f452004b16eabd20fa65a6c2c1c4)|Win32 EXE||2019-10-12 09:07:06|Client.exe|
|[47870ff98164155f088062c95c448783](https://www.virustotal.com/gui/file/47870ff98164155f088062c95c448783)|Win32 EXE||2019-10-12 09:06:09|009406c1c7c0b289a25d44dfaa8364633d9b71df5f3c7a65deec1ef00a8c2ebb.sample|
|[066731c76f623f418029a1a97758361d](https://www.virustotal.com/gui/file/066731c76f623f418029a1a97758361d)|Win32 DLL||2019-10-06 23:50:21| |
|[71dd8648a286d4d5ccb040db4f81a3cb](https://www.virustotal.com/gui/file/71dd8648a286d4d5ccb040db4f81a3cb)|Win32 DLL||2019-10-05 16:42:59| |
|[1612666c3ffa54d60c5e2118bbb4ae1c](https://www.virustotal.com/gui/file/1612666c3ffa54d60c5e2118bbb4ae1c)|TXT||2019-09-17 08:56:15|f_000f8b|
|[b17966427921e6b905874e18be549e9e](https://www.virustotal.com/gui/file/b17966427921e6b905874e18be549e9e)|Win32 DLL||2019-08-30 18:58:11| |
|[52beacccecd9342421aa682ad538e677](https://www.virustotal.com/gui/file/52beacccecd9342421aa682ad538e677)|Win32 EXE|Ursu|2019-08-19 19:34:59|Microsoft.Exchange.MessagingPolicies.Search.exe|
|[031782fccc281aca377cef1d6d6ffc6b](https://www.virustotal.com/gui/file/031782fccc281aca377cef1d6d6ffc6b)|Win64 DLL|turla|2019-08-19 19:34:50|BPA.Transport.dll|
|[743d9a2d087e17e20e7819944ba68fcd](https://www.virustotal.com/gui/file/743d9a2d087e17e20e7819944ba68fcd)|Win64 EXE|turla|2019-08-17 00:45:21|fea27eb2e939e930c8617dcf64366d1649988f30555f6ee9cd09fe54e4bc22b3.zip|
|[3e792792bd6ddead1d0ecc76b8d71ab3](https://www.virustotal.com/gui/file/3e792792bd6ddead1d0ecc76b8d71ab3)|Win64 EXE|turla|2019-07-29 14:01:26|JPEGView|
|[3c98235a50b76050b18d2908261fd7c2](https://www.virustotal.com/gui/file/3c98235a50b76050b18d2908261fd7c2)|unknown|Kryptik|2019-07-11 13:51:55|MicrosoftDirectX11|
|[535e67930dfbec1a0ae2671b63e2ef8e](https://www.virustotal.com/gui/file/535e67930dfbec1a0ae2671b63e2ef8e)|Win32 EXE||2019-06-27 21:40:27|%WINDIR%\syswow64\w3wwp.exe|
|[6e4b7f13178ebc04304ee2b5ee646d09](https://www.virustotal.com/gui/file/6e4b7f13178ebc04304ee2b5ee646d09)|Win32 EXE||2019-06-27 05:47:20|eseutil.exe|
|[32a29827e7ccf31e33d56cb1026f935e](https://www.virustotal.com/gui/file/32a29827e7ccf31e33d56cb1026f935e)|Win64 DLL|turla|2019-06-26 23:29:58| |
|[2a8672b0fd29dc3b6f49935691b648bc](https://www.virustotal.com/gui/file/2a8672b0fd29dc3b6f49935691b648bc)|Win32 EXE||2019-06-26 03:05:41|wuauclt.exe|
|[8851f2fd31964f867eb07c398d57112a](https://www.virustotal.com/gui/file/8851f2fd31964f867eb07c398d57112a)|Win32 DLL|turla|2019-06-21 19:08:50|Microsoft.Exchange.Security.Interop.dll|
|[9456197d0f8b6cabfea5f02ffb0176dd](https://www.virustotal.com/gui/file/9456197d0f8b6cabfea5f02ffb0176dd)|Win64 DLL|turla|2019-06-21 10:35:30|eseutil.dll|
|[fe19cf15a3c1f9f4691231965cbd9ae0](https://www.virustotal.com/gui/file/fe19cf15a3c1f9f4691231965cbd9ae0)|Win32 EXE|turla|2019-06-05 05:45:15|fe19cf15a3c1f9f4691231965cbd9ae0.virobj|
|[06c7fff3ab4549e7730cc55ba4f3d7e5](https://www.virustotal.com/gui/file/06c7fff3ab4549e7730cc55ba4f3d7e5)|Win32 DLL|turla|2019-06-05 05:04:54|tcss.dll|
|[23fe1a55c19a11401219b6ba9d03530d](https://www.virustotal.com/gui/file/23fe1a55c19a11401219b6ba9d03530d)|Win32 EXE||2019-06-05 05:04:53|wds.exe|
|[5a7a4755e785c227c250a7c1c346db20](https://www.virustotal.com/gui/file/5a7a4755e785c227c250a7c1c346db20)|DOC|o97m|2019-06-05 04:56:19|5a7a4755e785c227c250a7c1c346db20.virobj|
|[afcf3936639b706221d5f67afa75d80b](https://www.virustotal.com/gui/file/afcf3936639b706221d5f67afa75d80b)|Win32 EXE||2019-05-26 10:33:36|Microsoft.Exchange.Mapi.Service.exe|
|[7911f8d717dc9d7a78d99e687a12d7ad](https://www.virustotal.com/gui/file/7911f8d717dc9d7a78d99e687a12d7ad)|Win64 DLL||2019-04-29 16:25:41|jpicom.dll|
|[5bd6544e0884613743607b7084610186](https://www.virustotal.com/gui/file/5bd6544e0884613743607b7084610186)|Win32 DLL||2019-04-22 18:09:27|MSJAVAVM|
|[103dc636c7d970f2f88d4cacff06db20](https://www.virustotal.com/gui/file/103dc636c7d970f2f88d4cacff06db20)|Win32 DLL||2019-04-21 23:02:39|MSJAVAVM|
|[0c35bc92aaba0cde4dd759a350011416](https://www.virustotal.com/gui/file/0c35bc92aaba0cde4dd759a350011416)|Win64 EXE||2019-04-17 19:08:13|outputEXE|
|[3783e51ce48f7b6a48ea433cccacda19](https://www.virustotal.com/gui/file/3783e51ce48f7b6a48ea433cccacda19)|Win64 EXE||2019-04-16 07:04:25|JPEGView|
|[59e6b97e7a3ada359e84d92302d02dfe](https://www.virustotal.com/gui/file/59e6b97e7a3ada359e84d92302d02dfe)|Text|turla|2019-04-15 15:40:23|GoogleUpdater.vbs|
|[ced8a9dac22338cb5be039936615f070](https://www.virustotal.com/gui/file/ced8a9dac22338cb5be039936615f070)|Text||2019-04-15 15:26:54|ced8a9dac22338cb5be039936615f070.virobj|
|[38abeb8a68e9207da3e6ead88a9682ec](https://www.virustotal.com/gui/file/38abeb8a68e9207da3e6ead88a9682ec)|Win64 DLL|turla|2019-04-13 07:05:45|Win32.Turla.v1.bin|
|[165be7620b78fe37cf25c797ee5b49e7](https://www.virustotal.com/gui/file/165be7620b78fe37cf25c797ee5b49e7)|Text||2019-04-12 13:31:26|22a8b4a7c7a467ea7fcf0a3930c99ecb482095093839683b400f58e2cdda176f.bin|
|[198ee041e8f3eb12a19bc321f86ccb88](https://www.virustotal.com/gui/file/198ee041e8f3eb12a19bc321f86ccb88)|Win32 EXE||2019-03-25 12:33:37|SmsServiceServerTest.exe|
|[cccc15cb2db720fc6ffbd319b82648fc](https://www.virustotal.com/gui/file/cccc15cb2db720fc6ffbd319b82648fc)|Win64 DLL||2019-03-12 19:53:33|module.51024.54b4e7840.17cfb0a0000.dll|
|[eaaf9f763ae8c70d6e63d4b1e3364f74](https://www.virustotal.com/gui/file/eaaf9f763ae8c70d6e63d4b1e3364f74)|Win32 EXE||2019-03-10 17:27:07|btwcb.exe|
|[1bdd52a68fe474da685f1a2d502481cc](https://www.virustotal.com/gui/file/1bdd52a68fe474da685f1a2d502481cc)|Win32 DLL|turla|2019-02-25 01:14:07|winstor32.sys|
|[e1fdde61d9db9d6875994e4a412987f7](https://www.virustotal.com/gui/file/e1fdde61d9db9d6875994e4a412987f7)|Win32 EXE|razy|2019-02-23 13:00:26|Microsoft.Exchange.MessagingPolicies.Search.exe|
|[687d7ddb080fb769b26a0c054f4cd422](https://www.virustotal.com/gui/file/687d7ddb080fb769b26a0c054f4cd422)|Win32 EXE||2019-01-29 07:21:05|WSMProvider.exe|
|[1753424464a00c628d7166152cc30d1e](https://www.virustotal.com/gui/file/1753424464a00c628d7166152cc30d1e)|Win32 EXE||2019-01-29 07:18:47|Microsoft.Exchange.Mapi.Service.exe|
|[55319464e46e2c31d22b39b46d5477fb](https://www.virustotal.com/gui/file/55319464e46e2c31d22b39b46d5477fb)|Win32 EXE|Ursu|2019-01-22 20:01:03|module.4296.63cb687d0.7d40000.dll|
|[5924eac8af1f3e3f1f825998bc59c062](https://www.virustotal.com/gui/file/5924eac8af1f3e3f1f825998bc59c062)|Win64 DLL|turla|2019-01-18 03:08:15|BPA.Transport.dll|
|[2b14f9f3c758a2cf842a61aca6a3455d](https://www.virustotal.com/gui/file/2b14f9f3c758a2cf842a61aca6a3455d)|Win32 EXE|turla|2019-01-14 16:25:05|Microsoft.Exchange.MessagingPolicies.Search.exe|
|[978b1cc65241e768d6b611436dc11696](https://www.virustotal.com/gui/file/978b1cc65241e768d6b611436dc11696)|JPEG||2018-12-21 06:25:59|ATT00001.jpg|
|[3c04b325aeb77ba957f98b53cddac88d](https://www.virustotal.com/gui/file/3c04b325aeb77ba957f98b53cddac88d)|JPEG||2018-12-21 06:22:34|ATT00001.jpg|
|[25ad1d40b05d9b6978d352b490e7b93f](https://www.virustotal.com/gui/file/25ad1d40b05d9b6978d352b490e7b93f)|Win32 DLL||2018-11-02 16:43:01|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/TurlaSnakeImplant.bin|
|[d891c9374ccb2a4cae2274170e8644d8](https://www.virustotal.com/gui/file/d891c9374ccb2a4cae2274170e8644d8)|Win32 EXE||2018-10-23 16:23:32|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/NCSC.bin|
|[2ced6205942be2349da93af07170bdfd](https://www.virustotal.com/gui/file/2ced6205942be2349da93af07170bdfd)|Win32 DLL||2018-10-18 14:25:38|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/NeuronImplant2018.bin|
|[38ff4b9747c1e6462d8fc31d5455cca2](https://www.virustotal.com/gui/file/38ff4b9747c1e6462d8fc31d5455cca2)|Win64 EXE|turla|2018-10-12 05:42:25|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/CarbonImplant.bin|
|[2cf3b60fb0d99f2b97e6b69d5aef8bc2](https://www.virustotal.com/gui/file/2cf3b60fb0d99f2b97e6b69d5aef8bc2)|Win32 DLL|turla|2018-09-17 11:18:36|f039fabe740253789027edda5d78ac1eb62215ce3fb37d944d118c3e6c3ac045.sample|
|[d2e8e75c30dccd98a95d25b218ba7d2e](https://www.virustotal.com/gui/file/d2e8e75c30dccd98a95d25b218ba7d2e)|Win64 EXE|turla|2018-09-13 08:15:30|JPEGView|
|[b38cf254efd2bbad7acff33493014c8d](https://www.virustotal.com/gui/file/b38cf254efd2bbad7acff33493014c8d)|Win32 DLL|turla|2018-09-04 08:57:59|MSCAPGPL.DLL|
|[ee2af051e817b1952045833d16aef4e7](https://www.virustotal.com/gui/file/ee2af051e817b1952045833d16aef4e7)|Win32 DLL|turla|2018-09-04 08:57:58|WICACCESS.DLL|
|[79b794b6b291e4759fe07059113e93c8](https://www.virustotal.com/gui/file/79b794b6b291e4759fe07059113e93c8)|Win32 DLL|turla|2018-09-04 08:57:56|antros32.sys|
|[875484a6614962170c9797382010826b](https://www.virustotal.com/gui/file/875484a6614962170c9797382010826b)|Win32 EXE||2018-09-04 08:53:05|dotnetfx35.cab|
|[c5367fdf50d877162d69940fc2577523](https://www.virustotal.com/gui/file/c5367fdf50d877162d69940fc2577523)|Win32 DLL||2018-09-02 15:55:15|MSJAVAVM|
|[4bfde8b3a3cbcdfaa32d4d711476ccf2](https://www.virustotal.com/gui/file/4bfde8b3a3cbcdfaa32d4d711476ccf2)|Text||2018-09-02 09:31:54| |
|[fc137a5c307ee95055b54e8b43c6eac5](https://www.virustotal.com/gui/file/fc137a5c307ee95055b54e8b43c6eac5)|Win32 DLL||2018-08-27 19:45:02|b4249f6af24ea89976f3f7d9e3a605ccfbfe768069891f62c48df950d9212093.sample|
|[cddf058a8acc8139af072b2fa564940d](https://www.virustotal.com/gui/file/cddf058a8acc8139af072b2fa564940d)|Win32 EXE||2018-08-27 19:44:54|a2af1e9af48c4fa52a52ffba734ffeaa46c17d7320137d51dbd15539cc4cef8b.sample|
|[09caf5c0205bbab78d2d1877898a2398](https://www.virustotal.com/gui/file/09caf5c0205bbab78d2d1877898a2398)|Win32 EXE||2018-08-26 18:04:05| |
|[8d1c06ccab35c496556b23dc602b62e3](https://www.virustotal.com/gui/file/8d1c06ccab35c496556b23dc602b62e3)|Win32 EXE||2018-07-06 17:35:33|f9b83eff6d705c214993be9575f8990aa8150128a815e849c6faee90df14a0ea.sample|
|[5a65fc8d425925e26115c7337664b13e](https://www.virustotal.com/gui/file/5a65fc8d425925e26115c7337664b13e)|Win64 EXE||2018-06-26 14:02:46|MSTCSS.EXE|
|[a352f93e5f63bbf5cd0905c38f054d27](https://www.virustotal.com/gui/file/a352f93e5f63bbf5cd0905c38f054d27)|Win32 DLL||2018-06-14 16:16:34|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/TurlaAgent.exe|
|[905b4e9a2159dab45724333a0d99238f](https://www.virustotal.com/gui/file/905b4e9a2159dab45724333a0d99238f)|Text||2018-06-04 16:38:26|c5dd79cd-6fbd-5a11-bed3-2b1a39280d58.mal_|
|[110e9bc680c9d5452c23722f42c385b3](https://www.virustotal.com/gui/file/110e9bc680c9d5452c23722f42c385b3)|Text||2018-06-04 16:37:34|7914bba2-4e87-5678-b9ab-b0cfa9041308.mal_|
|[e27554923034da41d8fefbf6bfca66ae](https://www.virustotal.com/gui/file/e27554923034da41d8fefbf6bfca66ae)|Win32 EXE||2018-05-02 02:10:22|myfile.exe|
|[5dd1973e760e393a5ac3305ffe94a1f2](https://www.virustotal.com/gui/file/5dd1973e760e393a5ac3305ffe94a1f2)|Win32 EXE||2018-04-20 02:00:20|codexgigas_509fd277bcacf846a102ae08c4ac993188766372|
|[edfd33d319af1cce7baa1b15b52940e7](https://www.virustotal.com/gui/file/edfd33d319af1cce7baa1b15b52940e7)|Win32 DLL||2018-04-08 12:20:04|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/KazuarRAT.bin|
|[876903c3869abf77c8504148ac23f02b](https://www.virustotal.com/gui/file/876903c3869abf77c8504148ac23f02b)|Win32 DLL|turla|2018-03-19 12:28:27|olemon.dll|
|[5f7120d2debb34cab0e53b22c5e332e2](https://www.virustotal.com/gui/file/5f7120d2debb34cab0e53b22c5e332e2)|Win32 DLL|turla|2018-03-19 12:28:24|71b3b876702f2405_ksecdrv.sys|
|[d3b51adaab3a2043082ecc204862e150](https://www.virustotal.com/gui/file/d3b51adaab3a2043082ecc204862e150)|Win32 EXE||2018-03-13 07:07:01|wavReader.exe|
|[59b57bdabee2ce1fb566de51dd92ec94](https://www.virustotal.com/gui/file/59b57bdabee2ce1fb566de51dd92ec94)|Win64 DLL|turla|2018-03-12 08:46:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/TurlaKeylogger.bin|
|[ea874ac436223b30743fc9979eed5f2f](https://www.virustotal.com/gui/file/ea874ac436223b30743fc9979eed5f2f)|Win64 DLL||2018-02-25 01:25:27|myfile.exe|
|[080b2ce7188547c1e9ad1b8089467261](https://www.virustotal.com/gui/file/080b2ce7188547c1e9ad1b8089467261)|Win32 DLL|turla|2018-01-10 15:10:07|080b2ce7188547c1e9ad1b8089467261.virus|
|[137eb9b6ef122857bde72f78962ed208](https://www.virustotal.com/gui/file/137eb9b6ef122857bde72f78962ed208)|Win32 DLL|turla|2018-01-10 15:10:06|137eb9b6ef122857bde72f78962ed208.virus|
|[dfce6f7d3a992dc2ee7fedb8dea58237](https://www.virustotal.com/gui/file/dfce6f7d3a992dc2ee7fedb8dea58237)|Win32 DLL|turla|2018-01-10 15:10:06|dfce6f7d3a992dc2ee7fedb8dea58237.virus|
|[60bcc6bc746078d81a9cd15cd4f199bb](https://www.virustotal.com/gui/file/60bcc6bc746078d81a9cd15cd4f199bb)|Win64 DLL||2018-01-03 17:15:10|60bcc6bc746078d81a9cd15cd4f199bb.virus|
|[cc3adfe6079c1420a411b72f702e7dc7](https://www.virustotal.com/gui/file/cc3adfe6079c1420a411b72f702e7dc7)|Win32 EXE|turla|2017-12-17 02:19:06|cc3adfe6079c1420a411b72f702e7dc7.virus|
|[dfca3fc4b7f4c637d7319219fcec1876](https://www.virustotal.com/gui/file/dfca3fc4b7f4c637d7319219fcec1876)|Win32 EXE|turla|2017-12-16 21:38:15|dfca3fc4b7f4c637d7319219fcec1876.virus|
|[0ab62a3e02a036d81a64dac9e6b53533](https://www.virustotal.com/gui/file/0ab62a3e02a036d81a64dac9e6b53533)|Win32 EXE|Zbot|2017-10-16 02:53:39|0ab62a3e02a036d81a64dac9e6b53533.virus|
|[3e65a6d5658e6517c59d978dc159057a](https://www.virustotal.com/gui/file/3e65a6d5658e6517c59d978dc159057a)|Win32 EXE|turla|2017-10-16 02:22:29|3e65a6d5658e6517c59d978dc159057a.virus|
|[2e244d33dd8eb70bd83eb38e029d39ac](https://www.virustotal.com/gui/file/2e244d33dd8eb70bd83eb38e029d39ac)|Win32 EXE|turla|2017-09-24 19:03:21|2e244d33dd8eb70bd83eb38e029d39ac|
|[3c32e13162d884ab66e44902eddb8eee](https://www.virustotal.com/gui/file/3c32e13162d884ab66e44902eddb8eee)|Win32 DLL|turla|2017-09-22 11:06:12|24925a2e8de38f2498906f8088cf2a8939e3cfd3|
|[06bd89448a10aa5c2f4ca46b4709a879](https://www.virustotal.com/gui/file/06bd89448a10aa5c2f4ca46b4709a879)|Win32 DLL||2017-09-08 05:20:19|E:/byeongal/virustotal_public/malware/20170912/06bd89448a10aa5c2f4ca46b4709a879.vir|
|[5a2acbc101a8323f876bdd26948ee8a7](https://www.virustotal.com/gui/file/5a2acbc101a8323f876bdd26948ee8a7)|Win32 EXE||2017-08-30 13:43:25|E:/vt/malware/20170905/5a2acbc101a8323f876bdd26948ee8a7.vir|
|[0c6bb4ce1251c34365b8eb2a933dc431](https://www.virustotal.com/gui/file/0c6bb4ce1251c34365b8eb2a933dc431)|Win32 EXE||2017-08-30 13:42:40|0c6bb4ce1251c34365b8eb2a933dc431.vir|
|[fd7e0ecc41735d3ba0329e1e311689f8](https://www.virustotal.com/gui/file/fd7e0ecc41735d3ba0329e1e311689f8)|Win64 EXE|turla|2017-08-30 13:42:33|C:\Malware\malware.exe|
|[b099b82acb860d9a9a571515024b35f0](https://www.virustotal.com/gui/file/b099b82acb860d9a9a571515024b35f0)|Win32 EXE||2017-08-30 13:41:28|E:/vt/malware/20170905/b099b82acb860d9a9a571515024b35f0.vir|
|[0892096e45a3909b1bafe44235c508da](https://www.virustotal.com/gui/file/0892096e45a3909b1bafe44235c508da)|PDF||2017-08-23 06:10:25|Save the Date G20 Digital Economy Taskforce  23 24 October.pdf|
|[ccc172686bc7afc51349713178e2e45e](https://www.virustotal.com/gui/file/ccc172686bc7afc51349713178e2e45e)|Win64 DLL||2017-08-22 08:18:17|ccc172686bc7afc51349713178e2e45e|
|[b7fd4c5119867539e36e96de1d07af6e](https://www.virustotal.com/gui/file/b7fd4c5119867539e36e96de1d07af6e)|Win32 DLL||2017-08-17 18:44:59|aaclient.tlb|
|[df1b4f63c1adb9abfe04e0247956ce66](https://www.virustotal.com/gui/file/df1b4f63c1adb9abfe04e0247956ce66)|Text||2017-08-15 07:34:08|myvtfile.exe|
|[b318af64676a879dc50b491beccfa951](https://www.virustotal.com/gui/file/b318af64676a879dc50b491beccfa951)|Text||2017-08-15 07:34:06|myvtfile.exe|
|[7c378d78b7a89aef27e8a3c5066b8511](https://www.virustotal.com/gui/file/7c378d78b7a89aef27e8a3c5066b8511)|Win32 EXE||2017-07-29 04:32:03|Runer.exe|
|[fe4549563f9f59b6ebe933f2919555c7](https://www.virustotal.com/gui/file/fe4549563f9f59b6ebe933f2919555c7)|ZIP||2017-06-06 08:25:20|a7e32618e3f35a22e3817eacd64163148ea8af64bc832bb689c097eac77aa569.bin|
|[3b4517db282833f620dae675967f7c0a](https://www.virustotal.com/gui/file/3b4517db282833f620dae675967f7c0a)|ZIP||2017-06-06 08:24:48|html5.xpi|
|[a79ac543b0836b53a3623e0b4cb6a6f7](https://www.virustotal.com/gui/file/a79ac543b0836b53a3623e0b4cb6a6f7)|PLIST|snake|2017-05-04 19:16:13| |
|[5e996bcbb6f15d345a4a59758dc4d75f](https://www.virustotal.com/gui/file/5e996bcbb6f15d345a4a59758dc4d75f)|unknown|snake|2017-05-04 19:16:02| |
|[a90379e02cf9b66c3863131730a4b099](https://www.virustotal.com/gui/file/a90379e02cf9b66c3863131730a4b099)|sh script|snake|2017-05-04 19:15:02| |
|[f48ee47a79d5da606e9eff0401971075](https://www.virustotal.com/gui/file/f48ee47a79d5da606e9eff0401971075)|bash script|turla|2017-05-04 19:14:22| |
|[77b4ffe73491d534946d010bfca138f7](https://www.virustotal.com/gui/file/77b4ffe73491d534946d010bfca138f7)|Mach-O executable|turla|2017-05-02 16:42:38|/Library/Scripts/installdp|
|[6c74ff2cc39b5362ee5dec576ece211b](https://www.virustotal.com/gui/file/6c74ff2cc39b5362ee5dec576ece211b)|Mach-O executable|turla|2017-05-02 16:42:38|Install|
|[af8889f4705145d4390ee8d581f45436](https://www.virustotal.com/gui/file/af8889f4705145d4390ee8d581f45436)|Win32 DLL|turla|2017-03-25 11:31:15|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/OutlookBackdoor.bin|
|[ff8c3f362d7c9b9a19cfa09b4b3cfc75](https://www.virustotal.com/gui/file/ff8c3f362d7c9b9a19cfa09b4b3cfc75)|Win32 EXE|Zbot|2017-03-22 09:16:11|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/TurlaDropper.bin|
|[21802eb06e2b05b5db40381f296d67ad](https://www.virustotal.com/gui/file/21802eb06e2b05b5db40381f296d67ad)|Win64 DLL||2017-02-01 18:13:54|MSIMGHLP.DLL|
|[b4096859121998c065896d3d19e46e50](https://www.virustotal.com/gui/file/b4096859121998c065896d3d19e46e50)|Win64 DLL|turla|2017-02-01 18:07:50|MSIMGHLP.DLL|
|[05d07279ed123b3a9170fa2c540d2919](https://www.virustotal.com/gui/file/05d07279ed123b3a9170fa2c540d2919)|Text|Nemucod|2017-01-28 17:09:28|myvtfile.exe|
|[7ddee9311d7ab2d548e9b252383863ef](https://www.virustotal.com/gui/file/7ddee9311d7ab2d548e9b252383863ef)|Win32 DLL|turla|2017-01-17 15:09:50|SERVICE.DLL|
|[e664b6f5f50d1a7991e254e5e81a683f](https://www.virustotal.com/gui/file/e664b6f5f50d1a7991e254e5e81a683f)|Win32 DLL||2017-01-17 14:31:53|MSIMGHLP.DLL|
|[6e7991f93c53a58ba63a602b277e07f7](https://www.virustotal.com/gui/file/6e7991f93c53a58ba63a602b277e07f7)|DOC|turla|2016-11-28 10:55:17|d6e6eab05af60a496060d266f144e43f6d5d6ec1_National Day Reception|
|[f51ba5883a65a0f7cf6783a6490320d3](https://www.virustotal.com/gui/file/f51ba5883a65a0f7cf6783a6490320d3)|Win32 EXE||2016-08-05 15:12:43|upzcfl.exe|
|[9ff452a1f33d74a8eb38e00b577547f2](https://www.virustotal.com/gui/file/9ff452a1f33d74a8eb38e00b577547f2)|Win32 DLL||2016-07-24 05:41:41|9ff452a1f33d74a8eb38e00b577547f2.virus|
|[b6b671d6371ee30bfa208e01b12adc64](https://www.virustotal.com/gui/file/b6b671d6371ee30bfa208e01b12adc64)|Win32 DLL|dynamer|2016-06-14 15:23:18|2fde6ec829874d28_msvck.dll|
|[1fb407a20373f3970f08d3f3c086841d](https://www.virustotal.com/gui/file/1fb407a20373f3970f08d3f3c086841d)|Win64 DLL|turla|2016-05-05 22:28:18|KmSvc.DLL|
|[213ca4db4c2abd3b631da00c299d75ef](https://www.virustotal.com/gui/file/213ca4db4c2abd3b631da00c299d75ef)|Win64 EXE|turla|2016-05-05 22:27:17|SERVICE.EXE|
|[88f24b129e200c4f48852dcbb6e21daf](https://www.virustotal.com/gui/file/88f24b129e200c4f48852dcbb6e21daf)|Win32 DLL|Zbot|2016-04-28 21:41:53|88f24b129e200c4f48852dcbb6e21daf.virus|
|[278e56c4b171d4d8799b9a77c31e4484](https://www.virustotal.com/gui/file/278e56c4b171d4d8799b9a77c31e4484)|Win32 DLL|Zbot|2016-04-08 09:08:00|MSXIML.DLL|
|[3b28045c0636f455a3fdf75bd44256ba](https://www.virustotal.com/gui/file/3b28045c0636f455a3fdf75bd44256ba)|Win32 DLL|Zbot|2016-04-08 08:31:07|MSXIML.DLL|
|[d115532ed6189b3f74569f8012efe110](https://www.virustotal.com/gui/file/d115532ed6189b3f74569f8012efe110)|Win64 DLL|turla|2016-03-29 17:05:07|MSIMGHLP.DLL|
|[1c84038a7aac6342894d5896a390913d](https://www.virustotal.com/gui/file/1c84038a7aac6342894d5896a390913d)|Win32 DLL|Zbot|2016-03-29 06:11:32|MSXIML.DLL|
|[4085820a53a7f8dd58d4ba5ecf94e42b](https://www.virustotal.com/gui/file/4085820a53a7f8dd58d4ba5ecf94e42b)|Win64 DLL|turla|2016-03-22 19:04:14|myfile.exe|
|[13a81d857610d05f387c1aa86b4b49b9](https://www.virustotal.com/gui/file/13a81d857610d05f387c1aa86b4b49b9)|Win32 DLL|Zbot|2016-03-22 17:22:00|MSXIML.DLL|
|[8d4f71c3ec9a7a52904bbf30d0ad7f07](https://www.virustotal.com/gui/file/8d4f71c3ec9a7a52904bbf30d0ad7f07)|Win64 DLL||2015-12-04 20:06:18|SHDOCVW.DLL|
|[f86afb092e4b1a364ed6f6bc7f81db74](https://www.virustotal.com/gui/file/f86afb092e4b1a364ed6f6bc7f81db74)|Win32 DLL|turla|2015-08-18 14:20:11|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[7731d42b043865559258464fe1c98513](https://www.virustotal.com/gui/file/7731d42b043865559258464fe1c98513)|Win32 EXE|razy|2015-04-09 09:52:15|xxuo.exe|
|[2a7670aa9d1cc64e61fd50f9f64296f9](https://www.virustotal.com/gui/file/2a7670aa9d1cc64e61fd50f9f64296f9)|Win32 EXE|turla|2015-02-17 18:32:05|smbinst|
|[dd5c6199cef69d4e2a1795e481d5f87d](https://www.virustotal.com/gui/file/dd5c6199cef69d4e2a1795e481d5f87d)|PNG||2015-02-07 22:43:27|badhash|
|[42b7b0bd4795fc8e336e1f145fc2d27c](https://www.virustotal.com/gui/file/42b7b0bd4795fc8e336e1f145fc2d27c)|Win32 EXE||2015-01-26 11:53:44|btwcb.exe|
|[19fbd8cbfb12482e8020a887d6427315](https://www.virustotal.com/gui/file/19fbd8cbfb12482e8020a887d6427315)|ELF executable|turla|2014-12-06 13:35:37|/home/wys/botnet/botnet-procedure/44|
|[0994d9deb50352e76b0322f48ee576c6](https://www.virustotal.com/gui/file/0994d9deb50352e76b0322f48ee576c6)|ELF executable|turla|2014-11-19 12:41:40|Turla_linux_0994d9deb50352e76b0322f48ee576c6|
|[14ecd5e6fc8e501037b54ca263896a11](https://www.virustotal.com/gui/file/14ecd5e6fc8e501037b54ca263896a11)|ELF executable|turla|2014-11-19 12:35:57|Turla_linux_14ecd5e6fc8e501037b54ca263896a11|
|[c0c03b71684eb0545ef9182f5f9928ca](https://www.virustotal.com/gui/file/c0c03b71684eb0545ef9182f5f9928ca)|Win32 EXE||2014-11-07 20:20:35|dsquery.exe|
|[b407b6e5b4046da226d6e189a67f62ca](https://www.virustotal.com/gui/file/b407b6e5b4046da226d6e189a67f62ca)|Win32 DLL|turla|2014-10-17 11:03:11|cryptsp.dll|
|[255118ac14a9e66124f7110acd16f2cd](https://www.virustotal.com/gui/file/255118ac14a9e66124f7110acd16f2cd)|Win32 DLL|turla|2014-10-17 11:03:10|SHDOCVW.DLL|
|[0ae421691579ff6b27f65f49e79e88f6](https://www.virustotal.com/gui/file/0ae421691579ff6b27f65f49e79e88f6)|Win32 EXE|turla|2014-10-17 11:02:38|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\0AE421691579FF6B27F65F49E79E88F6|
|[ea23d67e41d1f0a7f7e7a8b59e7cb60f](https://www.virustotal.com/gui/file/ea23d67e41d1f0a7f7e7a8b59e7cb60f)|Win64 DLL||2014-09-22 18:20:42|MSXIML.DLL|
|[498f9aa4992782784f49758c81679d0a](https://www.virustotal.com/gui/file/498f9aa4992782784f49758c81679d0a)|Win32 DLL|Bedep|2014-09-04 08:30:24|charmap|
|[81371773630098af082d714501683c70](https://www.virustotal.com/gui/file/81371773630098af082d714501683c70)|Win32 EXE||2014-09-01 20:10:16|wmkt.exe|
|[030f5fdb78bfc1ce7b459d3cc2cf1877](https://www.virustotal.com/gui/file/030f5fdb78bfc1ce7b459d3cc2cf1877)|Win32 EXE||2014-09-01 12:07:55|exeview.exe|
|[e481f5ea90d684e5986e70e6338539b4](https://www.virustotal.com/gui/file/e481f5ea90d684e5986e70e6338539b4)|ZIP|java|2014-08-24 02:21:08|z:\volatile\buncak\f30\7345cf599705e0bc1b60cba5cc0168c099c9252f33d85d8c7c965c4580a5ccd9.log|
|[f41077c4734ef27dec41c89223136cf8](https://www.virustotal.com/gui/file/f41077c4734ef27dec41c89223136cf8)|ZIP|java|2014-08-23 23:30:24|z:\volatile\buncak\f30\59769fc465ab06160bf8800b92e79dd97fb98e7620496b915d1a0161d3d3cb80.log|
|[21cbc17b28126b88b954b3b123958b46](https://www.virustotal.com/gui/file/21cbc17b28126b88b954b3b123958b46)|ZIP|java|2014-08-23 11:59:13|z:\volatile\buncak\f30\15bbea27b10b1746d3aa4c1ae70b03bd196d8f8b9942f9f635f4e5d336fb81ec.log|
|[66962d3e0f00e7713c0e1483b4bf4b19](https://www.virustotal.com/gui/file/66962d3e0f00e7713c0e1483b4bf4b19)|Win32 DLL||2014-08-20 08:58:13|vti-rescan|
|[15060a4b998d8e288589d31ccd230f86](https://www.virustotal.com/gui/file/15060a4b998d8e288589d31ccd230f86)|HTML||2014-08-12 18:29:59|71ce639d45b68c1f9ff12e477d8d8da6d6f45dde|
|[acae4a875cd160c015adfdea57bd62c4](https://www.virustotal.com/gui/file/acae4a875cd160c015adfdea57bd62c4)|HTML||2014-08-12 18:29:56|4c0e3022e5acb5563fbbcb6420be51634ba6fddc|
|[536eca0defc14eff0a38b64c74e03c79](https://www.virustotal.com/gui/file/536eca0defc14eff0a38b64c74e03c79)|HTML||2014-08-12 18:29:55|isheriff_536eca0defc14eff0a38b64c74e03c79.bin|
|[1369fee289fe7798a02cde100a5e91d8](https://www.virustotal.com/gui/file/1369fee289fe7798a02cde100a5e91d8)|Win32 EXE||2014-08-10 11:12:40|dsquery.exe|
|[a3cbf6179d437909eb532b7319b3dafe](https://www.virustotal.com/gui/file/a3cbf6179d437909eb532b7319b3dafe)|Win32 EXE|keylogger|2014-08-08 06:49:17|vti-rescan|
|[4c1017de62ea4788c7c8058a8f825a2d](https://www.virustotal.com/gui/file/4c1017de62ea4788c7c8058a8f825a2d)|Win32 DLL||2014-08-04 08:51:52|SERVICE.DLL|
|[244505129d96be57134cb00f27d4359c](https://www.virustotal.com/gui/file/244505129d96be57134cb00f27d4359c)|Win64 DLL||2014-08-04 08:51:50|MSIMGHLP.DLL|
|[91a5594343b47462ebd6266a9c40abbe](https://www.virustotal.com/gui/file/91a5594343b47462ebd6266a9c40abbe)|Win64 DLL||2014-08-04 08:51:49|KmSvc.DLL|
|[4ae7e6011b550372d2a73ab3b4d67096](https://www.virustotal.com/gui/file/4ae7e6011b550372d2a73ab3b4d67096)|Win64 DLL||2014-08-04 08:51:48|MSXIML.DLL|
|[43e896ede6fe025ee90f7f27c6d376a4](https://www.virustotal.com/gui/file/43e896ede6fe025ee90f7f27c6d376a4)|Win32 DLL||2014-08-04 08:51:47|KmSvc.DLL|
|[554450c1ecb925693fedbb9e56702646](https://www.virustotal.com/gui/file/554450c1ecb925693fedbb9e56702646)|Win32 DLL||2014-08-04 08:51:46|MSXIML.DLL|
|[df230db9bddf200b24d8744ad84d80e8](https://www.virustotal.com/gui/file/df230db9bddf200b24d8744ad84d80e8)|Win64 DLL||2014-08-04 08:51:45|SERVICE.DLL|
|[e6d1dcc6c2601e592f2b03f35b06fa8f](https://www.virustotal.com/gui/file/e6d1dcc6c2601e592f2b03f35b06fa8f)|Win32 DLL||2014-08-04 08:51:44|MSIMGHLP.DLL|
|[cb1b68d9971c2353c2d6a8119c49b51f](https://www.virustotal.com/gui/file/cb1b68d9971c2353c2d6a8119c49b51f)|Win32 EXE||2014-08-04 08:51:11|SERVICE.EXE|
|[071d3b60ebec2095165b6879e41211f2](https://www.virustotal.com/gui/file/071d3b60ebec2095165b6879e41211f2)|Win32 DLL|Symmi|2014-08-04 08:30:17|e9580b6b13822090db018c320e80865f_1cdb29a9d92fb5c141b2c4808a2b5548_undefined.exe_254.exe|
|[e9580b6b13822090db018c320e80865f](https://www.virustotal.com/gui/file/e9580b6b13822090db018c320e80865f)|Win32 EXE||2014-08-04 08:28:32|myfile.exe|
|[f3858dc203da418474b5033a912170c0](https://www.virustotal.com/gui/file/f3858dc203da418474b5033a912170c0)|Win32 DLL|Bedep|2014-08-03 16:54:48|charmap|
|[199fa4ef7c88271882d81618d82acd0a](https://www.virustotal.com/gui/file/199fa4ef7c88271882d81618d82acd0a)|Win32 DLL|turla|2014-07-28 11:38:55|driver.8500c000.sys|
|[c62e2197ac81347459e07d6b350be93a](https://www.virustotal.com/gui/file/c62e2197ac81347459e07d6b350be93a)|Win32 DLL|turla|2014-07-25 15:33:56|7245f21b632f0fa627e02f254e464b9debc7a179|
|[4bd507e64c289d6687901baf16f6bbd7](https://www.virustotal.com/gui/file/4bd507e64c289d6687901baf16f6bbd7)|Win32 DLL|graftor|2014-07-25 07:36:08|f48710f2a94e79563b0311f7087b237fbac5a2a8|
|[60ec7a1c72f0775561819aa7681cf1ac](https://www.virustotal.com/gui/file/60ec7a1c72f0775561819aa7681cf1ac)|Win32 DLL|turla|2014-07-25 07:33:52|6f08bad370fa023c02620d2d8a81c2c556bcd96d|
|[22d01fa2725ad7a83948f399144563f9](https://www.virustotal.com/gui/file/22d01fa2725ad7a83948f399144563f9)|Win32 DLL||2014-07-24 15:26:03|process.0x842634c0.0x3530000.dmp|
|[c0a2e3f9af9e227252428df59777fc47](https://www.virustotal.com/gui/file/c0a2e3f9af9e227252428df59777fc47)|Win32 EXE||2014-07-22 20:47:35|0ac463de10eaf57c_vmdev.exe|
|[18da7eea4e8a862a19c8c4f10d7341c0](https://www.virustotal.com/gui/file/18da7eea4e8a862a19c8c4f10d7341c0)|Win32 DLL||2014-07-20 09:03:49|AMStream|
|[d5bd7211332d31dcead4bfb07b288473](https://www.virustotal.com/gui/file/d5bd7211332d31dcead4bfb07b288473)|Win32 EXE|turla|2014-07-16 05:57:55|smbinst|
|[0e441602449856e57d1105496023f458](https://www.virustotal.com/gui/file/0e441602449856e57d1105496023f458)|Win32 EXE|razy|2014-06-24 02:11:11|fwvkpvw.exe|
|[7c52c340ec5c6f57ef2fd174e6490433](https://www.virustotal.com/gui/file/7c52c340ec5c6f57ef2fd174e6490433)|Win32 EXE||2014-06-23 18:09:21|exeview.exe|
|[e224fd7563b9c7893566018204be820c](https://www.virustotal.com/gui/file/e224fd7563b9c7893566018204be820c)|Win32 DLL|turla|2014-06-04 09:02:03|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[edd5fd7cf3b22fa4ea956d1a447520ff](https://www.virustotal.com/gui/file/edd5fd7cf3b22fa4ea956d1a447520ff)|Win64 DLL||2014-04-30 11:07:57|C:\Users\admin\Desktop\123 - 副本\ED785.sys|
|[594cb9523e32a5bbf4eb1c491f06d4f9](https://www.virustotal.com/gui/file/594cb9523e32a5bbf4eb1c491f06d4f9)|Win32 DLL|Symmi|2014-04-30 03:02:06|/home/virustotal/sample/594CB9523E32A5BBF4EB1C491F06D4F9|
|[5036c44fbe7a99a0bddc9f05f7e9df77](https://www.virustotal.com/gui/file/5036c44fbe7a99a0bddc9f05f7e9df77)|Win32 DLL|turla|2014-04-14 11:15:37|F:\unpacked_driver\Malware_driver.b1bdd000.sys|
|[e1ee88eda1d399822587eb58eac9b347](https://www.virustotal.com/gui/file/e1ee88eda1d399822587eb58eac9b347)|Win64 DLL|razy|2014-03-23 21:27:06|dll.dll|
|[a7853bab983ede28959a30653baec74a](https://www.virustotal.com/gui/file/a7853bab983ede28959a30653baec74a)|Win64 DLL|turla|2014-03-23 21:26:59|dll_2.dll|
|[2b47ad7df9902aaa19474723064ee76f](https://www.virustotal.com/gui/file/2b47ad7df9902aaa19474723064ee76f)|Win64 DLL|turla|2014-03-14 16:08:42|decrypted_inj_snake_x64.dll.exe|
|[b46c792c8e051bc5c9d4cecab96e4c30](https://www.virustotal.com/gui/file/b46c792c8e051bc5c9d4cecab96e4c30)|Win64 DLL|turla|2014-03-14 16:08:06|myfile.exe|
|[ea1c266eec718323265c16b1fdc92dac](https://www.virustotal.com/gui/file/ea1c266eec718323265c16b1fdc92dac)|Win32 EXE||2014-03-14 10:59:52|btwcb.exe|
|[5f8f3cf46719afa7eb5f761cdd18b63d](https://www.virustotal.com/gui/file/5f8f3cf46719afa7eb5f761cdd18b63d)|Win64 DLL|turla|2014-03-14 06:53:24|myfile.exe|
|[f57c84e22e9e6eaa6cbd9730d7c652dc](https://www.virustotal.com/gui/file/f57c84e22e9e6eaa6cbd9730d7c652dc)|Win32 DLL|turla|2014-03-14 04:50:17|myfile.exe|
|[3c1a8991e96f4c56ae3e90fb6f0ae679](https://www.virustotal.com/gui/file/3c1a8991e96f4c56ae3e90fb6f0ae679)|Win32 DLL|turla|2014-03-14 04:44:16|3c1a8991e96f4c56ae3e90fb6f0ae679_decrypted_rkctl_Win32.dll|
|[24ad996024bb9b2321550abf348e009d](https://www.virustotal.com/gui/file/24ad996024bb9b2321550abf348e009d)|Win64 DLL|turla|2014-03-13 17:52:23|e2e5cc06f3814c48a14af0a587c947eb098f3803383fe8ac3162ab1027f991f9.vir|
|[8cd392a5b62c44dd88c6b847db428fba](https://www.virustotal.com/gui/file/8cd392a5b62c44dd88c6b847db428fba)|Win32 DLL|turla|2014-03-13 16:53:11|charmap|
|[1538246b770e215781e730297cedb071](https://www.virustotal.com/gui/file/1538246b770e215781e730297cedb071)|Win32 DLL|turla|2014-03-13 16:52:56|charmap|
|[a762d2c56999eda5316d0f94aba940cb](https://www.virustotal.com/gui/file/a762d2c56999eda5316d0f94aba940cb)|Win32 DLL|Bedep|2014-03-13 16:52:55|charmap|
|[1d4ec94509aa1cb53148eb715facae76](https://www.virustotal.com/gui/file/1d4ec94509aa1cb53148eb715facae76)|Win32 DLL||2014-03-08 14:48:08|1D4EC94509AA1CB53148EB715FACAE76|
|[d31f1d873fa3591c027b54c2aa76a52b](https://www.virustotal.com/gui/file/d31f1d873fa3591c027b54c2aa76a52b)|Win32 EXE||2014-03-07 20:14:37|flmover.exe|
|[e183bfd93326f77f7596dcc41064a7c8](https://www.virustotal.com/gui/file/e183bfd93326f77f7596dcc41064a7c8)|Win64 DLL||2014-03-06 23:34:18|fdisk_decrypted.sys|
|[c58ab0bec0ebaa0440e1f64aa9dd91b3](https://www.virustotal.com/gui/file/c58ab0bec0ebaa0440e1f64aa9dd91b3)|Win64 DLL||2014-03-06 02:20:06|charmap|
|[ea3d1ee0dd5da37862ba81f468c44d2a](https://www.virustotal.com/gui/file/ea3d1ee0dd5da37862ba81f468c44d2a)|Win64 DLL||2014-03-06 02:19:36|charmap|
|[10254385e980f8b0784e13a5153e4f17](https://www.virustotal.com/gui/file/10254385e980f8b0784e13a5153e4f17)|Win64 DLL||2014-03-06 02:19:12|charmap|
|[368d20edfd287e5ea3bb664a90e1a95e](https://www.virustotal.com/gui/file/368d20edfd287e5ea3bb664a90e1a95e)|DOS EXE||2014-03-05 15:22:30|eb625dbe9c2d37b076a6eb0d67e5f0be9b16f74a|
|[626955d20325371aca2742a70d6861ab](https://www.virustotal.com/gui/file/626955d20325371aca2742a70d6861ab)|Win32 EXE||2014-03-05 15:21:40|vti-rescan|
|[8cf1c23e71783a4fb00005e569253d6d](https://www.virustotal.com/gui/file/8cf1c23e71783a4fb00005e569253d6d)|Win32 DLL|turla|2014-03-05 15:21:21|charmap|
|[83b9eeffc9aad9d777dd9a7654b3637e](https://www.virustotal.com/gui/file/83b9eeffc9aad9d777dd9a7654b3637e)|Win32 DLL|turla|2014-03-05 07:21:47|vdm.dll|
|[a22150576ca5c95c163fea4e4e750164](https://www.virustotal.com/gui/file/a22150576ca5c95c163fea4e4e750164)|Win32 DLL|turla|2014-03-05 07:21:40|vti-rescan|
|[5ede9cb859b40fb01cf1efb6ad32a5f1](https://www.virustotal.com/gui/file/5ede9cb859b40fb01cf1efb6ad32a5f1)|Win32 DLL|turla|2014-03-04 20:30:20|1000|
|[380bb5b8c750c7252948dc08901c0487](https://www.virustotal.com/gui/file/380bb5b8c750c7252948dc08901c0487)|Win32 DLL|turla|2014-03-04 20:30:05|3000|
|[921ad714e7fb01aaa8e9b960544e0d36](https://www.virustotal.com/gui/file/921ad714e7fb01aaa8e9b960544e0d36)|Win64 DLL|turla|2014-03-04 19:31:35|161|
|[209bfa50786096328934ad1dc62a4ec3](https://www.virustotal.com/gui/file/209bfa50786096328934ad1dc62a4ec3)|Win32 DLL|turla|2014-03-04 16:31:55|4000|
|[5cc5989e870b23915280aee310669ccb](https://www.virustotal.com/gui/file/5cc5989e870b23915280aee310669ccb)|Win32 DLL|turla|2014-03-04 12:30:11|5ab10be672d1e3bd68821de994394d889eee77cf.codex|
|[6095f71f699ff30bba2321d433e91e1d](https://www.virustotal.com/gui/file/6095f71f699ff30bba2321d433e91e1d)|Win32 EXE|turla|2014-03-04 12:28:49|1002-4d07186fbe64aa1959eb0740af0d86f85a74bf2b|
|[d22b0ec4e9b2302c07f38c835a78148a](https://www.virustotal.com/gui/file/d22b0ec4e9b2302c07f38c835a78148a)|Win32 EXE|razy|2014-03-04 12:21:43|unlji.exe|
|[80323d1f7033bf33875624914a6a6010](https://www.virustotal.com/gui/file/80323d1f7033bf33875624914a6a6010)|Win32 EXE|ipatre|2014-03-04 12:21:09|vti-rescan|
|[77083b1709681d43a1b0503057b6f096](https://www.virustotal.com/gui/file/77083b1709681d43a1b0503057b6f096)|Win32 EXE|ipatre|2014-03-04 04:34:06|vti-rescan|
|[3de8301147da3199e422b28bb782e2a9](https://www.virustotal.com/gui/file/3de8301147da3199e422b28bb782e2a9)|Win32 DLL||2014-03-03 03:33:05|vti-rescan|
|[335387e729499ff7d46c25477e9c8c5a](https://www.virustotal.com/gui/file/335387e729499ff7d46c25477e9c8c5a)|Win32 DLL|turla|2014-03-03 01:15:19|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[eb621eeecafd25a15e999fe786470bf4](https://www.virustotal.com/gui/file/eb621eeecafd25a15e999fe786470bf4)|Win64 DLL||2014-03-01 20:28:49|charmap|
|[465eed02d1646a3ad20c43b9f0bbe2e9](https://www.virustotal.com/gui/file/465eed02d1646a3ad20c43b9f0bbe2e9)|Win64 DLL||2014-03-01 20:28:25|charmap|
|[4535025837bebae7a04eb744383a82d7](https://www.virustotal.com/gui/file/4535025837bebae7a04eb744383a82d7)|Win32 DLL|turla|2014-03-01 12:28:41|charmap|
|[bb4e92c27d52fb8514a133629c4c7b05](https://www.virustotal.com/gui/file/bb4e92c27d52fb8514a133629c4c7b05)|Win32 DLL|turla|2014-03-01 12:28:12|charmap|
|[a231056fcc095d0f853e49f47988e46e](https://www.virustotal.com/gui/file/a231056fcc095d0f853e49f47988e46e)|Win64 DLL||2014-03-01 12:28:02|charmap|
|[ee58e5434b0cabaff8aba84ed1526d8d](https://www.virustotal.com/gui/file/ee58e5434b0cabaff8aba84ed1526d8d)|Win32 DLL|turla|2014-03-01 12:27:55|charmap|
|[d4fb3ec5951a89a573445058012d7dcd](https://www.virustotal.com/gui/file/d4fb3ec5951a89a573445058012d7dcd)|Win32 DLL|turla|2014-03-01 12:23:36|charmap|
|[1c6c857fa17ef0aa3373ff16084f2f1c](https://www.virustotal.com/gui/file/1c6c857fa17ef0aa3373ff16084f2f1c)|Win32 DLL|turla|2014-03-01 12:23:15|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[8c4029bbd9dfb1093fb9cca3db01f8ff](https://www.virustotal.com/gui/file/8c4029bbd9dfb1093fb9cca3db01f8ff)|Win32 DLL|turla|2014-03-01 12:23:00|charmap|
|[119f2d545b167745fc6f71aed1f117f6](https://www.virustotal.com/gui/file/119f2d545b167745fc6f71aed1f117f6)|Win32 DLL|turla|2014-03-01 12:22:49|charmap|
|[b2a9326bc421581dc60a03b97ee7ffce](https://www.virustotal.com/gui/file/b2a9326bc421581dc60a03b97ee7ffce)|Win32 DLL|turla|2014-02-25 01:43:40|ef444eaef804955cb7a5902e30b43201c3d45c0f35aaa0b0ea73f3af916688ae.sys|
|[9bec941bec02c7fbe037a97db8c89f18](https://www.virustotal.com/gui/file/9bec941bec02c7fbe037a97db8c89f18)|Win32 EXE|Zbot|2014-02-21 20:32:38|Wextract|
|[7009af646c6c3e6abc0af744152ca968](https://www.virustotal.com/gui/file/7009af646c6c3e6abc0af744152ca968)|Win32 DLL|turla|2014-02-11 18:11:09|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/OutlookBackdoor2.bin|
|[440802107441b03f09921138303ca9e9](https://www.virustotal.com/gui/file/440802107441b03f09921138303ca9e9)|Win32 DLL|Symmi|2014-01-31 15:20:39|/home/virustotal/sample/440802107441B03F09921138303CA9E9|
|[2eb233a759642abaae2e3b29b7c85b89](https://www.virustotal.com/gui/file/2eb233a759642abaae2e3b29b7c85b89)|Win32 DLL|Symmi|2014-01-29 07:40:12|/home/virustotal/sample/2EB233A759642ABAAE2E3B29B7C85B89|
|[ab686acde338c67bec8ab42519714273](https://www.virustotal.com/gui/file/ab686acde338c67bec8ab42519714273)|Win32 EXE|razy|2014-01-15 15:06:57|ipqh.exe|
|[1c3634c7777bd6667936ec279bac5c2a](https://www.virustotal.com/gui/file/1c3634c7777bd6667936ec279bac5c2a)|Win32 EXE|ipatre|2014-01-15 07:03:03|vti-rescan|
|[4d667af648047f2bd24511ef8f36c9cc](https://www.virustotal.com/gui/file/4d667af648047f2bd24511ef8f36c9cc)|Win32 EXE|ipatre|2014-01-15 07:03:03|vti-rescan|
|[dc37cba3e8699062b4346fd21f83de81](https://www.virustotal.com/gui/file/dc37cba3e8699062b4346fd21f83de81)|Win32 EXE|kazy|2014-01-09 20:52:57|btwcb.exe|
|[fdba4370b60eda1ee852c6515da9da58](https://www.virustotal.com/gui/file/fdba4370b60eda1ee852c6515da9da58)|Win32 EXE|razy|2013-12-23 06:26:18|xxuo.exe|
|[3ab3d463575a011dfad630da154600b5](https://www.virustotal.com/gui/file/3ab3d463575a011dfad630da154600b5)|Win32 EXE|razy|2013-12-18 22:43:55|xxuo.exe|
|[dba209c99df5e94c13b1f44c0f23ef2b](https://www.virustotal.com/gui/file/dba209c99df5e94c13b1f44c0f23ef2b)|PDF|cve-2013-5065|2013-12-09 16:49:56|dba209c99df5e94c13b1f44c0f23ef2b.pdf|
|[973fce2d142e1323156ff1ad3735e50d](https://www.virustotal.com/gui/file/973fce2d142e1323156ff1ad3735e50d)|Win32 DLL|turla|2013-12-05 13:29:00|/home/virustotal/sample/973FCE2D142E1323156FF1AD3735E50D|
|[cd962320f5b1619b1c1773de235bda63](https://www.virustotal.com/gui/file/cd962320f5b1619b1c1773de235bda63)|Win32 DLL|turla|2013-12-04 13:11:49|msw32.sys|
|[6406ad8833bafec59a32be842245c7dc](https://www.virustotal.com/gui/file/6406ad8833bafec59a32be842245c7dc)|Win32 DLL|turla|2013-12-03 09:55:22|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[24b354f8cfb6a181906ceaf9a7ec28b0](https://www.virustotal.com/gui/file/24b354f8cfb6a181906ceaf9a7ec28b0)|Win32 EXE||2013-12-02 23:10:06|24b354f8cfb6a181906ceaf9a7ec28b0.virobj|
|[4c65126ae52cadb76ca1a9cfb8b4ce74](https://www.virustotal.com/gui/file/4c65126ae52cadb76ca1a9cfb8b4ce74)|PDF||2013-11-29 20:31:08|4c65126ae52cadb76ca1a9cfb8b4ce74.pdf|
|[f44b1dea7e56b5eac95c12732d9d6435](https://www.virustotal.com/gui/file/f44b1dea7e56b5eac95c12732d9d6435)|PDF||2013-11-29 10:02:36|f44b1dea7e56b5eac95c12732d9d6435.pdf|
|[d102e873971aa4190a809039bc789e4d](https://www.virustotal.com/gui/file/d102e873971aa4190a809039bc789e4d)|Win32 EXE|kazy|2013-11-29 02:00:42|btwcb.exe|
|[111ed2f02d8af54d0b982d8c9dd4932e](https://www.virustotal.com/gui/file/111ed2f02d8af54d0b982d8c9dd4932e)|Win32 EXE|kazy|2013-11-08 06:34:57|btwcb.exe|
|[6776bda19a3a8ed4c2870c34279dbaa9](https://www.virustotal.com/gui/file/6776bda19a3a8ed4c2870c34279dbaa9)|PDF||2013-11-07 10:48:56|malicious-6776bda19a.pdf|
|[40aa66d9600d82e6c814b5307c137be5](https://www.virustotal.com/gui/file/40aa66d9600d82e6c814b5307c137be5)|Win32 DLL|turla|2013-09-23 04:15:15|25407|
|[5129c26818ef712bde318dff970eba8d](https://www.virustotal.com/gui/file/5129c26818ef712bde318dff970eba8d)|Win32 EXE|Zbot|2013-08-28 09:08:10|Wextract|
|[eaea9ccb40c82af8f3867cd0f4dd5e9d](https://www.virustotal.com/gui/file/eaea9ccb40c82af8f3867cd0f4dd5e9d)|Win64 EXE||2013-08-08 16:57:08|<DRIVERS>\vboxdrv.sys|
|[a86ac0ad1f8928e8d4e1b728448f54f9](https://www.virustotal.com/gui/file/a86ac0ad1f8928e8d4e1b728448f54f9)|Win32 EXE|turla|2013-08-07 10:09:41|charmap|
|[f156ff2a1694f479a079f6777f0c5af0](https://www.virustotal.com/gui/file/f156ff2a1694f479a079f6777f0c5af0)|Win64 EXE||2013-07-29 17:10:24|2.dll|
|[ed785bbd156b61553aaf78b6f71fb37b](https://www.virustotal.com/gui/file/ed785bbd156b61553aaf78b6f71fb37b)|Win64 DLL|turla|2013-07-24 11:30:33|/home/virustotal/sample/ED785BBD156B61553AAF78B6F71FB37B|
|[2786525baa5f2f2569ca15caff1ebf86](https://www.virustotal.com/gui/file/2786525baa5f2f2569ca15caff1ebf86)|DOS EXE|turla|2013-07-22 18:10:44|91ed5b048899d54995fa7fe53cee57596288406407ea692457ae7ee95866aeee.exe|
|[626576e5f0f85d77c460a322a92bb267](https://www.virustotal.com/gui/file/626576e5f0f85d77c460a322a92bb267)|Win32 EXE|turla|2013-07-18 16:24:46|charmap|
|[90478f6ed92664e0a6e6a25ecfa8e395](https://www.virustotal.com/gui/file/90478f6ed92664e0a6e6a25ecfa8e395)|Win64 DLL|turla|2013-07-18 16:23:02|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[b329095db961cf3b54d9acb48a3711da](https://www.virustotal.com/gui/file/b329095db961cf3b54d9acb48a3711da)|Win32 DLL|dynamer|2013-07-18 10:59:05|/home/virustotal/sample/B329095DB961CF3B54D9ACB48A3711DA|
|[038f0e564c06a817e8a53d054406383e](https://www.virustotal.com/gui/file/038f0e564c06a817e8a53d054406383e)|Win32 DLL|turla|2013-07-17 12:58:38|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[5ce3455b85f2e8738a9aceb815b48aee](https://www.virustotal.com/gui/file/5ce3455b85f2e8738a9aceb815b48aee)|Win32 DLL|turla|2013-07-16 17:31:35|/home/virustotal/sample/5CE3455B85F2E8738A9ACEB815B48AEE|
|[53b59dffce657b59872278433f9244a2](https://www.virustotal.com/gui/file/53b59dffce657b59872278433f9244a2)|Win32 DLL||2013-05-08 08:53:30|beac78638a18b7de1861845797ff3adfae22607dceee42b99e17d191045244ed.dll|
|[ff64031d8e34243636ae725e8f9bbe8b](https://www.virustotal.com/gui/file/ff64031d8e34243636ae725e8f9bbe8b)|Win32 DLL|turla|2013-04-10 14:55:43|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[4f901461bb8fa1369f85a7effd1787f1](https://www.virustotal.com/gui/file/4f901461bb8fa1369f85a7effd1787f1)|Win32 DLL|graftor|2013-01-27 09:09:10|cryptapi32.dll|
|[e5a9fc45ab11dd0845508d122a6c8c8c](https://www.virustotal.com/gui/file/e5a9fc45ab11dd0845508d122a6c8c8c)|Win32 EXE||2012-11-23 08:46:21|e5a9fc45ab11dd0845508d122a6c8c8c|
|[fb56ce4b853a94ae3f64367c02ec7e31](https://www.virustotal.com/gui/file/fb56ce4b853a94ae3f64367c02ec7e31)|Win32 EXE|turla|2012-11-08 07:59:35|vti-rescan|
|[eb40189cde69d60ca6f9a3f0531dbc5e](https://www.virustotal.com/gui/file/eb40189cde69d60ca6f9a3f0531dbc5e)|Win32 EXE||2012-07-20 08:34:57|vti-rescan|
|[f4f192004df1a4723cb9a8b4a9eb2fbf](https://www.virustotal.com/gui/file/f4f192004df1a4723cb9a8b4a9eb2fbf)|Win32 DLL|turla|2012-07-02 13:30:27|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[9af488ce67be89b3908931fe4ab21831](https://www.virustotal.com/gui/file/9af488ce67be89b3908931fe4ab21831)|Win32 DLL|graftor|2012-03-31 08:25:42|cryptapi32.dll|
|[e32d9e04c04c0c7e497905b5dcba7e50](https://www.virustotal.com/gui/file/e32d9e04c04c0c7e497905b5dcba7e50)|Win32 DLL|turla|2012-02-24 02:08:11|e32d9e04c04c0c7e497905b5dcba7e50.virobj|
|[320f4e6ee421c1616bd058e73cfea282](https://www.virustotal.com/gui/file/320f4e6ee421c1616bd058e73cfea282)|Win32 DLL|turla|2011-10-20 10:35:27|PH 3.0 MS_V98 V564 bw02 - RTC07|
|[2145945b9b32b4ccbd498db50419b39b](https://www.virustotal.com/gui/file/2145945b9b32b4ccbd498db50419b39b)|Win32 DLL|turla|2011-06-21 23:32:24|3de0ba77fa2d8b26e4226fd28edc3ab8448434d851f6b2b268ec072c5da92ade.bin|
|[938b92958ded4d50a357d22eddf141ad](https://www.virustotal.com/gui/file/938b92958ded4d50a357d22eddf141ad)|Win32 EXE||2010-10-18 00:43:37|charmap.exe|
|[20c9df1e5f426f9eb7461cd99d406904](https://www.virustotal.com/gui/file/20c9df1e5f426f9eb7461cd99d406904)|Win32 EXE||2010-10-09 07:45:56|vti-rescan|
|[a67311ec502593630307a5f3c220dc59](https://www.virustotal.com/gui/file/a67311ec502593630307a5f3c220dc59)|Win32 DLL|turla|2010-10-07 18:14:22|74b0c62737f43b0138cfae0d0972178a14fbea10_cryptoapi.dl|
|[98de96dfa10f7e8f437fbd4d12872bc1](https://www.virustotal.com/gui/file/98de96dfa10f7e8f437fbd4d12872bc1)|Win32 DLL||2010-09-25 00:27:10|commodule.dll|
|[dee81c3b22e98abbf941eaf0ae9c5478](https://www.virustotal.com/gui/file/dee81c3b22e98abbf941eaf0ae9c5478)|Win32 DLL||2010-09-24 22:42:10|commodule.dll|
|[bf0e4d46a51f27493cbe47e1cfb1b2ea](https://www.virustotal.com/gui/file/bf0e4d46a51f27493cbe47e1cfb1b2ea)|Win32 EXE|turla|2010-09-16 20:47:22|MSNET|
|[d664e4f660eb1f47e9879492c12d1042](https://www.virustotal.com/gui/file/d664e4f660eb1f47e9879492c12d1042)|Win32 DLL|cridex|2010-07-19 08:24:29|commodule.dll|
|[342700f8d9c1d23f3987df18db68cb4d](https://www.virustotal.com/gui/file/342700f8d9c1d23f3987df18db68cb4d)|Win32 DLL|turla|2010-06-07 11:51:43|isheriff_342700f8d9c1d23f3987df18db68cb4d.bin|
|[d686ce4ed3c46c3476acf1be0a1324e6](https://www.virustotal.com/gui/file/d686ce4ed3c46c3476acf1be0a1324e6)|Win32 EXE|turla|2010-01-31 03:27:41|Wextract|
|[9a2f7e8fa0e5ccda88902ac5ea9f4713](https://www.virustotal.com/gui/file/9a2f7e8fa0e5ccda88902ac5ea9f4713)|Win32 DLL||2010-01-30 23:47:27|commodule.dll|
|[fa8715078d45101200a6e2bf7321aa04](https://www.virustotal.com/gui/file/fa8715078d45101200a6e2bf7321aa04)|unknown||2010-01-30 10:33:57|Reimage.ini|
|[2b61e8a11749bfb55d21b5d8441de5c9](https://www.virustotal.com/gui/file/2b61e8a11749bfb55d21b5d8441de5c9)|Win32 DLL||2010-01-26 08:40:36|msidfn32.dll|
|[e93f4dd907142db4b59bb736fc46f644](https://www.virustotal.com/gui/file/e93f4dd907142db4b59bb736fc46f644)|Win32 EXE||2009-12-24 16:43:11|atmarpd.sys|
|[ae3774fefba7557599fcc8af547cca70](https://www.virustotal.com/gui/file/ae3774fefba7557599fcc8af547cca70)|Win32 EXE||2009-10-27 23:04:43| |
|[5b4a956c6ec246899b1d459838892493](https://www.virustotal.com/gui/file/5b4a956c6ec246899b1d459838892493)|Win32 EXE|turla|2009-10-27 15:23:03|93742b415f28f57c61e7ce7d55208f71d5c4880dc66616da52f3c274b20b43b0|
|[db93128bff2912a75b39ee117796cdc6](https://www.virustotal.com/gui/file/db93128bff2912a75b39ee117796cdc6)|Win32 DLL||2009-10-27 15:21:28|db93128bff2912a75b39ee117796cdc6|
|[177e1ba54fc154774d103971964ee442](https://www.virustotal.com/gui/file/177e1ba54fc154774d103971964ee442)|Win32 DLL||2009-10-23 23:18:56|vti-rescan|
|[62e9839bf0b81d7774a3606112b318e8](https://www.virustotal.com/gui/file/62e9839bf0b81d7774a3606112b318e8)|Win64 DLL||2009-10-22 13:37:06|39050386f17b2d34bdbd118eec62ed6b2f386e21500a740362454ed73ea362e8|
|[22149a1ee21e6d60758fe58b34f04952](https://www.virustotal.com/gui/file/22149a1ee21e6d60758fe58b34f04952)|Win32 EXE|turla|2009-10-16 05:19:26|MSNET|
|[bc87546fea261dab3cd95a00953179b8](https://www.virustotal.com/gui/file/bc87546fea261dab3cd95a00953179b8)|Win32 DLL||2009-09-17 11:11:00|../../repo_all/repo_06/bc87546fea261dab3cd95a00953179b8|
|[db7a4925013b457d7c309ec10cfe257e](https://www.virustotal.com/gui/file/db7a4925013b457d7c309ec10cfe257e)|unknown||2008-06-04 17:50:16| |
|[c98a0d1909d8fad4110c8f35ee6f8391](https://www.virustotal.com/gui/file/c98a0d1909d8fad4110c8f35ee6f8391)|Win32 EXE||2008-05-07 00:01:47|0f5ec3b9535d4f95_~df81c3.tmp|
|[0328dedfce54e185ad395ac44aa4223c](https://www.virustotal.com/gui/file/0328dedfce54e185ad395ac44aa4223c)|Win32 EXE|turla|2007-12-19 19:06:59|Turla.bin|
|[150d0addf65b6524eb92b9762db6f074](https://www.virustotal.com/gui/file/150d0addf65b6524eb92b9762db6f074)|Win32 EXE|Razy|2020-10-06 08:28:49|Agent.exe|
|[122907a62a6ade198e94b87eed4b4810](https://www.virustotal.com/gui/file/122907a62a6ade198e94b87eed4b4810)|Win32 EXE|Turla|2020-09-14 10:21:45|Agent.exe|
|[869c9b1209009a6887f31ffb7c43fa04](https://www.virustotal.com/gui/file/869c9b1209009a6887f31ffb7c43fa04)|Win32 EXE|Turla|2020-09-11 07:50:01|%WINDIR%\adschemeintegrity.exe|
|[71f821c443d618cf40411b9a79e95d5c](https://www.virustotal.com/gui/file/71f821c443d618cf40411b9a79e95d5c)|Win32 EXE|Turla|2020-09-04 06:58:04|./KISA_dataset_2020_train/6ca0b4efe077fe05b2ae871bf50133c706c7090a54d2c3536a6c86ff454caa9a.vir|
|[277f2d8e682f7ffc071560f44af4ab41](https://www.virustotal.com/gui/file/277f2d8e682f7ffc071560f44af4ab41)|Win32 EXE|Razy|2020-07-28 06:16:45|DebugView.exe|
|[50c98af90563bae4f89219d50feba38f](https://www.virustotal.com/gui/file/50c98af90563bae4f89219d50feba38f)|Win64 DLL||2020-06-24 08:07:51|722fa0c893b39fef787b7bc277c979d29adc1525d77dd952f0cc61cd4d0597cc.bin|
|[e6d114379914a51c09949e37e1790f62](https://www.virustotal.com/gui/file/e6d114379914a51c09949e37e1790f62)|TXT||2020-06-18 13:04:43|97187123b80b1618f0d8afc2a5f84e9a17ac8e53a6e4ce8b0aa39fe06cec1f36.bin|
|[a6efd027b121347201a3de769389e6dd](https://www.virustotal.com/gui/file/a6efd027b121347201a3de769389e6dd)|Win64 EXE|Turla|2020-06-13 20:22:17|493e5fae191950b901764868b065ddddffa4f4c9b497022ee2f998b4a94f0fc2.bin|
|[03b236b23b1ec37c663527c1f53af3fe](https://www.virustotal.com/gui/file/03b236b23b1ec37c663527c1f53af3fe)|Win64 DLL||2020-06-05 19:18:00|lib3DXquery.dll|
|[1a78c735481095dad7576afae3b2fc4b](https://www.virustotal.com/gui/file/1a78c735481095dad7576afae3b2fc4b)|Win64 DLL||2020-06-04 14:07:58|WindowsHolographicService.dll|
|[2d3115ac3d96b29d9ba20e310a8e7457](https://www.virustotal.com/gui/file/2d3115ac3d96b29d9ba20e310a8e7457)|Win64 DLL||2020-06-03 10:15:52|QShvHost.bin|
|[c9c819991d4e6476e8f0307beed080b7](https://www.virustotal.com/gui/file/c9c819991d4e6476e8f0307beed080b7)|Win64 DLL||2020-05-29 11:28:24|WICACCESS.DLL|
|[e5a90e7e63ededbdd5ee13219bc93fce](https://www.virustotal.com/gui/file/e5a90e7e63ededbdd5ee13219bc93fce)|Win32 DLL||2020-05-29 11:27:54|WICACCESS.DLL|
|[3b10f20729d79ca3a92510674ff037c2](https://www.virustotal.com/gui/file/3b10f20729d79ca3a92510674ff037c2)|Win64 DLL||2020-05-29 11:27:13|MSCAPGPL.DLL|
|[2b35c299c96d17a1d4b09092b09bf692](https://www.virustotal.com/gui/file/2b35c299c96d17a1d4b09092b09bf692)|Win32 EXE|Turla|2020-04-06 02:33:16|WindowsFormsApplication2.exe|
|[e67ab185c7663939e78db5e77facb749](https://www.virustotal.com/gui/file/e67ab185c7663939e78db5e77facb749)|Win32 EXE|Turla|2020-04-06 00:25:13|Stub.exe|
|[2262bb56584a0e58193404e5fb3a8eed](https://www.virustotal.com/gui/file/2262bb56584a0e58193404e5fb3a8eed)|Win32 DLL||2020-02-27 15:39:01|MSJAVAVM|
|[07bf024a43c324dd2a4b8a8cf6e63480](https://www.virustotal.com/gui/file/07bf024a43c324dd2a4b8a8cf6e63480)|Win64 DLL|Razy|2020-02-12 11:58:21|C:\Users\jack\Desktop\dll_07BF024A43C324DD2A4B8A8CF6E63480.fil|
|[710da05065780eac2203b60e692b79e7](https://www.virustotal.com/gui/file/710da05065780eac2203b60e692b79e7)|Win32 DLL||2020-02-10 00:32:47|MSJAVAVM|
|[252ec60966a4e249d1fecbea52519438](https://www.virustotal.com/gui/file/252ec60966a4e249d1fecbea52519438)|Win32 DLL|occamy|2020-02-06 18:15:32|096FBD61.bin|
|[d1018c9860ab45185816f8c3aa2fa6cd](https://www.virustotal.com/gui/file/d1018c9860ab45185816f8c3aa2fa6cd)|Win32 DLL||2020-02-01 10:22:11|MSJAVAVM|
|[2c091aead3f99908a77597ad224295a6](https://www.virustotal.com/gui/file/2c091aead3f99908a77597ad224295a6)|Win64 DLL|Razy|2020-01-29 17:52:03|.|
|[899e28b6ec1f9c5ad2de5ab93d20e38d](https://www.virustotal.com/gui/file/899e28b6ec1f9c5ad2de5ab93d20e38d)|Win32 DLL||2020-01-24 21:11:44|MSJAVAVM|
|[79db9a7ca5c2f1ff0919b9b582734159](https://www.virustotal.com/gui/file/79db9a7ca5c2f1ff0919b9b582734159)|Win32 EXE|Turla|2020-01-23 08:08:27|Agent.Original.exe|
|[4181de1b2e03b20d6b7ad42efe6ec514](https://www.virustotal.com/gui/file/4181de1b2e03b20d6b7ad42efe6ec514)|Win32 DLL||2020-01-21 02:01:33|MSJAVAVM|
|[bc7bd81607aacb5a5198b988946cc29f](https://www.virustotal.com/gui/file/bc7bd81607aacb5a5198b988946cc29f)|Win32 DLL||2020-01-20 08:01:55|209326.dll|
|[0d1a72a9d89d8c08245e951ccdee7f0d](https://www.virustotal.com/gui/file/0d1a72a9d89d8c08245e951ccdee7f0d)|Win64 DLL|Razy|2020-01-03 07:08:26|CD6F5173.dll|
|[e36cbb7bdde4eb104d101b8d092b5c43](https://www.virustotal.com/gui/file/e36cbb7bdde4eb104d101b8d092b5c43)|Win32 EXE|Turla|2020-01-01 13:56:44|ETPhoneHome.exe|
|[10772c88a8053b3c73544feca1d040c3](https://www.virustotal.com/gui/file/10772c88a8053b3c73544feca1d040c3)|unknown||2019-12-21 04:00:32|.data|
|[ef49780995d9bab25bcb4b70bd206df4](https://www.virustotal.com/gui/file/ef49780995d9bab25bcb4b70bd206df4)|Win32 DLL|Turla|2019-12-19 05:40:03|ef49780995d9bab25bcb4b70bd206df4.virus|
|[fb3b84d2d28a599281afa3c32b2946f9](https://www.virustotal.com/gui/file/fb3b84d2d28a599281afa3c32b2946f9)|Win64 DLL||2019-12-11 14:14:08|018833609|
|[9cd8a8c58b076a355188038b34424bb2](https://www.virustotal.com/gui/file/9cd8a8c58b076a355188038b34424bb2)|Win64 DLL|Turla|2019-12-11 14:12:22|018833609|
|[55ba9886ff2ab87a1e088c2deb72bdbe](https://www.virustotal.com/gui/file/55ba9886ff2ab87a1e088c2deb72bdbe)|Win64 DLL|Turla|2019-12-11 14:10:45|018833609|
|[1619fee6d8b9f99abcdae1cd78b16e60](https://www.virustotal.com/gui/file/1619fee6d8b9f99abcdae1cd78b16e60)|Win64 DLL|Turla|2019-12-11 14:03:28|018833609|
|[78f8144c138332937e78833146bb34b9](https://www.virustotal.com/gui/file/78f8144c138332937e78833146bb34b9)|Win64 DLL|Turla|2019-12-11 14:00:45|018833609|
|[fd99b6a8a95e3126005813bafcbba70f](https://www.virustotal.com/gui/file/fd99b6a8a95e3126005813bafcbba70f)|Win32 DLL||2019-12-06 19:26:42|MSJAVAVM|
|[c713cf68acd195e0c6e05fd6d9c3cdcd](https://www.virustotal.com/gui/file/c713cf68acd195e0c6e05fd6d9c3cdcd)|Win32 EXE||2019-11-19 20:14:16|with and kaztxt.exe|
|[f3bf767fb3f1f53ef5f9527168f98e46](https://www.virustotal.com/gui/file/f3bf767fb3f1f53ef5f9527168f98e46)|Win32 DLL||2019-11-19 19:50:56|many warning.exe|
|[88b76be1f1ffb9afa3fd8a1dca0fe92a](https://www.virustotal.com/gui/file/88b76be1f1ffb9afa3fd8a1dca0fe92a)|Win32 EXE||2019-11-19 19:49:11|many warning.exe|
|[4dccffe134ac6f21083d70c917a8dfe5](https://www.virustotal.com/gui/file/4dccffe134ac6f21083d70c917a8dfe5)|Win32 EXE||2019-11-19 19:05:09|adl+kuz.exe|
|[599c6a452973c04ffd285c69ac62a260](https://www.virustotal.com/gui/file/599c6a452973c04ffd285c69ac62a260)|Win64 DLL|Turla|2019-11-05 14:25:50|Microsoft.SmartScreen.DomainRep.dat.1|
|[96be1e1f997a3bad8a179af72e9e45e2](https://www.virustotal.com/gui/file/96be1e1f997a3bad8a179af72e9e45e2)|Win32 DLL||2019-11-02 15:36:08|MSJAVAVM|
|[5926ed4e825635589f2fb9220e1e8dc1](https://www.virustotal.com/gui/file/5926ed4e825635589f2fb9220e1e8dc1)|TXT||2019-10-30 21:13:12|jquery.easing.1.3.js.txt|
|[3e93f8b7c46a32236c225926d9f063f2](https://www.virustotal.com/gui/file/3e93f8b7c46a32236c225926d9f063f2)|Win32 DLL|Turla|2019-10-08 03:50:04| |
|[4c0a84a2ebe157fbab2c42f8e92ab330](https://www.virustotal.com/gui/file/4c0a84a2ebe157fbab2c42f8e92ab330)|Win32 DLL|Ursu|2019-10-07 04:04:30| |
|[44fb1516e3c290237b4bed7d59496442](https://www.virustotal.com/gui/file/44fb1516e3c290237b4bed7d59496442)|Win32 DLL|Ursu|2019-10-07 03:33:56| |
|[65e6025462d5b47e07d5fd724a549c92](https://www.virustotal.com/gui/file/65e6025462d5b47e07d5fd724a549c92)|Win32 DLL|Ursu|2019-10-07 03:01:27| |
|[1f8a62d84c8d521aa333a9bcd7f630d3](https://www.virustotal.com/gui/file/1f8a62d84c8d521aa333a9bcd7f630d3)|Win64 DLL||2019-10-07 00:05:18|739aa8eb0a2a6e77_1f3975ea6a12e99f7f0579c84710d1dd.dll|
|[f19f0170ede809218b35b705478dc1a9](https://www.virustotal.com/gui/file/f19f0170ede809218b35b705478dc1a9)|Win32 DLL|Ursu|2019-10-06 22:23:32| |
|[f4273f979565c66fe00fdcc0619793b1](https://www.virustotal.com/gui/file/f4273f979565c66fe00fdcc0619793b1)|Win32 DLL|Turla|2019-10-06 10:39:31| |
|[11dc55d38e4d29acf32fe40c2bbfb461](https://www.virustotal.com/gui/file/11dc55d38e4d29acf32fe40c2bbfb461)|Win32 DLL|Ursu|2019-10-06 06:00:44| |
|[4a9eb485e7324499da77e00eb222d553](https://www.virustotal.com/gui/file/4a9eb485e7324499da77e00eb222d553)|Win32 DLL|Graftor|2019-10-05 16:28:12| |
|[2df3d9ad6759556d11764e7423b37b94](https://www.virustotal.com/gui/file/2df3d9ad6759556d11764e7423b37b94)|Win32 DLL|Turla|2019-10-05 16:19:42| |
|[ab3e7524f8e75bee47cfa1a838782f1d](https://www.virustotal.com/gui/file/ab3e7524f8e75bee47cfa1a838782f1d)|Win32 EXE||2019-10-05 16:16:55| |
|[597425ea47067eaee6f2ace7376614bb](https://www.virustotal.com/gui/file/597425ea47067eaee6f2ace7376614bb)|Win32 DLL||2019-09-10 09:55:16|MSJAVAVM|
|[a2a5c24530c2aa8efaadcf78f8dc54bd](https://www.virustotal.com/gui/file/a2a5c24530c2aa8efaadcf78f8dc54bd)|Win32 DLL||2019-08-30 22:49:28|MSJAVAVM|
|[45e611c1bede7d1ff0a9a169590c0c28](https://www.virustotal.com/gui/file/45e611c1bede7d1ff0a9a169590c0c28)|Win32 DLL||2019-07-03 04:23:03|MSJAVAVM|
|[2540ddea844c96e61460392a8ee573ae](https://www.virustotal.com/gui/file/2540ddea844c96e61460392a8ee573ae)|Win32 DLL||2019-06-01 04:30:12|MSJAVAVM|
|[87ad17f943692fa749259190a52c81e3](https://www.virustotal.com/gui/file/87ad17f943692fa749259190a52c81e3)|Win32 EXE||2019-05-31 12:56:26|dttcodexgigas.d63c2d55af499ead7f7fefe7951f6f1b1296774e|
|[e0abec19095864c3f67dd9cb50c1144d](https://www.virustotal.com/gui/file/e0abec19095864c3f67dd9cb50c1144d)|Win32 DLL||2019-05-31 10:54:13|MSJAVAVM|
|[41705c15ca2e5b707ec2fcd25e69a025](https://www.virustotal.com/gui/file/41705c15ca2e5b707ec2fcd25e69a025)|Win32 EXE|Wacatac|2019-05-21 18:17:37|shellcode.bin|
|[347c626ebd441790fc73c103af192893](https://www.virustotal.com/gui/file/347c626ebd441790fc73c103af192893)|Win32 DLL||2019-05-12 10:00:35|MSJAVAVM|
|[64b2e54e905373d09bc4458ea34c7bd0](https://www.virustotal.com/gui/file/64b2e54e905373d09bc4458ea34c7bd0)|Win32 EXE|occamy|2019-05-10 17:36:57|WOWManager|
|[26a7f2fe450f9033c8496baa404f1ef9](https://www.virustotal.com/gui/file/26a7f2fe450f9033c8496baa404f1ef9)|Win32 DLL||2019-05-10 05:31:11|MSJAVAVM|
|[1ab6d09801640cb3a508942e4da3c9a1](https://www.virustotal.com/gui/file/1ab6d09801640cb3a508942e4da3c9a1)|Win32 EXE|Turla|2019-05-09 18:56:45|.|
|[0952b0efe7c2099100904dc787825061](https://www.virustotal.com/gui/file/0952b0efe7c2099100904dc787825061)|Win32 DLL|Turla|2019-05-09 18:13:27|./KISA_dataset_2020_train/49d57452f11e15b81336c985a42a2887ea53e747297587580105166561d8401d.vir|
|[53e823cad0837fffe540d3daa3335e55](https://www.virustotal.com/gui/file/53e823cad0837fffe540d3daa3335e55)|Win32 DLL|Skeeyah|2019-05-09 18:08:20|.|
|[d532e06adb3000bcda9d94079ce0ca1b](https://www.virustotal.com/gui/file/d532e06adb3000bcda9d94079ce0ca1b)|Win32 DLL||2019-05-07 05:50:29|MSJAVAVM|
|[7c834d71a108c4da3c0a8b7af05507ad](https://www.virustotal.com/gui/file/7c834d71a108c4da3c0a8b7af05507ad)|Win32 DLL||2019-05-05 11:25:56|MSJAVAVM|
|[d91153dc28274eb12e2e1233ab0552f1](https://www.virustotal.com/gui/file/d91153dc28274eb12e2e1233ab0552f1)|Win32 DLL||2019-05-01 07:10:20|MSJAVAVM|
|[4deb0196b26ced848d300158eca103f0](https://www.virustotal.com/gui/file/4deb0196b26ced848d300158eca103f0)|Win32 DLL||2019-04-27 03:27:13|MSJAVAVM|
|[81468559724652d91df6b26833cc34bf](https://www.virustotal.com/gui/file/81468559724652d91df6b26833cc34bf)|Win32 DLL||2019-04-26 19:51:27|MSJAVAVM|
|[6f8f369641401b3440c9faaf63773cd8](https://www.virustotal.com/gui/file/6f8f369641401b3440c9faaf63773cd8)|Win32 DLL||2019-04-26 12:12:42|MSJAVAVM|
|[8bdad50d7f2b2f30f1c8d5323475f35c](https://www.virustotal.com/gui/file/8bdad50d7f2b2f30f1c8d5323475f35c)|Win32 DLL||2019-04-26 12:11:22|MSJAVAVM|
|[c6798d524de5dae9a34aa665175b2677](https://www.virustotal.com/gui/file/c6798d524de5dae9a34aa665175b2677)|Win32 DLL||2019-04-26 12:07:56|MSJAVAVM|
|[6f29e6cae443412ff6086322eeffb56f](https://www.virustotal.com/gui/file/6f29e6cae443412ff6086322eeffb56f)|Win32 DLL||2019-04-19 15:36:09|MSJAVAVM|
|[f643205cda53f8f7f157cf2b6a0a443d](https://www.virustotal.com/gui/file/f643205cda53f8f7f157cf2b6a0a443d)|Win32 DLL||2019-04-19 08:19:38|MSJAVAVM|
|[be58f7bc35fb5f215a39470ae43ea2ac](https://www.virustotal.com/gui/file/be58f7bc35fb5f215a39470ae43ea2ac)|Win32 DLL||2019-04-18 16:20:55|MSJAVAVM|
|[b759f62ae689f6004f86f92c3f77b3ad](https://www.virustotal.com/gui/file/b759f62ae689f6004f86f92c3f77b3ad)|Win64 DLL|turla|2019-04-12 10:52:09|fa921b247e478b6f8570b4817ec740a62ad95cf7fcf14c265a6571cfd77abf87.sample|
|[5036314c2f8f594cc2d597307c814176](https://www.virustotal.com/gui/file/5036314c2f8f594cc2d597307c814176)|Win32 DLL||2019-04-09 15:07:15|MSJAVAVM|
|[7200e355f0573f054d80472f41976519](https://www.virustotal.com/gui/file/7200e355f0573f054d80472f41976519)|Win32 DLL|Turla|2019-04-09 12:25:48|myfile.exe|
|[fe82adcdca51ef8038b2c9cbf7671e7a](https://www.virustotal.com/gui/file/fe82adcdca51ef8038b2c9cbf7671e7a)|Win32 DLL|Turla|2019-03-28 12:23:48|fe82adcdca51ef8038b2c9cbf7671e7a.virus|
|[97bc5d5b77ce385e9820cd4477892dd1](https://www.virustotal.com/gui/file/97bc5d5b77ce385e9820cd4477892dd1)|Virtual Device Driver||2019-03-27 01:19:34| |
|[a45cac94e6e7dfd66b28d3b01fa8c8aa](https://www.virustotal.com/gui/file/a45cac94e6e7dfd66b28d3b01fa8c8aa)|Win32 DLL|Skeeyah|2019-03-12 14:34:52|MSJAVAVM|
|[01e2e224a63886a9640334ba449f8a3a](https://www.virustotal.com/gui/file/01e2e224a63886a9640334ba449f8a3a)|Win32 DLL||2019-03-12 14:25:22|MSJAVAVM|
|[d5de9bd2ea9045bc2dcb6fccf24f4b62](https://www.virustotal.com/gui/file/d5de9bd2ea9045bc2dcb6fccf24f4b62)|Win32 DLL||2019-03-12 14:16:08|MSJAVAVM|
|[8d2e0400c2c16fbdeafe4e8737542203](https://www.virustotal.com/gui/file/8d2e0400c2c16fbdeafe4e8737542203)|Win32 DLL|Turla|2019-03-12 14:13:12|MSJAVAVM|
|[a48227bdd058e0d507dad9d570b9d71d](https://www.virustotal.com/gui/file/a48227bdd058e0d507dad9d570b9d71d)|Win32 DLL|occamy|2019-03-12 14:09:54|MSJAVAVM|
|[ad27c99559a742a9949560d42c25a5b2](https://www.virustotal.com/gui/file/ad27c99559a742a9949560d42c25a5b2)|Win32 DLL|Turla|2019-03-12 14:04:17|730b196431d4953cd5e3c4468637429a05b350f7d508c3ec0a982bec4c60d5ab_dump7_0x002d0000_reconstructed|
|[e8ab99fcd9bd876ca79e0ea7ab32e6ed](https://www.virustotal.com/gui/file/e8ab99fcd9bd876ca79e0ea7ab32e6ed)|Win32 DLL|Turla|2019-03-12 14:03:23|05dc66031e4276bc20010743d8cd0ee36e4064cf087b6b4617fefb86a4702873_dump7_0x002d0000_reconstructed|
|[47c17d62cd1962e4bd282bbc40647940](https://www.virustotal.com/gui/file/47c17d62cd1962e4bd282bbc40647940)|Win32 DLL||2019-03-12 14:02:25|MSJAVAVM|
|[0a3ea5ecd7e29cd66da02a17ff6e86a4](https://www.virustotal.com/gui/file/0a3ea5ecd7e29cd66da02a17ff6e86a4)|Win32 DLL||2019-03-12 14:01:43|MSJAVAVM|
|[f993d53e05a3b87262219802a8e3ae38](https://www.virustotal.com/gui/file/f993d53e05a3b87262219802a8e3ae38)|Win32 DLL||2019-03-12 14:00:09|MSJAVAVM|
|[bdfb9ad55e908799d6b78c41cb340710](https://www.virustotal.com/gui/file/bdfb9ad55e908799d6b78c41cb340710)|Win32 DLL|Turla|2019-03-12 13:56:49|df5cc17e0efb2e4c2a85494a1f60672f3191820ef2caea81bcb031970c3f412e_dump7_0x002d0000_reconstructed|
|[83dbdf9cfcf65a97e5addc7e824a6842](https://www.virustotal.com/gui/file/83dbdf9cfcf65a97e5addc7e824a6842)|Win32 DLL|Graftor|2019-03-12 13:50:47|MSJAVAVM|
|[de457bdf41b07faaa728e9122adfd064](https://www.virustotal.com/gui/file/de457bdf41b07faaa728e9122adfd064)|Win32 EXE|Kazy|2019-03-12 13:42:11|btwcb.exe|
|[9443437c07299dd30089437430900b25](https://www.virustotal.com/gui/file/9443437c07299dd30089437430900b25)|Win32 DLL|Graftor|2019-03-12 13:41:15|MSJAVAVM|
|[1e295a6c8ca911746165812c61527730](https://www.virustotal.com/gui/file/1e295a6c8ca911746165812c61527730)|Win32 DLL|Tiggre|2019-03-12 13:40:33|MSJAVAVM|
|[efa53c81f9b6d0b245609fdcdd652826](https://www.virustotal.com/gui/file/efa53c81f9b6d0b245609fdcdd652826)|Win64 DLL||2019-03-08 15:56:21|Microsoft.Exchange.Data.Mime.dll|
|[481af8ec3f2e3f96d984693df8602e2f](https://www.virustotal.com/gui/file/481af8ec3f2e3f96d984693df8602e2f)|Win64 DLL|Agentwdcr|2019-02-11 06:39:30|myfile.exe|
|[19db0b290b19b66041eec48a51804124](https://www.virustotal.com/gui/file/19db0b290b19b66041eec48a51804124)|Win64 DLL|Turla|2019-01-28 16:21:22|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/KazuarRAT2019/TurlaKazuarRat|
|[0c8be90f4c6f3299a727b1db7406b87e](https://www.virustotal.com/gui/file/0c8be90f4c6f3299a727b1db7406b87e)|Win32 DLL|Turla|2019-01-28 16:20:40|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/KazuarRAT2019/TurlaKazRat.bin|
|[163451f0f8ac882d7218422e594d7c38](https://www.virustotal.com/gui/file/163451f0f8ac882d7218422e594d7c38)|Win64 DLL|Turla|2019-01-28 16:19:26|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/KazuarRAT2019/TurlaKazImplant|
|[988df2967a7239a4b916cc9fcedaff68](https://www.virustotal.com/gui/file/988df2967a7239a4b916cc9fcedaff68)|Win32 EXE|Razy|2019-01-27 22:32:13|Agent.exe|
|[e88029a87ca6e3f7b271e5d35471b240](https://www.virustotal.com/gui/file/e88029a87ca6e3f7b271e5d35471b240)|Win32 DLL|Turla|2019-01-27 22:23:55|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/Turla/KazuarRAT2019/TurlaKazImplantVarient|
|[f58e5a860a4d846ebe86596f9691e2e8](https://www.virustotal.com/gui/file/f58e5a860a4d846ebe86596f9691e2e8)|Win32 EXE|Turla|2018-07-25 05:15:30|./KISA_dataset_2020_train/20691ff3c9474cfd7bf6fa3f8720eb7326e6f87f64a1f190861589c1e7397fa5.vir|
|[25433e78c32d3d074ac68260957f5659](https://www.virustotal.com/gui/file/25433e78c32d3d074ac68260957f5659)|JPEG||2018-01-18 12:26:51|attachment.bin|
|[a5e8e5633bb06f12a511011d6adb3a83](https://www.virustotal.com/gui/file/a5e8e5633bb06f12a511011d6adb3a83)|Win32 DLL|Ursu|2018-01-09 16:04:28|b820b42479b87058bcbb9a63856cc8510af4632b51126113e52e222e04b6bc97.sample|
|[f7bb82b0e665b494bcebefc7351f46c5](https://www.virustotal.com/gui/file/f7bb82b0e665b494bcebefc7351f46c5)|Win64 DLL|Turla|2017-09-26 11:54:10|1678-pefile.dll|
|[bfa7e07441929be3c6d5002e3be467ea](https://www.virustotal.com/gui/file/bfa7e07441929be3c6d5002e3be467ea)|Win32 EXE||2016-10-14 12:43:10|Agent.exe|
|[a029007534b95c2bd8e29e80f97f292d](https://www.virustotal.com/gui/file/a029007534b95c2bd8e29e80f97f292d)|Win32 EXE|Zbot|2016-10-14 12:15:52|Agent.exe|
|[cafe3f10dc01ad158b14932b6562616f](https://www.virustotal.com/gui/file/cafe3f10dc01ad158b14932b6562616f)|Win32 EXE|Zbot|2016-10-10 11:08:52|Agent.exe|
|[7a778e076e48ff269e91f17a15ea97d5](https://www.virustotal.com/gui/file/7a778e076e48ff269e91f17a15ea97d5)|Win32 EXE|Zbot|2016-10-04 09:40:50|Agent.exe|
|[448524fd62dec1151c75b55b86587784](https://www.virustotal.com/gui/file/448524fd62dec1151c75b55b86587784)|Win32 DLL||2014-02-20 19:33:36|MSJAVAVM|
|[ca8d5f41c074dfb2f8fbb66a352aef06](https://www.virustotal.com/gui/file/ca8d5f41c074dfb2f8fbb66a352aef06)|Win32 EXE|Tspy|2013-08-30 07:32:54|Wextract|
|[eb928bca5675722c7e9e2b09eec1158a](https://www.virustotal.com/gui/file/eb928bca5675722c7e9e2b09eec1158a)|Win32 DLL||2013-07-30 05:23:14|MSJAVAVM|
|[890c13f99a35dcd780ca151dcf1c7aa2](https://www.virustotal.com/gui/file/890c13f99a35dcd780ca151dcf1c7aa2)|Win32 EXE||2013-04-06 15:24:19|myfile.exe|
|[78d3f074b70788897ae7e20e5137bf47](https://www.virustotal.com/gui/file/78d3f074b70788897ae7e20e5137bf47)|Win32 DLL||2012-12-15 07:36:15|MSJAVAVM|
|[28024234c30880ecf146526ca430f9ca](https://www.virustotal.com/gui/file/28024234c30880ecf146526ca430f9ca)|Win32 DLL|Turla|2012-05-25 19:18:10|MSJAVAVM|
|[80fc5df5022be7b91de43017f586f1d7](https://www.virustotal.com/gui/file/80fc5df5022be7b91de43017f586f1d7)|Win32 DLL||2012-05-02 03:27:27|80fc5df5022be7b91de43017f586f1d7|
|[8940b9b7e6d0d669c7a9d3082016354e](https://www.virustotal.com/gui/file/8940b9b7e6d0d669c7a9d3082016354e)|Win32 DLL||2012-04-30 03:44:09|8940b9b7e6d0d669c7a9d3082016354e|
|[5bc96f6c393f73f78ebc4bd28167f57d](https://www.virustotal.com/gui/file/5bc96f6c393f73f78ebc4bd28167f57d)|Win32 DLL|Turla|2012-03-31 18:33:58|MSJAVAVM|
|[e028c0d5842313dc746c14342622549e](https://www.virustotal.com/gui/file/e028c0d5842313dc746c14342622549e)|Win32 DLL|Turla|2012-03-27 13:47:50|MSJAVAVM|
|[daaa03e1c73d613dd0b221abbd6998ea](https://www.virustotal.com/gui/file/daaa03e1c73d613dd0b221abbd6998ea)|Win32 EXE|Turla|2010-07-19 00:23:21|atmarpd.sys|
|[6889eff32b36c63a25172144516bebbd](https://www.virustotal.com/gui/file/6889eff32b36c63a25172144516bebbd)|Win32 DLL|Turla|2010-01-30 20:34:08|MSJAVAVM|
|[9e8d05e70588e4d3b2feb1a5e895960a](https://www.virustotal.com/gui/file/9e8d05e70588e4d3b2feb1a5e895960a)|Win32 EXE||2009-07-16 10:58:26|Wextract|
|[db1156b072d58acdac1aeab9af2160a2](https://www.virustotal.com/gui/file/db1156b072d58acdac1aeab9af2160a2)|Win32 DLL|Zbot|2008-11-14 18:45:48|MSJAVAVM|
|[986f263ca2c529d5d28bce3c62f858ea](https://www.virustotal.com/gui/file/986f263ca2c529d5d28bce3c62f858ea)|Win32 DLL||2008-09-08 11:04:34|MSJAVAVM|
|[f93ce76f6580d68a95260198b2d6feaa](https://www.virustotal.com/gui/file/f93ce76f6580d68a95260198b2d6feaa)|Win32 DLL||2008-02-14 12:39:45|MSJAVAVM|
|[b41fbdd02e4d54b4bc28eda99a8c1502](https://www.virustotal.com/gui/file/b41fbdd02e4d54b4bc28eda99a8c1502)|Win32 DLL||2007-08-14 11:04:04|desktop.dll|
