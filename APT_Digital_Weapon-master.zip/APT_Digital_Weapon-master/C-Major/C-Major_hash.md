|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[b4080cda4fb1b27c727d546c8529909c](https://www.virustotal.com/gui/file/b4080cda4fb1b27c727d546c8529909c)|Win32 EXE||2019-11-01 09:39:53|wintcpx.exe|
|[e9b1a3aa2de67300356b6587a8034b0b](https://www.virustotal.com/gui/file/e9b1a3aa2de67300356b6587a8034b0b)|Win32 EXE||2019-11-01 09:39:48|udriver.exe|
|[39ae6f1fd36c08e8199a9725906a9f0a](https://www.virustotal.com/gui/file/39ae6f1fd36c08e8199a9725906a9f0a)|XLS||2019-10-22 13:01:06|35982_1571811270_39ae6f1fd36c08e8199a9725906a9f0a|
|[d7fffb36d22a36d9757ccc8ffa032d31](https://www.virustotal.com/gui/file/d7fffb36d22a36d9757ccc8ffa032d31)|Win32 EXE||2019-10-17 04:54:31|twainResolver.exe|
|[a579d7cf970b388558aa257cd84dcf52](https://www.virustotal.com/gui/file/a579d7cf970b388558aa257cd84dcf52)|Win32 EXE||2019-10-17 04:52:05|drivertoolkit.tmp|
|[214eb28f04d969c9f637b09e4ffad644](https://www.virustotal.com/gui/file/214eb28f04d969c9f637b09e4ffad644)|Win32 EXE||2019-10-05 04:14:17|winword.exe|
|[bda458bd3b32fe8c8bbabfc8b9a2fc77](https://www.virustotal.com/gui/file/bda458bd3b32fe8c8bbabfc8b9a2fc77)|Win32 EXE||2019-08-30 15:00:48|R Sample.scr|
|[4c6e1672d5bc9be4b12c794b33c1b082](https://www.virustotal.com/gui/file/4c6e1672d5bc9be4b12c794b33c1b082)|XLS||2019-08-30 08:11:27|Malicious Excel.xls|
|[f9db2b92a24a288a8a90d933074b7059](https://www.virustotal.com/gui/file/f9db2b92a24a288a8a90d933074b7059)|Win32 EXE|Ursu|2019-08-30 07:03:15|PowerIso.exe|
|[0fa9b24535f55ec64be0f02a75d637b3](https://www.virustotal.com/gui/file/0fa9b24535f55ec64be0f02a75d637b3)|XLS|Banload|2019-07-08 19:47:09|Application_Form_for_membership_for_PROMEX.xls|
|[02ba9703d1f250b411ea4c868d17fd2e](https://www.virustotal.com/gui/file/02ba9703d1f250b411ea4c868d17fd2e)|XLS||2019-05-20 10:28:13|Final List.xls|
|[2eb4469c76f5230c66626a6918c7664f](https://www.virustotal.com/gui/file/2eb4469c76f5230c66626a6918c7664f)|Win32 EXE||2019-02-28 07:00:28|rgiwsdasxa.exe|
|[41b70737fa8dda75d5e95c82699c2e9b](https://www.virustotal.com/gui/file/41b70737fa8dda75d5e95c82699c2e9b)|DOC||2019-02-28 04:17:25|Exclusive_Pictures__destruction_of_Jaish_Camp_and_dead_bodies_of_terrorists.doc|
|[b16d4956f6609104eb93a521b60c6f42](https://www.virustotal.com/gui/file/b16d4956f6609104eb93a521b60c6f42)|XLS||2019-02-25 19:19:32|EoMA_PGA_2019.xls|
|[2c94776b6a145854f305a9febf95fd00](https://www.virustotal.com/gui/file/2c94776b6a145854f305a9febf95fd00)|Win32 EXE|occamy|2019-02-25 12:50:02|hintellitrace.exe|
|[1b7b5c85fe5b9daf2264b7d5f6b364e9](https://www.virustotal.com/gui/file/1b7b5c85fe5b9daf2264b7d5f6b364e9)|DOC||2019-02-07 13:07:15|contacts.doc|
|[7fa6689ec0a8863e5084d30de4b9b252](https://www.virustotal.com/gui/file/7fa6689ec0a8863e5084d30de4b9b252)|XLS|Banload|2019-01-30 11:31:35|UNITED_NATIONS_MILITARY_OBSERVERS____COURSE___UNMOC-19_.xls|
|[ab68db5c97f9ee12ca29c1eed881781d](https://www.virustotal.com/gui/file/ab68db5c97f9ee12ca29c1eed881781d)|Win32 EXE||2019-01-24 17:53:13|ekeoil.exe|
|[4dfde74cb13ed3890e33082b7f296f57](https://www.virustotal.com/gui/file/4dfde74cb13ed3890e33082b7f296f57)|Win32 EXE||2018-11-20 23:29:02|tcdss.exe|
|[208606ace2e34c4b2fefeb4909c66d50](https://www.virustotal.com/gui/file/208606ace2e34c4b2fefeb4909c66d50)|Win32 EXE|msilperseus|2018-10-29 22:39:40|hedklu.exe|
|[91e5c5afcf42f8912d5ae3b7dafcda22](https://www.virustotal.com/gui/file/91e5c5afcf42f8912d5ae3b7dafcda22)|XLS||2018-10-29 19:04:38|Officer_Course_for_FY_2018_19-4.xls|
|[d4851409252705ed0b3d885bc63b5372](https://www.virustotal.com/gui/file/d4851409252705ed0b3d885bc63b5372)|Android||2018-05-15 16:17:28|d4851409252705ed0b3d885bc63b5372.virus|
|[63fca1c3ae266c300b6f6c368309e051](https://www.virustotal.com/gui/file/63fca1c3ae266c300b6f6c368309e051)|Android||2018-05-15 13:39:09|63fca1c3ae266c300b6f6c368309e051.virus|
|[54a3969a751d211eeaf3ffd62a59d4cf](https://www.virustotal.com/gui/file/54a3969a751d211eeaf3ffd62a59d4cf)|Android||2018-05-15 13:22:34|54a3969a751d211eeaf3ffd62a59d4cf.virus|
|[79d690b27e287a0a24c91b6be91254cf](https://www.virustotal.com/gui/file/79d690b27e287a0a24c91b6be91254cf)|XLS||2018-05-03 05:26:48|Pay Matrix Projected After 7th CPC (3).xls|
|[ece38518be7ceabfddb460b753f3854b](https://www.virustotal.com/gui/file/ece38518be7ceabfddb460b753f3854b)|Text||2018-04-25 22:00:18| |
|[da8e7de69615637fd6a3cd645dde1f43](https://www.virustotal.com/gui/file/da8e7de69615637fd6a3cd645dde1f43)|Text||2018-04-24 16:44:35|6800371|
|[a3941faa3f7bf7b2d64d0e94c539dabf](https://www.virustotal.com/gui/file/a3941faa3f7bf7b2d64d0e94c539dabf)|Text||2018-04-24 16:44:14|6800372|
|[5d8eba87bf1d785257dde44920ff5d34](https://www.virustotal.com/gui/file/5d8eba87bf1d785257dde44920ff5d34)|Text||2018-04-24 16:44:13|6800370|
|[f4b28f398c129278d49e39705aeecbf9](https://www.virustotal.com/gui/file/f4b28f398c129278d49e39705aeecbf9)|Text||2018-04-24 16:43:40|6800374|
|[a332f1b6e7e063b313c0090762bb4193](https://www.virustotal.com/gui/file/a332f1b6e7e063b313c0090762bb4193)|Text||2018-04-24 16:43:32|6800368|
|[27b0c7cf4087d333b7abe1b719810cac](https://www.virustotal.com/gui/file/27b0c7cf4087d333b7abe1b719810cac)|Text|o97m|2018-04-24 16:43:08|6800375|
|[f54f533ee9ec92c4792cd73af55760b1](https://www.virustotal.com/gui/file/f54f533ee9ec92c4792cd73af55760b1)|Text||2018-04-24 16:42:49|6800373|
|[f10fcface42da20d941ff84bcc9b6cff](https://www.virustotal.com/gui/file/f10fcface42da20d941ff84bcc9b6cff)|Text||2018-04-24 16:42:28|6800387|
|[b17faa3c392f9b36bf0904cbb61c0168](https://www.virustotal.com/gui/file/b17faa3c392f9b36bf0904cbb61c0168)|Text||2018-04-24 16:42:28|6800376|
|[10fd87af447de6e042269b15414731a6](https://www.virustotal.com/gui/file/10fd87af447de6e042269b15414731a6)|Text||2018-04-24 16:42:09|6800369|
|[032a3fe7c4411f4bf9eaaa04ecb19d3b](https://www.virustotal.com/gui/file/032a3fe7c4411f4bf9eaaa04ecb19d3b)|Android||2018-04-20 08:17:42|032a3fe7c4411f4bf9eaaa04ecb19d3b.virus|
|[197e603f859abc79ae9fdabae4deb4fa](https://www.virustotal.com/gui/file/197e603f859abc79ae9fdabae4deb4fa)|Win32 EXE||2018-04-17 12:34:07|svchost32.exe|
|[e426c13c57b6c866164b5ee36e91e12c](https://www.virustotal.com/gui/file/e426c13c57b6c866164b5ee36e91e12c)|Text|o97m|2018-04-16 16:45:11|e426c13c57b6c866164b5ee36e91e12c|
|[93350312094d1ffcf2656c8d8df694bf](https://www.virustotal.com/gui/file/93350312094d1ffcf2656c8d8df694bf)|Win32 EXE|MSILPerseus|2018-04-13 09:25:24|ewbusm.exe|
|[11bfb965c20327564f4555734e966cdc](https://www.virustotal.com/gui/file/11bfb965c20327564f4555734e966cdc)|Win32 EXE||2018-04-13 09:25:11|idwusm.exe|
|[b76c6b112c6a71c4d92060e45ae0b4bd](https://www.virustotal.com/gui/file/b76c6b112c6a71c4d92060e45ae0b4bd)|Win32 EXE||2018-04-12 00:28:55|Mycetology|
|[5740d3a2a860c44abd2c2ec07996219e](https://www.virustotal.com/gui/file/5740d3a2a860c44abd2c2ec07996219e)|Win32 EXE|Delf|2018-04-11 01:54:42|/var/www/clean-mx/virusesevidence/output.113000443.txt|
|[b0bcb2521a705fbccb49c41d9b0fae39](https://www.virustotal.com/gui/file/b0bcb2521a705fbccb49c41d9b0fae39)|Win32 EXE|Fareit|2018-04-10 23:41:02|17.exe|
|[8c44875c81f28ac9c2a485a8c77618fa](https://www.virustotal.com/gui/file/8c44875c81f28ac9c2a485a8c77618fa)|Win32 EXE|neshta|2018-04-10 11:15:04|15.exe|
|[066f3d945823d4c14b6b8f6f6ff3ca3b](https://www.virustotal.com/gui/file/066f3d945823d4c14b6b8f6f6ff3ca3b)|Win32 EXE||2018-04-09 22:51:08|13.exe|
|[d6c838a6046f171f3c6a795deabb61cb](https://www.virustotal.com/gui/file/d6c838a6046f171f3c6a795deabb61cb)|Win32 EXE|Kryptik|2018-04-09 18:40:32|4.exe|
|[392d7d7f1914dd823d01554471881c42](https://www.virustotal.com/gui/file/392d7d7f1914dd823d01554471881c42)|Win32 EXE|Zbot|2018-04-08 17:35:05|myfile.exe|
|[ab5719fa3e6aa3b913b51721cc4a120a](https://www.virustotal.com/gui/file/ab5719fa3e6aa3b913b51721cc4a120a)|Win32 EXE|Kryptik|2018-04-07 14:05:47|nSEiMgzieo1O4K67.aipTQu2m.exe|
|[7845c0747d5d7b542ae63a2f7cde17da](https://www.virustotal.com/gui/file/7845c0747d5d7b542ae63a2f7cde17da)|RTF|emodldr|2018-04-06 08:40:10|/var/www/clean-mx/virusesevidence/output.113106371.txt|
|[896d6033702e0edde552bf29a5374374](https://www.virustotal.com/gui/file/896d6033702e0edde552bf29a5374374)|Text||2018-04-06 07:09:43|/var/www/clean-mx/virusesevidence/output.113082129.txt|
|[38922c07375c89b273826f06ae07eacf](https://www.virustotal.com/gui/file/38922c07375c89b273826f06ae07eacf)|Win32 EXE||2018-04-05 19:20:26|myfile.exe|
|[6ac98cf3e021e4e01521665fa1f18e6d](https://www.virustotal.com/gui/file/6ac98cf3e021e4e01521665fa1f18e6d)|Win32 EXE|dynamer|2018-04-05 19:18:35|myfile.exe|
|[a9e0fb46e77c8e35173a2a3d8abbf637](https://www.virustotal.com/gui/file/a9e0fb46e77c8e35173a2a3d8abbf637)|Win32 EXE|dynamer|2018-04-05 19:17:41|myfile.exe|
|[f40572efb5ed5aa1c9dbfbace698bccf](https://www.virustotal.com/gui/file/f40572efb5ed5aa1c9dbfbace698bccf)|Win32 EXE|Kryptik|2018-04-05 15:26:43|thi2ijDoWG4rRvQ3.1mEyUlIN.exe|
|[bdebbde94650132a7171a1edf40e762c](https://www.virustotal.com/gui/file/bdebbde94650132a7171a1edf40e762c)|Text||2018-04-05 14:47:29|31A89963F95276BA9E2177C98FC19DD6EDF7B2AF91415E6BCF03668BC567AEAB|
|[628054cd91b51ef2ca44b03e3c631522](https://www.virustotal.com/gui/file/628054cd91b51ef2ca44b03e3c631522)|Win32 EXE|Kryptik|2018-04-05 13:06:05|XKMEXva7wnp17qIf.HgP6LZWs.exe|
|[a5161cd7a30aff3cea81a1e5fab6b8d4](https://www.virustotal.com/gui/file/a5161cd7a30aff3cea81a1e5fab6b8d4)|RTF|emodldr|2018-04-05 11:07:57|18.doc|
|[11b8ac9a0ca8f098a720ade719796a91](https://www.virustotal.com/gui/file/11b8ac9a0ca8f098a720ade719796a91)|RTF|emodldr|2018-04-05 11:07:52|5.doc|
|[a5ebe7f27f8c1e7afc4c6a520636e335](https://www.virustotal.com/gui/file/a5ebe7f27f8c1e7afc4c6a520636e335)|Text|Kryptik|2018-04-05 11:07:50|5.vbs|
|[c2933f2604ff8111f5aa6df62f61cc42](https://www.virustotal.com/gui/file/c2933f2604ff8111f5aa6df62f61cc42)|Text||2018-04-05 11:07:47|/var/www/clean-mx/virusesevidence/output.113082130.txt|
|[2a12dc90e0cfa42cce055cf6956358bd](https://www.virustotal.com/gui/file/2a12dc90e0cfa42cce055cf6956358bd)|RTF|emodldr|2018-04-05 11:07:46|/var/www/clean-mx/virusesevidence/output.113082113.txt|
|[ec9cbda30e21f9eff5ccd70d9b299017](https://www.virustotal.com/gui/file/ec9cbda30e21f9eff5ccd70d9b299017)|RTF||2018-04-05 11:07:46|15.doc|
|[0e6f46e1a2ea7b7376cc69c054d72184](https://www.virustotal.com/gui/file/0e6f46e1a2ea7b7376cc69c054d72184)|Text||2018-04-05 11:07:44|myvtfile.exe|
|[862a4f0a49f5694ab1faf8c1de3a9fa6](https://www.virustotal.com/gui/file/862a4f0a49f5694ab1faf8c1de3a9fa6)|RTF|emodldr|2018-04-05 11:07:43|/var/www/clean-mx/virusesevidence/output.113082134.txt|
|[a9298d47c5621b9be12878e2a22f7622](https://www.virustotal.com/gui/file/a9298d47c5621b9be12878e2a22f7622)|RTF|emodldr|2018-04-05 11:07:43|7.doc|
|[75183c351679255fd2a0f1239b6f4a1e](https://www.virustotal.com/gui/file/75183c351679255fd2a0f1239b6f4a1e)|RTF|emodldr|2018-04-05 11:07:42|/var/www/clean-mx/virusesevidence/output.113176786.txt|
|[cadf03649a459b5f8fef51ab05ed43f5](https://www.virustotal.com/gui/file/cadf03649a459b5f8fef51ab05ed43f5)|RTF|emodldr|2018-04-05 11:07:39|/var/www/clean-mx/virusesevidence/output.113082111.txt|
|[cfa76c4452423b8bebcf10b9692fab18](https://www.virustotal.com/gui/file/cfa76c4452423b8bebcf10b9692fab18)|RTF|emodldr|2018-04-05 11:07:39|/var/www/clean-mx/virusesevidence/output.113082125.txt|
|[835b6d5d8e3195308479a927dea3e1bd](https://www.virustotal.com/gui/file/835b6d5d8e3195308479a927dea3e1bd)|RTF|emodldr|2018-04-05 11:07:36|10.doc|
|[181cf4934abc899507251ecc5d10f35c](https://www.virustotal.com/gui/file/181cf4934abc899507251ecc5d10f35c)|Text||2018-04-05 11:07:34|myvtfile.exe|
|[96828ba6c1491266e5329a2b4ce64b06](https://www.virustotal.com/gui/file/96828ba6c1491266e5329a2b4ce64b06)|RTF|emodldr|2018-04-05 11:07:33|3.doc|
|[629d4bf99296a56b5c562e75bdb5ced2](https://www.virustotal.com/gui/file/629d4bf99296a56b5c562e75bdb5ced2)|Text||2018-04-05 11:07:32|65E43A75DB8CFD765DDBC7C06AA2638B954D951D1E9E58FC03269B4DAA6B4DAB|
|[a026e90336984aa910c0396f8d498dd2](https://www.virustotal.com/gui/file/a026e90336984aa910c0396f8d498dd2)|Text||2018-04-05 11:07:30|/var/www/clean-mx/virusesevidence/output.113082128.txt|
|[cdb0fb687c9b75340d6d4e93f4cb7680](https://www.virustotal.com/gui/file/cdb0fb687c9b75340d6d4e93f4cb7680)|RTF|emodldr|2018-04-05 11:07:30|/var/www/clean-mx/virusesevidence/output.113082122.txt|
|[45d27951faec3964a1ede441a6e654db](https://www.virustotal.com/gui/file/45d27951faec3964a1ede441a6e654db)|Text||2018-04-05 11:07:29|/var/www/clean-mx/virusesevidence/output.113082131.txt|
|[4147b9d3f947f2b4a26b44cbadc4a317](https://www.virustotal.com/gui/file/4147b9d3f947f2b4a26b44cbadc4a317)|RTF|emodldr|2018-04-05 11:07:26|/var/www/clean-mx/virusesevidence/output.113082133.txt|
|[f13d436f3f2d35fd4db0f75cd76bf34a](https://www.virustotal.com/gui/file/f13d436f3f2d35fd4db0f75cd76bf34a)|RTF|emodldr|2018-04-05 11:07:25|/var/www/clean-mx/virusesevidence/output.113082121.txt|
|[3d5775e17dcd2be5f54fc3d62a47cc2d](https://www.virustotal.com/gui/file/3d5775e17dcd2be5f54fc3d62a47cc2d)|RTF|emodldr|2018-04-05 10:34:13|/var/www/clean-mx/virusesevidence/output.113082117.txt|
|[e5c722769ce140f106cf53c9f1ef5934](https://www.virustotal.com/gui/file/e5c722769ce140f106cf53c9f1ef5934)|RTF|emodldr|2018-04-05 09:32:26|17.doc|
|[d86e9a89cfb57892a694572b640c7a91](https://www.virustotal.com/gui/file/d86e9a89cfb57892a694572b640c7a91)|Text||2018-04-05 06:46:23|20.vbs_|
|[53eaf462feca7cec01fe54a6217f2c58](https://www.virustotal.com/gui/file/53eaf462feca7cec01fe54a6217f2c58)|Win32 EXE|DarkKomet|2018-04-05 03:05:47|MSRSAAPP|
|[53eb377aa14c4aa13420779024ebac1a](https://www.virustotal.com/gui/file/53eb377aa14c4aa13420779024ebac1a)|RTF|emodldr|2018-04-05 03:05:22|54ead7edf6d8bd31993e6c3948978757222ac79ac183e7e784e7a437d50e4fd8.bin|
|[836f6f97aaab695e9991143e88e06fca](https://www.virustotal.com/gui/file/836f6f97aaab695e9991143e88e06fca)|Win32 EXE|Symmi|2018-04-05 03:03:39|myfile.exe|
|[f96daa1b221c5c2a598e3f46bfd518dd](https://www.virustotal.com/gui/file/f96daa1b221c5c2a598e3f46bfd518dd)|RTF|emodldr|2018-04-04 14:19:43|/var/www/clean-mx/virusesevidence/output.113082124.txt|
|[8ba0e481d0d2a76c5969c100eecaa176](https://www.virustotal.com/gui/file/8ba0e481d0d2a76c5969c100eecaa176)|Win32 EXE|Symmi|2018-04-04 14:07:01|1.exe|
|[ef51e56da31ba444702ae26eba135536](https://www.virustotal.com/gui/file/ef51e56da31ba444702ae26eba135536)|RTF|emodldr|2018-04-03 22:13:57|763772416d2ae9463ddd67930ac9d3cdb0117833d1b7806cd5385913c2423c4d.bin|
|[db0448999ab65eb6b3603c1689ba1609](https://www.virustotal.com/gui/file/db0448999ab65eb6b3603c1689ba1609)|RTF||2018-03-26 03:40:20|15.doc|
|[63d4d8a277f530503a77b59d9e6066f6](https://www.virustotal.com/gui/file/63d4d8a277f530503a77b59d9e6066f6)|Win32 EXE|generickdz|2018-03-24 19:08:06|10.exe|
|[99afda6820e000917b438a94d86a2300](https://www.virustotal.com/gui/file/99afda6820e000917b438a94d86a2300)|Win32 EXE|Delf|2018-03-23 11:14:07|data/bad/8fa4fe00-3038-11e8-ab59-80e65024849a.file|
|[84a44f6cd793ac944eb64dfa2beef098](https://www.virustotal.com/gui/file/84a44f6cd793ac944eb64dfa2beef098)|Win32 EXE|Fareit|2018-03-23 11:13:14|BvSshCtrl|
|[a7cc783c2599b761c3be6d6f619a3f33](https://www.virustotal.com/gui/file/a7cc783c2599b761c3be6d6f619a3f33)|Win32 EXE|Delf|2018-03-23 11:13:14|myfile.exe|
|[c02de7d699bf1402f66ab86d58dc9df2](https://www.virustotal.com/gui/file/c02de7d699bf1402f66ab86d58dc9df2)|RTF|o97m|2018-03-23 02:40:12|/var/www/clean-mx/virusesevidence/output.113032474.txt|
|[9e33b39b9989fa71a3c423441ffeb1c1](https://www.virustotal.com/gui/file/9e33b39b9989fa71a3c423441ffeb1c1)|RTF|o97m|2018-03-23 02:36:43|/var/www/clean-mx/virusesevidence/output.113032470.txt|
|[13b40a0ab93b784ef29a01f3edb3dd6a](https://www.virustotal.com/gui/file/13b40a0ab93b784ef29a01f3edb3dd6a)|RTF|o97m|2018-03-22 14:11:38|/var/www/clean-mx/virusesevidence/output.113032471.txt|
|[d6a3432a687c93bf1164da4ad9163d27](https://www.virustotal.com/gui/file/d6a3432a687c93bf1164da4ad9163d27)|RTF||2018-03-22 10:16:32| |
|[1a77516842d1d471021aacce298d39e3](https://www.virustotal.com/gui/file/1a77516842d1d471021aacce298d39e3)|RTF|o97m|2018-03-22 09:25:17|/var/www/clean-mx/virusesevidence/output.113032472.txt|
|[63aa62ffd0b9aaaaa543fed0de19943d](https://www.virustotal.com/gui/file/63aa62ffd0b9aaaaa543fed0de19943d)|RTF|o97m|2018-03-22 09:07:28|/var/www/clean-mx/virusesevidence/output.113032473.txt|
|[91898b62840b11845adf7020934da1ed](https://www.virustotal.com/gui/file/91898b62840b11845adf7020934da1ed)|RTF||2018-03-22 08:41:16|18.doc|
|[c91250a6ba94f93137c5a2fe926bc8d5](https://www.virustotal.com/gui/file/c91250a6ba94f93137c5a2fe926bc8d5)|Win32 EXE||2018-03-22 08:32:37|4.exe|
|[674a2076b43605ddb5876ef1c03a20ab](https://www.virustotal.com/gui/file/674a2076b43605ddb5876ef1c03a20ab)|Win32 EXE|Delf|2018-03-22 03:45:49|myfile.exe|
|[e104ac164c5561f28d92770c6a4dc5d9](https://www.virustotal.com/gui/file/e104ac164c5561f28d92770c6a4dc5d9)|Win32 EXE|Delf|2018-03-19 13:55:12|myfile.exe|
|[4d91d8742b767699722852dafdfaf83f](https://www.virustotal.com/gui/file/4d91d8742b767699722852dafdfaf83f)|Android||2018-03-09 22:44:06|4d91d8742b767699722852dafdfaf83f.virus|
|[3b979fd0a8fa0ecbc334a3bbbfb68a36](https://www.virustotal.com/gui/file/3b979fd0a8fa0ecbc334a3bbbfb68a36)|Win32 EXE||2018-03-07 20:25:03|3b979fd0a8fa0ecbc334a3bbbfb68a36|
|[b709529e2db6356c4578000de02725cb](https://www.virustotal.com/gui/file/b709529e2db6356c4578000de02725cb)|Win32 EXE||2018-02-20 06:47:27|axess_4343.exe|
|[a6ab8d81d9d28b9c4e1f8ec06082944a](https://www.virustotal.com/gui/file/a6ab8d81d9d28b9c4e1f8ec06082944a)|Android||2017-12-29 19:08:19|a6ab8d81d9d28b9c4e1f8ec06082944a.virus|
|[078b9f8501afb4c15b1317b1f6101380](https://www.virustotal.com/gui/file/078b9f8501afb4c15b1317b1f6101380)|Win32 EXE|Fareit|2017-11-07 15:48:27|078b9f8501afb4c15b1317b1f6101380.virobj|
|[1300ef72d620d298d5413658e01ee7e8](https://www.virustotal.com/gui/file/1300ef72d620d298d5413658e01ee7e8)|Win32 EXE||2017-11-04 17:11:53|dd619b54200555226e77d59dfdf2bc5889a4c188|
|[86e27e86e64031720a1ca52d2fbb7c98](https://www.virustotal.com/gui/file/86e27e86e64031720a1ca52d2fbb7c98)|Win32 EXE||2017-09-09 01:32:20|e1c6c76bd0ae16d7592148cb36550bd0e1a47343|
|[3b3b39cb3c2306e38f9e06b23c4a645e](https://www.virustotal.com/gui/file/3b3b39cb3c2306e38f9e06b23c4a645e)|Win32 EXE||2017-04-09 21:23:05|SwitchHosts.exe|
|[973ca595e9abe9f4c6e6cf5a624f21d7](https://www.virustotal.com/gui/file/973ca595e9abe9f4c6e6cf5a624f21d7)|Win32 EXE||2017-03-02 14:18:15|_bold_Axess.exe|
|[a40b4c6e2d94b37bd0bad1467044763d](https://www.virustotal.com/gui/file/a40b4c6e2d94b37bd0bad1467044763d)|Win32 EXE|LokiBot|2017-02-26 00:02:07|myfile.exe|
|[ec544e62d65474e4f033fdc4d4aff639](https://www.virustotal.com/gui/file/ec544e62d65474e4f033fdc4d4aff639)|Win32 EXE||2016-11-28 06:16:50|Axess.exe|
|[ae0c1e552014ef5f352a654dea8ad728](https://www.virustotal.com/gui/file/ae0c1e552014ef5f352a654dea8ad728)|Android||2016-11-24 19:14:02|ae0c1e552014ef5f352a654dea8ad728.virus|
|[5579c13396ea1a644e27d0c600013267](https://www.virustotal.com/gui/file/5579c13396ea1a644e27d0c600013267)|Android||2016-11-23 22:57:58|5579c13396ea1a644e27d0c600013267.virus|
|[d30c6df94922323041f8036365abbfd2](https://www.virustotal.com/gui/file/d30c6df94922323041f8036365abbfd2)|Win32 DLL||2016-11-17 06:53:37|/home/netml/Desktop/TestMalwares/d30c6df94922323041f8036365abbfd2|
|[463565ec38e4d790a89eb592435820e3](https://www.virustotal.com/gui/file/463565ec38e4d790a89eb592435820e3)|Win32 EXE||2016-10-28 06:38:25|windwm.exe|
|[370bb0ec1c16bd8821f7e53f6bfc61e3](https://www.virustotal.com/gui/file/370bb0ec1c16bd8821f7e53f6bfc61e3)|Win32 EXE|MSILPerseus|2016-09-14 16:50:41|sscupdates.exe|
|[3f84ddc0d9ec7b08477a76b75b4421b8](https://www.virustotal.com/gui/file/3f84ddc0d9ec7b08477a76b75b4421b8)|Win32 EXE||2016-08-26 08:14:48|udriver.exe|
|[b705ce8dbc55138b9fa1628933e3c7b3](https://www.virustotal.com/gui/file/b705ce8dbc55138b9fa1628933e3c7b3)|Rich Text Format|CVE-2010-3333|2016-08-21 17:30:44|b705ce8dbc55138b9fa1628933e3c7b3_Army_Housing_Scheme_in_Delhi.doc|
|[f3c8630d06e51e8f76aa1fb438371d21](https://www.virustotal.com/gui/file/f3c8630d06e51e8f76aa1fb438371d21)|Win32 EXE||2016-08-09 09:05:15|winservice.exe|
|[1f82e509371c1c29b40b865ba77d091a](https://www.virustotal.com/gui/file/1f82e509371c1c29b40b865ba77d091a)|Rich Text Format||2016-06-05 18:45:51|F:\mobileresearch\st.tar\st\storage\Administrator_VMI40043_v1_345632\C\Users\Administrator\Desktop\AWHO-Upcoming-Projects.doc|
|[765f0556ed4db467291d48e7d3c24b3b](https://www.virustotal.com/gui/file/765f0556ed4db467291d48e7d3c24b3b)|Win32 EXE||2016-03-27 09:58:24|msdocuments.exe|
|[c2bc8bc9ff7a34f14403222e58963507](https://www.virustotal.com/gui/file/c2bc8bc9ff7a34f14403222e58963507)|Win32 EXE||2016-03-13 20:07:52|windows_defender.exe|
|[37b93ed2e803c35d2f0dee28864a5d02](https://www.virustotal.com/gui/file/37b93ed2e803c35d2f0dee28864a5d02)|Win32 EXE||2016-03-09 17:18:07|msskype.exe|
|[e187911d0ba69380956c3b5037700bee](https://www.virustotal.com/gui/file/e187911d0ba69380956c3b5037700bee)|XLS||2016-03-07 06:32:28|Contact.xls|
|[68773f362d5ab4897d4ca217a9f53975](https://www.virustotal.com/gui/file/68773f362d5ab4897d4ca217a9f53975)|Rich Text Format|CVE-2012-0158|2016-03-03 19:47:19|cve2012-0158andcve2014-1761.bin|
|[139a346c537ab91a38b438c82c8c219f](https://www.virustotal.com/gui/file/139a346c537ab91a38b438c82c8c219f)|Win32 EXE||2016-03-01 22:55:23|windwm.exe|
|[95cba4805f980e8c1df180b660e2abb4](https://www.virustotal.com/gui/file/95cba4805f980e8c1df180b660e2abb4)|Win32 EXE|MSILPerseus|2016-03-01 12:20:26|filescan.exe|
|[d11ebec8f1d42dd139b18639f7f9534a](https://www.virustotal.com/gui/file/d11ebec8f1d42dd139b18639f7f9534a)|Win32 EXE||2016-03-01 12:19:58|usbrm.exe|
|[1911c1234cc2918273baeffd7d37392e](https://www.virustotal.com/gui/file/1911c1234cc2918273baeffd7d37392e)|Win32 EXE|razy|2016-02-28 18:15:29|microsoftscans.exe|
|[6746c430f978d0bc9bbecff87c651fa2](https://www.virustotal.com/gui/file/6746c430f978d0bc9bbecff87c651fa2)|Win32 EXE||2016-02-27 22:33:52|servicesDefender.exe|
|[2c9cc5a8569ab7d06bb8f8d7cf7dc03a](https://www.virustotal.com/gui/file/2c9cc5a8569ab7d06bb8f8d7cf7dc03a)|Win32 EXE|MSILPerseus|2016-02-25 08:27:23|securetycheck.exe|
|[045c4b69d907833729fd83d937669f66](https://www.virustotal.com/gui/file/045c4b69d907833729fd83d937669f66)|Win32 EXE||2016-02-24 18:17:06|folder.exe|
|[83a8ce707e625e977d54408ca747fa29](https://www.virustotal.com/gui/file/83a8ce707e625e977d54408ca747fa29)|Win32 EXE||2016-02-24 04:44:05|securetycheck.exe|
|[98bdcd97cd536ff6bcb2d39d9a097319](https://www.virustotal.com/gui/file/98bdcd97cd536ff6bcb2d39d9a097319)|XLS|o97m|2016-02-23 12:36:00|AFOWO Broucher 2016.xls|
|[0ad849121b4656a239e85379948e5f5d](https://www.virustotal.com/gui/file/0ad849121b4656a239e85379948e5f5d)|Win32 EXE|razy|2016-02-19 09:34:53|windowsdocs.exe|
|[55c8c8e02c351d00dbbc9072d7b935f2](https://www.virustotal.com/gui/file/55c8c8e02c351d00dbbc9072d7b935f2)|Win32 EXE||2016-02-18 18:59:49|d853d556-05f9-11e8-9e72-00accb28c0ad|
|[9b98abb9a9fa714e05d43b08b76c0afa](https://www.virustotal.com/gui/file/9b98abb9a9fa714e05d43b08b76c0afa)|Win32 EXE||2016-02-18 18:58:13|outter|
|[19b9f62f29f3689b1db4c56deed7e162](https://www.virustotal.com/gui/file/19b9f62f29f3689b1db4c56deed7e162)|Win32 EXE|razy|2016-02-17 09:35:38|mservices.exe|
|[bc6d139a3d630ba829337687b9328caf](https://www.virustotal.com/gui/file/bc6d139a3d630ba829337687b9328caf)|Win32 EXE|razy|2016-02-17 06:17:05|nvidia_vga.exe|
|[0a7a15180053270e25a220a3e38e7949](https://www.virustotal.com/gui/file/0a7a15180053270e25a220a3e38e7949)|Win32 EXE||2016-02-17 06:15:33|chromex.exe|
|[85429d5f2745d813e53b28d3d953d1cd](https://www.virustotal.com/gui/file/85429d5f2745d813e53b28d3d953d1cd)|Win32 EXE|razy|2016-02-16 17:52:10|documents.exe|
|[f078b5aeaf73831361ecd96a069c9f50](https://www.virustotal.com/gui/file/f078b5aeaf73831361ecd96a069c9f50)|Win32 EXE|Zbot|2016-02-15 11:09:21|msoclient.exe|
|[18711f1db99f6a6f73f8ab64f563accc](https://www.virustotal.com/gui/file/18711f1db99f6a6f73f8ab64f563accc)|XLS|o97m|2016-02-14 11:43:56|Call Details Record.xls|
|[340f31a36e159e58595a375b8b0b37b2](https://www.virustotal.com/gui/file/340f31a36e159e58595a375b8b0b37b2)|Win32 EXE|MSILPerseus|2016-02-13 11:25:30|msantimalware.exe|
|[532013750ee3caac93a9972103761233](https://www.virustotal.com/gui/file/532013750ee3caac93a9972103761233)|Win32 EXE||2016-02-12 16:04:02|dotnetframwork.exe|
|[3a67ebcab5dc3563dc161fdc3c7fb161](https://www.virustotal.com/gui/file/3a67ebcab5dc3563dc161fdc3c7fb161)|Win32 EXE|fakeav|2016-02-12 16:03:48|antimalware.exe|
|[94d29dded4dfd920fc4153f18e82fc6c](https://www.virustotal.com/gui/file/94d29dded4dfd920fc4153f18e82fc6c)|Win32 EXE|razy|2016-02-12 16:03:08|servicesdefender.exe|
|[b8b70732a105372d05cd2d8e03a75ff9](https://www.virustotal.com/gui/file/b8b70732a105372d05cd2d8e03a75ff9)|Email|CVE-2012-0158|2016-02-12 04:52:04|Personal Request C_O Brig Mehta (2).eml|
|[3fafced0432cfe9c8efe00043f386b6a](https://www.virustotal.com/gui/file/3fafced0432cfe9c8efe00043f386b6a)|Email|CVE-2012-0158|2016-02-12 04:51:38|Personal Request C_O Brig Mehta (3).eml|
|[3966f669a6af4278869b9cce0f2d9279](https://www.virustotal.com/gui/file/3966f669a6af4278869b9cce0f2d9279)|Rich Text Format|CVE-2012-0158|2016-02-12 04:51:35|Harrasment Case Shakantula.doc|
|[c0eb694960d0a7316264ced4d44b3abb](https://www.virustotal.com/gui/file/c0eb694960d0a7316264ced4d44b3abb)|Win32 EXE|MSILPerseus|2016-02-11 06:32:21|msword.exe|
|[ee23470258397f29914a44309817aa5a](https://www.virustotal.com/gui/file/ee23470258397f29914a44309817aa5a)|XLS||2016-02-10 16:34:12|10feb.xls|
|[f710e3ad19a682dab374c167c7c2796a](https://www.virustotal.com/gui/file/f710e3ad19a682dab374c167c7c2796a)|Win32 EXE|kazy|2016-02-09 19:18:10|filescan.exe|
|[06c18c72f9f136bacc5c9b0d8fa93195](https://www.virustotal.com/gui/file/06c18c72f9f136bacc5c9b0d8fa93195)|Win32 EXE||2016-02-09 11:00:30|msantimalware.exe|
|[eaee83a376914616924eab9b4b96b050](https://www.virustotal.com/gui/file/eaee83a376914616924eab9b4b96b050)|Win32 EXE|razy|2016-02-08 20:00:29|servicesDefender.exe|
|[da56347c80bb441eee4a78bf355b1099](https://www.virustotal.com/gui/file/da56347c80bb441eee4a78bf355b1099)|Win32 EXE|Disfa|2016-02-08 11:13:15|/home/virustotal/sample/DA56347C80BB441EEE4A78BF355B1099|
|[14be26aa207cff81ff814c8a7a8e2f03](https://www.virustotal.com/gui/file/14be26aa207cff81ff814c8a7a8e2f03)|Win32 EXE|MSILPerseus|2016-02-06 13:20:29|msedefender.exe|
|[75798547f0ddca076070bcea67a0b064](https://www.virustotal.com/gui/file/75798547f0ddca076070bcea67a0b064)|Win32 EXE|Zbot|2016-02-04 21:43:40|wsecurity.exe|
|[897fc3a65f84e1c3db932965a574d982](https://www.virustotal.com/gui/file/897fc3a65f84e1c3db932965a574d982)|Win32 EXE|dynamer|2016-02-04 16:09:32|msisecurity.exe|
|[4b1a627c43d4e0af504bf20023e74f6b](https://www.virustotal.com/gui/file/4b1a627c43d4e0af504bf20023e74f6b)|Win32 EXE|strictor|2016-02-03 06:51:33|png.exe|
|[cf5e472613921dc330008c79870b23ab](https://www.virustotal.com/gui/file/cf5e472613921dc330008c79870b23ab)|Win32 EXE||2016-02-01 12:26:58|udriver.exe|
|[127ee83854f47628984ab47de725ee2f](https://www.virustotal.com/gui/file/127ee83854f47628984ab47de725ee2f)|Win32 EXE||2016-02-01 12:23:42|svehost.exe|
|[bcbac2241977c976aec01592fb514aa4](https://www.virustotal.com/gui/file/bcbac2241977c976aec01592fb514aa4)|Win32 EXE||2016-02-01 12:03:52|httpservice.exe|
|[9fcc3e18b9c0bd7380325f24a4623439](https://www.virustotal.com/gui/file/9fcc3e18b9c0bd7380325f24a4623439)|Win32 EXE||2016-02-01 12:01:48|httpscan.exe|
|[5b4361e6a6117e9f7189a564f46157d7](https://www.virustotal.com/gui/file/5b4361e6a6117e9f7189a564f46157d7)|Win32 EXE|razy|2016-01-30 15:23:22|msoutlook.exe|
|[1ab5f55763663ffb0807079397812b47](https://www.virustotal.com/gui/file/1ab5f55763663ffb0807079397812b47)|Win32 EXE|Zbot|2016-01-30 03:15:51|microsoftdocs.exe|
|[032bacaea0d335daec271f228db6bc88](https://www.virustotal.com/gui/file/032bacaea0d335daec271f228db6bc88)|Win32 EXE||2016-01-26 20:20:55|securetychecks.exe|
|[0b651ef0eb7b919e91a2c5c5dbccd27e](https://www.virustotal.com/gui/file/0b651ef0eb7b919e91a2c5c5dbccd27e)|Win32 EXE|MSILPerseus|2016-01-25 03:18:20|securetychecks.exe|
|[eee91d8de7ea7c0ac3372f65c43e916a](https://www.virustotal.com/gui/file/eee91d8de7ea7c0ac3372f65c43e916a)|Win32 EXE|razy|2016-01-24 03:44:32|msantimalware.exe|
|[9bdfc0d5c45f1ce1200419ec6eec15f4](https://www.virustotal.com/gui/file/9bdfc0d5c45f1ce1200419ec6eec15f4)|Win32 EXE||2016-01-23 09:16:57|msexcel.exe|
|[43ffbc0f74d4bf61b2a71c8c552fa52b](https://www.virustotal.com/gui/file/43ffbc0f74d4bf61b2a71c8c552fa52b)|XLS||2016-01-23 04:54:23|csd-car-price-list-2016.xls|
|[3e91836b89b6d6249741dc8ee0d2895a](https://www.virustotal.com/gui/file/3e91836b89b6d6249741dc8ee0d2895a)|Win32 EXE|MSILPerseus|2016-01-19 13:19:07|microsoftdocs.exe|
|[c0bf5a0f535380edec9b42a3cebb84c4](https://www.virustotal.com/gui/file/c0bf5a0f535380edec9b42a3cebb84c4)|Win32 EXE||2016-01-15 03:10:11|windows_defender.exe|
|[6c3b38bf90a203b2f7542d0359b8e60e](https://www.virustotal.com/gui/file/6c3b38bf90a203b2f7542d0359b8e60e)|Win32 EXE|MSILPerseus|2016-01-14 06:52:12|securetycheck.exe|
|[34ad98510d4d6e24b7e38f27a24ad9f6](https://www.virustotal.com/gui/file/34ad98510d4d6e24b7e38f27a24ad9f6)|Win32 EXE|razy|2016-01-14 06:49:36|securetychecks.exe|
|[71cd70b289c53567579f8f6033d8191b](https://www.virustotal.com/gui/file/71cd70b289c53567579f8f6033d8191b)|Win32 EXE|MSILPerseus|2016-01-13 20:18:11|filescan.exe|
|[438f3ea41587e9891484dad233d6faa6](https://www.virustotal.com/gui/file/438f3ea41587e9891484dad233d6faa6)|Win32 EXE|dynamer|2016-01-13 20:18:11|filescan.exe|
|[7ccc752b5956b86b966d15a6a4cf6df0](https://www.virustotal.com/gui/file/7ccc752b5956b86b966d15a6a4cf6df0)|Win32 EXE|msilperseus|2016-01-13 20:18:10|filescan.exe|
|[b2ed9415d7cf9bc06f8ccb8cfdba1ad6](https://www.virustotal.com/gui/file/b2ed9415d7cf9bc06f8ccb8cfdba1ad6)|Win32 EXE||2016-01-13 20:18:10|filescan.exe|
|[12929730cd95c6cf50dd3d470dd5f347](https://www.virustotal.com/gui/file/12929730cd95c6cf50dd3d470dd5f347)|Win32 EXE|MSILPerseus|2016-01-13 20:18:10|filescan.exe|
|[d8637bdbcfc9112fcb1f0167b398e771](https://www.virustotal.com/gui/file/d8637bdbcfc9112fcb1f0167b398e771)|Win32 EXE|msilperseus|2016-01-13 20:18:09|filescan.exe|
|[3c922fab76a6c48be4036a2d0d2146c1](https://www.virustotal.com/gui/file/3c922fab76a6c48be4036a2d0d2146c1)|Win32 EXE||2016-01-13 06:25:16|microsoftdocs.exe|
|[af046d94f254a3f85a0ba731562a05c5](https://www.virustotal.com/gui/file/af046d94f254a3f85a0ba731562a05c5)|Android|sandr|2016-01-12 06:15:27|af046d94f254a3f85a0ba731562a05c5.virus|
|[870c0312cea7b3b6b82be01633b071cd](https://www.virustotal.com/gui/file/870c0312cea7b3b6b82be01633b071cd)|Win32 EXE||2016-01-11 08:39:40|skypeupdate.exe|
|[5a6bec1a9c38f6857525cca40f64b2ed](https://www.virustotal.com/gui/file/5a6bec1a9c38f6857525cca40f64b2ed)|Win32 EXE||2016-01-07 09:17:10|windowsWord.exe|
|[df6be8accc487bf63260aacf5e582fe2](https://www.virustotal.com/gui/file/df6be8accc487bf63260aacf5e582fe2)|Win32 EXE||2016-01-07 07:30:24|servicesscan.exe|
|[b6263f987fdec3fb3877845c8d5479dd](https://www.virustotal.com/gui/file/b6263f987fdec3fb3877845c8d5479dd)|Win32 EXE|MSILPerseus|2016-01-07 07:29:53|svshost.exe|
|[59e0fc469d1af7532507c19b47f19960](https://www.virustotal.com/gui/file/59e0fc469d1af7532507c19b47f19960)|Win32 EXE||2016-01-07 07:28:30|wservices.exe|
|[723d85f905588f092edf8691c1095fdb](https://www.virustotal.com/gui/file/723d85f905588f092edf8691c1095fdb)|Win32 EXE|kazy|2016-01-05 08:26:27|msdocuments.exe|
|[65f6143d69cb1246a117a704e9f07fdc](https://www.virustotal.com/gui/file/65f6143d69cb1246a117a704e9f07fdc)|Win32 EXE|MSILPerseus|2016-01-05 08:23:38|msdocuments.exe|
|[92f78a182faf26550d6fab2d9ec0692d](https://www.virustotal.com/gui/file/92f78a182faf26550d6fab2d9ec0692d)|Win32 EXE|kazy|2015-12-31 05:26:42|msedefender.exe|
|[51c57b0366d0b71acf05b4df0afef52f](https://www.virustotal.com/gui/file/51c57b0366d0b71acf05b4df0afef52f)|Win32 EXE|MSILPerseus|2015-12-29 16:41:09|filescan.exe|
|[cedb0fc3dfbb748fdcbb3eae9eb0a3f1](https://www.virustotal.com/gui/file/cedb0fc3dfbb748fdcbb3eae9eb0a3f1)|Win32 EXE|MSILPerseus|2015-12-29 16:41:06|filescan.exe|
|[796ae0b75c0e0b08ea84668495df4070](https://www.virustotal.com/gui/file/796ae0b75c0e0b08ea84668495df4070)|Win32 EXE|MSILPerseus|2015-12-25 01:47:08|totalSecurity.exe|
|[cb0768c89e83f2328952ba51e4d4b7f1](https://www.virustotal.com/gui/file/cb0768c89e83f2328952ba51e4d4b7f1)|Win32 EXE||2015-12-24 23:38:25|windows_defender.exe|
|[af071cd2420057090cfe33fefa139d01](https://www.virustotal.com/gui/file/af071cd2420057090cfe33fefa139d01)|Win32 EXE||2015-12-24 11:50:37|gif.exe|
|[417fa395f91b1b61e5fd73cd586953e1](https://www.virustotal.com/gui/file/417fa395f91b1b61e5fd73cd586953e1)|Win32 EXE||2015-12-23 15:46:38|Accn Letter.scr|
|[c3af6b938988a88ea2dc2e59f8418062](https://www.virustotal.com/gui/file/c3af6b938988a88ea2dc2e59f8418062)|Win32 EXE|Ursu|2015-12-23 02:25:35|mp4.exe|
|[bf1400105c97a28fefd33d8c0df5d4c1](https://www.virustotal.com/gui/file/bf1400105c97a28fefd33d8c0df5d4c1)|Win32 EXE|MSILPerseus|2015-12-22 18:25:53|securetycheck.exe|
|[292f468f98e322795d1185c2b15c1f62](https://www.virustotal.com/gui/file/292f468f98e322795d1185c2b15c1f62)|Win32 EXE||2015-12-21 19:13:10|FireFox.exe|
|[c303a6ac44e3c59a9c3613ac9f92373b](https://www.virustotal.com/gui/file/c303a6ac44e3c59a9c3613ac9f92373b)|Win32 EXE||2015-12-21 19:12:57|winscan.exe|
|[d938a75d93c20790b1f2b5d5b7294895](https://www.virustotal.com/gui/file/d938a75d93c20790b1f2b5d5b7294895)|Win32 EXE||2015-12-21 19:12:41|chrome_update.exe|
|[f1a2caf0dd7922ea3a64231fd5af7715](https://www.virustotal.com/gui/file/f1a2caf0dd7922ea3a64231fd5af7715)|Win32 EXE||2015-12-21 19:12:28|micrsosftWord.exe|
|[9e73d275202b02b3f0ed23951fda30da](https://www.virustotal.com/gui/file/9e73d275202b02b3f0ed23951fda30da)|Win32 EXE||2015-12-21 07:19:03|IntelHD.exe|
|[6a1c037c66184aa39096933f75d2d8ca](https://www.virustotal.com/gui/file/6a1c037c66184aa39096933f75d2d8ca)|Win32 EXE||2015-12-21 05:31:10|gif.exe|
|[07defabf004c891ae836de91260e6c82](https://www.virustotal.com/gui/file/07defabf004c891ae836de91260e6c82)|Win32 EXE||2015-12-21 04:40:16|msdocuments.exe|
|[d53de7c980eb34f9369e342d5d235c9b](https://www.virustotal.com/gui/file/d53de7c980eb34f9369e342d5d235c9b)|Win32 EXE||2015-12-20 08:55:01|msservices.exe|
|[0ed7f485166796e10bcb9123de24d211](https://www.virustotal.com/gui/file/0ed7f485166796e10bcb9123de24d211)|Win32 EXE||2015-12-19 08:17:38|secure_scan.exe|
|[bf2eb6c19778a35f812ddc86d616c837](https://www.virustotal.com/gui/file/bf2eb6c19778a35f812ddc86d616c837)|Win32 EXE||2015-12-17 19:35:02|usbdriver.exe|
|[0437655995f4d3104989fb963aa41339](https://www.virustotal.com/gui/file/0437655995f4d3104989fb963aa41339)|Win32 EXE|Emotet|2015-12-17 10:06:44|totalSecurity.exe|
|[278fd26be39a06d5e19c5e7fd7d3dcc2](https://www.virustotal.com/gui/file/278fd26be39a06d5e19c5e7fd7d3dcc2)|XLS||2015-12-16 05:41:06|/upd/AWHO-Upcoming-Projects.xls|
|[e456d6035e41962a4e49345b00393dcd](https://www.virustotal.com/gui/file/e456d6035e41962a4e49345b00393dcd)|Win32 EXE||2015-12-15 21:03:32|securetycheck.exe|
|[c0ff05a6bf05465adfc9a1dfd5305bde](https://www.virustotal.com/gui/file/c0ff05a6bf05465adfc9a1dfd5305bde)|Win32 EXE|Fareit|2015-12-11 11:49:42|totalSecurity.exe|
|[ce59958c01e437f4bdc68b4896222b8e](https://www.virustotal.com/gui/file/ce59958c01e437f4bdc68b4896222b8e)|Android|Kasandra|2015-12-11 08:20:12|ce59958c01e437f4bdc68b4896222b8e.virus|
|[131b4ed3df80e2f794a3e353e2c7f8fb](https://www.virustotal.com/gui/file/131b4ed3df80e2f794a3e353e2c7f8fb)|Win32 EXE||2015-12-10 14:59:57|/home/netml/Desktop/TestMalwares/131b4ed3df80e2f794a3e353e2c7f8fb|
|[76f410c27d97e6c0403df274bebd5f6e](https://www.virustotal.com/gui/file/76f410c27d97e6c0403df274bebd5f6e)|XLS|Banload|2015-12-08 10:46:29|/upd/un-jobs-details.xls|
|[2d6d0dbd8ac7c941d78ba14289a7ab9d](https://www.virustotal.com/gui/file/2d6d0dbd8ac7c941d78ba14289a7ab9d)|Win32 EXE|MSILPerseus|2015-12-04 07:17:13|filescan.exe|
|[19f2780064f960ad257d1dd02905db88](https://www.virustotal.com/gui/file/19f2780064f960ad257d1dd02905db88)|Android||2015-12-03 08:45:52|19f2780064f960ad257d1dd02905db88.virus|
|[f5d1eea264840ba59d1b0769f268e7e4](https://www.virustotal.com/gui/file/f5d1eea264840ba59d1b0769f268e7e4)|Android|androidos|2015-12-03 08:32:52|f5d1eea264840ba59d1b0769f268e7e4.virus|
|[22e5c74a2153b4b2eeda59ff17df97fe](https://www.virustotal.com/gui/file/22e5c74a2153b4b2eeda59ff17df97fe)|Android|sandr|2015-11-24 18:48:33|22e5c74a2153b4b2eeda59ff17df97fe.virus|
|[708a1af68d532df35c34f7088b8e798f](https://www.virustotal.com/gui/file/708a1af68d532df35c34f7088b8e798f)|Win32 EXE|razy|2015-11-22 16:05:06|/home/netml/Desktop/TestMalwares/708a1af68d532df35c34f7088b8e798f|
|[0e93b58193fe8ff8b84d543b535f313c](https://www.virustotal.com/gui/file/0e93b58193fe8ff8b84d543b535f313c)|XLS|o97m|2015-11-21 16:37:11|/cu/awho_handot_2015.xls|
|[c3d65d73cd6894fdad3fc281b976fd8b](https://www.virustotal.com/gui/file/c3d65d73cd6894fdad3fc281b976fd8b)|Win32 EXE||2015-11-17 19:10:16|udriver.exe|
|[5371d2984cbd1ae8283f9ae9eeee718d](https://www.virustotal.com/gui/file/5371d2984cbd1ae8283f9ae9eeee718d)|Win32 EXE|kazy|2015-11-17 07:50:33|microsoftDefender.exe|
|[f04b6fed9fcdb8fa480419f75047c8d2](https://www.virustotal.com/gui/file/f04b6fed9fcdb8fa480419f75047c8d2)|Win32 EXE|msilperseus|2015-11-16 11:31:56|filescan.exe|
|[1af4df1382c04677050379ccdafcafd2](https://www.virustotal.com/gui/file/1af4df1382c04677050379ccdafcafd2)|Win32 EXE||2015-11-16 08:42:42|totalSecurity.exe|
|[11ba93d968bd96e9e9c9418ea1fdcbbc](https://www.virustotal.com/gui/file/11ba93d968bd96e9e9c9418ea1fdcbbc)|Android||2015-11-14 18:49:11|11ba93d968bd96e9e9c9418ea1fdcbbc.virus|
|[2dfe4468a052a07cab117a20e182adc9](https://www.virustotal.com/gui/file/2dfe4468a052a07cab117a20e182adc9)|Win32 EXE|kazy|2015-11-09 08:50:22|skypeupdate.exe|
|[dfd2eca84919418da2fa617fc51e9de5](https://www.virustotal.com/gui/file/dfd2eca84919418da2fa617fc51e9de5)|Android||2015-11-08 20:45:56|dfd2eca84919418da2fa617fc51e9de5.virus|
|[5ff65fdefe144800e43a2f6cc6244c75](https://www.virustotal.com/gui/file/5ff65fdefe144800e43a2f6cc6244c75)|Win32 EXE||2015-11-07 00:02:41|smartSecurity.exe|
|[7470757050f584101a851d7ba105db31](https://www.virustotal.com/gui/file/7470757050f584101a851d7ba105db31)|Win32 EXE|dynamer|2015-11-06 17:06:44|dc773c4533177898a5d2a2277f512824cce97170|
|[2507f545a2d6e52ade2d7708d9ce89d1](https://www.virustotal.com/gui/file/2507f545a2d6e52ade2d7708d9ce89d1)|Win32 EXE|dynamer|2015-11-06 08:17:46|windows_service.exe|
|[ed1daf18ef09fb2a5c58ab89824ecab0](https://www.virustotal.com/gui/file/ed1daf18ef09fb2a5c58ab89824ecab0)|Win32 EXE||2015-11-05 17:00:46|IntelHD.exe|
|[9e0fef5552100a7e0a2d044b63736fb2](https://www.virustotal.com/gui/file/9e0fef5552100a7e0a2d044b63736fb2)|Win32 EXE||2015-11-05 10:06:37|/home/netml/Desktop/TestMalwares/9e0fef5552100a7e0a2d044b63736fb2|
|[f936afdd0b69d109215d295ab864d309](https://www.virustotal.com/gui/file/f936afdd0b69d109215d295ab864d309)|Win32 EXE|Zbot|2015-11-05 06:06:33|winscan.exe|
|[7289c160582f010a3c7dbd512c5d8a09](https://www.virustotal.com/gui/file/7289c160582f010a3c7dbd512c5d8a09)|Win32 EXE|MSILPerseus|2015-11-04 14:53:50|smartSecurity.exe|
|[dac4f8ba3190cfa1f813e79864a73fe1](https://www.virustotal.com/gui/file/dac4f8ba3190cfa1f813e79864a73fe1)|Win32 EXE||2015-11-02 01:46:09|smartSecurity.exe|
|[38ce32cb94092cc6790030abcc9a638b](https://www.virustotal.com/gui/file/38ce32cb94092cc6790030abcc9a638b)|Win32 EXE||2015-10-29 16:47:25|windowsWord.exe|
|[43f47d2045ca98265fd4bd4011a04932](https://www.virustotal.com/gui/file/43f47d2045ca98265fd4bd4011a04932)|Win32 EXE||2015-10-29 16:28:22|microsoftDefender.exe|
|[b55a7da332bed90e798313b968ce7819](https://www.virustotal.com/gui/file/b55a7da332bed90e798313b968ce7819)|Win32 EXE|kazy|2015-10-28 02:23:35|chromes.exe|
|[0991033c2414b4992c1b5ab21c5a47e2](https://www.virustotal.com/gui/file/0991033c2414b4992c1b5ab21c5a47e2)|Win32 EXE|MSILPerseus|2015-10-27 03:26:41|filescan.exe|
|[ae9659a2c08e2cb9ab9e5cdcb8ab4036](https://www.virustotal.com/gui/file/ae9659a2c08e2cb9ab9e5cdcb8ab4036)|Win32 EXE||2015-10-27 00:05:39|filescan.exe|
|[4d7ad9ab4c1d40365da60d4f2f195db4](https://www.virustotal.com/gui/file/4d7ad9ab4c1d40365da60d4f2f195db4)|Win32 EXE|Zbot|2015-10-25 17:13:24|winscan.exe|
|[ec4bef2233002d8fe568428d16e610b1](https://www.virustotal.com/gui/file/ec4bef2233002d8fe568428d16e610b1)|Win32 EXE|Zbot|2015-10-25 17:08:32|winscan.exe|
|[e66203177a03743a6361a7b3e668b6a6](https://www.virustotal.com/gui/file/e66203177a03743a6361a7b3e668b6a6)|Win32 EXE||2015-10-25 16:35:13|windowsWord.exe|
|[43b39b40605afb9d2624f1cede6b48a8](https://www.virustotal.com/gui/file/43b39b40605afb9d2624f1cede6b48a8)|Win32 EXE||2015-10-23 20:10:43|adobe_update.exe|
|[522178a60b030bbab910cb86cfeaff20](https://www.virustotal.com/gui/file/522178a60b030bbab910cb86cfeaff20)|Win32 EXE|strictor|2015-10-22 08:52:30|security_scan.exe|
|[0747848ae0fc45b3eae1d142024e700e](https://www.virustotal.com/gui/file/0747848ae0fc45b3eae1d142024e700e)|Win32 EXE|kazy|2015-10-21 10:54:57|filescan.exe|
|[e3254ad0275370f92cffeacbf603a905](https://www.virustotal.com/gui/file/e3254ad0275370f92cffeacbf603a905)|Win32 EXE||2015-10-21 09:17:52|securityScan.exe|
|[92d6366d692a1b3691dce1379bb7b5aa](https://www.virustotal.com/gui/file/92d6366d692a1b3691dce1379bb7b5aa)|Win32 EXE|Zbot|2015-10-19 20:25:04|winscan.exe|
|[4f9b754da90bed9a633130d893d65c4e](https://www.virustotal.com/gui/file/4f9b754da90bed9a633130d893d65c4e)|Win32 EXE|barys|2015-10-19 16:54:33|wanscan.exe|
|[aec91b4453a1b321e302127bc9f21a7c](https://www.virustotal.com/gui/file/aec91b4453a1b321e302127bc9f21a7c)|Win32 EXE||2015-10-19 15:48:17|qzxdxzeP.exe|
|[29097319b60c103421437214d5a3297e](https://www.virustotal.com/gui/file/29097319b60c103421437214d5a3297e)|Win32 EXE||2015-10-19 14:01:40|winword.exe|
|[1bedd50f4ae757c6009acbe7da021122](https://www.virustotal.com/gui/file/1bedd50f4ae757c6009acbe7da021122)|Win32 EXE|MSILPerseus|2015-10-16 12:37:08|filescan.exe|
|[eb01bbfe8ca7e8f59aab475ad1f18245](https://www.virustotal.com/gui/file/eb01bbfe8ca7e8f59aab475ad1f18245)|Win32 EXE|MSILPerseus|2015-10-13 07:58:04|attachment.exe|
|[c61061a40dba411b839fe631299c267a](https://www.virustotal.com/gui/file/c61061a40dba411b839fe631299c267a)|Win32 EXE||2015-10-13 05:32:38|secure_scan.exe|
|[0d7846a76675be378a50667767d0e35a](https://www.virustotal.com/gui/file/0d7846a76675be378a50667767d0e35a)|Win32 EXE||2015-10-12 09:12:33|filescan.exe|
|[73b878e56f790dccf08bd2344b4031c8](https://www.virustotal.com/gui/file/73b878e56f790dccf08bd2344b4031c8)|Win32 EXE||2015-10-11 23:46:39|firewallScan.exe|
|[d0152f228e934dcafa866445c08e3242](https://www.virustotal.com/gui/file/d0152f228e934dcafa866445c08e3242)|Win32 EXE|kazy|2015-10-10 02:47:09|security_scan.exe|
|[8336d9aeccee3408a4f9fbf4b1a42bac](https://www.virustotal.com/gui/file/8336d9aeccee3408a4f9fbf4b1a42bac)|Win32 EXE||2015-10-08 19:05:03|skypeupdate.exe|
|[7e50c67f1e94b154f110d5d73e2f312c](https://www.virustotal.com/gui/file/7e50c67f1e94b154f110d5d73e2f312c)|Win32 EXE||2015-10-06 06:40:58|filescan.exe|
|[a74165ec1d55b682ed232ffde62b3b11](https://www.virustotal.com/gui/file/a74165ec1d55b682ed232ffde62b3b11)|Win32 EXE||2015-10-05 18:16:46|skypeupdate.exe|
|[f0f6544ddb26c55df2d6184f433d8c17](https://www.virustotal.com/gui/file/f0f6544ddb26c55df2d6184f433d8c17)|Win32 EXE|MSILPerseus|2015-10-05 06:20:10|filescan.exe|
|[d3094c89cad5f8d1ea5f0a7f23f0a2b1](https://www.virustotal.com/gui/file/d3094c89cad5f8d1ea5f0a7f23f0a2b1)|Win32 EXE||2015-10-04 17:17:37|wmplayer.exe|
|[950eb314435bdb3c46c9f0954c935287](https://www.virustotal.com/gui/file/950eb314435bdb3c46c9f0954c935287)|Win32 EXE||2015-10-04 11:16:21|wmapphost.exe|
|[7c23f984170fd793cfde5fd68535d0a8](https://www.virustotal.com/gui/file/7c23f984170fd793cfde5fd68535d0a8)|Win32 EXE||2015-10-03 08:08:03|filescan.exe|
|[df6b3946d1064f37d1b99f7bfae51203](https://www.virustotal.com/gui/file/df6b3946d1064f37d1b99f7bfae51203)|Win32 EXE|MSILPerseus|2015-10-01 10:44:26|secure_scan.exe|
|[6d2442494c3019f1597256cbeb45e5f6](https://www.virustotal.com/gui/file/6d2442494c3019f1597256cbeb45e5f6)|Win32 EXE||2015-09-29 06:25:47|secure_scan.exe|
|[9b3cb979b1397a4a13ea62dbf46510d8](https://www.virustotal.com/gui/file/9b3cb979b1397a4a13ea62dbf46510d8)|Win32 EXE|dynamer|2015-09-18 16:47:26|filescan.exe|
|[ccfd8c384558c5a1e09350941faa08ab](https://www.virustotal.com/gui/file/ccfd8c384558c5a1e09350941faa08ab)|Win32 EXE||2015-09-18 13:08:56|wanscan.exe|
|[5c6b401979469040b39babb0469fc0c8](https://www.virustotal.com/gui/file/5c6b401979469040b39babb0469fc0c8)|Win32 EXE||2015-09-17 16:27:44|secure_scan.exe|
|[b67047e341653a01526cc178966d1f6c](https://www.virustotal.com/gui/file/b67047e341653a01526cc178966d1f6c)|Win32 EXE|dynamer|2015-09-17 07:22:12|skypeupdate.exe|
|[17495ce3d11e9cddf5a98ec34ee91d6a](https://www.virustotal.com/gui/file/17495ce3d11e9cddf5a98ec34ee91d6a)|Win32 EXE|razy|2015-09-12 22:37:01|filescan.exe|
|[5d9b42853ecf3ff28d4e4313276b21ed](https://www.virustotal.com/gui/file/5d9b42853ecf3ff28d4e4313276b21ed)|Win32 EXE||2015-09-12 21:14:48|googletsk.exe|
|[148403235614461c1f088d524fbd9fd0](https://www.virustotal.com/gui/file/148403235614461c1f088d524fbd9fd0)|Win32 EXE|MSILPerseus|2015-09-09 07:58:56|filescan.exe|
|[e7803020e9697d77f165babecf20ea82](https://www.virustotal.com/gui/file/e7803020e9697d77f165babecf20ea82)|Win32 EXE||2015-09-06 06:33:13|secure_scan.exe|
|[16eb146eee147a333ef82d39266d5cfb](https://www.virustotal.com/gui/file/16eb146eee147a333ef82d39266d5cfb)|Win32 EXE|kazy|2015-09-04 20:50:05|windows_service.exe|
|[1a1426a94e37e5f3c14cd2b6740e27e1](https://www.virustotal.com/gui/file/1a1426a94e37e5f3c14cd2b6740e27e1)|Win32 EXE|MSILPerseus|2015-09-01 15:07:14|windows_defender.exe|
|[ef0ab9f731e7c980b163c7e1b5db9746](https://www.virustotal.com/gui/file/ef0ab9f731e7c980b163c7e1b5db9746)|Win32 EXE||2015-08-31 11:20:28|filescan.exe|
|[ac637313520ca159a02d674474d341ef](https://www.virustotal.com/gui/file/ac637313520ca159a02d674474d341ef)|Win32 EXE|skeeyah|2015-08-26 17:41:22|secure_scan.exe|
|[6eb40b2e6a67a785d5cc6e4ad9102b5d](https://www.virustotal.com/gui/file/6eb40b2e6a67a785d5cc6e4ad9102b5d)|Win32 EXE||2015-08-25 14:43:15|secure_scan.exe|
|[803d2758c3b89882e2d41867768d7b15](https://www.virustotal.com/gui/file/803d2758c3b89882e2d41867768d7b15)|Win32 EXE||2015-08-25 14:41:35|secure_scan.exe|
|[e0217714f3a03fae4cdf4b5120213c38](https://www.virustotal.com/gui/file/e0217714f3a03fae4cdf4b5120213c38)|Win32 EXE||2015-08-24 03:00:19|IntelVHD.exe|
|[82377fcf288e9db675ab24cbf76ea032](https://www.virustotal.com/gui/file/82377fcf288e9db675ab24cbf76ea032)|Win32 EXE||2015-08-23 15:52:07|service_security.exe|
|[a3aa3a12d81c9862b18f83a77d7215ca](https://www.virustotal.com/gui/file/a3aa3a12d81c9862b18f83a77d7215ca)|Win32 EXE||2015-08-22 21:01:52|windows_defender.exe|
|[f6d141f45e76cefcb712f69c193b3ac1](https://www.virustotal.com/gui/file/f6d141f45e76cefcb712f69c193b3ac1)|Win32 EXE||2015-08-15 18:12:13|/home/netml/Desktop/TestMalwares/f6d141f45e76cefcb712f69c193b3ac1|
|[9b674985a412c4c07d52c7482c2ed286](https://www.virustotal.com/gui/file/9b674985a412c4c07d52c7482c2ed286)|Win32 EXE||2015-08-14 15:27:32|access.exe|
|[79f7e1d6389c73a7e2525d0ec8fa3ce2](https://www.virustotal.com/gui/file/79f7e1d6389c73a7e2525d0ec8fa3ce2)|Win32 EXE|razy|2015-08-13 16:20:31|filescan.exe|
|[99d93e0c6bf9cf9acb92580686f6b743](https://www.virustotal.com/gui/file/99d93e0c6bf9cf9acb92580686f6b743)|Win32 EXE||2015-08-12 15:51:17|jpg.exe|
|[e2d1309893c0de5a026a2ae9e8ada486](https://www.virustotal.com/gui/file/e2d1309893c0de5a026a2ae9e8ada486)|Win32 EXE||2015-08-11 15:54:14|security_scan.exe|
|[0a8d414eb910eb4caeb96a648b70eef3](https://www.virustotal.com/gui/file/0a8d414eb910eb4caeb96a648b70eef3)|Win32 EXE|kazy|2015-08-10 01:08:34|secure_scan.exe|
|[adf657337d7fa7fa07c72b12fb880e41](https://www.virustotal.com/gui/file/adf657337d7fa7fa07c72b12fb880e41)|Win32 EXE||2015-08-08 15:47:51|security_scan.exe|
|[3ff165ee68d1bc03ae7d4d3baf99b963](https://www.virustotal.com/gui/file/3ff165ee68d1bc03ae7d4d3baf99b963)|Win32 EXE||2015-08-05 07:49:56|windows_defender.exe|
|[8c30ed1bc13feaa8e937be0f6a739be4](https://www.virustotal.com/gui/file/8c30ed1bc13feaa8e937be0f6a739be4)|Win32 EXE|Zbot|2015-08-05 05:32:34|security_scan.exe|
|[dac44b9d5a8494a3293088c9678754bc](https://www.virustotal.com/gui/file/dac44b9d5a8494a3293088c9678754bc)|Win32 EXE|skeeyah|2015-08-05 05:22:19|IntelVHD.exe|
|[8317bb3d192c4495507a5945f27705af](https://www.virustotal.com/gui/file/8317bb3d192c4495507a5945f27705af)|Win32 EXE||2015-08-04 17:06:34|windows_defender.exe|
|[41a0e4f9745e4bd5ad7b9d500deb76fa](https://www.virustotal.com/gui/file/41a0e4f9745e4bd5ad7b9d500deb76fa)|Win32 EXE||2015-08-04 14:30:28|windows_scan.exe|
|[29eb61f04b905e2133e9afdd12482073](https://www.virustotal.com/gui/file/29eb61f04b905e2133e9afdd12482073)|Win32 EXE||2015-07-31 00:40:33|skypescan.exe|
|[167d632eea9bd1b6cac00a69b431a5c0](https://www.virustotal.com/gui/file/167d632eea9bd1b6cac00a69b431a5c0)|Win32 EXE||2015-07-31 00:40:32|wanscan.exe|
|[f18172d7bb8b98246cb3dbb0e9144731](https://www.virustotal.com/gui/file/f18172d7bb8b98246cb3dbb0e9144731)|Win32 EXE|Zbot|2015-07-31 00:40:30|nvidia.exe|
|[3739bbf831d04e8a2b06275cd3af371d](https://www.virustotal.com/gui/file/3739bbf831d04e8a2b06275cd3af371d)|Win32 EXE||2015-07-31 00:25:24|skypeupdate.exe|
|[e3e4ced9b000aa47a449f186c7604ac8](https://www.virustotal.com/gui/file/e3e4ced9b000aa47a449f186c7604ac8)|Win32 EXE||2015-07-30 19:45:53|filescan.exe|
|[b8098acf09d121ab298351f0c804ef8b](https://www.virustotal.com/gui/file/b8098acf09d121ab298351f0c804ef8b)|Win32 EXE|razy|2015-07-25 04:46:07|secure_scan.exe|
|[943f35200dce22766d0c2906d25be187](https://www.virustotal.com/gui/file/943f35200dce22766d0c2906d25be187)|Win32 EXE||2015-07-18 09:19:56|windows_defender.exe|
|[7a6b88e43cccc8133c066b87f72c53f7](https://www.virustotal.com/gui/file/7a6b88e43cccc8133c066b87f72c53f7)|Win32 EXE||2015-07-16 20:25:32|secure_scan.exe|
|[85e2c950ddb18fe1dd18709cfbb9b203](https://www.virustotal.com/gui/file/85e2c950ddb18fe1dd18709cfbb9b203)|Win32 EXE||2015-07-13 10:40:37|secure_scan.exe|
|[1f97ddaea7ac0c4e20b2db75969b4545](https://www.virustotal.com/gui/file/1f97ddaea7ac0c4e20b2db75969b4545)|Win32 EXE|Kryptik|2015-07-10 16:56:16|tWCZAiqZ.exe|
|[1e5c2029dafdd50dce2effd5154b6879](https://www.virustotal.com/gui/file/1e5c2029dafdd50dce2effd5154b6879)|Win32 EXE|dynamer|2015-07-10 15:47:59|usbdriver.exe|
|[9079f06a955a4ad20de17fa605476619](https://www.virustotal.com/gui/file/9079f06a955a4ad20de17fa605476619)|Win32 EXE|strictor|2015-07-10 09:57:48|securityScan.exe|
|[052eb62056794a08a04f4cd61455602c](https://www.virustotal.com/gui/file/052eb62056794a08a04f4cd61455602c)|Win32 EXE||2015-07-05 15:16:48|servicescan.exe|
|[725379749d3fa793edcce12291782134](https://www.virustotal.com/gui/file/725379749d3fa793edcce12291782134)|Win32 EXE||2015-07-05 15:16:47|cmc.exe|
|[4297041e3a701ed8c01e40d6c54264a1](https://www.virustotal.com/gui/file/4297041e3a701ed8c01e40d6c54264a1)|Win32 EXE||2015-06-12 19:40:02|windows_defender.exe|
|[31a9e46ff607b842b8fff4a0644cc0f4](https://www.virustotal.com/gui/file/31a9e46ff607b842b8fff4a0644cc0f4)|Win32 EXE||2015-05-30 11:33:43|5331a1d01a260875c12aef094db49582d9dd637a|
|[5d038817ffeab7715415d68d438af345](https://www.virustotal.com/gui/file/5d038817ffeab7715415d68d438af345)|Win32 EXE||2015-05-19 09:33:34|services_scan.exe|
|[17d22686bfc825d9369a0751c4cc6a22](https://www.virustotal.com/gui/file/17d22686bfc825d9369a0751c4cc6a22)|Win32 EXE||2015-04-10 06:05:37|avssync_3398.exe|
|[05ccf90e3d6ad057a67dffd80119cda1](https://www.virustotal.com/gui/file/05ccf90e3d6ad057a67dffd80119cda1)|Win32 EXE|Zbot|2015-03-18 12:16:27|security_scan.exe|
|[819715180810caaaa969c816eb2b7491](https://www.virustotal.com/gui/file/819715180810caaaa969c816eb2b7491)|Win32 EXE||2015-02-27 07:03:38|msoclient.exe|
|[a4ce604f8d3ac2e5facdae3c63ef4dc6](https://www.virustotal.com/gui/file/a4ce604f8d3ac2e5facdae3c63ef4dc6)|Win32 EXE||2015-01-22 07:33:57|upx.exe|
|[ee5a460ded205d2074a23e387c377840](https://www.virustotal.com/gui/file/ee5a460ded205d2074a23e387c377840)|Win32 EXE||2015-01-15 08:10:25|/home/netml/Desktop/TestMalwares/ee5a460ded205d2074a23e387c377840|
|[f7369c556966cde86b98bfe5c2f5717a](https://www.virustotal.com/gui/file/f7369c556966cde86b98bfe5c2f5717a)|Win32 EXE||2015-01-14 07:42:38|0734375001421039723.exe|
|[ab6b6f675e48d818044c5e66d05813ce](https://www.virustotal.com/gui/file/ab6b6f675e48d818044c5e66d05813ce)|Win32 EXE||2015-01-13 01:24:19|folder.exe|
|[b04117ee18182c1c07ffaf6fb35b08bc](https://www.virustotal.com/gui/file/b04117ee18182c1c07ffaf6fb35b08bc)|Win32 EXE||2015-01-12 11:06:15|btc.exe|
|[f13a1a0cbcd5e13dd00dbc77c35973ef](https://www.virustotal.com/gui/file/f13a1a0cbcd5e13dd00dbc77c35973ef)|Win32 EXE||2015-01-12 10:39:28|client.exe|
|[f4123e7f09961479452f0f42b3706293](https://www.virustotal.com/gui/file/f4123e7f09961479452f0f42b3706293)|Win32 EXE|kazy|2015-01-12 05:57:47|0734375001421039723.exe|
|[0964887f6f709f9c3f11701412acb9c1](https://www.virustotal.com/gui/file/0964887f6f709f9c3f11701412acb9c1)|Win32 EXE|strictor|2015-01-11 15:08:15|png.exe|
|[c33c79c437d94fad3476f78361df0f24](https://www.virustotal.com/gui/file/c33c79c437d94fad3476f78361df0f24)|Win32 EXE||2015-01-01 15:06:13|/home/netml/Desktop/TestMalwares/c33c79c437d94fad3476f78361df0f24|
|[82719f0f6237d3efb9dd67d95f842013](https://www.virustotal.com/gui/file/82719f0f6237d3efb9dd67d95f842013)|Win32 EXE|Andromeda|2014-12-31 11:54:26|/home/netml/Desktop/TestMalwares/82719f0f6237d3efb9dd67d95f842013|
|[2d58826fbff197918caa805aeed86059](https://www.virustotal.com/gui/file/2d58826fbff197918caa805aeed86059)|Win32 EXE|kazy|2014-12-28 03:18:49|folder.exe|
|[f8955450fbd62cb4461c725d8985ff60](https://www.virustotal.com/gui/file/f8955450fbd62cb4461c725d8985ff60)|Win32 EXE||2014-11-26 00:35:24|061388b418af03bdca9fb4b01e50a4e4edc7df3a|
|[990c3b67061109d82627a5642bf1bb68](https://www.virustotal.com/gui/file/990c3b67061109d82627a5642bf1bb68)|Win32 EXE|Andromeda|2014-11-21 11:24:45|/home/netml/Desktop/TestMalwares/990c3b67061109d82627a5642bf1bb68|
|[b67411da3ddfcae9f2a20935619e5c4a](https://www.virustotal.com/gui/file/b67411da3ddfcae9f2a20935619e5c4a)|Win32 EXE||2014-11-10 02:23:23|security_scan.exe|
|[f05834a930f6fda6b877011c3fb3ef18](https://www.virustotal.com/gui/file/f05834a930f6fda6b877011c3fb3ef18)|Win32 EXE||2014-11-06 09:48:15|mseces.exe|
|[71b4bbddf46e1990210742a406c490bf](https://www.virustotal.com/gui/file/71b4bbddf46e1990210742a406c490bf)|Win32 EXE||2014-10-31 09:47:16|msoclient.exe|
|[511bcd411ec79c6ca555670e98709e46](https://www.virustotal.com/gui/file/511bcd411ec79c6ca555670e98709e46)|Win32 EXE||2014-10-31 09:45:30|vt-upload-7KgbS|
|[75b390dc72751a062e8106328450ef87](https://www.virustotal.com/gui/file/75b390dc72751a062e8106328450ef87)|Win32 EXE|dynamer|2014-10-20 07:02:23|security_scan.exe|
|[17dbd878985b78848d4a3a758a3ef89c](https://www.virustotal.com/gui/file/17dbd878985b78848d4a3a758a3ef89c)|Win32 EXE|dynamer|2014-10-19 18:04:35|security_scan.exe|
|[a6d75b57bd597e723335f96f074f5700](https://www.virustotal.com/gui/file/a6d75b57bd597e723335f96f074f5700)|Win32 EXE|Andromeda|2014-10-16 06:40:39|/home/netml/Desktop/TestMalwares/a6d75b57bd597e723335f96f074f5700|
|[f9798f171194ee4fec5334ded3d786e7](https://www.virustotal.com/gui/file/f9798f171194ee4fec5334ded3d786e7)|Win32 EXE||2014-10-09 09:01:50|ieSecurity.exe|
|[23ec916b3eae3f88853bde8081be870f](https://www.virustotal.com/gui/file/23ec916b3eae3f88853bde8081be870f)|Win32 EXE||2014-10-08 02:17:28|/home/netml/Desktop/TestMalwares/23ec916b3eae3f88853bde8081be870f|
|[2cff1578ac42cc0cd5f59e28d6e7240f](https://www.virustotal.com/gui/file/2cff1578ac42cc0cd5f59e28d6e7240f)|Win32 EXE||2014-09-29 07:09:56|%APPDATA%\kssync\kssync_9199.exe|
|[c9e4c816b4ef23c28992e0e894b9c822](https://www.virustotal.com/gui/file/c9e4c816b4ef23c28992e0e894b9c822)|Win32 EXE||2014-09-22 07:14:23|bbm.exe|
|[3e7c2791ff7bc14ef30bba74954ef1e2](https://www.virustotal.com/gui/file/3e7c2791ff7bc14ef30bba74954ef1e2)|Win32 EXE||2014-08-29 15:49:00|googleupdates.exe|
|[b785db2b3801d5190dad9e6f03d48999](https://www.virustotal.com/gui/file/b785db2b3801d5190dad9e6f03d48999)|Win32 EXE||2014-08-26 06:02:58|usbdriver.exe|
|[2fa82dd2490fc697bb0bb0f8feb0dd85](https://www.virustotal.com/gui/file/2fa82dd2490fc697bb0bb0f8feb0dd85)|Win32 EXE||2014-08-17 15:21:49|msoklogs.exe|
|[22192141d2010fe9fed871d05573dda4](https://www.virustotal.com/gui/file/22192141d2010fe9fed871d05573dda4)|Win32 EXE||2014-08-13 07:28:09|231ca1967f581b740d31fb0cccee7c97b0ce22a3|
|[ca27cefe404821ccd8dc695da55102e8](https://www.virustotal.com/gui/file/ca27cefe404821ccd8dc695da55102e8)|Win32 EXE|kazy|2014-08-09 15:10:13|systemtask.exe|
|[90b07bc12b45f2eb1b0305949f2cec25](https://www.virustotal.com/gui/file/90b07bc12b45f2eb1b0305949f2cec25)|Win32 EXE||2014-08-03 20:55:52|googleupdates.exe|
|[2463d1ff1166e845e52a0c580fd3cb7d](https://www.virustotal.com/gui/file/2463d1ff1166e845e52a0c580fd3cb7d)|Win32 EXE||2014-07-28 15:06:09|bbm_exe|
|[fd5a419924a0816c6357b47f4e375732](https://www.virustotal.com/gui/file/fd5a419924a0816c6357b47f4e375732)|Win32 EXE|DarkKomet|2014-07-28 15:06:07|ReflectorCmd.exe|
|[e49edc719eaab11a40158c15c9dd9b7b](https://www.virustotal.com/gui/file/e49edc719eaab11a40158c15c9dd9b7b)|Win32 EXE|Bozok|2014-07-19 11:06:26|VCREAD.exe|
|[ae2ef98a91c70dc43979ce7df8e475ad](https://www.virustotal.com/gui/file/ae2ef98a91c70dc43979ce7df8e475ad)|Win32 EXE|Andromeda|2014-07-18 07:31:00|/home/netml/Desktop/TestMalwares/ae2ef98a91c70dc43979ce7df8e475ad|
|[ba4978ed1084707dfaedfa2fded65851](https://www.virustotal.com/gui/file/ba4978ed1084707dfaedfa2fded65851)|Win32 EXE|Androm|2014-07-12 21:52:12|ba4978ed1084707dfaedfa2fded65851.virobj|
|[9b77eb38e32d43a97c5bde5ec829c5ca](https://www.virustotal.com/gui/file/9b77eb38e32d43a97c5bde5ec829c5ca)|Win32 EXE|dynamer|2014-07-08 09:33:06|folder.exe|
|[2eea994efa88e0a612e82ee3e08e78f1](https://www.virustotal.com/gui/file/2eea994efa88e0a612e82ee3e08e78f1)|Win32 EXE||2014-07-08 09:19:04|intelVGA.exe|
|[4b0481a591c87e8542e2089396a10d3c](https://www.virustotal.com/gui/file/4b0481a591c87e8542e2089396a10d3c)|Win32 EXE|Androm|2014-07-07 20:05:52|vti-rescan|
|[5b6beb9ee6e604f4e474b8129e6135f4](https://www.virustotal.com/gui/file/5b6beb9ee6e604f4e474b8129e6135f4)|Win32 EXE||2014-07-07 10:45:06|security_scan.exe|
|[811eb99fb1aca98052db4b78c288889c](https://www.virustotal.com/gui/file/811eb99fb1aca98052db4b78c288889c)|Win32 EXE||2014-07-06 18:02:05|msoclient.exe|
|[133e0c441ea744951080d700604a63ee](https://www.virustotal.com/gui/file/133e0c441ea744951080d700604a63ee)|Win32 EXE|Gamarue|2014-07-06 09:38:08|VirusShare_133e0c441ea744951080d700604a63ee|
|[3b08095786731c522f5649081f8dbb7e](https://www.virustotal.com/gui/file/3b08095786731c522f5649081f8dbb7e)|Win32 EXE||2014-06-30 13:01:58|security_scan.exe|
|[7920862303764a55050d2da38b8bf4db](https://www.virustotal.com/gui/file/7920862303764a55050d2da38b8bf4db)|Win32 EXE||2014-06-14 17:50:05|1010-e861c257c257401a5bd4c5487a45696d7796135c|
|[85d182f7a0e049169a7bd0aa796fba96](https://www.virustotal.com/gui/file/85d182f7a0e049169a7bd0aa796fba96)|Win32 EXE|Symmi|2014-05-13 15:17:26|AS SSD Benchmark.exe|
|[f0e64d2b011223ece668c595406f1abc](https://www.virustotal.com/gui/file/f0e64d2b011223ece668c595406f1abc)|Win32 EXE|Symmi|2014-05-11 14:52:03|AS SSD Benchmark.exe|
|[236e7451cbce959ca0f62fb3b499b54e](https://www.virustotal.com/gui/file/236e7451cbce959ca0f62fb3b499b54e)|Win32 EXE|Bozok|2014-03-09 15:13:36|/home/netml/Desktop/TestMalwares/236e7451cbce959ca0f62fb3b499b54e|
|[fa97cba6a52896e1f2146957a6eec04f](https://www.virustotal.com/gui/file/fa97cba6a52896e1f2146957a6eec04f)|Win32 EXE||2014-02-27 15:10:56|/home/netml/Desktop/TestMalwares/fa97cba6a52896e1f2146957a6eec04f|
|[b05730eda99a9160cc3f8dec66e9f347](https://www.virustotal.com/gui/file/b05730eda99a9160cc3f8dec66e9f347)|Win32 EXE||2014-02-24 13:34:15|msoclient.exe|
|[a73494ca564f6404488a985cefd96f56](https://www.virustotal.com/gui/file/a73494ca564f6404488a985cefd96f56)|Win32 EXE||2014-02-08 02:59:34|googleupdates.exe|
|[4a717b657ea475197d967008c7db8353](https://www.virustotal.com/gui/file/4a717b657ea475197d967008c7db8353)|Win32 EXE||2014-01-25 23:28:51|/home/netml/Desktop/TestMalwares/4a717b657ea475197d967008c7db8353|
|[b467df662af8a1fbafa845c894d917e3](https://www.virustotal.com/gui/file/b467df662af8a1fbafa845c894d917e3)|Win32 EXE||2014-01-20 18:09:01|msoclient.exe|
|[535888163707b60c1a8dfefffad70635](https://www.virustotal.com/gui/file/535888163707b60c1a8dfefffad70635)|Win32 EXE|dynamer|2013-12-31 03:08:57|systemtask.exe|
|[b0327f155ebaba23102f72c1100fa26b](https://www.virustotal.com/gui/file/b0327f155ebaba23102f72c1100fa26b)|Win32 EXE||2013-12-30 08:49:02|msoclient.exe|
|[128c0ccc1252098bc2314d88f4e70044](https://www.virustotal.com/gui/file/128c0ccc1252098bc2314d88f4e70044)|Win32 EXE|Andromeda|2013-12-21 19:03:56|10|
|[5dbeb8475e22a938415eb43e6bd24fe8](https://www.virustotal.com/gui/file/5dbeb8475e22a938415eb43e6bd24fe8)|Win32 EXE||2013-12-05 17:52:22|msoclient.exe|
|[c0ceba3a708082c372c077aa9420d09e](https://www.virustotal.com/gui/file/c0ceba3a708082c372c077aa9420d09e)|Win32 EXE||2013-12-02 15:20:09|udrive.exe|
|[44145124e046804bf579c8839b63a9a7](https://www.virustotal.com/gui/file/44145124e046804bf579c8839b63a9a7)|Win32 EXE||2013-11-25 20:30:03|googleupdates.exe|
|[44fe2f4dd8b001bbcc4de737128095ca](https://www.virustotal.com/gui/file/44fe2f4dd8b001bbcc4de737128095ca)|Win32 EXE|wacatac|2013-11-21 22:22:54|/home/netml/Desktop/TestMalwares/44fe2f4dd8b001bbcc4de737128095ca|
|[3540f2771b2661ecbd03933c227fb7f7](https://www.virustotal.com/gui/file/3540f2771b2661ecbd03933c227fb7f7)|Win32 EXE||2013-11-12 08:37:00|/home/netml/Desktop/TestMalwares/3540f2771b2661ecbd03933c227fb7f7|
|[8a0db32b97be106d2834739ffd65715b](https://www.virustotal.com/gui/file/8a0db32b97be106d2834739ffd65715b)|Win32 EXE||2013-11-06 12:34:20|googletsk.exe|
|[439ba84a964a17ce2c3d51ac49c68f81](https://www.virustotal.com/gui/file/439ba84a964a17ce2c3d51ac49c68f81)|Win32 EXE|kazy|2013-09-21 15:46:45|msoclient.exe|
|[7e97efc85be451432388b9f1ce623400](https://www.virustotal.com/gui/file/7e97efc85be451432388b9f1ce623400)|Win32 EXE|dynamer|2013-09-01 07:20:06|/home/netml/Desktop/TestMalwares/7e97efc85be451432388b9f1ce623400|
|[278f889f494d62e214406c4fcfa6f9a3](https://www.virustotal.com/gui/file/278f889f494d62e214406c4fcfa6f9a3)|Win32 EXE|DarkKomet|2013-08-28 13:55:53|h_m_z.exe|
|[073889fe855f401c3c4cc548bc08c502](https://www.virustotal.com/gui/file/073889fe855f401c3c4cc548bc08c502)|Win32 EXE||2013-08-21 04:53:34|msoclient.exe|
|[77c7c0117a0e457d7e3ceef4ab82c2ca](https://www.virustotal.com/gui/file/77c7c0117a0e457d7e3ceef4ab82c2ca)|Win32 EXE||2013-08-15 04:51:27|/home/netml/Desktop/TestMalwares/77c7c0117a0e457d7e3ceef4ab82c2ca|
|[67bad4ad3d9a06fc20bea8c3ebb7ad01](https://www.virustotal.com/gui/file/67bad4ad3d9a06fc20bea8c3ebb7ad01)|Win32 EXE||2013-08-06 16:28:28|5072b281100a1253a80caf4991ed32626861d8c0|
|[fb2cb45bf53cef41674da2d9a4bdba32](https://www.virustotal.com/gui/file/fb2cb45bf53cef41674da2d9a4bdba32)|Win32 EXE|Andromeda|2013-07-30 15:46:29|fina|
|[7ec3ec88185f9c235e2d3da7434b928a](https://www.virustotal.com/gui/file/7ec3ec88185f9c235e2d3da7434b928a)|Win32 EXE|Gamarue|2013-07-27 21:29:23|3|
|[96dbed32a59b50e6100f1ca35ef5a698](https://www.virustotal.com/gui/file/96dbed32a59b50e6100f1ca35ef5a698)|Win32 EXE|injector|2013-07-13 08:16:59|k_K_Z.exe|
|[4131776ae573bdb25009a343cf1541f5](https://www.virustotal.com/gui/file/4131776ae573bdb25009a343cf1541f5)|Win32 EXE||2013-07-10 10:59:16|4131776ae573bdb25009a343cf1541f5.exe|
|[5998641f454f82b738977aa8b3d1d283](https://www.virustotal.com/gui/file/5998641f454f82b738977aa8b3d1d283)|Win32 EXE||2013-07-07 07:06:10|/home/netml/Desktop/TestMalwares/5998641f454f82b738977aa8b3d1d283|
|[fe955b4bbe3b6aa2a1d8ebf6ee7c5c42](https://www.virustotal.com/gui/file/fe955b4bbe3b6aa2a1d8ebf6ee7c5c42)|Win32 EXE||2013-05-25 22:18:19|msoclient.exe|
|[94770186027a0ccdf733b72894a0c7d0](https://www.virustotal.com/gui/file/94770186027a0ccdf733b72894a0c7d0)|Win32 EXE||2013-05-25 21:38:00|systemtask.exe|
|[21fc043b31d22b5c3f5529db83e90422](https://www.virustotal.com/gui/file/21fc043b31d22b5c3f5529db83e90422)|Win32 EXE|kazy|2013-05-25 21:18:43|systemtask.exe|
|[878aa68245675ca5ea677aaf28707b7a](https://www.virustotal.com/gui/file/878aa68245675ca5ea677aaf28707b7a)|Win32 EXE|Androm|2013-05-23 07:43:32|95|
|[0aecd3b79d72cbfa8f5dce2a12e76053](https://www.virustotal.com/gui/file/0aecd3b79d72cbfa8f5dce2a12e76053)|Win32 EXE||2013-04-28 13:57:35|96|
|[44db769fb1f29a32d5c1998e29b4b7c4](https://www.virustotal.com/gui/file/44db769fb1f29a32d5c1998e29b4b7c4)|Win32 EXE|graftor|2013-04-26 21:51:03|96|
|[114551a87fa332a243fc05b7246309b9](https://www.virustotal.com/gui/file/114551a87fa332a243fc05b7246309b9)|Win32 EXE|Gamarue|2013-04-26 21:16:31|96|
|[1d49dc6af6803d9ffc59a859315b2ac4](https://www.virustotal.com/gui/file/1d49dc6af6803d9ffc59a859315b2ac4)|Win32 EXE||2013-03-16 08:49:35|/home/netml/Desktop/TestMalwares/1d49dc6af6803d9ffc59a859315b2ac4|
|[861f621fdf2d3e760df50009fe2824ae](https://www.virustotal.com/gui/file/861f621fdf2d3e760df50009fe2824ae)|Win32 EXE|Zbot|2013-03-11 02:34:20|wifeswapping?gpj.exe|
|[643e30e665124eea94a22641f79a9c91](https://www.virustotal.com/gui/file/643e30e665124eea94a22641f79a9c91)|Win32 EXE||2013-03-05 22:58:29|/home/netml/Desktop/TestMalwares/643e30e665124eea94a22641f79a9c91|
|[c16b43a5897861fbe023e4b7d340f2e8](https://www.virustotal.com/gui/file/c16b43a5897861fbe023e4b7d340f2e8)|Win32 EXE||2013-01-22 07:55:11|c16b43a5897861fbe023e4b7d340f2e8|
|[dbd5c44e6c189f289e0eea1454897b26](https://www.virustotal.com/gui/file/dbd5c44e6c189f289e0eea1454897b26)|Win32 EXE||2013-01-22 07:48:50|/home/netml/Desktop/TestMalwares/dbd5c44e6c189f289e0eea1454897b26|
|[a957e3a7aed4efd1b214d3c3b79f5874](https://www.virustotal.com/gui/file/a957e3a7aed4efd1b214d3c3b79f5874)|Win32 EXE||2013-01-14 04:03:57|/home/netml/Desktop/TestMalwares/a957e3a7aed4efd1b214d3c3b79f5874|
|[63ee06dae035981c5aea04f5a52879c1](https://www.virustotal.com/gui/file/63ee06dae035981c5aea04f5a52879c1)|Win32 EXE||2012-10-01 05:06:25|drop/63ee06dae035981c5aea04f5a52|
|[e26150f5186bb7230d85f4cf3aa45d17](https://www.virustotal.com/gui/file/e26150f5186bb7230d85f4cf3aa45d17)|Win32 EXE||2012-09-25 15:55:33|drop/e26150f5186bb7230d85f4cf3aa|
|[fab5eff5fc65a7a2c5920586df5e29c2](https://www.virustotal.com/gui/file/fab5eff5fc65a7a2c5920586df5e29c2)|Win32 EXE||2012-09-24 13:12:50|dnl.php|
|[2ba1e2a63129517055ab3a63cb089e33](https://www.virustotal.com/gui/file/2ba1e2a63129517055ab3a63cb089e33)|Win32 EXE||2012-09-24 13:08:32|/home/netml/Desktop/TestMalwares/2ba1e2a63129517055ab3a63cb089e33|
|[af5e96e260b71356d62900551f68f338](https://www.virustotal.com/gui/file/af5e96e260b71356d62900551f68f338)|Win32 EXE||2012-05-22 22:25:11|/home/netml/Desktop/TestMalwares/af5e96e260b71356d62900551f68f338|
|[2cd6db80e8dadce0c00f2417b6dedaf4](https://www.virustotal.com/gui/file/2cd6db80e8dadce0c00f2417b6dedaf4)|Win32 EXE||2020-11-08 13:57:57|rvhdhimsa.exe|
|[7a03b766a87f9ed759a74ca5103fef21](https://www.virustotal.com/gui/file/7a03b766a87f9ed759a74ca5103fef21)|RAR|Wacatac|2020-11-08 10:28:45|scan0001.rar|
|[fc1b40b286ddee0421ce06cc000cd08e](https://www.virustotal.com/gui/file/fc1b40b286ddee0421ce06cc000cd08e)|Win32 EXE|foreign|2020-10-05 10:15:36|dhrsaisnedh.exe|
|[77f21927f30034a103370516ab85302f](https://www.virustotal.com/gui/file/77f21927f30034a103370516ab85302f)|Win32 EXE||2020-10-04 09:57:32|rhrsadhirns.exe|
|[4136a0b56c635095d378d01828a79f85](https://www.virustotal.com/gui/file/4136a0b56c635095d378d01828a79f85)|Android||2020-06-18 03:10:33|viber.apk|
|[2ffd4f2ab4f00c78ef2661690fe349c9](https://www.virustotal.com/gui/file/2ffd4f2ab4f00c78ef2661690fe349c9)|Android||2020-06-18 03:10:28|trueC.apk|
|[d8fd669eecaf6577994e4e4e99204527](https://www.virustotal.com/gui/file/d8fd669eecaf6577994e4e4e99204527)|Android||2020-06-18 03:10:23|snap.apk|
|[4ae2680320e8c0d2c202cd81eb5a220f](https://www.virustotal.com/gui/file/4ae2680320e8c0d2c202cd81eb5a220f)|Android||2020-06-18 03:10:17|normal.apk|
|[1c25ceee18f3813d78d5ef817005ede2](https://www.virustotal.com/gui/file/1c25ceee18f3813d78d5ef817005ede2)|Android||2020-06-18 03:10:12|imo.apk|
|[216dc32c48cbea14e7af1e60085a6c66](https://www.virustotal.com/gui/file/216dc32c48cbea14e7af1e60085a6c66)|Android||2020-06-18 03:10:07|face.apk|
|[b955782e0bf948c4dcf77c60d1793d8d](https://www.virustotal.com/gui/file/b955782e0bf948c4dcf77c60d1793d8d)|Android||2020-06-17 23:30:18|b955782e0bf948c4dcf77c60d1793d8d.virus|
|[c0c2bca1b2668d10d0b26e0f6db34a64](https://www.virustotal.com/gui/file/c0c2bca1b2668d10d0b26e0f6db34a64)|Win32 EXE||2020-06-13 08:16:17|witharsrau.exe|
|[bace8f757b7b53980798f9920f0ea615](https://www.virustotal.com/gui/file/bace8f757b7b53980798f9920f0ea615)|Android|androidos|2020-05-18 13:07:59|helloWooFmim.apk|
|[111d61aa7ebb22d3037465d515949479](https://www.virustotal.com/gui/file/111d61aa7ebb22d3037465d515949479)|Android|androidos|2020-05-02 16:11:44|viber.apk|
|[1ef033bfd65a3eabe177c766940ae07c](https://www.virustotal.com/gui/file/1ef033bfd65a3eabe177c766940ae07c)|Android|androidos|2020-05-02 16:11:40|trueC.apk|
|[6774b46183515353179a8455fefc9bf1](https://www.virustotal.com/gui/file/6774b46183515353179a8455fefc9bf1)|Android|androidos|2020-05-02 16:11:36|snap.apk|
|[681ff974adb54692e61551f9640f76bf](https://www.virustotal.com/gui/file/681ff974adb54692e61551f9640f76bf)|Android|androidos|2020-05-02 16:11:31|normal.apk|
|[3117580ca2929da80150acd069cde4ab](https://www.virustotal.com/gui/file/3117580ca2929da80150acd069cde4ab)|Android|androidos|2020-05-02 16:11:26|imo.apk|
|[a09f4199a047e1ae5cf5728fbfc90831](https://www.virustotal.com/gui/file/a09f4199a047e1ae5cf5728fbfc90831)|Android||2020-05-02 16:11:23|face.apk|
|[adb4e3f7a2fe9170d7421413e6faf6a3](https://www.virustotal.com/gui/file/adb4e3f7a2fe9170d7421413e6faf6a3)|TXT|o97m|2020-04-29 13:33:57|Sample1.eml|
|[931435cb8a5b2542f8e5f29fd369e010](https://www.virustotal.com/gui/file/931435cb8a5b2542f8e5f29fd369e010)|Android|androidos|2020-04-24 09:48:14|ccbe720fd059610227d478578a5a4019c96885de8fd3e83984f9c1c5fe850ad6.bin|
|[3eb36a9853c9c68524dbe8c44734ec35](https://www.virustotal.com/gui/file/3eb36a9853c9c68524dbe8c44734ec35)|Android|androidos|2020-04-24 09:48:13|trueC.apk|
|[a912e5967261656457fd076986bb327c](https://www.virustotal.com/gui/file/a912e5967261656457fd076986bb327c)|Android|androidos|2020-04-24 09:48:11|5ce6d273df4fcad8953dd4f37e7f4a0390f9da52978f0227b021b6a724b59313.bin|
|[62fad3ac69db0e8e541efa2f479618ce](https://www.virustotal.com/gui/file/62fad3ac69db0e8e541efa2f479618ce)|Android||2020-04-24 09:48:09|451cab3d5b5a1c699f1b9b3d8a4ddf73c48f891cbca88e4e1a829e2442116efb.bin|
|[627aa2f8a8fc2787b783e64c8c57b0ed](https://www.virustotal.com/gui/file/627aa2f8a8fc2787b783e64c8c57b0ed)|Android|androidos|2020-04-24 09:48:07|56bba40bc62d021b17fb79d1e7e307a61a8727bf9f59fdcae8cfff7a0e0f9422.bin|
|[cf71ba878434605a3506203829c63b9d](https://www.virustotal.com/gui/file/cf71ba878434605a3506203829c63b9d)|Android||2020-04-24 09:48:05|fadc0fe0714d9e95904ccaaf16d895ac71c1337e92b8eb51258fed9fb8fb4620.bin|
|[5f563a38e3b98a7bc6c65555d0ad5cfd](https://www.virustotal.com/gui/file/5f563a38e3b98a7bc6c65555d0ad5cfd)|Android||2020-04-24 06:15:52|72aa69be5cd46220e1509c040ceb6e3cbb3c676a6c464a811370d688f45f26ec.bin|
|[97e3531a6a1455f56360e8e44617330c](https://www.virustotal.com/gui/file/97e3531a6a1455f56360e8e44617330c)|FPX|o97m|2020-04-21 03:34:28|vbaProject.bin|
|[67dc69a16ba744fc0fa2206a6ef1d10a](https://www.virustotal.com/gui/file/67dc69a16ba744fc0fa2206a6ef1d10a)|Android||2020-04-07 14:45:39|67dc69a16ba744fc0fa2206a6ef1d10a.virus|
|[3952ebedf24716728b7355b8be8e71b6](https://www.virustotal.com/gui/file/3952ebedf24716728b7355b8be8e71b6)|DOC|o97m|2020-04-02 17:31:28|preet.doc|
|[5bf97a6cb64ae6fd48d6c5d849be8983](https://www.virustotal.com/gui/file/5bf97a6cb64ae6fd48d6c5d849be8983)|DOCX||2020-03-31 21:13:49|C:\Users\user\Documents\f79dc97642675df808bdf4c6e83a3d0e_02 .docx|
|[e0db666fff1c8ac20106aa04b20b7b2e](https://www.virustotal.com/gui/file/e0db666fff1c8ac20106aa04b20b7b2e)|Win32 EXE|MSILPerseus|2020-03-17 10:26:25|dhrwarhsav.exe|
|[3c03f18dad61e9cde18a326eab9e64c1](https://www.virustotal.com/gui/file/3c03f18dad61e9cde18a326eab9e64c1)|XLS|o97m|2020-03-17 06:30:45|Enclosed_File.xls|
|[3bcf1bf59b51a170cbf0b8bad518608d](https://www.virustotal.com/gui/file/3bcf1bf59b51a170cbf0b8bad518608d)|Win32 EXE|Ursu|2020-03-11 04:01:28|mdlthsrvain.exe|
|[cafffff2f91b5fa5741bd69f2f89a822](https://www.virustotal.com/gui/file/cafffff2f91b5fa5741bd69f2f89a822)|RAR||2020-03-10 19:01:56|مرکز هماهنگی اوپراتیفی زون جنوب.rar|
|[c3e60bd2cf811f5049e1ed106c533f36](https://www.virustotal.com/gui/file/c3e60bd2cf811f5049e1ed106c533f36)|Win32 EXE|foreign|2020-03-09 08:23:35|thjavgnias.exe|
|[4d33804d5e6fd053837ddd374d7e32b5](https://www.virustotal.com/gui/file/4d33804d5e6fd053837ddd374d7e32b5)|DOC|EmoDldr|2020-03-09 08:08:37|file.doc|
|[d62156fa2c5bffdc63f0975c5482eab6](https://www.virustotal.com/gui/file/d62156fa2c5bffdc63f0975c5482eab6)|Win32 EXE||2020-03-06 12:29:56|brwmarivas.exe|
|[cbfae579a25df1e2fe0e02934efd65dc](https://www.virustotal.com/gui/file/cbfae579a25df1e2fe0e02934efd65dc)|DOC|o97m|2020-03-06 06:42:34|sonam.doc|
|[1f0fe3a696143743b9c77b77332c0902](https://www.virustotal.com/gui/file/1f0fe3a696143743b9c77b77332c0902)|Win32 EXE|occamy|2020-03-02 22:25:37|Xmahthen.exe|
|[15b47ac554679f7ca2fac728123f2694](https://www.virustotal.com/gui/file/15b47ac554679f7ca2fac728123f2694)|DOC||2020-03-02 19:45:05|New selected officials.doc|
|[d7d6889bfa96724f7b3f951bc06e8c02](https://www.virustotal.com/gui/file/d7d6889bfa96724f7b3f951bc06e8c02)|Win32 EXE|Neshta|2020-02-19 16:38:15|wifeexchange.exe|
|[6c3308cd8a060327d841626a677a0549](https://www.virustotal.com/gui/file/6c3308cd8a060327d841626a677a0549)|Android|Skeeyah|2020-02-18 18:40:23|cee88ffae63cd95e4f9f7008a86a8d7818a47b62608d28a70bbe8d73c6d2b042.bin|
|[4556ccecbf24b2e3e07d3856f42c7072](https://www.virustotal.com/gui/file/4556ccecbf24b2e3e07d3856f42c7072)|Android|androidos|2020-02-18 18:40:18|81ca347465f28d093a27caf3d83fe5c4fb50c5e48cfd851a06784d431fa8c2cf.bin|
|[b8006e986453a6f25fd94db6b7114ac2](https://www.virustotal.com/gui/file/b8006e986453a6f25fd94db6b7114ac2)|Android|androidos|2020-02-18 18:40:13|e158b20c400cb2c24ce4223bb947dee86e3717b18446b76911389a9a1fcc2260.bin|
|[bae69f2ce9f002a11238dcf29101c14f](https://www.virustotal.com/gui/file/bae69f2ce9f002a11238dcf29101c14f)|Android|androidos|2020-02-18 18:40:07|c598f7956b1d0d6514ade39df05c9fcad70f970957c980d15f6d019e5ca04df6.bin|
|[53cd72147b0ef6bf6e64d266bf3ccafe](https://www.virustotal.com/gui/file/53cd72147b0ef6bf6e64d266bf3ccafe)|Android|androidos|2020-02-18 18:40:01|58643719af0f271b87c51665c2e8c904db70155b8c6f514d6e5f44c0828a4a53.bin|
|[a20fc273a49c3b882845ac8d6cc5beac](https://www.virustotal.com/gui/file/a20fc273a49c3b882845ac8d6cc5beac)|Android|androidos|2020-02-18 18:39:56|face.apk|
|[0294f46d0e8cb5377f97b49ea3593c25](https://www.virustotal.com/gui/file/0294f46d0e8cb5377f97b49ea3593c25)|Android||2020-02-18 15:43:14|53e3d197e9d6ac3f23f8da64ffb1a1013e84d1ebf52864f5b0f8b79006f1ddc4.bin|
|[31967bead845fd5f3c2747befbb6072b](https://www.virustotal.com/gui/file/31967bead845fd5f3c2747befbb6072b)|Win32 EXE|MSILPerseus|2020-02-17 13:52:15|dhrwarhsav.exe|
|[e074c234858d890502c7bb6905f0716e](https://www.virustotal.com/gui/file/e074c234858d890502c7bb6905f0716e)|XLS||2020-02-17 11:44:16|36978_1582552996_NHQEncl1.xls1|
|[e262407a5502fa5607ad3b709a73a2e0](https://www.virustotal.com/gui/file/e262407a5502fa5607ad3b709a73a2e0)|Win32 EXE|MSILPerseus|2020-02-17 06:19:58|dhrwarhsav.exe|
|[c57defdc4133d27f9bc02a340ac35cd2](https://www.virustotal.com/gui/file/c57defdc4133d27f9bc02a340ac35cd2)|Win32 EXE||2020-02-13 23:29:26|nvidhrgaur.exe|
|[d4de0d1aa8c1d361d9e1c6444e5121f3](https://www.virustotal.com/gui/file/d4de0d1aa8c1d361d9e1c6444e5121f3)|DOC||2020-02-13 19:55:23|engg_review.doc|
|[bc97f303a61ea390c5fdb29f21785ba2](https://www.virustotal.com/gui/file/bc97f303a61ea390c5fdb29f21785ba2)|Android||2020-02-13 17:36:40|bc97f303a61ea390c5fdb29f21785ba2.virus|
|[6d3fe5661c9b89ea23211a3d2e1a45d7](https://www.virustotal.com/gui/file/6d3fe5661c9b89ea23211a3d2e1a45d7)|Win32 EXE||2020-02-10 13:41:48|6d3fe5661c9b89ea23211a3d2e1a45d7.virus|
|[b775e11e7d90a0fc33f26cd5cc3f6697](https://www.virustotal.com/gui/file/b775e11e7d90a0fc33f26cd5cc3f6697)|Win32 EXE||2020-02-10 01:20:19|Realtime.scr|
|[0a2b1f2201a99ee5726c7d5e4a1844f2](https://www.virustotal.com/gui/file/0a2b1f2201a99ee5726c7d5e4a1844f2)|XLS||2020-02-09 23:59:15|662c3b181467a9d2f40a7b632a4b5fe5ddd201a528ba408badbf7b2375ee3553.xls|
|[03edfaefb8ef26342a234315b14eae2b](https://www.virustotal.com/gui/file/03edfaefb8ef26342a234315b14eae2b)|Win32 EXE|occamy|2020-02-09 18:47:10|%PROGRAMDATA%\sppextcomtel\sppextcomtel.scr|
|[5507125d8bf2634da05331cecf9be557](https://www.virustotal.com/gui/file/5507125d8bf2634da05331cecf9be557)|Win32 DLL|occamy|2020-02-08 19:26:38|%TEMP%\m1ssh0upuuchcukxanevpozlu.dll|
|[95970056e0ff6c26d196496105521c19](https://www.virustotal.com/gui/file/95970056e0ff6c26d196496105521c19)|Win32 EXE|occamy|2020-02-08 18:47:52|SppExtComTel.exe|
|[d333bae2c45fe431befd7a88f1d7a540](https://www.virustotal.com/gui/file/d333bae2c45fe431befd7a88f1d7a540)|Win32 EXE|Ursu|2020-02-08 18:47:51|C:\ProgramData\systemidleperf\x64i.scr|
|[f78838433e7b090fd9526fa92920a0f6](https://www.virustotal.com/gui/file/f78838433e7b090fd9526fa92920a0f6)|Win32 EXE||2020-02-08 18:47:23|SilentCMD.exe|
|[b95e2ec3d72c65dd9495b633a1dbc906](https://www.virustotal.com/gui/file/b95e2ec3d72c65dd9495b633a1dbc906)|XLS||2020-02-08 16:43:41|DSOP_Advance.xls|
|[b3f8eee133ae385d9c7655aae033ca3e](https://www.virustotal.com/gui/file/b3f8eee133ae385d9c7655aae033ca3e)|DOC|o97m|2020-01-20 08:49:28|Criteria of Army Officers.doc|
|[48476da4403243b342a166d8a6be7a3f](https://www.virustotal.com/gui/file/48476da4403243b342a166d8a6be7a3f)|XLS|EmoDldr|2020-01-20 08:28:30|2aa160726037e80384672e89968ab4d2bd3b7f5ca3dfa1b9c1ecc4d1647a63f0.bin|
|[a3a0750d74705d235b60556f1331ae9b](https://www.virustotal.com/gui/file/a3a0750d74705d235b60556f1331ae9b)|Win32 EXE|MSILPerseus|2020-01-20 06:20:08|ulhtagnias.exe|
|[15da10765b7becfcca3325a91d90db37](https://www.virustotal.com/gui/file/15da10765b7becfcca3325a91d90db37)|DOCX|PhishingSite|2020-01-20 05:31:45|6c9c6966ce269bbcab164aca3c3f0231af1f7b26a18e5abc927b2ccdd9499368.docx|
|[9c52beedf24a763c8551715b7736b032](https://www.virustotal.com/gui/file/9c52beedf24a763c8551715b7736b032)|Win32 EXE|MSILPerseus|2020-01-16 17:48:44|rdhmrarhsa.exe|
|[e061670462a35bb5f46803394f9ca733](https://www.virustotal.com/gui/file/e061670462a35bb5f46803394f9ca733)|XLS||2020-01-16 11:33:49|2020-21.xls|
|[929be0cd74fe30bd0480928cf6369f28](https://www.virustotal.com/gui/file/929be0cd74fe30bd0480928cf6369f28)|Win32 DLL||2020-01-09 01:11:31|/home/share_write/x00408755/20200911_cyberflood/new_samples/929be0cd74fe30bd0480928cf6369f28|
|[c8288412e6679f33f77106b80020376b](https://www.virustotal.com/gui/file/c8288412e6679f33f77106b80020376b)|Win32 DLL|Ursu|2020-01-09 01:11:24|/home/share_write/x00408755/20200911_cyberflood/new_samples/c8288412e6679f33f77106b80020376b|
|[63902ca9d9a24bc52e5deb03846e5546](https://www.virustotal.com/gui/file/63902ca9d9a24bc52e5deb03846e5546)|MS Excel Spreadsheet||2020-01-04 16:29:41|.|
|[308ac61ecb808fae3698d8c1285d419e](https://www.virustotal.com/gui/file/308ac61ecb808fae3698d8c1285d419e)|Android||2020-01-03 22:39:19| |
|[085b821db833d44ad717f73dd819c29f](https://www.virustotal.com/gui/file/085b821db833d44ad717f73dd819c29f)|XLS||2020-01-03 17:56:08|Kashmir Projects.xls|
|[888ca13af164c6f514dec5223d319a40](https://www.virustotal.com/gui/file/888ca13af164c6f514dec5223d319a40)|Win32 EXE|Wacatac|2020-01-03 12:31:31|\PROGRA~2\Daithas\dllhvarima.exe|
|[284df0208d03af926d1dfc868f0ef474](https://www.virustotal.com/gui/file/284df0208d03af926d1dfc868f0ef474)|Win32 EXE|MSILPerseus|2020-01-03 05:06:31|New Preet cv.exe|
|[8a1f4a512fe9edbcc62ba4b1c3e08f0a](https://www.virustotal.com/gui/file/8a1f4a512fe9edbcc62ba4b1c3e08f0a)|Win32 EXE|Tiggre|2019-12-27 17:41:23|rlbwrarhsa.exe|
|[bce8a8ea8d47951abffeec38fbeeeef1](https://www.virustotal.com/gui/file/bce8a8ea8d47951abffeec38fbeeeef1)|XLS|o97m|2019-12-27 11:45:27|36586_1578371289_defence.xls111|
|[309c16372edcfe697abf7af66cd6a6da](https://www.virustotal.com/gui/file/309c16372edcfe697abf7af66cd6a6da)|Win32 EXE||2019-12-23 09:50:33|thnbiarwn.exe|
|[8fc5adbb6c01030f750c1ed8e913c876](https://www.virustotal.com/gui/file/8fc5adbb6c01030f750c1ed8e913c876)|Win32 EXE|MSILPerseus|2019-12-16 16:41:02|thnaviwa.exe|
|[80812d4b01071a137f5bf845beb80e8b](https://www.virustotal.com/gui/file/80812d4b01071a137f5bf845beb80e8b)|DOC||2019-12-16 14:24:43|Album_and_Feedback_Form.doc|
|[fc155137f3de70071d7d0d80695febd0](https://www.virustotal.com/gui/file/fc155137f3de70071d7d0d80695febd0)|Android||2019-12-09 11:53:36|fc155137f3de70071d7d0d80695febd0.virus|
|[6d5e033651ae6371b8c8a44b269101b2](https://www.virustotal.com/gui/file/6d5e033651ae6371b8c8a44b269101b2)|Win32 EXE|MSILPerseus|2019-12-04 14:40:54|tbvrarthsa.exe|
|[5158c5c17862225a86c8a4f36f054ae2](https://www.virustotal.com/gui/file/5158c5c17862225a86c8a4f36f054ae2)|XLS||2019-12-04 11:07:01|NHQ Notice File.xls|
|[a84549691a492ad081bf177b6c4518b0](https://www.virustotal.com/gui/file/a84549691a492ad081bf177b6c4518b0)|Win64 EXE||2019-10-07 15:27:18|Y:\Information Security\Issues\5-10-19\FPSRV-HZ\M\PerfLogs\psexec.exe|
|[783dc28185837c8e66dca34e9a519c7c](https://www.virustotal.com/gui/file/783dc28185837c8e66dca34e9a519c7c)|Win32 EXE||2019-10-03 07:04:56|sshnet.exe|
|[197ab57347843b00c8d9c23d695c5904](https://www.virustotal.com/gui/file/197ab57347843b00c8d9c23d695c5904)|Android||2019-08-20 18:48:18|.|
|[e98ea14133925d26a5c34b8c0bd9fd49](https://www.virustotal.com/gui/file/e98ea14133925d26a5c34b8c0bd9fd49)|Android||2019-08-16 22:57:50|ncrTest.apk|
|[babc1b62dd7c823f8536476aef874a3d](https://www.virustotal.com/gui/file/babc1b62dd7c823f8536476aef874a3d)|Win32 EXE|Disfa|2019-06-18 07:04:06|ngasfrmas.exe|
|[a87d59456f323bd373cb958273dfe8bb](https://www.virustotal.com/gui/file/a87d59456f323bd373cb958273dfe8bb)|TXT||2019-04-19 07:32:18|195e95b6a1f9de762ee01027f903010c560ce76e050d61a7223b6fce0b1060a3.bin|
|[0c4db17ed145310f336ab4887914f80c](https://www.virustotal.com/gui/file/0c4db17ed145310f336ab4887914f80c)|TXT||2019-03-21 07:00:13|49d5cfb41066bca7c9f03aad2d729e9d9d99c95bc9c50c152af3ccc94e3db4f9.bin|
|[4c0e752600746b6d67cf1d49c103d64a](https://www.virustotal.com/gui/file/4c0e752600746b6d67cf1d49c103d64a)|DOC||2019-03-21 04:45:54|CV.doc|
|[341bf386e067095bb17b875a451c96f2](https://www.virustotal.com/gui/file/341bf386e067095bb17b875a451c96f2)|Win32 EXE||2019-03-04 22:23:13|SilentCMD.exe|
|[04a6a6bb92be95f59ffc8b8a0b522571](https://www.virustotal.com/gui/file/04a6a6bb92be95f59ffc8b8a0b522571)|Android|androidos|2019-01-28 14:33:03|android.s.apk|
|[b4fcb52673089caf3e6e76379f2604d8](https://www.virustotal.com/gui/file/b4fcb52673089caf3e6e76379f2604d8)|TXT||2018-12-16 14:39:10|32e602df2a327292b9c93b609d2d210e568a058a200563795654cf16c3afc6b8.bin|
|[0f7d3d33d7235b13d0fac4329e0d2420](https://www.virustotal.com/gui/file/0f7d3d33d7235b13d0fac4329e0d2420)|TXT||2018-11-27 09:01:07|cmd.aspx|
|[31b431df84eaf71848c8b172c40124ec](https://www.virustotal.com/gui/file/31b431df84eaf71848c8b172c40124ec)|TXT||2018-10-22 15:39:26|C:\Users\ADMINI~1\AppData\Local\Temp\AutoRDPwn-master\Resources\Scripts\Invoke-SMBExec.ps1|
|[54af54c9e0aa4b26c4be803c44c5f473](https://www.virustotal.com/gui/file/54af54c9e0aa4b26c4be803c44c5f473)|TXT||2018-10-22 15:38:17|Invoke-TheHash.psm1|
|[b63de834ab7cc8fcd0e71003c6786213](https://www.virustotal.com/gui/file/b63de834ab7cc8fcd0e71003c6786213)|TXT||2018-09-05 12:02:34|d4a177af7b6e19ff4f1917e2f0a606c21845c7921e62453432ff341485b4cfa8.bin|
|[808502752ca0492aca995e9b620d507b](https://www.virustotal.com/gui/file/808502752ca0492aca995e9b620d507b)|Win64 EXE|Johnnie|2018-08-15 09:33:26|JuicyPotato.exe|
|[6fea7a30b2bd6014c1b15defe8963273](https://www.virustotal.com/gui/file/6fea7a30b2bd6014c1b15defe8963273)|TXT||2018-04-28 14:38:40|tiny.aspx|
|[01a9293fb10985204a4278006796ea3f](https://www.virustotal.com/gui/file/01a9293fb10985204a4278006796ea3f)|Win32 EXE||2017-12-14 05:51:58|port.exe|
|[f064ff619ebf67a59566c0dd54c5d05c](https://www.virustotal.com/gui/file/f064ff619ebf67a59566c0dd54c5d05c)|Win32 EXE||2017-12-14 05:51:48|sshnet.exe|
|[cb84fc4682a74ba81ef477bc1359959b](https://www.virustotal.com/gui/file/cb84fc4682a74ba81ef477bc1359959b)|Win32 EXE|rozena|2017-12-14 05:51:31|ConsoleApplication5.exe|
|[cfcbb6472cac07ea138379578d80845b](https://www.virustotal.com/gui/file/cfcbb6472cac07ea138379578d80845b)|Win32 EXE|rozena|2017-12-14 05:51:19|ConsoleApplication5.exe|
|[29fb089328e78f67ff86739583a9e63a](https://www.virustotal.com/gui/file/29fb089328e78f67ff86739583a9e63a)|Win32 EXE||2017-12-11 22:30:18|sshnet.exe|
|[155837e476b50c93b6522b310a684a33](https://www.virustotal.com/gui/file/155837e476b50c93b6522b310a684a33)|Win32 EXE|rozena|2017-12-11 14:45:29|ConsoleApplication5.exe|
|[475f89de6031db2158231eafa07b8b72](https://www.virustotal.com/gui/file/475f89de6031db2158231eafa07b8b72)|Win32 EXE||2017-12-11 14:22:18|cs|
|[836d61745e087e6017832233701218a4](https://www.virustotal.com/gui/file/836d61745e087e6017832233701218a4)|TXT||2017-05-03 19:53:01|Invoke-TheHash.psd1|
|[366aeab3b8ae90a98eeaed68ccfdef00](https://www.virustotal.com/gui/file/366aeab3b8ae90a98eeaed68ccfdef00)|Win32 DLL||2017-03-31 01:35:35|shell.pyd|
|[46fdb64ce8324bdc49fbd1ccc2c5cc3b](https://www.virustotal.com/gui/file/46fdb64ce8324bdc49fbd1ccc2c5cc3b)|Win32 DLL||2017-03-31 01:35:34|win32pipe.pyd|
|[285a796650d360081fd415edfbff8511](https://www.virustotal.com/gui/file/285a796650d360081fd415edfbff8511)|Win32 DLL||2017-03-31 01:35:34|f9b82d9e7781304f__win32sysloader.pyd|
|[c05cfcfd3752d6feadc0d71d04707602](https://www.virustotal.com/gui/file/c05cfcfd3752d6feadc0d71d04707602)|Win32 DLL||2016-06-28 19:29:57|\Users\Petra\AppData\Local\Temp\_MEI36722\unicodedata.pyd|
|[f12a4d8a3bb4d4c589cebc25373ca1ff](https://www.virustotal.com/gui/file/f12a4d8a3bb4d4c589cebc25373ca1ff)|Win32 DLL||2016-06-28 14:03:31|C:\Users\<USER>\AppData\Local\Temp\_MEI28042\_ssl.pyd|
|[6a3ab29e2f55484b07e1f71dc130dba9](https://www.virustotal.com/gui/file/6a3ab29e2f55484b07e1f71dc130dba9)|Win32 DLL||2016-06-28 14:01:07|a19d4057e460e65a_select.pyd|
|[41cda77c69614a0fbfcc4a38ebae659b](https://www.virustotal.com/gui/file/41cda77c69614a0fbfcc4a38ebae659b)|TXT||2013-09-02 06:11:35|37a2494de2689be02bb0e6185dcf0248001e90d2b049a32bb907e1025e550748.bin|
|[1f137ac28556d4507f97f736b0ac7d45](https://www.virustotal.com/gui/file/1f137ac28556d4507f97f736b0ac7d45)|Win64 DLL||2011-03-10 17:00:10|aeinv.dll|
|[4b78b431f225fd8624c5655cb1de7b61](https://www.virustotal.com/gui/file/4b78b431f225fd8624c5655cb1de7b61)|Win64 DLL||2009-09-12 16:14:01|aelupsvc.dll|
