**NAME:**  
C-Major  
  
**Alias**  
ProjectM, Transparent Tribe, Operation C-Major, C-Major  
  
**Description**:   
C-Major targeted Indian military officials via spear-phishing emails, distributing spyware to its victims via an Adobe Reader vulnerability.
  
**References**:  
http://documents.trendmicro.com/assets/pdf/Indian-military-personnel-targeted-by-information-theft-campaign-cmajor.pdf

