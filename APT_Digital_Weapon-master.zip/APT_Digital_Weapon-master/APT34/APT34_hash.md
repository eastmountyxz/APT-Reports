|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[08dc0073537b588d40deda1f31893c52](https://www.virustotal.com/gui/file/08dc0073537b588d40deda1f31893c52)|TXT||2020-01-08 08:09:44| |
|[993e9cb95301126debdea7dd66b9e121](https://www.virustotal.com/gui/file/993e9cb95301126debdea7dd66b9e121)|Win64 EXE||2019-09-26 15:15:23|elrawdsk.sys|
|[33f98b613b331b49e272512274669844](https://www.virustotal.com/gui/file/33f98b613b331b49e272512274669844)|Win32 EXE||2019-07-15 07:03:15|%WINDIR%\temp\udd711b.tmp|
|[48f10b9ced741ff6e0de281a4eb621d1](https://www.virustotal.com/gui/file/48f10b9ced741ff6e0de281a4eb621d1)|XLS||2019-07-13 18:06:20| |
|[2a872aa431b36d8fd5b1782de7711d7a](https://www.virustotal.com/gui/file/2a872aa431b36d8fd5b1782de7711d7a)|XLS||2019-07-11 09:49:24|survey-sheet.xls|
|[caf418cbf6a9c4e93e79d4714d5d3b87](https://www.virustotal.com/gui/file/caf418cbf6a9c4e93e79d4714d5d3b87)|XLS||2019-06-19 10:57:56|System Manager.bin|
|[b338baa673ac007d7af54075ea69660b](https://www.virustotal.com/gui/file/b338baa673ac007d7af54075ea69660b)|Win32 EXE||2019-06-17 09:06:36|Client.exe|
|[9fff498b78d9498b33e08b892148135f](https://www.virustotal.com/gui/file/9fff498b78d9498b33e08b892148135f)|Win32 EXE||2019-06-17 08:42:28|b.exe|
|[6eca9c2b7cf12c247032aae28419319e](https://www.virustotal.com/gui/file/6eca9c2b7cf12c247032aae28419319e)|Win64 DLL||2019-06-17 08:40:36|P64.dll|
|[50fb09d53c856dcd0782e1470eaeae35](https://www.virustotal.com/gui/file/50fb09d53c856dcd0782e1470eaeae35)|Win32 EXE||2019-06-17 08:34:22|Client.exe|
|[d8abe843db508048b4d4db748f92a103](https://www.virustotal.com/gui/file/d8abe843db508048b4d4db748f92a103)|Win32 DLL||2019-06-12 09:05:47|P86.dll|
|[172c004ec5ecac3c4b13336200c693e4](https://www.virustotal.com/gui/file/172c004ec5ecac3c4b13336200c693e4)|Win32 EXE||2019-06-03 10:46:52|Jason.exe|
|[37fdfe356adb362d253e7ca533018b51](https://www.virustotal.com/gui/file/37fdfe356adb362d253e7ca533018b51)|C++||2019-04-21 06:19:31|srvr.js|
|[96c9abd9c7c155fb3fd2b3906a9788f3](https://www.virustotal.com/gui/file/96c9abd9c7c155fb3fd2b3906a9788f3)|Text||2019-04-20 23:25:48|151332|
|[6e86c57385d26a59c0df1580454b9967](https://www.virustotal.com/gui/file/6e86c57385d26a59c0df1580454b9967)|TXT||2019-04-18 20:52:38|eb1ded644e7491f3f60982be9652cbe40b0c819329927ea654cb43e40acb9b1c.bin|
|[688a165fc64b3c9ad19022f581599c91](https://www.virustotal.com/gui/file/688a165fc64b3c9ad19022f581599c91)|Text||2019-04-18 17:06:36|dns.ps1|
|[701dce1e70c2acddff42d04537bb3f92](https://www.virustotal.com/gui/file/701dce1e70c2acddff42d04537bb3f92)|C++||2019-04-18 16:11:10|3578a541b9c51e2b8727334e6051942c20247bb8cdb5badd00a6bfe033717136.bin|
|[81e047b76994428d6b579593dd822b5e](https://www.virustotal.com/gui/file/81e047b76994428d6b579593dd822b5e)|HTML||2019-04-18 16:06:14|22c4023c8daa57434ef79b838e601d9d72833fec363340536396fe7d08ee2017.bin|
|[1576a260fe303860a3994d8ab257fb73](https://www.virustotal.com/gui/file/1576a260fe303860a3994d8ab257fb73)|Win32 EXE||2019-04-18 12:01:31|newPanel.exe|
|[a11b492ef25cd9956668fc0f84ba9bbf](https://www.virustotal.com/gui/file/a11b492ef25cd9956668fc0f84ba9bbf)|Win32 EXE||2019-04-17 19:46:36|Tardigrade.exe|
|[9d3d8fe14927172ca5546bdb95d94762](https://www.virustotal.com/gui/file/9d3d8fe14927172ca5546bdb95d94762)|TXT||2019-04-17 10:57:08|C:\users\public\public\xhupdater.ps1|
|[a9a2360c6e5dbcb43c4f0edd2081f9ff](https://www.virustotal.com/gui/file/a9a2360c6e5dbcb43c4f0edd2081f9ff)|unknown||2019-04-17 10:56:37|07e791d18ea8f2f7ede2962522626b43f28cb242873a7bd55fff4feb91299741.bin|
|[cd0bbff03ce7946cd7c9dc339726d90a](https://www.virustotal.com/gui/file/cd0bbff03ce7946cd7c9dc339726d90a)|Text||2019-04-17 10:55:06|C:\users\public\public\xdupdater.ps1|
|[5e17061bf2dce87d402ddd8531abb49f](https://www.virustotal.com/gui/file/5e17061bf2dce87d402ddd8531abb49f)|Text||2019-04-17 09:44:35|poisonfrog.ps1|
|[e4e39045c99b3aecdd5c53e22245c4aa](https://www.virustotal.com/gui/file/e4e39045c99b3aecdd5c53e22245c4aa)|Text||2019-02-09 06:43:23|dttcodexgigas.11fabbd3c8c8c29ac3bfff01ba5a735ec75a47d4|
|[c30f57eee92cd6d244a055c122137cab](https://www.virustotal.com/gui/file/c30f57eee92cd6d244a055c122137cab)|Text||2019-02-09 06:36:52|dttcodexgigas.4494a79f932ffcfaae80d2ec8c8843747b5f75b0|
|[e2df50af1ee3a91746856c9e289b8317](https://www.virustotal.com/gui/file/e2df50af1ee3a91746856c9e289b8317)|Text||2019-02-09 06:27:47|dttcodexgigas.3396a485d91277f4b996b799d954bc1273be6293|
|[2b46b782d57df9f02d8f47f946e4d45f](https://www.virustotal.com/gui/file/2b46b782d57df9f02d8f47f946e4d45f)|Text||2019-02-09 06:24:10|myvtfile.exe|
|[42061b4e3c4b85e2786babb2798a51f5](https://www.virustotal.com/gui/file/42061b4e3c4b85e2786babb2798a51f5)|Text||2019-02-09 06:22:59|myvtfile.exe|
|[45ae24fdbe68f95ea6eadf2248836907](https://www.virustotal.com/gui/file/45ae24fdbe68f95ea6eadf2248836907)|Text||2019-02-09 06:15:54|myvtfile.exe|
|[258f4445bda29e6787931ecc451a3cfd](https://www.virustotal.com/gui/file/258f4445bda29e6787931ecc451a3cfd)|Text||2019-02-09 05:57:11|myvtfile.exe|
|[3c5867e62dbb4b3a56650e0d621fff39](https://www.virustotal.com/gui/file/3c5867e62dbb4b3a56650e0d621fff39)|Text||2019-02-09 05:52:20|myvtfile.exe|
|[31a2aaa122e8a41b75a15c62455c1e74](https://www.virustotal.com/gui/file/31a2aaa122e8a41b75a15c62455c1e74)|Text||2019-02-09 05:48:19|myvtfile.exe|
|[1b8134fd21b4b5cc153f9b3a4da889de](https://www.virustotal.com/gui/file/1b8134fd21b4b5cc153f9b3a4da889de)|Text||2019-02-09 05:44:38|myvtfile.exe|
|[5a789f06ed0312fbba002171023d4799](https://www.virustotal.com/gui/file/5a789f06ed0312fbba002171023d4799)|Text||2019-02-09 05:42:04|dttcodexgigas.c29daf3a2433895f28a69f70c5a25593f75ccb55|
|[b8ad490b8379cbb721163e34867bd40d](https://www.virustotal.com/gui/file/b8ad490b8379cbb721163e34867bd40d)|Text||2019-02-08 22:37:02|dttcodexgigas.2ff2c90da7b64031590b99bacf8259849b17c72e|
|[da33dc48ab92f7b5d6446b146c45f250](https://www.virustotal.com/gui/file/da33dc48ab92f7b5d6446b146c45f250)|Text||2019-02-08 22:34:14|virussign.com_da33dc48ab92f7b5d6446b146c45f250.vir|
|[930471105792a48594d092ec81ff4a6b](https://www.virustotal.com/gui/file/930471105792a48594d092ec81ff4a6b)|Text||2019-02-08 22:33:17|dttcodexgigas.640d1713e8bbb35713a122653a5d2c92d4161d19|
|[cbb34109b84333695e1a29216e6238b6](https://www.virustotal.com/gui/file/cbb34109b84333695e1a29216e6238b6)|Text||2019-02-08 22:28:01|myvtfile.exe|
|[d94e68cfb9824d82530d672afa057e10](https://www.virustotal.com/gui/file/d94e68cfb9824d82530d672afa057e10)|Text||2019-02-08 22:27:48|virussign.com_d94e68cfb9824d82530d672afa057e10.vir|
|[a66d6bac591cf5e90830abd98152aebf](https://www.virustotal.com/gui/file/a66d6bac591cf5e90830abd98152aebf)|Text||2019-02-08 22:23:58|myvtfile.exe|
|[056bb39cded71f8f7bfe7f6e8ec368ce](https://www.virustotal.com/gui/file/056bb39cded71f8f7bfe7f6e8ec368ce)|Text||2019-02-08 22:16:33|dttcodexgigas.ff2246fd46b54cadc7287bc7300daabcc7419f03|
|[bd57f02bf301aac02af9f29981a84e34](https://www.virustotal.com/gui/file/bd57f02bf301aac02af9f29981a84e34)|Text||2019-02-08 22:16:33|myvtfile.exe|
|[431a214c3a15f16ca2123df5acfb0285](https://www.virustotal.com/gui/file/431a214c3a15f16ca2123df5acfb0285)|Text||2019-02-08 22:13:28|myvtfile.exe|
|[48456ab18afe8a543e6fa9cf45778c0a](https://www.virustotal.com/gui/file/48456ab18afe8a543e6fa9cf45778c0a)|Text||2019-02-08 22:02:29|dttcodexgigas.c55001d2b8e9c239ab989ed47654e57a395872c2|
|[f5ab974c3f3dcc3172761672a5924e70](https://www.virustotal.com/gui/file/f5ab974c3f3dcc3172761672a5924e70)|Text||2019-02-08 22:02:22|dttcodexgigas.80101e32719054578cdbc12b5bc51dac98d1192f|
|[1cb1f24cc137f39e6590f2954181b243](https://www.virustotal.com/gui/file/1cb1f24cc137f39e6590f2954181b243)|Text||2019-02-08 21:57:52|myvtfile.exe|
|[f9096b84c772f2570810eaef39066d30](https://www.virustotal.com/gui/file/f9096b84c772f2570810eaef39066d30)|Text||2019-02-08 21:57:14|virussign.com_f9096b84c772f2570810eaef39066d30.vir|
|[64b9c8db63ac138c89909e39a7fb8432](https://www.virustotal.com/gui/file/64b9c8db63ac138c89909e39a7fb8432)|Text||2019-02-08 21:55:30|myvtfile.exe|
|[14119a08bd75dc20b925888904493b0a](https://www.virustotal.com/gui/file/14119a08bd75dc20b925888904493b0a)|Text||2019-02-08 21:52:38|myvtfile.exe|
|[60494e534750bb5a2cc23856f869dc0a](https://www.virustotal.com/gui/file/60494e534750bb5a2cc23856f869dc0a)|Text||2019-02-08 21:44:38|dttcodexgigas.03629975db8b5957db6aff3666ceffdc5ddfc0b6|
|[0c747a7a464c37d1e9d380148960f9ef](https://www.virustotal.com/gui/file/0c747a7a464c37d1e9d380148960f9ef)|Text||2019-02-08 21:42:06|dttcodexgigas.9ff3c2dea7e4355572ec8e51144dbe43f2683edb|
|[76573c14fda6735cb29b7aa3672aa6ec](https://www.virustotal.com/gui/file/76573c14fda6735cb29b7aa3672aa6ec)|HTML||2019-01-28 10:36:06|Error.aspx.txt|
|[761040222756244d84cf276db8610cc1](https://www.virustotal.com/gui/file/761040222756244d84cf276db8610cc1)|HTML||2019-01-28 10:35:30|525900b31b42ec66bacb47637a967b7b2057f3dd4b4a8cf68cfd5b756cbfdeb8.bin|
|[10d12a4363a4ca5cb369edd4d6df108e](https://www.virustotal.com/gui/file/10d12a4363a4ca5cb369edd4d6df108e)|DOC|w2km|2018-09-09 10:06:05|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT34,Iranian/MagicHoundAPT34.doc|
|[88a3636fbae365ac19d7fb68c2cc2fef](https://www.virustotal.com/gui/file/88a3636fbae365ac19d7fb68c2cc2fef)|TXT||2018-08-27 16:33:02|%PROGRAMDATA%\windowsapppool\apppool.vbs|
|[4df7942bc9b4a915be585b3c415f13e6](https://www.virustotal.com/gui/file/4df7942bc9b4a915be585b3c415f13e6)|FPX|Bitrep|2018-08-27 14:43:04|Fw No Subject.msg|
|[8c4fa86dcc2fd00933b70cbf239f0636](https://www.virustotal.com/gui/file/8c4fa86dcc2fd00933b70cbf239f0636)|TXT||2018-08-27 14:29:41|%PROGRAMDATA%\windowsapppool\apppool.ps1|
|[52b6e1ef0d079f4c2572705156365c06](https://www.virustotal.com/gui/file/52b6e1ef0d079f4c2572705156365c06)|DOC|o97m|2018-08-27 14:25:41|VirusShare_52b6e1ef0d079f4c2572705156365c06|
|[d93927f31afa691bc0d1107ab28fc0f1](https://www.virustotal.com/gui/file/d93927f31afa691bc0d1107ab28fc0f1)|XLS|o97m|2018-08-26 05:45:29|70ff20f2e5c7fd90c6bfe92e28df585f711ee4090fc7669b3a9bd024c4e11702.bin|
|[7d08fd0f5abe8c928d223c592e961274](https://www.virustotal.com/gui/file/7d08fd0f5abe8c928d223c592e961274)|XLS|o97m|2018-08-26 05:43:37|66d678b097a2245f60f3d95bb608f3958aa0f5f19ca7e5853f38ea79885b9633.bin|
|[aa7c9cc7063d4e541246034485fc114e](https://www.virustotal.com/gui/file/aa7c9cc7063d4e541246034485fc114e)|XLS|o97m|2018-08-21 08:19:34|364e2884251c151a29071a5975ca0076405a8cc2bab8da3e784491632ec07f56.bin|
|[fb854cc448f60ca750cd7bf3486db11b](https://www.virustotal.com/gui/file/fb854cc448f60ca750cd7bf3486db11b)|XLS|o97m|2018-08-21 08:09:37|687027d966667780ab786635b0d4274b651f27d99717c5ba95e139e94ef114c3.bin|
|[10e1387eb09286518db5cc22b763a3fd](https://www.virustotal.com/gui/file/10e1387eb09286518db5cc22b763a3fd)|XLS|o97m|2018-08-21 08:03:42|sss.xls|
|[8fec2d11642f8d6c5fc25839c6739fc3](https://www.virustotal.com/gui/file/8fec2d11642f8d6c5fc25839c6739fc3)|XLS|o97m|2018-08-21 07:58:54|sss.xls|
|[ac685796da5c02bec61c2909867892ad](https://www.virustotal.com/gui/file/ac685796da5c02bec61c2909867892ad)|XLS|o97m|2018-08-21 06:25:25|XLS-withyourface - test.xls|
|[11bf5c50f45b9c8aca1d86ae2e2aec44](https://www.virustotal.com/gui/file/11bf5c50f45b9c8aca1d86ae2e2aec44)|XLS|o97m|2018-08-20 19:39:11|XLS-withyourface.xls|
|[c99df7fbff1bf73f818e6ab9d008a37c](https://www.virustotal.com/gui/file/c99df7fbff1bf73f818e6ab9d008a37c)|XLS|o97m|2018-08-20 19:32:12|XLS-withyourface.xls|
|[ec94c2102c727f9e2707143d81bc5555](https://www.virustotal.com/gui/file/ec94c2102c727f9e2707143d81bc5555)|XLS|o97m|2018-08-20 19:30:45|XLS-withyourface.xls|
|[ea6321f55ea83e6f2887a2360f8e55b0](https://www.virustotal.com/gui/file/ea6321f55ea83e6f2887a2360f8e55b0)|Win32 EXE||2018-07-25 18:05:40|Windows Implantment Module.exe|
|[d51c2ffce844d42bab2f2c3131e3dbd4](https://www.virustotal.com/gui/file/d51c2ffce844d42bab2f2c3131e3dbd4)|Win32 EXE||2018-07-02 18:41:53|SystemDiskClean.exe|
|[3cf8aff7c56cf477bde9adbd543abc40](https://www.virustotal.com/gui/file/3cf8aff7c56cf477bde9adbd543abc40)|Win32 EXE||2018-07-02 18:30:55|Windows Implantment Module.exe|
|[d41207d54b69fb3eeb7a104f7d36c7b0](https://www.virustotal.com/gui/file/d41207d54b69fb3eeb7a104f7d36c7b0)|Win32 EXE||2018-06-09 12:21:25|WinSyncMetastore.exe|
|[5998ef679682878e68d5ac4a1733fac5](https://www.virustotal.com/gui/file/5998ef679682878e68d5ac4a1733fac5)|Win32 EXE||2018-06-09 12:21:24|WinSyncMetastore.exe|
|[485041067b8e37d3b172f5c0e700bff1](https://www.virustotal.com/gui/file/485041067b8e37d3b172f5c0e700bff1)|DOC||2018-06-05 08:43:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT34,Iranian/QUADAGENTPowershell.bin|
|[486bdf835a453c6ffb5f56647e697871](https://www.virustotal.com/gui/file/486bdf835a453c6ffb5f56647e697871)|DOC|w2km|2018-01-29 08:59:19|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT34,Iranian/OilrigThreeDollarsMacro.bin|
|[e0bf38e77143363bf761d52039d3e171](https://www.virustotal.com/gui/file/e0bf38e77143363bf761d52039d3e171)|Win32 EXE|tiggre|2018-01-18 07:23:31|IntelSecurityManager.exe|
|[ca64a55a9f491864a2c51357fb7f6958](https://www.virustotal.com/gui/file/ca64a55a9f491864a2c51357fb7f6958)|DOC|o97m|2018-01-18 06:51:52|81eb43ad46ed39bd4b869c709e5e468a6fc714485da288aaa77c80291ce6db8c.bin|
|[d7b1230bf3ec5906797103e65ba3cfd7](https://www.virustotal.com/gui/file/d7b1230bf3ec5906797103e65ba3cfd7)|ZIP|Adwind|2018-01-17 22:52:03|ecf8244dfd02bb882a8d02d8be032c1d6577ca3b|
|[9de7fa8ae2f2814137dec6660b8e68eb](https://www.virustotal.com/gui/file/9de7fa8ae2f2814137dec6660b8e68eb)|DOCX||2018-01-14 07:01:32|Risk.DOCX|
|[2bf8099845f805a1d9d09af1527d12be](https://www.virustotal.com/gui/file/2bf8099845f805a1d9d09af1527d12be)|CHM||2018-01-02 11:05:10|2d71ae51af7e7baf4bd2cb24a3cd9bf7ceed9afbf77a9ac2f6d591d277f749cc.bin|
|[55cdb9f0e6a8c8b5d6354393fb98f1d8](https://www.virustotal.com/gui/file/55cdb9f0e6a8c8b5d6354393fb98f1d8)|Text||2018-01-01 10:27:39|dntx.txt|
|[46a761099f523a01ab4edddfe9110ae2](https://www.virustotal.com/gui/file/46a761099f523a01ab4edddfe9110ae2)|Text||2018-01-01 10:19:25|dnip.txt|
|[bbde33f5709cb1452ab941c08acc775e](https://www.virustotal.com/gui/file/bbde33f5709cb1452ab941c08acc775e)|Text||2018-01-01 09:33:29|bbde33f5709cb1452ab941c08acc775e.virus|
|[247b2a9fcba6e9ec29ed818948939702](https://www.virustotal.com/gui/file/247b2a9fcba6e9ec29ed818948939702)|Text||2018-01-01 09:32:35|247b2a9fcba6e9ec29ed818948939702.virus|
|[b2d13a336a3eb7bd27612be7d4e334df](https://www.virustotal.com/gui/file/b2d13a336a3eb7bd27612be7d4e334df)|Text||2017-12-29 16:20:43|b2d13a336a3eb7bd27612be7d4e334df_Win32.VBS.APT34Dropper|
|[d8094617f10145b5a18c3cd91359f769](https://www.virustotal.com/gui/file/d8094617f10145b5a18c3cd91359f769)|Win32 EXE||2017-12-25 13:13:06|IntelSecurityManager.exe|
|[a1fbcd3ce8226bd0793360b2f886a245](https://www.virustotal.com/gui/file/a1fbcd3ce8226bd0793360b2f886a245)|HTML||2017-12-21 12:31:18|login.aspx|
|[1cb8a29c2963cfbb7a0a7968c4235575](https://www.virustotal.com/gui/file/1cb8a29c2963cfbb7a0a7968c4235575)|Win32 EXE||2017-12-21 12:22:27|mnl.exe|
|[6a711e56f54656cc3e679dded8e1df8f](https://www.virustotal.com/gui/file/6a711e56f54656cc3e679dded8e1df8f)|Win32 DLL||2017-12-21 12:09:18|TEST3|
|[86c2ca43ba1f231ce169f13bfdfa464c](https://www.virustotal.com/gui/file/86c2ca43ba1f231ce169f13bfdfa464c)|Win32 EXE||2017-12-20 18:50:48|meter_tcp 45.exe|
|[3cfbccbf310988e2dd56d20c4f416336](https://www.virustotal.com/gui/file/3cfbccbf310988e2dd56d20c4f416336)|Win64 EXE||2017-12-20 12:00:53|WSC|
|[3bdca22193eb676df24f333922575524](https://www.virustotal.com/gui/file/3bdca22193eb676df24f333922575524)|Win32 EXE||2017-12-19 11:02:50|Samples 20_12_2017 (157)|
|[0fd171676885b747402b15bc8e9b6892](https://www.virustotal.com/gui/file/0fd171676885b747402b15bc8e9b6892)|Win32 EXE||2017-12-19 11:02:49|1024-040db783fbecfda5b2bf63a72c2d9f3d03f53098|
|[cfdef4d525ea7b054f9531de64876e4d](https://www.virustotal.com/gui/file/cfdef4d525ea7b054f9531de64876e4d)|Win32 EXE||2017-12-19 11:02:49|1024-7fe3630e76f9dce4ff53038aa3c9de2e0742b788|
|[61bd178c694a719f78605f892b374ba9](https://www.virustotal.com/gui/file/61bd178c694a719f78605f892b374ba9)|Win32 EXE||2017-12-19 11:02:48|Python_EXE_Impacket_Exploit|
|[f3206dad96e2d42119a7823def4c9ce9](https://www.virustotal.com/gui/file/f3206dad96e2d42119a7823def4c9ce9)|Win32 EXE||2017-11-28 10:39:17|alma.exe|
|[f4de44ed5e6c4c6f19fba5856f0dac40](https://www.virustotal.com/gui/file/f4de44ed5e6c4c6f19fba5856f0dac40)|XLS||2017-11-01 13:29:03|f4de44ed5e6c4c6f19fba5856f0dac40.virus|
|[e6ac6f18256c4dde5bf06a9191562f82](https://www.virustotal.com/gui/file/e6ac6f18256c4dde5bf06a9191562f82)|HTML||2017-10-17 08:24:10|f6fa94cc8efea0dbd7d4d4ca4cf85ac6da97ee5cf0c59d16a6aafccd2b9d8b9a.sample|
|[eaf3448808481fb1fdbb675bc5ea24de](https://www.virustotal.com/gui/file/eaf3448808481fb1fdbb675bc5ea24de)|HTML||2017-10-15 11:07:35|eaf3448808481fb1fdbb675bc5ea24de.virus|
|[82755bf7ad786d7bf8da00b6c19b6091](https://www.virustotal.com/gui/file/82755bf7ad786d7bf8da00b6c19b6091)|Win32 EXE||2017-10-09 18:38:51|82755bf7ad786d7bf8da00b6c19b6091.virus|
|[a602a7b6deadc3dfb6473a94d7edc9e4](https://www.virustotal.com/gui/file/a602a7b6deadc3dfb6473a94d7edc9e4)|Win32 EXE||2017-09-28 07:00:09|exeruner.exe|
|[4ea656d10be1d6eac05d69252d270592](https://www.virustotal.com/gui/file/4ea656d10be1d6eac05d69252d270592)|Win32 EXE||2017-09-25 04:20:23|exeruner_new.exe|
|[37d586727c1293d8a278b69d3f0c5c4b](https://www.virustotal.com/gui/file/37d586727c1293d8a278b69d3f0c5c4b)|Win32 EXE|Upatre|2017-09-22 04:35:13|C:/Users/seongmin/Documents/VT2/malware/20170928/37d586727c1293d8a278b69d3f0c5c4b.vir|
|[87fb0c1e0de46177390de3ee18608b21](https://www.virustotal.com/gui/file/87fb0c1e0de46177390de3ee18608b21)|Win32 EXE||2017-07-27 15:27:02|exeruner_new.exe|
|[d85818e82a6e64ca185edfddba2d1b76](https://www.virustotal.com/gui/file/d85818e82a6e64ca185edfddba2d1b76)|Text||2017-07-20 05:46:39|d85818e82a6e64ca185edfddba2d1b76.virus|
|[c9f16f0be8c77f0170b9b6ce876ed7fb](https://www.virustotal.com/gui/file/c9f16f0be8c77f0170b9b6ce876ed7fb)|Win32 EXE|MSILPerseus|2017-07-12 15:33:16|exeruner.exe|
|[8afdfd6d035b3c616dc37894a15206b4](https://www.virustotal.com/gui/file/8afdfd6d035b3c616dc37894a15206b4)|Win64 DLL||2017-03-05 09:44:25|TrafficHandler.dll|
|[527405a2a56961e69d201288a31301b2](https://www.virustotal.com/gui/file/527405a2a56961e69d201288a31301b2)|Win32 EXE||2016-11-09 17:22:39|527405a2a56961e69d201288a31301b2.virus|
|[46b4d31fcafaac43bc99c48140fa8afe](https://www.virustotal.com/gui/file/46b4d31fcafaac43bc99c48140fa8afe)|Win32 EXE||2016-10-04 10:48:16|a6a0fbfee08367046d3d26fb4b4cf7779f7fb6eaf7e60e1d9b6bf31c5be5b63e.bin|
|[0f9d0b03254830714654c2ceb11a7f5d](https://www.virustotal.com/gui/file/0f9d0b03254830714654c2ceb11a7f5d)|Win64 DLL||2016-09-28 06:47:47|HttpParser.dll|
|[a0fb3b8d64c40e78b7502b0f8d7ada00](https://www.virustotal.com/gui/file/a0fb3b8d64c40e78b7502b0f8d7ada00)|Win32 EXE||2016-09-11 11:17:53|pos.exe|
|[0c2f71a8b5f88dbe385b1fbd9b41836f](https://www.virustotal.com/gui/file/0c2f71a8b5f88dbe385b1fbd9b41836f)|XLS||2016-05-25 01:07:44|/home/virustotal/sample/0C2F71A8B5F88DBE385B1FBD9B41836F|
|[f252a06e629b881f49917a7da7c8ecc4](https://www.virustotal.com/gui/file/f252a06e629b881f49917a7da7c8ecc4)|XLS|o97m|2016-05-22 16:06:53|/home/virustotal/sample/F252A06E629B881F49917A7DA7C8ECC4|
|[6318e219b7f6e7f96192e0cdfea1742c](https://www.virustotal.com/gui/file/6318e219b7f6e7f96192e0cdfea1742c)|XLS|o97m|2016-05-15 13:22:17|/home/virustotal/sample/6318E219B7F6E7F96192E0CDFEA1742C|
|[dcd3913fa8b82983cabb36770070861b](https://www.virustotal.com/gui/file/dcd3913fa8b82983cabb36770070861b)|XLS||2016-05-12 07:29:34|/home/virustotal/sample/DCD3913FA8B82983CABB36770070861B|
|[5432363a0f644e3988fe56eefe6a668c](https://www.virustotal.com/gui/file/5432363a0f644e3988fe56eefe6a668c)|XLS||2016-05-11 04:39:16|/home/virustotal/sample/5432363A0F644E3988FE56EEFE6A668C|
|[ccfcd3c63abfb00db901308bbfe11bd1](https://www.virustotal.com/gui/file/ccfcd3c63abfb00db901308bbfe11bd1)|XLS||2016-05-09 06:33:54|/home/virustotal/sample/CCFCD3C63ABFB00DB901308BBFE11BD1|
|[69b0cec55e4df899e649fa00c2979661](https://www.virustotal.com/gui/file/69b0cec55e4df899e649fa00c2979661)|Win32 EXE||2013-07-25 19:32:13|elrawdsk.sys|
|[38a1811096a24210a472133a23e2f942](https://www.virustotal.com/gui/file/38a1811096a24210a472133a23e2f942)|Win64 EXE||2009-06-30 08:34:24|3ca3a957c526eaeabcf17b0b2cd345c0fffab549adfdf04470b6983b87f7ec62.bin|
|[f01a9a2d1e31332ed36c1a4d2839f412](https://www.virustotal.com/gui/file/f01a9a2d1e31332ed36c1a4d2839f412)|Win32 EXE||2009-02-12 22:19:48|nb.exe|
|[20d9d5cf185b7aed08ef93a51a75bf27](https://www.virustotal.com/gui/file/20d9d5cf185b7aed08ef93a51a75bf27)|XLS|o97m|2020-03-04 10:58:21|14120-20d9d5cf185b7aed08ef93a51a75bf27.xls|
|[6058a180ef3026c35f15600ac3e2c57a](https://www.virustotal.com/gui/file/6058a180ef3026c35f15600ac3e2c57a)|XLS|o97m|2020-03-02 20:43:04| |
|[48d22038c7e7cc968a2cb6fb39519e11](https://www.virustotal.com/gui/file/48d22038c7e7cc968a2cb6fb39519e11)|XML||2020-03-02 07:49:50|C:\Users\Public\.Monitor\monitor.exe.config|
|[b08dff2a95426a0e32731ef337eab542](https://www.virustotal.com/gui/file/b08dff2a95426a0e32731ef337eab542)|Win32 EXE||2020-02-29 13:44:52|System Exchange Service.exe|
|[07d78e211fe6684b999bd9ee46e3ba31](https://www.virustotal.com/gui/file/07d78e211fe6684b999bd9ee46e3ba31)|XLS|o97m|2020-02-17 16:05:05|07d78e211fe6684b999bd9ee46e3ba31.virus|
|[51e362e8dc8d5ed7228af47ed913242a](https://www.virustotal.com/gui/file/51e362e8dc8d5ed7228af47ed913242a)|ZIP||2020-01-28 21:51:55|testfile.zip|
|[8beb7bb883a091d2690982d9d46d3bb4](https://www.virustotal.com/gui/file/8beb7bb883a091d2690982d9d46d3bb4)|XLS|Sagent|2020-01-28 13:51:38|20b3d046ed617b7336156a64a0550d416afdd80a2c32ce332be6bbfd4829832c.bin|
|[b15552213169ad3b8efb14470987a335](https://www.virustotal.com/gui/file/b15552213169ad3b8efb14470987a335)|XLS|Sagent|2020-01-28 10:31:09|a897164e3547f0ce3aaa476b0364a200769e8c07ce825bcfdc43939dd1314bb1.bin|
|[17150a137c43235ad07011b552f9ff27](https://www.virustotal.com/gui/file/17150a137c43235ad07011b552f9ff27)|Win32 EXE||2020-01-28 10:28:13|Client update.exe|
|[e2fc67d5572f66f92c21a9d95a4df2d0](https://www.virustotal.com/gui/file/e2fc67d5572f66f92c21a9d95a4df2d0)|Win64 EXE||2020-01-28 10:27:25|ch.exe|
|[8afa8a59eebf43ef223be52e08fcdc67](https://www.virustotal.com/gui/file/8afa8a59eebf43ef223be52e08fcdc67)|Win64 EXE||2019-12-30 15:53:45|f07b0c79a8c88a5760847226af277cf34ab5508394a58820db4db5a8d0340fc7.exe|
|[f5f8160fe8468a77b6a495155c3dacea](https://www.virustotal.com/gui/file/f5f8160fe8468a77b6a495155c3dacea)|Win64 EXE||2019-12-30 15:53:36|44100c73c6e2529c591a10cd3668691d92dc0241152ec82a72c6e63da299d3a2.exe|
|[32a5f02066b4f74de28d156132bb9eb4](https://www.virustotal.com/gui/file/32a5f02066b4f74de28d156132bb9eb4)|TXT||2019-12-23 10:40:15|f1aa9f9012213f0202ef779219f7cba84c2fa01bb19e21951e074d84f84c5ec7.bin|
|[2de2e528991ac2d85aa8f12fce5351ad](https://www.virustotal.com/gui/file/2de2e528991ac2d85aa8f12fce5351ad)|Win32 EXE||2019-12-13 17:37:41|8406ca490c60ec41569b35f31f1860ff4663bba44d1daac64760ecdfe694203d.bin|
