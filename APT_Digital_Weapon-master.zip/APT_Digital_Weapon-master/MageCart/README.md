**NAME:**  
MageCart  

**Description**:   
According to RiskIQ, Magecart is a rapidly growing cybercrime syndicate comprised of dozens of subgroups that specialize in cyberattacks involving digital credit card theft by skimming online payment forms. It also refers to the JavaScript code those groups inject.
Magecart mainly targets e-commerce websites, aiming to inject their JavaScript skimmers on checkout pages. It also steals other types of sensitive, monetizable data entered into online web forms.

**References**:  
https://www.bleepingcomputer.com/news/security/british-airways-fell-victim-to-card-scraping-attack/  
https://www.bleepingcomputer.com/news/security/feedify-hacked-with-magecart-information-stealing-script/  
https://www.bleepingcomputer.com/news/security/magecart-group-compromises-plugin-used-in-thousands-of-stores-makes-rookie-mistake/  
https://www.bleepingcomputer.com/news/security/visiondirect-data-breach-caused-by-magecart-attack/  
https://www.bleepingcomputer.com/news/security/magecart-group-sabotages-rival-to-ruin-data-and-reputation/  