|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[852b3467f3a79e805b91d0cac01bd328](https://www.virustotal.com/gui/file/852b3467f3a79e805b91d0cac01bd328)|Win32 EXE||2019-08-29 10:29:21|panefivakuluxaso.exe|
|[8c47745c1a0cb6b2f7278b807ce46648](https://www.virustotal.com/gui/file/8c47745c1a0cb6b2f7278b807ce46648)|Text||2019-08-28 16:12:13|payload.js|
|[fceac5474b5f4db3508aa2b008e90930](https://www.virustotal.com/gui/file/fceac5474b5f4db3508aa2b008e90930)|Win32 EXE|Kryptik|2019-08-15 16:40:26|4450cdc07b5e74dca239f91073c7711b10374f5f6223dd01227dc825eb412951.bin|
|[9d2c60cad96e3c1c6e6fae0faca55cb0](https://www.virustotal.com/gui/file/9d2c60cad96e3c1c6e6fae0faca55cb0)|Win32 EXE|Kryptik|2019-08-15 16:36:07|587c02514de3de4eb3be5e4d0949b39e6d14529250c766974f5f727dff4f1ffe.bin|
|[e55adc77da695df375ab985469b5e5e4](https://www.virustotal.com/gui/file/e55adc77da695df375ab985469b5e5e4)|Win32 EXE|wacatac|2019-08-12 19:31:08|panefivakuluxaso.exe|
|[0e65c933f2e53ecee4c677bad5f84899](https://www.virustotal.com/gui/file/0e65c933f2e53ecee4c677bad5f84899)|Win32 EXE|Kryptik|2019-08-10 09:46:39|kewalohaxevirucehep.exe|
|[fb01f0b120b61a87306b94c5fcb3de4d](https://www.virustotal.com/gui/file/fb01f0b120b61a87306b94c5fcb3de4d)|Win32 EXE|wacatac|2019-08-06 11:27:03|C:\Users\<USER>\AppData\Local\Microsoft\Windows\Temporary Internet Files\Content.IE5\XBL73YY1\taskis[1].exe|
|[946734422c21c3b6185dc61e272098aa](https://www.virustotal.com/gui/file/946734422c21c3b6185dc61e272098aa)|Text||2019-06-27 10:41:19|5cfe2040ea03d.js|
|[72eb788c598edee286b162b499f2384d](https://www.virustotal.com/gui/file/72eb788c598edee286b162b499f2384d)|C++||2019-05-12 19:38:21|.|
|[d73c133273ac30806f9e943adff08576](https://www.virustotal.com/gui/file/d73c133273ac30806f9e943adff08576)|C++||2019-04-13 14:25:29|b7e459344bf01f27e817e536641138f15922b723afcf629603c7c41d86e3c0f3.bin|
|[9da1bd97847f756a7cec9a185b59bb62](https://www.virustotal.com/gui/file/9da1bd97847f756a7cec9a185b59bb62)|TXT||2019-04-13 14:22:49|test3try.js|
|[e47d6744890d0e9a8717b07bf0e1f138](https://www.virustotal.com/gui/file/e47d6744890d0e9a8717b07bf0e1f138)|Text||2019-04-13 13:52:01|test2.js|
|[0e8c29c023af603ea1a0a0cc6bd4e3d0](https://www.virustotal.com/gui/file/0e8c29c023af603ea1a0a0cc6bd4e3d0)|TXT||2019-04-11 20:54:30|test2try.js|
|[c5e7dfc561644466afbd34360c12be7e](https://www.virustotal.com/gui/file/c5e7dfc561644466afbd34360c12be7e)|TXT||2019-04-11 20:49:09|test4try.js|
|[b6135b7d590c64eb06d453b45fd40974](https://www.virustotal.com/gui/file/b6135b7d590c64eb06d453b45fd40974)|Text||2019-04-11 20:47:09|test4try.js|
|[0fa975c34914fec4073fa5264e6c9838](https://www.virustotal.com/gui/file/0fa975c34914fec4073fa5264e6c9838)|TXT||2019-04-11 20:44:47|test4ccf.js|
|[e157c59d3c62937296f42e994f27d6d0](https://www.virustotal.com/gui/file/e157c59d3c62937296f42e994f27d6d0)|Text|foretype|2019-04-11 20:40:48|test3try.js|
|[0a7b6bc47e5af3c0dc9a4aaf58253410](https://www.virustotal.com/gui/file/0a7b6bc47e5af3c0dc9a4aaf58253410)|C++|foretype|2019-04-11 20:38:18|test3ccf.js|
|[3a91b845cf4be1b27a4928bff59113d7](https://www.virustotal.com/gui/file/3a91b845cf4be1b27a4928bff59113d7)|Text||2019-04-11 20:33:41|test2try.js|
|[17829aa74646cefddb503541cf877ab0](https://www.virustotal.com/gui/file/17829aa74646cefddb503541cf877ab0)|Text||2019-04-11 20:12:53|test1try.js|
|[5823ffc250df8e69abdd88cc0514983b](https://www.virustotal.com/gui/file/5823ffc250df8e69abdd88cc0514983b)|TXT||2019-04-11 20:11:16|test1ccf.js|
|[0df090327467555726b6145ac7ee72ff](https://www.virustotal.com/gui/file/0df090327467555726b6145ac7ee72ff)|TXT||2019-04-11 17:31:32|test4.js|
|[3038479ac6a342d9c1a1b338605abdae](https://www.virustotal.com/gui/file/3038479ac6a342d9c1a1b338605abdae)|HTML||2019-04-11 17:27:29|test4.html|
|[5993560c902ea578431437f81f96d74e](https://www.virustotal.com/gui/file/5993560c902ea578431437f81f96d74e)|TXT||2019-04-11 16:57:46|test3.js|
|[1450f76e2d91beda081a0f4fc79eed0c](https://www.virustotal.com/gui/file/1450f76e2d91beda081a0f4fc79eed0c)|Text||2019-04-11 16:46:14|test2.js|
|[d1840e0624fb8885ac31ec69eef77296](https://www.virustotal.com/gui/file/d1840e0624fb8885ac31ec69eef77296)|TXT||2019-04-11 16:39:38|test.js|
|[f7219a040364923c858070ebaaaf1ea0](https://www.virustotal.com/gui/file/f7219a040364923c858070ebaaaf1ea0)|Win32 EXE||2019-03-28 20:35:31|f7219a040364923c858070ebaaaf1ea0.virus|
|[0c04c3b060b7429b2a216b76a71e6850](https://www.virustotal.com/gui/file/0c04c3b060b7429b2a216b76a71e6850)|Text||2019-01-07 15:56:24|myvtfile.exe|
|[0395dd9d4ec08fe5224106a7d2ee9260](https://www.virustotal.com/gui/file/0395dd9d4ec08fe5224106a7d2ee9260)|Text||2019-01-07 15:52:22|myvtfile.exe|
|[ee157c39e6cf4555476ca41db8420e68](https://www.virustotal.com/gui/file/ee157c39e6cf4555476ca41db8420e68)|Text|Kryptik|2019-01-03 16:45:53|myvtfile.exe|
|[db0cb908da4723a290478160d3b855d4](https://www.virustotal.com/gui/file/db0cb908da4723a290478160d3b855d4)|Text||2018-12-21 09:35:07|VirusShare_db0cb908da4723a290478160d3b855d4|
|[50321d8f0d0d9a44465995251bef98a1](https://www.virustotal.com/gui/file/50321d8f0d0d9a44465995251bef98a1)|Text||2018-11-21 08:45:06|/data/cfs/malshare/50321d8f0d0d9a44465995251bef98a1|
|[2ae7c73badcffa20d7ff999a809a9e5c](https://www.virustotal.com/gui/file/2ae7c73badcffa20d7ff999a809a9e5c)|Text||2018-11-19 06:00:04|/data/cfs/malshare/2ae7c73badcffa20d7ff999a809a9e5c|
|[787d1d1733a70e5107f414f9b1e7868d](https://www.virustotal.com/gui/file/787d1d1733a70e5107f414f9b1e7868d)|Text||2018-11-19 05:41:40|analytics.js|
|[9cb61c81cd71d33a84e33f8ee3b81fc9](https://www.virustotal.com/gui/file/9cb61c81cd71d33a84e33f8ee3b81fc9)|Text||2018-11-11 11:01:05|VirusShare_9cb61c81cd71d33a84e33f8ee3b81fc9|
|[967f7722009eae576a7af1626eb43955](https://www.virustotal.com/gui/file/967f7722009eae576a7af1626eb43955)|Text||2018-11-11 04:13:56|VirusShare_967f7722009eae576a7af1626eb43955|
|[180d903f47e3c7baa65825f65e09bca0](https://www.virustotal.com/gui/file/180d903f47e3c7baa65825f65e09bca0)|Text||2018-11-10 09:22:48|VirusShare_180d903f47e3c7baa65825f65e09bca0|
|[f884178d47d05be4abfa8ff81895dfcc](https://www.virustotal.com/gui/file/f884178d47d05be4abfa8ff81895dfcc)|Text||2018-11-10 00:04:32|/data/cfs/malshare/f884178d47d05be4abfa8ff81895dfcc|
|[434a1c9e65d68138666f86fbe2c630ff](https://www.virustotal.com/gui/file/434a1c9e65d68138666f86fbe2c630ff)|Text||2018-11-09 23:05:57|VirusShare_434a1c9e65d68138666f86fbe2c630ff|
|[5889b1826a45e10010e68cfe70eacdd4](https://www.virustotal.com/gui/file/5889b1826a45e10010e68cfe70eacdd4)|Text||2018-11-09 23:05:20|VirusShare_5889b1826a45e10010e68cfe70eacdd4|
|[fe59f6f0d088e07177361c773cd807ba](https://www.virustotal.com/gui/file/fe59f6f0d088e07177361c773cd807ba)|Text||2018-11-09 16:00:46|VirusShare_fe59f6f0d088e07177361c773cd807ba|
|[5f56c50b6d537fef6762ef8899ecff51](https://www.virustotal.com/gui/file/5f56c50b6d537fef6762ef8899ecff51)|Text||2018-11-09 10:07:13|/data/cfs/malshare/5f56c50b6d537fef6762ef8899ecff51|
|[ad60c1ccb84e81e2f77b503054261920](https://www.virustotal.com/gui/file/ad60c1ccb84e81e2f77b503054261920)|Text||2018-11-09 07:22:59|VirusShare_ad60c1ccb84e81e2f77b503054261920|
|[46e0ac454f6dfb8c6436139c076df774](https://www.virustotal.com/gui/file/46e0ac454f6dfb8c6436139c076df774)|Text||2018-11-09 06:02:28|VirusShare_46e0ac454f6dfb8c6436139c076df774|
|[57a65a522efbc2d339de3c6fd89bdaa7](https://www.virustotal.com/gui/file/57a65a522efbc2d339de3c6fd89bdaa7)|Text||2018-11-09 01:07:38|VirusShare_57a65a522efbc2d339de3c6fd89bdaa7|
|[4c1526a9d34b3e89ca238d6dbaacee81](https://www.virustotal.com/gui/file/4c1526a9d34b3e89ca238d6dbaacee81)|Text||2018-11-05 18:14:30|myvtfile.exe|
|[270c35144b6633f7cf416593846d4c13](https://www.virustotal.com/gui/file/270c35144b6633f7cf416593846d4c13)|Text||2018-10-23 20:11:32|myvtfile.exe|
|[6f270df4d9664b57837be6645950d05e](https://www.virustotal.com/gui/file/6f270df4d9664b57837be6645950d05e)|TXT||2017-11-06 18:52:29|2d01e61a73d64c45271f9407dde61b063e30a7dc9188f1353a634fe462f285b4.bin|
|[976561b2eb98ea05385e2f31e3e75bc9](https://www.virustotal.com/gui/file/976561b2eb98ea05385e2f31e3e75bc9)|TXT||2017-04-21 06:33:52|390b778497f71989058c95dc12628f969e995d2f261f128e8c14aa2c262737d7.bin|
|[98ceaced3fa4c06ad48c8eb52352d528](https://www.virustotal.com/gui/file/98ceaced3fa4c06ad48c8eb52352d528)|unknown||2017-02-02 00:12:37|jquery.min.js|
|[b91726b451b026311c7399bd4646f121](https://www.virustotal.com/gui/file/b91726b451b026311c7399bd4646f121)|TXT||2012-04-06 10:58:48|advnads20.js|
|[2d7a20bd3b76701b2d0de524f7862239](https://www.virustotal.com/gui/file/2d7a20bd3b76701b2d0de524f7862239)|PNG||2020-03-22 22:05:56|faq_icon.png|
