**NAME:**  
Blackgear  
  
**Alias**  
Topgear, Comnie, Blackgear  
  
**Description**:   
Blackgear is an espionage campaign which has targeted users in Japan, Korea and China (Taiwan) for many years. Protux was frequently used to target public institutions and high-tech industries. Related Elirks malware was also captured by Trend Micro in 2016 while targeting Japan. The malware usually uses blogs, Weibo and social networks for C2 communications.
  
**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/blackgear-cyberespionage-campaign-resurfaces-abuses-social-media-for-cc-communication/  
