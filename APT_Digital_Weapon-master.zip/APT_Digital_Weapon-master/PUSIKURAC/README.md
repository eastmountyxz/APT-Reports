**NAME:**  
PUSIKURAC  
  
**Description**:   
PUSIKURAC, disclosed by Morphisec, is a threat actor specifically focuses on information stealing and .NET evasion. Before executing the attacks, it registers domains through FreeDns services. It also utilizes legitimate free text storage services like paste, signs its executables, heavily missuses commercial .NET packers and embeds payloads within video files and images.
  
**References**:  
http://blog.morphisec.com/new-campaign-delivering-orcus-rat