|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[67b1d64f669eabd6f843a163edeb88a2](https://www.virustotal.com/gui/file/67b1d64f669eabd6f843a163edeb88a2)|Win32 EXE||2018-10-29 14:20:53|wsmprovav.exe|
