**NAME:**  
NotPetya  
  
**Description**:   
The massive NotPetya ransomware outbreak that crippled organizations around the world in 2017 was connected to TeleBots by ESET. While the malware has a ransomware component, NotPetya can’t decrypt victims’ disk, even if a payment is made. It contains worm-like features to spread itself across a computer network using the SMBv1 exploits EternalBlue and EternalRomance.
  
**References**:  
https://www.eset.com/us/about/newsroom/press-releases/eset-researchers-discover-links-between-two-major-cybersecurity-attacks-notpetya-and-industroyer/
