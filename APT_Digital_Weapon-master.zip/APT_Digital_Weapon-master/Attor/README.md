**NAME:**  
Attor  

**Description**:   
Attor is an espionage platform with a complex architecture uncovered by ESET. Its GSM plugin uses the AT command protocol, and second, it uses Tor for its network communications.
Attor’s espionage operation is highly targeted. The platform was used in targeted attacks against diplomatic missions and governmental institutions, and privacy-concerned users since at least 2013.

  
**References**:  
https://www.welivesecurity.com/2019/10/10/eset-discovers-attor-spy-platform/