|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c08edc46d28d62379aed5b71620f86f2](https://www.virustotal.com/gui/file/c08edc46d28d62379aed5b71620f86f2)|Android||2018-01-31 20:31:50|c08edc46d28d62379aed5b71620f86f2.virus|
|[85b794e080d83a91e904b97769e1e770](https://www.virustotal.com/gui/file/85b794e080d83a91e904b97769e1e770)|ZIP|CrossRAT|2018-01-23 02:39:52|CrossRAT.jar|
|[95ad2569e58d4c7d9d81c3b93f1437ab](https://www.virustotal.com/gui/file/95ad2569e58d4c7d9d81c3b93f1437ab)|Win32 DLL||2018-01-21 20:25:25|95ad2569e58d4c7d9d81c3b93f1437ab.virus|
|[d5a658db102da78958f1aea1c3d0f202](https://www.virustotal.com/gui/file/d5a658db102da78958f1aea1c3d0f202)|CHM||2018-01-19 09:17:28|d5a658db102da78958f1aea1c3d0f202.virus|
|[d38ee304db5692030838d0dc1e37c97b](https://www.virustotal.com/gui/file/d38ee304db5692030838d0dc1e37c97b)|Win32 DLL||2017-11-22 21:59:37|d38ee304db5692030838d0dc1e37c97b.virus|
|[6e5e829e7a503dcefc753ba6f33f1e3d](https://www.virustotal.com/gui/file/6e5e829e7a503dcefc753ba6f33f1e3d)|Win32 EXE||2017-08-08 10:58:15|a887426dcb133e22449bafd6498eddc2a5fa67e6|
|[f4340bb3bd18a4c500c9c3d24e74fe97](https://www.virustotal.com/gui/file/f4340bb3bd18a4c500c9c3d24e74fe97)|Win32 EXE||2017-08-03 20:23:09|da81aec00b563123d2fbd14fb6a76619c90f81e83c5bd8aa0676922cae96b9ad.exe|
|[e8b61369ae7894baba2e26b3b58f23b6](https://www.virustotal.com/gui/file/e8b61369ae7894baba2e26b3b58f23b6)|Win32 EXE||2017-08-01 22:47:21|bf600e7b27bdd9e396e5c396aba7f079c244bfb92ee45c721c2294aa36586206.exe|
|[e0c854bda714fed48fdc72d86c0226a3](https://www.virustotal.com/gui/file/e0c854bda714fed48fdc72d86c0226a3)|Win32 DLL||2017-06-17 09:06:49| |
|[84a825480f054767814598df235061fa](https://www.virustotal.com/gui/file/84a825480f054767814598df235061fa)|Win32 EXE||2017-06-12 17:42:55|Spectre|
|[825ffbca0f80a7f1999712a0d6d2000c](https://www.virustotal.com/gui/file/825ffbca0f80a7f1999712a0d6d2000c)|Win32 EXE|Zbot|2017-05-29 16:31:20|f581a75a0f8f8eb200a283437bed48f30ae9d5616e94f64acfd93c12fcef987a.bin|
|[b14a16af8e9feacb215db2b6434214fc](https://www.virustotal.com/gui/file/b14a16af8e9feacb215db2b6434214fc)|Win32 EXE|Dorkbot|2017-05-27 00:24:27| |
|[a254d46e8fe36ab3fc4310d9bcf1dafc](https://www.virustotal.com/gui/file/a254d46e8fe36ab3fc4310d9bcf1dafc)|Android||2017-05-23 07:34:35|a254d46e8fe36ab3fc4310d9bcf1dafc.virus|
|[cd57c9d2167e5b7893b4ef965cd863b3](https://www.virustotal.com/gui/file/cd57c9d2167e5b7893b4ef965cd863b3)|Android|androidos|2017-05-23 07:33:46|cd57c9d2167e5b7893b4ef965cd863b3.virus|
|[4b1918576e4be67de835a85d986b75ef](https://www.virustotal.com/gui/file/4b1918576e4be67de835a85d986b75ef)|Android|androidos|2017-05-23 07:33:42|4b1918576e4be67de835a85d986b75ef.virus|
|[c1852f1116527f27c8115d876ca70d87](https://www.virustotal.com/gui/file/c1852f1116527f27c8115d876ca70d87)|Android||2017-05-23 07:33:21|qfijUo5NfuYUYsKry6J420180129-14389-1n3lwxz|
|[4416beffba77e4a78227e4aeb687f0a7](https://www.virustotal.com/gui/file/4416beffba77e4a78227e4aeb687f0a7)|Android||2017-05-23 07:33:14|4416beffba77e4a78227e4aeb687f0a7.virus|
|[739aea2e591ff8e5fd7021ba1fb5df5d](https://www.virustotal.com/gui/file/739aea2e591ff8e5fd7021ba1fb5df5d)|Android||2017-05-23 07:32:15|739aea2e591ff8e5fd7021ba1fb5df5d.virus|
|[bc6bd454281171a9ccfc464c2dd65291](https://www.virustotal.com/gui/file/bc6bd454281171a9ccfc464c2dd65291)|Android||2017-05-23 07:31:16|Dh9PK63v8FixSaqWiyZC20180129-13516-ly7hhy|
|[cda2bbcf9414001233f1d025c377b0ac](https://www.virustotal.com/gui/file/cda2bbcf9414001233f1d025c377b0ac)|Android||2017-05-23 07:31:06|cda2bbcf9414001233f1d025c377b0ac.virus|
|[d5249bfc8909a669e1675c2d81754748](https://www.virustotal.com/gui/file/d5249bfc8909a669e1675c2d81754748)|Win32 EXE||2017-05-17 07:13:23|extra.abc|
|[643b0db380149d220ce9074a29f83841](https://www.virustotal.com/gui/file/643b0db380149d220ce9074a29f83841)|Win32 EXE||2016-05-04 13:38:11|Spectre|
|[150cce17d72f765217e69f36d6d6bf64](https://www.virustotal.com/gui/file/150cce17d72f765217e69f36d6d6bf64)|Win32 EXE|graftor|2016-01-11 14:26:51|150cce17d72f765217e69f36d6d6bf64.virus|
|[05bd5ac2baf0abbce24deb916d0fb79c](https://www.virustotal.com/gui/file/05bd5ac2baf0abbce24deb916d0fb79c)|Win32 EXE||2014-06-10 10:07:52|host.exe|
