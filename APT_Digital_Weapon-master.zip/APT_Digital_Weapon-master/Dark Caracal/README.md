**NAME:**  
Dark Caracal  

**Description**:   
Dark Caracal, a persistent and prolific actor, is believed to be administered out of a building belonging to the Lebanese General Security Directorate in Beirut. Hundreds of gigabytes of data have been exfiltrated since 2012, including enterprise intellectual property and personally identifiable information
  
**References**:  
https://info.lookout.com/rs/051-ESQ-475/images/Lookout_Dark-Caracal_srr_20180118_us_v.1.0.pdf
