|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[650183a8cef11f3105a056189c777196](https://www.virustotal.com/gui/file/650183a8cef11f3105a056189c777196)|Android||2019-07-02 06:41:56| |
|[053ae0ccb16c90faee6539556dc4e392](https://www.virustotal.com/gui/file/053ae0ccb16c90faee6539556dc4e392)|Android||2019-05-25 18:48:44|053ae0ccb16c90faee6539556dc4e392.virus|
|[81db60e82a0a107d754a93a5e29fd71a](https://www.virustotal.com/gui/file/81db60e82a0a107d754a93a5e29fd71a)|Android||2019-01-20 23:19:56| |
|[694040b229562b8dca9534c5301f8d73](https://www.virustotal.com/gui/file/694040b229562b8dca9534c5301f8d73)|Win32 EXE|razy|2018-11-26 17:42:41|smtpldr|
|[d16071e966e9a4827d187f73e3186c34](https://www.virustotal.com/gui/file/d16071e966e9a4827d187f73e3186c34)|Win32 EXE|Symmi|2018-08-22 05:20:44|sscvc|
|[52f09063a9771a4952611945c8db081a](https://www.virustotal.com/gui/file/52f09063a9771a4952611945c8db081a)|Win32 EXE|razy|2018-08-20 14:54:55|syssrvc|
|[6c2a682f495d13d44a40c8568074a8f5](https://www.virustotal.com/gui/file/6c2a682f495d13d44a40c8568074a8f5)|Win32 EXE||2018-08-16 21:22:53|cdmvr|
|[103e89c80ada1d686d18e6c6b8f824c2](https://www.virustotal.com/gui/file/103e89c80ada1d686d18e6c6b8f824c2)|Win32 EXE|Delf|2018-08-15 08:22:32|windlls|
|[ad2ba55638843995ff79a83680241ab7](https://www.virustotal.com/gui/file/ad2ba55638843995ff79a83680241ab7)|Android||2018-08-07 07:00:45|AD2BA55638843995FF79A83680241AB7.apk|
|[8bd6bb54ccb5312c209438f1e676d9eb](https://www.virustotal.com/gui/file/8bd6bb54ccb5312c209438f1e676d9eb)|Win32 EXE|Delf|2018-07-20 23:04:24|ckmsvc.exe|
|[ce2a6437a308dfe777dec42eec39d9ea](https://www.virustotal.com/gui/file/ce2a6437a308dfe777dec42eec39d9ea)|FPX||2018-07-20 10:48:09|7ef9b59cb57193fb62039602596723189fcdb5986590ca4e55edb1d0034f2faf.bin|
|[ae8031cb4758b24d3b8c812c916e7c89](https://www.virustotal.com/gui/file/ae8031cb4758b24d3b8c812c916e7c89)|Win32 EXE|Delf|2018-07-06 14:54:06|grphsrv|
|[c6a8b7a0b04d445e3609404e307aa81b](https://www.virustotal.com/gui/file/c6a8b7a0b04d445e3609404e307aa81b)|RTF|CVE-2017-11882|2018-07-06 10:14:32|Operational_Reports_June_2018.doc|
|[56ce941496bef3ef8d1d361a0ee22499](https://www.virustotal.com/gui/file/56ce941496bef3ef8d1d361a0ee22499)|Android|androidos|2018-07-05 07:19:46|SysServ.apk|
|[bda6f461ddc38cae7d43b6af7f712c3d](https://www.virustotal.com/gui/file/bda6f461ddc38cae7d43b6af7f712c3d)|Android||2018-07-02 05:10:13|shield.blacklist.apk|
|[984e51e6668f0a80d9608b0974da68c9](https://www.virustotal.com/gui/file/984e51e6668f0a80d9608b0974da68c9)|RTF||2018-06-30 18:29:54|ed3db1676f0e7d17ced0fda4a7c3b327a241c0e7|
|[56e7b14b81f229a7e690bf781c019a9b](https://www.virustotal.com/gui/file/56e7b14b81f229a7e690bf781c019a9b)|Android||2018-06-27 04:45:22|app-debug(1).apk|
|[b1d3ca3d6f4a743c3dd292c59afdb5e8](https://www.virustotal.com/gui/file/b1d3ca3d6f4a743c3dd292c59afdb5e8)|Win32 EXE||2018-06-19 18:49:29|WinUtility|
|[f9bcc1983b16c0b12073ca3bc888d41a](https://www.virustotal.com/gui/file/f9bcc1983b16c0b12073ca3bc888d41a)|RTF|Delf|2018-06-16 06:14:55|NIA_Filed_Chargesheet_Against_ULFA_Leader.doc|
|[fb5735b3d9ffa6ac4a15e4cfc1ff3129](https://www.virustotal.com/gui/file/fb5735b3d9ffa6ac4a15e4cfc1ff3129)|Android||2018-06-04 22:32:45|mychoice.musicplayer.apk|
|[522236125079e83db1a0e7b38ea208a0](https://www.virustotal.com/gui/file/522236125079e83db1a0e7b38ea208a0)|Win32 EXE|Symmi|2018-06-02 07:55:05|522236125079e83db1a0e7b38ea208a0.virobj|
|[e1a4700edfa32116c62663b272833f1d](https://www.virustotal.com/gui/file/e1a4700edfa32116c62663b272833f1d)|Win32 EXE|razy|2018-05-30 13:44:32|winopen.ex|
|[8195e1eb105e5d768d5dc2ff4fa4265d](https://www.virustotal.com/gui/file/8195e1eb105e5d768d5dc2ff4fa4265d)|Android||2018-05-19 03:51:33|/home/lz/lxtmp/547/com.videowatcher.apk|
|[5286631c91642510cbc649458041aae2](https://www.virustotal.com/gui/file/5286631c91642510cbc649458041aae2)|Win32 EXE|Kraken|2018-05-10 04:09:45|wqSvcmgr|
|[f37e10460c16e3c4cfeed18e18bace64](https://www.virustotal.com/gui/file/f37e10460c16e3c4cfeed18e18bace64)|Win32 EXE|razy|2018-05-10 02:22:23|jkvxxxi|
|[1462facb5f53c73ebaa76bf7b249026a](https://www.virustotal.com/gui/file/1462facb5f53c73ebaa76bf7b249026a)|FPX||2018-03-09 05:05:41|Jadhav case detailed Report.inp|
|[f6b419f0a2bfe6f76282fbc480ebab95](https://www.virustotal.com/gui/file/f6b419f0a2bfe6f76282fbc480ebab95)|FPX||2018-03-01 16:22:00|~WRD0000.tmp|
|[8aabce0b9378633aad8ebbcd7497dc60](https://www.virustotal.com/gui/file/8aabce0b9378633aad8ebbcd7497dc60)|Text||2018-03-01 16:21:59|template.rtf|
|[85a39544a37be96b32a5227e8c0642c4](https://www.virustotal.com/gui/file/85a39544a37be96b32a5227e8c0642c4)|RTF|CVE-2017-0199|2018-03-01 11:31:17|434d34c0502910c562f5c6840694737a2c82a8c44004fa58c7c457b08aac17bd.bin|
|[ebc5c2fe0ccfa081f1940a7921fa7f17](https://www.virustotal.com/gui/file/ebc5c2fe0ccfa081f1940a7921fa7f17)|Win32 EXE|Delf|2018-02-26 06:57:22|netlogsui|
|[ac31fd4f977c07f1a1746736382d25d9](https://www.virustotal.com/gui/file/ac31fd4f977c07f1a1746736382d25d9)|Win32 EXE||2018-02-16 18:22:25|uytutuys|
|[6fe6071e1ddeb2b7a16e78b168797c34](https://www.virustotal.com/gui/file/6fe6071e1ddeb2b7a16e78b168797c34)|Win32 EXE||2018-02-15 18:26:03|AIMPLB  remove Salman Nadvi .exe|
|[4495512798b3729c3ca964eaf61ced27](https://www.virustotal.com/gui/file/4495512798b3729c3ca964eaf61ced27)|MP3||2018-02-14 18:25:57|89de8879829f66c2b1360b313b1c24d2cb676ce9|
|[f936b994c278817026ba8680cb8a5436](https://www.virustotal.com/gui/file/f936b994c278817026ba8680cb8a5436)|Win32 EXE|razy|2018-02-11 13:51:16|vmmrdcx|
|[c17bb2d6e2ed5a291794391eb9ca8b2e](https://www.virustotal.com/gui/file/c17bb2d6e2ed5a291794391eb9ca8b2e)|Win32 EXE||2018-01-16 20:21:44|tvsvs|
|[af48a507055a900c36b8a948e52207e2](https://www.virustotal.com/gui/file/af48a507055a900c36b8a948e52207e2)|Android||2018-01-12 14:46:14|com.newszone.apk|
|[a02f2d1693683972260adc26d71af9fa](https://www.virustotal.com/gui/file/a02f2d1693683972260adc26d71af9fa)|Win32 EXE||2018-01-10 13:36:26|idman623build12.exe|
|[330e2fab0668526b03442ded3257fc28](https://www.virustotal.com/gui/file/330e2fab0668526b03442ded3257fc28)|Win32 EXE|Delf|2018-01-10 13:34:00|ucnhost|
|[a4452e1fc61acef782095bb3fbc004f5](https://www.virustotal.com/gui/file/a4452e1fc61acef782095bb3fbc004f5)|RAR||2018-01-10 13:32:13|IDM 6.23 build 12 por JimmyTutoriales.rar|
|[adb84098afa86b11bbb6c9992cd271a5](https://www.virustotal.com/gui/file/adb84098afa86b11bbb6c9992cd271a5)|Win32 EXE|DELF|2018-01-10 13:32:13|Download Accelerator Plus 9.3.0.6 Beta [multilive.net].exe|
|[94394247c21a559c0e7324e79e02d242](https://www.virustotal.com/gui/file/94394247c21a559c0e7324e79e02d242)|Win32 EXE||2018-01-10 13:32:13|u Torrent.exe|
|[781f5efadfbc1060937aa436de15fa4e](https://www.virustotal.com/gui/file/781f5efadfbc1060937aa436de15fa4e)|7ZIP||2018-01-10 13:32:07|901226|
|[a05dc6a2cd6007fa028ef985f0c01b26](https://www.virustotal.com/gui/file/a05dc6a2cd6007fa028ef985f0c01b26)|Android|androidos|2018-01-03 07:37:50|/1/8/a/8af837d3f54ce0f1cd4deacf235f6bd8f4e89872a34bdf427c13172343cece98.file|
|[23b6b01d9d04ea827b5dfe13840b3f05](https://www.virustotal.com/gui/file/23b6b01d9d04ea827b5dfe13840b3f05)|Android||2017-12-21 06:51:30|49aaed9dec956d345610cc724c0d1fae52ca319b8635f96bfc49ae0421ccfbaa.apk|
|[e6afc5f1db4d0599193d8fff692d665b](https://www.virustotal.com/gui/file/e6afc5f1db4d0599193d8fff692d665b)|Win32 EXE||2017-12-19 05:55:54|lpssvs|
|[fdff61b3a45ef39b7ebf6c1810c0ada2](https://www.virustotal.com/gui/file/fdff61b3a45ef39b7ebf6c1810c0ada2)|Android||2017-12-09 05:18:14|com.perfectstyle.cam.apk|
|[4a7e2e2de18721dd73f6f84c8aa280da](https://www.virustotal.com/gui/file/4a7e2e2de18721dd73f6f84c8aa280da)|Android||2017-12-09 03:38:29|FxENjKBLYFeQ1BJr_2sy20180530-6984-1ffhmdw|
|[665ececb5a29affa1bbc7bd7a9aad830](https://www.virustotal.com/gui/file/665ececb5a29affa1bbc7bd7a9aad830)|Android||2017-12-07 12:50:00|wP4_y_q53dcYyBePx5xG20180603-9771-1dmyurm|
|[85b18467dd4f76c2580e5d7ea63f62cd](https://www.virustotal.com/gui/file/85b18467dd4f76c2580e5d7ea63f62cd)|Android||2017-12-05 09:33:52|com.note.android.gnotes.apk|
|[bf818782ee460d9681ecf729f4c628d9](https://www.virustotal.com/gui/file/bf818782ee460d9681ecf729f4c628d9)|Android||2017-12-03 01:37:01|9W4eb3k9axD2p1o7Mp1-20180603-32440-e7qwuj|
|[1a78238f663baa03d29d3268a91b8d09](https://www.virustotal.com/gui/file/1a78238f663baa03d29d3268a91b8d09)|Win32 EXE|Delf|2017-11-29 16:51:51|ausntool|
|[1c6bc48ffbad1471178cfcc35a59ec5a](https://www.virustotal.com/gui/file/1c6bc48ffbad1471178cfcc35a59ec5a)|Win32 EXE||2017-11-26 08:04:11|htbss|
|[95307752bd12eb171af6c919afcfbb35](https://www.virustotal.com/gui/file/95307752bd12eb171af6c919afcfbb35)|Win32 EXE|Delf|2017-11-16 01:47:31|hmtss|
|[36581d5f7966a3d05fdfe8c9e048c393](https://www.virustotal.com/gui/file/36581d5f7966a3d05fdfe8c9e048c393)|Android|androidos|2017-11-13 06:51:23|/1/9/7/974c182fb9872a4d108109ef84d86333fabe585b604217a72fcd7c84cd4b95a4.file|
|[e77b48f9f5b30d92202b126b045da656](https://www.virustotal.com/gui/file/e77b48f9f5b30d92202b126b045da656)|Win32 EXE||2017-11-08 10:10:36|Idtsvc|
|[a965a87773f5e5a2b143d58e82684ec5](https://www.virustotal.com/gui/file/a965a87773f5e5a2b143d58e82684ec5)|FPX||2017-11-07 18:48:10|C:\TotalVirusScan\Invitation.inp|
|[fec0ca2056d679a63ca18cb132223332](https://www.virustotal.com/gui/file/fec0ca2056d679a63ca18cb132223332)|Win32 EXE|Delf|2017-11-03 10:22:00|fec0ca2056d679a63ca18cb132223332_tRbcrUKvpBM.Exe|
|[23147bfe3be459a4ea2f678aee4566d7](https://www.virustotal.com/gui/file/23147bfe3be459a4ea2f678aee4566d7)|Win32 EXE||2017-10-30 12:05:13|juschek|
|[396db0396afa681e8987838ca4a9ead6](https://www.virustotal.com/gui/file/396db0396afa681e8987838ca4a9ead6)|Win32 EXE|Delf|2017-10-29 10:29:47|xerccver|
|[59cfaa644ba832a370f5c62a34eb61c3](https://www.virustotal.com/gui/file/59cfaa644ba832a370f5c62a34eb61c3)|Win32 EXE||2017-10-25 10:37:11|amd.exe|
|[a160da02ff4d080fe1e62570cb66014b](https://www.virustotal.com/gui/file/a160da02ff4d080fe1e62570cb66014b)|Win32 EXE||2017-10-25 10:37:10|setup.exe|
|[dd3236ec3baf2d16d0a0ce9969ba8eb3](https://www.virustotal.com/gui/file/dd3236ec3baf2d16d0a0ce9969ba8eb3)|ZIP||2017-10-25 10:37:08|/1/2/e/2e4f4e707831e9e7884744200621c6fcd88ed26dadcc15361acd2f249943306c.file|
|[d83ca362217162eef1b21c1f9cbc4412](https://www.virustotal.com/gui/file/d83ca362217162eef1b21c1f9cbc4412)|Android||2017-10-20 02:54:06|d83ca362217162eef1b21c1f9cbc4412.virus|
|[6f8e15093f24fa7807ea0a41b6e582fe](https://www.virustotal.com/gui/file/6f8e15093f24fa7807ea0a41b6e582fe)|ZIP|DELF|2017-10-17 13:02:11|/1/d/d/ddf2520224381c653119908f0dceb154138b0724fa8307ef95629429576024e7.file|
|[605165d1fd3d2cc8ea4f574af50c136e](https://www.virustotal.com/gui/file/605165d1fd3d2cc8ea4f574af50c136e)|Win32 EXE|Delf|2017-10-16 01:26:08|sysm32dll|
|[a794e984d5ec277b255ee80081b3beae](https://www.virustotal.com/gui/file/a794e984d5ec277b255ee80081b3beae)|Win32 EXE|DELF|2017-10-16 01:26:07|a794e984d5ec277b255ee80081b3beae.virus|
|[a7c7a00b96d4b86349c5d115f8f51a6c](https://www.virustotal.com/gui/file/a7c7a00b96d4b86349c5d115f8f51a6c)|Win32 EXE|razy|2017-10-14 10:24:24|E:/data/kbw/new_request/malware/new_request/20171018/a7c7a00b96d4b86349c5d115f8f51a6c.vir|
|[421737b2a02998ef6a22ed7a77956806](https://www.virustotal.com/gui/file/421737b2a02998ef6a22ed7a77956806)|Win32 EXE|Swisyn|2017-10-14 10:23:56|E:/data/kbw/new_request/malware/new_request/20171018/421737b2a02998ef6a22ed7a77956806.vir|
|[759d4fe3ec22a6a47cd9a7a24621771f](https://www.virustotal.com/gui/file/759d4fe3ec22a6a47cd9a7a24621771f)|ZIP|DELF|2017-10-14 10:18:56|/1/6/0/60c1b45113484d97e3a0d56959ac6d010e945d28a266ed52abc20159f9a9a48a.file|
|[308c26bec83fabf8cd0f0ff516cbe1f9](https://www.virustotal.com/gui/file/308c26bec83fabf8cd0f0ff516cbe1f9)|Win32 EXE|johnnie|2017-10-13 08:20:30|D:/Download/MAL/malware/new_request/20171014/308c26bec83fabf8cd0f0ff516cbe1f9.vir|
|[e696a5869f1c160bcdce26163305ffab](https://www.virustotal.com/gui/file/e696a5869f1c160bcdce26163305ffab)|Win32 EXE|Delf|2017-09-21 10:30:15|C:/Users/seongmin/Documents/VT2/malware/20170926/e696a5869f1c160bcdce26163305ffab.vir|
|[bcd690966bc66f1c0e1e24f03cd6be53](https://www.virustotal.com/gui/file/bcd690966bc66f1c0e1e24f03cd6be53)|Win32 EXE||2017-09-16 19:24:32|opstss|
|[e2ed7474cf23e779368a504062aca824](https://www.virustotal.com/gui/file/e2ed7474cf23e779368a504062aca824)|Win32 EXE|Delf|2017-09-14 17:00:40|E:/byeongal/virustotal_public/malware/20170918/e2ed7474cf23e779368a504062aca824.vir|
|[fe4a59d9308857078f56b17a16e1c1a7](https://www.virustotal.com/gui/file/fe4a59d9308857078f56b17a16e1c1a7)|Win32 EXE|razy|2017-09-14 11:15:59|E:/byeongal/virustotal_public/malware/20170917/fe4a59d9308857078f56b17a16e1c1a7.vir|
|[f2ad1f561f5927c5d1f102df33592349](https://www.virustotal.com/gui/file/f2ad1f561f5927c5d1f102df33592349)|Win32 EXE|Delf|2017-09-14 04:28:14|fnvndcver|
|[81244d64582acc272343567567cbcd0f](https://www.virustotal.com/gui/file/81244d64582acc272343567567cbcd0f)|Win32 EXE||2017-08-18 07:52:48|cllproaxis|
|[d39be8e4bf703b211dfa4170d8ea5025](https://www.virustotal.com/gui/file/d39be8e4bf703b211dfa4170d8ea5025)|Win32 EXE||2017-08-18 07:52:32|C:/Users/seongmin/Documents/VT2/malware/20170827/d39be8e4bf703b211dfa4170d8ea5025.vir|
|[5fc3376e3d504e31b562ccba84c1c4b4](https://www.virustotal.com/gui/file/5fc3376e3d504e31b562ccba84c1c4b4)|Win32 EXE|razy|2017-08-05 11:39:28|bnvss|
|[8330c1fdf1731aba816435aecafefa61](https://www.virustotal.com/gui/file/8330c1fdf1731aba816435aecafefa61)|Win32 EXE|Delf|2017-08-04 11:57:43|ernertys|
|[1c1eee5c5be54320077c9c4d80ab0db8](https://www.virustotal.com/gui/file/1c1eee5c5be54320077c9c4d80ab0db8)|Android|androidos|2017-06-21 21:20:14|Cache Remover_v2.7_apkpure.com.apk|
|[ee4c70817d034e041c900da957483977](https://www.virustotal.com/gui/file/ee4c70817d034e041c900da957483977)|Android||2017-06-14 23:40:54|ar.ramdan.apk|
|[ff8f6556897df62d4c4af518f715df97](https://www.virustotal.com/gui/file/ff8f6556897df62d4c4af518f715df97)|DOCX|CVE-2015-2545|2017-06-13 23:50:14|b5ae8fa65faeada5399aded7a1d3a0ab8c5e9936|
|[99b89bd6d5a0268b563c3e521cad0108](https://www.virustotal.com/gui/file/99b89bd6d5a0268b563c3e521cad0108)|Android|androidos|2017-05-22 01:13:06|com.pikr.phto.apk|
|[96c0cff3a73c9e050ea59145a0f83215](https://www.virustotal.com/gui/file/96c0cff3a73c9e050ea59145a0f83215)|Android||2017-04-30 03:11:55|com.gsecu.secure.apk|
|[cf113ea9b61bfeac57c4aa12c78301e0](https://www.virustotal.com/gui/file/cf113ea9b61bfeac57c4aa12c78301e0)|Android||2017-04-25 00:54:53|com.gsecu.secure.apk|
|[262dadd751fca33cb2ac8a0471470f1f](https://www.virustotal.com/gui/file/262dadd751fca33cb2ac8a0471470f1f)|FPX||2017-04-17 11:38:04|KulbhushanYadhav_Vs_MdHabib_SpySwap.inp|
|[5c386264534d496d40c8ef91971eedcb](https://www.virustotal.com/gui/file/5c386264534d496d40c8ef91971eedcb)|Win32 EXE|razy|2017-04-14 10:33:21|spsrefres|
|[5729e488d05206470fca3cf835be4db9](https://www.virustotal.com/gui/file/5729e488d05206470fca3cf835be4db9)|Android|androidos|2017-04-13 11:38:06|/mnt_apk/57/29/5729E488D05206470FCA3CF835BE4DB9|
|[29af4694367119e7c63bf148e6d4c189](https://www.virustotal.com/gui/file/29af4694367119e7c63bf148e6d4c189)|Win32 EXE||2017-04-05 09:41:14|ijkss|
|[81d2f97f759d9c035df34e5a1024cd1d](https://www.virustotal.com/gui/file/81d2f97f759d9c035df34e5a1024cd1d)|Android||2017-03-21 06:26:03|fun.ae.funtimes.apk|
|[3fce4ad82c98bae3ab412d2aebab0aad](https://www.virustotal.com/gui/file/3fce4ad82c98bae3ab412d2aebab0aad)|Win32 EXE|Delf|2017-03-17 10:01:31|ssrcvggr|
|[7abc5042d0660cd07a6a4c1db7b85cfa](https://www.virustotal.com/gui/file/7abc5042d0660cd07a6a4c1db7b85cfa)|Win32 EXE|razy|2017-03-01 08:57:32|jkmss|
|[712bdf5d9975b6d9f17c04d9e66ee1f1](https://www.virustotal.com/gui/file/712bdf5d9975b6d9f17c04d9e66ee1f1)|Win32 EXE|Delf|2017-01-25 06:29:18|vplrefresh|
|[ea545d677e332f318c386844e9629955](https://www.virustotal.com/gui/file/ea545d677e332f318c386844e9629955)|Win32 EXE|Delf|2017-01-10 17:48:58|cnwizardsd|
|[98531c7a857834b3e34a9a0cf15fe0d6](https://www.virustotal.com/gui/file/98531c7a857834b3e34a9a0cf15fe0d6)|Win32 EXE|Delf|2016-11-28 13:41:54|cdesrssr|
|[9c8738ebea75ac9c75c42951cad912c7](https://www.virustotal.com/gui/file/9c8738ebea75ac9c75c42951cad912c7)|Win32 EXE|Delf|2016-10-01 12:27:06|mrsfr|
|[c985e9146112d2745e5894f41b7d690c](https://www.virustotal.com/gui/file/c985e9146112d2745e5894f41b7d690c)|FPX|o97m|2016-09-30 23:49:34|Analysis Report on Kashmir PART ONE.inp|
|[6696ed96f204b4823d60bbb09a6304d4](https://www.virustotal.com/gui/file/6696ed96f204b4823d60bbb09a6304d4)|Android||2016-09-24 18:01:24| |
|[9fda18930234c1893ca504ebeb6121cb](https://www.virustotal.com/gui/file/9fda18930234c1893ca504ebeb6121cb)|Win32 EXE|Delf|2016-09-18 15:50:42|fdsss|
|[a378626a8a08573e8aadc480250358c8](https://www.virustotal.com/gui/file/a378626a8a08573e8aadc480250358c8)|Win32 EXE||2016-09-18 12:05:23|Screenshot.exe|
|[c43fbb5bca12ce1470d148c48af4ce94](https://www.virustotal.com/gui/file/c43fbb5bca12ce1470d148c48af4ce94)|ZIP|Reconyc|2016-09-18 08:16:04|Screenshot.zip|
|[d4d38a0ed5f3986589a5f818e0eb4545](https://www.virustotal.com/gui/file/d4d38a0ed5f3986589a5f818e0eb4545)|Win32 EXE|Delf|2016-09-01 17:01:14|desss|
|[ebb9fbf650baebb3557775b7ff52c815](https://www.virustotal.com/gui/file/ebb9fbf650baebb3557775b7ff52c815)|Win32 EXE|Delf|2016-08-14 04:55:06|dwmlogon|
|[9bb5e4e4ea632e7e218429e3e136751c](https://www.virustotal.com/gui/file/9bb5e4e4ea632e7e218429e3e136751c)|Win32 EXE|Ursu|2016-07-15 06:29:28|dsexplrob|
|[89cae2033d2f7d91eb5adcc82047227b](https://www.virustotal.com/gui/file/89cae2033d2f7d91eb5adcc82047227b)|Win32 EXE|Delf|2016-07-15 06:29:12|msvsmuns|
|[99f1a8bf9efd4a24a3212b8c867b7b00](https://www.virustotal.com/gui/file/99f1a8bf9efd4a24a3212b8c867b7b00)|Win32 EXE|Delf|2016-07-07 07:04:39|cllproaxis|
|[a9072062309e35843d9bc16f8f9a2bd3](https://www.virustotal.com/gui/file/a9072062309e35843d9bc16f8f9a2bd3)|FPX||2016-07-07 07:03:57|test.inp|
|[25f7251e2e303ea2d9fdccab20091b78](https://www.virustotal.com/gui/file/25f7251e2e303ea2d9fdccab20091b78)|Win32 EXE|Delf|2016-06-16 22:29:09|dwm|
|[fddbad955654447aa4bebf4cdfb2cfd6](https://www.virustotal.com/gui/file/fddbad955654447aa4bebf4cdfb2cfd6)|Android||2016-05-30 07:36:10| |
|[0804eed757380924afb35c58142ae147](https://www.virustotal.com/gui/file/0804eed757380924afb35c58142ae147)|Win32 EXE|Delf|2016-05-22 05:51:00|csrssmngnt|
|[d51b2e75015177435e9048f0bcc6e327](https://www.virustotal.com/gui/file/d51b2e75015177435e9048f0bcc6e327)|Win32 EXE||2016-04-26 22:51:19|cmdloader|
|[47a104db7e1f31a9eedbc34afc6e9036](https://www.virustotal.com/gui/file/47a104db7e1f31a9eedbc34afc6e9036)|Win32 EXE|Delf|2016-04-06 08:38:34|syscrlog|
|[3c9afdf5417c325138b6c339ab4732ac](https://www.virustotal.com/gui/file/3c9afdf5417c325138b6c339ab4732ac)|Win32 EXE|vilsel|2016-02-12 04:34:30|inspckge|
|[2a5595474e7ae04058dbd8df8908e314](https://www.virustotal.com/gui/file/2a5595474e7ae04058dbd8df8908e314)|Win32 EXE|Delf|2016-02-02 18:02:12|cmdintgtr|
|[845583cabb74b6d591f741b3ee386e73](https://www.virustotal.com/gui/file/845583cabb74b6d591f741b3ee386e73)|Win32 EXE|Delf|2016-01-29 10:22:58|ispdesk|
|[9e097b06165b75a3b2fc2030ccf8d7a2](https://www.virustotal.com/gui/file/9e097b06165b75a3b2fc2030ccf8d7a2)|Win32 EXE|Delf|2015-12-18 21:53:37|wngtres|
|[493c4b3e20d8713b1b17b1531013d5e0](https://www.virustotal.com/gui/file/493c4b3e20d8713b1b17b1531013d5e0)|Win32 EXE|Delf|2015-12-01 23:47:28|winmedia|
|[cf51420cc1edca47adc8f4d0e2f524bb](https://www.virustotal.com/gui/file/cf51420cc1edca47adc8f4d0e2f524bb)|Win32 EXE||2015-10-28 20:04:18|systemedia|
|[3b95d189755477de7ea507b809bd89e9](https://www.virustotal.com/gui/file/3b95d189755477de7ea507b809bd89e9)|Win32 EXE|Delf|2015-05-30 16:12:05|wscrncmg|
|[f5d4eec833af09535b4fce414e03e015](https://www.virustotal.com/gui/file/f5d4eec833af09535b4fce414e03e015)|Win32 EXE|Symmi|2015-04-18 07:08:51|wssysnet|
|[d18ab4554263dad1a3741e67c4507bef](https://www.virustotal.com/gui/file/d18ab4554263dad1a3741e67c4507bef)|Win32 EXE|Symmi|2015-04-18 07:08:15|akhbare.exe|
|[be8bb23ea34e85c3ed35198483d527d1](https://www.virustotal.com/gui/file/be8bb23ea34e85c3ed35198483d527d1)|ZIP|Symmi|2015-04-18 07:07:36|akhbare.zip|
|[6e3dfe5cb86bdd2bfc5cab2daf9eee24](https://www.virustotal.com/gui/file/6e3dfe5cb86bdd2bfc5cab2daf9eee24)|Win32 EXE|DELF|2015-03-25 16:26:16|winitsvchost.exe|
|[05c49036da47e7684950dfd9799ab5fe](https://www.virustotal.com/gui/file/05c49036da47e7684950dfd9799ab5fe)|Win32 EXE|Delf|2015-03-04 00:08:29|Wninetsrvce|
|[f6f4e7d52bf254deb8d1e95b3e697dd8](https://www.virustotal.com/gui/file/f6f4e7d52bf254deb8d1e95b3e697dd8)|Win32 EXE|Delf|2015-01-16 16:37:58|wngtres|
|[bb0f507ff7d353c484ffdbba64d09b6f](https://www.virustotal.com/gui/file/bb0f507ff7d353c484ffdbba64d09b6f)|Win32 EXE|Delf|2015-01-15 07:27:55|winrecvry|
|[50e9a2ea0a557eb077b758bb9a05a609](https://www.virustotal.com/gui/file/50e9a2ea0a557eb077b758bb9a05a609)|Win32 EXE|Delf|2015-01-03 21:50:03|winfsmod|
|[41a6cbba98e12614cd880b6645ecb5a5](https://www.virustotal.com/gui/file/41a6cbba98e12614cd880b6645ecb5a5)|Win32 EXE||2014-12-24 14:07:33|winfsmod.exe|
|[25980bcd30c9ec4d8f245deabf3ce9c7](https://www.virustotal.com/gui/file/25980bcd30c9ec4d8f245deabf3ce9c7)|Win32 EXE|Delf|2014-12-12 09:58:34|winfsrcvry|
|[f05b5b9ca1b7dee39e1ef6a899609555](https://www.virustotal.com/gui/file/f05b5b9ca1b7dee39e1ef6a899609555)|ZIP|DELF|2014-11-17 22:29:06|VeenaInAction.avi.zip|
|[b2afcb37fc15878b5504910bded31049](https://www.virustotal.com/gui/file/b2afcb37fc15878b5504910bded31049)|Win32 EXE|Delf|2014-10-23 05:44:33|21b1621068ce5ddd44644d36cd46c7b15822f5f8|
|[361b1c948ec11de501012a75c5bbb60f](https://www.virustotal.com/gui/file/361b1c948ec11de501012a75c5bbb60f)|FPX|CVE-2012-0158|2014-10-22 21:40:56|vt-upload-_Jhma|
|[1483b5ac9a72706817bcb6eda02d91f5](https://www.virustotal.com/gui/file/1483b5ac9a72706817bcb6eda02d91f5)|Win32 EXE|Delf|2014-10-21 14:47:42|ais_samples (440).exe|
|[510f37f22905b98f5c56caf6bab98fd8](https://www.virustotal.com/gui/file/510f37f22905b98f5c56caf6bab98fd8)|Win32 EXE|Delf|2014-10-07 16:45:36|winhstrar|
|[0e670e833200c806a406967d400426dc](https://www.virustotal.com/gui/file/0e670e833200c806a406967d400426dc)|Win32 EXE|Delf|2014-10-07 16:33:36|0e670e833200c806a406967d400426dc|
|[ac49ba8d53aa343853bed1e97c9bcaa5](https://www.virustotal.com/gui/file/ac49ba8d53aa343853bed1e97c9bcaa5)|Win32 EXE|Delf|2014-10-06 08:34:53|winrvy|
|[3ce849b9fdd2ce7fe8b31f49c343deb7](https://www.virustotal.com/gui/file/3ce849b9fdd2ce7fe8b31f49c343deb7)|Win32 EXE|Delf|2014-08-19 23:16:50|mswinpro|
|[ead88ee7680ce76cd418803466c40cca](https://www.virustotal.com/gui/file/ead88ee7680ce76cd418803466c40cca)|Win32 EXE|Delf|2014-07-23 10:44:24|orea.exe|
|[7b557b9d1fcfbe4e04faad5a94d337e2](https://www.virustotal.com/gui/file/7b557b9d1fcfbe4e04faad5a94d337e2)|Win32 EXE|Delf|2014-03-07 23:08:15|avg.exe|
