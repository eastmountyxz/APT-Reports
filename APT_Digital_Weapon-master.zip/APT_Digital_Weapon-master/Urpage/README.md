**NAME:**  
Urpage  
  
**Description**:   
Urpage, named by Trend Micro, shares connection with Confucius, Patchwork, and Bahamut. 
It targets InPage, a word processor for Urdu and Arabic languages. Its Delphi backdoor component has in common with Confucius and Patchwork, and its apparent use of Bahamut-like malware makes it more intriguing as it connects Urpage to these other known threats. Related Android samples were captured as well.
  
**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/the-urpage-connection-to-bahamut-confucius-and-patchwork/