**NAME:**  
Thrip  

**Description**:   
Thrip, uncovered by Symantec, is an espionage group that has targeted satellite communications, telecoms, and defense contractor companies in the U.S. and Southeast Asia. It uses a mixture of custom malware and living off the land tools to perform attacks.
  
**References**:  
https://www.symantec.com/blogs/threat-intelligence/thrip-hits-satellite-telecoms-defense-targets