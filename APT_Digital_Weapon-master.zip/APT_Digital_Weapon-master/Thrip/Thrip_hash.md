|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4d2ee532a6d5abf2a9a8125f8d05d16b](https://www.virustotal.com/gui/file/4d2ee532a6d5abf2a9a8125f8d05d16b)|Win32 DLL|graftor|2019-05-07 02:19:29| |
|[579b88cfd43c4628855920abc120bcde](https://www.virustotal.com/gui/file/579b88cfd43c4628855920abc120bcde)|Win64 DLL|Kryptik|2019-04-30 20:41:20|579b88cfd43c4628855920abc120bcde.virus|
|[59545d3dcf49e230f419583779b705e6](https://www.virustotal.com/gui/file/59545d3dcf49e230f419583779b705e6)|Win64 DLL|Kryptik|2019-04-27 18:42:17| |
|[2731785bf7f5f839accec4278fa722e4](https://www.virustotal.com/gui/file/2731785bf7f5f839accec4278fa722e4)|Win32 DLL|Zbot|2019-04-25 07:47:22|d54de8e0dc2b58b140f8677be3f0ea3c902dc3f3b112c7350aa95a9cbe24a8af.sample|
|[93416de80483dbb6633c9fd473960099](https://www.virustotal.com/gui/file/93416de80483dbb6633c9fd473960099)|Win32 EXE||2019-03-24 00:01:24| |
|[6dcd5ba39cb2a3a3b66cc079acf563ef](https://www.virustotal.com/gui/file/6dcd5ba39cb2a3a3b66cc079acf563ef)|Win32 EXE||2019-03-07 02:53:10|shat.exe|
|[f7f252ae6fe54eb826d35c5e5a8b4c12](https://www.virustotal.com/gui/file/f7f252ae6fe54eb826d35c5e5a8b4c12)|Win32 EXE||2018-09-17 18:13:55|f7f252ae6fe54eb826d35c5e5a8b4c12-pe|
|[de6eb3d2439988be1c40714b2b825ace](https://www.virustotal.com/gui/file/de6eb3d2439988be1c40714b2b825ace)|Win64 DLL|razy|2018-08-12 05:38:26|C:\Users\evadmin\Documents\submit\batch 1\appmgmt_1.dll|
|[b07499a9e157bff01b592f373400fe1c](https://www.virustotal.com/gui/file/b07499a9e157bff01b592f373400fe1c)|Win32 EXE||2018-08-09 08:38:28|bd92ce8ef31cd40894b68338d9b71d371936b432b5347d944fad7d9381459761.exe|
|[c46a07a4dde2be5776a7640534f44bd6](https://www.virustotal.com/gui/file/c46a07a4dde2be5776a7640534f44bd6)|Win32 EXE||2018-07-15 19:26:17|95e6271e344264abee5cb142bb7c765cef467836923ea28b10d2f3eca21b92cb.bin|
|[3232ff20fb600768cadfe040792bbe5f](https://www.virustotal.com/gui/file/3232ff20fb600768cadfe040792bbe5f)|Win32 EXE||2018-07-11 02:14:33|6b01d376b355c56ede966ccf5cca6c8d5616962e67bbf0ddbf7ad395d117fdee.bin|
|[3a6712da8d50e5b5164fc02f9b49d0ed](https://www.virustotal.com/gui/file/3a6712da8d50e5b5164fc02f9b49d0ed)|Win32 EXE||2018-07-08 11:09:00| |
|[fea9f7ff95df34e7ee1859cc29c513c3](https://www.virustotal.com/gui/file/fea9f7ff95df34e7ee1859cc29c513c3)|Win32 DLL||2018-06-26 03:40:52|43309792ae8abb510a4cfe2c70f6e04de7170e66d8dde6945e6e050866d8816b.bin|
|[e71a0022bdc31d53e01766e183bbcf6b](https://www.virustotal.com/gui/file/e71a0022bdc31d53e01766e183bbcf6b)|Win32 EXE||2018-06-26 00:20:03|933ed68d0e4bbf9e_cuckoo-933ed68d0e4bbf9e3db0af6b4d54acf3685a9f22672703a67ce0818163f017ec.exe|
|[e9a7459c22b1e1a01c8cfd77683f6e37](https://www.virustotal.com/gui/file/e9a7459c22b1e1a01c8cfd77683f6e37)|Win32 EXE|Symmi|2018-06-23 01:54:50| |
|[e01396624aeaf79827f0a23e19f10190](https://www.virustotal.com/gui/file/e01396624aeaf79827f0a23e19f10190)|Win32 DLL|Zbot|2018-01-17 06:10:19|e01396624aeaf79827f0a23e19f10190.virobj|
|[e544a4d616b60147d9774b48c2b65ef2](https://www.virustotal.com/gui/file/e544a4d616b60147d9774b48c2b65ef2)|Win32 EXE||2018-01-15 11:59:38|e544a4d616b60147d9774b48c2b65ef2.virus|
|[e4d5e46b1b968ecbe8a9a00d3b36adb5](https://www.virustotal.com/gui/file/e4d5e46b1b968ecbe8a9a00d3b36adb5)|Win32 DLL||2017-12-21 12:28:53|1002-e00c4b19db4fea51242dcd1898ab623a2195ea91|
|[d937049b917e6014a792bec727efeb41](https://www.virustotal.com/gui/file/d937049b917e6014a792bec727efeb41)|Win32 DLL|Ursu|2017-12-21 07:19:54|dc86a82751b26f410b0aa1b7f0c019cc455d6c74fe40f02dfdad119e48915ec0.bin|
|[4ad36e16bc438ddda1cbdbf452d79fe9](https://www.virustotal.com/gui/file/4ad36e16bc438ddda1cbdbf452d79fe9)|Win32 EXE|tspy|2017-12-13 05:45:56|4ad36e16bc438ddda1cbdbf452d79fe9.virus|
|[04a14478380be82d87a2236185ff7001](https://www.virustotal.com/gui/file/04a14478380be82d87a2236185ff7001)|Win32 EXE||2017-10-19 08:41:50|780620521c92aab3d592b3dc149cbf58751ea285cfdaa50510002b441796b312.bin|
|[58a11a79f5a745c45d7b451373535950](https://www.virustotal.com/gui/file/58a11a79f5a745c45d7b451373535950)|Win32 DLL|Zbot|2017-10-17 02:19:19|sysinfo.dll|
|[a16b76461d676965535b91aabef85cfc](https://www.virustotal.com/gui/file/a16b76461d676965535b91aabef85cfc)|Win32 EXE||2017-09-15 10:51:21|a16b76461d676965535b91aabef85cfc.virus|
|[def5d0d5ec7131aaeae61764a0fea15b](https://www.virustotal.com/gui/file/def5d0d5ec7131aaeae61764a0fea15b)|Win32 DLL||2017-09-07 05:08:20|E:/vt/malware/20170910/def5d0d5ec7131aaeae61764a0fea15b.vir|
|[a36c3dc601b7b4d94c4a2100b2947d32](https://www.virustotal.com/gui/file/a36c3dc601b7b4d94c4a2100b2947d32)|Win32 EXE||2017-08-29 16:09:24|a36c3dc601b7b4d94c4a2100b2947d32|
|[09a40750c3333acb6b94062bdeb9380a](https://www.virustotal.com/gui/file/09a40750c3333acb6b94062bdeb9380a)|Win32 EXE||2017-08-21 14:38:48|09a40750c3333acb6b94062bdeb9380a.virus|
|[41cc3eb12a41e5b2e74034abed86bf22](https://www.virustotal.com/gui/file/41cc3eb12a41e5b2e74034abed86bf22)|Win32 DLL|Kryptik|2017-07-25 10:39:40|5f67e9d2523558c0fef56af470995b24ae7a3090|
|[8a324544c203fb2284282b5b634c6651](https://www.virustotal.com/gui/file/8a324544c203fb2284282b5b634c6651)|Win32 DLL|Banload|2017-07-05 03:16:41|knhi0p98ypo3bn489ht|
|[70d0c5434197529738b9e979247cb1e7](https://www.virustotal.com/gui/file/70d0c5434197529738b9e979247cb1e7)|Win32 DLL|Banload|2017-07-05 03:12:41|3rtji23498tyhfdjkgbihreiub3|
|[436fa7b75d50d12cf8b9e442e00f33c7](https://www.virustotal.com/gui/file/436fa7b75d50d12cf8b9e442e00f33c7)|Win32 EXE|Symmi|2017-02-10 10:22:57|436fa7b75d50d12cf8b9e442e00f33c7.virus|
|[807a16ed2f3ecc7df4fd121b9a0cc870](https://www.virustotal.com/gui/file/807a16ed2f3ecc7df4fd121b9a0cc870)|Win32 DLL||2016-11-09 02:00:24|ntmssvcc.dll|
|[f0fd91666ad932a98e913ec6bf35598b](https://www.virustotal.com/gui/file/f0fd91666ad932a98e913ec6bf35598b)|Win64 DLL|Kryptik|2016-11-02 10:18:50|scsidsc.dll|
|[4281e01020c9c786fc47b7983d70537a](https://www.virustotal.com/gui/file/4281e01020c9c786fc47b7983d70537a)|Win32 EXE|Virut|2016-10-15 09:27:34|a6ff8dfe654da70390cd71626cdca8a6f6a0d7980cd7d82269373737b04fd206.exe|
|[57471fb021938bf45c8a5d11b70b8920](https://www.virustotal.com/gui/file/57471fb021938bf45c8a5d11b70b8920)|Text||2016-10-06 06:59:36|Suspicious java script.js|
|[07f4d68ad87961dcef11e6f5f2246d1f](https://www.virustotal.com/gui/file/07f4d68ad87961dcef11e6f5f2246d1f)|Win32 EXE|tspy|2016-09-30 09:12:27|da48df19ea40c3687652a672e81856e995bb7a0b33948672e9572571efdfea91.bin|
|[4ab5c39b9ebb49e73281c3c0604b64b8](https://www.virustotal.com/gui/file/4ab5c39b9ebb49e73281c3c0604b64b8)|Win32 EXE|keylogger|2016-09-30 09:10:50|svchost|
|[bb992ba5a4b4a882a169a5583d26cb2b](https://www.virustotal.com/gui/file/bb992ba5a4b4a882a169a5583d26cb2b)|Win32 DLL|dynamer|2016-08-08 00:25:54|appdate.dll|
|[bc684adf6c514671f4751051faf6ff1b](https://www.virustotal.com/gui/file/bc684adf6c514671f4751051faf6ff1b)|Win32 DLL|graftor|2016-02-15 03:39:19|appinfo.dll.rename|
|[02c006f5170ce58c48e3cefddae2c6e8](https://www.virustotal.com/gui/file/02c006f5170ce58c48e3cefddae2c6e8)|Win32 DLL||2016-02-13 12:57:24| |
|[38631ce6e46a4f99372fd2d3e655bbe9](https://www.virustotal.com/gui/file/38631ce6e46a4f99372fd2d3e655bbe9)|Win32 EXE||2016-01-27 10:27:32|a036279e3c27f0e716b8fa4b5c7378805b9788c7ce3f4eada9367a4f0738967f.bin|
|[7c00854e0fb97824a856e8b5d602c7c2](https://www.virustotal.com/gui/file/7c00854e0fb97824a856e8b5d602c7c2)|Win32 EXE||2015-09-09 05:36:46|UsbGoOn|
|[d9ec3d956cbee17d1f6385b6d0a79574](https://www.virustotal.com/gui/file/d9ec3d956cbee17d1f6385b6d0a79574)|Win32 DLL||2015-08-24 02:51:22|w32svc.dll|
|[dda4874a73b57b8787dbc0009816a3d9](https://www.virustotal.com/gui/file/dda4874a73b57b8787dbc0009816a3d9)|Win32 DLL|Ursu|2015-08-05 16:37:51| |
|[705a646097ea58ccb7f4cacadd1d6465](https://www.virustotal.com/gui/file/705a646097ea58ccb7f4cacadd1d6465)|Win32 EXE||2015-08-05 16:36:05|m:\dailytesters\##\xxx\_unknown\973da52700fc100d836ce51be72f9ebd00f39e72ec654d618eef3b9b476c9c1b.exe|
|[2c92a5c8823dbe76c343a9006d63f789](https://www.virustotal.com/gui/file/2c92a5c8823dbe76c343a9006d63f789)|Win32 EXE|keylogger|2015-08-05 08:27:23|svchost|
|[9ceb9a0725f0386a67607bcee00ec93c](https://www.virustotal.com/gui/file/9ceb9a0725f0386a67607bcee00ec93c)|Win32 EXE||2015-07-28 18:00:55|32889639a27961497d53176765b3addf9fff27f1c8cc41634a365085d6d55920.bin|
|[5c23e2b75ad6e32cab66108af576683c](https://www.virustotal.com/gui/file/5c23e2b75ad6e32cab66108af576683c)|Win32 EXE||2015-07-27 18:25:12|fb387f959a6a6c1f_cuckoo-fb387f959a6a6c1f9fd58903f86ce2a25e4d4bbfdd33afc3b2c3776001f558bc.exe|
|[c4991d51f76b27604b0dbb2e9109dc36](https://www.virustotal.com/gui/file/c4991d51f76b27604b0dbb2e9109dc36)|Win32 DLL|Ursu|2015-07-27 00:15:49| |
|[9b743ed9318010860cf69a29530c8299](https://www.virustotal.com/gui/file/9b743ed9318010860cf69a29530c8299)|Win64 DLL||2015-05-20 06:34:14|mmbbbhub.dll|
|[92ad246f52b4e9f3be5bfd49f7521aee](https://www.virustotal.com/gui/file/92ad246f52b4e9f3be5bfd49f7521aee)|Win64 DLL|Cycbot|2015-05-01 09:06:56|d788a7083a83e9de32e66d9f5bf1c0bd691a8cb69a47021c2f9bc2de4c3b3a8a.bin|
|[ef7d71be46ec2e113b1d9a3c6eb4f7b1](https://www.virustotal.com/gui/file/ef7d71be46ec2e113b1d9a3c6eb4f7b1)|Win32 EXE||2015-04-28 09:04:07|svchost|
|[2283537dcfca24a73a0e9914de08d32a](https://www.virustotal.com/gui/file/2283537dcfca24a73a0e9914de08d32a)|Win32 DLL|ursu|2015-03-06 14:36:30|c:\windows\system32\mmbphdri.dll|
|[c37a017ecb592114f55022608d5bf2aa](https://www.virustotal.com/gui/file/c37a017ecb592114f55022608d5bf2aa)|Win32 DLL||2015-02-20 11:25:24|nsct.dat|
|[582f3ec32d06d38615ac1b86f786b266](https://www.virustotal.com/gui/file/582f3ec32d06d38615ac1b86f786b266)|Win32 EXE||2015-01-14 22:20:54|~Ne1.tmp|
|[d0b820e4dd2b02adfe2ec31d03a44d6b](https://www.virustotal.com/gui/file/d0b820e4dd2b02adfe2ec31d03a44d6b)|Win32 EXE|Symmi|2015-01-14 22:19:25|susp_dw20.exe|
|[c6ae3a18daceba808fae2c4bb3a7906e](https://www.virustotal.com/gui/file/c6ae3a18daceba808fae2c4bb3a7906e)|Win32 EXE|Symmi|2014-11-24 03:48:10|55555.exe|
|[f000e68175fad14b605ec70be581a2ff](https://www.virustotal.com/gui/file/f000e68175fad14b605ec70be581a2ff)|Win32 EXE||2014-11-05 20:17:43|f000e68175fad14b605ec70be581a2ff|
|[653483f36eab9a0d2fae9f9d3e0f53cc](https://www.virustotal.com/gui/file/653483f36eab9a0d2fae9f9d3e0f53cc)|Win32 EXE|keylogger|2014-11-05 06:39:18|svchost|
|[f854ba4d425ab2e2cded952e1db492b1](https://www.virustotal.com/gui/file/f854ba4d425ab2e2cded952e1db492b1)|Win32 EXE||2014-11-03 08:30:32|~Ne1.tmp|
|[6306b290df499cbc2b3bc49d74f01c43](https://www.virustotal.com/gui/file/6306b290df499cbc2b3bc49d74f01c43)|Win32 EXE||2014-11-03 08:28:21|eeb7003de4820a08f2f1c1e37635c73aa22a13e8|
|[2c96a5cb9694abaa51a8497a03bcb76f](https://www.virustotal.com/gui/file/2c96a5cb9694abaa51a8497a03bcb76f)|Win32 EXE||2014-11-03 08:27:56|4d7e96dcb71d6860ab055f8f99ee488eec252192|
|[599b14be0da29858cad69e64d252df85](https://www.virustotal.com/gui/file/599b14be0da29858cad69e64d252df85)|Win32 EXE||2014-11-01 06:52:34|~Ne1.tmp|
|[7d453ee9d0f85f2cfaf5ac243e259ad9](https://www.virustotal.com/gui/file/7d453ee9d0f85f2cfaf5ac243e259ad9)|Win32 EXE||2014-11-01 06:51:20|2|
|[83c220563c69e9e21551526f85add62b](https://www.virustotal.com/gui/file/83c220563c69e9e21551526f85add62b)|Win32 EXE||2014-10-28 16:23:14|83c220563c69e9e21551526f85add62b|
|[70857e02d60c66e27a173f8f292774f1](https://www.virustotal.com/gui/file/70857e02d60c66e27a173f8f292774f1)|Win64 EXE||2014-10-17 12:54:08|C:\Users\<USER>\AppData\Local\Temp\3582-490\8d97ec78b721c1c31ee5623358b06e98.exe|
|[d3c04f18d0355759caf84b3e952a216c](https://www.virustotal.com/gui/file/d3c04f18d0355759caf84b3e952a216c)|Win32 EXE||2014-10-12 10:03:41|7366829e9a7a0b169c55b123f53dd4a0c1884321|
|[7b38ab6dfccb481c4722d337a3ddb4f5](https://www.virustotal.com/gui/file/7b38ab6dfccb481c4722d337a3ddb4f5)|Win32 EXE||2014-10-10 20:35:39|7b38ab6dfccb481c4722d337a3ddb4f5|
|[5f550c8d11998ff7cd103da90efe2be7](https://www.virustotal.com/gui/file/5f550c8d11998ff7cd103da90efe2be7)|Win32 EXE|Symmi|2014-10-10 06:11:05|gupdate.exe|
|[2ed7009fa839a4632812791eb787652e](https://www.virustotal.com/gui/file/2ed7009fa839a4632812791eb787652e)|Win32 EXE||2014-09-28 09:16:40|vti-rescan|
|[0ae58a21d761e2f56446543678bb3f92](https://www.virustotal.com/gui/file/0ae58a21d761e2f56446543678bb3f92)|Win32 EXE||2014-09-10 04:06:20|gupdate.exe|
|[a4e5e165ad507e93d52262851eb04171](https://www.virustotal.com/gui/file/a4e5e165ad507e93d52262851eb04171)|Win32 EXE||2014-09-04 15:02:16|dw20.exe|
|[36b991e7af762ad47432a87101e386e9](https://www.virustotal.com/gui/file/36b991e7af762ad47432a87101e386e9)|Win32 EXE||2014-09-04 10:28:30|Untitled1|
|[e3d05f7c3992cd20d14356a161b7b1ac](https://www.virustotal.com/gui/file/e3d05f7c3992cd20d14356a161b7b1ac)|Win32 EXE||2014-09-03 09:36:59|gupdate.exe|
|[d21dd6e352d93e18d3fdaf6d10d19c0f](https://www.virustotal.com/gui/file/d21dd6e352d93e18d3fdaf6d10d19c0f)|Win32 EXE||2014-08-29 10:39:15|Irmon.sys|
|[f1bdb485d886df381589b47329e457a2](https://www.virustotal.com/gui/file/f1bdb485d886df381589b47329e457a2)|Win32 EXE||2014-08-26 00:31:52|vt-upload-rkiha|
|[f058ecc86731a573fe6341e589cc04f0](https://www.virustotal.com/gui/file/f058ecc86731a573fe6341e589cc04f0)|Win32 EXE||2014-08-25 20:40:58|def3190ea39f1125b00793e296d109992e1904e6|
|[150c800758eb5c1195fb465f5fd12c25](https://www.virustotal.com/gui/file/150c800758eb5c1195fb465f5fd12c25)|Win32 EXE||2014-07-07 02:46:59|4395f9af3218aba6fb775b5ff53c448cf6d4ebe1|
|[d9aa9cfb42ad8f8389929146048c244d](https://www.virustotal.com/gui/file/d9aa9cfb42ad8f8389929146048c244d)|Win32 EXE||2014-07-04 05:10:47|21a85fafa7ab9d9fe3252dfb5cd60fe97707da25bdec6abe9a1ab590756bba2d.bin|
|[a34813f8553ed0cd7997b81931c0fe4e](https://www.virustotal.com/gui/file/a34813f8553ed0cd7997b81931c0fe4e)|Win32 EXE||2014-07-04 05:10:36|vti-rescan|
|[8cc7cde40a51f2ca278419d9ba5a2298](https://www.virustotal.com/gui/file/8cc7cde40a51f2ca278419d9ba5a2298)|Win32 EXE||2014-06-02 10:19:56|svchost|
|[e13f1c1db60a8038af5b185752956a69](https://www.virustotal.com/gui/file/e13f1c1db60a8038af5b185752956a69)|Win32 EXE||2014-05-20 13:34:37|dw20.exe|
|[2cae3dd1fae239edfc38d705af2c8feb](https://www.virustotal.com/gui/file/2cae3dd1fae239edfc38d705af2c8feb)|Win32 DLL||2014-04-16 18:21:42|mmbzznai.dll|
|[846b46d462a438e50efb7f323cf7f5ff](https://www.virustotal.com/gui/file/846b46d462a438e50efb7f323cf7f5ff)|Win64 DLL|keylogger|2014-04-12 13:02:03|vti-rescan|
|[ef2fdf0d8e1192d283be2ef4f3efb84d](https://www.virustotal.com/gui/file/ef2fdf0d8e1192d283be2ef4f3efb84d)|Win32 EXE||2014-03-25 01:55:19|svchost|
|[5bae226ba7fbf5a5d7d7fa11a92a86c4](https://www.virustotal.com/gui/file/5bae226ba7fbf5a5d7d7fa11a92a86c4)|Win32 DLL|Symmi|2014-03-03 10:16:26|b036d456a3924f114c9e39c5cb254e11cb9a23a817275c7118d5e39cb834ef31.bin|
|[101271c84142adfd2920e950de682a2e](https://www.virustotal.com/gui/file/101271c84142adfd2920e950de682a2e)|Win32 EXE||2014-03-03 10:11:35|svchost|
|[c469b1010f348bd4a5bd5471ff388464](https://www.virustotal.com/gui/file/c469b1010f348bd4a5bd5471ff388464)|Win32 DLL||2014-02-06 15:02:24|CryptBase.dll|
|[9ce7cd5b997a293e6b46b4006444502e](https://www.virustotal.com/gui/file/9ce7cd5b997a293e6b46b4006444502e)|Win32 EXE|Zbot|2014-01-22 09:29:34|b5434effe88f06faf3882e949ab826a831f42ac863947a55b54f0ecf54c8a5cb|
|[c167abcc478268b47e0b098389b24a01](https://www.virustotal.com/gui/file/c167abcc478268b47e0b098389b24a01)|Win32 EXE|Zbot|2014-01-14 17:15:32|9e1343c5c6eead0f6b245748cf154d1558b6258c|
|[44efe6f78cf1606d74fbd5abbe66de5e](https://www.virustotal.com/gui/file/44efe6f78cf1606d74fbd5abbe66de5e)|Win32 EXE||2013-11-22 06:16:41|Irmon.sys|
|[9dfd87911ace5b24e2e0d82c618a1a66](https://www.virustotal.com/gui/file/9dfd87911ace5b24e2e0d82c618a1a66)|Win32 EXE|Zbot|2013-09-25 10:52:51|F34FEB7D4EC722F1B7B6187D511E505838E0D43B|
|[75b9466d0348b780266cd7a15ed5f3fd](https://www.virustotal.com/gui/file/75b9466d0348b780266cd7a15ed5f3fd)|Win32 DLL|Injecto|2013-07-25 07:31:41|vti-rescan|
|[5d0091a08e738fed70737d9e093b4ed1](https://www.virustotal.com/gui/file/5d0091a08e738fed70737d9e093b4ed1)|Win32 DLL||2013-06-26 13:42:17|991506de19f19e5440b941a0f0d13e254250e23bde3d464ccddd8f6d1b8bdfbb.bin|
|[93650189504b932f32198ad4966b49e3](https://www.virustotal.com/gui/file/93650189504b932f32198ad4966b49e3)|Win32 EXE|keylogger|2013-05-29 07:20:50|svchost|
|[b60ce366e142200e3191a1dffdf7283c](https://www.virustotal.com/gui/file/b60ce366e142200e3191a1dffdf7283c)|Win32 EXE||2013-05-24 16:32:02|b60ce366e142200e3191a1dffdf7283c|
|[9914a3331b8c8e312c7d0a5924eb7708](https://www.virustotal.com/gui/file/9914a3331b8c8e312c7d0a5924eb7708)|Win32 DLL|ursu|2013-05-20 19:53:01|vti-rescan|
|[7ee6a8cc75b5e8adf64af899fabd88a4](https://www.virustotal.com/gui/file/7ee6a8cc75b5e8adf64af899fabd88a4)|Win32 EXE|Symmi|2013-05-17 06:21:21|6efb12d11d2719bd8f5ca2a44ad418f703f4791b.exe|
|[1183a27b24c63dd318f143f9d2de4eb2](https://www.virustotal.com/gui/file/1183a27b24c63dd318f143f9d2de4eb2)|Win32 DLL|ursu|2013-05-09 08:26:07|vti-rescan|
|[4c434c0815c799f7d0c6d6d56fea5cd4](https://www.virustotal.com/gui/file/4c434c0815c799f7d0c6d6d56fea5cd4)|unknown||2013-03-18 19:56:19|2029d2de96162887593f0227ae27109aba5ac9090ad34be1b425f41091bd5b49.bin|
|[d6e03190c6408a7b229a328af55df8d8](https://www.virustotal.com/gui/file/d6e03190c6408a7b229a328af55df8d8)|Win32 DLL||2013-03-18 03:10:53|bits.dll|
|[49d78fe429381fbaf59fb5e39308417a](https://www.virustotal.com/gui/file/49d78fe429381fbaf59fb5e39308417a)|Win32 DLL||2013-03-13 13:27:55|\sonas\share\samples\49\d7\8f\e4\49d78fe429381fbaf59fb5e39308417a.cfe845f11091b07c90670138e83ac9269c3fe484|
|[884471168360b1f8a86bce7a08187171](https://www.virustotal.com/gui/file/884471168360b1f8a86bce7a08187171)|Win32 EXE||2013-01-08 00:20:59|svchost|
|[881fc631cf9e2633b8f42778b5c430dc](https://www.virustotal.com/gui/file/881fc631cf9e2633b8f42778b5c430dc)|Win64 DLL|dale|2012-12-26 06:46:42|myfile.exe|
|[759e153aa4a282077ca456145c1adaac](https://www.virustotal.com/gui/file/759e153aa4a282077ca456145c1adaac)|Win32 EXE||2010-09-27 00:49:09|759e153aa4a282077ca456145c1adaac_windows-kernel-exploits_MS10-048_ms10048_ms10048.exe|
