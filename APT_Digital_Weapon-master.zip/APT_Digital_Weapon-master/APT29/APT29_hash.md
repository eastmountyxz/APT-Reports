|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5dc4fced3eb731fffb88d0d2b17b1c83](https://www.virustotal.com/gui/file/5dc4fced3eb731fffb88d0d2b17b1c83)|Win32 DLL||2019-09-24 17:57:02|dttcodexgigas.81affba765aa87a0d0b12b5a213f09fd51e1e9a1|
|[d36351af2453640663bba20d365e5383](https://www.virustotal.com/gui/file/d36351af2453640663bba20d365e5383)|Win64 DLL||2019-09-24 17:57:00|dttcodexgigas.4975293c49ca223013088e51b8378e935322fe93|
|[aefd68ed5b4b672e72b5e00391fed9ed](https://www.virustotal.com/gui/file/aefd68ed5b4b672e72b5e00391fed9ed)|Win32 DLL||2019-09-24 17:56:55|dttcodexgigas.b2b2e5c5a6f8a07f051aab14fbec1f6607888b50|
|[46b48d2709edcc49114e45bf6d21e6ba](https://www.virustotal.com/gui/file/46b48d2709edcc49114e45bf6d21e6ba)|Win32 DLL||2019-09-24 17:45:07|dttcodexgigas.6b64ed0f4e39a1c320c7cbd342a93faed9f5df86|
|[6805c95e94feb35873412afdc6d0e540](https://www.virustotal.com/gui/file/6805c95e94feb35873412afdc6d0e540)|Win32 DLL||2019-09-24 17:45:06|6805c95e94feb35873412afdc6d0e540.virobj|
|[8719198899a009c8deb544b12d0cb35f](https://www.virustotal.com/gui/file/8719198899a009c8deb544b12d0cb35f)|Win64 DLL||2019-09-24 17:45:06|dttcodexgigas.feb9424386af47d550b13614c78530bc06ec876e|
|[5eb7edc915ab27deedf422e3f184c89a](https://www.virustotal.com/gui/file/5eb7edc915ab27deedf422e3f184c89a)|Win32 DLL||2019-09-24 17:43:45|dttcodexgigas.ba29768a2452a0e3abde02a903e53a181ee05bc8|
|[63523643e2040bf01dc0c312294feb80](https://www.virustotal.com/gui/file/63523643e2040bf01dc0c312294feb80)|Win32 DLL||2019-09-24 17:43:43|dttcodexgigas.3c8ba7ca3675ecc75855a58b9c0527d067c88f86|
|[b3a1d5dd34a2ebbf5a0e00aeb523c655](https://www.virustotal.com/gui/file/b3a1d5dd34a2ebbf5a0e00aeb523c655)|Win64 DLL||2019-09-24 17:43:42|dttcodexgigas.43a979aa6ab08685d9ce949c67e19bebbb3c3559|
|[d2d6093f0bd1ffdbc01ea7f1390a84b3](https://www.virustotal.com/gui/file/d2d6093f0bd1ffdbc01ea7f1390a84b3)|Win32 DLL||2019-09-24 17:42:07|dttcodexgigas.3f0be1751afa9cb0fdd6bc6fc9874dd880bc8c1b|
|[4df44ce045d2f4572b3b68b1ef0f9151](https://www.virustotal.com/gui/file/4df44ce045d2f4572b3b68b1ef0f9151)|Win64 DLL||2019-09-24 17:42:06|dttcodexgigas.034481acd945028f4521cf0eaa3685c6202f9e19|
|[da311c2005e7580c662d1911dbee49c0](https://www.virustotal.com/gui/file/da311c2005e7580c662d1911dbee49c0)|Win32 DLL||2019-09-24 17:38:00|dttcodexgigas.26d030c93c517d63147f502bf6536c3914698821|
|[3c8469d2c5af6ab277a6be483a1775f5](https://www.virustotal.com/gui/file/3c8469d2c5af6ab277a6be483a1775f5)|Win64 DLL||2019-09-24 17:37:59|dttcodexgigas.d89fc09f1aa72547d4b7f022470b6c8362997a5f|
|[56729e5170a93a4c790c707284ba05df](https://www.virustotal.com/gui/file/56729e5170a93a4c790c707284ba05df)|Win32 DLL||2019-09-24 17:37:57|dttcodexgigas.efd41300ccf4143d04664715e1de98cb416ffdd1|
|[a0170807b9dc06589628c0e8db8dd669](https://www.virustotal.com/gui/file/a0170807b9dc06589628c0e8db8dd669)|Win32 DLL||2019-09-24 16:30:54|dttcodexgigas.1e02eea130d17b9afb712d846612ab8bd6972183|
|[cbf96820dc74a50a91b2b8b94376682a](https://www.virustotal.com/gui/file/cbf96820dc74a50a91b2b8b94376682a)|PNG||2019-06-06 18:09:46|sample_B_stage2.png|
|[ad6723f61e10aefd9688b29b474a9323](https://www.virustotal.com/gui/file/ad6723f61e10aefd9688b29b474a9323)|Win32 DLL||2019-06-04 14:40:41|fywhx.dll|
|[ae997d2047705ff46a0c228f7b5d7052](https://www.virustotal.com/gui/file/ae997d2047705ff46a0c228f7b5d7052)|Win32 DLL||2019-06-04 04:44:40|sample_A_stage1.dll|
|[16bbc967a8b6a365871a05c74a4f345b](https://www.virustotal.com/gui/file/16bbc967a8b6a365871a05c74a4f345b)|Win64 DLL|CobaltStrike|2018-11-14 20:32:27|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/Nov2018New!/AudioSes.dll|
|[6ed0020b0851fb71d5b0076f4ee95f3c](https://www.virustotal.com/gui/file/6ed0020b0851fb71d5b0076f4ee95f3c)|LNK||2018-11-14 18:03:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/Nov2018New!/ds7002.bin|
|[3fccf531ff0ae6fedd7c586774b17a2d](https://www.virustotal.com/gui/file/3fccf531ff0ae6fedd7c586774b17a2d)|ZIP||2018-11-14 11:53:18|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/Nov2018New!/ds7001.zip|
|[658c6fe38f95995fa8dc8f6cfe41df7b](https://www.virustotal.com/gui/file/658c6fe38f95995fa8dc8f6cfe41df7b)|ZIP||2018-11-14 10:33:29|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/Nov2018New!/ds7002.zip|
|[313f4808aa2a2073005d219bc68971cd](https://www.virustotal.com/gui/file/313f4808aa2a2073005d219bc68971cd)|PDF||2018-11-14 09:00:00|ds7002.PDF|
|[f08ef840f59cbd4c4695e36ef3eaa9d7](https://www.virustotal.com/gui/file/f08ef840f59cbd4c4695e36ef3eaa9d7)|Win32 DLL||2018-10-28 17:18:50|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/APT29miniduke.bin|
|[3fc589ca4ae8b838f4eb1a41d4da4037](https://www.virustotal.com/gui/file/3fc589ca4ae8b838f4eb1a41d4da4037)|XLS||2018-10-03 12:47:11|XLSTAT.xla|
|[887489b27f6e7053ec2702dc8ba51af7](https://www.virustotal.com/gui/file/887489b27f6e7053ec2702dc8ba51af7)|Win32 DLL||2018-09-22 11:11:26|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/MinidukeAPT29.bin|
|[f0bf570b9cc055c7c7b8a77573264917](https://www.virustotal.com/gui/file/f0bf570b9cc055c7c7b8a77573264917)|Win32 DLL||2018-06-07 06:51:08|f0bf570b9cc055c7c7b8a77573264917.vir|
|[b37eefd5c8433a91827904483ccb926e](https://www.virustotal.com/gui/file/b37eefd5c8433a91827904483ccb926e)|Win64 DLL||2018-05-29 22:07:35|C:\Samples\021916\b37eefd5c8433a91827904483ccb926e|
|[452ee2968ec82c7e30c21c828b330c17](https://www.virustotal.com/gui/file/452ee2968ec82c7e30c21c828b330c17)|Win32 DLL|Zbot|2018-05-22 09:15:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/atiagentCozyBear.bin|
|[6bc34809e44c40b61dd29e0a387ee682](https://www.virustotal.com/gui/file/6bc34809e44c40b61dd29e0a387ee682)|Win32 EXE|razy|2018-05-07 18:26:09|/home/virustotal/sample/6BC34809E44C40B61DD29E0A387EE682|
|[53db085a276ebbf5798ba756cac833ea](https://www.virustotal.com/gui/file/53db085a276ebbf5798ba756cac833ea)|Win32 EXE||2018-05-07 17:30:17|/home/virustotal/sample/53DB085A276EBBF5798BA756CAC833EA|
|[8ddef83c57a5a752b20e3f98209acba4](https://www.virustotal.com/gui/file/8ddef83c57a5a752b20e3f98209acba4)|PDF||2017-10-23 09:06:10|APT29 Domain Fronting With TOR  Threat Research Blog _ FireEye Inc.pdf|
|[b58fb3e7a7fd225e0059d19f33b9b3d5](https://www.virustotal.com/gui/file/b58fb3e7a7fd225e0059d19f33b9b3d5)|Win64 DLL||2017-05-05 17:16:49|b58fb3e7a7fd225e0059d19f33b9b3d5.virus|
|[5e71474f388841e71563a66ee98e9bd0](https://www.virustotal.com/gui/file/5e71474f388841e71563a66ee98e9bd0)|Win32 DLL||2017-05-05 17:11:04|5e71474f388841e71563a66ee98e9bd0.virobj|
|[3f0c8c18b46d54ac587d14e3a1704957](https://www.virustotal.com/gui/file/3f0c8c18b46d54ac587d14e3a1704957)|Win32 DLL||2017-05-05 17:10:50|3f0c8c18b46d54ac587d14e3a1704957.virus|
|[4ef778dd915947de6b739c087060c404](https://www.virustotal.com/gui/file/4ef778dd915947de6b739c087060c404)|Win64 DLL|razy|2017-05-05 16:45:17|4ef778dd915947de6b739c087060c404.virus|
|[fc6772572b884a849baf100e7faf2e00](https://www.virustotal.com/gui/file/fc6772572b884a849baf100e7faf2e00)|Win32 DLL||2017-05-05 16:36:40|fc6772572b884a849baf100e7faf2e00.virobj|
|[0da4d68dc1715558bf84193354e51800](https://www.virustotal.com/gui/file/0da4d68dc1715558bf84193354e51800)|Win32 DLL||2017-05-05 16:30:46|0da4d68dc1715558bf84193354e51800.virobj|
|[bff64b84d72d2aa56d3c3596b34805ad](https://www.virustotal.com/gui/file/bff64b84d72d2aa56d3c3596b34805ad)|Win64 DLL||2017-02-25 13:20:25| |
|[a1859bdc5d68be03e174b45ce8da46bf](https://www.virustotal.com/gui/file/a1859bdc5d68be03e174b45ce8da46bf)|Win32 DLL||2017-02-25 08:55:14|a1859bdc5d68be03e174b45ce8da46bf.virus|
|[ae7e3e531494b201fbf6021066ddd188](https://www.virustotal.com/gui/file/ae7e3e531494b201fbf6021066ddd188)|Win32 DLL||2016-12-29 19:06:15|ae7e3e531494b201fbf6021066ddd188.dll_SayWhatBackdoor|
|[8f154d23ac2071d7f179959aaba37ad5](https://www.virustotal.com/gui/file/8f154d23ac2071d7f179959aaba37ad5)|Win32 DLL||2016-12-29 19:03:11|/home/vega/CONTAGIO/apt/APT29/APT29_2016-12_Chris_Grizzly SteppeLighting up Like A Christmas Tree/8f154d23ac2071d7f179959aaba37ad5.dll_SayWhatBackdoor|
|[57c627d68e156676d08bfc0829b94331](https://www.virustotal.com/gui/file/57c627d68e156676d08bfc0829b94331)|Win32 DLL||2016-11-20 22:00:33|/home/vega/CONTAGIO/apt/APT29/APT29_2016-11_Volexity_PowerDukePostElection/Samples/4BCBF078A78BA0E842F78963BA9DD71240AB6A6D_cldsys.dll_|
|[3335f0461e5472803f4b19b706eaf4b5](https://www.virustotal.com/gui/file/3335f0461e5472803f4b19b706eaf4b5)|Win32 EXE||2016-11-09 19:01:38|5CC807F80F14BC4A1D6036865E50D576200DFD2E_RWP16-038_Norris.exe_|
|[f713d5df826c6051e65f995e57d6817d](https://www.virustotal.com/gui/file/f713d5df826c6051e65f995e57d6817d)|LNK||2016-11-09 17:58:18|2d2fa32f928f8abf31b9e79153422d65fe72cd5ad0d1f815a9d2ffa42fc8d224.bin|
|[8b3050a95e3ce00424b85f6e9cc3ccec](https://www.virustotal.com/gui/file/8b3050a95e3ce00424b85f6e9cc3ccec)|ZIP|phishing|2016-11-09 17:28:02|D5DCF445830C54AF145C0DFEAEBF28F8EC780EB5_RWP_16-038_Norris.ZIP_|
|[f79caf27a99c091e6c1775b306993341](https://www.virustotal.com/gui/file/f79caf27a99c091e6c1775b306993341)|ZIP|phishing|2016-11-09 17:08:07|A76C02C067EAE26D78F4B494274DFA6AEDC6FA7A_37486.ZIP_|
|[a8e700492e113f73558131d94bc9ae2f](https://www.virustotal.com/gui/file/a8e700492e113f73558131d94bc9ae2f)|FPX||2016-11-09 16:14:57|B5684384C8028F0324ED7119F6ABF379F2789970_election-headlines-FTE2016.docm_|
|[7fce89d5e3d59d8e849d55d604b70a6f](https://www.virustotal.com/gui/file/7fce89d5e3d59d8e849d55d604b70a6f)|PHP|Kryptik|2016-09-20 14:14:56|default.php|
|[81f1af277010cb78755f08dfcc379ca6](https://www.virustotal.com/gui/file/81f1af277010cb78755f08dfcc379ca6)|RTF|razy|2016-07-02 19:55:09|81F1AF277010CB78755F08DFCC379CA6_ fhyge.rtf_|
|[ba57f95eba99722ebdeae433fc168d72](https://www.virustotal.com/gui/file/ba57f95eba99722ebdeae433fc168d72)|Win32 EXE||2016-06-30 16:06:04|/home/vega/CONTAGIO/apt/APT29/APT29_2014-07_Kaspersky_Miniduke is back_Nemesis Gemina and the Botgen Studio/86EC70C27E5346700714DBAE2F10E168A08210E4|
|[ce227ae503e166b77bf46b6c8f5ee4da](https://www.virustotal.com/gui/file/ce227ae503e166b77bf46b6c8f5ee4da)|Win32 EXE||2016-06-21 17:09:00|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/CozyBearImplant.bin|
|[fdc96d77af6fdae487002e32d61df123](https://www.virustotal.com/gui/file/fdc96d77af6fdae487002e32d61df123)|Win32 DLL|razy|2016-05-15 17:01:42|fdc96d77af6fdae487002e32d61df123.virus|
|[617ba99be8a7d0771628344d209e9d8a](https://www.virustotal.com/gui/file/617ba99be8a7d0771628344d209e9d8a)|Win32 EXE|Fareit|2016-04-18 20:07:14|Star Polk.exe|
|[a9c045c401afb9766e2ca838dc6f47a4](https://www.virustotal.com/gui/file/a9c045c401afb9766e2ca838dc6f47a4)|Win32 EXE|Satan|2015-08-03 20:56:30|m:\dailytesters\vl\A\A51A3D1C7DF9EC3F49CBEBAB0CA35283\d3d503934c0dfe75e386d0fb8da2e32238d93739624b6c5a929fe5b722b35d36.exe|
|[4f148ffeac50df60f9f9015b909d8ed0](https://www.virustotal.com/gui/file/4f148ffeac50df60f9f9015b909d8ed0)|Win32 EXE|Satan|2015-07-29 20:25:29|reader.exe|
|[964e4b516d72b7717aabb71ad7cc7bf6](https://www.virustotal.com/gui/file/964e4b516d72b7717aabb71ad7cc7bf6)|Win32 EXE|Satan|2015-07-22 16:09:12|oracle.exe|
|[719cf63a3922953ceaca6fb4dbed6584](https://www.virustotal.com/gui/file/719cf63a3922953ceaca6fb4dbed6584)|Win32 DLL||2015-07-22 14:57:15|dnlibsh.dll|
|[07660a9b83b7fbc7ab372a911c69a85b](https://www.virustotal.com/gui/file/07660a9b83b7fbc7ab372a911c69a85b)|Win32 EXE|Satan|2015-07-22 03:23:35|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/2F53BFCD2016D506674D0A05852318F9E8188EE1|
|[b8690064dc61333c591252c4204fbbb3](https://www.virustotal.com/gui/file/b8690064dc61333c591252c4204fbbb3)|Win32 EXE|Satan|2015-07-21 20:03:55|B8690064DC61333C591252C4204FBBB3|
|[e163d9a91f97f133b0e3f2bbe4dc226a](https://www.virustotal.com/gui/file/e163d9a91f97f133b0e3f2bbe4dc226a)|Win32 EXE|Satan|2015-07-21 20:00:50|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/C16529DBC2987BE3AC628B9B413106E5749999ED|
|[a4f3e00b3da3e9d9382840dfbdbef311](https://www.virustotal.com/gui/file/a4f3e00b3da3e9d9382840dfbdbef311)|Win32 EXE|Satan|2015-07-21 17:13:26|5442.exe|
|[27f3d0556c59e32791567a09236507d9](https://www.virustotal.com/gui/file/27f3d0556c59e32791567a09236507d9)|ZIP|Satan|2015-07-21 17:12:45|5442.ZIP|
|[72512c49401bd3d04a8ef6c7a6475307](https://www.virustotal.com/gui/file/72512c49401bd3d04a8ef6c7a6475307)|Win32 EXE|Satan|2015-07-21 16:08:02|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/52D44E936388B77A0AFDB21B099CF83ED6CBAA6F|
|[50bf9c6de53b7de6906c2d5ed6177c28](https://www.virustotal.com/gui/file/50bf9c6de53b7de6906c2d5ed6177c28)|Win32 EXE|Satan|2015-07-21 14:37:17|6a3c2ad9919ad09ef6cdffc80940286814a0aa2c.codex|
|[e268e5c53da8361d4f7b6a884d7dfc8a](https://www.virustotal.com/gui/file/e268e5c53da8361d4f7b6a884d7dfc8a)|ZIP|Satan|2015-07-21 14:35:18|5442.ZIP|
|[8c9113aec4d0585f2744e2027ef8a03d](https://www.virustotal.com/gui/file/8c9113aec4d0585f2744e2027ef8a03d)|PDF||2015-07-21 13:48:13|5442.pdf|
|[ffb407dc2b20357302a4550a73f6c342](https://www.virustotal.com/gui/file/ffb407dc2b20357302a4550a73f6c342)|Win32 EXE|Satan|2015-07-21 13:48:11|acrotray.exe|
|[bfd2d6bf8e99332157a0fe46a4a91c52](https://www.virustotal.com/gui/file/bfd2d6bf8e99332157a0fe46a4a91c52)|Win32 EXE|Satan|2015-07-21 12:53:57|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/04299C0B549D4A46154E0A754DDA2BC9E43DFF76|
|[f338e21422eca3a52239089f821519d6](https://www.virustotal.com/gui/file/f338e21422eca3a52239089f821519d6)|ZIP|Satan|2015-07-21 12:53:25|dea20c241265e2995244187c8476570893df41b9623784a4ca6ed075721b8cdf.bin.exe|
|[97886672cc570ba4a5d6a162e92d0155](https://www.virustotal.com/gui/file/97886672cc570ba4a5d6a162e92d0155)|Win32 EXE|Satan|2015-07-16 13:26:25|_01110000.exe|
|[b0a9a175e2407352214b2d005253bc0c](https://www.virustotal.com/gui/file/b0a9a175e2407352214b2d005253bc0c)|Win32 EXE|Satan|2015-07-15 16:23:47|6c8eb3365b7fb7683b9b465817e5cb87574026e306c700f3d103eba056777720 (1)|
|[22a46be630c877e2885c51147de10863](https://www.virustotal.com/gui/file/22a46be630c877e2885c51147de10863)|Win32 EXE||2015-07-14 19:17:42|10|
|[51ea28f4f3fa794d5b207475897b1eef](https://www.virustotal.com/gui/file/51ea28f4f3fa794d5b207475897b1eef)|Win32 EXE||2015-07-10 06:19:47|/home/vega/CONTAGIO/apt/APT29/APT29_2015-07_PaloAlto_Tracking_MiniDionis/9EEF49FC724B9F40BE795A80BC6363EB0C6B6DD6|
|[42ffc84c6381a18b1f6d000b94c74b09](https://www.virustotal.com/gui/file/42ffc84c6381a18b1f6d000b94c74b09)|Win32 EXE|Satan|2015-07-09 20:12:47|TimbuktuDaemon.exe|
|[e00bf9b8261410744c10ae3fe2ce9049](https://www.virustotal.com/gui/file/e00bf9b8261410744c10ae3fe2ce9049)|Win32 EXE|Satan|2015-07-09 12:48:52|player.exe|
|[98613ecb3afde5fc48ca4204f8363f1d](https://www.virustotal.com/gui/file/98613ecb3afde5fc48ca4204f8363f1d)|Win32 EXE|Satan|2015-07-09 02:37:25|voicemail5220148331536798976.exe|
|[4d3a94134aaf590ae8ece0a57257e129](https://www.virustotal.com/gui/file/4d3a94134aaf590ae8ece0a57257e129)|Win32 EXE|Satan|2015-07-09 01:45:08|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/DEA6E89E36CF5A4A216E324983CC0B8F6C58EAA8|
|[9018fa0826f237342471895f315dbf39](https://www.virustotal.com/gui/file/9018fa0826f237342471895f315dbf39)|Win32 EXE|Satan|2015-07-09 01:37:13|adobe.exe|
|[837b522730ff896435682b36f7b27a3e](https://www.virustotal.com/gui/file/837b522730ff896435682b36f7b27a3e)|Win32 EXE|Satan|2015-07-08 22:13:44|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CloudDuke/BFE26837DA22F21451F0416AA9D241F98FF1C0F8|
|[3a04a5d7ed785daa16f4ebfd3acf0867](https://www.virustotal.com/gui/file/3a04a5d7ed785daa16f4ebfd3acf0867)|Win32 EXE|Satan|2015-07-08 22:10:41|/home/vega/CONTAGIO/apt/APT29/APT29_2015-07_PaloAlto_Tracking_MiniDionis/10B31A17449705BE20890DDD8AD97A2FEB093674|
|[856b224da7525ea5192efbef7a9b8112](https://www.virustotal.com/gui/file/856b224da7525ea5192efbef7a9b8112)|Win32 EXE|Satan|2015-07-08 20:14:16|eekas.exe|
|[70f5574e4e7ad360f4f5c2117a7a1ca7](https://www.virustotal.com/gui/file/70f5574e4e7ad360f4f5c2117a7a1ca7)|Win32 EXE|Satan|2015-07-08 20:10:00|player.exe|
|[4cbd9a0832dcf23867b092de37c10d9d](https://www.virustotal.com/gui/file/4cbd9a0832dcf23867b092de37c10d9d)|Win32 EXE|dynamer|2015-07-08 17:43:56|NDI Georgia_April 2015 Poll_Public Issues_ENG_VF_0.exe|
|[e07ef8ffe965ec8b72041ddf9527cac4](https://www.virustotal.com/gui/file/e07ef8ffe965ec8b72041ddf9527cac4)|Win32 EXE|Satan|2015-07-08 15:37:54|242021.exe|
|[030da7510113c28ee68df8a19c643bb0](https://www.virustotal.com/gui/file/030da7510113c28ee68df8a19c643bb0)|Win32 EXE|Satan|2015-07-08 12:17:22|/home/vega/CONTAGIO/apt/APT29/APT29_2015-07_PaloAlto_Tracking_MiniDionis/4F977DEBAA25925E82F254080E8F7C42B70CB669|
|[8473fae7fdae7ee5a8b0fb64ebb596c1](https://www.virustotal.com/gui/file/8473fae7fdae7ee5a8b0fb64ebb596c1)|Win32 EXE|Satan|2015-07-08 11:55:53|readerView.exe|
|[3195110045f64a3c83fc3e043c46d253](https://www.virustotal.com/gui/file/3195110045f64a3c83fc3e043c46d253)|Win32 EXE|Satan|2015-07-08 11:33:34|/home/vega/CONTAGIO/apt/APT29/APT29_2015-07_PaloAlto_Tracking_MiniDionis/D7F7AEF824265136AD077AE4F874D265AE45A6B0|
|[c8b49b42e6ebb6b977ce7001b6bd96c8](https://www.virustotal.com/gui/file/c8b49b42e6ebb6b977ce7001b6bd96c8)|Win32 EXE|Satan|2015-07-08 11:30:32|DRAFT_AGENDA.exe|
|[0f9534b63cb7af1e3aa34839d7d6e632](https://www.virustotal.com/gui/file/0f9534b63cb7af1e3aa34839d7d6e632)|Win32 EXE|Satan|2015-07-08 08:01:08|890B943BA5C43B74AD2965874A21C7EF4BA896FF.bak|
|[2e64131c0426a18c1c363ec69ae6b5f2](https://www.virustotal.com/gui/file/2e64131c0426a18c1c363ec69ae6b5f2)|Win32 EXE|Satan|2015-07-08 02:04:46|6c95cdbe7d3c65104abd0912aa7dc99099887030.codex|
|[5fa3c3dabb8edd601302d9cf02db899d](https://www.virustotal.com/gui/file/5fa3c3dabb8edd601302d9cf02db899d)|Win64 DLL||2015-07-05 17:46:34|4a16674c799fae6535c82f878f6a37f94ee9a49b.codex|
|[9e3f3b5e9ece79102d257e8cf982e09e](https://www.virustotal.com/gui/file/9e3f3b5e9ece79102d257e8cf982e09e)|Win32 DLL||2015-06-28 10:13:56|9E3F3B5E9ECE79102D257E8CF982E09E_Cache.dl_|
|[84137c8e7509a0e9cf7ff71ba060cdb5](https://www.virustotal.com/gui/file/84137c8e7509a0e9cf7ff71ba060cdb5)|DOCX||2015-06-12 09:29:51|F1F1ACE3906080CEF52CA4948185B665D1D7B13E_RD RCB 11.06.docx_|
|[9e3c39aaa240da8c7002924170019f78](https://www.virustotal.com/gui/file/9e3c39aaa240da8c7002924170019f78)|Win32 DLL||2015-06-07 17:35:53| |
|[2337a4fa99547eb0cf7600601ab44dda](https://www.virustotal.com/gui/file/2337a4fa99547eb0cf7600601ab44dda)|Win32 EXE|CosmicDuke|2015-05-27 16:29:08|chrome_exe|
|[5dabff44971cc53bef7d8e17e85dda73](https://www.virustotal.com/gui/file/5dabff44971cc53bef7d8e17e85dda73)|Win32 EXE|CosmicDuke|2015-05-27 14:50:13|chrome_exe|
|[18edd6bc785e56990f6721cd553c24ad](https://www.virustotal.com/gui/file/18edd6bc785e56990f6721cd553c24ad)|Win32 EXE|CosmicDuke|2015-05-27 06:40:20|chrome_exe|
|[6f535a0f5c7f710ec4739e52f35a5673](https://www.virustotal.com/gui/file/6f535a0f5c7f710ec4739e52f35a5673)|Win32 EXE|Zbot|2015-05-25 20:02:49|95f8e91fb2059954866e52459cb88f5ff7b2aea590fce587e51f1140222ef27f.bin|
|[5eabc9c54b73fffb5f3fddb37a653d7b](https://www.virustotal.com/gui/file/5eabc9c54b73fffb5f3fddb37a653d7b)|Win32 EXE|Zbot|2015-05-25 20:02:44|5ffe420a3cc848024884db8e2cfed68c47368dae.codex|
|[8019dea970331823a504baaa90d3470f](https://www.virustotal.com/gui/file/8019dea970331823a504baaa90d3470f)|Win32 EXE||2015-05-20 15:07:57|AMD Chipset Support|
|[a4008cf300fd22f470c38489da9e25cf](https://www.virustotal.com/gui/file/a4008cf300fd22f470c38489da9e25cf)|Win32 EXE||2015-05-02 07:31:16|AMD Chipset Support|
|[612fba96383a5098c26fe1a222e1e755](https://www.virustotal.com/gui/file/612fba96383a5098c26fe1a222e1e755)|Win32 DLL|kazy|2015-05-01 19:48:01| |
|[8d3542af992b1de4cf1f587f61dddb50](https://www.virustotal.com/gui/file/8d3542af992b1de4cf1f587f61dddb50)|Win32 DLL|kazy|2015-05-01 19:43:05| |
|[74593127f50abff5327b3f7038b456d2](https://www.virustotal.com/gui/file/74593127f50abff5327b3f7038b456d2)|Win32 DLL|kazy|2015-05-01 19:31:32| |
|[423bb8914078a587d08b54d16bbd527c](https://www.virustotal.com/gui/file/423bb8914078a587d08b54d16bbd527c)|Win32 DLL|kazy|2015-05-01 19:20:38|/home/vega/CONTAGIO/apt/APT29/APT29_2013-04_Bitdefender_A Closer Look at MiniDuke/2012/c13794601c5bdec3d5d76de9571e6c0e0b022b9fc62907018566895e3b949982|
|[3a2ba475bf6a60dbe3ed59330c53c3f7](https://www.virustotal.com/gui/file/3a2ba475bf6a60dbe3ed59330c53c3f7)|Win32 EXE|CosmicDuke|2015-05-01 18:05:20|Adobe Acrobat Updater|
|[23273a83bfd7aed10b9403e23a8bcba9](https://www.virustotal.com/gui/file/23273a83bfd7aed10b9403e23a8bcba9)|Win32 EXE||2015-04-30 00:12:38|ClientUI.exe|
|[45d6515ebb7f57404b8703f1e77a461a](https://www.virustotal.com/gui/file/45d6515ebb7f57404b8703f1e77a461a)|Win64 DLL||2015-04-23 13:32:07|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/8BA7932A40008881A4ED975F52271C0B679EAFF2|
|[209a4a102a977b698544c99d8236e9ca](https://www.virustotal.com/gui/file/209a4a102a977b698544c99d8236e9ca)|Win32 DLL||2015-04-23 13:32:07|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/E0779AC6E5CC76E91FCA71EFEADE2A5D7F099C80|
|[52474b705610245f67bbd1c86ab8bd7b](https://www.virustotal.com/gui/file/52474b705610245f67bbd1c86ab8bd7b)|Win32 DLL|Zbot|2015-04-23 13:32:06|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/29A91E7823046F4EC3FD6B3FD1B442EAA92F3565|
|[864bb9137f6bf94e59fbaa9b21065d1e](https://www.virustotal.com/gui/file/864bb9137f6bf94e59fbaa9b21065d1e)|Win32 DLL||2015-04-23 12:47:05|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/B5E973DF0A159AB583FC8923C796C8CBF5B535DF|
|[10b852b9f669aa6ec60bc838dbee6de3](https://www.virustotal.com/gui/file/10b852b9f669aa6ec60bc838dbee6de3)|Win64 DLL||2015-04-23 12:47:05|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/C62E840FFE4BBA50F6584B33A877475F0EBCF558|
|[f2b05e6b01be3b6cb14e9068e7a66fc1](https://www.virustotal.com/gui/file/f2b05e6b01be3b6cb14e9068e7a66fc1)|Win32 EXE||2015-04-21 22:41:57|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/B65AA8590A1BAC52A85DBD1EA091FC586F6AB00A|
|[e315436c42e681962a8e174ef7fad480](https://www.virustotal.com/gui/file/e315436c42e681962a8e174ef7fad480)|Win32 EXE||2015-04-21 22:41:55|SearchFilterHost.exe|
|[a25ec7749b2de12c2a86167afa88a4dd](https://www.virustotal.com/gui/file/a25ec7749b2de12c2a86167afa88a4dd)|Win32 EXE||2015-04-21 22:41:36|LogonUI.exe|
|[5080bc705217c614b9cbf67a679979a8](https://www.virustotal.com/gui/file/5080bc705217c614b9cbf67a679979a8)|Win32 EXE||2015-04-20 15:57:59|mdm.exe|
|[69cab1853df0749d42b68bf41d78e655](https://www.virustotal.com/gui/file/69cab1853df0749d42b68bf41d78e655)|Win64 DLL||2015-04-19 06:33:36| |
|[f81f858335b253d4708fbdfa6ca92ee9](https://www.virustotal.com/gui/file/f81f858335b253d4708fbdfa6ca92ee9)|DOCX||2015-04-15 12:35:16|owe szczegóły katastrofy polskiego samol otu.doc|
|[335160cad23e28d4597c1546458042c4](https://www.virustotal.com/gui/file/335160cad23e28d4597c1546458042c4)|DOCX||2015-04-15 05:39:45|18|
|[823760d749db5f3f28c7d9366acd0f64](https://www.virustotal.com/gui/file/823760d749db5f3f28c7d9366acd0f64)|Win32 EXE|Zbot|2015-04-13 16:49:11|C6.tmp|
|[14d779777af6eb7c556ae338b462c48d](https://www.virustotal.com/gui/file/14d779777af6eb7c556ae338b462c48d)|Win32 EXE||2015-04-10 22:50:08|B9EA2CC39808780ADE1FE51287072E958448BE7E3A7B32BFD48438453592018C.dat|
|[d3109c83e07dd5d7fe032dc80c581d08](https://www.virustotal.com/gui/file/d3109c83e07dd5d7fe032dc80c581d08)|Win32 EXE||2015-04-08 17:12:25|WerMgr|
|[51a96f279e790d2f861bb0ff843a7328](https://www.virustotal.com/gui/file/51a96f279e790d2f861bb0ff843a7328)|Win32 EXE|scar|2015-03-27 22:12:57|Intel NGO|
|[bd52b2a371ff397c90b891b7a4f04c66](https://www.virustotal.com/gui/file/bd52b2a371ff397c90b891b7a4f04c66)|Win32 DLL||2015-03-24 11:20:45|R:\Malware_Investigation\Infections\Cozycar\amdhwdecoder_32.dll|
|[43c012086c1ae0a67c38b0926d6cba3f](https://www.virustotal.com/gui/file/43c012086c1ae0a67c38b0926d6cba3f)|Win32 EXE|Zbot|2015-03-21 00:08:52|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/BF9D3A45273608CAF90084C1157DE2074322A230|
|[f0a6436ffee12558a434a0fc24b3b33f](https://www.virustotal.com/gui/file/f0a6436ffee12558a434a0fc24b3b33f)|Win32 EXE|Zbot|2015-03-16 17:08:22|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/23E20C523B9970686D913360D438C88E6067C157|
|[eb22b99d44223866e24872d80a4ddefd](https://www.virustotal.com/gui/file/eb22b99d44223866e24872d80a4ddefd)|Win32 EXE||2015-03-13 12:20:21|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/EA0CFE60A7B7168C42C0E86E15FEB5B0C9674029|
|[9f612661000605c5d0787fe13746e4cc](https://www.virustotal.com/gui/file/9f612661000605c5d0787fe13746e4cc)|Win32 EXE|Zbot|2015-03-12 12:45:14| |
|[e8510a7ae4919a3fcedad985fbbca352](https://www.virustotal.com/gui/file/e8510a7ae4919a3fcedad985fbbca352)|Win32 EXE|Zbot|2015-03-12 07:13:26|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/8C3ED0BBDC77AEC299C77F666C21659840F5CE23|
|[9f65e3b320ec91380ebc28d4fdff4895](https://www.virustotal.com/gui/file/9f65e3b320ec91380ebc28d4fdff4895)|Win32 EXE||2015-03-10 14:59:41|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/F2FFC4E1D5FAEC0B7C03A233524BB78E44F0E50B|
|[416db420e781c709bb71acee0b79282f](https://www.virustotal.com/gui/file/416db420e781c709bb71acee0b79282f)|Win32 EXE|Zbot|2015-03-10 08:23:57|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/BDD2BAE83C3BAB9BA0C199492FE57E70C6425DD3|
|[d5a82520ebf38a0c595367ff0ca89fae](https://www.virustotal.com/gui/file/d5a82520ebf38a0c595367ff0ca89fae)|Win32 EXE||2015-03-08 23:36:24|reader_sl.exe|
|[cb52ba412736c9966c02265946b0fdb0](https://www.virustotal.com/gui/file/cb52ba412736c9966c02265946b0fdb0)|Win32 EXE|Zbot|2015-03-08 14:34:42|9d217fc19800472327465066f4cf369df9ef9c43dd3822af1d7cda79c74e7793.bin|
|[5b4250a6bb4c6915ce962d489ee912d6](https://www.virustotal.com/gui/file/5b4250a6bb4c6915ce962d489ee912d6)|Win32 EXE||2015-03-05 02:56:50|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/01D3973E1BB46E2B75034736991C567862A11263|
|[0e0182694c381f8b68afc5f3ff4c4653](https://www.virustotal.com/gui/file/0e0182694c381f8b68afc5f3ff4c4653)|Win32 EXE|Zbot|2015-03-04 19:41:29|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/32B0C8C46F8BAABA0159967C5602F58DD73EBDE9|
|[66d2b5ed8646a0ef38eef822555b9828](https://www.virustotal.com/gui/file/66d2b5ed8646a0ef38eef822555b9828)|Win32 EXE||2015-03-04 17:14:05|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/B26BC0A3E35C474F7099BD2B066F1680F3394B14|
|[83acacbd57997f6326817f709f857893](https://www.virustotal.com/gui/file/83acacbd57997f6326817f709f857893)|Win32 EXE||2015-03-03 16:31:03|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/7C710CF31F20EF7E0AD1809672255D4EDFDFF052|
|[a250c5ca9968e4ce2336462fc839bb90](https://www.virustotal.com/gui/file/a250c5ca9968e4ce2336462fc839bb90)|Win32 EXE||2015-03-03 14:20:25|A.tmp|
|[7f6bca4f08c63e597bed969f5b729c56](https://www.virustotal.com/gui/file/7f6bca4f08c63e597bed969f5b729c56)|Win32 DLL||2015-02-28 00:41:35|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/F33C980D4B6AAAB1DC401226AB452CE840AD4F40|
|[50992eefe5df1c85dde85dc008b5010d](https://www.virustotal.com/gui/file/50992eefe5df1c85dde85dc008b5010d)|Win32 DLL||2015-02-28 00:37:58|amdmiracast.dll|
|[c42bf27579eaadfa080134f3400a417b](https://www.virustotal.com/gui/file/c42bf27579eaadfa080134f3400a417b)|Win32 EXE||2015-02-27 18:32:29|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/6B5EF7B76B35203DD323AF49BFA27CFA7E1B6376|
|[57a1f0658712ee7b3a724b6d07e97259](https://www.virustotal.com/gui/file/57a1f0658712ee7b3a724b6d07e97259)|Win32 EXE||2015-02-27 13:54:05|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/6B0721A9CED806076F84E828D9C65504A77D106C|
|[d543904651b180fd5e4dc1584e639b5e](https://www.virustotal.com/gui/file/d543904651b180fd5e4dc1584e639b5e)|ZIP||2015-02-27 13:53:14|3852.ZIP|
|[ae505c295fc0f98c10aa08577fb9fe00](https://www.virustotal.com/gui/file/ae505c295fc0f98c10aa08577fb9fe00)|ZIP||2015-02-27 02:31:54|5463.ZIP|
|[1a42acbdb285a7fba17f95068822ea4e](https://www.virustotal.com/gui/file/1a42acbdb285a7fba17f95068822ea4e)|Win64 DLL||2015-02-27 00:43:40|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/04AEFBF1527536159D72D20DEA907CBD080793E3|
|[acffb2823fc655637657dcbd25f35af8](https://www.virustotal.com/gui/file/acffb2823fc655637657dcbd25f35af8)|Win32 DLL||2015-02-27 00:24:59|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/CCF83CD713E0F078697F9E842A06D624F8B9757E|
|[b5553645fe819a93aafe2894da13dae7](https://www.virustotal.com/gui/file/b5553645fe819a93aafe2894da13dae7)|Win32 DLL||2015-02-27 00:24:23|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/EB851ADFADA7B40FC4F6C0AE348694500F878493|
|[d7af9a4010c75af6756a603fd6aef5a4](https://www.virustotal.com/gui/file/d7af9a4010c75af6756a603fd6aef5a4)|ZIP||2015-02-26 23:01:48|5463.ZIP|
|[98a6484533fa12a9ba6b1bd9df1899dc](https://www.virustotal.com/gui/file/98a6484533fa12a9ba6b1bd9df1899dc)|Win32 EXE||2015-02-26 17:08:42|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/C6472898E9085E563CD56BAEB6B6E21928C5486D|
|[1a262a7bfecd981d7874633f41ea5de8](https://www.virustotal.com/gui/file/1a262a7bfecd981d7874633f41ea5de8)|Win32 EXE||2015-02-26 16:55:19|5463.exe|
|[90bd910ee161b71c7a37ac642f910059](https://www.virustotal.com/gui/file/90bd910ee161b71c7a37ac642f910059)|Win32 EXE||2015-02-26 15:03:03|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/93D53BE2C3E7961BC01E0BFA5065A2390305268C|
|[f02da961eb7b87b41aee5fd9537022f0](https://www.virustotal.com/gui/file/f02da961eb7b87b41aee5fd9537022f0)|Win32 EXE|Zbot|2015-02-26 10:57:22|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/93EE1C714FAD9CC1BF2CBA19F3DE9D1E83C665E2|
|[2ef51f1ca11ce73fa20b54a5886ad1dd](https://www.virustotal.com/gui/file/2ef51f1ca11ce73fa20b54a5886ad1dd)|Win32 EXE|Zbot|2015-02-26 10:50:59|reader_sl.exe|
|[90674c3cca487fedbe77c4986d023296](https://www.virustotal.com/gui/file/90674c3cca487fedbe77c4986d023296)|Win32 EXE||2015-02-26 09:47:30|5463.exe|
|[8ac0b6d0874449acfacc47bf1fd33236](https://www.virustotal.com/gui/file/8ac0b6d0874449acfacc47bf1fd33236)|ZIP||2015-02-26 01:34:10|3812.ZIP|
|[1ff0ed11fc6a41db458a75ae71670f94](https://www.virustotal.com/gui/file/1ff0ed11fc6a41db458a75ae71670f94)|Win32 EXE|Zbot|2015-02-26 00:49:31|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/9319BF72000F8E468C182947DD5C82FB8B9AE419|
|[4121414c63079b7fa836be00f8d0a93b](https://www.virustotal.com/gui/file/4121414c63079b7fa836be00f8d0a93b)|Win32 EXE|Zbot|2015-02-26 00:44:22| |
|[c79bf9a04913a5018ab8de65ffd1060f](https://www.virustotal.com/gui/file/c79bf9a04913a5018ab8de65ffd1060f)|Win32 EXE||2015-02-25 17:35:29|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/9F8F1672594A6FBAC43793C857DD7718E75F328A|
|[992d2386998566a2a95c2affbfe3f3fe](https://www.virustotal.com/gui/file/992d2386998566a2a95c2affbfe3f3fe)|Win32 DLL||2015-02-25 16:07:56|atidxx32.dll|
|[859f167704b5c138ed9a9d4d3fdc0723](https://www.virustotal.com/gui/file/859f167704b5c138ed9a9d4d3fdc0723)|Win32 EXE|Zbot|2015-02-25 01:46:46|5bcd74e0c3c661580201e7d8122d7525a1480b4c.codex|
|[08709ef0e3d467ce843af4deb77d74d5](https://www.virustotal.com/gui/file/08709ef0e3d467ce843af4deb77d74d5)|Win32 EXE|Zbot|2015-02-25 00:32:56|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/49FB759D133EEAAB3FCC78CEC64418E44ED649AB|
|[217549d8093f5a953f21e06c6649ec37](https://www.virustotal.com/gui/file/217549d8093f5a953f21e06c6649ec37)|ZIP|Zbot|2015-02-24 21:13:09|5283.ZIP|
|[1dde02ff744fa4e261168e2008fd613a](https://www.virustotal.com/gui/file/1dde02ff744fa4e261168e2008fd613a)|Win32 EXE||2015-02-24 19:24:13|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/BF265227F9A8E22EA1C0035AC4D2449CEED43E2B|
|[387a3eaee643695c41485e7e9aaab032](https://www.virustotal.com/gui/file/387a3eaee643695c41485e7e9aaab032)|ZIP||2015-02-24 17:11:35|2537.zip|
|[3dce9f631cc0b8a1b1bdc1b4671e2569](https://www.virustotal.com/gui/file/3dce9f631cc0b8a1b1bdc1b4671e2569)|Win32 EXE|Zbot|2015-02-24 15:35:01|0648.exe|
|[b4ae6966e65e47afa41610b1fb554607](https://www.virustotal.com/gui/file/b4ae6966e65e47afa41610b1fb554607)|Win32 EXE||2015-02-24 14:20:57|2.bin|
|[5ebce6cbedfec82f1428c3409e3df0ef](https://www.virustotal.com/gui/file/5ebce6cbedfec82f1428c3409e3df0ef)|Win32 EXE|Zbot|2015-02-24 13:56:10|reader_sl.exe|
|[330ed7549d50bdb56497a5577132610a](https://www.virustotal.com/gui/file/330ed7549d50bdb56497a5577132610a)|Win32 EXE|Zbot|2015-02-24 13:15:16|5283.exe|
|[62c4ce93050e48d623569c7dcc4d0278](https://www.virustotal.com/gui/file/62c4ce93050e48d623569c7dcc4d0278)|Win32 EXE||2015-02-24 09:12:12|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/E76DA232EC020D133530FDD52FFCC38B7C1D7662|
|[a5d6ad8ad82c266fda96e076335a5080](https://www.virustotal.com/gui/file/a5d6ad8ad82c266fda96e076335a5080)|Win32 EXE|Zbot|2015-02-24 05:59:39|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/F7D47C38ECA7EC68AA478C06B1BA983D9BF02E15|
|[a683a19b396be56749989f12aff2b871](https://www.virustotal.com/gui/file/a683a19b396be56749989f12aff2b871)|ZIP|Zbot|2015-02-24 03:47:31|b10021ab05e8141dabf7bac30e8af0b118b3ea4e|
|[fef254d6c46fdced294db44acef8d839](https://www.virustotal.com/gui/file/fef254d6c46fdced294db44acef8d839)|Win32 EXE|Zbot|2015-02-23 19:51:01|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDukeDropper/FEF254D6C46FDCED294DB44ACEF8D839|
|[8670710bc9477431a01a576b6b5c1b2a](https://www.virustotal.com/gui/file/8670710bc9477431a01a576b6b5c1b2a)|Win32 DLL||2015-02-17 19:04:02|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/8099A40B9EF478EE50C466EB65FE71B247FCF014|
|[83f57f0116a3b3d69ef7b1dbe9943801](https://www.virustotal.com/gui/file/83f57f0116a3b3d69ef7b1dbe9943801)|Win32 DLL||2015-02-17 18:48:01|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/0E020C03FFFABC6D20ECA67F559C46B4939BB4F4|
|[556b9eca4a85f52e2f3176c306e18661](https://www.virustotal.com/gui/file/556b9eca4a85f52e2f3176c306e18661)|Win64 DLL||2015-02-17 18:47:41|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/6E00B86A2480ABC6DBD971C0BF6495D81ED1B629|
|[75457cc94b1d1dfa3f5d1aedc2edb044](https://www.virustotal.com/gui/file/75457cc94b1d1dfa3f5d1aedc2edb044)|Win32 DLL||2015-02-15 03:14:16|atitmmxx.dll|
|[f16629ad4bc9473ef4978d6a3dd551f1](https://www.virustotal.com/gui/file/f16629ad4bc9473ef4978d6a3dd551f1)|Win32 DLL||2015-02-01 19:41:10|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/C3FDE950FE7D668805B40B1680D519F20C18B899|
|[fd8e27f820bdbdf6cb80a46c67fd978a](https://www.virustotal.com/gui/file/fd8e27f820bdbdf6cb80a46c67fd978a)|Win32 EXE||2015-01-29 05:35:36|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/482D1624F9450CA1C99926CEEC2606260E7CE544|
|[7688be226b946e231e0cd36e6b708d20](https://www.virustotal.com/gui/file/7688be226b946e231e0cd36e6b708d20)|ZIP||2015-01-29 05:35:05|56469839|
|[93176df76e351b3ea829e0e6c6832bdf](https://www.virustotal.com/gui/file/93176df76e351b3ea829e0e6c6832bdf)|PDF||2015-01-28 19:48:59|4156.pdf|
|[9ad55b83f2eec0c19873a770b0c86a2f](https://www.virustotal.com/gui/file/9ad55b83f2eec0c19873a770b0c86a2f)|Win32 EXE||2015-01-28 15:20:21|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/9B56155B82F14000F0EC027F29FF20E6AE5205C2|
|[d9e877c9d256256a5d8b37073f5f8cd8](https://www.virustotal.com/gui/file/d9e877c9d256256a5d8b37073f5f8cd8)|ZIP||2015-01-26 02:11:52|eFAX-854.ZIP|
|[f58a4369b8176edbde4396dc977c9008](https://www.virustotal.com/gui/file/f58a4369b8176edbde4396dc977c9008)|Win32 EXE||2015-01-25 18:26:15|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/87668D14910C1E1BB8BBEA0C6363F76E664DCD09|
|[f16dff8ec8702518471f637eb5313ab2](https://www.virustotal.com/gui/file/f16dff8ec8702518471f637eb5313ab2)|Win32 EXE||2015-01-25 18:16:39|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/C3D8A548FA0525E1E55AA592E14303FC6964D28D|
|[4649609b8394283ec36ada132b02a0c6](https://www.virustotal.com/gui/file/4649609b8394283ec36ada132b02a0c6)|Win32 EXE||2015-01-25 03:58:46|4649609b8394283ec36ada132b02a0c6|
|[181a88c911b10d0fcb4682ae552c0de3](https://www.virustotal.com/gui/file/181a88c911b10d0fcb4682ae552c0de3)|Win32 EXE||2015-01-23 16:57:38|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/78E9960CC5819583FB98FB619B33BFF7768EE861|
|[fe17934587e41662ef6fbd7708023733](https://www.virustotal.com/gui/file/fe17934587e41662ef6fbd7708023733)|ZIP||2015-01-22 22:37:50|eFAX-854.ZIP|
|[d9703d014c5d4f55e2996f3573544476](https://www.virustotal.com/gui/file/d9703d014c5d4f55e2996f3573544476)|Win32 EXE||2015-01-22 14:38:53|/home/vega/CONTAGIO/apt/APT29/APT29_2012-02_FSecure_Cozyduke/CozyDuke/210BC99275368DF7EA179055737CFFC3A12A6614|
|[31b3069cef380b4bf85e75a8885bcee8](https://www.virustotal.com/gui/file/31b3069cef380b4bf85e75a8885bcee8)|Win32 EXE||2015-01-14 04:00:03|/home/vega/CONTAGIO/apt/APT29/APT29_2017-03_Fireeye_Domain_Fronting_with_Tor/57e2f0fdc2566f11af661dc02e989dd65132a3f4_GoogleService.exe_|
|[0ea4ccf2737f7095b367eda58e475e1f](https://www.virustotal.com/gui/file/0ea4ccf2737f7095b367eda58e475e1f)|Win32 DLL||2015-01-10 12:57:22|0ea4ccf2737f7095b367eda58e475e1f|
|[b602adb677d0560601e7668eaf158605](https://www.virustotal.com/gui/file/b602adb677d0560601e7668eaf158605)|Win32 EXE||2014-12-24 19:34:01|b602adb677d0560601e7668eaf158605|
|[4638a4e7faf5a9343551cc6e9668d143](https://www.virustotal.com/gui/file/4638a4e7faf5a9343551cc6e9668d143)|Win32 EXE||2014-12-04 19:27:59|4638a4e7faf5a9343551cc6e9668d143|
|[80a93e5dd3a3ea22f9a9af1547f797ab](https://www.virustotal.com/gui/file/80a93e5dd3a3ea22f9a9af1547f797ab)|Win32 DLL||2014-11-28 09:34:25|e09f283ade693ff89864f6ec9c2354091fbd186e|
|[f78f1359fcf04e89e3bb0fbdf74c1e05](https://www.virustotal.com/gui/file/f78f1359fcf04e89e3bb0fbdf74c1e05)|Win32 DLL|CosmicDuke|2014-11-17 04:51:08|UserCache.tmp|
|[591a5ef38c1be504fbbc88219eb39692](https://www.virustotal.com/gui/file/591a5ef38c1be504fbbc88219eb39692)|Win32 EXE||2014-11-12 13:17:35|idman621build15.exe|
|[868915de8b23cfc87765525efbdb4fa0](https://www.virustotal.com/gui/file/868915de8b23cfc87765525efbdb4fa0)|Win32 EXE||2014-11-03 12:13:02|wmplayer.exe|
|[37c394e3e15d211a050446bc90edac94](https://www.virustotal.com/gui/file/37c394e3e15d211a050446bc90edac94)|Win32 EXE||2014-11-03 10:15:28|wmplayer.exe|
|[6629b432266d78f9eb74d2d1a71d0d32](https://www.virustotal.com/gui/file/6629b432266d78f9eb74d2d1a71d0d32)|Win32 EXE|CosmicDuke|2014-10-21 16:01:02|iisexpress.exe|
|[d22c02dafb1ee0ef8d4ea90ac48a6988](https://www.virustotal.com/gui/file/d22c02dafb1ee0ef8d4ea90ac48a6988)|Win32 EXE|CosmicDuke|2014-10-18 01:53:32|WLMerger|
|[6332176672744320e9fee2117b059193](https://www.virustotal.com/gui/file/6332176672744320e9fee2117b059193)|Win64 DLL||2014-10-15 03:02:06|amdocl.dll|
|[ac7a22d1af180c21b0061b8d512586d3](https://www.virustotal.com/gui/file/ac7a22d1af180c21b0061b8d512586d3)|Win32 EXE||2014-10-12 18:49:16|atibtmon.exe|
|[5400d3db044befebbc39087ee1fe9533](https://www.virustotal.com/gui/file/5400d3db044befebbc39087ee1fe9533)|Win32 EXE|graftor|2014-10-09 09:35:18|Intel NGO|
|[b2737204531a80c31bb30e9be9a1cc4c](https://www.virustotal.com/gui/file/b2737204531a80c31bb30e9be9a1cc4c)|Win32 EXE||2014-10-08 19:21:17|dumprep32.exe|
|[7040ee4cd4be4b84f8510c04663a2500](https://www.virustotal.com/gui/file/7040ee4cd4be4b84f8510c04663a2500)|Win32 EXE|CosmicDuke|2014-10-02 12:29:42|Wextract|
|[925b37a936304a5914941ac4584e346c](https://www.virustotal.com/gui/file/925b37a936304a5914941ac4584e346c)|Win32 EXE|CosmicDuke|2014-09-19 07:57:32|iisexpress.exe|
|[eb48ff76cc7dd24b519c93a0aa250d27](https://www.virustotal.com/gui/file/eb48ff76cc7dd24b519c93a0aa250d27)|Win64 DLL||2014-09-18 16:56:03|EB48FF76CC7DD24B519C93A0AA250D27 - input64.dl|
|[ed463d501c23db34e27bd32902971081](https://www.virustotal.com/gui/file/ed463d501c23db34e27bd32902971081)|DOCM|Symmi|2014-09-18 13:46:30|World News Digest.docx|
|[f27ffc3d3ff7a2ddc6728d9495427ee5](https://www.virustotal.com/gui/file/f27ffc3d3ff7a2ddc6728d9495427ee5)|DOCM|Symmi|2014-09-18 06:59:25|F27FFC3D3FF7A2DDC6728D9495427EE5 - report.docx_|
|[3d3363598f87c78826c859077606e514](https://www.virustotal.com/gui/file/3d3363598f87c78826c859077606e514)|Win32 EXE||2014-09-17 17:00:18|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT29,CozyBear/TrojanCozyBear.bin|
|[2aabd78ef11926d7b562fd0d91e68ad3](https://www.virustotal.com/gui/file/2aabd78ef11926d7b562fd0d91e68ad3)|Win32 EXE||2014-09-17 16:59:44|Adobe Flash Player 9.0|
|[bc626c8f11ed753f33ad1c0fe848d898](https://www.virustotal.com/gui/file/bc626c8f11ed753f33ad1c0fe848d898)|Win32 DLL||2014-09-17 16:58:19|isheriff_bc626c8f11ed753f33ad1c0fe848d898.bin|
|[d596827d48a3ff836545b3a999f2c3e3](https://www.virustotal.com/gui/file/d596827d48a3ff836545b3a999f2c3e3)|Win64 DLL||2014-09-17 16:57:49|aticaldd.dll|
|[6761106f816313394a653db5172dc487](https://www.virustotal.com/gui/file/6761106f816313394a653db5172dc487)|Win32 DLL||2014-09-17 16:57:03|amdhcp32.dll|
|[6d45f34e6d29391ee6f0e91bf344a7d0](https://www.virustotal.com/gui/file/6d45f34e6d29391ee6f0e91bf344a7d0)|Win32 EXE||2014-09-11 12:48:54|lvagent.exe|
|[d1ce79089578da2d41f1ad901f7b1014](https://www.virustotal.com/gui/file/d1ce79089578da2d41f1ad901f7b1014)|Win32 DLL||2014-09-11 08:38:16|/home/vega/CONTAGIO/apt/APT29/APT29_2014-11_FSecure_OnionDuke APT Attacks Via the Tor Network/D433F281CF56015941A1C2CB87066CA62EA1DB37|
|[f1583641033d66873ed1604e2f1bea1b](https://www.virustotal.com/gui/file/f1583641033d66873ed1604e2f1bea1b)|Win32 EXE||2014-09-10 11:15:21|isheriff_f1583641033d66873ed1604e2f1bea1b.bin|
|[1aa8a941ec22a3ffe32d079323a2e6c4](https://www.virustotal.com/gui/file/1aa8a941ec22a3ffe32d079323a2e6c4)|Win32 DLL|dynamer|2014-09-05 15:46:57|sysinfo_163.dll|
|[ccb6d74a8577ca44ca56cfc7fa6332b6](https://www.virustotal.com/gui/file/ccb6d74a8577ca44ca56cfc7fa6332b6)|Win32 DLL||2014-09-05 15:46:54|91CB047F28A15B558A9A4DFF26DF642B9001F8D7.exe|
|[db9ccc6fa0f7605f39d93487fbaba866](https://www.virustotal.com/gui/file/db9ccc6fa0f7605f39d93487fbaba866)|Win32 DLL||2014-09-04 03:27:20|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/OnionDuke/61283EF203F4286F1D366A57E077B0A581BE1659|
|[e1db6b72ec26311b175663b7d88e3c00](https://www.virustotal.com/gui/file/e1db6b72ec26311b175663b7d88e3c00)|Win32 DLL||2014-09-02 10:04:55|145c5081037fad98fa72aa4d6dc6c193fdb1c127_GoogleCrashReport.dl|
|[811f66d6dd2c713073c0b0aebbe74ce8](https://www.virustotal.com/gui/file/811f66d6dd2c713073c0b0aebbe74ce8)|Win32 EXE||2014-08-31 08:33:39|vt-upload-3Le1F|
|[0ee0f7fd55843d1ef7c9d6396bbcb99b](https://www.virustotal.com/gui/file/0ee0f7fd55843d1ef7c9d6396bbcb99b)|Win32 EXE|Zbot|2014-08-27 07:45:46|Adobe Flash Player Control Panel Applet 11.5|
|[2c6a49568e1733b66ef9dd2fa659aedb](https://www.virustotal.com/gui/file/2c6a49568e1733b66ef9dd2fa659aedb)|Win32 EXE|Zbot|2014-08-27 07:42:52|Adobe Flash Player Control Panel Applet 11.5|
|[d47b25667effc0f88ab460c6edeecc55](https://www.virustotal.com/gui/file/d47b25667effc0f88ab460c6edeecc55)|Win32 EXE|Zbot|2014-08-27 07:42:37|Adobe Flash Player Control Panel Applet 11.5|
|[cb8624999aa959b873e9bdb60ee65c0f](https://www.virustotal.com/gui/file/cb8624999aa959b873e9bdb60ee65c0f)|Win32 EXE|graftor|2014-08-25 22:17:07|ConHost|
|[2a998ce2750335079d73e6b2eb2bd011](https://www.virustotal.com/gui/file/2a998ce2750335079d73e6b2eb2bd011)|Win32 EXE||2014-08-19 06:52:35|ConHost|
|[cd012e8f5340d2e148d2c2cbac4270a1](https://www.virustotal.com/gui/file/cd012e8f5340d2e148d2c2cbac4270a1)|Win32 EXE||2014-08-18 14:20:46|ConHost|
|[75d15f552aba5ed0df80ec2c16ab683e](https://www.virustotal.com/gui/file/75d15f552aba5ed0df80ec2c16ab683e)|Win32 EXE||2014-08-13 19:34:40|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CosmicDuke/4FD46C30FB1B6F5431C12A38430D684ED1FF5A75|
|[628d4f33bd604203d25dbc6a5bb35b90](https://www.virustotal.com/gui/file/628d4f33bd604203d25dbc6a5bb35b90)|Win32 EXE||2014-07-29 20:04:21|C:\Program Files (x86)\Vidalia Relay Bundle\Tor\tor.exe|
|[9dc3d5da2f68b4ed9336c5b78b955780](https://www.virustotal.com/gui/file/9dc3d5da2f68b4ed9336c5b78b955780)|Win32 EXE||2014-07-26 05:06:32|Adobe Acrobat Updater|
|[608b22fcd2d067730176e335d3c6454b](https://www.virustotal.com/gui/file/608b22fcd2d067730176e335d3c6454b)|Win32 EXE||2014-07-12 09:29:06|Adobe Acrobat Updater|
|[acac7584d7dc066d27555997d0f6d6cf](https://www.virustotal.com/gui/file/acac7584d7dc066d27555997d0f6d6cf)|Win32 EXE||2014-07-08 11:00:13|WLMerger|
|[2aa2a6e004159b9e3a590c63a0cc47b3](https://www.virustotal.com/gui/file/2aa2a6e004159b9e3a590c63a0cc47b3)|PDF|pidief|2014-07-08 09:13:34|vt-upload-HnljG|
|[5a7659b691a3caf107e6636d8906dcb0](https://www.virustotal.com/gui/file/5a7659b691a3caf107e6636d8906dcb0)|Win32 EXE|CosmicDuke|2014-07-08 08:12:53|Adobe Flash Player Control Panel Applet 11.5|
|[3a746f525877b3d006758def2957ddaf](https://www.virustotal.com/gui/file/3a746f525877b3d006758def2957ddaf)|Win32 DLL||2014-07-04 04:37:56|4D5D056E501BC3FCA73A156B23E05612BD2FC7F09B44745766B98B6CA2599BFB.dat|
|[95b3ec0a4e539efaa1faa3d4e25d51de](https://www.virustotal.com/gui/file/95b3ec0a4e539efaa1faa3d4e25d51de)|Win32 EXE||2014-07-03 12:33:28|/home/vega/CONTAGIO/apt/APT29/APT29_2015-04_Kaspersky_CozyDuke-CozyBear/95B3EC0A4E539EFAA1FAA3D4E25D51DE_Office Monkeys (Short Flash Movie).exe_|
|[91aaf47843a34a9d8d1bb715a6d4acec](https://www.virustotal.com/gui/file/91aaf47843a34a9d8d1bb715a6d4acec)|Win32 EXE||2014-07-02 12:15:01|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/CozyDuke/446DAABB7AC2B9F11DC1267FBD192628CC2BAC19|
|[dffcd7f930f8874dc9f5115d0ae50b57](https://www.virustotal.com/gui/file/dffcd7f930f8874dc9f5115d0ae50b57)|Win32 EXE||2014-06-05 19:26:05|ConHost|
|[351c913e4120081d8f04317121654a39](https://www.virustotal.com/gui/file/351c913e4120081d8f04317121654a39)|Win32 EXE||2014-06-02 08:57:19|WLMerger|
|[f611f8b0655a8980cf71a252536c7a5a](https://www.virustotal.com/gui/file/f611f8b0655a8980cf71a252536c7a5a)|Win32 EXE|CosmicDuke|2014-05-29 22:07:24|chrome_exe|
|[1270217794b67491365048584a27a5ed](https://www.virustotal.com/gui/file/1270217794b67491365048584a27a5ed)|Win32 EXE|Zbot|2014-05-27 09:28:34|javatmsup|
|[270ca8368cd4216b1813281d3efe485d](https://www.virustotal.com/gui/file/270ca8368cd4216b1813281d3efe485d)|Win32 DLL|razy|2014-05-27 09:22:54|VirusShare_270ca8368cd4216b1813281d3efe485d|
|[e175be029dd2b78c059278a567b3ada1](https://www.virustotal.com/gui/file/e175be029dd2b78c059278a567b3ada1)|Win32 EXE|CosmicDuke|2014-05-27 09:05:57|WLMerger|
|[dc92eba92885f2e937cb6f694647eb71](https://www.virustotal.com/gui/file/dc92eba92885f2e937cb6f694647eb71)|Win32 EXE|agentwdcr|2014-04-27 19:15:22|WLMerger|
|[d824cbf08604dea9724ab8e707bb9fec](https://www.virustotal.com/gui/file/d824cbf08604dea9724ab8e707bb9fec)|Win32 EXE||2014-04-27 19:13:48|D824CBF08604DEA9724AB8E707BB9FEC|
|[6b08ff05b50dd89d81e2aa47554aa5e6](https://www.virustotal.com/gui/file/6b08ff05b50dd89d81e2aa47554aa5e6)|RTF|CVE-2012-0158|2014-04-08 13:18:43|58be4918df7fbf1e12de1a31d4f622e570a81b93_Proposal-Cover-Sheet-English.rtf_|
|[6a5a0ac42161333e9758589ecabed3c6](https://www.virustotal.com/gui/file/6a5a0ac42161333e9758589ecabed3c6)|Win32 DLL|Ursu|2014-04-07 16:48:57|UserCache.dll|
|[0753697172046fcfb03d6445fff1f093](https://www.virustotal.com/gui/file/0753697172046fcfb03d6445fff1f093)|Win32 EXE|dynamer|2014-04-07 16:47:19|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/OnionDuke/25E0AF331B8E9FED64DC0DF71A2687BE348100E8|
|[933b3c5d3728ef6e08af4ae579c00d11](https://www.virustotal.com/gui/file/933b3c5d3728ef6e08af4ae579c00d11)|Win32 EXE|CosmicDuke|2014-04-01 12:18:22|%TEMP%\7d13a037-8cfc-4401-b28b-05cde195c7ff|
|[b59199877e0d68a5e93fc8ea76374ed1](https://www.virustotal.com/gui/file/b59199877e0d68a5e93fc8ea76374ed1)|Win32 EXE|CosmicDuke|2014-03-31 19:54:12|C:\Users\<USER>\AppData\Local\Temp\rasfw.exe|
|[16bb0f9d98eb7a832b6db1e92f4e4f1a](https://www.virustotal.com/gui/file/16bb0f9d98eb7a832b6db1e92f4e4f1a)|Win32 DLL||2014-03-30 00:20:21|/tmp/vt-upload-zEu06r|
|[3729a14be6b3a92265cf6d8e14c79abe](https://www.virustotal.com/gui/file/3729a14be6b3a92265cf6d8e14c79abe)|Win32 EXE|agentwdcr|2014-03-26 13:21:07|Adobe Acrobat Updater|
|[edf7a81dab0bf0520bfb8204a010b730](https://www.virustotal.com/gui/file/edf7a81dab0bf0520bfb8204a010b730)|Win32 EXE|CosmicDuke|2014-03-22 12:50:20|ecd2feb0afd5614d7575598c63d9b0146a67ecaa_exe.ex|
|[d729fbb50665932fe529f7073acca9c1](https://www.virustotal.com/gui/file/d729fbb50665932fe529f7073acca9c1)|Win32 EXE|CosmicDuke|2014-03-21 09:52:57|chrome_exe|
|[8988f29396515f47de0457f9daa1dd62](https://www.virustotal.com/gui/file/8988f29396515f47de0457f9daa1dd62)|Win32 EXE|CosmicDuke|2014-03-20 08:51:30|svchost.exe|
|[8e5106565fd96df1308d208d1e3426a3](https://www.virustotal.com/gui/file/8e5106565fd96df1308d208d1e3426a3)|Win32 EXE|CosmicDuke|2014-03-20 08:48:00|chrome_exe|
|[6571a2d3892ca937697e96f8bb795e42](https://www.virustotal.com/gui/file/6571a2d3892ca937697e96f8bb795e42)|PDF||2014-03-20 07:06:38|6571A2D3892CA937697E96F8BB795E42 - pdf|
|[1a874e5ecd67dffab45e17e9b730daed](https://www.virustotal.com/gui/file/1a874e5ecd67dffab45e17e9b730daed)|Win32 EXE|agentwdcr|2014-03-18 09:54:01|WLMerger|
|[20d86cb4ebbffb739faa47f7354ee134](https://www.virustotal.com/gui/file/20d86cb4ebbffb739faa47f7354ee134)|Win32 EXE|CosmicDuke|2014-03-18 08:46:41|20D86CB4EBBFFB739FAA47F7354EE134|
|[f22606385080d35551e7f8e8f49b7de9](https://www.virustotal.com/gui/file/f22606385080d35551e7f8e8f49b7de9)|Win32 EXE|CosmicDuke|2014-03-13 15:06:55|F22606385080D35551E7F8E8F49B7DE9|
|[19aca5da05ee8e5862e1d1ee50e84cec](https://www.virustotal.com/gui/file/19aca5da05ee8e5862e1d1ee50e84cec)|Win32 DLL||2014-03-13 15:04:51|19aca5da05ee8e5862e1d1ee50e84cec|
|[6542cd548182d6adc08a63c942f9bc54](https://www.virustotal.com/gui/file/6542cd548182d6adc08a63c942f9bc54)|PDF||2014-03-11 07:21:28|6542CD548182D6ADC08A63C942F9BC54 - pdf|
|[23d2592db15c251382706515cf4fd37e](https://www.virustotal.com/gui/file/23d2592db15c251382706515cf4fd37e)|PDF|pidief|2014-03-05 16:25:43|23D2592DB15C251382706515CF4FD37E - pdf|
|[af534ba7bfc624c76e718ceab3477118](https://www.virustotal.com/gui/file/af534ba7bfc624c76e718ceab3477118)|Win32 DLL||2014-02-19 15:31:23|vti-rescan|
|[b8088f6594dd8cba31b4f52a2d91f40e](https://www.virustotal.com/gui/file/b8088f6594dd8cba31b4f52a2d91f40e)|Win32 DLL|razy|2014-01-14 23:33:01|b8088f6594dd8cba31b4f52a2d91f40e|
|[ab2d8a0d5b03d40f148f2f907b55f9f1](https://www.virustotal.com/gui/file/ab2d8a0d5b03d40f148f2f907b55f9f1)|Win32 DLL|razy|2014-01-14 23:21:13|ab2d8a0d5b03d40f148f2f907b55f9f1|
|[a67ad3e2a020f690d892b727102a759b](https://www.virustotal.com/gui/file/a67ad3e2a020f690d892b727102a759b)|Win32 DLL|razy|2014-01-14 03:15:13|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/223C7EB7B9DDE08EE028BBA6552409EE144DB54A|
|[b8e89f9908262b5385623c0e39d6b940](https://www.virustotal.com/gui/file/b8e89f9908262b5385623c0e39d6b940)|Win32 DLL|razy|2014-01-05 23:28:25|b8e89f9908262b5385623c0e39d6b940|
|[28f96a57fa5ff663926e9bad51a1d0cb](https://www.virustotal.com/gui/file/28f96a57fa5ff663926e9bad51a1d0cb)|Win32 EXE||2013-12-18 01:35:09|/home/vega/CONTAGIO/apt/APT29/APT29_2014-11_FSecure_OnionDuke APT Attacks Via the Tor Network/A75995F94854DEA8799650A2F4A97980B71199D2|
|[3c0ca0ab63a76dbf836725c95e2a5b7a](https://www.virustotal.com/gui/file/3c0ca0ab63a76dbf836725c95e2a5b7a)|Win32 EXE|Festalco|2013-12-09 09:52:25|AMD Chipset Support|
|[2d96b4c95152819a888deccf7ec965d6](https://www.virustotal.com/gui/file/2d96b4c95152819a888deccf7ec965d6)|Win32 DLL||2013-11-28 16:47:44|2d96b4c95152819a888deccf7ec965d6|
|[89b3cf1023825cc49efe59b06092dba1](https://www.virustotal.com/gui/file/89b3cf1023825cc49efe59b06092dba1)|Win32 DLL||2013-11-28 16:47:42|89b3cf1023825cc49efe59b06092dba1|
|[dc6cc442c0900104a5601a6049354fad](https://www.virustotal.com/gui/file/dc6cc442c0900104a5601a6049354fad)|Win32 EXE|CosmicDuke|2013-11-11 02:00:32|dc6cc442c0900104a5601a6049354fad.exe|
|[ab7a66ed3c6de1b7449d6054a8b46d7f](https://www.virustotal.com/gui/file/ab7a66ed3c6de1b7449d6054a8b46d7f)|PDF||2013-11-04 17:08:46|AB7A66ED3C6DE1B7449D6054A8B46D7F - pdf|
|[c0f27bcdede7fe36664770dfe9f84044](https://www.virustotal.com/gui/file/c0f27bcdede7fe36664770dfe9f84044)|Win32 EXE||2013-10-11 20:00:26|Louisian.exe|
|[c8eb6040fd02d77660d19057a38ff769](https://www.virustotal.com/gui/file/c8eb6040fd02d77660d19057a38ff769)|Win32 DLL||2013-09-10 19:48:11|c8eb6040fd02d77660d19057a38ff769_366affd094cc63e2c19c5d57a6866b487889dab5d1b07c084fff94262d8a390b|
|[69232da84dc7d9b2fdf1f1daade6eaae](https://www.virustotal.com/gui/file/69232da84dc7d9b2fdf1f1daade6eaae)|Win32 EXE||2013-08-27 16:10:11|17593776|
|[561017f887865b8d13f85c5474cdcbb8](https://www.virustotal.com/gui/file/561017f887865b8d13f85c5474cdcbb8)|Win32 DLL|kazy|2013-08-12 11:18:23|2a13ae3806de8e2c7adba6465c4b2a7bb347f0f5.codex|
|[dee4b9c620a390be143a79f555225c85](https://www.virustotal.com/gui/file/dee4b9c620a390be143a79f555225c85)|Win32 EXE|Zbot|2013-08-08 10:27:47|Java(TM) Update Sheduler|
|[f23a89f3b7b6fa1312e6a10ede4e23a6](https://www.virustotal.com/gui/file/f23a89f3b7b6fa1312e6a10ede4e23a6)|Win32 DLL||2013-07-29 08:58:14|socnet_99.php|
|[9993445521ca03ac3a693625b5ca1f36](https://www.virustotal.com/gui/file/9993445521ca03ac3a693625b5ca1f36)|Win32 DLL||2013-07-23 23:22:29|socnet_95.php|
|[d33e91246924adb5edc97ceae8a60084](https://www.virustotal.com/gui/file/d33e91246924adb5edc97ceae8a60084)|Win32 EXE||2013-07-23 17:00:35|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/OnionDuke/E519198DE4CC8BCB0644AA1AB6552B1D15C99A0E|
|[0be02d5f66f84ebd03f362ad4b4a06e6](https://www.virustotal.com/gui/file/0be02d5f66f84ebd03f362ad4b4a06e6)|Win32 EXE||2013-07-22 08:19:29|WLMerger|
|[3a6b45a7c8fa74bc342b69e926079960](https://www.virustotal.com/gui/file/3a6b45a7c8fa74bc342b69e926079960)|Win32 DLL||2013-07-21 08:36:20|5|
|[c728dc7b8b9cf927a8c3aa29a1e935b4](https://www.virustotal.com/gui/file/c728dc7b8b9cf927a8c3aa29a1e935b4)|Win32 EXE||2013-07-16 16:59:16|\sonas\share\samples\c7\28\dc\7b\c728dc7b8b9cf927a8c3aa29a1e935b4.797b3101b9352be812b8d411179ae765e14065a6|
|[9d95c8f09f991a5fc37b79c45ebd2043](https://www.virustotal.com/gui/file/9d95c8f09f991a5fc37b79c45ebd2043)|Win32 EXE|CosmicDuke|2013-07-16 15:32:05|chrome_exe|
|[ab24962ba63d32a62cefd3c68c54a2ec](https://www.virustotal.com/gui/file/ab24962ba63d32a62cefd3c68c54a2ec)|Win32 EXE||2013-07-11 13:21:34|ab24962ba63d32a62cefd3c68c54a2ec.application_x-dosexec|
|[d26ff50f81e76dffd1382fbf16783b47](https://www.virustotal.com/gui/file/d26ff50f81e76dffd1382fbf16783b47)|Win32 EXE||2013-07-11 05:02:54|Toy_Defense_2_Rus.exe|
|[5bc3b701819a4f2004b000d7db4b1b63](https://www.virustotal.com/gui/file/5bc3b701819a4f2004b000d7db4b1b63)|Win32 EXE||2013-07-09 04:24:40|C:\Users\<USER>\AppData\Local\Temp\msinfosrv.exe|
|[fc0e380447be2bbdf9f06fc3358f8648](https://www.virustotal.com/gui/file/fc0e380447be2bbdf9f06fc3358f8648)|PDF||2013-07-01 15:38:09|FC0E380447BE2BBDF9F06FC3358F8648 - pdf|
|[a4c77494cccb41aaa8849176bd58055e](https://www.virustotal.com/gui/file/a4c77494cccb41aaa8849176bd58055e)|Win32 EXE||2013-06-26 17:26:02|Gadgets_MegaPack.exe|
|[65c40b01a0870250fb358efc8b201192](https://www.virustotal.com/gui/file/65c40b01a0870250fb358efc8b201192)|Win32 DLL||2013-06-22 17:35:52|MsAssistClient.dll|
|[664b149ae8469cbda7fd7ed48c7dc9b6](https://www.virustotal.com/gui/file/664b149ae8469cbda7fd7ed48c7dc9b6)|Win32 EXE|CosmicDuke|2013-04-25 06:32:38|Java(TM) Update Scheduler|
|[f239e79e87f09000c247ff7e91ab9603](https://www.virustotal.com/gui/file/f239e79e87f09000c247ff7e91ab9603)|Win32 DLL||2013-04-24 10:20:04|spoolcds.-|
|[ffefe16d581340c1e49f585a576a1fd8](https://www.virustotal.com/gui/file/ffefe16d581340c1e49f585a576a1fd8)|Win32 DLL|razy|2013-04-23 14:40:44|31ab6830f4e39c2c520ae55d4c4bffe0b347c947-ffefe16d581340c1e49f585a576a1fd8.01.dll.vir|
|[f19345e0e5aecc0da45b4c110591bdd9](https://www.virustotal.com/gui/file/f19345e0e5aecc0da45b4c110591bdd9)|Win32 DLL|razy|2013-04-23 14:40:26|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/D81B0705D26390EB82188C03644786DD6F1A2A9E|
|[e990e0d1ee90cd10c4be7bfde6cc3e5a](https://www.virustotal.com/gui/file/e990e0d1ee90cd10c4be7bfde6cc3e5a)|Win32 DLL|razy|2013-04-23 14:40:17|e990e0d1ee90cd10c4be7bfde6cc3e5a.PE_|
|[e1a659473ae1e828508309b77da13783](https://www.virustotal.com/gui/file/e1a659473ae1e828508309b77da13783)|Win32 DLL|razy|2013-04-23 14:40:09|e1a659473ae1e828508309b77da13783.PE_|
|[c92252487615d5379317febc22dba7d4](https://www.virustotal.com/gui/file/c92252487615d5379317febc22dba7d4)|Win32 DLL|razy|2013-04-23 14:39:42|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/73366C1EB26B92886531586728BE4975D56F7CA5|
|[c519eef57001ad3ae60cdcb0009bf778](https://www.virustotal.com/gui/file/c519eef57001ad3ae60cdcb0009bf778)|Win32 DLL|razy|2013-04-23 14:39:28|c519eef57001ad3ae60cdcb0009bf778.PE_|
|[b68677e04fcc9103560bb0a5e5c7303f](https://www.virustotal.com/gui/file/b68677e04fcc9103560bb0a5e5c7303f)|Win32 DLL|razy|2013-04-23 14:39:09|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/A6C18FCBE6B25C370E1305D523B5DE662172875B|
|[b100d530d67cfbe76394bb0160567382](https://www.virustotal.com/gui/file/b100d530d67cfbe76394bb0160567382)|Win32 DLL|razy|2013-04-23 14:38:58|43fa0d5a30b4cd72bb7e156c00c1611bb4f4bd0a-b100d530d67cfbe76394bb0160567382.01.dll.vir|
|[935892bb70d954efdc5ee1b0c5f97184](https://www.virustotal.com/gui/file/935892bb70d954efdc5ee1b0c5f97184)|Win32 DLL|razy|2013-04-23 14:38:19|935892bb70d954efdc5ee1b0c5f97184.PE_|
|[381691b297f7f5694709e21ad61ec645](https://www.virustotal.com/gui/file/381691b297f7f5694709e21ad61ec645)|Win32 DLL|razy|2013-04-23 14:38:02|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/F62600984C5086F2DA3D70BC1F5042CF464F928D|
|[8282eb6d6f20c5de6e7f4ae3a42438d2](https://www.virustotal.com/gui/file/8282eb6d6f20c5de6e7f4ae3a42438d2)|Win32 DLL|razy|2013-04-23 14:37:44|8282eb6d6f20c5de6e7f4ae3a42438d2.PE_|
|[48bbce47e4d2d51811ea99d5a771cd1a](https://www.virustotal.com/gui/file/48bbce47e4d2d51811ea99d5a771cd1a)|Win32 DLL|razy|2013-04-23 14:36:49|1ba5bcd62abcbff517a4adb2609f721dd7f609df-48bbce47e4d2d51811ea99d5a771cd1a.01.dll.vir|
|[05d10323111f02233163a6742556c974](https://www.virustotal.com/gui/file/05d10323111f02233163a6742556c974)|Win32 DLL|razy|2013-04-23 14:36:44|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/4EC769C15A9E318D41FD4A1997EC13C029976FC2|
|[2dcd049c591644e35102921a48799975](https://www.virustotal.com/gui/file/2dcd049c591644e35102921a48799975)|Win32 DLL|razy|2013-04-23 14:36:40|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage2/30B377E7DC2418607D8CF5D01AE1F925EAB2F037|
|[2d87ab160291664d62445548a2164c60](https://www.virustotal.com/gui/file/2d87ab160291664d62445548a2164c60)|Win32 DLL|razy|2013-04-23 14:36:36|2d87ab160291664d62445548a2164c60.PE_|
|[2e30fd352b659557b5da83dcba6195c0](https://www.virustotal.com/gui/file/2e30fd352b659557b5da83dcba6195c0)|Win32 EXE||2013-04-20 03:29:20|2e30fd352b659557b5da83dcba6195c0|
|[2384eb7914fd9d8d11be72bb83046445](https://www.virustotal.com/gui/file/2384eb7914fd9d8d11be72bb83046445)|Win32 EXE||2013-04-14 16:41:41|vt-upload-zfi1D|
|[d39f2202b421561cfc36a8802184685c](https://www.virustotal.com/gui/file/d39f2202b421561cfc36a8802184685c)|GIF||2013-03-25 08:53:02|bg_edf.gif|
|[441ee6a307e672c24d334d66cd7b2e1a](https://www.virustotal.com/gui/file/441ee6a307e672c24d334d66cd7b2e1a)|Win32 DLL|razy|2013-03-24 19:44:59|441ee6a307e672c24d334d66cd7b2e1a.PE_|
|[0775a35e939a14a382b562c95845cb50](https://www.virustotal.com/gui/file/0775a35e939a14a382b562c95845cb50)|Win32 EXE||2013-03-15 01:12:10|apt.exe_|
|[c48d0822eedd75c9c56f688fb8a05259](https://www.virustotal.com/gui/file/c48d0822eedd75c9c56f688fb8a05259)|GIF||2013-03-14 13:16:02|3198217296.gif|
|[92ff4df1d079a003ae2a8ac47dd5e81b](https://www.virustotal.com/gui/file/92ff4df1d079a003ae2a8ac47dd5e81b)|GIF||2013-03-14 13:15:43|6CF8CA847EE317255A9084BB44AE3F38EF61E5C31|
|[1e1b0d16a16cf5c7f3a7c053ce78f515](https://www.virustotal.com/gui/file/1e1b0d16a16cf5c7f3a7c053ce78f515)|Win32 EXE||2013-03-06 15:24:06|/home/vega/CONTAGIO/apt/APT29/APT29_2015-09_FSecure_THE DUKES7 years of Russian cyberespionage/MiniDuke/DE8E9DEF2553F4D211CC0B34A3972D9814F156AA|
|[e863737773f64498091cd775c7abde66](https://www.virustotal.com/gui/file/e863737773f64498091cd775c7abde66)|Win32 DLL|razy|2013-03-06 15:10:00|e863737773f64498091cd775c7abde66|
|[06cca401a1049ae2fbb4f00aac720136](https://www.virustotal.com/gui/file/06cca401a1049ae2fbb4f00aac720136)|PDF||2013-03-06 03:32:04|77A62F51649388E8DA9939D5C467F56102269EB1_Nato_pdf_|
|[2ab25d33d61cf4cfbac92c26c7c0598e](https://www.virustotal.com/gui/file/2ab25d33d61cf4cfbac92c26c7c0598e)|Win32 DLL|razy|2013-03-05 05:47:20|2AB25D33D61CF4CFBAC92C26C7C0598E|
|[7049aa581874752093bb98850ff45dac](https://www.virustotal.com/gui/file/7049aa581874752093bb98850ff45dac)|GIF||2013-03-02 18:16:12|bg_dfdsh.gif|
|[44ee71de720fc1a50c919bc5a01c592d](https://www.virustotal.com/gui/file/44ee71de720fc1a50c919bc5a01c592d)|GIF||2013-03-02 18:16:10|3946889701.gif|
|[78e51be60eab2c6e952c9538a46ab521](https://www.virustotal.com/gui/file/78e51be60eab2c6e952c9538a46ab521)|Win32 EXE||2013-03-02 11:11:09|78e51be60eab2c6e952c9538a46ab521|
|[4c6608203e751cf27f627220269d6835](https://www.virustotal.com/gui/file/4c6608203e751cf27f627220269d6835)|Win32 EXE||2013-03-02 11:10:59|/home/vega/CONTAGIO/apt/APT29/APT29_2013-02_Crysys_Miniduke Indicators/Stage3/118114446847EAD7A2FE87ECB4943FDBDD2BBD1E|
|[86ef8f5f62ae8590d6edf45e04806515](https://www.virustotal.com/gui/file/86ef8f5f62ae8590d6edf45e04806515)|Win32 EXE||2013-03-01 02:09:57|86ef8f5f62ae8590d6edf45e04806515|
|[6942f1dfd61d231df8acb7ed0f6310c4](https://www.virustotal.com/gui/file/6942f1dfd61d231df8acb7ed0f6310c4)|Win32 DLL|razy|2013-03-01 00:37:26|\sonas\share\samples\69\42\f1\df\6942f1dfd61d231df8acb7ed0f6310c4|
|[1528567b1a2f1da31d602ce1ddfd8918](https://www.virustotal.com/gui/file/1528567b1a2f1da31d602ce1ddfd8918)|Win32 DLL|razy|2013-02-28 01:41:58|1528567B1A2F1DA31D602CE1DDFD8918|
|[a58e8e935341b6f5cc1369c616de3765](https://www.virustotal.com/gui/file/a58e8e935341b6f5cc1369c616de3765)|Win32 DLL|razy|2013-02-28 01:39:36|a58e8e935341b6f5cc1369c616de3765.PE_|
|[d2f39019bfa05c7e71748d0624be9a94](https://www.virustotal.com/gui/file/d2f39019bfa05c7e71748d0624be9a94)|Win32 DLL|razy|2013-02-28 01:36:56|vti-rescan|
|[304bb5f1419a2e56f4bcd0d0f3b1312f](https://www.virustotal.com/gui/file/304bb5f1419a2e56f4bcd0d0f3b1312f)|PDF||2013-02-28 01:23:56|themysteryofthepdf0-dayassemblermicrobackdoor.pdf|
|[738c60fff066934b6f33e368cfe9a88c](https://www.virustotal.com/gui/file/738c60fff066934b6f33e368cfe9a88c)|Win32 EXE||2013-02-27 19:28:10|738c60fff066934b6f33e368cfe9a88c|
|[18e64b8e5ce5bdd33ce8bd9e00af672c](https://www.virustotal.com/gui/file/18e64b8e5ce5bdd33ce8bd9e00af672c)|Win32 EXE||2013-02-27 19:27:56|\sonas\share\samples\18\e6\4b\8e\18e64b8e5ce5bdd33ce8bd9e00af672c|
|[cf59ed2b5473281cc2e083eba3f4b662](https://www.virustotal.com/gui/file/cf59ed2b5473281cc2e083eba3f4b662)|Win32 EXE||2013-02-27 19:27:55|cf59ed2b5473281cc2e083eba3f4b662|
|[a4ad6b55b1bc9e16123de1388f6ef9bf](https://www.virustotal.com/gui/file/a4ad6b55b1bc9e16123de1388f6ef9bf)|Win32 DLL|razy|2013-02-27 19:27:19|A4AD6B55B1BC9E16123DE1388F6EF9BF|
|[b798c968cbfd53f878e13c7698610d9c](https://www.virustotal.com/gui/file/b798c968cbfd53f878e13c7698610d9c)|Win32 EXE|razy|2013-02-27 19:27:02|B798C968CBFD53F878E13C7698610D9C|
|[afe0190820b3edc296daefe6d1611051](https://www.virustotal.com/gui/file/afe0190820b3edc296daefe6d1611051)|GIF||2013-02-27 18:27:11|81612FC09CFAE280CC35B1331C832A5A87C2EDFF1|
|[06def6c642dcbd58d0291ac110a57274](https://www.virustotal.com/gui/file/06def6c642dcbd58d0291ac110a57274)|GIF||2013-02-27 18:26:39|3c28d41fbe5f6f0e4a8402fdd036f2a8cf271dabe135919ea0de0d5f1348f871|
|[92a2c993b7a1849f11e8a95defacd2f7](https://www.virustotal.com/gui/file/92a2c993b7a1849f11e8a95defacd2f7)|GIF||2013-02-27 18:26:15|5de532fd62bd4e528ed6e0ccf746e20e2e58041b7ff5327ddbbcf37628429077|
|[2530f54b87508e6f09a6bc5ab863b5db](https://www.virustotal.com/gui/file/2530f54b87508e6f09a6bc5ab863b5db)|Win32 DLL|razy|2013-02-27 15:47:37|~98w.tmp|
|[c786a4cdfe08dbe7c64972a14669c4d1](https://www.virustotal.com/gui/file/c786a4cdfe08dbe7c64972a14669c4d1)|Win32 DLL|razy|2013-02-27 15:45:59|0d78d1690d2db2ee322ca11b82d79c758a901ebc_dll.dl|
|[297ef5bf99b5e4fd413f3755ba6aad79](https://www.virustotal.com/gui/file/297ef5bf99b5e4fd413f3755ba6aad79)|Win32 DLL|razy|2013-02-27 15:01:40|c60621e82f58b5ea5b36cde40889a076cb2c7f1612144998b1d388200bc7e295.bin|
|[626489f8cafacb1b24fe6ecf0db52f23](https://www.virustotal.com/gui/file/626489f8cafacb1b24fe6ecf0db52f23)|GIF||2013-02-27 14:58:38|3979106736.gif|
|[07a9975d7d96ff3b56de024ab2017582](https://www.virustotal.com/gui/file/07a9975d7d96ff3b56de024ab2017582)|GIF||2013-02-27 14:32:29|15406110|
|[ded2f80457aaefe1a80a9cefd1f4645d](https://www.virustotal.com/gui/file/ded2f80457aaefe1a80a9cefd1f4645d)|Win32 DLL|kazy|2013-02-27 13:53:14|\sonas\share\samples\de\d2\f8\04\ded2f80457aaefe1a80a9cefd1f4645d|
|[810de1b9fa0a9396acae23dcd113a60d](https://www.virustotal.com/gui/file/810de1b9fa0a9396acae23dcd113a60d)|Win32 DLL||2013-02-27 10:48:53|/home/vega/CONTAGIO/apt/APT29/APT29_2013-04_Bitdefender_A Closer Look at MiniDuke/2013/7815e5275ea849a9ed1f193abd8781ff7ae6b88ef6282f6a0900175a4bb59131|
|[c03bcb0cde62b3f45b4d772ab635e2b0](https://www.virustotal.com/gui/file/c03bcb0cde62b3f45b4d772ab635e2b0)|PDF|pidief|2013-02-25 15:30:33|myfile.exe|
|[cf5a5239ada9b43592757c0d7bf66169](https://www.virustotal.com/gui/file/cf5a5239ada9b43592757c0d7bf66169)|PDF||2013-02-25 10:54:56|2402C2DC6ACC5A8418201FEA5B2043F985E1DD69_EUAG_report.pdf_|
|[527537cc28705e01af8d8006ae8308a9](https://www.virustotal.com/gui/file/527537cc28705e01af8d8006ae8308a9)|Win32 DLL|razy|2013-02-25 06:52:17|6c2409d415e66faebf0a031350b44d5a014ab4f62f2c1a3115982d452b7f97b9|
|[9003e1d69cd29280d2233c1634370c60](https://www.virustotal.com/gui/file/9003e1d69cd29280d2233c1634370c60)|Win32 EXE|Symmi|2013-02-24 04:51:07|Intel NGO|
|[0cdf55626e56ffbf1b198beb4f6ed559](https://www.virustotal.com/gui/file/0cdf55626e56ffbf1b198beb4f6ed559)|PDF|pidief|2013-02-22 08:11:39|myfile.exe|
|[88292d7181514fda5390292d73da28d4](https://www.virustotal.com/gui/file/88292d7181514fda5390292d73da28d4)|PDF|pidief|2013-02-21 12:25:54|CVE-2013-0640_PDF_88292D7181514FDA5390292D73DA28D4_ASEM_Seminar.pdf_|
|[3f301758aa3d5d123a9ddbad1890853b](https://www.virustotal.com/gui/file/3f301758aa3d5d123a9ddbad1890853b)|PDF||2013-02-21 08:43:14|CVE-2013-0640_PDF_3F301758AA3D5D123A9DDBAD1890853B_EUAG_report.pdf_|
|[3668b018b4bb080d1875aee346e3650a](https://www.virustotal.com/gui/file/3668b018b4bb080d1875aee346e3650a)|PDF|pidief|2013-02-21 08:25:35|myfile.exe|
|[685d678b3ffd72fce3f8b48d82a76f60](https://www.virustotal.com/gui/file/685d678b3ffd72fce3f8b48d82a76f60)|Win32 EXE||2013-02-15 04:31:06|70a7248b90573ba2edde5d9e8f0acd478235054480d98b0531d85725555f3a5c.vir|
|[7ad50c9e4a4bab73bba38860906220b6](https://www.virustotal.com/gui/file/7ad50c9e4a4bab73bba38860906220b6)|Win32 DLL||2013-02-10 15:11:59|desktop.dll|
|[6f5a73931c6c109bd6504a5ee0476ae7](https://www.virustotal.com/gui/file/6f5a73931c6c109bd6504a5ee0476ae7)|Win32 EXE||2013-02-10 15:11:49|vti-rescan|
|[1e417aa350346731f6e0c936d725f1a5](https://www.virustotal.com/gui/file/1e417aa350346731f6e0c936d725f1a5)|Win32 EXE||2013-02-09 10:35:40|Java(TM) Update Sheduler|
|[37369a91ad462f1fac9004f3a86bb3ac](https://www.virustotal.com/gui/file/37369a91ad462f1fac9004f3a86bb3ac)|Win32 EXE||2012-12-04 02:06:08|AMD Chipset Support|
|[50a56d98be79a1e6f04a1964e170a5d7](https://www.virustotal.com/gui/file/50a56d98be79a1e6f04a1964e170a5d7)|Win32 DLL||2012-11-20 08:24:48|advsec32.dll_|
|[e36d73c6c8e832b7955c442b484472e5](https://www.virustotal.com/gui/file/e36d73c6c8e832b7955c442b484472e5)|Win32 EXE||2012-11-02 10:24:07|e36d73c6c8e832b7955c442b484472e5|
|[68f6d84ac9a28c2fea59ff5e04577911](https://www.virustotal.com/gui/file/68f6d84ac9a28c2fea59ff5e04577911)|Win32 EXE||2012-10-22 19:33:29|Java(TM) Update Scheduler|
|[210834cfcde3f416b82263c521eefa78](https://www.virustotal.com/gui/file/210834cfcde3f416b82263c521eefa78)|Win32 EXE||2012-10-08 18:49:16|98cd87a544ca06ae249e4f3c9790efbd63d8954e0ff695d2404e92f2383871bf.vir|
|[fa3b44b8a4a2a2b473cd5d934d1ec4bc](https://www.virustotal.com/gui/file/fa3b44b8a4a2a2b473cd5d934d1ec4bc)|Win32 EXE||2012-09-16 10:28:38|fa3b44b8a4a2a2b473cd5d934d1ec4bc|
|[e48fb57ce3d9c56ca3cf6c4aed8ad0ea](https://www.virustotal.com/gui/file/e48fb57ce3d9c56ca3cf6c4aed8ad0ea)|Win32 DLL|kazy|2012-09-10 15:22:22|Setup.dat|
|[ff83dad77ac2b526849930f1860dfd3f](https://www.virustotal.com/gui/file/ff83dad77ac2b526849930f1860dfd3f)|Win32 DLL|kazy|2012-09-10 15:15:30|045867051a6052d1d910abfcb24a7674bcc046ca_00000000.dl|
|[33548f84763edb22ea6039dbbd064aeb](https://www.virustotal.com/gui/file/33548f84763edb22ea6039dbbd064aeb)|Win32 EXE||2012-08-23 23:34:27|33548F84763EDB22EA6039DBBD064AEB.bin|
|[39e1b41b4118f4ea3ce2119c054b29e8](https://www.virustotal.com/gui/file/39e1b41b4118f4ea3ce2119c054b29e8)|Win32 EXE||2012-08-17 14:55:23|WLMerger|
|[89c6c5439a2747d7f2a7305521dddcbb](https://www.virustotal.com/gui/file/89c6c5439a2747d7f2a7305521dddcbb)|Win32 EXE||2012-08-12 09:05:53|isheriff_89c6c5439a2747d7f2a7305521dddcbb.bin|
|[9f13dc03904dbd45374acc2134477273](https://www.virustotal.com/gui/file/9f13dc03904dbd45374acc2134477273)|Win32 DLL|kazy|2012-06-13 20:04:49|upd.db|
|[1de51ec5d2b8466f0d424e1c8dcd6454](https://www.virustotal.com/gui/file/1de51ec5d2b8466f0d424e1c8dcd6454)|Win32 DLL|kazy|2012-06-13 18:20:20|/home/vega/CONTAGIO/apt/APT29/APT29_2013-04_Bitdefender_A Closer Look at MiniDuke/2012/1db9187b7b0e5bc97aca233f29b96295c0bc4058fdcff50df543c1f044e58836|
|[73931351f883cff5dbdcc54cc4eb10a7](https://www.virustotal.com/gui/file/73931351f883cff5dbdcc54cc4eb10a7)|Win32 DLL|kazy|2012-06-12 16:12:58|/home/vega/CONTAGIO/apt/APT29/APT29_2013-04_Bitdefender_A Closer Look at MiniDuke/2012/15101f74f974e3e80cc37805ebe5cc2efed77bb5745d82e1b44b1da4f0c83691|
|[bf839cb54473c333b2c151ad627eb39f](https://www.virustotal.com/gui/file/bf839cb54473c333b2c151ad627eb39f)|Win32 EXE||2012-05-29 05:53:23|../benign_from_unknown/bf839cb54473c333b2c151ad627eb39f|
|[f5cc1c0c90fb89e4b4fc048c5a03b46f](https://www.virustotal.com/gui/file/f5cc1c0c90fb89e4b4fc048c5a03b46f)|Win32 EXE|Festalco|2011-09-22 08:16:26|Intel Chipset Support|
|[2bd46a980dde8eaa13e3defffb87e1e0](https://www.virustotal.com/gui/file/2bd46a980dde8eaa13e3defffb87e1e0)|Win32 EXE||2011-09-22 07:33:33|f6af08e31471c98a_monusbwm.exe|
|[b5304f94cd5baae6fb5dad19c2759d2c](https://www.virustotal.com/gui/file/b5304f94cd5baae6fb5dad19c2759d2c)|Win32 EXE||2011-07-27 15:42:18|Java(TM) Update Sheduler|
|[1c658719e6dedb929a6d85359c59682d](https://www.virustotal.com/gui/file/1c658719e6dedb929a6d85359c59682d)|Win32 DLL|kazy|2011-06-24 00:48:39|/home/vega/CONTAGIO/apt/APT29/APT29_2013-04_Bitdefender_A Closer Look at MiniDuke/2011/_2011|
|[345adb4594e3a2b02041c7e2b5fde46b](https://www.virustotal.com/gui/file/345adb4594e3a2b02041c7e2b5fde46b)|Win32 DLL||2011-05-18 08:53:43|/home/support/SAMPLES/12|
|[91a50a90cb31fad48908d5c6294e92ba](https://www.virustotal.com/gui/file/91a50a90cb31fad48908d5c6294e92ba)|Win32 EXE|CosmicDuke|2011-04-15 12:57:12|Java(TM) Update Sheduler|
|[f7367f89d23e17d036a53662cc82882b](https://www.virustotal.com/gui/file/f7367f89d23e17d036a53662cc82882b)|Win32 EXE||2011-03-27 09:06:19|f7367f89d23e17d036a53662cc82882b|
|[baffad69d3ce95853a6db80711b74a38](https://www.virustotal.com/gui/file/baffad69d3ce95853a6db80711b74a38)|Win32 EXE||2011-02-20 07:14:56|Intel NGO|
|[704381812f4cc3c5b3875ea33232c842](https://www.virustotal.com/gui/file/704381812f4cc3c5b3875ea33232c842)|Win32 EXE|Zbot|2010-10-04 00:15:27|00000007.file|
|[35c6928790ce08309af997654ed6d719](https://www.virustotal.com/gui/file/35c6928790ce08309af997654ed6d719)|Win32 EXE|Zbot|2010-09-12 13:15:36|7d9296ac474b9917_dhcptapiinf.exe|
|[61c6d0076ee4187f9ec31841aa645d42](https://www.virustotal.com/gui/file/61c6d0076ee4187f9ec31841aa645d42)|Win32 EXE||2010-09-12 13:14:56|AMD Chipset Support|
|[cce1577e03093dcf195449d208e544d7](https://www.virustotal.com/gui/file/cce1577e03093dcf195449d208e544d7)|Win32 EXE||2010-09-08 20:33:08|Intel Chipset Support|
|[573b0f9dc06833bcfaea2147d28bcffc](https://www.virustotal.com/gui/file/573b0f9dc06833bcfaea2147d28bcffc)|Win32 EXE||2010-08-07 21:20:44|C:\Rfhh6G5\EnnVwCCI\zp10tOdqoS.dll|
|[ddeeebb34da3deea82ea1f4ff4c894a5](https://www.virustotal.com/gui/file/ddeeebb34da3deea82ea1f4ff4c894a5)|Win32 EXE||2010-07-18 03:36:55|c:/aa/aa|
|[cf2041ddfdc177b863a23ab7ade78043](https://www.virustotal.com/gui/file/cf2041ddfdc177b863a23ab7ade78043)|Win32 EXE|Festalco|2010-07-16 13:30:15|Intel Chipset Support|
|[0b78ad10bb56a3f69f13297e427806cf](https://www.virustotal.com/gui/file/0b78ad10bb56a3f69f13297e427806cf)|Win32 EXE|Festalco|2010-06-15 16:50:39|Intel Chipset Support|
|[26e8b95dfbc6a8aafe40ab84b1d2ab5e](https://www.virustotal.com/gui/file/26e8b95dfbc6a8aafe40ab84b1d2ab5e)|Win32 EXE|Festalco|2010-06-15 16:50:32|Intel Chipset Support|
|[b84a148f40c3a694b930c5374f7a90cb](https://www.virustotal.com/gui/file/b84a148f40c3a694b930c5374f7a90cb)|Win32 EXE||2010-05-31 17:27:39|C:\Users\<USER>\AppData\Local\Temp\objinfoms.exe|
|[3adea70969f52d365c119b3d25619de9](https://www.virustotal.com/gui/file/3adea70969f52d365c119b3d25619de9)|Win32 DLL||2010-05-21 21:04:57|c9f5a19c7b11fd86_advsec32.dll|
|[87f235c00e8c3960b264192621f594ae](https://www.virustotal.com/gui/file/87f235c00e8c3960b264192621f594ae)|Win32 EXE||2010-05-18 15:01:25| |
|[75c97ca9b085411af1860523c3c884b5](https://www.virustotal.com/gui/file/75c97ca9b085411af1860523c3c884b5)|Win32 EXE|Festalco|2010-04-17 22:38:40|Intel NGO|
|[bc304fb92a79bab73b75772427d14ffa](https://www.virustotal.com/gui/file/bc304fb92a79bab73b75772427d14ffa)|Win32 EXE||2010-04-14 16:58:03|Intel NGO|
|[78c6245367e6ef00ca76b8106eb73816](https://www.virustotal.com/gui/file/78c6245367e6ef00ca76b8106eb73816)|Win32 EXE||2010-04-14 16:55:25|Intel NGO|
|[fa52383868abf82d027b971e799a599a](https://www.virustotal.com/gui/file/fa52383868abf82d027b971e799a599a)|Win32 EXE||2010-04-14 15:52:45|Intel NGO|
|[ad02edae5173d0b7ba39a3065c9d5d63](https://www.virustotal.com/gui/file/ad02edae5173d0b7ba39a3065c9d5d63)|Win32 EXE||2010-04-13 10:30:06|Microsoft Host Process for Win32 Services|
|[52c73a7801a186077ed27a4cb7c7f887](https://www.virustotal.com/gui/file/52c73a7801a186077ed27a4cb7c7f887)|Win32 EXE||2010-04-08 19:11:49|52C73A7801A186077ED27A4CB7C7F887|
|[33c87cf8895a81706ca582efd922601b](https://www.virustotal.com/gui/file/33c87cf8895a81706ca582efd922601b)|Win32 EXE||2010-02-16 15:31:42|c:/aa/aa|
|[d34c6d5875f5d2aab929d1f7ce968860](https://www.virustotal.com/gui/file/d34c6d5875f5d2aab929d1f7ce968860)|Win32 EXE|vilsel|2010-01-22 11:20:31|MS Windows Context Switch Holder|
|[89b1e1c3c927f43d6d8108cf1422287a](https://www.virustotal.com/gui/file/89b1e1c3c927f43d6d8108cf1422287a)|Win32 EXE||2009-12-11 13:54:31|sample_89b1e1c3c927f43d6d8108cf1422287a|
|[45fb9f8733b3f0b26d38195b2c5ae54e](https://www.virustotal.com/gui/file/45fb9f8733b3f0b26d38195b2c5ae54e)|Win32 EXE||2009-09-10 18:25:18|ms_powerpoint_png.ex|
|[51138beea3e2c21ec44d0932c71762a8](https://www.virustotal.com/gui/file/51138beea3e2c21ec44d0932c71762a8)|Win32 EXE||2009-07-22 00:42:57|rundll32.exe|
|[c166d00faa2baf4851e51e46933461dd](https://www.virustotal.com/gui/file/c166d00faa2baf4851e51e46933461dd)|Win32 EXE||2009-07-02 18:44:54|c:/aa/aa|
|[db159b7a543cf0c0b84f00bd982482fc](https://www.virustotal.com/gui/file/db159b7a543cf0c0b84f00bd982482fc)|Win32 EXE||2009-06-27 08:27:32|C:\PwtdOL4Vgj\43shsN2Q8A.rtf|
|[59571740dcf8266c2205b901b6b489d1](https://www.virustotal.com/gui/file/59571740dcf8266c2205b901b6b489d1)|Win32 EXE||2009-04-30 21:43:12|test.txt|
|[75368a54b28acb89b2705b636ed5ec61](https://www.virustotal.com/gui/file/75368a54b28acb89b2705b636ed5ec61)|PDF|pidief|2009-04-29 00:44:25| |
|[8dcd3cb1e615edbfade8c2d9d6ef4c67](https://www.virustotal.com/gui/file/8dcd3cb1e615edbfade8c2d9d6ef4c67)|Win32 EXE||2009-03-17 22:15:39|test.txt|
|[c8cab28e550f60468099f60a0b6ccb81](https://www.virustotal.com/gui/file/c8cab28e550f60468099f60a0b6ccb81)|PDF|pidief|2009-03-10 19:47:22| |
|[969310a9775070c314377a9a4a665686](https://www.virustotal.com/gui/file/969310a9775070c314377a9a4a665686)|Win64 EXE|WellMess|2020-06-25 17:46:02|dttcodexgigas.a8e60df51c30106a7d1b0170cbb0a9ca7e167ca7|
|[11796e9e5567954ffe6eb9049f29acb2](https://www.virustotal.com/gui/file/11796e9e5567954ffe6eb9049f29acb2)|ELF executable|WellMess|2020-06-23 02:44:38|2daba469f50cd1b77481e605aeae0f28bf14cedfcd8e4369193e5e04c523bc38.sample|
|[a9485f3ecf7f35ba16a680a03d17c9ee](https://www.virustotal.com/gui/file/a9485f3ecf7f35ba16a680a03d17c9ee)|Win64 EXE||2020-06-18 13:05:06|dttcodexgigas.51379e74f85ede610cdc5aaf250fee4cdac5e3b0|
|[d4aed55bfbfe0afac5230d9827c63878](https://www.virustotal.com/gui/file/d4aed55bfbfe0afac5230d9827c63878)|ELF executable|WellMess|2020-05-25 10:24:00|watchdogd|
|[07854284dbd341cd695e24d7ca54162e](https://www.virustotal.com/gui/file/07854284dbd341cd695e24d7ca54162e)|ELF executable|WellMess|2020-05-17 10:55:11|0b8e6a11adaa3df120ec15846bb966d674724b6b92eae34d63b665e0698e0193_latest|
|[6c7ca0a40af4fe2b4527ff5260a39e48](https://www.virustotal.com/gui/file/6c7ca0a40af4fe2b4527ff5260a39e48)|ELF executable|WellMess|2020-05-17 10:26:34| |
|[d07992fe6abfb99e7fdddbc9f1a28d2c](https://www.virustotal.com/gui/file/d07992fe6abfb99e7fdddbc9f1a28d2c)|ELF executable|WellMess|2020-05-13 09:29:56|0b8e6a11adaa3df120ec15846bb966d674724b6b92eae34d63b665e0698e0193_to_Zero|
|[30247645638ff6d314c83044c831cdc4](https://www.virustotal.com/gui/file/30247645638ff6d314c83044c831cdc4)|ELF executable|WellMess|2020-05-12 13:05:43|ls_patched_2|
|[ee6420f6bccd3eb9510211c020129c0c](https://www.virustotal.com/gui/file/ee6420f6bccd3eb9510211c020129c0c)|Win32 EXE||2020-04-30 13:41:36|ee6420f6bccd3eb9510211c020129c0c.virus|
|[3a9cdd8a5cbc3ab10ad64c4bb641b41f](https://www.virustotal.com/gui/file/3a9cdd8a5cbc3ab10ad64c4bb641b41f)|ELF executable|WellMess|2020-04-23 02:41:45|5ca4a9f6553fea64ad2c724bf71d0fac2b372f9e7ce2200814c98aac647172fb.sample|
|[1d290d993eac8634b15b2204c3c011b4](https://www.virustotal.com/gui/file/1d290d993eac8634b15b2204c3c011b4)|Win64 EXE||2020-04-16 14:26:48|1d290d993eac8634b15b2204c3c011b4.virus|
|[18427cdcb5729a194954f0a6b5c0835a](https://www.virustotal.com/gui/file/18427cdcb5729a194954f0a6b5c0835a)|Win32 EXE|Ursu|2020-04-06 01:09:29|93e9383ae8ad2371d457fc4c1035157d887a84bbfe66fbbb3769c5637de59c75|
|[5988539d17d940cd7f51d9eb9fc2541c](https://www.virustotal.com/gui/file/5988539d17d940cd7f51d9eb9fc2541c)|ELF executable|WellMess|2020-04-01 09:39:44|watchdog.63|
|[dc146f77caaaea3deae053d9dc5a82d2](https://www.virustotal.com/gui/file/dc146f77caaaea3deae053d9dc5a82d2)|ELF executable|WellMess|2020-04-01 08:44:10|watchdog|
|[71fcbce4a9071e779dd9212cdffedc0a](https://www.virustotal.com/gui/file/71fcbce4a9071e779dd9212cdffedc0a)|Win64 EXE|WellMess|2020-03-31 18:15:19|avamar.exe|
|[a32e1202257a2945bf0f878c58490af8](https://www.virustotal.com/gui/file/a32e1202257a2945bf0f878c58490af8)|Win32 EXE||2020-03-30 03:11:41|SangforUD.exe|
|[e6399853def634dc8f8893f93158486d](https://www.virustotal.com/gui/file/e6399853def634dc8f8893f93158486d)|ELF executable|WellMess|2020-03-23 04:23:55|migration20|
|[429be60f0e444f4d9ba1255e88093721](https://www.virustotal.com/gui/file/429be60f0e444f4d9ba1255e88093721)|Win32 EXE|WellMess|2020-02-27 03:41:12|m.exe|
|[967fcf185634def5177f74b0f703bdc0](https://www.virustotal.com/gui/file/967fcf185634def5177f74b0f703bdc0)|Win32 EXE|Skeeyah|2020-01-24 21:46:49|SangforUD.exe|
|[c5d5cb99291fa4b2a68b5ea3ff9d9f9a](https://www.virustotal.com/gui/file/c5d5cb99291fa4b2a68b5ea3ff9d9f9a)|Win32 EXE||2020-01-21 00:02:13|SangforUD.exe|
|[e58b8de07372b9913ca2fbd3b103bb8f](https://www.virustotal.com/gui/file/e58b8de07372b9913ca2fbd3b103bb8f)|Win32 EXE|Ursu|2020-01-20 23:46:49|e58b8de07372b9913ca2fbd3b103bb8f.virus|
|[ae7a46529a0f74fb83beeb1ab2c68c5c](https://www.virustotal.com/gui/file/ae7a46529a0f74fb83beeb1ab2c68c5c)|ELF executable|WellMess|2019-10-12 14:25:27|watchdog|
|[69492c49fe10caebac8b56732467a7f4](https://www.virustotal.com/gui/file/69492c49fe10caebac8b56732467a7f4)|Win64 EXE|WellMess|2019-10-06 22:12:05| |
|[2f9f4f2a9d438cdc944f79bdf44a18f8](https://www.virustotal.com/gui/file/2f9f4f2a9d438cdc944f79bdf44a18f8)|ELF executable||2019-09-10 03:55:05|e329607379a01483fc914a47c0062d5a3a8d8d65f777fbad2c5a841a90a0af09.sample|
|[861879f402fe3080ab058c0c88536be4](https://www.virustotal.com/gui/file/861879f402fe3080ab058c0c88536be4)|ELF executable|WellMess|2019-09-09 01:16:01|watchdog-10.5.5.11|
|[01d322dcac438d2bb6bce2bae8d613cb](https://www.virustotal.com/gui/file/01d322dcac438d2bb6bce2bae8d613cb)|ELF executable||2019-07-30 09:58:47|ksoftirqd|
|[8777a9796565effa01b03cf1cea9d24d](https://www.virustotal.com/gui/file/8777a9796565effa01b03cf1cea9d24d)|ELF executable||2019-07-30 08:05:56|ksoftirqd|
|[4d38ac3319b167f6c8acb16b70297111](https://www.virustotal.com/gui/file/4d38ac3319b167f6c8acb16b70297111)|ELF executable|WellMess|2019-07-08 19:36:37| |
|[8ca29c265d8c41be7c2a463930e3e1b3](https://www.virustotal.com/gui/file/8ca29c265d8c41be7c2a463930e3e1b3)|Win64 EXE|WellMess|2019-03-12 14:16:40|bec1981e422c1e01c14511d384a33c9bcc66456c1274bbbac073da825a3f537d_dump7_0x00400000_reconstructed|
|[579d3af1b487ea3c442870eabe886a4f](https://www.virustotal.com/gui/file/579d3af1b487ea3c442870eabe886a4f)|Win32 EXE||2018-10-02 12:40:25|unp.exe|
|[b981736a057b888170148a91bcd86a59](https://www.virustotal.com/gui/file/b981736a057b888170148a91bcd86a59)|ELF executable||2018-07-30 00:31:37|perfc|
|[4a2b8954695b32322508e844ff7e74f5](https://www.virustotal.com/gui/file/4a2b8954695b32322508e844ff7e74f5)|Win32 EXE|WellMess|2018-04-11 09:01:41|conhost.exe|
|[05b5cf94f07fee666eb086c91182ad25](https://www.virustotal.com/gui/file/05b5cf94f07fee666eb086c91182ad25)|PPSX||2015-04-06 08:49:54|athirappalli.pps|
