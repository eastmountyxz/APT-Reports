**NAME:**  
Sidewinder  
  
**Alias**  
响尾蛇, APT-C-17, Sidewinder  
  
**Description**:   
SideWinder, disclosed by Tencent, is suspected to be an Indian APT group and carries out attacks against military targets in Pakistan and South Asia countries since 2012.
  
**References**:  
https://medium.com/@Sebdraven/apt-sidewinder-changes-theirs-ttps-to-install-their-backdoor-f92604a2739  
https://mp.weixin.qq.com/s/R8PuCGpUEbl8kXxNEeENHQ  
