|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f544a74de8264cd5b7bc184c81b78966](https://www.virustotal.com/gui/file/f544a74de8264cd5b7bc184c81b78966)|ELF shared library||2020-01-06 07:38:40|mtksuoppo|
|[9d71bc8643b0e309ea1d91903aea6555](https://www.virustotal.com/gui/file/9d71bc8643b0e309ea1d91903aea6555)|RTF||2019-12-17 06:33:35|Policy on Embedded Systems.doc|
|[aa7fd6d7d8bc06f7528975ca87133d1d](https://www.virustotal.com/gui/file/aa7fd6d7d8bc06f7528975ca87133d1d)|Win32 DLL||2019-12-09 03:38:44|DUSER.dll|
|[ff9d14b83f358a7a5be77af45a10d5a2](https://www.virustotal.com/gui/file/ff9d14b83f358a7a5be77af45a10d5a2)|Win32 DLL||2019-12-08 17:24:09|DUSER.dll|
|[4513f65bdf6976e93aa31b7a37dbb8b6](https://www.virustotal.com/gui/file/4513f65bdf6976e93aa31b7a37dbb8b6)|TXT||2019-12-07 15:29:34|%TEMP%\1.a|
|[3ee30a5cac2bef034767e159865683df](https://www.virustotal.com/gui/file/3ee30a5cac2bef034767e159865683df)|RTF||2019-12-07 06:02:16|main.file.rtf|
|[4ff9196bac6bf3c27421af411c57ba52](https://www.virustotal.com/gui/file/4ff9196bac6bf3c27421af411c57ba52)|RTF||2019-11-15 11:20:31|m.doc|
|[9b1d0537d0734f1ddb53c5567f5d7ab5](https://www.virustotal.com/gui/file/9b1d0537d0734f1ddb53c5567f5d7ab5)|DOCX||2019-11-15 07:37:40|ADVOCATE.docx|
|[827c5e51d180f621d392885b0bd536b3](https://www.virustotal.com/gui/file/827c5e51d180f621d392885b0bd536b3)|ELF shared library||2019-10-22 23:57:53|mtk-su|
|[65f66bc372ea1f372a8735e9862095da](https://www.virustotal.com/gui/file/65f66bc372ea1f372a8735e9862095da)|Text||2019-10-21 07:47:55|file.hta|
|[5e98ea66670fa34bf67054fb8a41979c](https://www.virustotal.com/gui/file/5e98ea66670fa34bf67054fb8a41979c)|TXT||2019-10-21 07:41:15|692cd02.hta|
|[7e23c62a81d2bfb90ef73047e170dea8](https://www.virustotal.com/gui/file/7e23c62a81d2bfb90ef73047e170dea8)|LNK||2019-10-21 07:34:14|Key_Points.doc.lnk|
|[497df762a3a7858c9a68dcbce24375fc](https://www.virustotal.com/gui/file/497df762a3a7858c9a68dcbce24375fc)|Win32 DLL||2019-10-21 02:44:45|497DF762A3A7858C9A68DCBCE24375FC.bin|
|[0b9e948dd5914deed01a05d86f5c978d](https://www.virustotal.com/gui/file/0b9e948dd5914deed01a05d86f5c978d)|Win32 DLL||2019-10-21 02:41:59|SystemApp.dll|
|[37a7cbb9ea0d399aafae48e25a9f867e](https://www.virustotal.com/gui/file/37a7cbb9ea0d399aafae48e25a9f867e)|RTF||2019-10-18 11:09:41|luan_nan_bao.doc|
|[3b70a0fbcc1fdf0c24ce298ef6a48e6c](https://www.virustotal.com/gui/file/3b70a0fbcc1fdf0c24ce298ef6a48e6c)|Win32 DLL||2019-10-16 11:46:42|bb|
|[bfad291d000b56ddd8a331d7283685b2](https://www.virustotal.com/gui/file/bfad291d000b56ddd8a331d7283685b2)|RTF||2019-10-09 23:38:41|zhengce.doc|
|[549d2310fd2b3f34ff95a86c48db53d8](https://www.virustotal.com/gui/file/549d2310fd2b3f34ff95a86c48db53d8)|RTF||2019-10-01 16:57:33|wenzhi_tiaoli.doc|
|[37166fa93d776147e545aad7e30b4160](https://www.virustotal.com/gui/file/37166fa93d776147e545aad7e30b4160)|RTF|CVE-2017-11882|2019-08-26 16:40:48| |
|[a9dbf0cbc46dfe0202b534c63bd52a4a](https://www.virustotal.com/gui/file/a9dbf0cbc46dfe0202b534c63bd52a4a)|C||2019-08-13 13:49:59|1.a|
|[58de7c0df5bd677e1a3cdc099019015d](https://www.virustotal.com/gui/file/58de7c0df5bd677e1a3cdc099019015d)|RTF|CVE-2017-11882|2019-08-11 16:32:03|SideWinder - original.rtf|
|[3d7da8b93d684e7d6a08fa230a87aa66](https://www.virustotal.com/gui/file/3d7da8b93d684e7d6a08fa230a87aa66)|RTF|CVE-2017-11882|2019-07-27 22:42:55| |
|[88678c5045fc9ed741282537ecad2c4e](https://www.virustotal.com/gui/file/88678c5045fc9ed741282537ecad2c4e)|Text||2019-07-24 05:48:54| |
|[4d59b084df25e9c6cba6343b753077b3](https://www.virustotal.com/gui/file/4d59b084df25e9c6cba6343b753077b3)|TXT||2019-07-15 17:49:14|file.hta|
|[050dd090b5af80fb73b2d6e6c8a3adc9](https://www.virustotal.com/gui/file/050dd090b5af80fb73b2d6e6c8a3adc9)|ZIP||2019-07-15 14:37:20|PassportchangeProfession.zip|
|[9eb7cbd46aa2aa624ae13acb64394b1c](https://www.virustotal.com/gui/file/9eb7cbd46aa2aa624ae13acb64394b1c)|ZIP||2019-07-14 20:25:02|.|
|[7af11efe4454dab75ad2338124be149d](https://www.virustotal.com/gui/file/7af11efe4454dab75ad2338124be149d)|ZIP||2019-07-06 12:05:14|Sponsorship-Benefits.zip|
|[e183fce03053423a0dd90f815a9c8fd9](https://www.virustotal.com/gui/file/e183fce03053423a0dd90f815a9c8fd9)|Win32 DLL|Stealer|2019-07-05 20:47:21|e183fce03053423a0dd90f815a9c8fd9.virus|
|[f4ba024d446c3e631770b920d334cc2c](https://www.virustotal.com/gui/file/f4ba024d446c3e631770b920d334cc2c)|Win32 EXE||2019-07-02 18:17:05|SeCEdit|
|[d2522e45c0b0d83dddd3fcc51862d48c](https://www.virustotal.com/gui/file/d2522e45c0b0d83dddd3fcc51862d48c)|LNK||2019-06-18 07:48:43|zzz.txt|
|[ab1608cb9967f3d08742cb1bbae2a67c](https://www.virustotal.com/gui/file/ab1608cb9967f3d08742cb1bbae2a67c)|RTF|CVE-2017-11882|2019-06-14 06:49:53| |
|[d79c33759c17ac7c2525e701d12a9b9c](https://www.virustotal.com/gui/file/d79c33759c17ac7c2525e701d12a9b9c)|Text|program|2019-05-27 22:45:12|stage2-hta.bin|
|[0da0b1578af124ea2bc1f223df52f6a9](https://www.virustotal.com/gui/file/0da0b1578af124ea2bc1f223df52f6a9)|Win32 DLL||2019-04-30 11:34:46|PreBotHta.dll|
|[5368863fd123f2e085be180897c3f583](https://www.virustotal.com/gui/file/5368863fd123f2e085be180897c3f583)|Win32 DLL||2019-04-30 11:31:55|LinkZip.dll|
|[52fa30ac4edc4c973a0a84f2e93f2432](https://www.virustotal.com/gui/file/52fa30ac4edc4c973a0a84f2e93f2432)|Win32 DLL|Ursu|2019-04-30 10:14:44|new 4~|
|[21cc890116adcf092d5a112716b6a55f](https://www.virustotal.com/gui/file/21cc890116adcf092d5a112716b6a55f)|Win32 DLL|Ursu|2019-04-28 03:13:34|Duser.dll1|
|[16e561159ee145008635c52a931b26c8](https://www.virustotal.com/gui/file/16e561159ee145008635c52a931b26c8)|Text||2019-04-25 09:16:02|final.hta1|
|[1fe3d9722db28c2f3291ff176b989c46](https://www.virustotal.com/gui/file/1fe3d9722db28c2f3291ff176b989c46)|RTF|CVE-2017-11882|2019-04-24 15:47:03|/var/www/clean-mx/virusesevidence/output.125157734.txt|
|[62606c6cff3867a582f9b31b018dfea5](https://www.virustotal.com/gui/file/62606c6cff3867a582f9b31b018dfea5)|Win32 DLL|Stealer|2019-04-24 15:46:32|myfile.exe|
|[549fb138b02c5420d6ea13f7a1a341b0](https://www.virustotal.com/gui/file/549fb138b02c5420d6ea13f7a1a341b0)|Email|oleink|2019-04-24 07:42:02|155600008311b6fa605581b50001RRsSfD.eml|
|[ce53ed2a093bbd788d49491851babffd](https://www.virustotal.com/gui/file/ce53ed2a093bbd788d49491851babffd)|Win32 DLL|Stealer|2019-04-23 19:59:11|.|
|[393497c43c760112714f3bb10f5170d2](https://www.virustotal.com/gui/file/393497c43c760112714f3bb10f5170d2)|DOCX|oleink|2019-04-23 09:49:41|STANDING OPERATING PROCEDURES FOR POLICE EMERGENCY THREAT LEVELS AND COLOR CODES FOR OPERATIONAL READINESS.docx|
|[29139545ca8610f2d84b2c65ee2800d6](https://www.virustotal.com/gui/file/29139545ca8610f2d84b2c65ee2800d6)|PDF||2019-04-14 10:10:33|job-instructions.pdf|
|[737f3ad2c727c7b42268bcacd00f8c66](https://www.virustotal.com/gui/file/737f3ad2c727c7b42268bcacd00f8c66)|Win32 DLL|Stealer|2019-04-13 16:18:53|a8ca6d51653866e8cbf5f63df5ac8220f829b5a1ec31e561496ad1c47cfff244.sample|
|[c71688a53272b8e3e3f83173a9059400](https://www.virustotal.com/gui/file/c71688a53272b8e3e3f83173a9059400)|Text||2019-04-11 08:56:36|c71688a53272b8e3e3f83173a9059400.virobj|
|[81f9eb617a2176ff0e561e34ef9ff503](https://www.virustotal.com/gui/file/81f9eb617a2176ff0e561e34ef9ff503)|Win32 DLL|Stealer|2019-03-05 20:06:41|.|
|[fb362fe18c3a0a150754a7a1ab068f1e](https://www.virustotal.com/gui/file/fb362fe18c3a0a150754a7a1ab068f1e)|Win32 DLL|Stealer|2019-03-05 14:15:07|7b6ec46bc619de754be553970c8989af55d4195a443beac73c04bd3a99b0aca7.sample|
|[f44a45e6f6273a7fb3d5cee145760362](https://www.virustotal.com/gui/file/f44a45e6f6273a7fb3d5cee145760362)|Win32 DLL|Stealer|2019-03-04 07:26:31|Duser.dll|
|[423194b0243870e8c82b35e5298ad7d7](https://www.virustotal.com/gui/file/423194b0243870e8c82b35e5298ad7d7)|Win32 DLL|Stealer|2019-03-04 04:36:06|.|
|[b5dbcb71ca158ee353955a69492c50c9](https://www.virustotal.com/gui/file/b5dbcb71ca158ee353955a69492c50c9)|RTF|CVE-2017-11882|2019-03-04 04:29:36|.|
|[4ab481d903afba53bd2de9bdb9eca6d4](https://www.virustotal.com/gui/file/4ab481d903afba53bd2de9bdb9eca6d4)|RTF|CVE-2017-0199|2019-03-04 03:31:23| |
|[a1ca53efda160b31ebf07d8553586264](https://www.virustotal.com/gui/file/a1ca53efda160b31ebf07d8553586264)|RTF|CVE-2017-11882|2019-02-07 18:48:19|.|
|[90e9f50e8e799dd340e09793a49a3521](https://www.virustotal.com/gui/file/90e9f50e8e799dd340e09793a49a3521)|Win32 DLL|Stealer|2019-01-29 05:20:43|90e9f50e8e799dd340e09793a49a3521.virus|
|[032d584f6c01cc184bf07cdec713e74d](https://www.virustotal.com/gui/file/032d584f6c01cc184bf07cdec713e74d)|Win32 DLL|Stealer|2019-01-24 02:42:54| |
|[e021a9e4eea1bf7d494269d20510e82c](https://www.virustotal.com/gui/file/e021a9e4eea1bf7d494269d20510e82c)|Win32 DLL|Stealer|2019-01-17 15:11:57|myfile.exe|
|[2d9655c659970145ab3f2d74bb411c5d](https://www.virustotal.com/gui/file/2d9655c659970145ab3f2d74bb411c5d)|Win32 DLL|Stealer|2019-01-17 09:45:10| |
|[b956496c28306c906fddf08ded1cdf65](https://www.virustotal.com/gui/file/b956496c28306c906fddf08ded1cdf65)|RTF|CVE-2017-11882|2018-11-08 07:24:19|pmo.doc|
|[358450e19d38db77c236f45881dcebef](https://www.virustotal.com/gui/file/358450e19d38db77c236f45881dcebef)|Win32 EXE||2018-10-12 15:39:36|proquota|
|[3725b4be01ef82438c22ede9e947e487](https://www.virustotal.com/gui/file/3725b4be01ef82438c22ede9e947e487)|ZIP||2018-10-12 15:39:32|codexgigas_2aa992959f53b1d228b48191553bbf07790d474c|
|[29325cdbde5e0cf60d277aa2d9ba4537](https://www.virustotal.com/gui/file/29325cdbde5e0cf60d277aa2d9ba4537)|Win32 DLL||2018-10-12 15:39:30|codexgigas_26346fb58da3bec503adf49200c8b1623ba4ee61|
|[fdca2916dd94a9e0d48167c2041ee717](https://www.virustotal.com/gui/file/fdca2916dd94a9e0d48167c2041ee717)|Targa||2018-10-12 15:39:29|codexgigas_1b511d2583b7473bf01e89d0bb65385f5e140ae2|
|[d1c3fa000154dbccd6e5485a10550a29](https://www.virustotal.com/gui/file/d1c3fa000154dbccd6e5485a10550a29)|RTF|CVE-2017-11882|2018-10-12 15:39:27|main.RTF|
|[1057edc5e8406d76741d5ea3be790e03](https://www.virustotal.com/gui/file/1057edc5e8406d76741d5ea3be790e03)|unknown||2018-10-12 15:39:24|codexgigas_5a0e6bd24cc07b68ba17ff372ab35896e5e4421d|
|[f5919f70371520645f4765bcc385bef4](https://www.virustotal.com/gui/file/f5919f70371520645f4765bcc385bef4)|RTF|CVE-2017-11882|2018-09-26 07:46:45|2018 Bilateral Training in China.doc|
|[2c2c8f0ecc63894ef73a06819ba0e412](https://www.virustotal.com/gui/file/2c2c8f0ecc63894ef73a06819ba0e412)|Win32 DLL||2018-07-18 08:17:12|cmpbk32.dll|
|[e4eddf1e8b0adc08220ad245a3365847](https://www.virustotal.com/gui/file/e4eddf1e8b0adc08220ad245a3365847)|Text||2018-07-18 00:09:10|final.hta|
|[c986635c40764f10bcebe280b05efe8c](https://www.virustotal.com/gui/file/c986635c40764f10bcebe280b05efe8c)|RTF||2018-05-17 11:32:13|CALS Renewal procedure.doc|
|[204860ce22c81c6d9de763c09e989a20](https://www.virustotal.com/gui/file/204860ce22c81c6d9de763c09e989a20)|Win32 EXE||2018-05-15 11:32:17|eventvwr|
|[c0f15436912d8a63dbb7150d95e6a4ee](https://www.virustotal.com/gui/file/c0f15436912d8a63dbb7150d95e6a4ee)|RTF|CVE-2017-11882|2018-05-15 05:49:23|2018 Bilateral Training in China.doc|
|[3cd725172384297732222ef9c8f74adc](https://www.virustotal.com/gui/file/3cd725172384297732222ef9c8f74adc)|RTF||2018-05-04 11:34:58|08b9b5b7592004b8733544df1029e2fc085d82db1ba488a43830df49bbbc73b6.bin|
|[f03c0390d0a655450f1b10ea4057b06e](https://www.virustotal.com/gui/file/f03c0390d0a655450f1b10ea4057b06e)|Win32 DLL||2018-04-12 12:52:26|myfile.exe|
|[444438f4ce76156cec1788392f887da6](https://www.virustotal.com/gui/file/444438f4ce76156cec1788392f887da6)|RTF||2018-04-04 10:10:25|Fund Allocation Policy.doc|
|[2cb633375a5965f86360e761363d9f2f](https://www.virustotal.com/gui/file/2cb633375a5965f86360e761363d9f2f)|Win32 DLL|Zbot|2017-11-29 11:15:20|1002-5de6e37cb7bc18b1be0dbf5b5908fec1eda3c047|
|[dbb45a0839719312f248351e3fb9a0ae](https://www.virustotal.com/gui/file/dbb45a0839719312f248351e3fb9a0ae)|Win32 EXE||2010-02-13 02:24:38|7092f1ddb58d11d7_cmdl32.exe|
|[5343a19c618bc515ceb1695586c6c137](https://www.virustotal.com/gui/file/5343a19c618bc515ceb1695586c6c137)|Win32 DLL||2009-12-13 09:13:12|(Image2629)_Windows_System32_msvbvm60.dll|
|[73bdde7e0f9ea29fdad03eeb7312b4d3](https://www.virustotal.com/gui/file/73bdde7e0f9ea29fdad03eeb7312b4d3)|ZIP||2020-04-10 04:39:04|Pak_Army_Deployed_in_Country_in_Fight_Against_Coronavirus (10).zip|
|[120e3733e167fcabdfd8194b3c49560b](https://www.virustotal.com/gui/file/120e3733e167fcabdfd8194b3c49560b)|LNK||2020-04-06 20:21:05|Additional_CSD_Rebate.pdf.lnk|
|[3c9f64763a24278a6f941e8807725369](https://www.virustotal.com/gui/file/3c9f64763a24278a6f941e8807725369)|LNK||2020-04-06 11:04:17|Pak_Army_Deployed_in_Country_in_Fight_Against_Coronavirus.pdf.lnk|
|[fef12d62a3b2fbf1d3be1f0c71ae393e](https://www.virustotal.com/gui/file/fef12d62a3b2fbf1d3be1f0c71ae393e)|RTF|CVE-2017-11882|2020-03-28 17:38:23|.|
|[58363311f04f03c6e9ccd17b780d03b2](https://www.virustotal.com/gui/file/58363311f04f03c6e9ccd17b780d03b2)|RTF|CVE-2017-11882|2020-03-24 04:00:07|/var/www/clean-mx/virusesevidence/output.153111507.txt|
|[26a7c3273e8e398ab13519793ff44626](https://www.virustotal.com/gui/file/26a7c3273e8e398ab13519793ff44626)|TXT||2020-02-25 13:16:15|/var/www/clean-mx/virusesevidence/output.149965783.txt|
|[cbf120f20fc4fc67e1b0c4a3694f0e58](https://www.virustotal.com/gui/file/cbf120f20fc4fc67e1b0c4a3694f0e58)|Win32 DLL|Starter|2019-12-25 17:27:38|DUSER.dll|
|[7442b3efecb909cfff4aea4ecaae98d8](https://www.virustotal.com/gui/file/7442b3efecb909cfff4aea4ecaae98d8)|LNK|Banload|2019-04-26 13:28:06|daraz-coupon.pdf.lnk|
|[3ad3ddc1e8ada7f6a4fe0800b578ee4a](https://www.virustotal.com/gui/file/3ad3ddc1e8ada7f6a4fe0800b578ee4a)|TXT||2020-10-15 08:49:25|%TEMP%\1.a|
|[2ba61596f9ec352eebe6e410a25867f6](https://www.virustotal.com/gui/file/2ba61596f9ec352eebe6e410a25867f6)|RTF|CVE-2017-11882|2020-10-15 08:48:20|MoU's.doc|
|[1cf37a0a8a5f5704a3df692d84a16a71](https://www.virustotal.com/gui/file/1cf37a0a8a5f5704a3df692d84a16a71)|RTF|o97m|2020-09-24 11:50:27|Protocol.doc|
|[4e804c96ef8544be3b56213f8e6cf016](https://www.virustotal.com/gui/file/4e804c96ef8544be3b56213f8e6cf016)|LNK||2020-09-22 20:14:38|Audit_Observation2019.pdf.lnk|
|[7680ea7601c90078f07f7b9be1944b3b](https://www.virustotal.com/gui/file/7680ea7601c90078f07f7b9be1944b3b)|Win32 DLL||2020-09-10 00:13:07|e890dadff013b7dc40e7b7857e435d6cf5b4da79758cf7e2328ae56ce000acdb.sample|
|[524f3992a5a8fec81da1b660eb60129f](https://www.virustotal.com/gui/file/524f3992a5a8fec81da1b660eb60129f)|DOCX||2020-06-29 10:56:51| |
|[cf18974bb2f68e7d9d172d939a4ba313](https://www.virustotal.com/gui/file/cf18974bb2f68e7d9d172d939a4ba313)|TXT|Kryptik|2020-05-16 08:22:33|악성코드46.hta|
|[4dc475b2055b5a880cbd67526b0f6e3c](https://www.virustotal.com/gui/file/4dc475b2055b5a880cbd67526b0f6e3c)|TXT|Kryptik|2020-05-14 12:49:32|3387c59|
|[265222bbe164d55750ca0ee1a53f2de2](https://www.virustotal.com/gui/file/265222bbe164d55750ca0ee1a53f2de2)|TXT|Kryptik|2020-05-14 11:32:31|extract-1589360921.153124-HTTP-FdJDvV1b1rPiJecXfa|
|[4e5deecb468ab36c5fe347a39878c949](https://www.virustotal.com/gui/file/4e5deecb468ab36c5fe347a39878c949)|TXT|Kryptik|2020-05-14 03:48:29|file.hta|
|[affbb0cf97289220b88dee2961e0a4b3](https://www.virustotal.com/gui/file/affbb0cf97289220b88dee2961e0a4b3)|TXT||2020-05-14 01:18:35|malicious.hta|
|[865e7c8013537414b97749e7a160a94e](https://www.virustotal.com/gui/file/865e7c8013537414b97749e7a160a94e)|ZIP||2020-05-13 06:28:38|Policy Guidelines for Online Classes.zip|
|[2c798c915568b3fd8ee7909c45a43168](https://www.virustotal.com/gui/file/2c798c915568b3fd8ee7909c45a43168)|RTF|Sagent|2020-04-21 18:39:36|%TEMP%\2c798c915568b3fd8ee7909c45a43168.rtf|
|[dbb09fd0da004742cac805150dbc01ca](https://www.virustotal.com/gui/file/dbb09fd0da004742cac805150dbc01ca)|RTF||2020-04-20 18:16:37|%TEMP%\dbb09fd0da004742cac805150dbc01ca.rtf|
|[f6d29ca878f0815935fc1de2def06c46](https://www.virustotal.com/gui/file/f6d29ca878f0815935fc1de2def06c46)|RTF|o97m|2020-04-14 15:04:51|main.file.rtf|
|[3e0c08851aafbca17dda7ce54ba52cb9](https://www.virustotal.com/gui/file/3e0c08851aafbca17dda7ce54ba52cb9)|TXT|Sagent|2020-04-08 16:16:44| |
|[40fd59323c3883717faca9424b29b9aa](https://www.virustotal.com/gui/file/40fd59323c3883717faca9424b29b9aa)|TXT||2020-04-06 11:16:55|cb2e3e0[1].hta|
|[7a4f9c2e5a60ec498c66d85d2df351e8](https://www.virustotal.com/gui/file/7a4f9c2e5a60ec498c66d85d2df351e8)|TXT|Nemucod|2020-04-06 11:11:53|966029e.hta|
|[4476ee858c455a84031d3f54a0dfe73d](https://www.virustotal.com/gui/file/4476ee858c455a84031d3f54a0dfe73d)|RTF|o97m|2020-02-05 14:48:52|6EF6D4C78AB11FE85D461AB71E3177666FAFD798|
|[bad0917fdb0963903747e86c33b74c08](https://www.virustotal.com/gui/file/bad0917fdb0963903747e86c33b74c08)|RTF|CVE-2017-11882|2020-01-14 13:37:11|%TEMP%\bad0917fdb0963903747e86c33b74c08.rtf|
