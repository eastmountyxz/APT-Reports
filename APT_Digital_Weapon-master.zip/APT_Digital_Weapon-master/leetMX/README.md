**NAME:**  
leetMX  

**Description**:   
According to ClearSky’s report, leetMX is a widespread cyber-attack campaign originating from Mexico and focused on targets in Mexico, El Salvador, and other countries in Latin America, such as Guatemala, Argentina and Costa Rica. It has been operating since at least November 2016.
  
**References**:  
https://www.clearskysec.com/leetmx/
