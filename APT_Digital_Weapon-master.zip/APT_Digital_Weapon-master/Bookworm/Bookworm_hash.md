|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[0b4ad1bd093e0a2eb8968e308e900180](https://www.virustotal.com/gui/file/0b4ad1bd093e0a2eb8968e308e900180)|Win32 EXE||2019-09-26 06:29:42| |
|[9df45e8d8619e234d0449daf2f617ba3](https://www.virustotal.com/gui/file/9df45e8d8619e234d0449daf2f617ba3)|Win32 EXE|PlugX|2018-05-02 14:03:46|bombs.exe|
|[210816c8bde338bf206f13bb923327a1](https://www.virustotal.com/gui/file/210816c8bde338bf206f13bb923327a1)|Win32 EXE|PlugX|2015-11-12 04:22:16|0|
|[5282b503b061eaa843c0bcda1c74b14f](https://www.virustotal.com/gui/file/5282b503b061eaa843c0bcda1c74b14f)|Win32 EXE|PlugX|2015-11-11 22:05:43| |
|[3e69c34298a8fd5169259a2fef506d63](https://www.virustotal.com/gui/file/3e69c34298a8fd5169259a2fef506d63)|Win32 EXE|PlugX|2015-11-05 06:18:32|dad.exe|
|[5e4852c8e5ef3cbceb69a9bc3d554d6c](https://www.virustotal.com/gui/file/5e4852c8e5ef3cbceb69a9bc3d554d6c)|Win32 EXE|Zlob|2015-11-04 00:49:40|setup_xcrsvr.exe|
|[35755a6839f3c54e602d777cd11ef557](https://www.virustotal.com/gui/file/35755a6839f3c54e602d777cd11ef557)|Win32 EXE|PlugX|2015-10-08 10:42:47|bomb.exe|
|[40f1b160b88ff98934017f3f1e7879a5](https://www.virustotal.com/gui/file/40f1b160b88ff98934017f3f1e7879a5)|Win32 EXE|PlugX|2015-09-26 04:47:49|bookworm.exe|
|[0f41c853a2d522e326f2c30b4b951b04](https://www.virustotal.com/gui/file/0f41c853a2d522e326f2c30b4b951b04)|Win32 EXE|PlugX|2015-09-24 07:17:36|VID235513764.exe|
|[599b6e05a38329081b80a461b57cec37](https://www.virustotal.com/gui/file/599b6e05a38329081b80a461b57cec37)|Win32 EXE|PlugX|2015-09-18 19:22:20|599B6E05A38329081B80A461B57CEC37.A66B26B7|
|[87d71401e2b8978c2084eb9a1d59c172](https://www.virustotal.com/gui/file/87d71401e2b8978c2084eb9a1d59c172)|Win32 EXE|PlugX|2015-09-08 03:27:31|b9724fbeb53739629441c0e99e47e85939fef419|
|[29df124f370752a87b3426dcad539ec6](https://www.virustotal.com/gui/file/29df124f370752a87b3426dcad539ec6)|Win32 EXE|PlugX|2015-09-07 20:04:03|setup_msmpeng.exe|
|[74c293acdda0d2c3b5087763dae27ec6](https://www.virustotal.com/gui/file/74c293acdda0d2c3b5087763dae27ec6)|Win32 EXE|PlugX|2015-09-07 04:43:52|1|
|[fcd68032c39cca3385c539ea38914735](https://www.virustotal.com/gui/file/fcd68032c39cca3385c539ea38914735)|CAB|PlugX|2015-09-07 04:41:54| |
|[ba1aea40182861e1d1de8c0c2ae78cb7](https://www.virustotal.com/gui/file/ba1aea40182861e1d1de8c0c2ae78cb7)|Win32 EXE|PlugX|2015-09-03 09:11:38|flashplayer18ax_ma_install.exe|
|[cba74e507e9741740d251b1fb34a1874](https://www.virustotal.com/gui/file/cba74e507e9741740d251b1fb34a1874)|Win32 EXE|PlugX|2015-09-03 04:05:14|flashplayer18_a_install.exe|
|[de1595a7585219967a87a909f38acaa2](https://www.virustotal.com/gui/file/de1595a7585219967a87a909f38acaa2)|Win32 EXE|PlugX|2015-08-31 07:09:49|police.exe|
|[b030c619bb24804cbcc05065530fcf2e](https://www.virustotal.com/gui/file/b030c619bb24804cbcc05065530fcf2e)|Win32 EXE|PlugX|2015-08-26 17:52:17| |
|[8ae2468d3f208d07fb47ebb1e0e297d7](https://www.virustotal.com/gui/file/8ae2468d3f208d07fb47ebb1e0e297d7)|Win32 EXE|PlugX|2015-08-21 03:23:10|bomb.exe|
|[0d57d2bef1296be62a3e791bfad33bcd](https://www.virustotal.com/gui/file/0d57d2bef1296be62a3e791bfad33bcd)|Win32 EXE||2015-08-07 08:43:30|0d57d2bef1296be62a3e791bfad33bcd.vir|
