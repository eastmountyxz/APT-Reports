**NAME:**  
Bookworm  
  
**Description**:   
Based on the contents of the associated decoys documents, as well as several of the dynamic DNS domain names used to host C2 servers, it is speculated that Bookworm targets organizations in Thailand to grab confidential intelligence.
  
**References**:  
https://unit42.paloaltonetworks.com/bookworm-trojan-a-model-of-modular-architecture/  