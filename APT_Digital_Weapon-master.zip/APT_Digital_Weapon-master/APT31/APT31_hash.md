|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[bd26122b29ece6ce5abafb593ff7b096](https://www.virustotal.com/gui/file/bd26122b29ece6ce5abafb593ff7b096)|Win64 EXE|pswtool|2020-08-21 05:37:50|OneDrive.exe|
|[f3896d4a29b4a2ea14ea8a7e2e500ee5](https://www.virustotal.com/gui/file/f3896d4a29b4a2ea14ea8a7e2e500ee5)|FPX|Dapato|2020-08-20 21:34:19|7f0784de102e7adbb59a39e3f5e37e6bd5b57515d9d642c69d05809ad266655b.bin|
|[077ebc3535b38742307ef1c9e3f95222](https://www.virustotal.com/gui/file/077ebc3535b38742307ef1c9e3f95222)|FPX|Dapato|2020-08-20 21:34:12|b6087bb0059e7e8d33e2d34a48e3f1db439e01fcd8856e7159428e9562df7067.bin|
|[b4112b0700be2343422c759f5dc7bb8b](https://www.virustotal.com/gui/file/b4112b0700be2343422c759f5dc7bb8b)|FPX|Dapato|2020-08-20 21:34:04|3b584c45cf77a968ab90d6e9a8e2b4779c96ed088d9097c154d0226a93dcd883.bin|
|[daa7045a5c607fc2ae6fe0804d493cea](https://www.virustotal.com/gui/file/daa7045a5c607fc2ae6fe0804d493cea)|FPX|Dapato|2020-08-20 21:33:56|9f358ad9515c63872655ce6cce0525e89a650898ffc4e357db93e19f33e61080.bin|
|[fc4995e931f0ff717fe6a6189f07af64](https://www.virustotal.com/gui/file/fc4995e931f0ff717fe6a6189f07af64)|Win64 EXE|pswtool|2020-08-19 06:45:32|4f36c1b7550c5765cadc9cc07758787649d3372e6ad6655f143150fb14e08cfd.bin|
|[3347a1409f0236904beaceba2c8c7d56](https://www.virustotal.com/gui/file/3347a1409f0236904beaceba2c8c7d56)|FPX|Dapato|2020-08-18 23:54:28|b7571fe26056b7baa31b0935b6be42c8fa1d55a742c26d58b1c2e017394adc14.bin|
