**NAME:**  
APT31

 
**Description**:   
Crowdstrike pointed out that it is suspected to target upstream suppliers (such as law firms and custodial service providers) to support other intrusions into well-known assets. In 2018, CrowdStrike observed that this adversary used spear phishing, network vulnerabilities and scheduled tasks to obtain credentials automatically.
  
**References**:  
https://www.crowdstrike.com/blog/cyber-deterrence-in-action-a-story-of-one-long-hurricane-panda-campaign
