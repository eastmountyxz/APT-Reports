**NAME:**  
LUNAR SPIDER  

**Description**:   
The LUNAR SPIDER threat group, disclosed by CrowdStrike, is the Eastern European-based operator and developer of the commodity banking malware called BokBot (aka IcedID), which was first observed in April 2017.
  
**References**:  
https://www.crowdstrike.com/blog/sin-ful-spiders-wizard-spider-and-lunar-spider-sharing-the-same-web/

