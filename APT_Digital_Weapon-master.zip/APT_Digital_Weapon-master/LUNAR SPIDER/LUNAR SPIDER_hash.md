|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c4df864cf6515dc924eaaf1bb7d1c6fb](https://www.virustotal.com/gui/file/c4df864cf6515dc924eaaf1bb7d1c6fb)|Win32 EXE|injector|2019-02-06 09:25:30|myfile.exe|
|[90948b766755b8bf9e7941725d1734d8](https://www.virustotal.com/gui/file/90948b766755b8bf9e7941725d1734d8)|Win32 EXE|TrickBot|2019-02-05 16:33:09|Library_Sys|
