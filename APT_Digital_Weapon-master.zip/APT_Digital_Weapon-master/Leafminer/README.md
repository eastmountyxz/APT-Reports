**NAME:**  
Leafminer  
  
**Alias**  
RASPITE, Leafminer  
  
**Description**:   
Leafminer, uncovered by Symantec, is an Iranian threat group that targeting a broad list of government organizations and business verticals in various regions in the Middle East since at least early 2017.
  
**References**:  
https://www.jpost.com/Israel-News/Politics-And-Diplomacy/Report-Iran-targeted-Israel-in-cyber-attack-563937
