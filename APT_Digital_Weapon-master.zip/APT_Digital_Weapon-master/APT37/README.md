**NAME:**  
APT37  
  
**Alias**  
Reaper group, Geumseong121, Group 123, Scarcruft, APT-S-008, Red Eyes, TEMP.Reaper, Ricochet Chollima, sun team, APT37  
  
**Description**:   
APT37 is a suspected North Korean cyber espionage group that has been in operation since at least 2012. Their targets are primarily located in South Korea, but also Japan, Vietnam, Russia, China, India, and some of the countries in the Middle East. A wider range of industries are affected, including chemicals, electronics, manufacturing, aerospace, automotive and healthcare entities
  
**References**:  
https://www2.fireeye.com/rs/848-DID-242/images/rpt_APT37.pdf  
https://securelist.com/operation-daybreak/75100/  
https://securelist.com/scarcruft-continues-to-evolve-introduces-bluetooth-harvester/90729/  
