|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[366defa5b85a044aac3dcc96ca4b7fbe](https://www.virustotal.com/gui/file/366defa5b85a044aac3dcc96ca4b7fbe)|unknown||2019-02-11 20:23:39|1910f5ddb0fc0438a3e2a553c97559557898e6310bf7e37b13cf3013fd66ea75.vbs.bin|
|[539d00b4f198967d32e3289d5f7a1bf4](https://www.virustotal.com/gui/file/539d00b4f198967d32e3289d5f7a1bf4)|unknown|Nemucod|2018-11-06 07:59:21|%APPDATA%\roaming\microsoft\protect\update.vbs|
|[0f03d46fba7659dcfbb9633ca6dbdf63](https://www.virustotal.com/gui/file/0f03d46fba7659dcfbb9633ca6dbdf63)|Text|Nemucod|2018-09-02 11:08:21|%APPDATA%\roaming\word|
|[e3de33496a50de23b997d43dcc42d4ed](https://www.virustotal.com/gui/file/e3de33496a50de23b997d43dcc42d4ed)|unknown|Nemucod|2018-08-25 07:46:28|=?UTF-8?B?2KrZgtiv2YrYsSDZhdmI2YLZgS3Yrtin2LUg2KjYp9mE2KXYrtmI2KkudmJz?=|
|[0ead162ad62eff2859cf35e00721dd82](https://www.virustotal.com/gui/file/0ead162ad62eff2859cf35e00721dd82)|unknown|Nemucod|2018-08-25 07:45:39|=?UTF-8?B?2KrZgtiv2YrYsSDZhdmI2YLZgS3Yrtin2LUg2KjYp9mE2KXYrtmI2KkuZG9jLnZicw==?=|
|[09c1fd5b2a4312eb98b4e112fb4deab1](https://www.virustotal.com/gui/file/09c1fd5b2a4312eb98b4e112fb4deab1)|unknown|Nemucod|2018-08-05 15:32:38|myvtfile.exe|
|[c9410a6c342327bdef6cd777344e4b35](https://www.virustotal.com/gui/file/c9410a6c342327bdef6cd777344e4b35)|unknown||2018-07-30 09:46:31|تقدير موقف-خاص بالإخوة.doc.vbs|
