**NAME:**  
WIRTE  
  
**Alias**  
WIRTE Group, WIRTE  
 
**Description**:   
WIRTE, identified by the Intelligence Development Group of S2 Grupo, attacked the Middle East without using very sophisticated mechanisms in August 2018.
  
**References**:  
https://www.securityartwork.es/2019/01/25/wirte-group-attacking-the-middle-east/
