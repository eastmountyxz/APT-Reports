|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[a0ef3ec023a8c1d6a104ebcb9efe2fbe](https://www.virustotal.com/gui/file/a0ef3ec023a8c1d6a104ebcb9efe2fbe)|Win32 EXE||2019-08-30 10:09:41|win7.exe|
|[17666d1c19811c30ba1692642cd1733b](https://www.virustotal.com/gui/file/17666d1c19811c30ba1692642cd1733b)|Win32 EXE||2019-08-30 09:10:51|C:\users\public\documents\alyacservice\alyacservice.exe|
|[ac25e913fcf6c8d7ca8dc3dfed0cebf0](https://www.virustotal.com/gui/file/ac25e913fcf6c8d7ca8dc3dfed0cebf0)|Win32 EXE|Wapomi|2019-06-01 20:50:03|$RXUCYZK.EXE|
|[28cbde363c1a9b8e7252fba5cbb72d11](https://www.virustotal.com/gui/file/28cbde363c1a9b8e7252fba5cbb72d11)|Win32 EXE|Wapomi|2019-06-01 20:49:53|$RTCIXMM.EXE|
|[d7916909912a0903b0037e96f731ae25](https://www.virustotal.com/gui/file/d7916909912a0903b0037e96f731ae25)|Win32 EXE||2019-06-01 20:49:49|$RGYEWCM.EXE|
|[0c6cbf288d94a85d0fb9e727db492300](https://www.virustotal.com/gui/file/0c6cbf288d94a85d0fb9e727db492300)|Win32 EXE|Wapomi|2019-06-01 20:49:42|$RQD09VN.EXE|
|[eb5bb97f79a7a41501efd56175704339](https://www.virustotal.com/gui/file/eb5bb97f79a7a41501efd56175704339)|Win32 EXE||2019-06-01 20:49:34|$RJ48CW4.EXE|
|[4e77d769514d476d598f17e31f165cc4](https://www.virustotal.com/gui/file/4e77d769514d476d598f17e31f165cc4)|Text||2019-03-06 10:21:21| |
|[c3b1bd4e3e159591d84e77452a09851d](https://www.virustotal.com/gui/file/c3b1bd4e3e159591d84e77452a09851d)|Win32 EXE|razy|2019-01-20 23:49:47|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/RogueRobinBackdoorDarkHyrdus.false|
|[89e50d52e498c34f1e976cf9a1017a39](https://www.virustotal.com/gui/file/89e50d52e498c34f1e976cf9a1017a39)|XLSM|o97m|2019-01-20 23:44:10|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/RogueRobinMSExcelDropper.bin|
|[b108412f1cdc0602d82d3e6b318dc634](https://www.virustotal.com/gui/file/b108412f1cdc0602d82d3e6b318dc634)|Win32 EXE||2019-01-10 10:33:42|DNSProject.exe|
|[039bd47f0fdb6bb7d68a2428c71f317d](https://www.virustotal.com/gui/file/039bd47f0fdb6bb7d68a2428c71f317d)|Win32 EXE||2019-01-09 14:21:24|DNSProject.exe|
|[5c3f96ade0ea67eef9d25161c64e6f3e](https://www.virustotal.com/gui/file/5c3f96ade0ea67eef9d25161c64e6f3e)|XLSM||2019-01-09 08:33:50|=?UTF-8?B?2KfZhNmB2YfYp9ix2LMueGxzbQ==?=|
|[8dc9f5450402ae799f5f8afd5c0a8352](https://www.virustotal.com/gui/file/8dc9f5450402ae799f5f8afd5c0a8352)|XLSM||2019-01-09 08:27:23|=?UTF-8?B?2KfZhNin2LfZhNin2LkueGxzbQ==?=|
|[21e9451af7c59a4a136f4046d036352a](https://www.virustotal.com/gui/file/21e9451af7c59a4a136f4046d036352a)|Win32 EXE||2018-07-30 11:09:27|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/DarkHydrus.bin|
|[9dd647d509a3306cb11dbdb3cd8968cc](https://www.virustotal.com/gui/file/9dd647d509a3306cb11dbdb3cd8968cc)|XML|CVE-2018-8414|2018-07-24 15:02:27|abc.SettingContent-MS|
|[953a753dd4944c9a2b9876b090bf7c00](https://www.virustotal.com/gui/file/953a753dd4944c9a2b9876b090bf7c00)|TXT|Kryptik|2018-07-17 13:59:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/RogueRobinPowershellPayloadObfuscated.bin|
|[bd764192e951b5afd56870d2084bccfd](https://www.virustotal.com/gui/file/bd764192e951b5afd56870d2084bccfd)|TXT||2018-07-17 13:58:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/DarkHydrusPowershellScript.bin|
|[377cfd5b9aad2473d1659a5dbad01d90](https://www.virustotal.com/gui/file/377cfd5b9aad2473d1659a5dbad01d90)|TXT||2018-07-16 08:45:05|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/DarkHydrusPayload.bin|
|[e2b78a69d59579d99213fcbd5bb8d924](https://www.virustotal.com/gui/file/e2b78a69d59579d99213fcbd5bb8d924)|DOCX|rozena|2017-11-15 06:40:38|e2b78a69d59579d99213fcbd5bb8d924.virus|
|[95edfcb1af1a8d615220f6c16dbb1c31](https://www.virustotal.com/gui/file/95edfcb1af1a8d615220f6c16dbb1c31)|DOCX||2017-11-13 04:30:52|95edfcb1af1a8d615220f6c16dbb1c31.virus|
|[ab9cf050fb3f4fadf3eb080e09995cda](https://www.virustotal.com/gui/file/ab9cf050fb3f4fadf3eb080e09995cda)|Win32 EXE|rozena|2017-11-01 15:05:23|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/DarkHydrus/DarkHydrusImplant.bin|
|[61e25b25240f596b3adc222764c36d6c](https://www.virustotal.com/gui/file/61e25b25240f596b3adc222764c36d6c)|DOCX||2017-10-30 06:24:11|61e25b25240f596b3adc222764c36d6c.virus|
|[6b2e7b24be526a4166873797b75c04b5](https://www.virustotal.com/gui/file/6b2e7b24be526a4166873797b75c04b5)|DOCX||2017-10-25 13:56:03|6b2e7b24be526a4166873797b75c04b5.virus|
|[33c4406d938ee1eea45f0a640071998b](https://www.virustotal.com/gui/file/33c4406d938ee1eea45f0a640071998b)|DOCX||2017-09-03 17:07:26|33c4406d938ee1eea45f0a640071998b.virus|
|[994e395743f2de895dc29e3878074257](https://www.virustotal.com/gui/file/994e395743f2de895dc29e3878074257)|Win32 EXE||2017-08-30 14:07:23|Process Monitor|
|[21cafc950889b647539a2cc6101f072e](https://www.virustotal.com/gui/file/21cafc950889b647539a2cc6101f072e)|Win32 EXE|skeeyah|2017-08-23 07:08:14|21cafc950889b647539a2cc6101f072e.virus|
|[2c2d41db12d4cb17bc90b1571a04272e](https://www.virustotal.com/gui/file/2c2d41db12d4cb17bc90b1571a04272e)|XLSM||2017-08-22 10:11:06|2c2d41db12d4cb17bc90b1571a04272e.virus|
|[6f16de57267b538eeff827d7885dadc6](https://www.virustotal.com/gui/file/6f16de57267b538eeff827d7885dadc6)|Win32 EXE||2017-07-19 22:17:34|6f16de57267b538eeff827d7885dadc6.virus|
|[2017133d9fd11c20c81d7e7fa451bc57](https://www.virustotal.com/gui/file/2017133d9fd11c20c81d7e7fa451bc57)|Win64 DLL|CobaltStrike|2017-04-26 03:11:26|2017133d9fd11c20c81d7e7fa451bc57.virus|
|[89d0f575b2d2fe16b46e4401194b1b51](https://www.virustotal.com/gui/file/89d0f575b2d2fe16b46e4401194b1b51)|unknown|Kryptik|2017-02-08 11:41:53|apt aptc16_c367e558eadfdae9d272ffa5ab969e3f691f29a62a5b7e2a11e8d8aef3fed587.bin|
|[e2c52f1975c4ae4091fc800df8fb3004](https://www.virustotal.com/gui/file/e2c52f1975c4ae4091fc800df8fb3004)|XLSM||2017-01-31 16:56:59|e2c52f1975c4ae4091fc800df8fb3004.virus|
|[f2ec272bbd787f8b5bfaa83b39afed81](https://www.virustotal.com/gui/file/f2ec272bbd787f8b5bfaa83b39afed81)|XLSM||2017-01-15 07:27:07|f2ec272bbd787f8b5bfaa83b39afed81.virus|
|[b439eaef9331cfbcd7d6b6f23e4ffecf](https://www.virustotal.com/gui/file/b439eaef9331cfbcd7d6b6f23e4ffecf)|Win32 DLL|Ursu|2017-01-04 19:08:42|b439eaef9331cfbcd7d6b6f23e4ffecf.virus|
|[61de8ecf816901cf60df70e465461c0f](https://www.virustotal.com/gui/file/61de8ecf816901cf60df70e465461c0f)|Win32 EXE||2016-12-13 10:39:26|61de8ecf816901cf60df70e465461c0f.virus|
|[13c8c37453d8bdea99b77aef45fc4111](https://www.virustotal.com/gui/file/13c8c37453d8bdea99b77aef45fc4111)|Win32 DLL|CobaltStrike|2016-11-27 19:07:33|13c8c37453d8bdea99b77aef45fc4111.virus|
|[a6c9f011950c4ab87c98d5e96cf86ab0](https://www.virustotal.com/gui/file/a6c9f011950c4ab87c98d5e96cf86ab0)|XLSM||2016-10-25 18:14:39|a6c9f011950c4ab87c98d5e96cf86ab0.virus|
|[6ad59bed63e2a52e3d148203842dc244](https://www.virustotal.com/gui/file/6ad59bed63e2a52e3d148203842dc244)|XLSM||2016-09-21 20:50:54|6ad59bed63e2a52e3d148203842dc244.virus|
|[9db70f3ceefec689dd91abe9bda08bf8](https://www.virustotal.com/gui/file/9db70f3ceefec689dd91abe9bda08bf8)|XLSM||2016-08-06 20:42:58|9db70f3ceefec689dd91abe9bda08bf8.virus|
|[cc5c5b2f2fd8af07824ae3b42f3b1a37](https://www.virustotal.com/gui/file/cc5c5b2f2fd8af07824ae3b42f3b1a37)|Win32 DLL|CobaltStrike|2016-08-03 22:08:49|cc5c5b2f2fd8af07824ae3b42f3b1a37.virus|
|[a7b2aa20628ccb7b576b8f7246f92e74](https://www.virustotal.com/gui/file/a7b2aa20628ccb7b576b8f7246f92e74)|DOC||2016-08-03 07:33:31|a7b2aa20628ccb7b576b8f7246f92e74.virus|
|[be8376c7a44d4274d152aff5a23c56e2](https://www.virustotal.com/gui/file/be8376c7a44d4274d152aff5a23c56e2)|XLSM||2016-07-24 05:00:07|be8376c7a44d4274d152aff5a23c56e2.virus|
|[29061115d0f5b9b67e0c6d8460dda274](https://www.virustotal.com/gui/file/29061115d0f5b9b67e0c6d8460dda274)|DOC|Kryptik|2016-04-03 07:54:40|29061115d0f5b9b67e0c6d8460dda274.virus|
