**NAME:**  
DarkHydrus  
  
**Alias**  
LazyMeerkat, DarkHydrus  
  
**Description**:   
DarkHydrus, disclosed by Palo Alto, is a threat group that has targeted government agencies and educational institutions in the Middle East since at least 2016. The group heavily leverages open-source tools and custom payloads for carrying out attacks. ClearSky pointed out that some domains overlapped with CopyKittens.
  
**References**:  
https://unit42.paloaltonetworks.com/unit42-new-threat-actor-group-darkhydrus-targets-middle-east-government/
