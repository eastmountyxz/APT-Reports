|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[cd15a7c3cb1725dc9d21160c26ab9c2e](https://www.virustotal.com/gui/file/cd15a7c3cb1725dc9d21160c26ab9c2e)|DOC|Banload|2018-10-12 13:38:05|sample.doc|
|[ac85b1fff1fe43ddad28bf1c4ce021c5](https://www.virustotal.com/gui/file/ac85b1fff1fe43ddad28bf1c4ce021c5)|DOC|o97m|2018-10-11 20:58:54|=?UTF-8?B?OC0xMC0yMDE4INCh0L7QvtCx0YnQtdC90LjQtS5kb2M=?=|
|[e3487e2725f8c79d04ffda6de9612e25](https://www.virustotal.com/gui/file/e3487e2725f8c79d04ffda6de9612e25)|DOC|o97m|2018-07-05 13:52:10|c0137e41f9d1b165c57e76714bb44e4ca4de2f8f83f6fd4bd34c90ed01553764.bin|
|[76426a43387e99863a64016a8d52ff67](https://www.virustotal.com/gui/file/76426a43387e99863a64016a8d52ff67)|Win64 DLL||2018-07-02 09:38:27|58d5849871f6bac4adc4bccca83c0fad0d6a8542bd63c4c670ff932021eae34c.sample|
|[4247901eca6d87f5f3af7df8249ea825](https://www.virustotal.com/gui/file/4247901eca6d87f5f3af7df8249ea825)|DOC|o97m|2018-06-15 07:24:37|d4ea3fba15379fe36f08685d542eceec727c1755395b3ff7928a7d994bcfcf0a.bin|
|[7f327ae9b70d6a2bd48e20c897f7f726](https://www.virustotal.com/gui/file/7f327ae9b70d6a2bd48e20c897f7f726)|DOC||2018-06-11 06:40:21|E-Mail-Adressliste_2018.doc|
|[e160ca75a0e8c4bc9177f412b09e7a29](https://www.virustotal.com/gui/file/e160ca75a0e8c4bc9177f412b09e7a29)|DOC|w2km|2018-06-05 14:42:10|E-Mail-Adressliste_2018.doc|
|[e2e102291d259f054625cc85318b7ef5](https://www.virustotal.com/gui/file/e2e102291d259f054625cc85318b7ef5)|DOC|o97m|2018-05-29 15:14:12|sample|
|[0e7b32d23fbd6d62a593c234bafa2311](https://www.virustotal.com/gui/file/0e7b32d23fbd6d62a593c234bafa2311)|DOC|o97m|2018-05-15 19:54:55|VirusShare_0e7b32d23fbd6d62a593c234bafa2311|
|[1d0cf431e623b21aeae8f2b8414d2a73](https://www.virustotal.com/gui/file/1d0cf431e623b21aeae8f2b8414d2a73)|DOC|o97m|2018-04-06 13:27:24|Investigation_file.doc|
|[bb5e8733a940fedfb1ef6b0e0ec3635c](https://www.virustotal.com/gui/file/bb5e8733a940fedfb1ef6b0e0ec3635c)|DOC|o97m|2018-03-22 17:30:37|9f270b1cef15fa30f3b0aa24690abcacbbe0bbc2e40e1ba99158ee4d4ba8c815.bin|
|[97ddc336d7d92b7db17d098ec2ee6092](https://www.virustotal.com/gui/file/97ddc336d7d92b7db17d098ec2ee6092)|DOC|w2km|2018-03-22 16:59:56|81d5626d826c4785921a4e23f1ad759afadc9a1dd4dbd39e4a7b2297a5ae519f.bin|
|[b60da65b8d3627a89481efb23d59713a](https://www.virustotal.com/gui/file/b60da65b8d3627a89481efb23d59713a)|DOC||2018-03-15 12:12:06|Corporativ_2018.doc|
|[104ecbc2746702fa6ecd4562a867e7fb](https://www.virustotal.com/gui/file/104ecbc2746702fa6ecd4562a867e7fb)|Win32 EXE|samcrex|2018-03-15 04:16:01|myfile.exe|
|[abe771f280cdea6e7eaf19a26b1a9488](https://www.virustotal.com/gui/file/abe771f280cdea6e7eaf19a26b1a9488)|DOC|o97m|2018-03-13 11:11:32|ef7a13c074a28bdbb2ee71c03556892967f0d022e3112bd6a6769dec72b81fd1.bin|
|[6ccd8133f250d4babefbd66b898739b9](https://www.virustotal.com/gui/file/6ccd8133f250d4babefbd66b898739b9)|DOC|o97m|2018-02-27 14:00:28|corporativ_2018.doc|
|[583f05b4f1724ed2ebfd06dd29064214](https://www.virustotal.com/gui/file/583f05b4f1724ed2ebfd06dd29064214)|Win32 DLL||2018-02-19 22:14:23|2_resource.exe|
|[da93e6651c5ba3e3e96f4ae2dd763d94](https://www.virustotal.com/gui/file/da93e6651c5ba3e3e96f4ae2dd763d94)|DOC|o97m|2018-02-19 11:23:21|Korporativ_2018.doc|
|[9bc365a16c63f25dfddcbe11da042974](https://www.virustotal.com/gui/file/9bc365a16c63f25dfddcbe11da042974)|DOC||2018-02-19 09:06:48|Korporativ .doc|
|[12668f8d072e89cf04b9cbcd5a3492e1](https://www.virustotal.com/gui/file/12668f8d072e89cf04b9cbcd5a3492e1)|Win32 EXE||2018-02-16 19:14:30|12668f8d072e89cf04b9cbcd5a3492e1|
|[83d8d40f435521c097d3f6f4d2358c67](https://www.virustotal.com/gui/file/83d8d40f435521c097d3f6f4d2358c67)|Win32 EXE||2018-02-15 17:05:02|bdfb1a9f59be657b__kek.exe|
|[4c8fa3731efd2c5097e903d50079a44d](https://www.virustotal.com/gui/file/4c8fa3731efd2c5097e903d50079a44d)|Win32 EXE||2018-02-15 17:04:20|d2e43c41acd40324__nka.exe|
|[7c3bf9ab05dd803ac218fc7084c75e96](https://www.virustotal.com/gui/file/7c3bf9ab05dd803ac218fc7084c75e96)|Win32 EXE||2018-02-15 13:18:30|/mnt/deeparmor_samples/reversinglabs/2018-02/2018-02-17-peexe_malicious/eabdd69e4e3b9f479bbdade8508359a8b663f33f|
|[03e27bb9fbf9a5321fc8283fbc8b17a9](https://www.virustotal.com/gui/file/03e27bb9fbf9a5321fc8283fbc8b17a9)|Win32 DLL||2018-02-13 20:38:23|ab5bf79274b6583a00be203256a4eacfa30a37bc889b5493da9456e2d5885c7f.sample|
|[51545abcf4f196095ed102b0d08dea7e](https://www.virustotal.com/gui/file/51545abcf4f196095ed102b0d08dea7e)|Win32 EXE||2018-02-13 07:27:59|_bdm.exe|
|[19c539ff2c50a0efd52bb5b93d03665a](https://www.virustotal.com/gui/file/19c539ff2c50a0efd52bb5b93d03665a)|Win32 EXE||2018-02-13 07:25:59|_rnk.exe|
|[5778d8ff5156de1f63361bd530e0404d](https://www.virustotal.com/gui/file/5778d8ff5156de1f63361bd530e0404d)|Win32 EXE||2018-02-12 20:37:16|_nfc.exe|
|[d9c37b937ffde812ae15de885913e101](https://www.virustotal.com/gui/file/d9c37b937ffde812ae15de885913e101)|Win64 EXE|samcrex|2018-02-12 16:03:23|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/OlympicDestroyer/OlympicSystemStealer.bin|
|[65c024d60af18ffab051f97ccddfab7f](https://www.virustotal.com/gui/file/65c024d60af18ffab051f97ccddfab7f)|Win32 EXE|samcrex|2018-02-09 21:58:58|_mfy.exe|
|[4f43f03783f9789f804dcf9b9474fa6d](https://www.virustotal.com/gui/file/4f43f03783f9789f804dcf9b9474fa6d)|Win32 EXE|samcrex|2018-02-09 21:58:48|afyhc.exe|
|[6e0ebeeea1cb00192b074b288a4f9cfe](https://www.virustotal.com/gui/file/6e0ebeeea1cb00192b074b288a4f9cfe)|Win32 EXE||2018-02-09 21:58:45|kxsqe.exe|
|[cfdd16225e67471f5ef54cab9b3a5558](https://www.virustotal.com/gui/file/cfdd16225e67471f5ef54cab9b3a5558)|Win32 EXE|samcrex|2018-02-09 21:53:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/OlympicDestroyer/OlympicDestroyer.bin|
|[ec724ef33521c4c2965de078e36c8277](https://www.virustotal.com/gui/file/ec724ef33521c4c2965de078e36c8277)|Win32 EXE||2018-02-09 14:42:59|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/OlympicDestroyer/OlympicDestroyerAtos.bin|
|[221c6db5b60049e3f1cdbb6212be7f41](https://www.virustotal.com/gui/file/221c6db5b60049e3f1cdbb6212be7f41)|Win32 EXE||2018-02-09 14:28:40|_wun.exe.vir|
|[59c3f3f99f44029de81293b1e7c37ed2](https://www.virustotal.com/gui/file/59c3f3f99f44029de81293b1e7c37ed2)|Win32 EXE||2018-02-09 13:50:07|_ljy.exe|
|[86d1a184850859a6a4d1c35982f3c40e](https://www.virustotal.com/gui/file/86d1a184850859a6a4d1c35982f3c40e)|Win64 EXE||2018-02-09 13:48:04|C:\Users\Virtual\AppData\Local\Temp\nogpz.exe|
|[64aa21201bfd88d521fe90d44c7b5dba](https://www.virustotal.com/gui/file/64aa21201bfd88d521fe90d44c7b5dba)|Win32 EXE||2018-02-09 13:46:23|atos.zip|
|[ca0eaca077aa67f2609f612cefe7f1f3](https://www.virustotal.com/gui/file/ca0eaca077aa67f2609f612cefe7f1f3)|Win32 EXE||2018-02-09 13:42:46|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/OlympicDestroyer/OlympicsSouthKorea.bin|
|[dfedf303b4d9b77ce5e59407c9484c37](https://www.virustotal.com/gui/file/dfedf303b4d9b77ce5e59407c9484c37)|Win32 EXE||2018-02-09 13:40:58|_qih.exe|
|[907c2c79ef21d84ff5ea6ed854f24f05](https://www.virustotal.com/gui/file/907c2c79ef21d84ff5ea6ed854f24f05)|Win32 EXE||2018-02-09 13:33:33|_nfv.exe|
|[3c0d740347b0362331c882c2dee96dbf](https://www.virustotal.com/gui/file/3c0d740347b0362331c882c2dee96dbf)|Win32 EXE|samcrex|2018-02-09 13:33:25|_fdo.exe|
|[68970b2cd5430c812bef5b87c1add6ea](https://www.virustotal.com/gui/file/68970b2cd5430c812bef5b87c1add6ea)|Win32 EXE||2018-02-09 13:33:23|C:\Users\Virtual\AppData\Local\Temp\ilvay.exe|
|[58dd6099f8df7e5509cee3cb279d74d5](https://www.virustotal.com/gui/file/58dd6099f8df7e5509cee3cb279d74d5)|Win32 EXE||2018-02-09 13:33:19|pmllq.exe|
|[a8224a04579b7e9039f91ac9b76c19dc](https://www.virustotal.com/gui/file/a8224a04579b7e9039f91ac9b76c19dc)|Win32 EXE||2018-02-09 13:31:39|_dqo.exe|
|[5ba7ec869c7157efc1e52f5157705867](https://www.virustotal.com/gui/file/5ba7ec869c7157efc1e52f5157705867)|DOC|w2km|2018-02-05 23:16:31|5ba7ec869c7157efc1e52f5157705867_HnKAtBcxYeNLNM.doC|
|[ebaf83302dc78d96d5993830430bd169](https://www.virustotal.com/gui/file/ebaf83302dc78d96d5993830430bd169)|Win32 DLL||2018-01-03 08:33:23|pcacli|
|[6b728d2966194968d12c56f8e3691855](https://www.virustotal.com/gui/file/6b728d2966194968d12c56f8e3691855)|DOC|valyria|2017-12-29 09:04:07|6b728d2966194968d12c56f8e3691855.virus|
|[8be90fc18186415db4f49bb281f70c62](https://www.virustotal.com/gui/file/8be90fc18186415db4f49bb281f70c62)|Win32 EXE||2017-12-27 17:13:12|myfile.exe|
|[21de71411ed3d5fffa4f9222057be82c](https://www.virustotal.com/gui/file/21de71411ed3d5fffa4f9222057be82c)|Win32 EXE||2017-12-26 17:13:27|21de71411ed3d5fffa4f9222057be82c_NyQPTT.Exe|
|[35133c3610cbfebff4bd12a96f8f9e9e](https://www.virustotal.com/gui/file/35133c3610cbfebff4bd12a96f8f9e9e)|Win32 EXE||2017-12-26 17:12:52|myfile.exe|
|[2bd4380c9aabe58812c9088d40bf127d](https://www.virustotal.com/gui/file/2bd4380c9aabe58812c9088d40bf127d)|Win32 EXE||2017-12-26 17:11:55|myfile.exe|
|[99986f0ec2b36763560a01925af69b75](https://www.virustotal.com/gui/file/99986f0ec2b36763560a01925af69b75)|Win32 EXE||2017-12-26 17:11:54|99986f0ec2b36763560a01925af69b75_SOWpecrfWmlLTkq.EXE|
|[d61f883a59c3e0729a3ecf78b70044cf](https://www.virustotal.com/gui/file/d61f883a59c3e0729a3ecf78b70044cf)|Win32 EXE||2017-12-26 17:10:57|myfile.exe|
|[0415b3ef4807134724b1029b88384371](https://www.virustotal.com/gui/file/0415b3ef4807134724b1029b88384371)|DOCX||2017-12-26 16:43:41|0415b3ef4807134724b1029b88384371.virus|
|[d3e2c0943952285ce359fcbf28472491](https://www.virustotal.com/gui/file/d3e2c0943952285ce359fcbf28472491)|Win32 EXE||2017-12-24 19:30:37|myfile.exe|
|[c605b7c3e4c339642db6a33c5780b49b](https://www.virustotal.com/gui/file/c605b7c3e4c339642db6a33c5780b49b)|Win32 EXE|Ursu|2017-12-24 18:51:58|c605b7c3e4c339642db6a33c5780b49b_AygjE.ExE|
|[92001e9cebec0f0f0ac2b7c7e04f017d](https://www.virustotal.com/gui/file/92001e9cebec0f0f0ac2b7c7e04f017d)|Win32 DLL||2017-12-21 18:10:40|ieproxy|
|[e2b9e490fe948a643d1bed89278ae7d0](https://www.virustotal.com/gui/file/e2b9e490fe948a643d1bed89278ae7d0)|Win32 DLL||2017-12-21 05:33:00|e2b9e490fe948a643d1bed89278ae7d0_OEfBWgRNfhmF.Dll|
|[341381d3ac281fc1b3900be117f67274](https://www.virustotal.com/gui/file/341381d3ac281fc1b3900be117f67274)|Win32 DLL||2017-12-21 05:32:47|myfile.exe|
|[05c3376df5d3b8594a990d1a2725e409](https://www.virustotal.com/gui/file/05c3376df5d3b8594a990d1a2725e409)|Win32 DLL|razy|2017-12-21 05:32:06|05c3376df5d3b8594a990d1a2725e409_zPSjDPgQiGwOFFkFmWmcfGF.dlL|
|[1083256b95a697f4e3248c5c741eb9c6](https://www.virustotal.com/gui/file/1083256b95a697f4e3248c5c741eb9c6)|Win32 DLL|Ursu|2017-12-21 05:31:45|myfile.exe|
|[1989f0b5c1f3281b2ce8d8087e5d8110](https://www.virustotal.com/gui/file/1989f0b5c1f3281b2ce8d8087e5d8110)|Win32 DLL|Ursu|2017-12-21 05:31:16|myfile.exe|
|[d4fd104e9a92840eca53c03a44ff53ac](https://www.virustotal.com/gui/file/d4fd104e9a92840eca53c03a44ff53ac)|Win32 DLL||2017-12-21 05:30:59|d4fd104e9a92840eca53c03a44ff53ac_gIsinOCgHpmTUAGiuRyWAxQ.dlL|
|[ecc2f0f66e5fd9132c8878178bc7d40d](https://www.virustotal.com/gui/file/ecc2f0f66e5fd9132c8878178bc7d40d)|Win32 DLL|Pcclient|2017-12-21 05:30:19|myfile.exe|
|[86b9784231e2c9be17a33e0ae39bd4fc](https://www.virustotal.com/gui/file/86b9784231e2c9be17a33e0ae39bd4fc)|Win32 DLL||2017-12-21 04:54:35|myfile.exe|
|[107824f43817ca299baf2ab19ecbc87d](https://www.virustotal.com/gui/file/107824f43817ca299baf2ab19ecbc87d)|Win32 DLL|Ursu|2017-12-21 04:53:09|myfile.exe|
|[33df74cbb60920d63fe677c6f90b63f9](https://www.virustotal.com/gui/file/33df74cbb60920d63fe677c6f90b63f9)|Win32 DLL|scar|2017-12-21 04:20:44|ieproxy|
|[8a0467ab4adbd2b678867c9636cf6526](https://www.virustotal.com/gui/file/8a0467ab4adbd2b678867c9636cf6526)|Win32 DLL||2017-12-21 04:20:38|8a0467ab4adbd2b678867c9636cf6526_hBnLvGulWmhLcJIvfhIJnlAD.Dll|
|[edf723c8e404cd67041e7dfbbb1a6eee](https://www.virustotal.com/gui/file/edf723c8e404cd67041e7dfbbb1a6eee)|Win32 DLL|Ursu|2017-12-21 04:20:37|myfile.exe|
|[5a6d034b9f656bd60cc29688d2eba618](https://www.virustotal.com/gui/file/5a6d034b9f656bd60cc29688d2eba618)|Win32 DLL||2017-12-21 04:04:50|myfile.exe|
|[b182fce35c27dd32e7f7433e4de583cc](https://www.virustotal.com/gui/file/b182fce35c27dd32e7f7433e4de583cc)|Win32 DLL|Ursu|2017-12-19 18:47:20|b182fce35c27dd32e7f7433e4de583cc_eFrwoUuKchZJM.Dll|
|[42b9f65fda3cbb613f726c9a4f26069e](https://www.virustotal.com/gui/file/42b9f65fda3cbb613f726c9a4f26069e)|Win32 DLL||2017-12-14 20:54:19|myfile.exe|
|[27304b246c7d5b4e149124d5f93c5b01](https://www.virustotal.com/gui/file/27304b246c7d5b4e149124d5f93c5b01)|Win32 EXE||2016-06-30 13:21:27|PsExec|
|[2dfb086bc73c259cac18a9cb1f9dbbc8](https://www.virustotal.com/gui/file/2dfb086bc73c259cac18a9cb1f9dbbc8)|Win32 EXE||2020-02-21 20:27:59|%HOMEPATH%\conhost.exe|
|[8d8e5a09fe6878f133b3b81799d84e27](https://www.virustotal.com/gui/file/8d8e5a09fe6878f133b3b81799d84e27)|DOC|sLoad|2020-02-21 18:00:47|1db31ada5f1ac2411ef33790244343946b741cd603745257a4612c5d2e6a4052.bin|
|[0acecad57c4015e14d9b3bb02b433d3e](https://www.virustotal.com/gui/file/0acecad57c4015e14d9b3bb02b433d3e)|Win32 EXE|Razy|2020-02-20 19:28:29|conhost.exe|
|[74572fba26f5e988b297ec5ea5c8ac1c](https://www.virustotal.com/gui/file/74572fba26f5e988b297ec5ea5c8ac1c)|DOC|sLoad|2020-02-20 17:07:19|62dd16724874e0b05257118fb06427a6aeb839602bce52e6a139dc379f538bed.bin|
|[53b31f65bb6ced61c5bafa8e4c98e9e8](https://www.virustotal.com/gui/file/53b31f65bb6ced61c5bafa8e4c98e9e8)|RAR|sLoad|2020-02-20 13:10:09|9aea43b22f214228caf4fc714f426c0a140b7dd70b010bf3778cd1c0ec440851.bin|
|[b86526bed4bf9cb034baff0403617856](https://www.virustotal.com/gui/file/b86526bed4bf9cb034baff0403617856)|DOC||2014-11-06 09:53:46|Informazioni10221419.doc|
|[047a0c1e472ec2f557a84676982465c9](https://www.virustotal.com/gui/file/047a0c1e472ec2f557a84676982465c9)|DOC||2014-10-27 09:28:20|VirusShare_047a0c1e472ec2f557a84676982465c9|
|[73874b9b5019f2224b4506f892482760](https://www.virustotal.com/gui/file/73874b9b5019f2224b4506f892482760)|DOC|Banload|2014-10-27 09:08:21|invoice_7340565.doc|
