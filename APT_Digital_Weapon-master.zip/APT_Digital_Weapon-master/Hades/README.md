**NAME:**  
Hades  
  
**Alias**  
Gold Dragon, Olympic Destroyer, Hades  

**Description**:   
The actor behind the Olympic Destroyer attack is called as Hades by Kaspersky. Olympic Destroyer is advanced attack that hit organizers, suppliers and partners of the Winter Olympic Games 2018 held in Pyeongchang, South Korea. It is a cyber-sabotage attack based on the spread of a destructive network worm. The sabotage stage was preceded by reconnaissance and infiltration into target networks to select the best foothold for the self-replicating and self-modifying destructive malware.
  
**References**:  
https://cyware.com/news/new-olympic-destroyer-variant-being-distributed-by-the-hades-apt-group-e4b3cdb3