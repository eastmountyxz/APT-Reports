|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[974298eb7e2adfa019cae4d1a927ab07](https://www.virustotal.com/gui/file/974298eb7e2adfa019cae4d1a927ab07)|unknown||2019-06-27 09:48:03|VirtualUMP.dll.crt|
|[e3e61f30f8a39cd7aa25149d0f8af5ef](https://www.virustotal.com/gui/file/e3e61f30f8a39cd7aa25149d0f8af5ef)|Win32 DLL||2019-05-31 14:26:53|MPSSVC.dll|
|[cce8c8ee42feaed68e9623185c3f7fe4](https://www.virustotal.com/gui/file/cce8c8ee42feaed68e9623185c3f7fe4)|unknown||2019-02-28 16:34:43|AppCert.dll.crt|
|[d1a1166bec950c75b65fdc7361dcdc63](https://www.virustotal.com/gui/file/d1a1166bec950c75b65fdc7361dcdc63)|Win64 DLL||2019-02-28 16:32:08|RasCon.dll|
|[06c1d7bf234ce99bb14639c194b3b318](https://www.virustotal.com/gui/file/06c1d7bf234ce99bb14639c194b3b318)|Win32 DLL||2019-01-31 11:19:18|a9a82099aa812d0c4025bee2b34f3b34c1d102773e36f1d50648815913dbe03d.bin|
|[5199ef9d086c97732d97eddef56591ec](https://www.virustotal.com/gui/file/5199ef9d086c97732d97eddef56591ec)|Win32 DLL||2019-01-31 06:07:28|dnscache.dll|
|[05f472a9d926f4c8a0a372e1a7193998](https://www.virustotal.com/gui/file/05f472a9d926f4c8a0a372e1a7193998)|unknown||2019-01-17 17:20:28|EFSProvider.dll.crt|
|[aa1cf5791a60d56f7ae6da9bb1e7f01e](https://www.virustotal.com/gui/file/aa1cf5791a60d56f7ae6da9bb1e7f01e)|Win32 DLL||2019-01-17 17:20:14|MPSSVC.dll|
|[e1a578a069b1910a25c95e2d9450c710](https://www.virustotal.com/gui/file/e1a578a069b1910a25c95e2d9450c710)|unknown||2019-01-17 17:01:26|RasCfgMan.dll.crt|
|[617d588eccd942f243ffa8cb13679d9c](https://www.virustotal.com/gui/file/617d588eccd942f243ffa8cb13679d9c)|Win32 DLL||2018-12-12 19:28:47|617d588eccd942f243ffa8cb13679d9c.virus|
|[c9c39045fa14e94618dd631044053824](https://www.virustotal.com/gui/file/c9c39045fa14e94618dd631044053824)|Win32 EXE||2018-07-24 14:28:52|C:\Users\<USER>\AppData\Local\Temp\C9C39045FA14E94618DD631044053824.exe|
|[0d532484193b8b098d7eb14319cefcd3](https://www.virustotal.com/gui/file/0d532484193b8b098d7eb14319cefcd3)|Win32 DLL||2018-06-15 03:02:11|RasCfgMan.dll|
|[e24a62d9826869bc4817366800a8805c](https://www.virustotal.com/gui/file/e24a62d9826869bc4817366800a8805c)|Win32 DLL||2018-06-15 03:01:38|C:\ProgramData\TMP_5C7171877144D98D\_data01.bin|
|[2807236c2d905a0675878e530ed8b1f8](https://www.virustotal.com/gui/file/2807236c2d905a0675878e530ed8b1f8)|Win32 DLL||2018-04-12 08:30:11|AeLookupMgr.dll|
|[1ed72c14c4aab3b66e830e16ef90b37b](https://www.virustotal.com/gui/file/1ed72c14c4aab3b66e830e16ef90b37b)|Win32 EXE||2018-03-06 07:59:56|1ed72c14c4aab3b66e830e16ef90b37b.virus|
|[17e05041730dcd0732e5b296db16d757](https://www.virustotal.com/gui/file/17e05041730dcd0732e5b296db16d757)|Win32 EXE||2018-03-04 12:50:03|C:\Users\<USER>\AppData\Local\Temp\17E05041730DCD0732E5B296DB16D757.exe|
|[cb914fc73c67b325f948dd1bf97f5733](https://www.virustotal.com/gui/file/cb914fc73c67b325f948dd1bf97f5733)|Win32 EXE||2017-10-24 16:41:23|1024-37ce4d0a3168e3b2f80b3fae38082e68a454aee0|
|[69322703b8ef9d490a20033684c28493](https://www.virustotal.com/gui/file/69322703b8ef9d490a20033684c28493)|Win32 DLL||2017-10-18 05:51:13|RasCon.dll|
|[6347e42f49a86aff2dea7c8bf455a52a](https://www.virustotal.com/gui/file/6347e42f49a86aff2dea7c8bf455a52a)|Win32 DLL||2017-09-29 09:27:50|HIDMgr.dll|
|[85ce60b365edf4beebbdd85cc971e84d](https://www.virustotal.com/gui/file/85ce60b365edf4beebbdd85cc971e84d)|Win32 EXE||2017-09-26 12:24:53|C:\Users\<USER>\AppData\Local\Temp\85CE60B365EDF4BEEBBDD85CC971E84D.exe|
|[c84df4b2cd0d3e7729210f15112da7ac](https://www.virustotal.com/gui/file/c84df4b2cd0d3e7729210f15112da7ac)|Win32 DLL||2017-07-18 18:00:33|mscorsvw.dll|
|[1e765fed294a7ad082169819c95d2c85](https://www.virustotal.com/gui/file/1e765fed294a7ad082169819c95d2c85)|Win32 EXE|Tofsee|2017-05-26 20:09:37|f6a09372156a8aef96576627a1ed9e57f194b008bb77e32ca29ac89505f933f0.bin|
