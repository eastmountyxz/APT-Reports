**NAME:**  
Calypso  

**Description**:   
Calypso is an APT group attacking state institutions that has been active since at least September 2016. The primary goal of the group is theft of confidential data. Main targets are governmental institutions in Brazil, India, Kazakhstan, Russia, Thailand, and Turkey.
  
**References**:  
https://www.ptsecurity.com/ww-en/analytics/calypso-apt-2019/#id5
