**NAME:**  
BlueMushroom
  
**Alias**  
APT-C-12, 核危机, BlueMushroom, 蓝宝菇  
  
**Description**:   
APT-C-12, also known as Blue Mushroom, is an APT group first disclosed by QiAnXin. It carried out continuous cyber espionage activities targeting key units and departments such as the government, military industry, scientific research, and finance since 2011, to exfiltrate sensitive information relating to the nuclear industry and research in China. Related attack campaign was named as Operation NuclearCrisis.

The attack group usually adopts spear-phishing technology to deliver malicious binary payloads. Cloud services are abused as C2, and also to store the stolen data.
  
**References**:  
https://ti.qianxin.com/uploads/2018/07/05/5fc9c36b4cb81d4281599f0d3416931a.pdf

