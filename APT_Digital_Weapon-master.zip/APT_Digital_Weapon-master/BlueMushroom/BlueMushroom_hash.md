|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[2125be782bb1130050b482f0e2dbfefe](https://www.virustotal.com/gui/file/2125be782bb1130050b482f0e2dbfefe)|Win32 DLL||2019-10-30 21:02:56|apisetstub|
|[36a5b24340f0ab46dcb63625ae3efeb8](https://www.virustotal.com/gui/file/36a5b24340f0ab46dcb63625ae3efeb8)|Win32 DLL||2019-10-30 21:01:31|36a5b24340f0ab46dcb63625ae3efeb8.virus|
|[95c452613c03dcccbbd6dc3efe313ede](https://www.virustotal.com/gui/file/95c452613c03dcccbbd6dc3efe313ede)|Win32 DLL||2019-10-30 21:00:20|95c452613c03dcccbbd6dc3efe313ede.virus|
|[debc84a9212f5b0f3d548576f389610d](https://www.virustotal.com/gui/file/debc84a9212f5b0f3d548576f389610d)|Win32 DLL||2019-10-30 20:51:42|debc84a9212f5b0f3d548576f389610d.virus|
|[1f17a50f38366872de9689bdd36225ed](https://www.virustotal.com/gui/file/1f17a50f38366872de9689bdd36225ed)|Win32 DLL||2019-10-29 20:47:22|1f17a50f38366872de9689bdd36225ed.virus|
|[4c63ee224fb25986ea46b4f96048b60e](https://www.virustotal.com/gui/file/4c63ee224fb25986ea46b4f96048b60e)|Win32 DLL||2019-10-29 20:46:15|4c63ee224fb25986ea46b4f96048b60e.virus|
|[fe5c8d00020fc10b0d82ca85f2d1a8dd](https://www.virustotal.com/gui/file/fe5c8d00020fc10b0d82ca85f2d1a8dd)|Win32 DLL||2019-10-29 17:11:54|73fcab1bf84c11ae39ee3ecb2b1a2bda8acd4bd5cc4ef5901fda0c5abc5bc50a.bin|
|[8ae508777949082383089b2329aba8bf](https://www.virustotal.com/gui/file/8ae508777949082383089b2329aba8bf)|Win32 DLL||2019-10-29 03:01:42|a500c4ec696302bfdad4e7c8681c267c378733114f8e897169eb7189784cb3d3.bin|
|[9805821213cc4681502db9cf7154b465](https://www.virustotal.com/gui/file/9805821213cc4681502db9cf7154b465)|Win32 EXE||2019-10-28 15:57:06|apisetstub|
|[30ec9fe19486ad3383cd57d6e9d36477](https://www.virustotal.com/gui/file/30ec9fe19486ad3383cd57d6e9d36477)|Win32 DLL|ursu|2018-11-04 16:31:22|dx12_gx3_32|
|[da1d8af45bde360cd5bd2898b089a625](https://www.virustotal.com/gui/file/da1d8af45bde360cd5bd2898b089a625)|Win32 DLL||2018-11-01 16:18:20|<LS_APPDATA>\op.bak|
|[8a8cf95ba821e84ae611c9d78c76c105](https://www.virustotal.com/gui/file/8a8cf95ba821e84ae611c9d78c76c105)|Win32 DLL||2018-11-01 16:15:48|.|
|[41344a2854d4cc46d8ec36dd9c8caa2d](https://www.virustotal.com/gui/file/41344a2854d4cc46d8ec36dd9c8caa2d)|Win32 EXE||2018-11-01 05:58:52|dxdncfg|
|[0be7e8dd06d163346b3a8009a4b838ad](https://www.virustotal.com/gui/file/0be7e8dd06d163346b3a8009a4b838ad)|Win32 DLL||2018-06-26 06:25:28|update.tmp|
|[96d9fd90e180aaf435c21334858654f6](https://www.virustotal.com/gui/file/96d9fd90e180aaf435c21334858654f6)|Win32 DLL||2018-04-26 10:14:33|nvapisetlib|
|[cc0ce9681c780547c9d9345a9765397f](https://www.virustotal.com/gui/file/cc0ce9681c780547c9d9345a9765397f)|Win32 DLL||2018-01-06 02:13:00|apisetstub|
|[e755a010871ea811ace245110db2a620](https://www.virustotal.com/gui/file/e755a010871ea811ace245110db2a620)|Win32 EXE|Zbot|2018-01-02 05:01:49|apisetstub|
|[d981fb92a8b9859c86735ec015c9898e](https://www.virustotal.com/gui/file/d981fb92a8b9859c86735ec015c9898e)|Win32 EXE|Swisyn|2013-05-31 01:21:10|/home/virustotal/sample/D981FB92A8B9859C86735EC015C9898E|
|[adc4de78a00819ff477623404451c17f](https://www.virustotal.com/gui/file/adc4de78a00819ff477623404451c17f)|Win32 EXE||2013-05-16 23:33:04|\sonas\share\samples\ad\c4\de\78\adc4de78a00819ff477623404451c17f.0bf1b75e9b93a516ed547322c78507dcdc2e0ea7|
|[1fa18280b25cb622ea8ace762663e085](https://www.virustotal.com/gui/file/1fa18280b25cb622ea8ace762663e085)|Win32 EXE|Symmi|2013-05-13 18:00:31|vti-rescan|
|[f3ca1f880227bb2940d4715da8ba08df](https://www.virustotal.com/gui/file/f3ca1f880227bb2940d4715da8ba08df)|Win32 EXE||2013-01-27 09:10:38|drop/f3ca1f880227bb2940d4715da8b|
|[7f65ab7506e6dde364364d9708b49b59](https://www.virustotal.com/gui/file/7f65ab7506e6dde364364d9708b49b59)|Win32 EXE||2013-01-16 20:33:51|prndivake4.co|
|[e6761f87f7c5eac8050f058053f37351](https://www.virustotal.com/gui/file/e6761f87f7c5eac8050f058053f37351)|Win32 EXE||2013-01-16 18:26:55|drop/e6761f87f7c5eac8050f058053f|
|[ad5e99c000f54724e468414af61c1dc2](https://www.virustotal.com/gui/file/ad5e99c000f54724e468414af61c1dc2)|Win32 EXE||2013-01-16 11:14:24|drop/ad5e99c000f54724e468414af61|
|[bcc118fd28a85353cecc16e712069e5e](https://www.virustotal.com/gui/file/bcc118fd28a85353cecc16e712069e5e)|Win32 EXE||2013-01-16 09:48:22|/home/virustotal/sample/BCC118FD28A85353CECC16E712069E5E|
|[f5c69274d07ab6e25b70be6dd7b81a09](https://www.virustotal.com/gui/file/f5c69274d07ab6e25b70be6dd7b81a09)|Win32 EXE||2013-01-16 08:49:54|/home/virustotal/sample/F5C69274D07AB6E25B70BE6DD7B81A09|
|[e19fe974447cf9a2b2b16c81c9df0e05](https://www.virustotal.com/gui/file/e19fe974447cf9a2b2b16c81c9df0e05)|Win32 EXE||2012-06-12 11:19:45|df52012924031256cd265a7a7092dae5a05fda2956c4bb2dd772fc600a44ccd4.vir|
|[2a02d56342b71ba51d067cb4dca043bb](https://www.virustotal.com/gui/file/2a02d56342b71ba51d067cb4dca043bb)|PDF||2020-02-21 09:45:55|¸½¼þ1-2018Ç°º£ºÏ×÷ÂÛÌ³·½°¸.pdf|
|[95e708b4edce4aae2f9a0b9c8b95f24a](https://www.virustotal.com/gui/file/95e708b4edce4aae2f9a0b9c8b95f24a)|Win32 DLL|Zbot|2020-02-19 09:29:17|nvapisetlib32|
|[1978332e1e3c240d42989584a0f63665](https://www.virustotal.com/gui/file/1978332e1e3c240d42989584a0f63665)|LNK||2020-02-12 08:23:43|ea6e7c9b9110c7c21062908be51dd3f881490b40b9b77a534fdc7812ab5cd2af.bin|
|[d8118faa53708c0d6628f9db1d569b14](https://www.virustotal.com/gui/file/d8118faa53708c0d6628f9db1d569b14)|LNK||2020-02-12 08:23:36|b0d7118d75c0f2a99fa5b319148b89148800e5db06ee403d6a31c451a8a54f2b.bin|
|[2196bb153d1e6380e827727b28e6825b](https://www.virustotal.com/gui/file/2196bb153d1e6380e827727b28e6825b)|LNK||2020-02-12 08:23:33|6ccad83fb9f7a50ac95e3e865a27be0288279e76fcd3b5af495c6fcf6d58fa36.bin|
|[6138f0a27043b15c98b21222375c5549](https://www.virustotal.com/gui/file/6138f0a27043b15c98b21222375c5549)|LNK||2020-02-12 08:22:33|20ad6fa72982a6ba0f9499361b2aa3a3f5cca73fd397c2969d08a4c5f2866814.bin|
|[444ed1831d55e1b4cab6c9f9ae19cc7c](https://www.virustotal.com/gui/file/444ed1831d55e1b4cab6c9f9ae19cc7c)|LNK||2019-10-29 12:43:22|444ED1831D55E1B4CAB6C9F9AE19CC7C.bin|
