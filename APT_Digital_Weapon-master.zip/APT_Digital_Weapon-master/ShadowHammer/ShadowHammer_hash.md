|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c778fc8e816061420c537db2617e0297](https://www.virustotal.com/gui/file/c778fc8e816061420c537db2617e0297)|Win32 EXE|shadowhammer|2019-08-21 02:38:22| |
|[95b6adbcef914a4df092f4294473252f](https://www.virustotal.com/gui/file/95b6adbcef914a4df092f4294473252f)|Win32 EXE|hackedapp|2019-07-23 20:27:04| |
|[063ff7cc1778e7073eacb5083738e6a2](https://www.virustotal.com/gui/file/063ff7cc1778e7073eacb5083738e6a2)|Win32 EXE||2019-06-27 18:03:38|Setup|
|[aafe680feae55bb6226ece175282f068](https://www.virustotal.com/gui/file/aafe680feae55bb6226ece175282f068)|Win32 EXE|hackedapp|2019-06-13 03:27:11| |
|[87a8930e88e9564a30288572b54faa46](https://www.virustotal.com/gui/file/87a8930e88e9564a30288572b54faa46)|Win32 EXE|hackedapp|2019-06-11 17:21:10| |
|[abbd7c949985748c353da68de9448538](https://www.virustotal.com/gui/file/abbd7c949985748c353da68de9448538)|Win32 EXE|shadowhammer|2019-05-28 14:30:11|Setup|
|[abbb53e1b60ab7044dd379cf80042660](https://www.virustotal.com/gui/file/abbb53e1b60ab7044dd379cf80042660)|Win32 EXE|hackedapp|2019-05-17 11:01:58| |
|[b042bc851cafd77e471fa0d90a082043](https://www.virustotal.com/gui/file/b042bc851cafd77e471fa0d90a082043)|Win32 EXE|hackedapp|2019-05-12 08:12:40| |
|[04fb0ccf3ef309b1cd587f609ab0e81e](https://www.virustotal.com/gui/file/04fb0ccf3ef309b1cd587f609ab0e81e)|Win32 EXE||2019-04-26 17:30:07| |
|[6b38c772b2ffd7a7818780b29f51ccb2](https://www.virustotal.com/gui/file/6b38c772b2ffd7a7818780b29f51ccb2)|Win32 EXE|shadowhammer|2019-03-28 00:33:51|Setup|
|[91eb2aacd783176d647e17b808fbd024](https://www.virustotal.com/gui/file/91eb2aacd783176d647e17b808fbd024)|Win32 EXE|shadowhammer|2019-03-27 16:14:11|3f1d59bdaca2d45fe861d56adda6b22e624dca2aff18cbb6508f1e073dda47c4.sample|
|[343ad9d459f4154d0d2de577519fb2d3](https://www.virustotal.com/gui/file/343ad9d459f4154d0d2de577519fb2d3)|Win32 EXE|hackedapp|2019-03-27 13:13:21|055ed359f2a9f1b4b7d024835ae5c4fd4468e64be7f7b610b69b81cc7545c23f.bin|
|[c0116d877d048b1ba87c0de6fd7c3fb2](https://www.virustotal.com/gui/file/c0116d877d048b1ba87c0de6fd7c3fb2)|Win32 EXE|shadowhammer|2019-03-26 11:31:46|myfile.exe|
|[06c19cd73471f0db027ab9eb85edc607](https://www.virustotal.com/gui/file/06c19cd73471f0db027ab9eb85edc607)|Win32 EXE||2019-03-25 14:24:02|C:\Users\daven\Downloads\b1tGob_6\682fc8ccfc9316c54f02ae7865eee553ad0211031d4d80bb9c4365fbbc74049a|
|[63f2fe96de336b6097806b22b5ab941a](https://www.virustotal.com/gui/file/63f2fe96de336b6097806b22b5ab941a)|Win32 EXE|shadowhammer|2019-03-25 14:23:01|C:\Users\daven\Downloads\b1tGob_6\1bb53937fa4cba70f61dc53f85e4e25551bc811bf9821fc47d25de1be9fd286a|
|[0f49621b06f2cdaac8850c6e9581a594](https://www.virustotal.com/gui/file/0f49621b06f2cdaac8850c6e9581a594)|Win32 EXE|shadowhammer|2019-03-25 14:22:02|Setup|
|[8578f0c7b0a14f129cc66ee236c58050](https://www.virustotal.com/gui/file/8578f0c7b0a14f129cc66ee236c58050)|Win32 EXE|hackedapp|2019-03-20 10:23:11|PBConfig.exe|
|[2ffc4f0e240ff62a8703e87030a96e39](https://www.virustotal.com/gui/file/2ffc4f0e240ff62a8703e87030a96e39)|Win32 EXE|hackedapp|2019-03-12 04:38:39|13e4bda99c359789ced1470a9d6869efe90a18eef5e57de7097fd79627fc5619.bin|
|[a96226b8c5599e3391c7b111860dd654](https://www.virustotal.com/gui/file/a96226b8c5599e3391c7b111860dd654)|Win32 EXE|hackedapp|2019-01-30 22:17:24|infestation.exe|
|[7f05d410dc0d1b0e7a3fcc6cdda7a2ff](https://www.virustotal.com/gui/file/7f05d410dc0d1b0e7a3fcc6cdda7a2ff)|Win64 DLL|razy|2019-01-28 04:41:36|Qt5Network.dll|
|[092ae9ce61f6575344c424967bd79437](https://www.virustotal.com/gui/file/092ae9ce61f6575344c424967bd79437)|Win64 DLL||2019-01-28 02:58:06|Qt5Network.dll|
|[eb37c75369046fb1076450b3c34fb8ab](https://www.virustotal.com/gui/file/eb37c75369046fb1076450b3c34fb8ab)|Win64 DLL|razy|2019-01-27 12:32:42|Qt5Network.dll|
|[496c224d10e1b39a22967a331f7de0a2](https://www.virustotal.com/gui/file/496c224d10e1b39a22967a331f7de0a2)|Win32 EXE|hackedapp|2018-12-26 04:50:45|/1/b/a/ba2e0a2420fb4aed5859aebef745218d6e8b01b3c98c2212e1feca5ee9ffa091.file|
|[d1ed421779c31df2a059fe0f91c24721](https://www.virustotal.com/gui/file/d1ed421779c31df2a059fe0f91c24721)|Win32 EXE|hackedapp|2018-12-08 09:12:51|C:\Garena\Games\32790\PBConfig.exe|
|[aac57bac5f849585ba265a6cd35fde67](https://www.virustotal.com/gui/file/aac57bac5f849585ba265a6cd35fde67)|Win32 EXE|shadowhammer|2018-11-22 17:55:21|ohshit.exe|
|[8baa46d0e0faa2c6a3f20aeda2556b18](https://www.virustotal.com/gui/file/8baa46d0e0faa2c6a3f20aeda2556b18)|Win32 EXE|shadowhammer|2018-11-17 23:03:00|Setup|
|[b257f366a9f5a065130d4dc99152ee10](https://www.virustotal.com/gui/file/b257f366a9f5a065130d4dc99152ee10)|Win32 EXE|hackedapp|2018-11-16 10:27:10|gxxsvc|
|[943db472b4fd0c43428bfc6542d11913](https://www.virustotal.com/gui/file/943db472b4fd0c43428bfc6542d11913)|Win32 EXE|hackedapp|2018-11-06 02:00:22|b7fcc7f99bd5c440ead40ae26ddff95d5160a248345b27bb5daa5a0a3aa87814.bin|
|[0e1cc8693478d84e0c5e9edb2dc8555c](https://www.virustotal.com/gui/file/0e1cc8693478d84e0c5e9edb2dc8555c)|Win32 EXE|hackedapp|2018-10-29 12:09:58|PBConfig.exe|
|[05eacf843b716294ea759823d8f4ab23](https://www.virustotal.com/gui/file/05eacf843b716294ea759823d8f4ab23)|Win32 EXE|hackedapp|2018-10-24 15:17:14|PBConfig.exe|
|[55a7aa5f0e52ba4d78c145811c830107](https://www.virustotal.com/gui/file/55a7aa5f0e52ba4d78c145811c830107)|Win32 EXE|shadowhammer|2018-10-20 13:07:53|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/ShadowHammer/Setup.bin|
|[aa15eb28292321b586c27d8401703494](https://www.virustotal.com/gui/file/aa15eb28292321b586c27d8401703494)|ZIP|shadowhammer|2018-10-19 15:01:58|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/ShadowHammer/ShadowHammer.zip|
|[5b6cd0a85996a7d47a8e9f8011d4ad3f](https://www.virustotal.com/gui/file/5b6cd0a85996a7d47a8e9f8011d4ad3f)|Win32 EXE|hackedapp|2018-10-18 05:07:44|PBConfig.exe|
|[8756bafa7f0a9764311d52bc792009f9](https://www.virustotal.com/gui/file/8756bafa7f0a9764311d52bc792009f9)|Win32 EXE|shadowhammer|2018-10-13 07:11:05|Setup|
|[dc15e578401ad9b8f72c4d60b79fdf0f](https://www.virustotal.com/gui/file/dc15e578401ad9b8f72c4d60b79fdf0f)|Win32 EXE|hackedapp|2018-10-01 02:32:59|PBConfig.exe|
|[cdb0a09067877f30189811c7aea3f253](https://www.virustotal.com/gui/file/cdb0a09067877f30189811c7aea3f253)|Win32 EXE|shadowhammer|2018-09-30 22:59:50|Setup|
|[d4c4813b21556dd478315734e1c7ae54](https://www.virustotal.com/gui/file/d4c4813b21556dd478315734e1c7ae54)|Win32 EXE|hackedapp|2018-09-26 23:06:03|b2ed5738895bd7a1e831d085615931a2e2cb42de2219200563b69930df4504c6.bin|
|[5220c683de5b01a70487dac2440e0ecb](https://www.virustotal.com/gui/file/5220c683de5b01a70487dac2440e0ecb)|Win32 EXE|shadowhammer|2018-09-25 08:10:47|Setup|
|[fa96e56e7c26515875214eec743d2db5](https://www.virustotal.com/gui/file/fa96e56e7c26515875214eec743d2db5)|Win32 EXE|hackedapp|2018-09-22 06:41:34|ba717ced042f448c015432db9479dee3b7c61d27aaeace4f981ee96f5c797779.bin|
|[b044cd0f6aae371acf2e349ef78ab39e](https://www.virustotal.com/gui/file/b044cd0f6aae371acf2e349ef78ab39e)|Win32 EXE|hackedapp|2018-09-19 19:51:33|1680a880203c170b85cb86a649a4c722f43bcc2889f378b55484b3e0ad3e56b2.bin|
|[915086d90596eb5903bcd5b02fd97e3e](https://www.virustotal.com/gui/file/915086d90596eb5903bcd5b02fd97e3e)|Win32 EXE|shadowhammer|2018-09-06 09:35:02|Setup|
|[e7dcfa8e75b0437975ce0b2cb123dc7b](https://www.virustotal.com/gui/file/e7dcfa8e75b0437975ce0b2cb123dc7b)|Win32 EXE|hackedapp|2018-08-03 18:20:43|d191a9370159a33cdf11f5859cadec02ff2fa01d3b7b36ce9560e94b39cc799d.bin|
|[cb3f78d3ff776a7afe6c56371b0c7e11](https://www.virustotal.com/gui/file/cb3f78d3ff776a7afe6c56371b0c7e11)|Win32 EXE|shadowhammer|2018-07-24 03:41:07| |
|[2a95475af7a07ee95ab11caad9e99b0c](https://www.virustotal.com/gui/file/2a95475af7a07ee95ab11caad9e99b0c)|Win32 EXE|shadowhammer|2018-07-24 03:40:29|ac0711afee5a157d084251f3443a40965fc63c57955e3a241df866cfc7315223.bin|
|[5855ce7c4a3167f0e006310eb1c76313](https://www.virustotal.com/gui/file/5855ce7c4a3167f0e006310eb1c76313)|Win32 EXE|shadowhammer|2018-07-21 15:17:31|cfbec77180bd67cceb2e17e64f8a8beec5e8875f47c41936b67a60093e07fcfd.bin|
|[f2f879989d967e03b9ea0938399464ab](https://www.virustotal.com/gui/file/f2f879989d967e03b9ea0938399464ab)|Win32 EXE|shadowhammer|2018-07-21 15:17:02|setup.exe|
|[fa83ffde24f149f9f6d1d8bc05c0e023](https://www.virustotal.com/gui/file/fa83ffde24f149f9f6d1d8bc05c0e023)|Win32 EXE|shadowhammer|2018-06-29 14:19:24|C:\Users\daven\Downloads\b1tGob_6\c299b6dd210ab5779f3abd9d10544f9cae31cd5c6afc92c0fc16c8f43def7596|
|[17a36ac3e31f3a18936552aff2c80249](https://www.virustotal.com/gui/file/17a36ac3e31f3a18936552aff2c80249)|Win32 EXE|shadowhammer|2018-06-29 14:18:03|Asuse|
