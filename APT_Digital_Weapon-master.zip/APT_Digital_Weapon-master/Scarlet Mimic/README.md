**NAME:**  
Scarlet Mimic  

**Description**:   
Scarlet Mimic, named by PaloAlto, is likely a well-funded and skillfully resourced cyber adversary. It has carried out attacks using both spear-phishing and watering holes since at least 2009 with increasingly advanced malware, and has deployed malware including FakeM, Psylo, and MobileOrder, to attack multiple operating systems and platforms.
  
**References**:  
http://researchcenter.paloaltonetworks.com/2016/01/scarlet-mimic-years-long-espionage-targets-minority-activists/