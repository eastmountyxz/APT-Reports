**NAME:**  
APT15  
  
**Alias**  
Vixen Panda, APT15, APT 15, Royal APT, Playful Dragon, GREF, Metushy, Lurid, Social Network Team, Mirage, APT15, Ke3chang  
  
**Description**:   
  APT15 is a threat group that has been active since at least 2010 and targeted several industries, including oil, government, military, and more. FireEye mentioned that the attackers may be operating from China while their exact identities and motivation remain unknown.  

**References**:  
https://www.fireeye.com/blog/threat-research/2014/09/forced-to-adapt-xslcmd-backdoor-now-on-os-x.html  
https://www.fireeye.com/content/dam/fireeye-www/global/en/current-threats/pdfs/wp-operation-ke3chang.pdf


