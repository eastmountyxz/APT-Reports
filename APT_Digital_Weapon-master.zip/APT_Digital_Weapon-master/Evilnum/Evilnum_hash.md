|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d92359c62de56dcd5d970b35f7918194](https://www.virustotal.com/gui/file/d92359c62de56dcd5d970b35f7918194)|TXT||2020-09-07 13:25:34|d92359c62de56dcd5d970b35f7918194.bin|
|[e53d8a86ad7b505de72da31b13ffcd3f](https://www.virustotal.com/gui/file/e53d8a86ad7b505de72da31b13ffcd3f)|TXT||2020-09-07 13:24:58|e53d8a86ad7b505de72da31b13ffcd3f.bin|
|[38df69eadf34f0a57c59a0fab7beae51](https://www.virustotal.com/gui/file/38df69eadf34f0a57c59a0fab7beae51)|Win32 EXE||2020-09-07 08:30:19|Java(TM) Web Start Launcher|
|[5ec381a8f872063715b055bb9ab1e323](https://www.virustotal.com/gui/file/5ec381a8f872063715b055bb9ab1e323)|Win32 EXE|Skeeyah|2020-09-07 08:29:01|nvStInst.exe|
|[123979be43ee455e7ba4f91c3a3dd567](https://www.virustotal.com/gui/file/123979be43ee455e7ba4f91c3a3dd567)|PDF||2020-09-07 08:23:37|123979be43ee455e7ba4f91c3a3dd567.in|
|[48cf7f7b4180b1c4fb3ac3e149917130](https://www.virustotal.com/gui/file/48cf7f7b4180b1c4fb3ac3e149917130)|LNK||2020-08-25 09:32:45|JointAccountDCS.pdf.lnk|
|[6706b28accb971bd98738649725456a9](https://www.virustotal.com/gui/file/6706b28accb971bd98738649725456a9)|Win32 EXE||2020-08-04 01:39:32|Java(TM) Web Start Launcher|
|[ffee111b993de52e2034e31953dee86b](https://www.virustotal.com/gui/file/ffee111b993de52e2034e31953dee86b)|LNK||2020-08-03 23:58:37|c:\users\admini~1\appdata\local\temp\1.lnk|
|[aad36ffbe3fc85f853751f4329a346e9](https://www.virustotal.com/gui/file/aad36ffbe3fc85f853751f4329a346e9)|LNK||2020-07-21 04:34:59|PersonalKYC.pdf.lnk|
|[2b33321ead1744461759d9c092b3c7d4](https://www.virustotal.com/gui/file/2b33321ead1744461759d9c092b3c7d4)|TXT|Sagent|2020-07-19 22:48:18|VirusShare_2b33321ead1744461759d9c092b3c7d4|
|[7b478edc2b74d7ecdc6b1d9532c9e7f8](https://www.virustotal.com/gui/file/7b478edc2b74d7ecdc6b1d9532c9e7f8)|Win32 EXE||2020-07-07 18:56:18|nvStInst.exe|
|[8b346ef17943e7923e44e80c5b129a47](https://www.virustotal.com/gui/file/8b346ef17943e7923e44e80c5b129a47)|Win32 EXE||2020-07-07 18:50:55|Java(TM) Web Start Launcher|
|[6363ddf8a20345c0201868b209afbd63](https://www.virustotal.com/gui/file/6363ddf8a20345c0201868b209afbd63)|LNK||2020-07-07 15:45:26|compliance-docpack.pdf.lnk|
|[fc00819c4cdc8609313041cf345a7dca](https://www.virustotal.com/gui/file/fc00819c4cdc8609313041cf345a7dca)|LNK||2020-06-29 09:53:54|VerificationDocuments.pdf.lnk|
|[cb908352d719b9e0a7142c4110ae502e](https://www.virustotal.com/gui/file/cb908352d719b9e0a7142c4110ae502e)|LNK||2020-06-18 14:33:47|VerificationDocuments.pdf.lnk|
|[25d6eeba718af78275f2c9a4a58cd8b2](https://www.virustotal.com/gui/file/25d6eeba718af78275f2c9a4a58cd8b2)|LNK||2020-05-12 15:23:36|e7510a4f5a90271f278970a8cb62d116b15ff08884c072ef44e419f896d65237.bin|
|[48e90ca0f344e1a0445936f2d28ae01f](https://www.virustotal.com/gui/file/48e90ca0f344e1a0445936f2d28ae01f)|LNK||2020-05-12 15:23:34|18558a236e6dc15447c4683d38d4cd5c65331f2469b95b65342a1dcc5e4999fe.bin|
|[42a0e13c97e0aa0867f769b71e378d24](https://www.virustotal.com/gui/file/42a0e13c97e0aa0867f769b71e378d24)|LNK||2020-05-12 15:23:33|bb579920513264854cb4ff08d86eb4ee6c2ade66ca14abd9752320053a1a7028.bin|
|[85b2d96080c853c686f0b7b7284896a8](https://www.virustotal.com/gui/file/85b2d96080c853c686f0b7b7284896a8)|LNK||2020-05-12 15:23:32|Barclays CC Back.jpg.lnk|
|[5b733b77e3bd909efd9f7acfa58e4770](https://www.virustotal.com/gui/file/5b733b77e3bd909efd9f7acfa58e4770)|LNK||2020-05-04 15:47:28|4.png.lnk|
|[12fd4e486b418914dbeedc4effc73426](https://www.virustotal.com/gui/file/12fd4e486b418914dbeedc4effc73426)|LNK||2020-05-04 15:47:27|3.png.lnk|
|[c32820d1eb296d44c56f8430584d9d69](https://www.virustotal.com/gui/file/c32820d1eb296d44c56f8430584d9d69)|LNK||2020-05-04 15:47:26|C:\Users\ADMINI~1\AppData\Local\Temp\1.lnk|
|[1e5bc1d8f6d2cd52e622dc1d60ae35a7](https://www.virustotal.com/gui/file/1e5bc1d8f6d2cd52e622dc1d60ae35a7)|HTML||2020-05-01 15:50:18|c0f50b921260b070d3db1a372eb05d932e05a87ebc13b608c0ec46989f56f013.bin|
|[7783211ed125bbe31cf50b47e9e96fbb](https://www.virustotal.com/gui/file/7783211ed125bbe31cf50b47e9e96fbb)|Win32 EXE||2020-04-22 11:30:39|ServiceHud.exe|
|[3df04716db7e3ec08648ebdf090ca36e](https://www.virustotal.com/gui/file/3df04716db7e3ec08648ebdf090ca36e)|Win32 EXE||2020-04-22 11:25:39|ypoc.exe|
|[6a381f91caf7457c693a456290bb332a](https://www.virustotal.com/gui/file/6a381f91caf7457c693a456290bb332a)|Win32 EXE||2020-04-16 20:50:15|Policy.exe|
|[9888accbce9c3be970d4eb3c7a253b86](https://www.virustotal.com/gui/file/9888accbce9c3be970d4eb3c7a253b86)|Win32 EXE||2020-04-16 20:50:08|ypoc.exe|
|[37d4011965747658d3a4dce01d375677](https://www.virustotal.com/gui/file/37d4011965747658d3a4dce01d375677)|FPX||2020-04-16 13:29:58|2461d5d8eb8bfaa6b178fe2c457c215bbea85443a7d33bb007aa7dce52428d18.bin|
|[cb57951e1b18cc31680a6e50b259b7d8](https://www.virustotal.com/gui/file/cb57951e1b18cc31680a6e50b259b7d8)|Win32 DLL|Ursu|2020-04-09 00:52:58|KeePassLib|
|[8ef5fad49b544d4ae14add39d325a3c6](https://www.virustotal.com/gui/file/8ef5fad49b544d4ae14add39d325a3c6)|LNK||2020-04-06 14:56:23|83e5eeb549543e16f98eb26d848194baa8273d5e0408c72222999535f91434fe.bin|
|[70a03cefc2345047ad3d42175e15536c](https://www.virustotal.com/gui/file/70a03cefc2345047ad3d42175e15536c)|LNK||2020-04-06 14:55:48|ceb892d73cbfea205239dab384101305a957bfd675486a126787a74068c1ddea.bin|
|[3d0836ddc60ac65f9c43cc6732e5317c](https://www.virustotal.com/gui/file/3d0836ddc60ac65f9c43cc6732e5317c)|LNK||2020-04-06 14:54:52|c:\users\administrator\appdata\local\temp\1.lnk|
|[41a80cc28047b7aeafe846aaa23c2cfe](https://www.virustotal.com/gui/file/41a80cc28047b7aeafe846aaa23c2cfe)|LNK||2020-04-06 14:53:41|ca23b0c263652259fc9163d9981033913c9aa3d51a23b1e43f145ca0e0960a30.bin|
|[781f6dd5bff76b38ae52da352c976850](https://www.virustotal.com/gui/file/781f6dd5bff76b38ae52da352c976850)|LNK||2020-04-02 06:51:06|Tax Bill Utility.jpg.lnk.bin|
|[2dbd582b909880eb446ed36e0129ad4b](https://www.virustotal.com/gui/file/2dbd582b909880eb446ed36e0129ad4b)|Win32 DLL|Ursu|2020-04-01 15:59:06|libgdk_pixbuf-2.0-0|
|[fcce335ad11f4e568e6fe23ae766b187](https://www.virustotal.com/gui/file/fcce335ad11f4e568e6fe23ae766b187)|Win32 DLL|occamy|2020-04-01 12:27:11|libgdk_pixbuf-2.0-0|
|[b034972a9540b3b00161310f5bf03fc9](https://www.virustotal.com/gui/file/b034972a9540b3b00161310f5bf03fc9)|Win64 DLL||2020-04-01 07:58:38|XVI32|
|[d76f443222551edfe07b357c3bb157da](https://www.virustotal.com/gui/file/d76f443222551edfe07b357c3bb157da)|Win64 DLL||2020-03-24 10:09:39|XVI32|
|[7cfeb19c792c78c791367c89f74bc8ab](https://www.virustotal.com/gui/file/7cfeb19c792c78c791367c89f74bc8ab)|Win64 DLL||2020-03-16 18:50:33|XVI32|
|[768ef933f1a00f2996fc957a35c56c95](https://www.virustotal.com/gui/file/768ef933f1a00f2996fc957a35c56c95)|LNK||2020-03-16 07:56:44|Credit Card Front.png.lnk|
|[e07c8e2f268018c7a751998dec8502c7](https://www.virustotal.com/gui/file/e07c8e2f268018c7a751998dec8502c7)|LNK||2020-03-09 15:49:46|GDPR-EXANTE2020.pdf.lnk|
|[61e2b04c0d33740d407d735f00062ab8](https://www.virustotal.com/gui/file/61e2b04c0d33740d407d735f00062ab8)|LNK||2020-02-21 17:14:20|D:\Download\e06ab6b87c4977c4ee30f3925dd935764a0ec0da11458aca4308da61b8027d76.bin|
|[9e81a4350ab3225a4d5a9a17b1c34bcb](https://www.virustotal.com/gui/file/9e81a4350ab3225a4d5a9a17b1c34bcb)|Win32 EXE|Cardinal|2020-02-10 14:34:36|Policy.exe|
|[0823457bcb82afff15c900f949e325f4](https://www.virustotal.com/gui/file/0823457bcb82afff15c900f949e325f4)|Win32 EXE|Cardinal|2019-12-30 11:55:23|Policy.exe|
|[02bf629bd6a36b96e8215d41f58415ea](https://www.virustotal.com/gui/file/02bf629bd6a36b96e8215d41f58415ea)|LNK||2019-12-17 18:51:07|Proof of Address.pdf.lnk|
|[9e5e6e980f5fa81d6e503b7d62e8b5a8](https://www.virustotal.com/gui/file/9e5e6e980f5fa81d6e503b7d62e8b5a8)|LNK||2019-12-17 18:51:04|Driv License Front.jpg.lnk|
|[2eb0c0ddcdfcb18412afa1d79e16c206](https://www.virustotal.com/gui/file/2eb0c0ddcdfcb18412afa1d79e16c206)|LNK||2019-12-17 18:51:02|Driv License Back.jpg.lnk|
|[8c4675a080b642bbf9f096d0e60711ff](https://www.virustotal.com/gui/file/8c4675a080b642bbf9f096d0e60711ff)|LNK||2019-12-17 18:50:59|Credit Card Front.jpg.lnk|
|[80b0ba4ef46a22bfd43f967905c25a75](https://www.virustotal.com/gui/file/80b0ba4ef46a22bfd43f967905c25a75)|LNK||2019-12-17 18:50:57|Credit Card Back.jpg.lnk|
|[f8b83901acf1e744441b5c2b3d954354](https://www.virustotal.com/gui/file/f8b83901acf1e744441b5c2b3d954354)|LNK||2019-11-29 05:57:17|passport front.jpg.lnk|
|[40d64f88071b43abaf29687a1f1ed882](https://www.virustotal.com/gui/file/40d64f88071b43abaf29687a1f1ed882)|LNK||2019-05-25 12:02:28|dolisznyj_id_front.jpg.lnk|
|[f226dbe5dc77fe071ffc8c5d3c82e424](https://www.virustotal.com/gui/file/f226dbe5dc77fe071ffc8c5d3c82e424)|TXT||2019-02-18 09:19:03|Assistance.js|
|[219dedb53da6b1dce0d6c071af59b45c](https://www.virustotal.com/gui/file/219dedb53da6b1dce0d6c071af59b45c)|LNK||2018-12-03 13:26:00|200_Germany.lnk|
|[a234deb636d76b7eb0cf88a305b4acf3](https://www.virustotal.com/gui/file/a234deb636d76b7eb0cf88a305b4acf3)|unknown||2013-07-16 17:34:28|MSCERT02.CER|
