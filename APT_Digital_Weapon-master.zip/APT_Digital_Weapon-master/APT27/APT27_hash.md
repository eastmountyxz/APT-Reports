|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[86c9e95dcf69f6eca2a176407dcb99ff](https://www.virustotal.com/gui/file/86c9e95dcf69f6eca2a176407dcb99ff)|Win32 EXE||2019-12-21 13:07:19|RahaSecIOC-x86.exe|
|[25517b158b729b7641e57241caa59ece](https://www.virustotal.com/gui/file/25517b158b729b7641e57241caa59ece)|Text||2019-10-09 10:33:37|70404.jpg|
|[70cff7c176c7df265a808aa52daf6f34](https://www.virustotal.com/gui/file/70cff7c176c7df265a808aa52daf6f34)|Win32 EXE||2019-09-16 20:17:49|odbcad32.exe|
|[a2eb59414823ae00d53ca05272168006](https://www.virustotal.com/gui/file/a2eb59414823ae00d53ca05272168006)|Win64 EXE||2019-09-09 09:30:20|<DRIVERS>\ndisproxy-mn.sys|
|[bc1305a6ca71d8bdb3961bfd4e2b3565](https://www.virustotal.com/gui/file/bc1305a6ca71d8bdb3961bfd4e2b3565)|Win32 DLL||2019-05-06 06:35:17|PYTHON33.dll|
|[95c60e0c0efe260ab1317ef500fda5af](https://www.virustotal.com/gui/file/95c60e0c0efe260ab1317ef500fda5af)|Text|zapchast|2019-05-02 09:40:47|6b3f835acbd954af168184f57c9d8e6798898e9ee650bd543ea6f2e9d5cf6378.bin|
|[9dc209f66da77858e362e624d0be86b3](https://www.virustotal.com/gui/file/9dc209f66da77858e362e624d0be86b3)|Win32 EXE||2019-02-13 02:04:32|chrome.exe|
|[5bcf71601eac1549e9ee60c06f4f55ed](https://www.virustotal.com/gui/file/5bcf71601eac1549e9ee60c06f4f55ed)|Win64 EXE||2019-01-11 14:09:42| |
|[3eeb4a7c692597df54e446c3dc110403](https://www.virustotal.com/gui/file/3eeb4a7c692597df54e446c3dc110403)|Win32 EXE||2019-01-04 02:27:23|090cefebef655be7f879f2f14bd849ac20c4051d0c13e55410a49789738fad98.bin|
|[1dd30422a1cb52d87337debb4983d342](https://www.virustotal.com/gui/file/1dd30422a1cb52d87337debb4983d342)|Win32 EXE||2018-11-01 02:26:20|7eea6e15bb13a3b65cca9405829123761bf7d12c6dc3b81ce499d8f6a0b25fb7.bin|
|[9dd9d006d40d7e43eedbd1db385844b8](https://www.virustotal.com/gui/file/9dd9d006d40d7e43eedbd1db385844b8)|Win32 EXE||2018-10-27 08:26:18|e781ce2d795c5dd6b0a5b849a414f5bd05bb99785f2ebf36edb70399205817ee.bin|
|[9e3dcc980bb4c1ce69048b6b5eeea823](https://www.virustotal.com/gui/file/9e3dcc980bb4c1ce69048b6b5eeea823)|Win32 EXE|Virut|2018-09-25 23:18:46| |
|[bd052811fffe5cc1e908a21a873fd43d](https://www.virustotal.com/gui/file/bd052811fffe5cc1e908a21a873fd43d)|Win32 DLL|Symmi|2018-09-25 22:30:53|bd052811fffe5cc1e908a21a873fd43d.virus|
|[d00775c66fa4835f1f427ff873b64cba](https://www.virustotal.com/gui/file/d00775c66fa4835f1f427ff873b64cba)|Win32 EXE|Virut|2018-09-25 19:14:16| |
|[bdaa11e64d00b25c99c254f0c2f5787f](https://www.virustotal.com/gui/file/bdaa11e64d00b25c99c254f0c2f5787f)|Win32 DLL|virtob|2018-09-25 14:36:51| |
|[b9a1fa2edb4eeb270b7c7e18e963ba5f](https://www.virustotal.com/gui/file/b9a1fa2edb4eeb270b7c7e18e963ba5f)|Win32 DLL|kazy|2018-09-25 14:04:08| |
|[294d7e213525c0bcb70b07667d789d6d](https://www.virustotal.com/gui/file/294d7e213525c0bcb70b07667d789d6d)|Win32 DLL|FakeLPK|2018-09-24 23:56:47| |
|[6a18a43b9c12ba82e7ef413d17bcc36b](https://www.virustotal.com/gui/file/6a18a43b9c12ba82e7ef413d17bcc36b)|Win32 DLL|virtob|2018-09-24 23:51:29| |
|[7a86f39d1a551bfb648856bc99fb10f9](https://www.virustotal.com/gui/file/7a86f39d1a551bfb648856bc99fb10f9)|Win32 DLL|pornoblocker|2018-09-24 23:41:34|myfile.exe|
|[88019fceae0b787d09ecdbd454a2b40e](https://www.virustotal.com/gui/file/88019fceae0b787d09ecdbd454a2b40e)|Win32 EXE|Parite|2018-09-24 22:26:33| |
|[58458a529d4ff6848be58ba26349749d](https://www.virustotal.com/gui/file/58458a529d4ff6848be58ba26349749d)|Win32 EXE|Virut|2018-09-24 18:08:06| |
|[03093a21dd46c916c846d2244dbf2bcb](https://www.virustotal.com/gui/file/03093a21dd46c916c846d2244dbf2bcb)|Win32 DLL|Parite|2018-09-24 15:19:07|myfile.exe|
|[d1e675aff0d308fece6194a7b629a6bd](https://www.virustotal.com/gui/file/d1e675aff0d308fece6194a7b629a6bd)|Win32 EXE|Virut|2018-09-24 08:19:43|102|
|[4ce12bbc292b9dd3a641b7e0483e8193](https://www.virustotal.com/gui/file/4ce12bbc292b9dd3a641b7e0483e8193)|Win64 EXE||2018-09-24 04:42:50|SecConfig.efi|
|[bc25bbf8a5bb344da9aef282fdab57cf](https://www.virustotal.com/gui/file/bc25bbf8a5bb344da9aef282fdab57cf)|Win32 EXE|Virut|2018-09-23 17:45:43|server|
|[d999a22ff6b541817221bd74e1d55f9f](https://www.virustotal.com/gui/file/d999a22ff6b541817221bd74e1d55f9f)|Win32 DLL|virtob|2018-09-23 12:51:01|d999a22ff6b541817221bd74e1d55f9f.virus|
|[f443b38ba80c228bf0d7defc9d8c18c5](https://www.virustotal.com/gui/file/f443b38ba80c228bf0d7defc9d8c18c5)|Win32 EXE|Virut|2018-09-23 12:44:08|server|
|[18d5de92036241d0d49b186840bdcc30](https://www.virustotal.com/gui/file/18d5de92036241d0d49b186840bdcc30)|Win32 DLL|virtob|2018-09-23 12:13:36|18d5de92036241d0d49b186840bdcc30.virobj|
|[1f9e6cfef0216755d6a9cec2fab0f5dc](https://www.virustotal.com/gui/file/1f9e6cfef0216755d6a9cec2fab0f5dc)|Win32 DLL||2018-09-23 06:38:52|1f9e6cfef0216755d6a9cec2fab0f5dc.virus|
|[083fd97c06babdb441f34cbb489d5a50](https://www.virustotal.com/gui/file/083fd97c06babdb441f34cbb489d5a50)|Win32 DLL|virtob|2018-09-23 05:20:20|083fd97c06babdb441f34cbb489d5a50.virobj|
|[239edaf861ddeb43113d913d081c48a1](https://www.virustotal.com/gui/file/239edaf861ddeb43113d913d081c48a1)|Win32 EXE|Virut|2018-09-23 03:47:26| |
|[d78ac51f69c511199bbe79a683037672](https://www.virustotal.com/gui/file/d78ac51f69c511199bbe79a683037672)|Win32 EXE||2018-09-23 03:27:48|_zerol_wsasme.exe|
|[232a788c66bbf24c556ad30997d61ff8](https://www.virustotal.com/gui/file/232a788c66bbf24c556ad30997d61ff8)|Win32 DLL||2018-09-22 20:53:04|232a788c66bbf24c556ad30997d61ff8.virus|
|[a87bd421844b838d487c1d94f7d06bc6](https://www.virustotal.com/gui/file/a87bd421844b838d487c1d94f7d06bc6)|Win32 DLL|razy|2018-09-22 12:49:30| |
|[2645eac10876fbe03976af2f69273f0a](https://www.virustotal.com/gui/file/2645eac10876fbe03976af2f69273f0a)|Win32 EXE|Virut|2018-09-22 11:12:31| |
|[a67c747837b14de1dbf6534aaf940731](https://www.virustotal.com/gui/file/a67c747837b14de1dbf6534aaf940731)|Win32 EXE|microfake|2018-09-22 11:08:55| |
|[f04afc1c31dacc002933a1f929d7b303](https://www.virustotal.com/gui/file/f04afc1c31dacc002933a1f929d7b303)|Win32 EXE||2018-09-22 09:42:45|QcConsol.exe|
|[5408ef844e2aeba3092d379420797078](https://www.virustotal.com/gui/file/5408ef844e2aeba3092d379420797078)|Win32 DLL|agentwdcr|2018-09-22 01:25:36|5408ef844e2aeba3092d379420797078.virus|
|[197cb8eaf3797318f49a01a53b6b6372](https://www.virustotal.com/gui/file/197cb8eaf3797318f49a01a53b6b6372)|Win32 DLL|virtob|2018-09-21 13:05:51| |
|[fc150c86b40d094ffa1d74346c519b7a](https://www.virustotal.com/gui/file/fc150c86b40d094ffa1d74346c519b7a)|Win32 EXE|Virut|2018-09-21 12:21:36|myfile.exe|
|[ec9d4ea6d94186185edc08bb588355c9](https://www.virustotal.com/gui/file/ec9d4ea6d94186185edc08bb588355c9)|Win32 EXE|Virut|2018-09-21 11:10:34| |
|[bdf46dd26d747ce97b8a45410a9cdc85](https://www.virustotal.com/gui/file/bdf46dd26d747ce97b8a45410a9cdc85)|Win32 DLL|virtob|2018-09-21 08:23:01|bdf46dd26d747ce97b8a45410a9cdc85.virus|
|[04f540671bfad403eb18569575a0add5](https://www.virustotal.com/gui/file/04f540671bfad403eb18569575a0add5)|Win32 EXE|razy|2018-09-21 02:18:52| |
|[d2961d64ecb9d22ef8b6d7280d818a29](https://www.virustotal.com/gui/file/d2961d64ecb9d22ef8b6d7280d818a29)|Win32 DLL|microfake|2018-09-20 18:24:17|lpk.dll|
|[10fa0058d6bdb26ae3e7880a9f6f1c87](https://www.virustotal.com/gui/file/10fa0058d6bdb26ae3e7880a9f6f1c87)|Win32 DLL|microfake|2018-09-20 00:42:04|10fa0058d6bdb26ae3e7880a9f6f1c87.virus|
|[40223513419edaea286c431eba5d1449](https://www.virustotal.com/gui/file/40223513419edaea286c431eba5d1449)|Win32 DLL|kazy|2018-09-20 00:40:12|40223513419edaea286c431eba5d1449.virus|
|[8f3b0daeaa04150b76ca9a3ddca7889c](https://www.virustotal.com/gui/file/8f3b0daeaa04150b76ca9a3ddca7889c)|Win32 DLL|kazy|2018-09-20 00:34:23|8f3b0daeaa04150b76ca9a3ddca7889c.virus|
|[2e99cdf7829a5714bd76d8c793039ec6](https://www.virustotal.com/gui/file/2e99cdf7829a5714bd76d8c793039ec6)|Win32 DLL||2018-09-20 00:33:59|2e99cdf7829a5714bd76d8c793039ec6.virus|
|[6c9d7a0f84c1bc18725fa59990c7abd8](https://www.virustotal.com/gui/file/6c9d7a0f84c1bc18725fa59990c7abd8)|Win32 DLL|kazy|2018-09-20 00:33:42|6c9d7a0f84c1bc18725fa59990c7abd8.virus|
|[2e73102f59a5f319414626e6ad7df6e2](https://www.virustotal.com/gui/file/2e73102f59a5f319414626e6ad7df6e2)|Win32 DLL||2018-09-20 00:33:03|2e73102f59a5f319414626e6ad7df6e2.virus|
|[8707578cc25e4047507ee293dea0d037](https://www.virustotal.com/gui/file/8707578cc25e4047507ee293dea0d037)|Win32 DLL|kazy|2018-09-20 00:23:52|8707578cc25e4047507ee293dea0d037.virus|
|[38b37cd02c736bb7b9a3fa77bb4095ce](https://www.virustotal.com/gui/file/38b37cd02c736bb7b9a3fa77bb4095ce)|Win32 DLL|microfake|2018-09-20 00:20:10|38b37cd02c736bb7b9a3fa77bb4095ce.virus|
|[11d364135c1012d8c584b18cb390757d](https://www.virustotal.com/gui/file/11d364135c1012d8c584b18cb390757d)|Win32 EXE|Virut|2018-09-19 22:14:40| |
|[f1b352680bda1c2c7e04f4ae94f56a46](https://www.virustotal.com/gui/file/f1b352680bda1c2c7e04f4ae94f56a46)|Win32 DLL|Zbot|2018-07-28 12:50:22|f1b352680bda1c2c7e04f4ae94f56a46.virus|
|[d4bb5c6364c4b4a07e6bbf2177129655](https://www.virustotal.com/gui/file/d4bb5c6364c4b4a07e6bbf2177129655)|unknown||2018-07-09 15:52:46|dcfc9e4077705385328133557629fffee11662b7843b34dd4e1e42404ac2e921.sample|
|[b7f958f93e2f297e717cffc2fe43f2e9](https://www.virustotal.com/gui/file/b7f958f93e2f297e717cffc2fe43f2e9)|Win32 EXE||2018-07-03 18:23:06|odbcad32.exe|
|[06348bbe0cc839f23c2d9471cfb19de3](https://www.virustotal.com/gui/file/06348bbe0cc839f23c2d9471cfb19de3)|Win32 EXE|Farfli|2018-07-02 04:22:48|b43ccd5b23d348f72466612d597ad71246113a9d524c9b27e682d1f7300a0672.bin|
|[62bcbfae5276064615d0d45b895fdff2](https://www.virustotal.com/gui/file/62bcbfae5276064615d0d45b895fdff2)|Win32 DLL||2018-06-04 15:40:21|scksp.dll|
|[ae9c39e0d9a0c0ae48a72cb10521d2f3](https://www.virustotal.com/gui/file/ae9c39e0d9a0c0ae48a72cb10521d2f3)|Win32 EXE|Zxshell|2018-05-16 11:18:21|autochk.sys|
|[40cdd3cfe86c93872b163fb3550f47f6](https://www.virustotal.com/gui/file/40cdd3cfe86c93872b163fb3550f47f6)|Win32 EXE|Farfli|2018-04-04 12:10:24|T.EXE|
|[ec645e21e93d215a5b7e0d86ae5b75b9](https://www.virustotal.com/gui/file/ec645e21e93d215a5b7e0d86ae5b75b9)|Win32 EXE||2018-04-04 08:41:11|38fa396770e0ecf60fe1ce089422283e2dc8599489bd18d5eb033255dd8e370c.bin|
|[04dece2662f648f619d9c0377a7ba7c0](https://www.virustotal.com/gui/file/04dece2662f648f619d9c0377a7ba7c0)|Win32 DLL|Symmi|2018-03-29 17:49:18|myfile.exe|
|[c69d60b82252b6e7eaaeb710d5e1ebe5](https://www.virustotal.com/gui/file/c69d60b82252b6e7eaaeb710d5e1ebe5)|Win32 DLL|Ursu|2018-03-27 07:44:48|inicore_v2.3.30.dll|
|[9c42cd7efbdfc47303d051f056c52d29](https://www.virustotal.com/gui/file/9c42cd7efbdfc47303d051f056c52d29)|Win32 DLL|Farfli|2018-02-08 17:28:03|svchost4|
|[9f8b60567642b9fd54af9ab644ce0ca0](https://www.virustotal.com/gui/file/9f8b60567642b9fd54af9ab644ce0ca0)|Win32 EXE|Ursu|2018-01-22 07:13:06|smb.exe|
|[cbb84d382724dd8adc5725dfca9b4af1](https://www.virustotal.com/gui/file/cbb84d382724dd8adc5725dfca9b4af1)|Win32 DLL|Zbot|2017-12-08 05:57:54|pdh.dll|
|[ef41da16fdedcc450d0cc6ca708a9222](https://www.virustotal.com/gui/file/ef41da16fdedcc450d0cc6ca708a9222)|Win32 EXE||2017-12-08 05:33:51|ef41da16fdedcc450d0cc6ca708a9222.virus|
|[8cb11e271aba3354545a77751c1e783e](https://www.virustotal.com/gui/file/8cb11e271aba3354545a77751c1e783e)|Win32 DLL||2017-12-07 05:29:24|pdh.dll|
|[c25e8e4a2d5314ea55afd09845b3e886](https://www.virustotal.com/gui/file/c25e8e4a2d5314ea55afd09845b3e886)|Win32 EXE||2017-12-07 05:29:07|e8cf3522b68a51b2aabcfc6f98b39da15a23da1d|
|[17acc1d983dde32b5bcde9c9624848b0](https://www.virustotal.com/gui/file/17acc1d983dde32b5bcde9c9624848b0)|Win32 EXE||2017-11-21 02:42:23|1023-a03b14cac23dcfa2b2e12d5a8e53959d5a2e8fa2|
|[22cbe2b0f1ef3f2b18b4c5aed6d7bb79](https://www.virustotal.com/gui/file/22cbe2b0f1ef3f2b18b4c5aed6d7bb79)|Win32 EXE|Zbot|2017-11-20 04:42:39|7zS2.sfx|
|[0d0320878946a73749111e6c94bf1525](https://www.virustotal.com/gui/file/0d0320878946a73749111e6c94bf1525)|Win32 EXE|Zbot|2017-11-19 14:19:55|7zS2.sfx|
|[53d0db22c5abaf904d85facb70a60c8e](https://www.virustotal.com/gui/file/53d0db22c5abaf904d85facb70a60c8e)|Win32 DLL||2017-11-15 06:40:57|1024-d363606e6159a786b06891227efac2164eeda7b3|
|[88a27758f3066dd4da18983a005ddc20](https://www.virustotal.com/gui/file/88a27758f3066dd4da18983a005ddc20)|Win32 EXE|Zbot|2017-11-15 06:40:55|88a27758f3066dd4da18983a005ddc20.virobj|
|[8b8e44bd5e4a9f7d58714ba9ca72351c](https://www.virustotal.com/gui/file/8b8e44bd5e4a9f7d58714ba9ca72351c)|DOCX||2017-11-15 06:40:09|FINAL.docx|
|[0955e01bc26455965b682247ecb86add](https://www.virustotal.com/gui/file/0955e01bc26455965b682247ecb86add)|Win32 DLL|injector|2017-09-19 19:46:51|pdh.dll|
|[c8d83840b96f5a186e7bb6320e998f72](https://www.virustotal.com/gui/file/c8d83840b96f5a186e7bb6320e998f72)|Win32 EXE|vigorf|2017-09-19 16:40:45|c8d83840b96f5a186e7bb6320e998f72.virus|
|[78142cdad08524475f710e5702827a66](https://www.virustotal.com/gui/file/78142cdad08524475f710e5702827a66)|unknown||2017-05-26 06:53:18|sys.bin.url|
|[a13772805b772f374f7d709999a816d5](https://www.virustotal.com/gui/file/a13772805b772f374f7d709999a816d5)|Win32 DLL||2017-05-24 20:37:54|Wsock32.dll|
|[9814cdc7033a97fcf4f31aa377be60ba](https://www.virustotal.com/gui/file/9814cdc7033a97fcf4f31aa377be60ba)|Win32 DLL|dynamer|2017-01-06 11:30:30|LDVPOCX.OCX|
|[2820653437d5935d94fcb0c997d6f13c](https://www.virustotal.com/gui/file/2820653437d5935d94fcb0c997d6f13c)|Win32 EXE||2016-09-09 12:45:07|/agent_Win32.exe|
|[ac9157fb554804636893154bf9b6c8e3](https://www.virustotal.com/gui/file/ac9157fb554804636893154bf9b6c8e3)|Win32 EXE|Symmi|2016-03-06 07:25:48|server|
|[2bcb003d74f93df762f94ed3c74dea6d](https://www.virustotal.com/gui/file/2bcb003d74f93df762f94ed3c74dea6d)|Win32 EXE||2014-11-03 10:19:37|s.exe|
|[fb541339e8d3047360ce11dfd5ca6e65](https://www.virustotal.com/gui/file/fb541339e8d3047360ce11dfd5ca6e65)|Win32 EXE||2014-07-28 01:13:45|INISafeWebSSO|
|[f9a00b2264b08435553b6b94098504f4](https://www.virustotal.com/gui/file/f9a00b2264b08435553b6b94098504f4)|Win32 EXE|FakeLPK|2014-04-20 00:49:51|b70c106991a7577f31efeace40fc1dded28389c4|
|[4489e8cb847cccf4d2d87ee3372e8235](https://www.virustotal.com/gui/file/4489e8cb847cccf4d2d87ee3372e8235)|Win32 EXE||2012-07-19 17:14:50|9f5f3a9ce156213445d08d1a9ea99356d2136924dc28a8ceca6d528f9dbd718b.bin|
|[0662e0e6e2db47c65ff600678007312a](https://www.virustotal.com/gui/file/0662e0e6e2db47c65ff600678007312a)|Win32 DLL|kazy|2011-07-03 14:17:03|/home/nfs/data/VirusShare_unzip/VirusShare_0662e0e6e2db47c65ff600678007312a|
|[ab4ed49e594e6e31ab31ca4e411525ad](https://www.virustotal.com/gui/file/ab4ed49e594e6e31ab31ca4e411525ad)|Win32 EXE|Rincux|2010-06-30 12:21:35|ccuwco.exe|
|[f01a9a2d1e31332ed36c1a4d2839f412](https://www.virustotal.com/gui/file/f01a9a2d1e31332ed36c1a4d2839f412)|Win32 EXE||2009-02-12 22:19:48|nb.exe|
|[0762764e298c369a2de8afaec5174ed9](https://www.virustotal.com/gui/file/0762764e298c369a2de8afaec5174ed9)|Win32 EXE|pswtool|2008-05-09 07:48:34|fgdump|
|[5fd6b30d0e9d0bf6c388f8c8cbf9823e](https://www.virustotal.com/gui/file/5fd6b30d0e9d0bf6c388f8c8cbf9823e)|Win32 DLL|Pcclient|2008-02-16 18:15:42|/home/nfs/data/VirusShare_unzip/VirusShare_5fd6b30d0e9d0bf6c388f8c8cbf9823e|
|[3a97d9b6f17754dcd38ca7fc89caab04](https://www.virustotal.com/gui/file/3a97d9b6f17754dcd38ca7fc89caab04)|Win32 EXE||2006-06-27 04:43:11|ScanLine|
|[eefeb76d26338e09958aae5d81479178](https://www.virustotal.com/gui/file/eefeb76d26338e09958aae5d81479178)|XML|PlugX|2020-03-20 09:41:47|9d52d8f10673518cb9f19153ddbe362acc7ca885974a217a52d1ee8257f22cfc.bin|
|[37f78b1ad43959a788162f560bdc9c79](https://www.virustotal.com/gui/file/37f78b1ad43959a788162f560bdc9c79)|CAB||2020-03-20 06:42:14|oGhPGUDC03tURV.tmp|
|[21a51a834372ab11fba72fb865d6830e](https://www.virustotal.com/gui/file/21a51a834372ab11fba72fb865d6830e)|LNK||2020-03-15 10:34:04|C:\Users\Administrator\AppData\Local\Temp\covid.pdf.lnk|
|[fd648c3b7495abbe86b850587e2e5431](https://www.virustotal.com/gui/file/fd648c3b7495abbe86b850587e2e5431)|Win32 EXE||2020-03-11 14:38:18|./KISA_dataset_2020_train/002c9e0578a8b76f626e59b755a8aac18b5d048f1cc76e2c12f68bc3dd18b124.vir|
|[83d04f21515c7e6316f9cd0bb393a118](https://www.virustotal.com/gui/file/83d04f21515c7e6316f9cd0bb393a118)|Win32 DLL||2020-03-11 14:36:25|OINFO12.OCX|
|[fde349e9cf1074c7c21e8b9085a441ea](https://www.virustotal.com/gui/file/fde349e9cf1074c7c21e8b9085a441ea)|PDF||2020-01-20 13:12:36|APT-27_Detector.pdf|
|[c43133da77ce560e66585f78642e089c](https://www.virustotal.com/gui/file/c43133da77ce560e66585f78642e089c)|TXT||2020-01-20 13:10:39|detector3.bat|
|[b9000b8f7701eb3925643f1a2bbcb1a0](https://www.virustotal.com/gui/file/b9000b8f7701eb3925643f1a2bbcb1a0)|Win32 EXE||2020-01-19 16:37:04|summarize-x86.exe|
|[7ab7a1e2493c0ce72faef10a677b4ca1](https://www.virustotal.com/gui/file/7ab7a1e2493c0ce72faef10a677b4ca1)|Win32 EXE||2020-01-19 16:37:00|AFTA-APT27-Dectector.exe|
|[ff5e90a3cc70e224c1e7eab8e4709f06](https://www.virustotal.com/gui/file/ff5e90a3cc70e224c1e7eab8e4709f06)|PDF||2020-01-01 14:54:39|APT27_ِDoc.pdf|
|[77df3fb2382ae5f77c69cd199560725b](https://www.virustotal.com/gui/file/77df3fb2382ae5f77c69cd199560725b)|Win32 EXE|Ursu|2020-01-01 04:22:53|AFTA-APT27-Dectector.exe|
|[28f9ef5798ea561936fae36ffa680753](https://www.virustotal.com/gui/file/28f9ef5798ea561936fae36ffa680753)|Win32 EXE||2020-01-01 03:56:19|AFTA-APT27-Removal.exe|
