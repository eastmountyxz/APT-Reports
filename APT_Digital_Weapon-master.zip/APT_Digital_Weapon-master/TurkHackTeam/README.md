**NAME:**  
TurkHackTeam  
  
**Alias**  
Turk Hack Team, TurkHackTeam  

**Description**:   
Founded in 2004, Turkhackteam is one of Turkey’s oldest and most high-profile hacking collectives that has carried out almost 30 highly publicized hacking campaigns targeting foreign government and commercial websites, including websites of international corporations.
  
**References**:  
https://www.turkhackteam.org/  
https://twitter.com/Turk_Hack__Team
