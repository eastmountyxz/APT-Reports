|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[9d23cad207b2b5f9120f405bb70c295d](https://www.virustotal.com/gui/file/9d23cad207b2b5f9120f405bb70c295d)|Win32 EXE|graftor|2018-03-18 06:58:17|9dfc7e78892a9f18d2d15adbfa52cda379ddd963.exe|
|[20c8ebfd075669d5eeb6d9fbe2590860](https://www.virustotal.com/gui/file/20c8ebfd075669d5eeb6d9fbe2590860)|Win32 EXE||2018-03-18 06:57:05| |
|[c0618556e9ef16b35b042bc29aeb9291](https://www.virustotal.com/gui/file/c0618556e9ef16b35b042bc29aeb9291)|Win32 EXE||2018-02-10 14:32:50|Statement of the Saharawi government.exe|
|[d6ca39fef03cf67f8ddc2a560874d80d](https://www.virustotal.com/gui/file/d6ca39fef03cf67f8ddc2a560874d80d)|Win32 EXE||2017-10-16 18:31:03|E:/virussign/malware/new_request/20171024/d6ca39fef03cf67f8ddc2a560874d80d.vir|
|[e56c0bb65c68e89921b4a8348976a0e9](https://www.virustotal.com/gui/file/e56c0bb65c68e89921b4a8348976a0e9)|Win32 EXE||2016-08-05 07:45:02|c:\!!Prace\!!To_do\e56c0bb65c68e89921b4a8348976a0e9|
|[6f5c89473c9e6baf741629549ec52fe1](https://www.virustotal.com/gui/file/6f5c89473c9e6baf741629549ec52fe1)|Win32 EXE||2016-01-30 00:56:34| |
|[80eab4d4b117ef420fe9cdd63d6a9b99](https://www.virustotal.com/gui/file/80eab4d4b117ef420fe9cdd63d6a9b99)|Win32 EXE||2015-11-24 14:54:54|D:\work\download\______samplesreview\samplesnew\Samples\e85c2eab4c9eea8d0c99e58199f313ca4e1d1735|
|[7f1f9fa306c2e71ecb96daefafadc6e3](https://www.virustotal.com/gui/file/7f1f9fa306c2e71ecb96daefafadc6e3)|Win32 EXE||2015-09-09 01:24:46| |
|[f3001d31503a2c610a6c490c24e87aba](https://www.virustotal.com/gui/file/f3001d31503a2c610a6c490c24e87aba)|Win32 EXE||2015-09-09 01:24:22| |
|[8f56458f3fb710c4c1d103e7e9951703](https://www.virustotal.com/gui/file/8f56458f3fb710c4c1d103e7e9951703)|Win32 EXE||2015-09-09 01:24:17| |
|[2612c832ffebbdb7dab7e5b8d1905390](https://www.virustotal.com/gui/file/2612c832ffebbdb7dab7e5b8d1905390)|Win32 EXE||2015-09-09 01:24:06|C:\gwhCUd\1DzCsDm6\i1YypTo.fon|
