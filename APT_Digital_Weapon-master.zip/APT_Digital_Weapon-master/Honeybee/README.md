**NAME:**  
Honeybee  
  
**Description**:   
Honeybee is an attack operation discovered by McAfee. It targets humanitarian aid organizations and using North Korean political topics as bait to lure victims into opening malicious Microsoft Word documents.
The actor behind Honeybee is likely a Korean speaker and has been operating with new implants since at least November 2017 with the first known version of NTWDBLIB installer.
This operation has expanded beyond the borders of South Korea to target Vietnam, Singapore, Argentina, Japan, Indonesia, and Canada.
  
**References**:  
https://securingtomorrow.mcafee.com/mcafee-labs/mcafee-uncovers-operation-honeybee-malicious-document-campaign-targeting-humanitarian-aid-groups/
