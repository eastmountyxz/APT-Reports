|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[cec4001f640f8993895a7cda682479a4](https://www.virustotal.com/gui/file/cec4001f640f8993895a7cda682479a4)|Win32 DLL|Konni|2018-08-30 11:40:28|codexgigas_be99b95e8051471f3eb7439ded9cc82801997eb7|
|[81aa0527c789098f90c38967b276e331](https://www.virustotal.com/gui/file/81aa0527c789098f90c38967b276e331)|Win32 DLL||2018-02-09 04:29:50|81aa0527c789098f90c38967b276e331.virus|
|[5ccfdca9b2a3628841accdedb33217fc](https://www.virustotal.com/gui/file/5ccfdca9b2a3628841accdedb33217fc)|DOC|o97m|2018-02-02 07:40:31|5ccfdca9b2a3628841accdedb33217fc.virus|
|[97e2323d884a96b1207005b6b8c041d4](https://www.virustotal.com/gui/file/97e2323d884a96b1207005b6b8c041d4)|DOC|o97m|2018-02-02 07:36:47|97e2323d884a96b1207005b6b8c041d4.virus|
|[4a67dfd94df2581aeeefacdd8f97e7de](https://www.virustotal.com/gui/file/4a67dfd94df2581aeeefacdd8f97e7de)|DOC|o97m|2018-02-02 07:07:39|4a67dfd94df2581aeeefacdd8f97e7de.virus|
|[9b5f6d131519880c72b13b3dde5508b2](https://www.virustotal.com/gui/file/9b5f6d131519880c72b13b3dde5508b2)|DOC|Banload|2018-02-02 06:59:16|9b5f6d131519880c72b13b3dde5508b2.virus|
|[587da1534b7ecf6fc8abc01f8c80c78b](https://www.virustotal.com/gui/file/587da1534b7ecf6fc8abc01f8c80c78b)|Win32 DLL||2018-02-02 05:27:46|587da1534b7ecf6fc8abc01f8c80c78b.virus|
|[828930dcd7c0bd10efceff42b79096c9](https://www.virustotal.com/gui/file/828930dcd7c0bd10efceff42b79096c9)|Win32 DLL||2018-01-31 03:37:10|myfile.exe|
|[c47b884de127ddc62e44689af4927bcf](https://www.virustotal.com/gui/file/c47b884de127ddc62e44689af4927bcf)|Win32 EXE||2018-01-19 00:45:37|c47b884de127ddc62e44689af4927bcf.virus|
|[665249eb8e0375c8553c2887504e9312](https://www.virustotal.com/gui/file/665249eb8e0375c8553c2887504e9312)|DOC||2018-01-17 11:32:31|665249eb8e0375c8553c2887504e9312.virus|
|[9b93066b085a7929aabbab8ccfd331be](https://www.virustotal.com/gui/file/9b93066b085a7929aabbab8ccfd331be)|DOC|o97m|2018-01-17 03:21:16|/data/cfs/malshare/9b93066b085a7929aabbab8ccfd331be|
|[3eb415f905e896ef1d43d8aac74d0039](https://www.virustotal.com/gui/file/3eb415f905e896ef1d43d8aac74d0039)|Win32 DLL||2018-01-15 01:55:15|3eb415f905e896ef1d43d8aac74d0039.virus|
|[e00e2d202f5a4a84d895254d6c0d447f](https://www.virustotal.com/gui/file/e00e2d202f5a4a84d895254d6c0d447f)|Win32 DLL||2018-01-15 01:12:43|e00e2d202f5a4a84d895254d6c0d447f.virus|
|[fac0a84c3d04cba36dd21ab68d759225](https://www.virustotal.com/gui/file/fac0a84c3d04cba36dd21ab68d759225)|Win32 DLL||2018-01-15 01:06:52|fac0a84c3d04cba36dd21ab68d759225.virus|
|[4017ce64f321fd1b75c9bb7815bde12a](https://www.virustotal.com/gui/file/4017ce64f321fd1b75c9bb7815bde12a)|Win32 DLL||2018-01-15 01:04:24|4017ce64f321fd1b75c9bb7815bde12a.virus|
|[9a925e048612e1c24b44974fc9b4bb6a](https://www.virustotal.com/gui/file/9a925e048612e1c24b44974fc9b4bb6a)|Win32 DLL||2018-01-15 00:59:45|9a925e048612e1c24b44974fc9b4bb6a.virus|
|[bb2fbd8d143e1fb0717d21d4443729fc](https://www.virustotal.com/gui/file/bb2fbd8d143e1fb0717d21d4443729fc)|Win32 DLL||2018-01-15 00:57:01|bb2fbd8d143e1fb0717d21d4443729fc.virus|
|[acd00e87feacbd91c1466af3102a14fd](https://www.virustotal.com/gui/file/acd00e87feacbd91c1466af3102a14fd)|Win32 DLL||2018-01-15 00:54:14|acd00e87feacbd91c1466af3102a14fd.virus|
|[36614876eea3d174e1b1a9f0c5e58034](https://www.virustotal.com/gui/file/36614876eea3d174e1b1a9f0c5e58034)|Win32 DLL||2018-01-15 00:52:03|myfile.exe|
|[41e9397a9e0f9770ac3342bc353528d5](https://www.virustotal.com/gui/file/41e9397a9e0f9770ac3342bc353528d5)|Win32 DLL||2018-01-15 00:45:51|41e9397a9e0f9770ac3342bc353528d5.virus|
|[9abd1767b449110a37f60c2dd41624d3](https://www.virustotal.com/gui/file/9abd1767b449110a37f60c2dd41624d3)|Win32 DLL||2018-01-15 00:42:11|9abd1767b449110a37f60c2dd41624d3.virus|
|[eac38d878c466ec7f7df1cd8153dfb2f](https://www.virustotal.com/gui/file/eac38d878c466ec7f7df1cd8153dfb2f)|Win32 DLL||2017-12-03 07:34:29|eac38d878c466ec7f7df1cd8153dfb2f.virus|
|[155842c2c1824e0e4f17f63646d23aac](https://www.virustotal.com/gui/file/155842c2c1824e0e4f17f63646d23aac)|Win32 DLL|tiggre|2017-12-03 07:30:09|155842c2c1824e0e4f17f63646d23aac.virus|
|[8d4210935ba3f15bd0e1ef5dbc9037a9](https://www.virustotal.com/gui/file/8d4210935ba3f15bd0e1ef5dbc9037a9)|Win32 DLL||2017-12-03 07:26:06|8d4210935ba3f15bd0e1ef5dbc9037a9.virus|
|[e69500f133b4f02d7ead478af8e7e29d](https://www.virustotal.com/gui/file/e69500f133b4f02d7ead478af8e7e29d)|Win32 DLL|zapchast|2017-11-21 01:58:16|e69500f133b4f02d7ead478af8e7e29d.virus|
|[1acd45c751fa80ae8fc860b9f4127f5e](https://www.virustotal.com/gui/file/1acd45c751fa80ae8fc860b9f4127f5e)|Win32 DLL||2017-11-13 01:32:01|1acd45c751fa80ae8fc860b9f4127f5e.virus|
