|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[4e61e0d8bb0f674c536afde9296dd736](https://www.virustotal.com/gui/file/4e61e0d8bb0f674c536afde9296dd736)|ELF executable||2019-11-11 10:17:42|Fysbis|
|[f3ec38b8d5a6e29db299e2eadacbcebe](https://www.virustotal.com/gui/file/f3ec38b8d5a6e29db299e2eadacbcebe)|Win32 DLL||2019-10-29 12:15:23|help.php|
|[b54e2b724b148fa03ae9f981506587d5](https://www.virustotal.com/gui/file/b54e2b724b148fa03ae9f981506587d5)|Win32 EXE||2019-10-08 03:47:46| |
|[6b7026e3a5ce0e2cc4bb8be955aecded](https://www.virustotal.com/gui/file/6b7026e3a5ce0e2cc4bb8be955aecded)|Win32 EXE||2019-10-07 03:10:10| |
|[ccac33be2e9b95d5f1a44a6a7f64ed08](https://www.virustotal.com/gui/file/ccac33be2e9b95d5f1a44a6a7f64ed08)|Win32 DLL||2019-10-04 14:53:40| |
|[c01e87de07bc56589965aff67860f593](https://www.virustotal.com/gui/file/c01e87de07bc56589965aff67860f593)|Win64 EXE||2019-09-11 08:56:28| |
|[c8609af87250899e90ea6ae8fa50ba34](https://www.virustotal.com/gui/file/c8609af87250899e90ea6ae8fa50ba34)|Win64 EXE|sednit|2019-09-09 08:21:38|certserv.exe|
|[f4254b34ece1cc7bb6b7483583d5ad37](https://www.virustotal.com/gui/file/f4254b34ece1cc7bb6b7483583d5ad37)|Win64 EXE||2019-09-09 07:16:11|xmrig.exe|
|[a8ff5ab6beab00df28e60e68a1e8f5db](https://www.virustotal.com/gui/file/a8ff5ab6beab00df28e60e68a1e8f5db)|Win64 EXE||2019-09-09 07:13:41|xmrig.exe|
|[20ef449a4e967dce148ca8b07a90b0e4](https://www.virustotal.com/gui/file/20ef449a4e967dce148ca8b07a90b0e4)|Win64 EXE|sednit|2019-09-09 06:29:07|certserv.exe|
|[7b97bd02415d4ac7ac347b533bd85f57](https://www.virustotal.com/gui/file/7b97bd02415d4ac7ac347b533bd85f57)|Win64 EXE||2019-09-08 04:50:30|certserv.exe|
|[7308f0b7a113cb2d0d7924acdbb4aef0](https://www.virustotal.com/gui/file/7308f0b7a113cb2d0d7924acdbb4aef0)|Win64 EXE||2019-09-08 04:47:20|certserv.exe|
|[2efd35fd26ac7260429a3983fadba30c](https://www.virustotal.com/gui/file/2efd35fd26ac7260429a3983fadba30c)|Win64 EXE||2019-09-07 06:40:09|certserv.exe|
|[4c9d9d17702e4ef4898b85e2d41ce8ab](https://www.virustotal.com/gui/file/4c9d9d17702e4ef4898b85e2d41ce8ab)|DOTM||2019-08-22 16:49:54|wordData.dotm|
|[c28d031b3131d62f2a03b037a4ce5199](https://www.virustotal.com/gui/file/c28d031b3131d62f2a03b037a4ce5199)|Email||2019-08-22 01:03:11|0c2bbb5d4d434277dc1adbd5ef0e7a406171ad37f1dd7b188e745cc5a255d082|
|[1d09f491777cc9b80d5e07880314c7b3](https://www.virustotal.com/gui/file/1d09f491777cc9b80d5e07880314c7b3)|Win32 EXE||2019-08-20 15:10:53|lmss.exe|
|[e26fe7f009adb74033be0a18b2847fcc](https://www.virustotal.com/gui/file/e26fe7f009adb74033be0a18b2847fcc)|DOCM||2019-08-20 15:10:50|dttcodexgigas.b8ac400e1deb6e90fa4e2adb150c511c98bafc6e|
|[d7f174cd44686c3afc4a9a5ac646f0db](https://www.virustotal.com/gui/file/d7f174cd44686c3afc4a9a5ac646f0db)|DOCX||2019-08-20 09:17:12|612243236.docx|
|[ff03e53ccdf82e9310f15ec4796819e3](https://www.virustotal.com/gui/file/ff03e53ccdf82e9310f15ec4796819e3)|Win32 EXE||2019-07-31 13:28:53| |
|[e1509c589fde2272c0d20072dfe09722](https://www.virustotal.com/gui/file/e1509c589fde2272c0d20072dfe09722)|Win32 DLL||2019-07-04 11:42:50|info.php|
|[27e9247d28598207794424eeb5ea4b1b](https://www.virustotal.com/gui/file/27e9247d28598207794424eeb5ea4b1b)|Win32 EXE|Stealer|2019-06-06 09:19:43|dttcodexgigas.daf5bccc18e31ce72879b6c88b4a0751514051ce|
|[57c2b46c7f2ad9aba80e4b6248f9367a](https://www.virustotal.com/gui/file/57c2b46c7f2ad9aba80e4b6248f9367a)|DOC||2019-06-06 09:19:31|dttcodexgigas.f14104ae2264d1eadfe9a1315190b4602830a814|
|[a863c2944581bc734619bf8d6ab1aef8](https://www.virustotal.com/gui/file/a863c2944581bc734619bf8d6ab1aef8)|DOC|Stealer|2019-06-06 07:06:26|gorodpavlodar.doc|
|[905ec122329c7b31dec70a180b7d99d5](https://www.virustotal.com/gui/file/905ec122329c7b31dec70a180b7d99d5)|Win32 EXE||2019-05-22 21:36:00|myfile.exe|
|[c6b26a3aa715d059286a719ac5c364c3](https://www.virustotal.com/gui/file/c6b26a3aa715d059286a719ac5c364c3)|Win32 DLL||2019-05-22 10:53:42|myfile.exe|
|[2093eff4ad465b615327e2f629ee4d38](https://www.virustotal.com/gui/file/2093eff4ad465b615327e2f629ee4d38)|Win32 DLL||2019-05-22 10:48:18|340130ef9b7faf101e0d901d8eb9181a8165ba1b0a346376a59067286b7d2dll|
|[9158b1d2bdf03b3d316f7e6fa3afb5a6](https://www.virustotal.com/gui/file/9158b1d2bdf03b3d316f7e6fa3afb5a6)|Win32 EXE||2019-05-22 10:38:41|340130ef9b7faf101e0d901d8eb9181a8165ba1b0a346376a59067286b7d26af.sample|
|[d51d485f98810ab1278df4e41b692761](https://www.virustotal.com/gui/file/d51d485f98810ab1278df4e41b692761)|Win64 DLL||2019-05-17 19:13:41|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/USCYBERCOM/npmproxy.dll|
|[46d2045598c6482ce7b58497018230a9](https://www.virustotal.com/gui/file/46d2045598c6482ce7b58497018230a9)|Win32 EXE||2019-05-16 16:22:47|50-112-234(1).exe|
|[5cd27284f1bb445fd0ae7b2518e63a5e](https://www.virustotal.com/gui/file/5cd27284f1bb445fd0ae7b2518e63a5e)|Win32 EXE||2019-05-15 11:28:31|RPCNETP.EXE|
|[e6662d25dfbcfae46fcd9d4f7b62762b](https://www.virustotal.com/gui/file/e6662d25dfbcfae46fcd9d4f7b62762b)|Win32 EXE||2019-05-13 19:56:26|wg.exe|
|[10d8b000a8c0d31e2055db44ce304c57](https://www.virustotal.com/gui/file/10d8b000a8c0d31e2055db44ce304c57)|Win32 EXE||2019-05-10 17:26:27|mimikatz|
|[ec8aab1f50130c628467de63b3938ea1](https://www.virustotal.com/gui/file/ec8aab1f50130c628467de63b3938ea1)|Win32 EXE||2019-04-29 18:35:52|wg.exe|
|[4223634eda491b13da7e857f61002369](https://www.virustotal.com/gui/file/4223634eda491b13da7e857f61002369)|Win32 DLL|Pigeon|2019-04-25 12:41:02|Crystal.dll|
|[4b22a6f74e6c12bc4810fbee1879273d](https://www.virustotal.com/gui/file/4b22a6f74e6c12bc4810fbee1879273d)|unknown|lojax|2019-04-16 13:05:08|rpcnetp.bin|
|[1ee5a8a123ab7b5a03f130d5336d0bc8](https://www.virustotal.com/gui/file/1ee5a8a123ab7b5a03f130d5336d0bc8)|FPX|sednit|2019-04-11 10:44:37| |
|[fd0691b47e636741e94be095657c7831](https://www.virustotal.com/gui/file/fd0691b47e636741e94be095657c7831)|DOCM|Banload|2019-04-11 07:13:49|b40cbf38284e6a1b9157002ad564e40fad2d85ba36437cf95c3b6326ad142520.doc|
|[545ec86c5c70f63e1921c5e58c9b7050](https://www.virustotal.com/gui/file/545ec86c5c70f63e1921c5e58c9b7050)|Win32 EXE||2019-04-10 07:41:11|Note 15-745 Kartapur corridor on April16!.exe|
|[84adc82e6c7dba8c0b9b46cc8c00f3f1](https://www.virustotal.com/gui/file/84adc82e6c7dba8c0b9b46cc8c00f3f1)|LNK||2019-03-31 15:56:14|e259df89e065c4162b273ebb18b75ea153f9bafe30a8c6610204ccf5e3f4ebcd.bin|
|[b236b36e8df40013bcf08dd3701264be](https://www.virustotal.com/gui/file/b236b36e8df40013bcf08dd3701264be)|Win32 EXE||2019-03-18 19:07:29|executable.3996.exe|
|[dd59a77c0a0a6e5162bd15db1ab84c64](https://www.virustotal.com/gui/file/dd59a77c0a0a6e5162bd15db1ab84c64)|Mach-O executable|sednit|2019-03-16 23:34:38|OSX_Sofacy_Komplex|
|[3e9515d503b6766398ec9e727a665c88](https://www.virustotal.com/gui/file/3e9515d503b6766398ec9e727a665c88)|Win32 DLL|Ursu|2019-03-07 15:41:10|mod.dll|
|[63b9b451c6daac14a838b318bbba458e](https://www.virustotal.com/gui/file/63b9b451c6daac14a838b318bbba458e)|Win32 DLL|sednit|2019-02-14 13:02:24|ntuser.dll|
|[70213367847c201f65fed99dbe7545d2](https://www.virustotal.com/gui/file/70213367847c201f65fed99dbe7545d2)|Win32 EXE|razy|2019-02-13 18:28:56|adobe.dll|
|[53ae587757eb9b4afa4c4ca9f238ade6](https://www.virustotal.com/gui/file/53ae587757eb9b4afa4c4ca9f238ade6)|Win32 EXE||2019-02-04 05:50:29|Health Key Managment|
|[896ed83884181517a002d2cf73548448](https://www.virustotal.com/gui/file/896ed83884181517a002d2cf73548448)|Win32 EXE||2019-02-02 19:33:34| |
|[67725d5f868b8c00a08327164dbb5df8](https://www.virustotal.com/gui/file/67725d5f868b8c00a08327164dbb5df8)|ARJ|autoit|2019-01-25 13:22:34|093.arj|
|[b68434af08360e6cf7a51d623195caa1](https://www.virustotal.com/gui/file/b68434af08360e6cf7a51d623195caa1)|Win32 EXE||2019-01-24 11:01:50|dttcodexgigas.78c7d4ee6d4f8d41a0af3b82e776878382419728|
|[9ae5e57d8c40f72a508475f19c0a42f6](https://www.virustotal.com/gui/file/9ae5e57d8c40f72a508475f19c0a42f6)|Win32 EXE|strictor|2019-01-24 10:25:58|scan_21.06.18(1).rar|
|[063fc3e58a0effd7cac127ec9a7046b4](https://www.virustotal.com/gui/file/063fc3e58a0effd7cac127ec9a7046b4)|Text||2019-01-24 09:46:20|zebrocy_.au3|
|[692043add4c77ed1bfdd6ffd0e7245f4](https://www.virustotal.com/gui/file/692043add4c77ed1bfdd6ffd0e7245f4)|Win32 EXE|autoit|2019-01-24 04:45:35|myfile.exe|
|[f1aeaf72995b12d5edd3971ccbc38fac](https://www.virustotal.com/gui/file/f1aeaf72995b12d5edd3971ccbc38fac)|Win32 EXE||2019-01-24 02:13:56|/home/seclab/Documents/meseum_data/only_using_data_set/vir/using_vir_all_data/indexing/f1aeaf72995b12d5edd3971ccbc38fac.vir|
|[ec57bb4980ea0190f4ad05d0ea9c9447](https://www.virustotal.com/gui/file/ec57bb4980ea0190f4ad05d0ea9c9447)|Win32 EXE||2019-01-23 06:41:17|myfile.exe|
|[97922f74310c628557658c1e44278713](https://www.virustotal.com/gui/file/97922f74310c628557658c1e44278713)|Win32 EXE||2019-01-14 16:44:22|C:\Users\jirik\Downloads\7ea33696c91761e95697549e0b0f84db2cf4033216cd16c3264b10daa31f598c.out\00000002.dat|
|[3e713a838a68259ae2f9ef2eed05a761](https://www.virustotal.com/gui/file/3e713a838a68259ae2f9ef2eed05a761)|Win32 EXE||2019-01-07 18:28:10| |
|[d9b5703b5b9fed49ed1a4ca92a232796](https://www.virustotal.com/gui/file/d9b5703b5b9fed49ed1a4ca92a232796)|Win32 EXE|MSILPerseus|2018-12-28 17:18:31|cannon.exe|
|[333d2b9e99b36fb42f9e79a2833fad9c](https://www.virustotal.com/gui/file/333d2b9e99b36fb42f9e79a2833fad9c)|Win32 EXE||2018-12-20 18:03:51|myfile.exe|
|[ebdc6098c733b23e99daa60e55cf858b](https://www.virustotal.com/gui/file/ebdc6098c733b23e99daa60e55cf858b)|Win32 DLL||2018-12-20 16:19:17|adobe.dll|
|[f8a778d21003098075c9aef8ed58c6c3](https://www.virustotal.com/gui/file/f8a778d21003098075c9aef8ed58c6c3)|DOC|o97m|2018-12-20 10:50:16|UDS 2019 Current Agenda.doc|
|[8da56a4b1a5ff8e4643421a5fefb5dc4](https://www.virustotal.com/gui/file/8da56a4b1a5ff8e4643421a5fefb5dc4)|Win32 EXE|razy|2018-12-18 15:43:50|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/Cannon.bin|
|[ea553c3de3fffbfa047e8e0eb2557b8b](https://www.virustotal.com/gui/file/ea553c3de3fffbfa047e8e0eb2557b8b)|Win32 EXE|sednit|2018-12-18 12:16:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/SCANPASS_QXWEGRFGCVT_323803488900X_jpeg.bin|
|[3eaf97b9c6b44f0447f2bd1c7acb8c96](https://www.virustotal.com/gui/file/3eaf97b9c6b44f0447f2bd1c7acb8c96)|Win32 EXE||2018-12-10 10:28:34| |
|[9d703d31795bac83c4dd90527d149796](https://www.virustotal.com/gui/file/9d703d31795bac83c4dd90527d149796)|DOCM||2018-12-05 14:10:38|~de03fc12a.docm|
|[4b4a964d938d300e8456fbc9b82e20df](https://www.virustotal.com/gui/file/4b4a964d938d300e8456fbc9b82e20df)|DOTM|o97m|2018-12-04 13:12:44|NormalOld.dotm|
|[3773150aeee03783a6da0820a8feb752](https://www.virustotal.com/gui/file/3773150aeee03783a6da0820a8feb752)|Win32 EXE||2018-12-04 11:59:08|myfile.exe|
|[e49728cee1fdbbb957f657361fba3c9f](https://www.virustotal.com/gui/file/e49728cee1fdbbb957f657361fba3c9f)|Win32 EXE||2018-12-04 11:58:59|dttcodexgigas.2edf78f39c84f6f5adeb3fb4ab941402c5535efd|
|[602d2901d55c2720f955503456ac2f68](https://www.virustotal.com/gui/file/602d2901d55c2720f955503456ac2f68)|Win32 EXE||2018-12-04 11:58:51|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/ZebrocyOct2018/ZebrocyGoVariantImplant.bin|
|[2318c0713df3404ccb7be4d1923621a3](https://www.virustotal.com/gui/file/2318c0713df3404ccb7be4d1923621a3)|DOCX|o97m|2018-12-04 08:08:42|Clearance 02-12-18.docx|
|[549726b8bfb1919a343ac764d48fdc81](https://www.virustotal.com/gui/file/549726b8bfb1919a343ac764d48fdc81)|Win32 DLL|sednit|2018-12-01 16:15:08|UpdaterUI.dll|
|[d6a60c6455f3937735ce2df82ad83627](https://www.virustotal.com/gui/file/d6a60c6455f3937735ce2df82ad83627)|Win32 EXE||2018-12-01 00:34:19|dttcodexgigas.4e9f8b2ccacfaac0553b6a2dbfe74a45f85aabc5|
|[43d7ffd611932cf51d7150b176ecfc29](https://www.virustotal.com/gui/file/43d7ffd611932cf51d7150b176ecfc29)|DOCM|o97m|2018-11-30 21:29:49|download.doc|
|[02c46f30f4c68a442cf7e13bebe8d3f8](https://www.virustotal.com/gui/file/02c46f30f4c68a442cf7e13bebe8d3f8)|Win32 EXE||2018-11-30 17:43:55| |
|[1fe6af243760ca287f80eafbb98ba1b0](https://www.virustotal.com/gui/file/1fe6af243760ca287f80eafbb98ba1b0)|Win32 EXE||2018-11-29 21:09:41|1fe6af243760ca287f80eafbb98ba1b0.virobj|
|[a4d63973c0e60936f72aed3d391fd461](https://www.virustotal.com/gui/file/a4d63973c0e60936f72aed3d391fd461)|Win32 EXE||2018-11-29 17:15:03|myfile.exe|
|[6895869337ba4ce9b81bcf7b75244384](https://www.virustotal.com/gui/file/6895869337ba4ce9b81bcf7b75244384)|Win32 EXE||2018-11-28 20:30:26|NonMalicious.exe|
|[536a982e8a6dcada26e90a69dd3f73c3](https://www.virustotal.com/gui/file/536a982e8a6dcada26e90a69dd3f73c3)|Win32 EXE||2018-11-28 19:33:05|mimikatz_via_domain.exe|
|[eeadf94df83f5f1d2b68bf00515a5b29](https://www.virustotal.com/gui/file/eeadf94df83f5f1d2b68bf00515a5b29)|Win32 EXE||2018-11-28 17:09:27|mimikatz|
|[e57a401e8f0943b703d975692fcfc0e8](https://www.virustotal.com/gui/file/e57a401e8f0943b703d975692fcfc0e8)|Win32 EXE||2018-11-28 14:40:51|Client Manager for Windows Task.exe|
|[9a7d82ba55216defc2d4131b6c453f02](https://www.virustotal.com/gui/file/9a7d82ba55216defc2d4131b6c453f02)|Win32 EXE||2018-11-24 09:40:08| |
|[5415b299f969c62174a624d236a56f42](https://www.virustotal.com/gui/file/5415b299f969c62174a624d236a56f42)|Win32 EXE||2018-11-21 11:11:10|sslwin|
|[f4cab3a393462a57639faa978a75d10a](https://www.virustotal.com/gui/file/f4cab3a393462a57639faa978a75d10a)|Win32 EXE|sednit|2018-11-16 09:39:09|dttcodexgigas.8286dfafaf9e1bc1d1fa0da18844a90901715d64|
|[405655be03df45881aa88b55603bef1d](https://www.virustotal.com/gui/file/405655be03df45881aa88b55603bef1d)|DOCX|Banload|2018-11-16 07:05:09|Brexit 15.11.2018.docx|
|[7e67122d3a052e4755b02965e2e56a2e](https://www.virustotal.com/gui/file/7e67122d3a052e4755b02965e2e56a2e)|Win32 EXE|sednit|2018-11-15 17:29:36|.|
|[83d31a7939dfdde940ce5675ee4a0e04](https://www.virustotal.com/gui/file/83d31a7939dfdde940ce5675ee4a0e04)|DOCX||2018-11-15 14:51:23|34bdb5b364358a07f598da4d26b30bac37e139a7dc2b9914debb3a16311f3ded.docx.bin|
|[fb5b1c2fccf21aa076449ecdf6f888d1](https://www.virustotal.com/gui/file/fb5b1c2fccf21aa076449ecdf6f888d1)|DOCX||2018-11-15 12:31:55|201811131257.docx|
|[a13c864980159cd9bdc94074b2389dda](https://www.virustotal.com/gui/file/a13c864980159cd9bdc94074b2389dda)|Win32 EXE||2018-11-14 16:37:42|WinApp.exe|
|[ed80d716ddea1dca2ef4c464a8cb5810](https://www.virustotal.com/gui/file/ed80d716ddea1dca2ef4c464a8cb5810)|Win32 EXE||2018-11-14 16:19:49|sslwin|
|[2a794b55b839b3237482098957877326](https://www.virustotal.com/gui/file/2a794b55b839b3237482098957877326)|DOTM||2018-11-14 09:49:09|01_samples_for_upload\007_.malware|
|[e8e1fcf757fe06be13bead43eaa1338c](https://www.virustotal.com/gui/file/e8e1fcf757fe06be13bead43eaa1338c)|Win64 EXE|sednit|2018-11-09 15:13:56|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/ctlnetw.bin|
|[f05a7cc3656c9467d38d54e037c24391](https://www.virustotal.com/gui/file/f05a7cc3656c9467d38d54e037c24391)|Win32 EXE|sednit|2018-11-06 14:17:17|dttcodexgigas.ccb7755fddb0d8fbe9c600c269f79dae91b6c5a1|
|[a6e6e783feaeb9400638283d1227f230](https://www.virustotal.com/gui/file/a6e6e783feaeb9400638283d1227f230)|DOCX|Banload|2018-11-06 10:03:49|a6e6e783feaeb9400638283d1227f230.virobj|
|[89503b7935a05b1d26cb26ce3793a3fb](https://www.virustotal.com/gui/file/89503b7935a05b1d26cb26ce3793a3fb)|Win32 EXE||2018-11-05 15:27:53|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/rpcnetp.exe.bin|
|[cffcae5c5551b4b9489fec5d56269d84](https://www.virustotal.com/gui/file/cffcae5c5551b4b9489fec5d56269d84)|Win32 DLL||2018-11-05 15:24:20|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/rpcnetpLojack.dll.bin|
|[c3dd5da756ac776cd29321c46eca011e](https://www.virustotal.com/gui/file/c3dd5da756ac776cd29321c46eca011e)|DOTM||2018-11-02 08:51:37|01_samples_for_upload\009_.malware|
|[05de2d6c3f9267c3a97b6c6c41f229be](https://www.virustotal.com/gui/file/05de2d6c3f9267c3a97b6c6c41f229be)|Win32 EXE||2018-11-01 14:43:36|wsslc.exe|
|[51aadb655b3783d4224f236e6c1ffa38](https://www.virustotal.com/gui/file/51aadb655b3783d4224f236e6c1ffa38)|DOCX||2018-11-01 11:41:25|=?UTF-8?B?0JfQsNGP0LLQu9C10L3QuNC1LmRvY3g=?=|
|[822693618a33b927e904725ea7939dfc](https://www.virustotal.com/gui/file/822693618a33b927e904725ea7939dfc)|Win32 DLL||2018-10-30 04:34:26|virus.bin|
|[80334346ea7b96204258517f0f38c3b7](https://www.virustotal.com/gui/file/80334346ea7b96204258517f0f38c3b7)|DOTM|o97m|2018-10-28 01:09:49|release.dotm|
|[fdbfceec5b3d2e855feb036c4e96e9aa](https://www.virustotal.com/gui/file/fdbfceec5b3d2e855feb036c4e96e9aa)|Win32 EXE|Delf|2018-10-27 01:29:07|wmisvc|
|[2b16b0f552ea6973fce06862c91ee8a9](https://www.virustotal.com/gui/file/2b16b0f552ea6973fce06862c91ee8a9)|Win32 EXE|sednit|2018-10-26 16:29:23|.|
|[843ed074adb454beb8a547c6b9e71fef](https://www.virustotal.com/gui/file/843ed074adb454beb8a547c6b9e71fef)|DOCX|Banload|2018-10-26 13:31:14|DN_325_170428_DEA Basic Narcotics Investigation Course invitation.docx|
|[268426b91d3f455ec7ef4558c4a4dfd1](https://www.virustotal.com/gui/file/268426b91d3f455ec7ef4558c4a4dfd1)|Win32 EXE|skeeyah|2018-10-26 03:56:43|office.exe|
|[f4ced8cbb792f6ef865fe8bd6b9fc79d](https://www.virustotal.com/gui/file/f4ced8cbb792f6ef865fe8bd6b9fc79d)|Win32 EXE|MSILPerseus|2018-10-18 21:54:15|cannon.exe|
|[efa1b414bf19ee295cc90f29332de4ed](https://www.virustotal.com/gui/file/efa1b414bf19ee295cc90f29332de4ed)|DOCX|Banload|2018-10-18 16:05:24|Note N359 MPD Telephone Chart.docx|
|[6fc45c0194e10b3cd5117200185e3d74](https://www.virustotal.com/gui/file/6fc45c0194e10b3cd5117200185e3d74)|DOTM||2018-10-18 11:26:26|Note_template.dotm|
|[ea5722ed66bd75871e24f7f88c5133aa](https://www.virustotal.com/gui/file/ea5722ed66bd75871e24f7f88c5133aa)|Win32 EXE||2018-10-18 11:24:34|c.exe|
|[ccd2e208c308b56acb5fb86dd029c034](https://www.virustotal.com/gui/file/ccd2e208c308b56acb5fb86dd029c034)|DOCX|Banload|2018-10-18 08:47:07|vWVTm0cadcNxHkAI48U5jhA2tMEupyI2R|
|[deb03c602b4e5b0835979cd47d8c5fcf](https://www.virustotal.com/gui/file/deb03c602b4e5b0835979cd47d8c5fcf)|Win32 EXE|sednit|2018-10-18 07:20:57|deb03c602b4e5b0835979cd47d8c5fcf.virus|
|[331454640fe386cd1a084709b4516ac4](https://www.virustotal.com/gui/file/331454640fe386cd1a084709b4516ac4)|Win32 EXE||2018-10-14 06:17:50|5223a45d8b08eb14e87a87edaa4b71593b4f9d2bdb6de1a5b6f3e77869eeca8a.sample|
|[a14c2e90a4512d32d0bc22b4e1d9ebf4](https://www.virustotal.com/gui/file/a14c2e90a4512d32d0bc22b4e1d9ebf4)|Win64 DLL||2018-10-09 11:15:34|Channeling.dll|
|[d647bcaf2d67133ca1aaf3d82135dc02](https://www.virustotal.com/gui/file/d647bcaf2d67133ca1aaf3d82135dc02)|ELF executable|VPNFilter|2018-09-26 23:00:56| |
|[8f35e2c769b981062709966b6c23a29a](https://www.virustotal.com/gui/file/8f35e2c769b981062709966b6c23a29a)|ELF executable|VPNFilter|2018-09-26 23:00:42| |
|[085f6fb4e7cf281215dd4e5f22fb46a7](https://www.virustotal.com/gui/file/085f6fb4e7cf281215dd4e5f22fb46a7)|ELF executable|VPNFilter|2018-09-26 23:00:35| |
|[6616b587fb8a90a007724d1f4ba63035](https://www.virustotal.com/gui/file/6616b587fb8a90a007724d1f4ba63035)|ELF executable|VPNFilter|2018-09-26 23:00:26| |
|[d33c82722b0830da75d32ebee7d00343](https://www.virustotal.com/gui/file/d33c82722b0830da75d32ebee7d00343)|ELF executable|VPNFilter|2018-09-26 23:00:18| |
|[62bc6c20bea3da7691fca8d2c6fe6a84](https://www.virustotal.com/gui/file/62bc6c20bea3da7691fca8d2c6fe6a84)|ELF executable|VPNFilter|2018-09-26 23:00:17| |
|[7fd5d510808219dcf5e9a8410b031187](https://www.virustotal.com/gui/file/7fd5d510808219dcf5e9a8410b031187)|ELF executable|VPNFilter|2018-09-26 23:00:10| |
|[9aefaa248e41373c4e499b22f2debdee](https://www.virustotal.com/gui/file/9aefaa248e41373c4e499b22f2debdee)|ELF executable|VPNFilter|2018-09-26 15:00:58| |
|[b576079d7fd70464b1cc3bc7d3b5811a](https://www.virustotal.com/gui/file/b576079d7fd70464b1cc3bc7d3b5811a)|ELF executable|VPNFilter|2018-09-26 15:00:57| |
|[ee3ec39c338d7422b3fffe8789870dd2](https://www.virustotal.com/gui/file/ee3ec39c338d7422b3fffe8789870dd2)|ELF executable|VPNFilter|2018-09-26 15:00:55| |
|[24363d084830f552930fbc3a9c7887a6](https://www.virustotal.com/gui/file/24363d084830f552930fbc3a9c7887a6)|ELF executable|VPNFilter|2018-09-26 15:00:54| |
|[40d820a6bd7cdaac703581e5dd80ecfe](https://www.virustotal.com/gui/file/40d820a6bd7cdaac703581e5dd80ecfe)|ELF executable|VPNFilter|2018-09-26 15:00:53| |
|[9114767e8a5fc46d5f494b401fcf743b](https://www.virustotal.com/gui/file/9114767e8a5fc46d5f494b401fcf743b)|ELF executable||2018-09-26 15:00:50| |
|[5b4f28331b6e144e0235a6290dffe2e0](https://www.virustotal.com/gui/file/5b4f28331b6e144e0235a6290dffe2e0)|ELF executable|VPNFilter|2018-09-26 15:00:49| |
|[0306959585cb9553329bec04164cb82d](https://www.virustotal.com/gui/file/0306959585cb9553329bec04164cb82d)|ELF executable|VPNFilter|2018-09-26 15:00:48| |
|[ed465acf4e2227c79137f5730dc3bb47](https://www.virustotal.com/gui/file/ed465acf4e2227c79137f5730dc3bb47)|ELF executable|VPNFilter|2018-09-26 15:00:48| |
|[ecb03c3497ef08ba07f44c5b30b2ae2d](https://www.virustotal.com/gui/file/ecb03c3497ef08ba07f44c5b30b2ae2d)|ELF executable|VPNFilter|2018-09-26 15:00:46| |
|[d24755065b92e2e0cc7a2262bb8b3c3f](https://www.virustotal.com/gui/file/d24755065b92e2e0cc7a2262bb8b3c3f)|ELF executable|VPNFilter|2018-09-26 15:00:45| |
|[3b073bf92551cbecde70c91f93de77aa](https://www.virustotal.com/gui/file/3b073bf92551cbecde70c91f93de77aa)|ELF executable|VPNFilter|2018-09-26 15:00:44| |
|[643809836183a088968f53282a661c4e](https://www.virustotal.com/gui/file/643809836183a088968f53282a661c4e)|ELF executable|VPNFilter|2018-09-26 15:00:43| |
|[a8ab016a4254b1173ab79890b76f9720](https://www.virustotal.com/gui/file/a8ab016a4254b1173ab79890b76f9720)|ELF executable|VPNFilter|2018-09-26 15:00:41| |
|[3d0bdc24d355fd0bfa4904240dc9539b](https://www.virustotal.com/gui/file/3d0bdc24d355fd0bfa4904240dc9539b)|ELF executable|VPNFilter|2018-09-26 15:00:39| |
|[c01beca43c8634e25720e332c0ef1de3](https://www.virustotal.com/gui/file/c01beca43c8634e25720e332c0ef1de3)|ELF executable|VPNFilter|2018-09-26 15:00:38| |
|[b8f8caac7a77273a5722a45f78d11528](https://www.virustotal.com/gui/file/b8f8caac7a77273a5722a45f78d11528)|ELF executable|VPNFilter|2018-09-26 15:00:37| |
|[a6f9d210221ab95b10178f74523c9993](https://www.virustotal.com/gui/file/a6f9d210221ab95b10178f74523c9993)|ELF executable|VPNFilter|2018-09-26 15:00:36| |
|[8ad5c5be9f9b84fab625369f32db4a89](https://www.virustotal.com/gui/file/8ad5c5be9f9b84fab625369f32db4a89)|ELF executable|VPNFilter|2018-09-26 15:00:34| |
|[8dfa0ff693e1f191dc943869e182f2ae](https://www.virustotal.com/gui/file/8dfa0ff693e1f191dc943869e182f2ae)|ELF executable|VPNFilter|2018-09-26 15:00:33| |
|[9f5b151949e1fc24ff086f64f0862702](https://www.virustotal.com/gui/file/9f5b151949e1fc24ff086f64f0862702)|ELF executable|VPNFilter|2018-09-26 15:00:32| |
|[fa15f3e8f775c1753976955ee1ddd24d](https://www.virustotal.com/gui/file/fa15f3e8f775c1753976955ee1ddd24d)|ELF executable|VPNFilter|2018-09-26 15:00:32| |
|[8f81535f9c2766c1b4df9a59c863050b](https://www.virustotal.com/gui/file/8f81535f9c2766c1b4df9a59c863050b)|ELF executable|VPNFilter|2018-09-26 15:00:31| |
|[b3598aeceb35dc79d098d751b0a6068e](https://www.virustotal.com/gui/file/b3598aeceb35dc79d098d751b0a6068e)|ELF executable|VPNFilter|2018-09-26 15:00:30| |
|[c2d2b1412dafd6ab7ef5b4eb8f27b243](https://www.virustotal.com/gui/file/c2d2b1412dafd6ab7ef5b4eb8f27b243)|ELF executable|VPNFilter|2018-09-26 15:00:29| |
|[c608d1ce52c0ac9a3ca737f20ab3fed9](https://www.virustotal.com/gui/file/c608d1ce52c0ac9a3ca737f20ab3fed9)|ELF executable|VPNFilter|2018-09-26 15:00:28| |
|[97cc584031f987218c62a8e78ef5fcf2](https://www.virustotal.com/gui/file/97cc584031f987218c62a8e78ef5fcf2)|ELF executable|VPNFilter|2018-09-26 15:00:27| |
|[d4e415cde967d9f30cabd47312f6a483](https://www.virustotal.com/gui/file/d4e415cde967d9f30cabd47312f6a483)|ELF executable|VPNFilter|2018-09-26 15:00:25| |
|[4e779ea1a40c804bdb7150e829519d49](https://www.virustotal.com/gui/file/4e779ea1a40c804bdb7150e829519d49)|ELF executable|VPNFilter|2018-09-26 15:00:24| |
|[9729e696529872125bbe6b34f8cebcb8](https://www.virustotal.com/gui/file/9729e696529872125bbe6b34f8cebcb8)|ELF executable|VPNFilter|2018-09-26 15:00:23| |
|[cfec0985e36603057d7fe974c52870e6](https://www.virustotal.com/gui/file/cfec0985e36603057d7fe974c52870e6)|ELF executable|VPNFilter|2018-09-26 15:00:22| |
|[da930b4b593004b8c58e3fda81fecba4](https://www.virustotal.com/gui/file/da930b4b593004b8c58e3fda81fecba4)|ELF executable|VPNFilter|2018-09-26 15:00:22| |
|[24a14cec1dc25599b19950a12cbbb10c](https://www.virustotal.com/gui/file/24a14cec1dc25599b19950a12cbbb10c)|ELF executable|VPNFilter|2018-09-26 15:00:21| |
|[f67635cdf0586e56b62ac59fb1fba60c](https://www.virustotal.com/gui/file/f67635cdf0586e56b62ac59fb1fba60c)|ELF executable|VPNFilter|2018-09-26 15:00:20| |
|[1d498ce446a7a68f9a8bc1278d1f46e0](https://www.virustotal.com/gui/file/1d498ce446a7a68f9a8bc1278d1f46e0)|ELF executable|VPNFilter|2018-09-26 15:00:19| |
|[6f04a48c7de0d0aeae893360180b80fd](https://www.virustotal.com/gui/file/6f04a48c7de0d0aeae893360180b80fd)|ELF executable|VPNFilter|2018-09-26 15:00:16| |
|[3d9fef47f003c263c23edfbccd010101](https://www.virustotal.com/gui/file/3d9fef47f003c263c23edfbccd010101)|ELF executable|VPNFilter|2018-09-26 15:00:15| |
|[9435103bc16f3ba138be84b9e4dead18](https://www.virustotal.com/gui/file/9435103bc16f3ba138be84b9e4dead18)|ELF executable|VPNFilter|2018-09-26 15:00:13| |
|[44500f1dbbd696e09736e940e602e787](https://www.virustotal.com/gui/file/44500f1dbbd696e09736e940e602e787)|ELF executable|VPNFilter|2018-09-26 15:00:12| |
|[7f36f5832527d1665a50cea62fadf277](https://www.virustotal.com/gui/file/7f36f5832527d1665a50cea62fadf277)|ELF executable|VPNFilter|2018-09-26 15:00:08| |
|[510899e3eb4e0f89f010af5bd24ba711](https://www.virustotal.com/gui/file/510899e3eb4e0f89f010af5bd24ba711)|ELF executable|VPNFilter|2018-09-26 15:00:07| |
|[3b88b074cf3dc4545296b3b86d95aaa5](https://www.virustotal.com/gui/file/3b88b074cf3dc4545296b3b86d95aaa5)|ELF executable|VPNFilter|2018-09-26 15:00:04| |
|[a67592fbed190881dfe46bcd12f8fbd9](https://www.virustotal.com/gui/file/a67592fbed190881dfe46bcd12f8fbd9)|ELF executable|VPNFilter|2018-09-26 15:00:03| |
|[0fb1975659a414d8412cc930fb3d4310](https://www.virustotal.com/gui/file/0fb1975659a414d8412cc930fb3d4310)|Win32 EXE||2018-09-20 00:24:33|0fb1975659a414d8412cc930fb3d4310.virobj|
|[e5db592704f30d42537b1257e79ff223](https://www.virustotal.com/gui/file/e5db592704f30d42537b1257e79ff223)|Win32 EXE||2018-09-19 21:55:12|00000003.dat|
|[84ce645913cc6400068ade70ac9e2728](https://www.virustotal.com/gui/file/84ce645913cc6400068ade70ac9e2728)|Win32 EXE||2018-09-19 20:11:40|84ce645913cc6400068ade70ac9e2728.virus|
|[f336379bd4a129f0851a24ccea47b4ec](https://www.virustotal.com/gui/file/f336379bd4a129f0851a24ccea47b4ec)|Win32 EXE||2018-09-19 20:04:53|f336379bd4a129f0851a24ccea47b4ec.virus|
|[e4d06d828513c70f9282ed39c3f8a553](https://www.virustotal.com/gui/file/e4d06d828513c70f9282ed39c3f8a553)|Win32 DLL||2018-09-19 19:45:17|archiannelidac5MxXdIWrGaX4ktBS1yiLSJzbN5e47Hv1g6XyVw52X3ZbLkBy.upx|
|[0d73f1a1c4b2f8723fffc83eb3d00f31](https://www.virustotal.com/gui/file/0d73f1a1c4b2f8723fffc83eb3d00f31)|Win64 DLL|TrickBot|2018-09-18 02:24:35|.|
|[c49acd386b243de233225d3ee9e9498a](https://www.virustotal.com/gui/file/c49acd386b243de233225d3ee9e9498a)|Win32 DLL||2018-09-18 02:09:25|.|
|[3adabf36f34ef2d6734e6fdcee842d30](https://www.virustotal.com/gui/file/3adabf36f34ef2d6734e6fdcee842d30)|Win32 EXE||2018-09-08 04:23:38| |
|[509e106284949416793a8d1aa0da742f](https://www.virustotal.com/gui/file/509e106284949416793a8d1aa0da742f)|Win32 EXE|sednit|2018-09-08 00:33:42| |
|[b8392185bc4986d7f456b54fe45463bd](https://www.virustotal.com/gui/file/b8392185bc4986d7f456b54fe45463bd)|Win32 EXE||2018-09-07 17:19:18|codexgigas_fdafa94fb8ab36dd4997845568ea63b637dfcfa0|
|[302277f8499305d24ada19e2f6d525a4](https://www.virustotal.com/gui/file/302277f8499305d24ada19e2f6d525a4)|Win32 DLL|dynamer|2018-09-06 14:35:41|NetIds.dll|
|[d6be74c21afeffe2ab7293f72a495904](https://www.virustotal.com/gui/file/d6be74c21afeffe2ab7293f72a495904)|Win32 EXE||2018-09-04 18:37:53|MSASCUI|
|[9a2e7cd06dbbd91e787a88e75a219757](https://www.virustotal.com/gui/file/9a2e7cd06dbbd91e787a88e75a219757)|Win32 DLL||2018-09-04 03:56:07|.|
|[504a054cd410fb378e11d9f703cfe23e](https://www.virustotal.com/gui/file/504a054cd410fb378e11d9f703cfe23e)|Win64 DLL|TrickBot|2018-09-04 03:30:14|504a054cd410fb378e11d9f703cfe23e-dll|
|[cba24ba2d2a96356d7f1ce79b1ead173](https://www.virustotal.com/gui/file/cba24ba2d2a96356d7f1ce79b1ead173)|unknown||2018-09-02 14:10:05|test2|
|[f41bbd08d89a7d4d396c287ed77685a0](https://www.virustotal.com/gui/file/f41bbd08d89a7d4d396c287ed77685a0)|Win32 DLL|TrickBot|2018-09-01 22:49:24|myfile.exe|
|[31fa004c59f2eb177c2375b2d01f1894](https://www.virustotal.com/gui/file/31fa004c59f2eb177c2375b2d01f1894)|Win32 EXE|sednit|2018-08-29 12:03:15|codexgigas_26831a4ded3fbf2f8f311c847ed4c590b6966c65|
|[5e4e8cab7fcb43ed39b2feac92ddc2e7](https://www.virustotal.com/gui/file/5e4e8cab7fcb43ed39b2feac92ddc2e7)|Win32 EXE||2018-08-25 19:54:22| |
|[961e79a33f432ea96d2c8bf9eb010006](https://www.virustotal.com/gui/file/961e79a33f432ea96d2c8bf9eb010006)|Win32 EXE|strictor|2018-08-24 13:18:28|codexgigas_913ac13ff245baeff843a99dc2cbc1ff5f8c025c|
|[fe8f363a035fdbefcee4567bf406f514](https://www.virustotal.com/gui/file/fe8f363a035fdbefcee4567bf406f514)|Win32 EXE||2018-08-23 16:03:59|/data/cfs/malshare/fe8f363a035fdbefcee4567bf406f514|
|[b50640a28a1d4f2acdce93adf2ea326c](https://www.virustotal.com/gui/file/b50640a28a1d4f2acdce93adf2ea326c)|Win32 EXE||2018-08-20 13:44:56|codexgigas_b758c7775d9bcdc0473fc2e738b32f05b464b175|
|[fca0c829da63ce9ea33548eef9c23a43](https://www.virustotal.com/gui/file/fca0c829da63ce9ea33548eef9c23a43)|Win32 EXE||2018-08-20 10:29:27| |
|[be6f600e05d6d958a9f614fc415ecba1](https://www.virustotal.com/gui/file/be6f600e05d6d958a9f614fc415ecba1)|Win32 EXE|strictor|2018-08-19 10:28:56|UpnP Error Handler|
|[4fa6cd01571905b9c7c8fc9a359b655e](https://www.virustotal.com/gui/file/4fa6cd01571905b9c7c8fc9a359b655e)|Win64 EXE|sednit|2018-08-18 03:51:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/X-AgentTrojan.bin|
|[9be30e2c2e185ccb6cdbbf585d368393](https://www.virustotal.com/gui/file/9be30e2c2e185ccb6cdbbf585d368393)|Win32 DLL||2018-08-09 11:25:56|15.exe|
|[bda5f83ee4a6d64d1057f19a2a1ef071](https://www.virustotal.com/gui/file/bda5f83ee4a6d64d1057f19a2a1ef071)|Win32 EXE||2018-08-09 11:23:01|bda5f83ee4a6d64d1057f19a2a1ef071.virus|
|[d1755976a6f7e1cbf21132ac4fdcf553](https://www.virustotal.com/gui/file/d1755976a6f7e1cbf21132ac4fdcf553)|Win32 EXE|Delf|2018-07-30 16:20:05|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/FancyBearZekapabImplant.bin|
|[2c27f24939144655677bb73d2790d668](https://www.virustotal.com/gui/file/2c27f24939144655677bb73d2790d668)|Win32 EXE||2018-07-26 18:26:57|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/FancyImplant.bin|
|[8c2f9832b38b4c10f3b5b7924379d599](https://www.virustotal.com/gui/file/8c2f9832b38b4c10f3b5b7924379d599)|Win32 EXE||2018-07-21 18:05:13|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/ZekapabImplant.bin|
|[edc83f5b08d3d009e60f3700d6a273da](https://www.virustotal.com/gui/file/edc83f5b08d3d009e60f3700d6a273da)|Win32 EXE|sednit|2018-07-14 09:38:15|upnphost.exe|
|[5debb3535cba6615526c64e44d0f5e2b](https://www.virustotal.com/gui/file/5debb3535cba6615526c64e44d0f5e2b)|XLS|o97m|2018-07-08 18:37:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28DropperExcelDoc.xls|
|[515a84980b091060a4f0070007f5a207](https://www.virustotal.com/gui/file/515a84980b091060a4f0070007f5a207)|DOCX||2018-07-06 21:56:01|515a84980b091060a4f0070007f5a207.virus|
|[dc40f11eb6815ca9adea0a3b8ce7262c](https://www.virustotal.com/gui/file/dc40f11eb6815ca9adea0a3b8ce7262c)|Win32 EXE||2018-07-04 07:00:16|/Users/x/VT/malware/evil.exe|
|[44d5d647016b04a095f3658260eaac72](https://www.virustotal.com/gui/file/44d5d647016b04a095f3658260eaac72)|Win32 EXE||2018-07-04 05:54:45|44d5d647016b04a095f3658260eaac72.vir|
|[687464d6c668b59f85b0e02012945fe5](https://www.virustotal.com/gui/file/687464d6c668b59f85b0e02012945fe5)|Win32 EXE||2018-07-03 08:00:43|e7dd9678b0a1c4881e80230ac716b21a41757648d71c538417755521438576f6.bin|
|[75fa78ebe2ccf42ad885c722a78399aa](https://www.virustotal.com/gui/file/75fa78ebe2ccf42ad885c722a78399aa)|Win32 EXE|strictor|2018-07-03 07:44:20|12-033-1589(1).rar|
|[c9e1b0628ac62e5cb01bf1fa30ac8317](https://www.virustotal.com/gui/file/c9e1b0628ac62e5cb01bf1fa30ac8317)|Win32 EXE|sednit|2018-06-28 12:48:34|Event Log Controls|
|[9157f70faaedf66688fc11f4abca83e2](https://www.virustotal.com/gui/file/9157f70faaedf66688fc11f4abca83e2)|Win32 DLL||2018-06-28 09:49:18|37f15647c26d475db805048d6592aa153533ac5f4373145c75e24012a51addll|
|[73ea983ec9c39fb820d086acdf439c95](https://www.virustotal.com/gui/file/73ea983ec9c39fb820d086acdf439c95)|Win32 EXE||2018-06-28 09:43:11|/home/seclab/Documents/meseum_data/only_using_data_set/vir/using_vir_all_data/indexing/73ea983ec9c39fb820d086acdf439c95.vir|
|[d29899195c604f0615885bc6c2fdf7a8](https://www.virustotal.com/gui/file/d29899195c604f0615885bc6c2fdf7a8)|Mach-O executable||2018-06-26 14:30:39|Samp_(16).file|
|[4384c701308a9d3aa92f49615ec74b2d](https://www.virustotal.com/gui/file/4384c701308a9d3aa92f49615ec74b2d)|Win32 EXE|Delf|2018-06-26 14:08:28|audev.exe|
|[ff9eb842642190a25e02c906f3f0a5d5](https://www.virustotal.com/gui/file/ff9eb842642190a25e02c906f3f0a5d5)|JPEG||2018-06-25 06:53:05|SCAN_QXWEGRFGCVT_3238036589.pdf|
|[374896a75493a406eb427f35eec86fe5](https://www.virustotal.com/gui/file/374896a75493a406eb427f35eec86fe5)|Win32 DLL|Ursu|2018-06-23 00:20:28|sdbn.dll|
|[58721c27c882e8c6a51f258f2ed5e89b](https://www.virustotal.com/gui/file/58721c27c882e8c6a51f258f2ed5e89b)|Win32 EXE||2018-06-21 09:00:35|308b41db9e3b332bb5b3e5ec633907761eac5082029b8b32e6b063b8c76b7365.bin|
|[5b915f7ea4d65c827952354b200c9bc6](https://www.virustotal.com/gui/file/5b915f7ea4d65c827952354b200c9bc6)|Win32 EXE|strictor|2018-06-21 08:47:20|1111.rar|
|[fc0cb1dbab4bc6504e644f311d9bb4a1](https://www.virustotal.com/gui/file/fc0cb1dbab4bc6504e644f311d9bb4a1)|Win64 DLL|sednit|2018-06-12 09:42:30|msoutlook.dll|
|[c6e95fb89df8e84eb21b3ce6b8947ce2](https://www.virustotal.com/gui/file/c6e95fb89df8e84eb21b3ce6b8947ce2)|Win32 EXE||2018-06-10 18:04:51|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/ZekaAPT28.bin|
|[1bcf064650aef06d83484d991bdf6750](https://www.virustotal.com/gui/file/1bcf064650aef06d83484d991bdf6750)|Win32 EXE||2018-06-09 03:00:31|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/FancyBearZekapab.bin|
|[809cbf6cfded8d571d20fe27d6cf91f9](https://www.virustotal.com/gui/file/809cbf6cfded8d571d20fe27d6cf91f9)|Win64 DLL|sednit|2018-06-08 13:19:59|outlook.dll|
|[6a674860f45219db61d90f17eb80731b](https://www.virustotal.com/gui/file/6a674860f45219db61d90f17eb80731b)|ELF executable|VPNFilter|2018-06-06 13:05:33|6a674860f45219db61d90f17eb80731b.virus|
|[f88f03f4fa8e9dc97aaa0b4610ce92cc](https://www.virustotal.com/gui/file/f88f03f4fa8e9dc97aaa0b4610ce92cc)|ELF executable|VPNFilter|2018-06-06 13:05:31|f88f03f4fa8e9dc97aaa0b4610ce92cc.virus|
|[1e96a5a6c7273af56268e9a173d91a36](https://www.virustotal.com/gui/file/1e96a5a6c7273af56268e9a173d91a36)|ELF executable|VPNFilter|2018-06-06 13:05:30|1e96a5a6c7273af56268e9a173d91a36.virus|
|[4f94ddcc0f9b295f53f668ad7e72061c](https://www.virustotal.com/gui/file/4f94ddcc0f9b295f53f668ad7e72061c)|ELF executable|VPNFilter|2018-06-06 13:05:29|4f94ddcc0f9b295f53f668ad7e72061c.virus|
|[2d751649c6d70a32c9c4b3ef368a6f9e](https://www.virustotal.com/gui/file/2d751649c6d70a32c9c4b3ef368a6f9e)|ELF executable|VPNFilter|2018-06-06 13:05:27|2d751649c6d70a32c9c4b3ef368a6f9e.virus|
|[6823c4944bf95c35aea1155028772ab3](https://www.virustotal.com/gui/file/6823c4944bf95c35aea1155028772ab3)|ELF executable|VPNFilter|2018-06-06 13:05:25|6823c4944bf95c35aea1155028772ab3.virus|
|[8309e828f9c277b15adfde8e141fed36](https://www.virustotal.com/gui/file/8309e828f9c277b15adfde8e141fed36)|ELF executable|VPNFilter|2018-06-06 13:05:24|8309e828f9c277b15adfde8e141fed36.virus|
|[fed5753b6e4314c00c8eb4ce05ee67da](https://www.virustotal.com/gui/file/fed5753b6e4314c00c8eb4ce05ee67da)|ELF executable|VPNFilter|2018-06-06 13:05:22|fed5753b6e4314c00c8eb4ce05ee67da.virus|
|[b88f7aef886d5f6450f388ade2056795](https://www.virustotal.com/gui/file/b88f7aef886d5f6450f388ade2056795)|ELF executable|VPNFilter|2018-06-06 13:05:21|b88f7aef886d5f6450f388ade2056795.virus|
|[869dbd7851e28a8a9b6d047ed6e2813b](https://www.virustotal.com/gui/file/869dbd7851e28a8a9b6d047ed6e2813b)|ELF executable|VPNFilter|2018-06-06 13:05:20|869dbd7851e28a8a9b6d047ed6e2813b.virus|
|[294f1919362657f7d223c6022a7fa559](https://www.virustotal.com/gui/file/294f1919362657f7d223c6022a7fa559)|ELF executable|VPNFilter|2018-06-06 13:05:17|294f1919362657f7d223c6022a7fa559.virus|
|[cb214c2c04a0dd1ddfda5c9be083f02e](https://www.virustotal.com/gui/file/cb214c2c04a0dd1ddfda5c9be083f02e)|ELF executable|VPNFilter|2018-06-06 13:05:15|cb214c2c04a0dd1ddfda5c9be083f02e.virus|
|[f38b4e8a6a9e27b425d2200cae32d063](https://www.virustotal.com/gui/file/f38b4e8a6a9e27b425d2200cae32d063)|ELF executable|VPNFilter|2018-06-06 13:05:10|f38b4e8a6a9e27b425d2200cae32d063.virus|
|[78b9dc46f5e57f656c83e18182151a65](https://www.virustotal.com/gui/file/78b9dc46f5e57f656c83e18182151a65)|ELF executable|VPNFilter|2018-06-06 13:05:09|78b9dc46f5e57f656c83e18182151a65.virus|
|[ed962f9c8091eb80496da2349c85eb8a](https://www.virustotal.com/gui/file/ed962f9c8091eb80496da2349c85eb8a)|ELF executable|VPNFilter|2018-06-06 13:05:08|ed962f9c8091eb80496da2349c85eb8a.virus|
|[199cb654d18cda821d71a4f47a6cb554](https://www.virustotal.com/gui/file/199cb654d18cda821d71a4f47a6cb554)|ELF executable|VPNFilter|2018-06-06 13:05:06|199cb654d18cda821d71a4f47a6cb554.virus|
|[15ecef0e780f7f8601c1e73028457a25](https://www.virustotal.com/gui/file/15ecef0e780f7f8601c1e73028457a25)|ELF executable|VPNFilter|2018-06-06 13:05:04|15ecef0e780f7f8601c1e73028457a25.virus|
|[c0c3aa8ee94a1addaf1be950dcb0d0ee](https://www.virustotal.com/gui/file/c0c3aa8ee94a1addaf1be950dcb0d0ee)|unknown||2018-06-06 13:05:02| |
|[a2cbb007508bbb6f6fa5345d98f2b2f6](https://www.virustotal.com/gui/file/a2cbb007508bbb6f6fa5345d98f2b2f6)|unknown||2018-06-06 13:05:01| |
|[0710f7254ccb5085dbbdbe3ba3a3f6b3](https://www.virustotal.com/gui/file/0710f7254ccb5085dbbdbe3ba3a3f6b3)|ELF executable|VPNFilter|2018-06-06 13:04:59|0710f7254ccb5085dbbdbe3ba3a3f6b3.virus|
|[5c683ee7537732b36303a667706be985](https://www.virustotal.com/gui/file/5c683ee7537732b36303a667706be985)|ELF executable|VPNFilter|2018-06-06 13:04:58|5c683ee7537732b36303a667706be985.virus|
|[b84f79b894e8f0bdb1cbad72d1f9f83f](https://www.virustotal.com/gui/file/b84f79b894e8f0bdb1cbad72d1f9f83f)|ELF executable|VPNFilter|2018-06-06 13:04:56|b84f79b894e8f0bdb1cbad72d1f9f83f.virus|
|[4bc594edc1c0e7dcfd85668c7c11e6e8](https://www.virustotal.com/gui/file/4bc594edc1c0e7dcfd85668c7c11e6e8)|ELF executable|VPNFilter|2018-06-06 13:04:55|4bc594edc1c0e7dcfd85668c7c11e6e8.virus|
|[4a0119bda96848a15d4b0aad844238dd](https://www.virustotal.com/gui/file/4a0119bda96848a15d4b0aad844238dd)|ELF executable|VPNFilter|2018-06-06 13:04:53|4a0119bda96848a15d4b0aad844238dd.virus|
|[62591ae87d11aa7d7025370f2ab1c390](https://www.virustotal.com/gui/file/62591ae87d11aa7d7025370f2ab1c390)|ELF executable|VPNFilter|2018-06-06 13:04:52|62591ae87d11aa7d7025370f2ab1c390.virus|
|[d625e44a61f6b020df0f8f78a780c473](https://www.virustotal.com/gui/file/d625e44a61f6b020df0f8f78a780c473)|ELF executable|VPNFilter|2018-06-06 13:04:51|d625e44a61f6b020df0f8f78a780c473.virus|
|[0f53a8c840b533333a68e2436a2da48a](https://www.virustotal.com/gui/file/0f53a8c840b533333a68e2436a2da48a)|unknown||2018-06-06 13:04:50| |
|[f1433d5c93fd448e3e0c3a4ca65bfe5b](https://www.virustotal.com/gui/file/f1433d5c93fd448e3e0c3a4ca65bfe5b)|ELF executable|VPNFilter|2018-06-06 13:04:48|f1433d5c93fd448e3e0c3a4ca65bfe5b.virus|
|[1c4cebcff557c22bc821ce7e65757e94](https://www.virustotal.com/gui/file/1c4cebcff557c22bc821ce7e65757e94)|ELF executable|VPNFilter|2018-06-06 13:04:47|1c4cebcff557c22bc821ce7e65757e94.virus|
|[62ff322cf8d45857f9559f8b66ea39b2](https://www.virustotal.com/gui/file/62ff322cf8d45857f9559f8b66ea39b2)|ELF executable|VPNFilter|2018-06-06 13:04:46|62ff322cf8d45857f9559f8b66ea39b2.virus|
|[d4c4e79a2a81bc9f0811beb612238b1b](https://www.virustotal.com/gui/file/d4c4e79a2a81bc9f0811beb612238b1b)|ELF executable|VPNFilter|2018-06-06 13:04:46|d4c4e79a2a81bc9f0811beb612238b1b.virus|
|[0773b186876da7656dc0bb937d75d364](https://www.virustotal.com/gui/file/0773b186876da7656dc0bb937d75d364)|ELF executable|VPNFilter|2018-06-06 13:04:44|0773b186876da7656dc0bb937d75d364.virus|
|[557addcbdf83dbe8bd6f9c47ce20cc63](https://www.virustotal.com/gui/file/557addcbdf83dbe8bd6f9c47ce20cc63)|ELF executable|VPNFilter|2018-06-06 13:04:43|557addcbdf83dbe8bd6f9c47ce20cc63.virus|
|[7c4ca045efa81cd3be46f2f7699a05b0](https://www.virustotal.com/gui/file/7c4ca045efa81cd3be46f2f7699a05b0)|ELF executable|VPNFilter|2018-06-06 13:04:41|7c4ca045efa81cd3be46f2f7699a05b0.virus|
|[e355e55072cf5c56c7ba0287214b6c75](https://www.virustotal.com/gui/file/e355e55072cf5c56c7ba0287214b6c75)|ELF executable|VPNFilter|2018-06-06 13:04:40|e355e55072cf5c56c7ba0287214b6c75.virus|
|[bfe231f46784c7560639957595db48a5](https://www.virustotal.com/gui/file/bfe231f46784c7560639957595db48a5)|ELF executable|VPNFilter|2018-06-06 13:04:38|bfe231f46784c7560639957595db48a5.virus|
|[4e65b38cd6160aa60980c8a0a7c2de3f](https://www.virustotal.com/gui/file/4e65b38cd6160aa60980c8a0a7c2de3f)|ELF executable|VPNFilter|2018-06-06 13:04:37|4e65b38cd6160aa60980c8a0a7c2de3f.virus|
|[ec043717badd5012b5656b92218484e3](https://www.virustotal.com/gui/file/ec043717badd5012b5656b92218484e3)|ELF executable|VPNFilter|2018-06-06 13:04:36|ec043717badd5012b5656b92218484e3.virus|
|[113543c3f820c02d66ad77c7da79e4d3](https://www.virustotal.com/gui/file/113543c3f820c02d66ad77c7da79e4d3)|ELF executable|VPNFilter|2018-06-06 13:04:33|113543c3f820c02d66ad77c7da79e4d3.virus|
|[b198bfb5239d4a785fd91819cc8fe4c0](https://www.virustotal.com/gui/file/b198bfb5239d4a785fd91819cc8fe4c0)|ELF executable|VPNFilter|2018-06-06 13:04:32|b198bfb5239d4a785fd91819cc8fe4c0.virus|
|[651c8836af7101549ec819f946cb4258](https://www.virustotal.com/gui/file/651c8836af7101549ec819f946cb4258)|ELF executable|VPNFilter|2018-06-06 13:04:32|651c8836af7101549ec819f946cb4258.virus|
|[a71dd0ef2fdcf50e063dd47d65d849f3](https://www.virustotal.com/gui/file/a71dd0ef2fdcf50e063dd47d65d849f3)|ELF executable|VPNFilter|2018-06-06 13:04:30|a71dd0ef2fdcf50e063dd47d65d849f3.virus|
|[3d5f8591d0c15d00067cad58b2c49d22](https://www.virustotal.com/gui/file/3d5f8591d0c15d00067cad58b2c49d22)|ELF executable|VPNFilter|2018-06-06 13:04:29|3d5f8591d0c15d00067cad58b2c49d22.virus|
|[2a3decffb7dd6393380ed676d5b8d047](https://www.virustotal.com/gui/file/2a3decffb7dd6393380ed676d5b8d047)|ELF executable|VPNFilter|2018-06-06 13:04:27|2a3decffb7dd6393380ed676d5b8d047.virus|
|[b9ff6a1221f60b399292a76cb0bf90c7](https://www.virustotal.com/gui/file/b9ff6a1221f60b399292a76cb0bf90c7)|ELF executable|VPNFilter|2018-06-06 13:04:26|b9ff6a1221f60b399292a76cb0bf90c7.virus|
|[7e4073ca610f3eb25e6c5ea18e0eb85b](https://www.virustotal.com/gui/file/7e4073ca610f3eb25e6c5ea18e0eb85b)|unknown||2018-06-06 13:04:25| |
|[e0bbcebb59c395a377cf660421f3c636](https://www.virustotal.com/gui/file/e0bbcebb59c395a377cf660421f3c636)|ELF executable|VPNFilter|2018-06-06 13:04:24|e0bbcebb59c395a377cf660421f3c636.virus|
|[50fed9ca4cff8f1beecd7698bf5ff094](https://www.virustotal.com/gui/file/50fed9ca4cff8f1beecd7698bf5ff094)|ELF executable|VPNFilter|2018-06-06 13:04:22|50fed9ca4cff8f1beecd7698bf5ff094.virus|
|[48558cd839f2e352d880375f4404ef16](https://www.virustotal.com/gui/file/48558cd839f2e352d880375f4404ef16)|ELF executable|VPNFilter|2018-06-06 13:04:21|48558cd839f2e352d880375f4404ef16.virus|
|[3ecb8725e433d395e4c14a496149024f](https://www.virustotal.com/gui/file/3ecb8725e433d395e4c14a496149024f)|ELF executable|VPNFilter|2018-06-06 13:04:20|3ecb8725e433d395e4c14a496149024f.virus|
|[8597431908de34ec4951d2e202e99d87](https://www.virustotal.com/gui/file/8597431908de34ec4951d2e202e99d87)|ELF executable|VPNFilter|2018-06-06 13:04:19|8597431908de34ec4951d2e202e99d87.virus|
|[e8a0a9a1e0f7441fea5a41d7a14af119](https://www.virustotal.com/gui/file/e8a0a9a1e0f7441fea5a41d7a14af119)|ELF executable|VPNFilter|2018-06-06 13:04:15|e8a0a9a1e0f7441fea5a41d7a14af119.virus|
|[3a5aaa8d41a0120382d04e03be82e3cd](https://www.virustotal.com/gui/file/3a5aaa8d41a0120382d04e03be82e3cd)|ELF executable|VPNFilter|2018-06-06 13:04:14|3a5aaa8d41a0120382d04e03be82e3cd.virus|
|[91f3bb91f15e534d767c0713a9a9aef5](https://www.virustotal.com/gui/file/91f3bb91f15e534d767c0713a9a9aef5)|ELF executable|VPNFilter|2018-06-06 13:04:13|91f3bb91f15e534d767c0713a9a9aef5.virus|
|[8939be5bfe9ffb100c204c0ce46d92ff](https://www.virustotal.com/gui/file/8939be5bfe9ffb100c204c0ce46d92ff)|ELF executable|VPNFilter|2018-06-06 13:04:12|8939be5bfe9ffb100c204c0ce46d92ff.virus|
|[372b6c23cb47b3cd1608139fb3f8c16a](https://www.virustotal.com/gui/file/372b6c23cb47b3cd1608139fb3f8c16a)|ELF executable|VPNFilter|2018-06-06 13:04:11|372b6c23cb47b3cd1608139fb3f8c16a.virus|
|[f94aabb3393fe40da29a2fdd9ea448d0](https://www.virustotal.com/gui/file/f94aabb3393fe40da29a2fdd9ea448d0)|ELF executable|VPNFilter|2018-06-06 13:04:10|f94aabb3393fe40da29a2fdd9ea448d0.virus|
|[f4dedb6b6b2eeb4980b924010c3b3d08](https://www.virustotal.com/gui/file/f4dedb6b6b2eeb4980b924010c3b3d08)|ELF executable|VPNFilter|2018-06-06 13:04:08|f4dedb6b6b2eeb4980b924010c3b3d08.virus|
|[9776b375ed173b199663190e49c10588](https://www.virustotal.com/gui/file/9776b375ed173b199663190e49c10588)|ELF executable|VPNFilter|2018-06-06 13:04:06|9776b375ed173b199663190e49c10588.virus|
|[08693c600ef80266d959ccfc6354a4f3](https://www.virustotal.com/gui/file/08693c600ef80266d959ccfc6354a4f3)|ELF executable|VPNFilter|2018-06-06 13:04:05|08693c600ef80266d959ccfc6354a4f3.virus|
|[3667d02f70ca6835d92d8a312821293f](https://www.virustotal.com/gui/file/3667d02f70ca6835d92d8a312821293f)|ELF executable|VPNFilter|2018-06-06 13:04:04|3667d02f70ca6835d92d8a312821293f.virus|
|[2e253570f12cc5acf073a72aa8c0b62b](https://www.virustotal.com/gui/file/2e253570f12cc5acf073a72aa8c0b62b)|ELF executable|VPNFilter|2018-06-06 13:04:03|2e253570f12cc5acf073a72aa8c0b62b.virus|
|[fd3dfcdb24f1eb0c2cb3aee640b9431b](https://www.virustotal.com/gui/file/fd3dfcdb24f1eb0c2cb3aee640b9431b)|ELF executable|VPNFilter|2018-06-06 13:04:01|fd3dfcdb24f1eb0c2cb3aee640b9431b.virus|
|[2471bcb9f3415678cf19f0582c655060](https://www.virustotal.com/gui/file/2471bcb9f3415678cf19f0582c655060)|ELF executable|VPNFilter|2018-06-06 13:03:59|2471bcb9f3415678cf19f0582c655060.virus|
|[cb0e6de9eb767e32208bd5ef80ddd226](https://www.virustotal.com/gui/file/cb0e6de9eb767e32208bd5ef80ddd226)|ELF executable|VPNFilter|2018-06-06 13:03:58|cb0e6de9eb767e32208bd5ef80ddd226.virus|
|[e7f6efa9fc34801c8d5af76911e47d07](https://www.virustotal.com/gui/file/e7f6efa9fc34801c8d5af76911e47d07)|unknown||2018-06-06 13:03:57| |
|[55e497150e6337255a9dce39d8e41ece](https://www.virustotal.com/gui/file/55e497150e6337255a9dce39d8e41ece)|ELF executable|VPNFilter|2018-06-06 13:03:56|55e497150e6337255a9dce39d8e41ece.virus|
|[272b941c683a37aff38dfc8ff8e33593](https://www.virustotal.com/gui/file/272b941c683a37aff38dfc8ff8e33593)|ELF executable|VPNFilter|2018-06-06 13:03:52|272b941c683a37aff38dfc8ff8e33593.virus|
|[2c26742856bc6f2e88acbeb7c9788d2c](https://www.virustotal.com/gui/file/2c26742856bc6f2e88acbeb7c9788d2c)|ELF executable|VPNFilter|2018-06-06 13:03:51|2c26742856bc6f2e88acbeb7c9788d2c.virus|
|[cfff33953e362a962f2a1b12f8c0a6d8](https://www.virustotal.com/gui/file/cfff33953e362a962f2a1b12f8c0a6d8)|ELF executable|VPNFilter|2018-06-06 13:03:49|cfff33953e362a962f2a1b12f8c0a6d8.virus|
|[8bec34995bd38137ed6d92178af4a605](https://www.virustotal.com/gui/file/8bec34995bd38137ed6d92178af4a605)|ELF executable|VPNFilter|2018-06-06 13:03:47|8bec34995bd38137ed6d92178af4a605.virus|
|[4802c3d32ee105878b047bffafc9db4f](https://www.virustotal.com/gui/file/4802c3d32ee105878b047bffafc9db4f)|ELF executable|VPNFilter|2018-06-06 13:03:46|4802c3d32ee105878b047bffafc9db4f.virus|
|[607433e752db3e05a7e3dac853a43cde](https://www.virustotal.com/gui/file/607433e752db3e05a7e3dac853a43cde)|unknown|VPNFilter|2018-06-06 13:03:45| |
|[d63b90f57fbdf9917adae4ee15286796](https://www.virustotal.com/gui/file/d63b90f57fbdf9917adae4ee15286796)|ELF executable|VPNFilter|2018-06-06 13:03:43|d63b90f57fbdf9917adae4ee15286796.virus|
|[af795346818e6df5fba879c2b0514f7e](https://www.virustotal.com/gui/file/af795346818e6df5fba879c2b0514f7e)|ELF executable|VPNFilter|2018-06-06 13:03:42|af795346818e6df5fba879c2b0514f7e.virus|
|[1ce4443396b17161d0c72ba582f82630](https://www.virustotal.com/gui/file/1ce4443396b17161d0c72ba582f82630)|ELF executable|VPNFilter|2018-06-06 13:03:40|1ce4443396b17161d0c72ba582f82630.virus|
|[d0d21fd09b5a0111ac27343ac503d362](https://www.virustotal.com/gui/file/d0d21fd09b5a0111ac27343ac503d362)|ELF executable|VPNFilter|2018-06-06 13:03:39|d0d21fd09b5a0111ac27343ac503d362.virus|
|[cbf0dcf944d93cbb425e718f49e70ea0](https://www.virustotal.com/gui/file/cbf0dcf944d93cbb425e718f49e70ea0)|ELF executable|VPNFilter|2018-06-06 13:03:38|cbf0dcf944d93cbb425e718f49e70ea0.virus|
|[431ea5bf13e96e620fd8ed7ba8bcdb33](https://www.virustotal.com/gui/file/431ea5bf13e96e620fd8ed7ba8bcdb33)|ELF executable|VPNFilter|2018-06-06 13:03:36|431ea5bf13e96e620fd8ed7ba8bcdb33.virus|
|[eb5b6d467d1202b42951ad41b7e6f22c](https://www.virustotal.com/gui/file/eb5b6d467d1202b42951ad41b7e6f22c)|ELF executable|VPNFilter|2018-06-06 13:03:35|eb5b6d467d1202b42951ad41b7e6f22c.virus|
|[8f82dc3edbefff2c5652aef23994d519](https://www.virustotal.com/gui/file/8f82dc3edbefff2c5652aef23994d519)|ELF executable|VPNFilter|2018-06-06 13:03:34|8f82dc3edbefff2c5652aef23994d519.virus|
|[a3e794ce4496d2f074ba48252b1444c0](https://www.virustotal.com/gui/file/a3e794ce4496d2f074ba48252b1444c0)|ELF executable|VPNFilter|2018-06-06 13:03:32|a3e794ce4496d2f074ba48252b1444c0.virus|
|[2da4d8ffca55181e10f8ee0066539c68](https://www.virustotal.com/gui/file/2da4d8ffca55181e10f8ee0066539c68)|ELF executable|VPNFilter|2018-06-06 13:03:31|2da4d8ffca55181e10f8ee0066539c68.virus|
|[e96a4fd6d4f219c72b463ea64c54c9c6](https://www.virustotal.com/gui/file/e96a4fd6d4f219c72b463ea64c54c9c6)|ELF executable|VPNFilter|2018-06-06 13:03:30|e96a4fd6d4f219c72b463ea64c54c9c6.virus|
|[dac9be5b12dd1f648149051db00c5804](https://www.virustotal.com/gui/file/dac9be5b12dd1f648149051db00c5804)|ELF executable|VPNFilter|2018-06-06 13:03:28|dac9be5b12dd1f648149051db00c5804.virus|
|[8e92bc4d3aa5312c1785601869a1e577](https://www.virustotal.com/gui/file/8e92bc4d3aa5312c1785601869a1e577)|ELF executable|VPNFilter|2018-06-06 13:03:27|8e92bc4d3aa5312c1785601869a1e577.virus|
|[fee92a496b321bc5221e7242e0d4c63a](https://www.virustotal.com/gui/file/fee92a496b321bc5221e7242e0d4c63a)|ELF executable|VPNFilter|2018-06-06 13:03:26|fee92a496b321bc5221e7242e0d4c63a.virus|
|[f84e6641f0416109af2d1f5acf2a3249](https://www.virustotal.com/gui/file/f84e6641f0416109af2d1f5acf2a3249)|ELF executable|VPNFilter|2018-06-06 13:03:25|f84e6641f0416109af2d1f5acf2a3249.virus|
|[fb17ae041caa00a5faeb5013d51335ac](https://www.virustotal.com/gui/file/fb17ae041caa00a5faeb5013d51335ac)|ELF executable|VPNFilter|2018-06-06 13:03:23|fb17ae041caa00a5faeb5013d51335ac.virus|
|[76d49863c24e9034ad4dabc3a5a77bd4](https://www.virustotal.com/gui/file/76d49863c24e9034ad4dabc3a5a77bd4)|ELF executable|VPNFilter|2018-06-06 13:03:22|76d49863c24e9034ad4dabc3a5a77bd4.virus|
|[d725747e000a0e28c56c51c4ec722f9d](https://www.virustotal.com/gui/file/d725747e000a0e28c56c51c4ec722f9d)|ELF executable|VPNFilter|2018-06-06 13:03:20|d725747e000a0e28c56c51c4ec722f9d.virus|
|[e9a4b93faccf444c53c0dd365f597c76](https://www.virustotal.com/gui/file/e9a4b93faccf444c53c0dd365f597c76)|ELF executable|VPNFilter|2018-06-06 13:03:17|e9a4b93faccf444c53c0dd365f597c76.virus|
|[be532071ed46e64b89f67008568ccdd3](https://www.virustotal.com/gui/file/be532071ed46e64b89f67008568ccdd3)|ELF executable|VPNFilter|2018-06-06 13:03:14|be532071ed46e64b89f67008568ccdd3.virus|
|[e93c08caff2acdd0ba7ab112771f4fa8](https://www.virustotal.com/gui/file/e93c08caff2acdd0ba7ab112771f4fa8)|ELF executable|VPNFilter|2018-06-06 13:03:11|e93c08caff2acdd0ba7ab112771f4fa8.virus|
|[d2486fff5f2cf5173ec5d47ae00d21b7](https://www.virustotal.com/gui/file/d2486fff5f2cf5173ec5d47ae00d21b7)|unknown||2018-06-06 13:03:10| |
|[dcfff5574c3ee69e543ba537ea69eaaf](https://www.virustotal.com/gui/file/dcfff5574c3ee69e543ba537ea69eaaf)|ELF executable|VPNFilter|2018-06-06 13:03:09|dcfff5574c3ee69e543ba537ea69eaaf.virus|
|[f81a5b94139d00456f4cb05649a431ac](https://www.virustotal.com/gui/file/f81a5b94139d00456f4cb05649a431ac)|ELF executable|VPNFilter|2018-06-06 13:03:08|f81a5b94139d00456f4cb05649a431ac.virus|
|[bd2374482669a6a024f905a3d4cae6b5](https://www.virustotal.com/gui/file/bd2374482669a6a024f905a3d4cae6b5)|ELF executable|VPNFilter|2018-06-06 13:03:06|bd2374482669a6a024f905a3d4cae6b5.virus|
|[b823c57710445200a013f3fb906d9eb1](https://www.virustotal.com/gui/file/b823c57710445200a013f3fb906d9eb1)|ELF executable|VPNFilter|2018-06-06 13:03:05|b823c57710445200a013f3fb906d9eb1.virus|
|[98f0b5fb57b4d05082b2ba5cd31ace94](https://www.virustotal.com/gui/file/98f0b5fb57b4d05082b2ba5cd31ace94)|ELF executable|VPNFilter|2018-06-06 13:03:03|98f0b5fb57b4d05082b2ba5cd31ace94.virus|
|[4c3b5e24d34a9aa2b64f46d5d88c3716](https://www.virustotal.com/gui/file/4c3b5e24d34a9aa2b64f46d5d88c3716)|ELF executable|VPNFilter|2018-06-06 13:03:01|4c3b5e24d34a9aa2b64f46d5d88c3716.virus|
|[d9895f7e8a8c64ce31a1f98f7997be4d](https://www.virustotal.com/gui/file/d9895f7e8a8c64ce31a1f98f7997be4d)|ELF executable|VPNFilter|2018-06-06 13:03:00|d9895f7e8a8c64ce31a1f98f7997be4d.virus|
|[acaa4b001f70a6bcf1d78c915a8c289c](https://www.virustotal.com/gui/file/acaa4b001f70a6bcf1d78c915a8c289c)|ELF executable|VPNFilter|2018-06-06 13:02:59|acaa4b001f70a6bcf1d78c915a8c289c.virus|
|[372530a6166bd74c10414a470537cdf9](https://www.virustotal.com/gui/file/372530a6166bd74c10414a470537cdf9)|ELF executable|VPNFilter|2018-06-06 13:02:58|372530a6166bd74c10414a470537cdf9.virus|
|[7507049c3977ca64361a8de31f656ea0](https://www.virustotal.com/gui/file/7507049c3977ca64361a8de31f656ea0)|ELF executable|VPNFilter|2018-06-06 13:02:57|7507049c3977ca64361a8de31f656ea0.virus|
|[20ea405d79b4de1b90de54a442952a45](https://www.virustotal.com/gui/file/20ea405d79b4de1b90de54a442952a45)|ELF executable|VPNFilter|2018-06-06 13:02:56|20ea405d79b4de1b90de54a442952a45.virus|
|[e0d3af19ea517d5edefcd3cf403ac893](https://www.virustotal.com/gui/file/e0d3af19ea517d5edefcd3cf403ac893)|ELF executable|VPNFilter|2018-06-06 13:02:55|e0d3af19ea517d5edefcd3cf403ac893.virus|
|[f2addcba185081bc21ddd7d24c054f36](https://www.virustotal.com/gui/file/f2addcba185081bc21ddd7d24c054f36)|ELF executable|VPNFilter|2018-06-06 13:02:52|f2addcba185081bc21ddd7d24c054f36.virus|
|[0a283975ee04c45049cc790e34cf0a03](https://www.virustotal.com/gui/file/0a283975ee04c45049cc790e34cf0a03)|ELF executable|VPNFilter|2018-06-06 13:02:51|0a283975ee04c45049cc790e34cf0a03.virus|
|[81b199f3b9f843afb632c5bba7645d92](https://www.virustotal.com/gui/file/81b199f3b9f843afb632c5bba7645d92)|ELF executable|VPNFilter|2018-06-06 13:02:49|81b199f3b9f843afb632c5bba7645d92.virus|
|[6d049580bceb22b2b3b791ebd848eb6e](https://www.virustotal.com/gui/file/6d049580bceb22b2b3b791ebd848eb6e)|ELF executable|VPNFilter|2018-06-06 13:02:47|6d049580bceb22b2b3b791ebd848eb6e.virus|
|[8e3766c36c2a02e2573937047ca8b9eb](https://www.virustotal.com/gui/file/8e3766c36c2a02e2573937047ca8b9eb)|ELF executable|VPNFilter|2018-06-06 13:02:44|8e3766c36c2a02e2573937047ca8b9eb.virus|
|[0f57ef32acb510ae3dd8948050105646](https://www.virustotal.com/gui/file/0f57ef32acb510ae3dd8948050105646)|ELF executable|VPNFilter|2018-06-06 13:02:43|0f57ef32acb510ae3dd8948050105646.virus|
|[b2ffc80ded0401d2c1d952e8b533c3ab](https://www.virustotal.com/gui/file/b2ffc80ded0401d2c1d952e8b533c3ab)|ELF executable|VPNFilter|2018-06-06 13:02:42|b2ffc80ded0401d2c1d952e8b533c3ab.virus|
|[aa9e2858a0c92e5e9cebd1f0d0272b88](https://www.virustotal.com/gui/file/aa9e2858a0c92e5e9cebd1f0d0272b88)|ELF executable|VPNFilter|2018-06-06 13:02:41|aa9e2858a0c92e5e9cebd1f0d0272b88.virus|
|[08c60ff3a0697b8fa8bcf31e491f9d14](https://www.virustotal.com/gui/file/08c60ff3a0697b8fa8bcf31e491f9d14)|ELF executable|VPNFilter|2018-06-06 13:02:38|08c60ff3a0697b8fa8bcf31e491f9d14.virus|
|[a0adf6697b6194d72b4c815e08216acd](https://www.virustotal.com/gui/file/a0adf6697b6194d72b4c815e08216acd)|ELF executable|VPNFilter|2018-06-06 13:02:37|a0adf6697b6194d72b4c815e08216acd.virus|
|[0fd922bf209aeb38d8900789ed372c4a](https://www.virustotal.com/gui/file/0fd922bf209aeb38d8900789ed372c4a)|ELF executable|VPNFilter|2018-06-06 13:02:36|0fd922bf209aeb38d8900789ed372c4a.virus|
|[fd9f8cb49eecbc660410523c435df171](https://www.virustotal.com/gui/file/fd9f8cb49eecbc660410523c435df171)|ELF executable|VPNFilter|2018-06-06 13:02:34|fd9f8cb49eecbc660410523c435df171.virus|
|[8803016812d6800f79dd0336eec0bbbb](https://www.virustotal.com/gui/file/8803016812d6800f79dd0336eec0bbbb)|ELF executable|VPNFilter|2018-06-06 13:02:32|8803016812d6800f79dd0336eec0bbbb.virus|
|[e3c91ae989c4893fc8f1e69a8631fe7f](https://www.virustotal.com/gui/file/e3c91ae989c4893fc8f1e69a8631fe7f)|ELF executable|VPNFilter|2018-06-06 13:02:28|e3c91ae989c4893fc8f1e69a8631fe7f.virus|
|[6b6df399d7662a905aa56592b6ecf842](https://www.virustotal.com/gui/file/6b6df399d7662a905aa56592b6ecf842)|ELF executable|VPNFilter|2018-06-06 13:02:27|6b6df399d7662a905aa56592b6ecf842.virus|
|[71dc76de840a7c2ab1936f00b08eb2b7](https://www.virustotal.com/gui/file/71dc76de840a7c2ab1936f00b08eb2b7)|ELF executable|VPNFilter|2018-06-06 13:02:26|71dc76de840a7c2ab1936f00b08eb2b7.virus|
|[8f40e127f564ba8ceaf13e9ae3fd8ab6](https://www.virustotal.com/gui/file/8f40e127f564ba8ceaf13e9ae3fd8ab6)|ELF executable|VPNFilter|2018-06-06 13:02:25|8f40e127f564ba8ceaf13e9ae3fd8ab6.virus|
|[5a9a223aabaee31db808b99a680ec085](https://www.virustotal.com/gui/file/5a9a223aabaee31db808b99a680ec085)|ELF executable|VPNFilter|2018-06-06 13:02:23|5a9a223aabaee31db808b99a680ec085.virus|
|[7dae3b0612112d915dd8bc9c40dea64b](https://www.virustotal.com/gui/file/7dae3b0612112d915dd8bc9c40dea64b)|ELF executable|VPNFilter|2018-06-06 13:02:21|/media/ahmed/0f0b5179-b625-471d-a08b-8cc99742b63c/IoTmalware/Malware/IoTFiltered/7dae3b0612112d915dd8bc9c40dea64b|
|[02ef9f203ba0d2f3ab0f12aa888693e6](https://www.virustotal.com/gui/file/02ef9f203ba0d2f3ab0f12aa888693e6)|ELF executable|VPNFilter|2018-06-06 13:02:19|02ef9f203ba0d2f3ab0f12aa888693e6.virus|
|[615d699f0e27a30ee42f8f370213e191](https://www.virustotal.com/gui/file/615d699f0e27a30ee42f8f370213e191)|ELF executable|VPNFilter|2018-06-06 13:02:17|615d699f0e27a30ee42f8f370213e191.virus|
|[db099e99bb37f9bdfb09b8c86ee69f48](https://www.virustotal.com/gui/file/db099e99bb37f9bdfb09b8c86ee69f48)|ELF executable|VPNFilter|2018-06-06 13:02:16|db099e99bb37f9bdfb09b8c86ee69f48.virus|
|[2613a6d105d010d02b79d63315c502c7](https://www.virustotal.com/gui/file/2613a6d105d010d02b79d63315c502c7)|ELF executable|VPNFilter|2018-06-06 13:02:14|2613a6d105d010d02b79d63315c502c7.virus|
|[7516865b259660683475e07703e85aa1](https://www.virustotal.com/gui/file/7516865b259660683475e07703e85aa1)|ELF executable|VPNFilter|2018-06-06 13:02:11|7516865b259660683475e07703e85aa1.virus|
|[8d75be0a392d3a9b9004a9f8814c3efb](https://www.virustotal.com/gui/file/8d75be0a392d3a9b9004a9f8814c3efb)|ELF executable|VPNFilter|2018-06-06 13:02:10|8d75be0a392d3a9b9004a9f8814c3efb.virus|
|[901cff074787639d919eaeb9b289a276](https://www.virustotal.com/gui/file/901cff074787639d919eaeb9b289a276)|ELF executable|VPNFilter|2018-06-06 13:02:08|/media/ahmed/0f0b5179-b625-471d-a08b-8cc99742b63c/IoTmalware/Malware/IoTFiltered/901cff074787639d919eaeb9b289a276|
|[b0a89a5eb524000224bc23e10c51dd5a](https://www.virustotal.com/gui/file/b0a89a5eb524000224bc23e10c51dd5a)|ELF executable|VPNFilter|2018-06-06 13:01:02|b0a89a5eb524000224bc23e10c51dd5a.virus|
|[8dbe37dfb0d498f96fb7f1e09e9e5c8f](https://www.virustotal.com/gui/file/8dbe37dfb0d498f96fb7f1e09e9e5c8f)|Win32 DLL||2018-05-30 10:30:04|gpu.dll|
|[d0dbbd31fe5205295301b2241610ef9c](https://www.virustotal.com/gui/file/d0dbbd31fe5205295301b2241610ef9c)|ELF executable|VPNFilter|2018-05-28 09:09:43|d0dbbd31fe5205295301b2241610ef9c.virus|
|[661b3db81d495a3fdd5b81185185160c](https://www.virustotal.com/gui/file/661b3db81d495a3fdd5b81185185160c)|ELF executable|VPNFilter|2018-05-28 09:08:40|661b3db81d495a3fdd5b81185185160c.virus|
|[fafb46c23c1e1e61a9180eda73b50efc](https://www.virustotal.com/gui/file/fafb46c23c1e1e61a9180eda73b50efc)|Text|VPNFilter|2018-05-27 11:04:19|fafb46c23c1e1e61a9180eda73b50efc.virus|
|[400a162a9e5946be10b9fd7155a9ee48](https://www.virustotal.com/gui/file/400a162a9e5946be10b9fd7155a9ee48)|Win32 EXE||2018-05-25 16:05:30|codexgigas_2c6e5895e1c8fc3211d04bf2390ca7d90d6bb906|
|[87049e223dd922dc1d8180c83e2fde77](https://www.virustotal.com/gui/file/87049e223dd922dc1d8180c83e2fde77)|ELF executable|VPNFilter|2018-05-23 13:01:18|87049e223dd922dc1d8180c83e2fde77_kxYYOhsarjrj.eLf|
|[b5dc976043db9b42c9f6fa889205c68a](https://www.virustotal.com/gui/file/b5dc976043db9b42c9f6fa889205c68a)|ELF executable|VPNFilter|2018-05-23 13:01:17|b5dc976043db9b42c9f6fa889205c68a_YQiOOeG.elF|
|[42d891bcdee9588f8ed5d27456896a5e](https://www.virustotal.com/gui/file/42d891bcdee9588f8ed5d27456896a5e)|ELF executable|VPNFilter|2018-05-23 13:01:13|42d891bcdee9588f8ed5d27456896a5e_xQOBRwrJmALxOHxuFrGmo.ELf|
|[4912aad5e79c78bc143e71633df9c17b](https://www.virustotal.com/gui/file/4912aad5e79c78bc143e71633df9c17b)|ELF executable|VPNFilter|2018-05-23 13:01:11|4912aad5e79c78bc143e71633df9c17b_SvYlZodXvraGeKR.ELF|
|[92d47495c92d8c5dba107163df2bb212](https://www.virustotal.com/gui/file/92d47495c92d8c5dba107163df2bb212)|ELF executable|VPNFilter|2018-05-23 13:01:10|92d47495c92d8c5dba107163df2bb212_BISSoRxDTvv.ELf|
|[8e74e36ba104389aa6dc4d4429bcf0cf](https://www.virustotal.com/gui/file/8e74e36ba104389aa6dc4d4429bcf0cf)|ELF executable|VPNFilter|2018-05-23 13:01:09|8e74e36ba104389aa6dc4d4429bcf0cf_RNzok.eLf|
|[17e5e5c25eef807a08f02b8e435dda30](https://www.virustotal.com/gui/file/17e5e5c25eef807a08f02b8e435dda30)|ELF executable|VPNFilter|2018-05-23 13:01:07|17e5e5c25eef807a08f02b8e435dda30_aFWNUJxpslPwUahmRCfgNu.ElF|
|[19dd8b95fcca498582642f5a0b2fc58b](https://www.virustotal.com/gui/file/19dd8b95fcca498582642f5a0b2fc58b)|ELF executable|VPNFilter|2018-05-23 13:01:06|19dd8b95fcca498582642f5a0b2fc58b_SuFBPcYKdwtfTYNkV.Elf|
|[93ff367439becebd9d71c3e12041c95e](https://www.virustotal.com/gui/file/93ff367439becebd9d71c3e12041c95e)|ELF executable|VPNFilter|2018-05-23 13:01:04|93ff367439becebd9d71c3e12041c95e_qxOKihQtzfAtsRyEIOoovHJ.eLf|
|[d8a4b6ecc209e73ba61cb505f9b0308d](https://www.virustotal.com/gui/file/d8a4b6ecc209e73ba61cb505f9b0308d)|Win32 EXE|Delf|2018-05-23 04:42:19|audev.exe|
|[a3bfff6e6b963708c4c87cf9ba3a1a87](https://www.virustotal.com/gui/file/a3bfff6e6b963708c4c87cf9ba3a1a87)|Win32 EXE|occamy|2018-05-22 15:14:02|cannon.exe|
|[3ae56ce55e11d43b0c7eaef2607b43f1](https://www.virustotal.com/gui/file/3ae56ce55e11d43b0c7eaef2607b43f1)|Win32 EXE|Delf|2018-05-22 09:50:32|wnssl.exe|
|[9ef7914ad1784cb42b904a15496deccc](https://www.virustotal.com/gui/file/9ef7914ad1784cb42b904a15496deccc)|Win32 EXE||2018-05-22 03:34:28|wmssl.exe|
|[3be1ef5134acf27938d2781359588290](https://www.virustotal.com/gui/file/3be1ef5134acf27938d2781359588290)|Win32 EXE|sednit|2018-05-16 04:42:41|myfile.exe|
|[5086989639aed17227b8d6b041ef3163](https://www.virustotal.com/gui/file/5086989639aed17227b8d6b041ef3163)|Win64 EXE||2018-05-11 10:19:30|myfile.exe|
|[77d4cc390e8bb7e2b5ccfd92efd3dd83](https://www.virustotal.com/gui/file/77d4cc390e8bb7e2b5ccfd92efd3dd83)|Win32 EXE|Banload|2018-04-25 05:56:34|77d4cc390e8bb7e2b5ccfd92efd3dd83.virus|
|[093bb6db11b0b934678feeb8fdd10bd4](https://www.virustotal.com/gui/file/093bb6db11b0b934678feeb8fdd10bd4)|Win32 EXE|MSILPerseus|2018-04-18 11:22:16|cannon.exe|
|[21834a5bb7ec4bf017a3ef74cf6781b9](https://www.virustotal.com/gui/file/21834a5bb7ec4bf017a3ef74cf6781b9)|Win32 EXE|skeeyah|2018-03-29 09:06:25|21834a5bb7ec4bf017a3ef74cf6781b9.virus|
|[6c6cdb4aa5e7c19eeda01196d0717038](https://www.virustotal.com/gui/file/6c6cdb4aa5e7c19eeda01196d0717038)|Win32 EXE||2018-03-20 10:18:16|6c6cdb4aa5e7c19eeda01196d0717038.virus|
|[92b90b0208805daaa8ab45fa19d36b14](https://www.virustotal.com/gui/file/92b90b0208805daaa8ab45fa19d36b14)|Win32 EXE|Zbot|2018-03-19 14:21:33|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28wmsApplication.exe|
|[f1df1a795eb784f7bfc3ba9a7e3b00ac](https://www.virustotal.com/gui/file/f1df1a795eb784f7bfc3ba9a7e3b00ac)|Win32 DLL||2018-03-14 10:08:16|myfile.exe|
|[6eaa1ff5f33df3169c209f98cc5012d0](https://www.virustotal.com/gui/file/6eaa1ff5f33df3169c209f98cc5012d0)|Win32 EXE||2018-03-14 10:07:17|myfile.exe|
|[87d7c3096ae4167a19c10d0d204c4609](https://www.virustotal.com/gui/file/87d7c3096ae4167a19c10d0d204c4609)|DOCX||2018-03-14 09:26:44|decoded.docx|
|[96a4208c6ae2bc1a4150ce9941c45ba6](https://www.virustotal.com/gui/file/96a4208c6ae2bc1a4150ce9941c45ba6)|Win32 EXE||2018-03-07 10:02:29|96a4208c6ae2bc1a4150ce9941c45ba6.virus|
|[96881c6d57497341cd7d8632dfbd8a8b](https://www.virustotal.com/gui/file/96881c6d57497341cd7d8632dfbd8a8b)|Win32 EXE|tspy|2018-03-06 04:31:39|96881c6d57497341cd7d8632dfbd8a8b.virus|
|[e0603d2072002abd1bbc1ad541e34dcf](https://www.virustotal.com/gui/file/e0603d2072002abd1bbc1ad541e34dcf)|Win32 EXE|Delf|2018-03-03 14:09:33|wnwnt.exe|
|[2361181c5d9a15ec3d5249de1985b83d](https://www.virustotal.com/gui/file/2361181c5d9a15ec3d5249de1985b83d)|Text|sednit|2018-03-01 11:04:14|C4V7W9J7.txt|
|[794d18f975f94e3d9b1144c542c7f39b](https://www.virustotal.com/gui/file/794d18f975f94e3d9b1144c542c7f39b)|Win32 EXE|Banload|2018-03-01 06:21:16|myfile.exe|
|[3738934b5aa862fc8d4c3188f36ad280](https://www.virustotal.com/gui/file/3738934b5aa862fc8d4c3188f36ad280)|Win32 EXE|skeeyah|2018-02-27 11:19:20|myfile.exe|
|[f3c6e16f0dd2b0e55a7dad365c3877d4](https://www.virustotal.com/gui/file/f3c6e16f0dd2b0e55a7dad365c3877d4)|Win32 DLL||2018-02-25 12:23:40|f3c6e16f0dd2b0e55a7dad365c3877d4.virus|
|[1d2c706e821076a59dcd38cf37dcf3c6](https://www.virustotal.com/gui/file/1d2c706e821076a59dcd38cf37dcf3c6)|RTF|o97m|2018-02-23 12:04:01|VirusShare_1d2c706e821076a59dcd38cf37dcf3c6|
|[35d2ce0651d8bc045e920c10fd52a178](https://www.virustotal.com/gui/file/35d2ce0651d8bc045e920c10fd52a178)|Win32 EXE||2018-02-23 00:06:45|myfile.exe|
|[6bb7c33879c07d9e97b9f8b62466c1cf](https://www.virustotal.com/gui/file/6bb7c33879c07d9e97b9f8b62466c1cf)|Win32 EXE|autoit|2018-02-22 11:34:45|8ac4e164b463c313af059760ce1f830c19b0d5a280ec80554e8f77939143e24e.bin|
|[8907c97ef307a8ba6cf577498a20c583](https://www.virustotal.com/gui/file/8907c97ef307a8ba6cf577498a20c583)|Win32 EXE||2018-02-22 11:17:39|myfile.exe|
|[cfbe5fad5a8190e93100c78f63a80664](https://www.virustotal.com/gui/file/cfbe5fad5a8190e93100c78f63a80664)|Win32 EXE|Delf|2018-02-22 04:30:26|wnwnet.exe|
|[c590c371200f8896da664168d13011ef](https://www.virustotal.com/gui/file/c590c371200f8896da664168d13011ef)|Win32 EXE||2018-02-21 05:53:55|myfile.exe|
|[953c7321c4959655fdd53302550ce02d](https://www.virustotal.com/gui/file/953c7321c4959655fdd53302550ce02d)|Win64 DLL|sednit|2018-02-20 17:48:52|ccfm.dll|
|[d41474811e5fb5be4d3cc83c5327992a](https://www.virustotal.com/gui/file/d41474811e5fb5be4d3cc83c5327992a)|Win32 EXE||2018-02-14 05:06:44|auddev.exe|
|[7c43b406119ade8f1f2a2a5a93c94248](https://www.virustotal.com/gui/file/7c43b406119ade8f1f2a2a5a93c94248)|Win32 DLL|sednit|2018-02-11 00:45:36|cdnver.dll|
|[ff0e4f31a6b18b676b9518d4a748fed1](https://www.virustotal.com/gui/file/ff0e4f31a6b18b676b9518d4a748fed1)|Win32 EXE|sednit|2018-02-03 00:38:32|ff0e4f31a6b18b676b9518d4a748fed1.virus|
|[aa2cd9d9fc5d196caa6f8fd5979e3f14](https://www.virustotal.com/gui/file/aa2cd9d9fc5d196caa6f8fd5979e3f14)|Win32 DLL|sednit|2018-02-02 12:32:44|cdnver.dll|
|[36524c90ca1fac2102e7653dfadb31b2](https://www.virustotal.com/gui/file/36524c90ca1fac2102e7653dfadb31b2)|Win32 EXE|sednit|2018-02-02 12:32:41|36524c90ca1fac2102e7653dfadb31b2_Win32.SofacyCarberp.exe|
|[56f98e3ed00e48ff9cb89dea5f6e11c1](https://www.virustotal.com/gui/file/56f98e3ed00e48ff9cb89dea5f6e11c1)|XLS||2018-02-02 09:55:47|Upcoming Events February 2018.xls|
|[35eb9e586dfef4b385d4ee13a85e29de](https://www.virustotal.com/gui/file/35eb9e586dfef4b385d4ee13a85e29de)|Win32 EXE||2018-01-24 11:49:29|myfile.exe|
|[87b5f05de6787fae0c48c23e03234502](https://www.virustotal.com/gui/file/87b5f05de6787fae0c48c23e03234502)|Win32 EXE||2018-01-23 19:08:05|myfile.exe|
|[39a400477b3289a9b627c1b7fb4af463](https://www.virustotal.com/gui/file/39a400477b3289a9b627c1b7fb4af463)|Win32 EXE|sednit|2018-01-19 18:15:58|39a400477b3289a9b627c1b7fb4af463.virus|
|[3c1db655039d49b38d3d987c3f8b73b1](https://www.virustotal.com/gui/file/3c1db655039d49b38d3d987c3f8b73b1)|Win32 EXE|Zbot|2018-01-12 22:36:22|srvcrm.exe|
|[8a9a42a9901b80753c12d97ca7bb35af](https://www.virustotal.com/gui/file/8a9a42a9901b80753c12d97ca7bb35af)|Win32 EXE|sednit|2018-01-11 04:25:57|8a9a42a9901b80753c12d97ca7bb35af.virus|
|[2d0cc82b5e5cf025b617d0988db3c4e7](https://www.virustotal.com/gui/file/2d0cc82b5e5cf025b617d0988db3c4e7)|Win32 EXE||2018-01-06 05:01:09|2d0cc82b5e5cf025b617d0988db3c4e7.virus|
|[d41dc335d2106d53b9f478a173e9c778](https://www.virustotal.com/gui/file/d41dc335d2106d53b9f478a173e9c778)|Win32 EXE||2017-12-27 04:23:36|myfile.exe|
|[d806ff313f7b77dd9334852599e5f7fe](https://www.virustotal.com/gui/file/d806ff313f7b77dd9334852599e5f7fe)|Win32 EXE|Banload|2017-12-27 04:22:35|d806ff313f7b77dd9334852599e5f7fe.virus|
|[98d1c9770d92ba42607ac5e98fc7486f](https://www.virustotal.com/gui/file/98d1c9770d92ba42607ac5e98fc7486f)|DOCM|Banload|2017-12-22 07:42:37|98d1c9770d92ba42607ac5e98fc7486f.virus|
|[8fa89f99f96aa694910087cfdc087e18](https://www.virustotal.com/gui/file/8fa89f99f96aa694910087cfdc087e18)|Win32 EXE|Banload|2017-12-19 01:40:08|8fa89f99f96aa694910087cfdc087e18.virus|
|[5b02ee0e44dcd54ee7e4aafafcd5abb0](https://www.virustotal.com/gui/file/5b02ee0e44dcd54ee7e4aafafcd5abb0)|Win32 EXE||2017-12-17 22:39:28|5b02ee0e44dcd54ee7e4aafafcd5abb0.virus|
|[0a2a1c64a70231498f36b56b8253bf85](https://www.virustotal.com/gui/file/0a2a1c64a70231498f36b56b8253bf85)|Win32 EXE|Zbot|2017-12-13 13:00:43|0a2a1c64a70231498f36b56b8253bf85.virus|
|[5c6eca1eeae5cd9157189352fdc8b02c](https://www.virustotal.com/gui/file/5c6eca1eeae5cd9157189352fdc8b02c)|Win64 DLL||2017-11-21 14:33:48|syscheck.dll|
|[6e52b4466cf1dcedf82c8f7463114469](https://www.virustotal.com/gui/file/6e52b4466cf1dcedf82c8f7463114469)|Win32 EXE||2017-11-20 11:31:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28Implant.bin|
|[1535acbcae591b0d03ef7518cb56883e](https://www.virustotal.com/gui/file/1535acbcae591b0d03ef7518cb56883e)|Win32 EXE|sednit|2017-11-19 05:30:04|1535acbcae591b0d03ef7518cb56883e.virus|
|[bf0fea133818387cca7eaef5a52c0aed](https://www.virustotal.com/gui/file/bf0fea133818387cca7eaef5a52c0aed)|Win32 EXE||2017-11-19 04:58:30|snvmse.exe|
|[9a6b771c934415f74a203e0dfab9edbe](https://www.virustotal.com/gui/file/9a6b771c934415f74a203e0dfab9edbe)|PDF||2017-11-15 12:29:37|=?UTF-8?Q?A_Look_Into_Fysbis=5F_Sofacy=E2=80=99s_Linux_Backdoor_=2D_Palo_Alto_Networks_Blog=2Epdf?=|
|[a0a51cbbbcc03c31fb087c5d1933052c](https://www.virustotal.com/gui/file/a0a51cbbbcc03c31fb087c5d1933052c)|Win32 DLL||2017-11-14 01:51:38|/home/virustotal/sample/A0A51CBBBCC03C31FB087C5D1933052C|
|[3aedbf887a3d782e4d4e1e86d563dba1](https://www.virustotal.com/gui/file/3aedbf887a3d782e4d4e1e86d563dba1)|Win32 DLL|sednit|2017-11-14 01:31:21|/home/virustotal/sample/3AEDBF887A3D782E4D4E1E86D563DBA1|
|[2d0860c3d867b2f557bfc568d1e90b4b](https://www.virustotal.com/gui/file/2d0860c3d867b2f557bfc568d1e90b4b)|Win32 EXE||2017-11-08 04:29:10|myfile.exe|
|[2d5a97f6333a2cd71869fd0796d60664](https://www.virustotal.com/gui/file/2d5a97f6333a2cd71869fd0796d60664)|Win64 EXE|sednit|2017-11-07 11:20:08|ctlnet.exe|
|[c834ef2d3e0fe5239b2c97d6d14a4c9b](https://www.virustotal.com/gui/file/c834ef2d3e0fe5239b2c97d6d14a4c9b)|Win32 EXE|strictor|2017-11-07 07:17:52|c834ef2d3e0fe5239b2c97d6d14a4c9b.virus|
|[e4ef63f74d55930157bc425bf3bd856f](https://www.virustotal.com/gui/file/e4ef63f74d55930157bc425bf3bd856f)|DOCM||2017-11-07 07:14:53|6f72632394b89daff89f08488081f782d63c1f01e0033cec693fd5c895965b80.bin|
|[b341e5109f94d13724c7899e9a7662b6](https://www.virustotal.com/gui/file/b341e5109f94d13724c7899e9a7662b6)|Win32 EXE|sednit|2017-11-07 03:58:46|myfile.exe|
|[f391556d9f89499fa8ee757cb3472710](https://www.virustotal.com/gui/file/f391556d9f89499fa8ee757cb3472710)|Win32 EXE||2017-11-05 16:14:14|myfile.exe|
|[bebcc9e6545d7baae13c095b31451e2d](https://www.virustotal.com/gui/file/bebcc9e6545d7baae13c095b31451e2d)|Win32 DLL|sednit|2017-11-05 04:21:03|vms.dll|
|[e0b8c953e3e6c3f133d1d9301e8eb15a](https://www.virustotal.com/gui/file/e0b8c953e3e6c3f133d1d9301e8eb15a)|DOCX||2017-11-04 17:59:18|IsisAttackinNewYork.docx|
|[b88633376fbb144971dcb503f72fd192](https://www.virustotal.com/gui/file/b88633376fbb144971dcb503f72fd192)|Win64 EXE|sednit|2017-11-03 08:08:39|/home/virustotal/sample/B88633376FBB144971DCB503F72FD192|
|[1c6f8eba504f2f429abf362626545c79](https://www.virustotal.com/gui/file/1c6f8eba504f2f429abf362626545c79)|Win32 DLL|sednit|2017-11-02 13:15:30|secnt.dll|
|[34dc9a69f33ba93e631cd5048d9f2624](https://www.virustotal.com/gui/file/34dc9a69f33ba93e631cd5048d9f2624)|DOCX|w2km|2017-11-01 07:08:45|sdoc|
|[cf4b9a62e794e6bdbc193fc360bee132](https://www.virustotal.com/gui/file/cf4b9a62e794e6bdbc193fc360bee132)|Win32 EXE||2017-10-30 23:01:28|cf4b9a62e794e6bdbc193fc360bee132.virus|
|[18afd364d287dfb20921e2c76d4e2c41](https://www.virustotal.com/gui/file/18afd364d287dfb20921e2c76d4e2c41)|Win32 EXE|strictor|2017-10-30 22:50:34|18afd364d287dfb20921e2c76d4e2c41.virus|
|[d89bef3fcf226b02d24e6026f4433944](https://www.virustotal.com/gui/file/d89bef3fcf226b02d24e6026f4433944)|Win32 EXE||2017-10-30 22:48:10|657c83297cfcc5809e89098adf69c206df95aee77bfc1292898bbbe1c44c9dc4.bin|
|[0e21c281a16787f6d96bdc22e7002cc1](https://www.virustotal.com/gui/file/0e21c281a16787f6d96bdc22e7002cc1)|Win32 EXE||2017-10-28 04:23:32|0e21c281a16787f6d96bdc22e7002cc1.virus|
|[fed3f5c6b68a299cf98a2adac4d16bb2](https://www.virustotal.com/gui/file/fed3f5c6b68a299cf98a2adac4d16bb2)|Win32 EXE|sednit|2017-10-27 17:14:19|fed3f5c6b68a299cf98a2adac4d16bb2.virus|
|[b5c9581b169990f94fa54dba19f6ece3](https://www.virustotal.com/gui/file/b5c9581b169990f94fa54dba19f6ece3)|Win32 EXE||2017-10-27 16:48:06|bb9a40db67fab5fcc89f5f90fb7c00f515a997cd46b5be378660017bbbd0b45a.bin|
|[c983f5f9f92734e10d60b30790a1c402](https://www.virustotal.com/gui/file/c983f5f9f92734e10d60b30790a1c402)|Win32 EXE||2017-10-21 00:21:43|c983f5f9f92734e10d60b30790a1c402.virus|
|[c67b2529e266909b0db5df03bd6690a7](https://www.virustotal.com/gui/file/c67b2529e266909b0db5df03bd6690a7)|DOCX||2017-10-20 16:17:20|/home/virustotal/sample/C67B2529E266909B0DB5DF03BD6690A7|
|[02b79c468c38c4312429a499fa4f6c81](https://www.virustotal.com/gui/file/02b79c468c38c4312429a499fa4f6c81)|Win64 DLL|sednit|2017-10-18 13:39:09|ccfm.dll|
|[0e0f7e17b8926d9bfd43a320d703e41b](https://www.virustotal.com/gui/file/0e0f7e17b8926d9bfd43a320d703e41b)|DOCX|o97m|2017-10-18 12:50:03|25f983961eef6751e53a72c96d35448f8b413edf727501d0990f763b8c5e900b.docx|
|[60bc999ff14ee2f359130d6c1375b033](https://www.virustotal.com/gui/file/60bc999ff14ee2f359130d6c1375b033)|Win32 DLL||2017-10-16 10:39:22|E:/data/kbw/new_request/malware/new_request/20171019/60bc999ff14ee2f359130d6c1375b033.vir|
|[94b288154e3d0225f86bb3c012fa8d63](https://www.virustotal.com/gui/file/94b288154e3d0225f86bb3c012fa8d63)|DOC|o97m|2017-10-12 08:36:41|/home/virustotal/sample/94B288154E3D0225F86BB3C012FA8D63|
|[f52ea8f238e57e49bfae304bd656ad98](https://www.virustotal.com/gui/file/f52ea8f238e57e49bfae304bd656ad98)|DOC|o97m|2017-10-11 12:22:15|/home/virustotal/sample/F52EA8F238E57E49BFAE304BD656AD98|
|[085be1b8b8f3e90be00f6a3bcea2879f](https://www.virustotal.com/gui/file/085be1b8b8f3e90be00f6a3bcea2879f)|DOC||2017-10-11 08:28:46|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28DecoyDocument.doc|
|[4c49a17ee2f2dcd8041914110f362cd8](https://www.virustotal.com/gui/file/4c49a17ee2f2dcd8041914110f362cd8)|Win32 EXE||2017-10-08 03:21:33|4c49a17ee2f2dcd8041914110f362cd8.virus|
|[4e95e9293a663e73eb63e24442a855e1](https://www.virustotal.com/gui/file/4e95e9293a663e73eb63e24442a855e1)|Win32 EXE||2017-10-05 17:59:52|4e95e9293a663e73eb63e24442a855e1.virus|
|[fc7d4cde5d2266082966d80f5f1566b9](https://www.virustotal.com/gui/file/fc7d4cde5d2266082966d80f5f1566b9)|Win32 DLL||2017-10-05 05:52:08|netwf.dll|
|[edbce2a1dee0f2adec5c3a75b24ae421](https://www.virustotal.com/gui/file/edbce2a1dee0f2adec5c3a75b24ae421)|Win32 DLL|sednit|2017-09-30 10:57:22|medcon.dll|
|[b094de5e24a5be42836768c524f40590](https://www.virustotal.com/gui/file/b094de5e24a5be42836768c524f40590)|Win32 DLL|sednit|2017-09-30 10:47:20|adruncfm.dll|
|[241631a32a4c26bd83ea17b90ad266c1](https://www.virustotal.com/gui/file/241631a32a4c26bd83ea17b90ad266c1)|Win32 EXE||2017-09-03 10:45:20|myfile.exe|
|[66b4fb539806ce27be184b6735584339](https://www.virustotal.com/gui/file/66b4fb539806ce27be184b6735584339)|Win32 EXE|sednit|2017-08-30 09:39:54|11fab8361a942e46375bd5ac259146fda20608594e265bcc1d3c011ab4c17226.bin|
|[f3309f143cca7954dba2887aadd2b4cb](https://www.virustotal.com/gui/file/f3309f143cca7954dba2887aadd2b4cb)|ELF executable|VPNFilter|2017-08-30 07:06:49|f3309f143cca7954dba2887aadd2b4cb.virus|
|[891df2e692685f809039a8e444fe9daa](https://www.virustotal.com/gui/file/891df2e692685f809039a8e444fe9daa)|Win32 EXE||2017-08-22 11:22:26|mmcsrv.exe|
|[b924ff83d9120d934bb49a7a2e3c4292](https://www.virustotal.com/gui/file/b924ff83d9120d934bb49a7a2e3c4292)|DOCM||2017-07-21 08:34:34|/home/virustotal/sample/B924FF83D9120D934BB49A7A2E3C4292|
|[e00216958f15f1db6371b583a3ea438a](https://www.virustotal.com/gui/file/e00216958f15f1db6371b583a3ea438a)|Win32 EXE||2017-07-20 11:13:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/LoJaxInfo_EFI.exe|
|[cf45ec807321d12f8df35fa434591460](https://www.virustotal.com/gui/file/cf45ec807321d12f8df35fa434591460)|Win32 EXE||2017-07-20 07:30:17|myfile.exe|
|[d6f2bf2066e053e58fe8bcd39cb2e9ad](https://www.virustotal.com/gui/file/d6f2bf2066e053e58fe8bcd39cb2e9ad)|Win32 DLL|sednit|2017-07-18 02:33:35|D:/vt/malware/20170728/d6f2bf2066e053e58fe8bcd39cb2e9ad.vir|
|[1421419d1be31f1f9ea60e8ed87277db](https://www.virustotal.com/gui/file/1421419d1be31f1f9ea60e8ed87277db)|Win32 DLL|sednit|2017-07-17 21:56:47|mvtband.dll|
|[b1d1a2c64474d2f6e7a5db71ccbafa31](https://www.virustotal.com/gui/file/b1d1a2c64474d2f6e7a5db71ccbafa31)|Win32 DLL|sednit|2017-07-17 21:56:43|/home/virustotal/sample/B1D1A2C64474D2F6E7A5DB71CCBAFA31|
|[583ea25b69feded9f65cfbff169147a9](https://www.virustotal.com/gui/file/583ea25b69feded9f65cfbff169147a9)|Text||2017-07-17 21:56:40|mrset.bat|
|[9b10685b774a783eabfecdb6119a8aa3](https://www.virustotal.com/gui/file/9b10685b774a783eabfecdb6119a8aa3)|DOCM||2017-07-17 16:40:10|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28Hospital.doc|
|[aa34fb2e5849bff4144a1c98a8158970](https://www.virustotal.com/gui/file/aa34fb2e5849bff4144a1c98a8158970)|Win32 DLL||2017-07-17 12:30:58|/home/virustotal/sample/AA34FB2E5849BFF4144A1C98A8158970|
|[5b3968b47eb16a1cb88525e3b565eab1](https://www.virustotal.com/gui/file/5b3968b47eb16a1cb88525e3b565eab1)|Win32 EXE||2017-07-17 08:28:52|cuinfo.exe|
|[aced5525ba0d4f44ffd01c4db2730a34](https://www.virustotal.com/gui/file/aced5525ba0d4f44ffd01c4db2730a34)|Win32 DLL||2017-07-13 13:54:42|imxtray.dll|
|[d4a5d44184333442f5015699c2b8af28](https://www.virustotal.com/gui/file/d4a5d44184333442f5015699c2b8af28)|Win64 DLL|sednit|2017-07-13 13:52:06|mmdivx.dll|
|[dd5e31f9d323e6c3e09e367e6bd0e7b1](https://www.virustotal.com/gui/file/dd5e31f9d323e6c3e09e367e6bd0e7b1)|PDF||2017-06-14 01:52:33|Bears in the Midst_ Intrusion into the Democratic National Committee _pdf|
|[5f358afee76f2a74b1a3443c6012b27b](https://www.virustotal.com/gui/file/5f358afee76f2a74b1a3443c6012b27b)|ELF executable|VPNFilter|2017-06-12 09:22:52|5f358afee76f2a74b1a3443c6012b27b_YCutsSLdOPNCzGxzUXqaP.ElF|
|[c64e34730407875418ab5278a17b5ec4](https://www.virustotal.com/gui/file/c64e34730407875418ab5278a17b5ec4)|Win32 EXE|sednit|2017-06-04 14:37:06| |
|[b1b88f78c2f4393d437da4ce743ac5e8](https://www.virustotal.com/gui/file/b1b88f78c2f4393d437da4ce743ac5e8)|PDF||2017-05-18 03:47:41|C:\2malware\other_malware\pdf\Tunnel of Gov_ DNC Hack and the Russian XTunnel _ Invincea.pdf|
|[2163a33330ae5786d3e984db09b2d9d2](https://www.virustotal.com/gui/file/2163a33330ae5786d3e984db09b2d9d2)|Win32 DLL||2017-05-10 07:29:06|apisecconnect.dll|
|[88009adca35560810ec220544e4fb6aa](https://www.virustotal.com/gui/file/88009adca35560810ec220544e4fb6aa)|Win32 DLL||2017-04-26 18:43:38|/home/virustotal/sample/88009ADCA35560810EC220544E4FB6AA|
|[6e0a03df72b4a30d4e1a2366c74902e0](https://www.virustotal.com/gui/file/6e0a03df72b4a30d4e1a2366c74902e0)|Win32 DLL||2017-04-26 18:43:28|joiner.dll|
|[277eb7762dcad112604ae2a0b55719a8](https://www.virustotal.com/gui/file/277eb7762dcad112604ae2a0b55719a8)|Win32 EXE||2017-04-23 17:19:42|277eb7762dcad112604ae2a0b55719a8.virus|
|[b137c809e3bf11f2f5d867a6f4215f95](https://www.virustotal.com/gui/file/b137c809e3bf11f2f5d867a6f4215f95)|PS|o97m|2017-04-18 16:56:32|myvtfile.exe|
|[f8e92d8b5488ea76c40601c8f1a08790](https://www.virustotal.com/gui/file/f8e92d8b5488ea76c40601c8f1a08790)|DOCX|o97m|2017-04-18 13:41:44|VirusShare_f8e92d8b5488ea76c40601c8f1a08790|
|[cdb58c2999eeda58a9d0c70f910d1195](https://www.virustotal.com/gui/file/cdb58c2999eeda58a9d0c70f910d1195)|Win32 DLL|zapchast|2017-04-12 06:04:15|/home/virustotal/sample/CDB58C2999EEDA58A9D0C70F910D1195|
|[10036063be45f92a9a743425fbf5abc7](https://www.virustotal.com/gui/file/10036063be45f92a9a743425fbf5abc7)|Win32 DLL||2017-03-21 11:37:05|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/LoJaxSmall_AgentDLL.exe|
|[595aff5212df3534fb8af6a587c6038e](https://www.virustotal.com/gui/file/595aff5212df3534fb8af6a587c6038e)|Win32 EXE||2017-03-21 11:35:09|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/LoJaxSmallAgent.exe|
|[a24d2f5258f8a0c3bddd1b5636b0ec57](https://www.virustotal.com/gui/file/a24d2f5258f8a0c3bddd1b5636b0ec57)|RTF||2017-02-21 14:01:01|D0AA4F3229FCD9A57E9E4F08860F3CC48C983ADDml.rtf|
|[4fe4b9560e99e33dabca553e2eeee510](https://www.virustotal.com/gui/file/4fe4b9560e99e33dabca553e2eeee510)|Mach-O executable||2017-02-08 19:01:00|4fe4b9560e99e33dabca553e2eeee510_70A1C4ED3A09A44A41D54C4FD4B409A5FC3159F6_XAgent_OSX|
|[a7b4e01335aac544a12c6f88aab80cd9](https://www.virustotal.com/gui/file/a7b4e01335aac544a12c6f88aab80cd9)|PDF||2017-01-30 14:55:04|eset-sednit-part3.pdf|
|[e228cd74103dc069663bb87d4f22d7d5](https://www.virustotal.com/gui/file/e228cd74103dc069663bb87d4f22d7d5)|DOCX||2017-01-30 11:10:42|/home/virustotal/sample/E228CD74103DC069663BB87D4F22D7D5|
|[62deab0e5d61d6bf9e0ba83d9e1d7e2b](https://www.virustotal.com/gui/file/62deab0e5d61d6bf9e0ba83d9e1d7e2b)|RTF||2016-12-27 15:07:07|/home/virustotal/sample/62DEAB0E5D61D6BF9E0BA83D9E1D7E2B|
|[f6b2ef4daf1b78802548d3e6d4de7ba7](https://www.virustotal.com/gui/file/f6b2ef4daf1b78802548d3e6d4de7ba7)|RTF||2016-12-27 14:45:12|/home/virustotal/sample/F6B2EF4DAF1B78802548D3E6D4DE7BA7|
|[2d146419c08c20e9fa35a7e7abf955b0](https://www.virustotal.com/gui/file/2d146419c08c20e9fa35a7e7abf955b0)|DOCX||2016-12-27 13:51:09|/home/virustotal/sample/2D146419C08C20E9FA35A7E7ABF955B0|
|[9fe3a0fb3304d749aeed2c3e2e5787eb](https://www.virustotal.com/gui/file/9fe3a0fb3304d749aeed2c3e2e5787eb)|RTF||2016-12-27 13:07:10|/home/virustotal/sample/9FE3A0FB3304D749AEED2C3E2E5787EB|
|[2f04b8eb993ca4a3d98607824a10acfb](https://www.virustotal.com/gui/file/2f04b8eb993ca4a3d98607824a10acfb)|RTF||2016-12-27 11:37:25|/home/virustotal/sample/2F04B8EB993CA4A3D98607824A10ACFB|
|[4b02dfdfd44df3c88b0ca8c2327843a4](https://www.virustotal.com/gui/file/4b02dfdfd44df3c88b0ca8c2327843a4)|RTF||2016-12-15 15:24:43|/home/virustotal/sample/4B02DFDFD44DF3C88B0CA8C2327843A4|
|[d3b7a382b7343fd394db94fbc8ac3305](https://www.virustotal.com/gui/file/d3b7a382b7343fd394db94fbc8ac3305)|Win32 EXE||2016-12-07 18:15:06|d3b7a382b7343fd394db94fbc8ac3305.virus|
|[5882a8dd4446abd137c05d2451b85fea](https://www.virustotal.com/gui/file/5882a8dd4446abd137c05d2451b85fea)|RTF||2016-12-02 11:13:08|/home/virustotal/sample/5882A8DD4446ABD137C05D2451B85FEA|
|[296c956fe429cedd1b64b78e66797122](https://www.virustotal.com/gui/file/296c956fe429cedd1b64b78e66797122)|RTF||2016-12-02 11:08:54|/home/virustotal/sample/296C956FE429CEDD1B64B78E66797122|
|[8c3f5f1fff999bc783062dd50357be79](https://www.virustotal.com/gui/file/8c3f5f1fff999bc783062dd50357be79)|RTF||2016-12-02 09:16:46|/home/virustotal/sample/8C3F5F1FFF999BC783062DD50357BE79|
|[bed5bc0a8aae2662ea5d2484f80c1760](https://www.virustotal.com/gui/file/bed5bc0a8aae2662ea5d2484f80c1760)|RTF||2016-12-02 08:06:24|/home/virustotal/sample/BED5BC0A8AAE2662EA5D2484F80C1760|
|[82f06d7157dd28a75f1fbb47728aea25](https://www.virustotal.com/gui/file/82f06d7157dd28a75f1fbb47728aea25)|RTF||2016-12-01 14:16:12|/home/virustotal/sample/82F06D7157DD28A75F1FBB47728AEA25|
|[d79a21970cad03e22440ea66bd85931f](https://www.virustotal.com/gui/file/d79a21970cad03e22440ea66bd85931f)|RTF||2016-11-08 02:53:51|/home/virustotal/sample/D79A21970CAD03E22440EA66BD85931F|
|[0b32e65caf653d77cab2a866ee2d9dbc](https://www.virustotal.com/gui/file/0b32e65caf653d77cab2a866ee2d9dbc)|RTF||2016-11-03 10:25:04|/home/virustotal/sample/0B32E65CAF653D77CAB2A866EE2D9DBC|
|[f8c8f6456c5a52ef24aa426e6b121685](https://www.virustotal.com/gui/file/f8c8f6456c5a52ef24aa426e6b121685)|Win64 EXE|sednit|2016-11-03 08:49:26|E:\중요자료\1.졸업작품\악성코드 샘플\samples\no_report\binary|
|[647edddf61954822ddb7ab3341f9a6c5](https://www.virustotal.com/gui/file/647edddf61954822ddb7ab3341f9a6c5)|RTF||2016-11-02 11:38:25|/home/virustotal/sample/647EDDDF61954822DDB7AB3341F9A6C5|
|[27faa10d1bec1a25f66e88645c695016](https://www.virustotal.com/gui/file/27faa10d1bec1a25f66e88645c695016)|RTF||2016-11-02 07:16:06|/home/virustotal/sample/27FAA10D1BEC1A25F66E88645C695016|
|[c789ec7537e300411d523aef74407a5e](https://www.virustotal.com/gui/file/c789ec7537e300411d523aef74407a5e)|RTF||2016-11-01 12:57:22|ais_samples (1964)|
|[7f7aa85afdfa6b6732f00fe26d733086](https://www.virustotal.com/gui/file/7f7aa85afdfa6b6732f00fe26d733086)|RTF||2016-10-31 10:33:08|ais_samples (80)|
|[93c589e9eaf3272bc0349d605b85c566](https://www.virustotal.com/gui/file/93c589e9eaf3272bc0349d605b85c566)|Win32 EXE||2016-10-27 00:58:06|EE788901CD804965F1CD00A0AFC713C8623430C4.exe_|
|[991ffdbf860756a4589164de26dd7ccf](https://www.virustotal.com/gui/file/991ffdbf860756a4589164de26dd7ccf)|Win32 EXE||2016-10-27 00:58:05|E8ACA4B0CFE509783A34FF908287F98CAB968D9E.exe_|
|[607a7401962eaf78b93676c9f5ca6a26](https://www.virustotal.com/gui/file/607a7401962eaf78b93676c9f5ca6a26)|Win32 EXE||2016-10-27 00:57:12|516EC3584073A1C05C0D909B8B6C15ECB10933F1.exe_|
|[23ae20329174d44ebc8dbfa9891c6260](https://www.virustotal.com/gui/file/23ae20329174d44ebc8dbfa9891c6260)|Win32 EXE||2016-10-27 00:57:11|49ACBA812894444C634B034962D46F986E0257CF.exe_|
|[0eefeaf2fb78ebc49e7beba505da273d](https://www.virustotal.com/gui/file/0eefeaf2fb78ebc49e7beba505da273d)|Win32 EXE||2016-10-27 00:56:30|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit A Mysterious Downloader/4C9C7C4FD83EDAF7EC80687A7A957826DE038DD7.exe_|
|[c3c278991ad051fbace1e2f3a4c20998](https://www.virustotal.com/gui/file/c3c278991ad051fbace1e2f3a4c20998)|PDF||2016-10-25 16:33:24|eset-sednit-part-2.pdf|
|[cd1c521b6ae08fc97e3d69f242f00f9e](https://www.virustotal.com/gui/file/cd1c521b6ae08fc97e3d69f242f00f9e)|Win32 EXE||2016-10-25 02:51:49|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/Xtunnel/E945DE27EBFD1BAF8E8D2A81F4FB0D4523D85D6A|
|[404eb3f7554392e85e56aed414db8455](https://www.virustotal.com/gui/file/404eb3f7554392e85e56aed414db8455)|Win32 DLL|ursu|2016-10-25 02:51:48|NvdSac.dll|
|[34651f2df01b956f1989da4b3ea40338](https://www.virustotal.com/gui/file/34651f2df01b956f1989da4b3ea40338)|Win32 EXE||2016-10-25 02:49:30|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/Xtunnel/DB731119FCA496064F8045061033A5976301770D|
|[12a9fff59de1663dec1b45ea2ede22f5](https://www.virustotal.com/gui/file/12a9fff59de1663dec1b45ea2ede22f5)|Win32 DLL|graftor|2016-10-25 02:48:54|msi.dll|
|[672b8d14d1d3e97c24baf69d50937afc](https://www.virustotal.com/gui/file/672b8d14d1d3e97c24baf69d50937afc)|Win32 EXE|kazy|2016-10-25 02:48:50|1c886.bin|
|[4265f6e8cc545b925912867ec8af2f11](https://www.virustotal.com/gui/file/4265f6e8cc545b925912867ec8af2f11)|Win32 DLL|ursu|2016-10-25 02:46:06|NvdSac.dll|
|[9d1a09bb98bf1ee31f390b60b0cf724d](https://www.virustotal.com/gui/file/9d1a09bb98bf1ee31f390b60b0cf724d)|Win32 EXE|Symmi|2016-10-25 02:46:03|Upnphosts.dll|
|[9a66142acfc7739f78c23ab1252db45b](https://www.virustotal.com/gui/file/9a66142acfc7739f78c23ab1252db45b)|Win32 DLL|ursu|2016-10-25 02:46:01|cabview.dll|
|[96ed0a7976e57ae0bb79dcbd67e39743](https://www.virustotal.com/gui/file/96ed0a7976e57ae0bb79dcbd67e39743)|Win32 DLL|ursu|2016-10-25 02:43:44|splm.dll|
|[4ac8d16ff796e825625ad1861546e2e8](https://www.virustotal.com/gui/file/4ac8d16ff796e825625ad1861546e2e8)|Win32 EXE||2016-10-25 02:06:17|1535D85BEE8A9ADB52E8179AF20983FB0558CCB3.exe_|
|[0ebfac6dba63ff8b35cbd374ef33323a](https://www.virustotal.com/gui/file/0ebfac6dba63ff8b35cbd374ef33323a)|Win32 EXE||2016-10-25 02:06:14|D:\work\VT_UPLOADS\982D9241147AAACF795174A9DAB0E645CF56B922|
|[ea726d3e8f6516807366584f3c5b5e2a](https://www.virustotal.com/gui/file/ea726d3e8f6516807366584f3c5b5e2a)|Win32 EXE|Zbot|2016-10-25 02:06:09|D:\work\VT_UPLOADS\499FF777C88AEACBBAA47EDDE183C944AC7E91D2|
|[ae4ded48da0766d237ce2262202c3c96](https://www.virustotal.com/gui/file/ae4ded48da0766d237ce2262202c3c96)|Win32 EXE|dynamer|2016-10-25 02:04:38|D:\work\VT_UPLOADS\42DEE38929A93DFD45C39045708C57DA15D7586C|
|[e766e048bd222cfd2b9cc1bf24125dac](https://www.virustotal.com/gui/file/e766e048bd222cfd2b9cc1bf24125dac)|Win32 EXE||2016-10-25 02:03:46|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/Xtunnel/8F4F0EDD5FB3737914180FF28ED0E9CCA25BF4CC|
|[9ca6ead1384953d787487d399c23cb41](https://www.virustotal.com/gui/file/9ca6ead1384953d787487d399c23cb41)|Win64 DLL||2016-10-25 02:02:59|NvdSac.dll|
|[5363e5cc28687b7dd71f1e257eab2d5d](https://www.virustotal.com/gui/file/5363e5cc28687b7dd71f1e257eab2d5d)|Win32 DLL||2016-10-25 02:02:57|D:\work\VT_UPLOADS\4F895DB287062A4EE1A2C5415900B56E2CF15842|
|[409848dabfd110f4d373dd0a97ff708e](https://www.virustotal.com/gui/file/409848dabfd110f4d373dd0a97ff708e)|Win32 EXE||2016-10-25 02:02:54|NvdSac.dll|
|[8b6d824619e993f74973eedfaf18be78](https://www.virustotal.com/gui/file/8b6d824619e993f74973eedfaf18be78)|Win32 EXE||2016-10-25 02:02:51|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/XAgent-WIN/0F04DAD5194F97BB4F1808DF19196B04B4AEE1B8|
|[20ff290b8393f006eaf4358f09f13e99](https://www.virustotal.com/gui/file/20ff290b8393f006eaf4358f09f13e99)|RTF||2016-10-24 17:44:38|/home/virustotal/sample/20FF290B8393F006EAF4358F09F13E99|
|[bae0221feefb37e6b81f5ca893864743](https://www.virustotal.com/gui/file/bae0221feefb37e6b81f5ca893864743)|PDF||2016-10-20 18:34:12|eset-sednit-part1.pdf|
|[f7ee38ca49cd4ae35824ce5738b6e587](https://www.virustotal.com/gui/file/f7ee38ca49cd4ae35824ce5738b6e587)|Win32 EXE|graftor|2016-10-20 00:56:47|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/6FB3FD8C2580C84314B14510944700144A9E31DF|
|[7b1bfd7c1866040e8f618fe67b93bea5](https://www.virustotal.com/gui/file/7b1bfd7c1866040e8f618fe67b93bea5)|Win32 DLL|graftor|2016-10-20 00:44:24|msdtckrn.dll|
|[f1d3447a2bff56646478b0adb7d0451c](https://www.virustotal.com/gui/file/f1d3447a2bff56646478b0adb7d0451c)|Win32 DLL|sednit|2016-10-20 00:42:41|mgswizap.dll|
|[540e4a7a28ca1514e53c2564993d8d87](https://www.virustotal.com/gui/file/540e4a7a28ca1514e53c2564993d8d87)|Win64 DLL||2016-10-20 00:38:11|browser.dll|
|[291af793767f5c5f2dc9c6d44f1bfb59](https://www.virustotal.com/gui/file/291af793767f5c5f2dc9c6d44f1bfb59)|Win32 DLL|razy|2016-10-20 00:38:10|api-ms-win-downlevel-profile-l1-1-0.dll|
|[dfc836e035cb6c43ce26ed870f61d7e8](https://www.virustotal.com/gui/file/dfc836e035cb6c43ce26ed870f61d7e8)|Mach-O executable|sednit|2016-10-20 00:32:05|D:\work\PART1_SAMPLES\VT_UPLOAD\51E42368639D593D0AE2968BD2849DC20735C071|
|[427218297202d65b755f0fcd60e953ec](https://www.virustotal.com/gui/file/427218297202d65b755f0fcd60e953ec)|Mach-O executable|sednit|2016-10-20 00:20:51|/Users/Shared/dufh|
|[35283c2e60a3cba6734f4f98c443d11f](https://www.virustotal.com/gui/file/35283c2e60a3cba6734f4f98c443d11f)|Mach-O executable||2016-10-20 00:18:53| |
|[3c4de20e464146bec844471867bd1628](https://www.virustotal.com/gui/file/3c4de20e464146bec844471867bd1628)|Win32 DLL|Fareit|2016-10-17 17:34:00|data/bad/8bcac011-ac06-11e6-af10-80e65024849a.file|
|[4400ec9c4732a32149ca58e7c5806178](https://www.virustotal.com/gui/file/4400ec9c4732a32149ca58e7c5806178)|Mach-O executable||2016-09-27 01:45:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/MacOSKomplexFancyBear.bin|
|[f62182cf0ab94b3c97b0261547dfc6cf](https://www.virustotal.com/gui/file/f62182cf0ab94b3c97b0261547dfc6cf)|RTF||2016-09-26 01:58:00|/home/virustotal/sample/F62182CF0AB94B3C97B0261547DFC6CF|
|[504182aaa5575bb38bf584839beb6d51](https://www.virustotal.com/gui/file/504182aaa5575bb38bf584839beb6d51)|RTF||2016-09-22 13:52:11|/home/virustotal/sample/504182AAA5575BB38BF584839BEB6D51|
|[783d1d533ba68b0f71902f8cf357c2f0](https://www.virustotal.com/gui/file/783d1d533ba68b0f71902f8cf357c2f0)|Win32 EXE||2016-09-07 11:17:49|myfile.exe|
|[ede5d82bb6775a9b1659dccb699fadcb](https://www.virustotal.com/gui/file/ede5d82bb6775a9b1659dccb699fadcb)|FPX||2016-08-24 06:54:47|/home/virustotal/sample/EDE5D82BB6775A9B1659DCCB699FADCB|
|[87b22a7f60348def879ac672649d31ca](https://www.virustotal.com/gui/file/87b22a7f60348def879ac672649d31ca)|Win32 DLL|tspy|2016-08-19 15:54:44|/home/virustotal/sample/87B22A7F60348DEF879AC672649D31CA|
|[116d2fc1665ce7524826a624be0ded1c](https://www.virustotal.com/gui/file/116d2fc1665ce7524826a624be0ded1c)|RTF||2016-08-15 11:10:06|/home/virustotal/sample/116D2FC1665CE7524826A624BE0DED1C|
|[e36e061f64536679fe48d2dcdb3ac4e6](https://www.virustotal.com/gui/file/e36e061f64536679fe48d2dcdb3ac4e6)|Mach-O executable||2016-08-11 18:07:19|localfile~.x86|
|[81749e780d27ddd15973d19de77c9007](https://www.virustotal.com/gui/file/81749e780d27ddd15973d19de77c9007)|Mach-O executable||2016-08-11 18:07:17|binder.exe|
|[b09fe828904a38f37b7a6f6933188279](https://www.virustotal.com/gui/file/b09fe828904a38f37b7a6f6933188279)|Mach-O executable|sednit|2016-08-11 14:27:31|kextd|
|[dee4ea5abaa73916909e9b5a64c8b2d5](https://www.virustotal.com/gui/file/dee4ea5abaa73916909e9b5a64c8b2d5)|Mach-O fat binary executable||2016-08-11 14:27:13|dee4ea5abaa73916909e9b5a64c8b2d5.virus|
|[ad44a7c5e18e9958dda66ccfc406cd44](https://www.virustotal.com/gui/file/ad44a7c5e18e9958dda66ccfc406cd44)|Win32 EXE||2016-07-25 14:48:20|ad44a7c5e18e9958dda66ccfc406cd44.None|
|[823dcbd2fca465fabae71098bbb81e1e](https://www.virustotal.com/gui/file/823dcbd2fca465fabae71098bbb81e1e)|Mach-O dynamic link library||2016-07-12 13:18:54| |
|[6f7523d3019fa190499f327211e01fcb](https://www.virustotal.com/gui/file/6f7523d3019fa190499f327211e01fcb)|Android||2016-06-23 12:51:01|android.apk|
|[cc9e6578a47182a941a478b276320e06](https://www.virustotal.com/gui/file/cc9e6578a47182a941a478b276320e06)|Win64 DLL|sednit|2016-06-21 17:10:37|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/twain_64DLL.dll|
|[9e7053a4b6c9081220a694ec93211b4e](https://www.virustotal.com/gui/file/9e7053a4b6c9081220a694ec93211b4e)|Win64 EXE||2016-06-21 17:08:23|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/Backdoor.XTunnel.exe|
|[19172b9210295518ca52e93a29cfe8f4](https://www.virustotal.com/gui/file/19172b9210295518ca52e93a29cfe8f4)|Win64 EXE|dynamer|2016-06-21 17:07:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/DNC/VmUpgradeHelper.exeImplant.exe|
|[21d63e99ed7dcd8baec74e6ce65c9ef3](https://www.virustotal.com/gui/file/21d63e99ed7dcd8baec74e6ce65c9ef3)|Win32 DLL|razy|2016-06-17 13:57:18|iprpp.dll|
|[1219318522fa28252368f58f36820ac2](https://www.virustotal.com/gui/file/1219318522fa28252368f58f36820ac2)|Win32 DLL||2016-06-17 13:53:26|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/C345A85C01360F2833752A253A5094FF421FC839|
|[3f44a0f1d746cb99ab0321e73133ecae](https://www.virustotal.com/gui/file/3f44a0f1d746cb99ab0321e73133ecae)|RTF|CVE-2015-1641|2016-06-08 20:33:28|12572c2fc2b0298ffd4305ca532317dc8b97ddfd0a05671066fe594997ec38f5.bin|
|[97444b5209278ed611e6a94076e814c8](https://www.virustotal.com/gui/file/97444b5209278ed611e6a94076e814c8)|ELF executable|VPNFilter|2016-06-06 09:46:51|97444b5209278ed611e6a94076e814c8_ObjjcxTng.ELf|
|[c2988e3e4f70d5901b234ff1c1363dcc](https://www.virustotal.com/gui/file/c2988e3e4f70d5901b234ff1c1363dcc)|Win32 DLL|razy|2016-05-30 08:04:57|svchost.dll|
|[7c2b1de614a9664103b6ff7f3d73f83d](https://www.virustotal.com/gui/file/7c2b1de614a9664103b6ff7f3d73f83d)|Win32 DLL|sednit|2016-05-30 06:33:40|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/A43EF43F3C3DB76A4A9CA8F40F7B2C89888F0399|
|[45871bad3a9b4594fc3de39e4b5930ad](https://www.virustotal.com/gui/file/45871bad3a9b4594fc3de39e4b5930ad)|ELF executable|VPNFilter|2016-05-27 12:56:38|45871bad3a9b4594fc3de39e4b5930ad_CUyaJBOQuBwQPV.elF|
|[c13655fee08417cffa04d1bf71af4ad1](https://www.virustotal.com/gui/file/c13655fee08417cffa04d1bf71af4ad1)|RTF|CVE-2015-1641|2016-05-24 12:46:49|03cb76bdc619fac422d2b954adfa511e7ecabc106adce804b1834581b5913bca.bin|
|[356d03f6975f443d6db6c5069d778af9](https://www.virustotal.com/gui/file/356d03f6975f443d6db6c5069d778af9)|Win32 EXE||2016-05-20 06:24:22|356d03f6975f443d6db6c5069d778af9_exe_|
|[ccaa16fbd2eb85dc496ee72ae125c711](https://www.virustotal.com/gui/file/ccaa16fbd2eb85dc496ee72ae125c711)|Win32 EXE|sednit|2016-05-09 07:11:44|ccaa16fbd2eb85dc496ee72ae125c711.virus|
|[a34734b3904ef24909ecc8a6d7a5aece](https://www.virustotal.com/gui/file/a34734b3904ef24909ecc8a6d7a5aece)|Win32 DLL|razy|2016-05-07 08:30:05|a34734b3904ef24909ecc8a6d7a5aece.virus|
|[fd8d1b48f91864dc5acb429a49932ca3](https://www.virustotal.com/gui/file/fd8d1b48f91864dc5acb429a49932ca3)|Win32 DLL|ursu|2016-05-03 16:18:30|syscornt.dll|
|[a2dc261893d9ccb4be571b0ef6b52a40](https://www.virustotal.com/gui/file/a2dc261893d9ccb4be571b0ef6b52a40)|Win32 EXE|Delf|2016-05-01 13:06:14|a2dc261893d9ccb4be571b0ef6b52a40.virus|
|[45fb46519b97acae722192304c804894](https://www.virustotal.com/gui/file/45fb46519b97acae722192304c804894)|Win32 DLL|razy|2016-04-29 23:07:56|clconfig.dll|
|[52c643f21b409ccd6b0d74901de76447](https://www.virustotal.com/gui/file/52c643f21b409ccd6b0d74901de76447)|Win32 DLL||2016-04-27 09:24:11|bitsprx3.dll|
|[bc7d13043fd9cdc65b5e70b1662f40d3](https://www.virustotal.com/gui/file/bc7d13043fd9cdc65b5e70b1662f40d3)|RTF||2016-04-27 04:36:59|1.rtf|
|[8378dd7ed7c15ca5dc3957a09d8db1c1](https://www.virustotal.com/gui/file/8378dd7ed7c15ca5dc3957a09d8db1c1)|Win32 EXE|Banload|2016-04-08 22:39:51|378aaaeaf2dcbaf5e2247b0f94ce8e584cec7645817a4df2e8357d0c7c41fe72.bin|
|[d7c471729bc124babf32945eb5706eb6](https://www.virustotal.com/gui/file/d7c471729bc124babf32945eb5706eb6)|Win64 EXE||2016-04-04 17:41:14|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/10686CC4E46CF3FFBDEB71DD565329A80787C439|
|[113cc4a88fd28ea4398e312093a6a4d5](https://www.virustotal.com/gui/file/113cc4a88fd28ea4398e312093a6a4d5)|Win64 DLL||2016-02-23 21:22:05|mscrypto.dll|
|[e49bce75070a7a3c63a7cebb699342b3](https://www.virustotal.com/gui/file/e49bce75070a7a3c63a7cebb699342b3)|Win32 EXE||2016-02-19 06:06:45|e49bce75070a7a3c63a7cebb699342b3_MS14-070.exe|
|[7a055cbe6672f77b2271c1cb8e2670b8](https://www.virustotal.com/gui/file/7a055cbe6672f77b2271c1cb8e2670b8)|Win32 DLL|ursu|2016-02-16 23:36:27|msi|
|[ba348414fff2f3eafc65fdccdce9336f](https://www.virustotal.com/gui/file/ba348414fff2f3eafc65fdccdce9336f)|Win32 EXE||2016-01-29 09:22:39|ba348414fff2f3eafc65fdccdce9336f.virus|
|[63add4783760ab93833fd3d9f1893899](https://www.virustotal.com/gui/file/63add4783760ab93833fd3d9f1893899)|Win32 EXE||2016-01-01 23:56:34|63add4783760ab93833fd3d9f1893899.virus|
|[ac3e087e43be67bdc674747c665b46c2](https://www.virustotal.com/gui/file/ac3e087e43be67bdc674747c665b46c2)|Win32 EXE||2015-12-22 11:02:08|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/Xtunnel/99B454262DC26B081600E844371982A49D334E5E|
|[1a5d89f6fd3f1ed5f4e76084b0fa7806](https://www.virustotal.com/gui/file/1a5d89f6fd3f1ed5f4e76084b0fa7806)|PDF||2015-12-17 13:07:35|Bitdefender_In-depth_analysis_of_APT28%E2%80%93The_Political_Cyber-Espionage.pdf|
|[7764499bb1c4720d0f1d302f15be792c](https://www.virustotal.com/gui/file/7764499bb1c4720d0f1d302f15be792c)|Win32 DLL||2015-12-16 00:36:54|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/E742B917D3EF41992E67389CD2FE2AAB0F9ACE5B|
|[732fbf0a4ceb10e9a2254af59ae4f880](https://www.virustotal.com/gui/file/732fbf0a4ceb10e9a2254af59ae4f880)|Win32 DLL||2015-12-15 14:42:17|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/C1EAE93785C9CB917CFB260D3ABF6432C6FDAF4D|
|[072c692783c67ea56da9de0a53a60d11](https://www.virustotal.com/gui/file/072c692783c67ea56da9de0a53a60d11)|Win32 DLL||2015-12-15 13:19:58|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/E5FB715A1C70402774EE2C518FB0E4E9CD3FDCFF|
|[e107c5c84ded6cd9391aede7f04d64c8](https://www.virustotal.com/gui/file/e107c5c84ded6cd9391aede7f04d64c8)|ELF executable||2015-12-11 17:20:11|ksysdefe|
|[a0f212fd0f103ca8beaf8362f74903a2](https://www.virustotal.com/gui/file/a0f212fd0f103ca8beaf8362f74903a2)|Win32 EXE||2015-11-28 03:11:09|VirusShare_a0f212fd0f103ca8beaf8362f74903a2|
|[56e011137b9678f1fcc54f9372198bae](https://www.virustotal.com/gui/file/56e011137b9678f1fcc54f9372198bae)|Win32 EXE||2015-11-27 03:25:41|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/2C86A6D6E9915A7F38D119888EDE60B38AB1D69D|
|[9863f1efc5274b3d449b5b7467819d28](https://www.virustotal.com/gui/file/9863f1efc5274b3d449b5b7467819d28)|Win32 DLL||2015-11-27 03:23:56|mgswizap.dll|
|[ed601bbd4dd0e267afb0be840cb27c90](https://www.virustotal.com/gui/file/ed601bbd4dd0e267afb0be840cb27c90)|Win32 DLL||2015-11-27 03:23:39|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/69D8CA2A02241A1F88A525617CF18971C99FB63B|
|[58ca9243d35e529499dd17d27642b419](https://www.virustotal.com/gui/file/58ca9243d35e529499dd17d27642b419)|Win32 EXE||2015-11-12 16:17:57|NvdSac.exe|
|[6ca857721be6fff26b10867c99bd8c80](https://www.virustotal.com/gui/file/6ca857721be6fff26b10867c99bd8c80)|SWF||2015-11-03 12:32:59|2DF498F32D8BAD89D0D6D30275C19127763D5568763D5568.swf_|
|[078755389b98d17788eb5148e23109a6](https://www.virustotal.com/gui/file/078755389b98d17788eb5148e23109a6)|Win32 DLL||2015-11-02 18:02:38|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/XAgent-WIN/C2E8C584D5401952AF4F1DB08CF4B6016874DDAC|
|[dffb22a1a6a757443ab403d61e760f0c](https://www.virustotal.com/gui/file/dffb22a1a6a757443ab403d61e760f0c)|Win32 EXE||2015-10-21 15:24:02|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/3956CFE34566BA8805F9B1FE0D2639606A404CD4|
|[07c8a0a792a5447daf08ac32d1e283e8](https://www.virustotal.com/gui/file/07c8a0a792a5447daf08ac32d1e283e8)|Win32 DLL||2015-10-20 13:14:38|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/99F927F97838EB47C1D59500EE9155ADB55B806A|
|[9227678b90869c5a67a05defcaf21dfb](https://www.virustotal.com/gui/file/9227678b90869c5a67a05defcaf21dfb)|Win32 EXE||2015-10-08 21:45:23|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit A Mysterious Downloader/4F92D364CE871C1AEBBF3C5D2445C296EF535632.exe_|
|[6cd2c953102792b738664d69ce41e080](https://www.virustotal.com/gui/file/6cd2c953102792b738664d69ce41e080)|Win32 DLL||2015-10-05 09:58:02|a13aa88c32eb0200_apisvcd.dll|
|[99b93cfcff258eb49e7af603d779a146](https://www.virustotal.com/gui/file/99b93cfcff258eb49e7af603d779a146)|Win32 DLL||2015-09-25 10:41:44|splm.dll|
|[6159c094a663a171efd531b23a46716d](https://www.virustotal.com/gui/file/6159c094a663a171efd531b23a46716d)|Win32 EXE|graftor|2015-09-25 00:57:12|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/4D5E923351F52A9D5C94EE90E6A00E6FCED733EF|
|[9f82abbaebc1093a187f1887df2cf926](https://www.virustotal.com/gui/file/9f82abbaebc1093a187f1887df2cf926)|Win64 EXE||2015-09-21 20:57:44| |
|[83cf67a5d2e68f9c00fbbe6d7d9203bf](https://www.virustotal.com/gui/file/83cf67a5d2e68f9c00fbbe6d7d9203bf)|Win32 DLL||2015-09-21 18:42:45|msdtckrn.dll|
|[1d1287d4a3ba5d02cca91f51863db738](https://www.virustotal.com/gui/file/1d1287d4a3ba5d02cca91f51863db738)|Win32 EXE|dynamer|2015-09-15 14:04:29|svchost.exe|
|[b2dc7c29cbf8d71d1dd57b474f1e04b9](https://www.virustotal.com/gui/file/b2dc7c29cbf8d71d1dd57b474f1e04b9)|Win32 EXE|razy|2015-09-09 22:33:39|m64hux.exe|
|[8c4d896957c36ec4abeb07b2802268b9](https://www.virustotal.com/gui/file/8c4d896957c36ec4abeb07b2802268b9)|Win32 DLL||2015-08-26 15:43:38|/home/virustotal/sample/8C4D896957C36EC4ABEB07B2802268B9|
|[ce8b99df8642c065b6af43fde1f786a3](https://www.virustotal.com/gui/file/ce8b99df8642c065b6af43fde1f786a3)|Win32 DLL|sednit|2015-08-26 15:41:46|/home/vega/CONTAGIO/apt/APT28/APT28_2015-12_Kaspersky_Sofacy APT hits high profile targets/C78FCAE030A66F388BF8CEA569422F5A79B7B96C_tmpdt.tmp__|
|[30cda69cf82637dfa2ffdc803bf2aead](https://www.virustotal.com/gui/file/30cda69cf82637dfa2ffdc803bf2aead)|Win32 DLL|graftor|2015-08-19 01:07:03| |
|[2dfc90375a09459033d430d046216d22](https://www.virustotal.com/gui/file/2dfc90375a09459033d430d046216d22)|Win32 DLL|razy|2015-08-17 09:48:40|api-ms-win-downlevel-profile-l1-1-0.dll|
|[18efc091b431c39d3e59be445429a7bc](https://www.virustotal.com/gui/file/18efc091b431c39d3e59be445429a7bc)|Win32 DLL|razy|2015-08-05 01:36:41|api-ms-win-downlevel-profile-l1-1-0.dll|
|[77089c094c0f2c15898ff0f021945148](https://www.virustotal.com/gui/file/77089c094c0f2c15898ff0f021945148)|Win32 EXE||2015-08-05 00:53:02|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/F3D50C1F7D5F322C1A1F9A72FF122CAC990881EE|
|[effd7b2411975447fd36603445b380c7](https://www.virustotal.com/gui/file/effd7b2411975447fd36603445b380c7)|Win32 DLL|ursu|2015-08-04 04:48:58|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/XAgent-WIN/780AA72F0397CB6C2A78536201BD9DB4818FA02A|
|[c2a0344a2bbb29d9b56d378386afcbed](https://www.virustotal.com/gui/file/c2a0344a2bbb29d9b56d378386afcbed)|Win32 EXE||2015-08-03 17:37:25|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/015425010BD4CF9D511F7FCD0FC17FC17C23EEC1|
|[a96f4b8ac7aa9dbf4624424b7602d4f7](https://www.virustotal.com/gui/file/a96f4b8ac7aa9dbf4624424b7602d4f7)|Win64 DLL||2015-08-01 01:16:55|advstorshell.dll|
|[c6a80316ea97218df11e11125337233a](https://www.virustotal.com/gui/file/c6a80316ea97218df11e11125337233a)|Win32 EXE|dynamer|2015-07-31 17:35:16|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/4FAE67D3988DA117608A7548D9029CADDBFB3EBF|
|[d535c3fc5f0f98e021bea0d6277d2559](https://www.virustotal.com/gui/file/d535c3fc5f0f98e021bea0d6277d2559)|Win32 DLL|razy|2015-07-29 12:17:50|api-ms-win-downlevel-profile-l1-1-0.dll|
|[c4ffab85d84b494e1c450819a0e9c7db](https://www.virustotal.com/gui/file/c4ffab85d84b494e1c450819a0e9c7db)|Win32 DLL|Symmi|2015-07-28 11:52:41|api-ms-win-downlevel-profile-l1-1-0.dll|
|[eda061c497ba73441994a30e36f55b1d](https://www.virustotal.com/gui/file/eda061c497ba73441994a30e36f55b1d)|Win32 EXE||2015-07-28 07:08:12|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/B7788AF2EF073D7B3FB84086496896E7404E625E|
|[78450806e56b1f224d00455efcd04ce3](https://www.virustotal.com/gui/file/78450806e56b1f224d00455efcd04ce3)|Win32 EXE||2015-07-28 07:06:35|CB796F2986700DF9CE7D8F8D7A3F47F2EB4DF682_xp.exe_APT28|
|[f686304cff9b35ea0d7647820ab525ba](https://www.virustotal.com/gui/file/f686304cff9b35ea0d7647820ab525ba)|Win64 EXE|sednit|2015-07-25 01:17:46| |
|[8b238931a7f64fddcad3057a96855f6c](https://www.virustotal.com/gui/file/8b238931a7f64fddcad3057a96855f6c)|Win32 DLL||2015-07-22 06:57:03|/home/virustotal/sample/8B238931A7F64FDDCAD3057A96855F6C|
|[57cc08213ab8b6d4a538e4568d00a123](https://www.virustotal.com/gui/file/57cc08213ab8b6d4a538e4568d00a123)|Win32 DLL||2015-07-22 06:42:22|msi.dll|
|[ce151285e8f0e7b2b90162ba171a4b90](https://www.virustotal.com/gui/file/ce151285e8f0e7b2b90162ba171a4b90)|Win32 DLL||2015-07-22 06:20:28|/home/virustotal/sample/CE151285E8F0E7B2B90162BA171A4B90|
|[acf8cda38b0d1b6a0d3664a0e33deb96](https://www.virustotal.com/gui/file/acf8cda38b0d1b6a0d3664a0e33deb96)|Win32 DLL||2015-07-20 14:56:59|credssp.dll|
|[5e93cf87040cf225ab5b5b9f9f0a0d03](https://www.virustotal.com/gui/file/5e93cf87040cf225ab5b5b9f9f0a0d03)|Win32 EXE|Zbot|2015-07-18 01:12:43| |
|[dcf6906a9a0c970bcd93f451b9b7932a](https://www.virustotal.com/gui/file/dcf6906a9a0c970bcd93f451b9b7932a)|Win32 DLL||2015-07-13 06:01:53|api-ms-win-downlevel-profile-l1-1-0.dll|
|[973e0c922eb07aad530d8a1de19c7755](https://www.virustotal.com/gui/file/973e0c922eb07aad530d8a1de19c7755)|Win32 EXE||2015-07-12 17:21:34|/home/vega/CONTAGIO/apt/APT28/APT28_2015-07_ESET_Sednit_meet_Hacking/51B0E3CD6360D50424BF776B3CD673DD45FD0F97.exe_|
|[211b7100fd799e9eaabeb13cfa446231](https://www.virustotal.com/gui/file/211b7100fd799e9eaabeb13cfa446231)|Win32 DLL|tspy|2015-07-11 16:50:21|api-ms-win-downlevel-profile-l1-1-0.dll|
|[afe09fb5a2b97f9e119f70292092604e](https://www.virustotal.com/gui/file/afe09fb5a2b97f9e119f70292092604e)|Win32 EXE||2015-07-11 16:45:44|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/B4A515EF9DE037F18D96B9B0E48271180F5725B7|
|[557f8d4c6f8b386c32001def807dc715](https://www.virustotal.com/gui/file/557f8d4c6f8b386c32001def807dc715)|SWF||2015-07-10 11:55:06|D43FD6579AB8B9C40524CC8E4B7BD05BE6674F6C_warfsgfdydcikf.mkv.swf_|
|[c0d1762561f8c2f812d868a3939d23f0](https://www.virustotal.com/gui/file/c0d1762561f8c2f812d868a3939d23f0)|Win32 DLL|Symmi|2015-07-06 05:35:40|browser.dll|
|[6a24be8f61bcd789622dc55ebb7db90b](https://www.virustotal.com/gui/file/6a24be8f61bcd789622dc55ebb7db90b)|Win64 EXE||2015-07-02 01:05:21|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Observing the Comings and Goings/Sedreco-dropper/E034E0D9AD069BAB5A6E68C1517C15665ABE67C9|
|[112c64f7c07a959a1cbff6621850a4ad](https://www.virustotal.com/gui/file/112c64f7c07a959a1cbff6621850a4ad)|RTF||2015-06-30 10:44:29|9e5fbd79d8febe7a162cd5200041772db60dc83244605b1ff37ef8d14334f512.bin|
|[9422ca55f7fca4449259d8878ede5e47](https://www.virustotal.com/gui/file/9422ca55f7fca4449259d8878ede5e47)|Win32 DLL|Zbot|2015-06-29 09:23:22|advstorshell.dll|
|[5e70a5c47c6b59dae7faf0f2d62b28b3](https://www.virustotal.com/gui/file/5e70a5c47c6b59dae7faf0f2d62b28b3)|Win32 EXE|dynamer|2015-06-25 08:56:06|myfile.exe|
|[9617f3948b1886ebc95689c02d2cf264](https://www.virustotal.com/gui/file/9617f3948b1886ebc95689c02d2cf264)|Win32 EXE|ursu|2015-06-24 01:11:30|m:\dailytesters\vl\4\488119A49CC518A27A7A506A2C085CEB\378ef276eeaa4a29dab46d114710fc14ba0a9f964f6d949bcbc5ed3267579892.exe|
|[75f71713a429589e87cf2656107d2bfc](https://www.virustotal.com/gui/file/75f71713a429589e87cf2656107d2bfc)|Win32 DLL|Symmi|2015-06-04 11:19:01|browser.dll|
|[0c334645a4c12513020aaabc3b78ef9f](https://www.virustotal.com/gui/file/0c334645a4c12513020aaabc3b78ef9f)|Win32 EXE|graftor|2015-05-30 10:04:22|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/A857BCCF4CC5C15B60667ECD865112999E1E56BA|
|[a579d53a1d29684de6d2c0cbabd525c5](https://www.virustotal.com/gui/file/a579d53a1d29684de6d2c0cbabd525c5)|Win32 EXE|graftor|2015-05-24 18:11:24|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/17661A04B4B150A6F70AFDABE3FD9839CC56BEE8|
|[0369620eb139c3875a62e36bb7abdae8](https://www.virustotal.com/gui/file/0369620eb139c3875a62e36bb7abdae8)|Win32 EXE||2015-05-20 11:43:21|msdeltemp.dll|
|[a3c757af9e7a9a60e235d08d54740fbc](https://www.virustotal.com/gui/file/a3c757af9e7a9a60e235d08d54740fbc)|Win32 DLL|Zbot|2015-04-30 01:10:50|credssp.dll|
|[8b031fce1d0c38d6b4c68d52b2764c7e](https://www.virustotal.com/gui/file/8b031fce1d0c38d6b4c68d52b2764c7e)|Win64 EXE||2015-04-09 16:29:07|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit Approaching the Target/D9989A46D590EBC792F14AA6FEC30560DFE931B1|
|[2d4eaa0331abbc6d867f5f979b2c890d](https://www.virustotal.com/gui/file/2d4eaa0331abbc6d867f5f979b2c890d)|Win32 EXE||2015-04-09 14:03:32|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/63D1D33E7418DAF200DC4660FC9A59492DDD50D9|
|[ac75fd7d79e64384b9c4053b37e5623f](https://www.virustotal.com/gui/file/ac75fd7d79e64384b9c4053b37e5623f)|Win32 DLL|Zbot|2015-04-09 11:18:11|credssp.dll|
|[91381cd82cdd5f52bbc7b30d34cb8d83](https://www.virustotal.com/gui/file/91381cd82cdd5f52bbc7b30d34cb8d83)|Win32 EXE||2015-04-09 07:08:49|/home/vega/CONTAGIO/apt/APT28/APT28_2015-09_SFecure_Sofacy-recycles-carberp-and-metasploit-code/Droppers/B8AABE12502F7D55AE332905ACEE80A10E3BC399|
|[075b6695ab63f36af65f7ffd45cccd39](https://www.virustotal.com/gui/file/075b6695ab63f36af65f7ffd45cccd39)|ELF executable||2015-02-25 19:57:02|ksysdefd|
|[c3ae4a37094ecfe95c2badecf40bf5bb](https://www.virustotal.com/gui/file/c3ae4a37094ecfe95c2badecf40bf5bb)|Win32 EXE||2015-02-17 19:51:51|myfile.exe|
|[f6f88caf49a3e32174387cacfa144a89](https://www.virustotal.com/gui/file/f6f88caf49a3e32174387cacfa144a89)|Win32 DLL||2015-02-17 19:50:41|/home/virustotal/sample/F6F88CAF49A3E32174387CACFA144A89|
|[da2a657dc69d7320f2ffc87013f257ad](https://www.virustotal.com/gui/file/da2a657dc69d7320f2ffc87013f257ad)|Win32 DLL||2014-11-03 06:49:47|coreshell.dll|
|[ce254486b02be740488c0ab3278956fd](https://www.virustotal.com/gui/file/ce254486b02be740488c0ab3278956fd)|PDF||2014-10-29 00:12:09|wp-operation-pawn-storm.pdf|
|[60e84516c6ec6dfdae7b422d1f7cab06](https://www.virustotal.com/gui/file/60e84516c6ec6dfdae7b422d1f7cab06)|Win64 EXE||2014-10-13 11:50:36|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/LoJaxKernelDriver.bin|
|[800af1c9d341b846a856a1e686be6a3e](https://www.virustotal.com/gui/file/800af1c9d341b846a856a1e686be6a3e)|Win32 DLL||2014-10-07 12:01:29|myfile.exe|
|[df895e6479abf85c4c65d7d3a2451ddb](https://www.virustotal.com/gui/file/df895e6479abf85c4c65d7d3a2451ddb)|Win32 EXE||2014-10-05 09:06:14|DF895E6479ABF85C4C65D7D3A2451DDB.virus|
|[ee64d3273f9b4d80020c24edcbbf961e](https://www.virustotal.com/gui/file/ee64d3273f9b4d80020c24edcbbf961e)|Win32 DLL||2014-10-05 08:33:08|splm.dll|
|[48656a93f9ba39410763a2196aabc67f](https://www.virustotal.com/gui/file/48656a93f9ba39410763a2196aabc67f)|Win32 DLL||2014-09-22 08:35:11|coreshell.dll|
|[364ff454dcf00420cff13a57bcb78467](https://www.virustotal.com/gui/file/364ff454dcf00420cff13a57bcb78467)|ELF executable||2014-09-12 06:25:41|364ff454dcf00420cff13a57bcb78467_EVTsEAmwXGjX.exe|
|[388594cd1bef96121be291880b22041a](https://www.virustotal.com/gui/file/388594cd1bef96121be291880b22041a)|DOC||2014-09-09 22:39:41|DAE7FAA1725DB8192AD711D759B13F8195A18821_Case6_MH17.doc_decoy|
|[d3de5b8500453107d6d152b3c8506935](https://www.virustotal.com/gui/file/d3de5b8500453107d6d152b3c8506935)|unknown|CVE-2012-0158|2014-09-09 21:47:01|33EEC0D1AE550FB33874EDCE0138F485538BB21B__.mht_|
|[bebb3675cfa4adaba7822cc8c39f55bf](https://www.virustotal.com/gui/file/bebb3675cfa4adaba7822cc8c39f55bf)|FPX||2014-09-09 03:20:05|B3098F99DB1F80E27AEC0C9A5A625AEDAAB5899A_APEC Media list 2013 Part2.xls_decoy|
|[77aa465744061b4b725f73848aebdff6](https://www.virustotal.com/gui/file/77aa465744061b4b725f73848aebdff6)|DOC||2014-09-08 06:45:44|/home/virustotal/sample/77AA465744061B4B725F73848AEBDFF6|
|[76d3eb8c2bed4f2588e22b8d0984af86](https://www.virustotal.com/gui/file/76d3eb8c2bed4f2588e22b8d0984af86)|PDF||2014-09-08 05:34:38|6ADA11C71A5176A82A8898680ED1EAA4E79B9BC3_Case1_Letter to IAEA.pdf_decoy|
|[d7a625779df56d874871bb632f3e3106](https://www.virustotal.com/gui/file/d7a625779df56d874871bb632f3e3106)|Win32 DLL|tspy|2014-09-03 19:13:44|advstorshell.dll|
|[8c4fa713c5e2b009114adda758adc445](https://www.virustotal.com/gui/file/8c4fa713c5e2b009114adda758adc445)|Win32 DLL||2014-08-04 22:28:09|coreshell.dll|
|[16a6c56ba458ec718b4e9bc8f9f10785](https://www.virustotal.com/gui/file/16a6c56ba458ec718b4e9bc8f9f10785)|Win32 DLL|Symmi|2014-08-04 21:27:17|/home/virustotal/sample/16A6C56BA458EC718B4E9BC8F9F10785|
|[ead4ec18ebce6890d20757bb9f5285b1](https://www.virustotal.com/gui/file/ead4ec18ebce6890d20757bb9f5285b1)|Win32 DLL||2014-08-01 18:47:20|coreshell.dll|
|[a24552843b9fedd7d0084e1eb1dd6e35](https://www.virustotal.com/gui/file/a24552843b9fedd7d0084e1eb1dd6e35)|Win32 DLL||2014-07-20 22:58:18|NetIds.dll|
|[791428601ad12b9230b9ace4f2138713](https://www.virustotal.com/gui/file/791428601ad12b9230b9ace4f2138713)|Win32 DLL||2014-06-19 09:01:38|coreshell.dll|
|[5882fda97fdf78b47081cc4105d44f7c](https://www.virustotal.com/gui/file/5882fda97fdf78b47081cc4105d44f7c)|Win32 DLL||2014-06-19 09:01:30|coreshell.dll|
|[3b0ecd011500f61237c205834db0e13a](https://www.virustotal.com/gui/file/3b0ecd011500f61237c205834db0e13a)|Win32 DLL||2014-04-22 08:14:10|coreshell.dll|
|[d70f4e9d55698f69c5f63b1a2e1507eb](https://www.virustotal.com/gui/file/d70f4e9d55698f69c5f63b1a2e1507eb)|Win32 DLL|sednit|2014-03-21 21:22:06|/home/vega/CONTAGIO/apt/APT28/APT28_2016-10_ESET_Sednit A Mysterious Downloader/7394EA20C3D510C938EF83A2D0195B767CD99ED7_x32.dll_|
|[9df2ddb2631ff5439c34f80ace40cd29](https://www.virustotal.com/gui/file/9df2ddb2631ff5439c34f80ace40cd29)|Win32 EXE||2014-03-21 21:20:02|f18fe2853ef0d489_bk.exe|
|[8cb08140ddb00ac373d29d37657a03cc](https://www.virustotal.com/gui/file/8cb08140ddb00ac373d29d37657a03cc)|Win32 EXE||2014-03-21 07:55:45|USBGuard.exe|
|[3430bf72d2694e428a73c84d5ac4a4b9](https://www.virustotal.com/gui/file/3430bf72d2694e428a73c84d5ac4a4b9)|Win32 EXE||2014-03-21 06:57:53|9F3AB8779F2B81CAE83F62245AFB124266765939_fsflt.1|
|[c16b07f7590a8620a8f0f687b0bd8bd8](https://www.virustotal.com/gui/file/c16b07f7590a8620a8f0f687b0bd8bd8)|Win32 EXE|Zbot|2014-03-12 19:20:14|/home/virustotal/sample/C16B07F7590A8620A8F0F687B0BD8BD8|
|[1ac15db72e6d4440f0b4f710a516b165](https://www.virustotal.com/gui/file/1ac15db72e6d4440f0b4f710a516b165)|RTF|CVE-2012-0158|2014-03-11 01:29:00|0cccb9d951ba888c0c37bb0977fbb3682c09f9df1b537eede5a1601e744a01ad.rtf|
|[77e7fb6b56c3ece4ef4e93b6dc608be0](https://www.virustotal.com/gui/file/77e7fb6b56c3ece4ef4e93b6dc608be0)|Win64 EXE||2014-02-18 01:42:49|77e7fb6b56c3ece4ef4e93b6dc608be0_FancyBear.GermanParliament|
|[94ebc9ef5565f98b1aa1e97c6d35c2e0](https://www.virustotal.com/gui/file/94ebc9ef5565f98b1aa1e97c6d35c2e0)|Win32 DLL||2014-01-14 09:05:58|VirusShare_94ebc9ef5565f98b1aa1e97c6d35c2e0|
|[81d9649612b05829476854bde71b8c3f](https://www.virustotal.com/gui/file/81d9649612b05829476854bde71b8c3f)|Win32 EXE||2014-01-07 13:11:30|5FC4D555CA7E0536D18043977602D421A6FD65F9.exe_|
|[cf30b7550f04a9372c3257c9b5cff3e9](https://www.virustotal.com/gui/file/cf30b7550f04a9372c3257c9b5cff3e9)|Win32 DLL||2013-11-28 15:03:48|EVILTOSS.exe|
|[1259c4fe5efd9bf07fc4c78466f2dd09](https://www.virustotal.com/gui/file/1259c4fe5efd9bf07fc4c78466f2dd09)|Win32 DLL|Zbot|2013-11-26 02:31:10|coreshell.dll|
|[26ac59dab32f6246e1ce3da7506d48fa](https://www.virustotal.com/gui/file/26ac59dab32f6246e1ce3da7506d48fa)|Win32 DLL||2013-11-08 12:38:02|xpool.dll|
|[8b92fe86c5b7a9e34f433a6fbac8bc3a](https://www.virustotal.com/gui/file/8b92fe86c5b7a9e34f433a6fbac8bc3a)|Win32 DLL|razy|2013-11-05 14:12:47|coreshell.dll|
|[aeebfc9eb9031e423797a5af1985242d](https://www.virustotal.com/gui/file/aeebfc9eb9031e423797a5af1985242d)|XLS|CVE-2012-0158|2013-10-23 14:29:46|Vnd.xls|
|[9eebfebe3987fec3c395594dc57a0c4c](https://www.virustotal.com/gui/file/9eebfebe3987fec3c395594dc57a0c4c)|Win32 DLL|razy|2013-10-22 16:59:14|coreshell.dll|
|[e1554b931affb3cd2edc90bc58028078](https://www.virustotal.com/gui/file/e1554b931affb3cd2edc90bc58028078)|Win32 DLL||2013-09-16 05:20:29|AC6B465A13370F87CF57929B7CFD1E45C3694585_Case4Payload_dw20.t_|
|[272f0fde35dbdfccbca1e33373b3570d](https://www.virustotal.com/gui/file/272f0fde35dbdfccbca1e33373b3570d)|Win32 DLL||2013-07-31 14:25:38|coreshell.dll|
|[35717cd78ce713067a5037286cf91c3e](https://www.virustotal.com/gui/file/35717cd78ce713067a5037286cf91c3e)|Win32 DLL|tspy|2013-06-22 21:50:00|/home/virustotal/sample/35717CD78CE713067A5037286CF91C3E|
|[aa3e6af90c144112a1ad0c19bdf873ff](https://www.virustotal.com/gui/file/aa3e6af90c144112a1ad0c19bdf873ff)|Win32 DLL|Zbot|2012-12-18 11:17:25|/home/virustotal/sample/AA3E6AF90C144112A1AD0C19BDF873FF|
|[66f368cab3d5e64475a91f636c87af15](https://www.virustotal.com/gui/file/66f368cab3d5e64475a91f636c87af15)|Win32 EXE|Symmi|2012-12-17 18:13:16|88F7E271E54C127912DB4DB49E37D93AEA8A49C9_Case3_download_msmvs.exe_|
|[f1704aaf08cd66a2ac6cf8810c9e07c2](https://www.virustotal.com/gui/file/f1704aaf08cd66a2ac6cf8810c9e07c2)|Win32 DLL||2012-12-17 18:13:14|/home/virustotal/sample/F1704AAF08CD66A2AC6CF8810C9E07C2|
|[c43edb579e43aaeb6f0c0703f84e43f7](https://www.virustotal.com/gui/file/c43edb579e43aaeb6f0c0703f84e43f7)|Win32 EXE|blocker|2012-10-03 13:46:48|/home/virustotal/sample/C43EDB579E43AAEB6F0C0703F84E43F7|
|[d4e99548832b6999f00e8d223c6fabbd](https://www.virustotal.com/gui/file/d4e99548832b6999f00e8d223c6fabbd)|Win32 DLL|tiggre|2012-09-21 21:37:42|9C622B39521183DD71ED2A174031CA159BEB6479_Case3_conhost.dll__|
|[db9edafbadd71c7a3a0f0aec1b216a92](https://www.virustotal.com/gui/file/db9edafbadd71c7a3a0f0aec1b216a92)|Win32 EXE|Zbot|2011-11-13 05:20:29|/home/vega/CONTAGIO/apt/APT28/APT28_2014-10_TrendMicro Operation Pawn Storm/0A3E6607D5E9C59C712106C355962B11DA2902FC_Case2_S.vbs_exe_|
|[1e217668d89b480ad42e230e8c2c4d97](https://www.virustotal.com/gui/file/1e217668d89b480ad42e230e8c2c4d97)|Win32 EXE||2011-10-17 20:57:07|myfile.exe|
|[7fcf20302404f644fb07fe9d4fe9ac84](https://www.virustotal.com/gui/file/7fcf20302404f644fb07fe9d4fe9ac84)|DOC|other|2011-10-15 22:32:00|/home/virustotal/sample/7FCF20302404F644FB07FE9D4FE9AC84|
|[7276d1dab1125f59604252159e0c529c](https://www.virustotal.com/gui/file/7276d1dab1125f59604252159e0c529c)|Win32 EXE||2011-09-02 10:51:18|/home/virustotal/sample/7276D1DAB1125F59604252159E0C529C|
|[ed7f6260dec470e81dafb0e63bafb5ae](https://www.virustotal.com/gui/file/ed7f6260dec470e81dafb0e63bafb5ae)|Win32 EXE||2011-08-26 10:45:01|ed7f6260dec470e81dafb0e63bafb5ae_Win32.Sofacy.A|
|[42bc93c0caddf07fce919d126a6e378f](https://www.virustotal.com/gui/file/42bc93c0caddf07fce919d126a6e378f)|Win32 DLL||2011-08-26 10:33:16|NetIds.dll|
|[41e14894f4ad9494e0359ee5bb3d9745](https://www.virustotal.com/gui/file/41e14894f4ad9494e0359ee5bb3d9745)|Win32 EXE|Tdss|2011-08-25 14:40:59|/home/virustotal/sample/41E14894F4AD9494E0359EE5BB3D9745|
|[d994b9780b69f611284e22033e435edb](https://www.virustotal.com/gui/file/d994b9780b69f611284e22033e435edb)|RTF|CVE-2010-3333|2011-08-23 15:16:53|342e1f591ab45fcca6cee7f5da118a99dce463e222c03511c3f1288ac2cf82c8.rtf|
|[9b6b266426616375acad7e506aba8d6a](https://www.virustotal.com/gui/file/9b6b266426616375acad7e506aba8d6a)|Win32 EXE||2011-04-11 16:50:49|LibRusLib.exe|
|[9e4817f7bf36a61b363e0911cc0f08b9](https://www.virustotal.com/gui/file/9e4817f7bf36a61b363e0911cc0f08b9)|Win32 DLL||2011-01-20 16:27:40|NetIds.dll|
|[85c80d01661f88ec556579e772a5a3db](https://www.virustotal.com/gui/file/85c80d01661f88ec556579e772a5a3db)|Win32 DLL||2010-03-03 07:43:27|NetIds.dll|
|[7f564a6a8910b513a851b2616af8d7ee](https://www.virustotal.com/gui/file/7f564a6a8910b513a851b2616af8d7ee)|Win32 EXE||2009-08-05 20:22:57|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/APT28,NATOPAPER,SOFACY2004.bin|
|[f01a9a2d1e31332ed36c1a4d2839f412](https://www.virustotal.com/gui/file/f01a9a2d1e31332ed36c1a4d2839f412)|Win32 EXE||2009-02-12 22:19:48|nb.exe|
|[2760c647d03b5d26d3a331428733c809](https://www.virustotal.com/gui/file/2760c647d03b5d26d3a331428733c809)|PDF||2020-10-23 09:58:24|k30-1868 20.10.2020.pdf|
|[72552ef22b484f8868dab10b0f605779](https://www.virustotal.com/gui/file/72552ef22b484f8868dab10b0f605779)|Win32 EXE||2020-10-22 10:44:05|30-1868 20.10.2020.exe|
|[855005fee45e71c36a466527c7fad62f](https://www.virustotal.com/gui/file/855005fee45e71c36a466527c7fad62f)|unknown||2020-10-22 07:08:04|30-1868.vhd|
|[a14c1fd7b59b34515e6a8a286114c48f](https://www.virustotal.com/gui/file/a14c1fd7b59b34515e6a8a286114c48f)|Win32 EXE|sednit|2020-08-07 20:15:59|./KISA_dataset_2020_train/fae335a465bb9faac24c58304a199f3bf9bb1b0bd07b05b18e2be6b9e90d72e6.vir|
|[d21a025e6ba0db784abb1d086b67d3df](https://www.virustotal.com/gui/file/d21a025e6ba0db784abb1d086b67d3df)|DOCX||2020-08-07 11:30:09|letter.docx|
|[98e304e28a51acd92a363346c2b02b2f](https://www.virustotal.com/gui/file/98e304e28a51acd92a363346c2b02b2f)|Win64 EXE||2020-08-07 11:30:08|./KISA_dataset_2020_train/7f698295230f59c7ca8193322eb48d71cd203f3675139f2da99e326589bfdad3.vir|
|[009f073f66b24677cf7ad66818fe4509](https://www.virustotal.com/gui/file/009f073f66b24677cf7ad66818fe4509)|Win32 EXE|sednit|2020-08-07 10:07:08|sqlservice.exe|
|[8103bffc16f8fb3e55028a62e1a004f8](https://www.virustotal.com/gui/file/8103bffc16f8fb3e55028a62e1a004f8)|Win32 EXE|sednit|2020-08-07 08:40:51|sqlservice.exe|
|[c74aa42b41ec44571a3f4e167b01c53c](https://www.virustotal.com/gui/file/c74aa42b41ec44571a3f4e167b01c53c)|ARJ||2020-08-07 07:06:43|Documentation AVT-355.arj|
|[d5e45a9db7f739979105e000d042f1fe](https://www.virustotal.com/gui/file/d5e45a9db7f739979105e000d042f1fe)|Win32 EXE|sednit|2020-08-05 16:33:39|./KISA_dataset_2020_train/aac3b1221366cf7e4421bdd555d0bc33d4b92d6f65fa58c1bb4d8474db883fec.vir|
|[b66c2aa25d1f9056f09d0a158d20faef](https://www.virustotal.com/gui/file/b66c2aa25d1f9056f09d0a158d20faef)|JPEG||2020-08-05 12:28:27|C:\Users\shukuran.quluyev\Desktop\Course 5 - 16 October 2020.zipx|
|[fafd702197d758ce2687706336750660](https://www.virustotal.com/gui/file/fafd702197d758ce2687706336750660)|Win64 EXE||2020-08-05 08:48:54|explorer|
|[93150535f9dcd9f7e169e255264c787a](https://www.virustotal.com/gui/file/93150535f9dcd9f7e169e255264c787a)|Win64 EXE|Wacatac|2020-08-05 08:43:45|explorer|
|[c4a0448925980eacbd22c2dd4869a1c7](https://www.virustotal.com/gui/file/c4a0448925980eacbd22c2dd4869a1c7)|Win64 EXE|EmoDldr|2020-07-30 18:32:06|client.exe|
|[3792380fd7512cc2ec9b28a686edb0e9](https://www.virustotal.com/gui/file/3792380fd7512cc2ec9b28a686edb0e9)|Win64 EXE|EmoDldr|2020-07-30 18:13:27|client_original.exe|
|[019555014b716f3eaac3d81d122beba0](https://www.virustotal.com/gui/file/019555014b716f3eaac3d81d122beba0)|Win32 EXE|sednit|2020-06-17 15:05:07|samclient.exe|
|[88ce694a89cc1d381818a61d9494ba58](https://www.virustotal.com/gui/file/88ce694a89cc1d381818a61d9494ba58)|ARJ||2020-05-21 05:27:13|DN-098-2020_MFA.rar|
|[ed63c42a51b711b81e9aca9a4a150bbd](https://www.virustotal.com/gui/file/ed63c42a51b711b81e9aca9a4a150bbd)|DOCX||2020-05-19 13:24:05|ucx.No.-744_14-05-2020.docx|
|[a31e3b8d2f5e0369be8f3dbb7e23120b](https://www.virustotal.com/gui/file/a31e3b8d2f5e0369be8f3dbb7e23120b)|Win32 EXE||2020-05-19 12:35:51|ucx.No.-745_14-05-2020(1).exe|
|[d9e48eacfe2147293ac233626dc77125](https://www.virustotal.com/gui/file/d9e48eacfe2147293ac233626dc77125)|Win32 EXE|Delf|2020-03-12 03:21:10|C:\Users\<USER>\AppData\Local\Temp\\app.exe|
|[7c487d8462567a826da95c799591f5fb](https://www.virustotal.com/gui/file/7c487d8462567a826da95c799591f5fb)|DOCX|Sagent|2020-01-14 09:25:04|mofa.docx|
|[2fa37cef3c93daf2fad84903af065ad4](https://www.virustotal.com/gui/file/2fa37cef3c93daf2fad84903af065ad4)|Win32 EXE|occamy|2019-07-24 08:19:11|Spisok.docx.exe|
