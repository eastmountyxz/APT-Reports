|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[63ada2e84d1426c582fc48a7006b4202](https://www.virustotal.com/gui/file/63ada2e84d1426c582fc48a7006b4202)|DOC|o97m|2018-10-17 15:15:26|Doc102018.doc|
|[92d66a5f165c57fe24e23dfe526da0bf](https://www.virustotal.com/gui/file/92d66a5f165c57fe24e23dfe526da0bf)|DOC||2018-10-16 07:54:51|/data/cfs/malshare/92d66a5f165c57fe24e23dfe526da0bf|
|[33970523d9c40fc59fdd8d98a4b7fa43](https://www.virustotal.com/gui/file/33970523d9c40fc59fdd8d98a4b7fa43)|PDF|Banload|2018-10-16 06:39:49|Remittance_final_settlements_citi.pdf|
|[1ded730be82850f1a78304be76ac7f4f](https://www.virustotal.com/gui/file/1ded730be82850f1a78304be76ac7f4f)|DOC|o97m|2018-10-09 16:56:09|/data/cfs/malshare/1ded730be82850f1a78304be76ac7f4f|
|[1e51b38c8eae14c74c21cb6e51b45219](https://www.virustotal.com/gui/file/1e51b38c8eae14c74c21cb6e51b45219)|PDF|phishing|2018-10-08 14:54:05|myfile.exe|
|[0c1b11b8159e78143bc67a49033fd406](https://www.virustotal.com/gui/file/0c1b11b8159e78143bc67a49033fd406)|RTF|CVE-2017-8570|2018-09-24 14:09:09|Document0922018.doc|
|[514965bee82ce1c708966e4af4e58540](https://www.virustotal.com/gui/file/514965bee82ce1c708966e4af4e58540)|PDF||2018-09-24 12:55:59|/data/cfs/malshare/514965bee82ce1c708966e4af4e58540|
|[85fe6932218236db4dbf9bedbf9a9dd6](https://www.virustotal.com/gui/file/85fe6932218236db4dbf9bedbf9a9dd6)|PDF||2018-09-24 04:50:06|myfile.exe|
|[9da89a3c06b501fe1dec98009489be4e](https://www.virustotal.com/gui/file/9da89a3c06b501fe1dec98009489be4e)|DOC|o97m|2018-09-14 11:19:02|Document092018.doc|
|[46b6f3d23ec4a07e7a56b537a2fd8fa5](https://www.virustotal.com/gui/file/46b6f3d23ec4a07e7a56b537a2fd8fa5)|PDF||2018-09-14 10:56:09|TT_SWTARC_S-180521-000080.pdf|
|[499b720ee80159804679f0009465916b](https://www.virustotal.com/gui/file/499b720ee80159804679f0009465916b)|PDF|Banload|2018-08-20 08:08:58|Bank Ref_Cancellation_Incorrect AC.pdf|
|[ec742366f68c56f2b91636bd81a6a03c](https://www.virustotal.com/gui/file/ec742366f68c56f2b91636bd81a6a03c)|PDF||2018-05-31 13:15:43|ec742366f68c56f2b91636bd81a6a03c.virus|
|[123db52ae79f0262e52cf674cc1b75fa](https://www.virustotal.com/gui/file/123db52ae79f0262e52cf674cc1b75fa)|RTF|CVE-2017-8570|2018-05-30 12:33:23|123db52ae79f0262e52cf674cc1b75fa.virus|
|[7ec291eb285af937209c810b5083b921](https://www.virustotal.com/gui/file/7ec291eb285af937209c810b5083b921)|DOC||2018-05-03 10:44:45| |
|[5f217deef257889df87573443976c713](https://www.virustotal.com/gui/file/5f217deef257889df87573443976c713)|PDF||2018-05-02 10:38:52|myfile.exe|
|[33cd8c06a1bc8eff1e003935069d120a](https://www.virustotal.com/gui/file/33cd8c06a1bc8eff1e003935069d120a)|DOC||2018-04-23 22:59:23|DOC00481950.doc|
