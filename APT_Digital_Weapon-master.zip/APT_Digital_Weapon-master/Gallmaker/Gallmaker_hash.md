|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f6ca38d0912c2f2d753b6810dffd02d1](https://www.virustotal.com/gui/file/f6ca38d0912c2f2d753b6810dffd02d1)|DOCX||2018-04-10 10:15:08|Navy.ro members list.docx|
|[19f1dfd6f46c9ab4c30702f7fe388920](https://www.virustotal.com/gui/file/19f1dfd6f46c9ab4c30702f7fe388920)|DOC||2018-04-03 08:38:50|GDPRCertification.doc|
|[3a2f4adedd80ab32e7a98fdab56e1c26](https://www.virustotal.com/gui/file/3a2f4adedd80ab32e7a98fdab56e1c26)|Text||2018-01-21 15:58:42|sina.bat|
|[b1f4b9173beb96d7c19f6a36892b4437](https://www.virustotal.com/gui/file/b1f4b9173beb96d7c19f6a36892b4437)|Text||2018-01-19 00:49:32|shellcode.bat|
|[b246a718811f79119f30537c3279b38b](https://www.virustotal.com/gui/file/b246a718811f79119f30537c3279b38b)|Text||2018-01-15 18:12:59|1.bat|
|[4aea481865972a0e9cd35250e03cf450](https://www.virustotal.com/gui/file/4aea481865972a0e9cd35250e03cf450)|DOCX||2017-12-22 22:57:33|Animal Research Study.docx|
|[f9a0bc69ee0067ec7eeb9f0679b141bf](https://www.virustotal.com/gui/file/f9a0bc69ee0067ec7eeb9f0679b141bf)|DOCX|o97m|2017-12-14 14:52:41|Benefits-Addendum-R4-2017.docx|
|[bc34cf16bbb185fe9da6980a19e25f74](https://www.virustotal.com/gui/file/bc34cf16bbb185fe9da6980a19e25f74)|DOCM||2017-09-01 07:29:27|Doc1.docm|
|[d3ed0a6643b5def7cd2bf26d078e873d](https://www.virustotal.com/gui/file/d3ed0a6643b5def7cd2bf26d078e873d)|DOCM|o97m|2017-04-06 10:36:12|reverse_tcp_3133_crypt2.docm|
|[4395348055019c666a7a2dba23106824](https://www.virustotal.com/gui/file/4395348055019c666a7a2dba23106824)|DOCM|o97m|2017-03-30 09:46:53|reverse_tcp_3133_crypt.docm|
|[746212ef5111d94e823ea99991b9d2e1](https://www.virustotal.com/gui/file/746212ef5111d94e823ea99991b9d2e1)|DOC||2017-02-07 10:47:11|parking.doc|
|[aaf6f977c675c0f98d37e8e9e80a57b2](https://www.virustotal.com/gui/file/aaf6f977c675c0f98d37e8e9e80a57b2)|DOC|o97m|2016-11-29 11:05:40|Accectable_Usage_Policy.doc|
|[c99f69f46701739478c25a1d278f7869](https://www.virustotal.com/gui/file/c99f69f46701739478c25a1d278f7869)|DOC|o97m|2016-11-24 09:35:37|Accectable_Usage_Policy.doc|
|[58a0cf2c6a578669ad86d81bcc568bc2](https://www.virustotal.com/gui/file/58a0cf2c6a578669ad86d81bcc568bc2)|DOC|o97m|2016-11-24 09:27:23|Accectable_Usage_Policy.doc|
|[0b6125bd9e8b7ece761d47f1091678db](https://www.virustotal.com/gui/file/0b6125bd9e8b7ece761d47f1091678db)|DOC|o97m|2016-10-31 20:36:11| |
