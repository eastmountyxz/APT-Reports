**NAME:**  
Gallmaker  
  
**Description**:   
Gallmaker, named by Symantec, has been operating since at least December 2017, with its most recent activity observed in June 2018. It targets government and military, including several overseas embassies of an Eastern European country, as well as military and defense targets in the Middle East. This attack group eschews custom malware and uses living off the land (LotL) tactics and publicly available hack tools to carry out cyber-espionage campaign.
  
**References**:  
https://www.symantec.com/blogs/threat-intelligence/gallmaker-attack-group
