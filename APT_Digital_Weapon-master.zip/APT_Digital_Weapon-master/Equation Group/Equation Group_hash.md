|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[b8c0eb946de83fe8440fefbacf7de4a2](https://www.virustotal.com/gui/file/b8c0eb946de83fe8440fefbacf7de4a2)|Win32 DLL||2019-11-18 20:12:15|b8c0eb946de83fe8440fefbacf7de4a2.exe|
|[f3a9e9a174772a0f6e597d4cde47c24b](https://www.virustotal.com/gui/file/f3a9e9a174772a0f6e597d4cde47c24b)|Text||2019-07-22 20:12:08|VirusShare_f3a9e9a174772a0f6e597d4cde47c24b|
|[98dea1bce37bf7087360e1958400589b](https://www.virustotal.com/gui/file/98dea1bce37bf7087360e1958400589b)|Win32 EXE|equationdrug|2015-03-20 00:12:56|msrtvd.sys|
|[2b444ac5209a8b4140dd6b747a996653](https://www.virustotal.com/gui/file/2b444ac5209a8b4140dd6b747a996653)|Win32 EXE|equationdrug|2015-02-17 07:40:16|hdd_driver.bin|
|[ba39212c5b58b97bfc9f5bc431170827](https://www.virustotal.com/gui/file/ba39212c5b58b97bfc9f5bc431170827)|Win32 DLL||2015-02-16 18:34:39|/home/virustotal/sample/BA39212C5B58B97BFC9F5BC431170827|
|[9180d5affe1e5df0717d7385e7f54386](https://www.virustotal.com/gui/file/9180d5affe1e5df0717d7385e7f54386)|Win32 DLL||2015-02-16 18:34:07|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/TripleFantasy.bin|
|[11fb08b9126cdb4668b3f5135cf7a6c5](https://www.virustotal.com/gui/file/11fb08b9126cdb4668b3f5135cf7a6c5)|Win32 DLL|equationdrug|2015-02-16 18:33:41|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/HDDFirmware|
|[24a6ec8ebf9c0867ed1c097f4a653b8d](https://www.virustotal.com/gui/file/24a6ec8ebf9c0867ed1c097f4a653b8d)|Win64 EXE|winnt|2015-02-16 18:32:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/GrokKeylogger|
|[9b1ca66aab784dc5f1dfe635d8f8a904](https://www.virustotal.com/gui/file/9b1ca66aab784dc5f1dfe635d8f8a904)|Win32 EXE||2015-02-16 18:32:24|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/GrayfishInstaller.bin|
|[2a12630ff976ba0994143ca93fecd17f](https://www.virustotal.com/gui/file/2a12630ff976ba0994143ca93fecd17f)|Win32 EXE||2015-02-16 18:29:21|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/DoubleFantasyInstaller.bin|
|[6fe6c03b938580ebf9b82f3b9cd4c4aa](https://www.virustotal.com/gui/file/6fe6c03b938580ebf9b82f3b9cd4c4aa)|Win32 EXE|equationdrug|2015-02-16 18:28:26|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/DiskFromHoustonEoPExploits.bin|
|[4556ce5eb007af1de5bd3b457f0b216d](https://www.virustotal.com/gui/file/4556ce5eb007af1de5bd3b457f0b216d)|Win32 EXE|Zbot|2015-01-28 21:45:53|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/EquationDrugLUTEUSOBSTOS|
|[03718676311de33dd0b8f4f18cffd488](https://www.virustotal.com/gui/file/03718676311de33dd0b8f4f18cffd488)|Win32 DLL|equationdrug|2015-01-19 05:17:44|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/SD_IP_CF.dll.bin|
|[8486ec3112e322f9f468bdea3005d7b5](https://www.virustotal.com/gui/file/8486ec3112e322f9f468bdea3005d7b5)|Win32 EXE||2014-12-01 15:59:28|fffdee.dll|
|[0a209ac0de4ac033f31d6ba9191a8f7a](https://www.virustotal.com/gui/file/0a209ac0de4ac033f31d6ba9191a8f7a)|Win32 DLL|equationdrug|2012-08-01 09:50:13|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/FannyWorm.bin|
|[06665b96e293b23acc80451abb413e50](https://www.virustotal.com/gui/file/06665b96e293b23acc80451abb413e50)|Win32 EXE||2012-06-20 07:37:11|06665b96e293b23acc80451abb413e50_f1d903251db466d35533c28e3c032b7212aa43c8d64ddf8c5521b43031e69e1e|
|[b505d65721bb2453d5039a389113b566](https://www.virustotal.com/gui/file/b505d65721bb2453d5039a389113b566)|Win32 DLL|winnt|2012-05-31 10:00:33|b505d65721bb2453d5039a389113b566_4e39bc95e35323ab586d740725a1c8cbcde01fe453f7c4cac7cced9a26e42cc9|
|[60dab5bb319281747c5863b44c5ac60d](https://www.virustotal.com/gui/file/60dab5bb319281747c5863b44c5ac60d)|Win32 EXE|equationdrug|2011-12-29 01:36:04|tdip.sys|
|[db405ad775ac887a337b02ea8b07fddc](https://www.virustotal.com/gui/file/db405ad775ac887a337b02ea8b07fddc)|Win32 DLL|winnt|2011-03-14 19:33:19|parclass|
|[744c07e886497f7b68f6f7fe57b7ab54](https://www.virustotal.com/gui/file/744c07e886497f7b68f6f7fe57b7ab54)|Win32 DLL||2011-03-14 13:01:53|floppy|
|[47d0e8f9d7a6429920329207a32ecc2e](https://www.virustotal.com/gui/file/47d0e8f9d7a6429920329207a32ecc2e)|Win32 DLL|winnt|2011-03-14 11:54:19|abiosdsk|
|[bfbe8c3ee78750c3a520480700e440f8](https://www.virustotal.com/gui/file/bfbe8c3ee78750c3a520480700e440f8)|Win32 DLL|winnt|2011-03-11 23:57:24|bfbe8c3ee78750c3a520480700e440f8_8d7be9ed64811ea7986d788a75cbc4ca166702c6ff68c33873270d7c6597f5db|
|[b29ca4f22ae7b7b25f79c1d4a421139d](https://www.virustotal.com/gui/file/b29ca4f22ae7b7b25f79c1d4a421139d)|Win32 EXE|winnt|2011-03-11 23:55:06|b29ca4f22ae7b7b25f79c1d4a421139d_a0d82c3730bc41e267711480c8009883d1412b68977ab175421eabc34e4ef355|
|[1c024e599ac055312a4ab75b3950040a](https://www.virustotal.com/gui/file/1c024e599ac055312a4ab75b3950040a)|Win32 DLL|winnt|2011-03-09 15:09:02|1c024e599ac055312a4ab75b3950040a_c0cf8e008fbfa0cb2c61d968057b4a077d62f64d7320769982d28107db370513|
|[4b6b86c7fec1c574706cecedf44abded](https://www.virustotal.com/gui/file/4b6b86c7fec1c574706cecedf44abded)|Win32 DLL|winnt|2011-03-09 15:06:09|usbclass|
|[ba7bb65634ce1e30c1e5415be3d1db1d](https://www.virustotal.com/gui/file/ba7bb65634ce1e30c1e5415be3d1db1d)|Win32 DLL|winnt|2011-03-09 15:06:03|ba7bb65634ce1e30c1e5415be3d1db1d_5001793790939009355ba841610412e0f8d60ef5461f2ea272ccf4fd4c83b823|
|[187044596bc1328efa0ed636d8aa4a5c](https://www.virustotal.com/gui/file/187044596bc1328efa0ed636d8aa4a5c)|Win32 EXE|winnt|2011-03-09 15:05:53|187044596bc1328efa0ed636d8aa4a5c_a7e3ad8ea7edf1ca10b0e5b0d976675c3016e5933219f97e94900dea0d470abe|
|[d240f06e98c8d3e647cbf4d442d79475](https://www.virustotal.com/gui/file/d240f06e98c8d3e647cbf4d442d79475)|Win32 EXE|winnt|2011-03-09 15:05:49|d240f06e98c8d3e647cbf4d442d79475_9cd5127ef31da0e8a4e36292f2af5a9ec1de3b294da367d7c05786fe2d5de44f|
|[2c8b9d2885543d7ade3cae98225e263b](https://www.virustotal.com/gui/file/2c8b9d2885543d7ade3cae98225e263b)|Win32 DLL|winnt|2011-03-09 15:05:43|usbclass|
|[6662c390b2bbbd291ec7987388fc75d7](https://www.virustotal.com/gui/file/6662c390b2bbbd291ec7987388fc75d7)|Win32 EXE|winnt|2011-03-09 09:05:52|6662c390b2bbbd291ec7987388fc75d7_e1ba03a10a40aab909b2ba58dcdfd378b4d264f1f4a554b669797bbb8c8ac902|
|[20506375665a6a62f7d9dd22d1cc9870](https://www.virustotal.com/gui/file/20506375665a6a62f7d9dd22d1cc9870)|Win32 EXE|equationdrug|2010-12-18 07:08:58|tdip.sys|
|[26297dc3cd0b688de3b846983c5385e5](https://www.virustotal.com/gui/file/26297dc3cd0b688de3b846983c5385e5)|Win32 DLL|winnt|2010-08-04 08:18:51|26297DC3CD0B688DE3B846983C5385E5|
|[b269894f434657db2b15949641a67532](https://www.virustotal.com/gui/file/b269894f434657db2b15949641a67532)|Win32 DLL|winnt|2010-03-15 16:24:16|b269894f434657db2b15949641a67532_a7493fac96345a989b1a03772444075754a2ef11daa22a7600466adc1f69a669|
|[c17e16a54916d3838f63d208ebab9879](https://www.virustotal.com/gui/file/c17e16a54916d3838f63d208ebab9879)|Win32 EXE|equationdrug|2009-12-16 21:48:02|volrec.sys|
|[15d39578460e878dd89e8911180494ff](https://www.virustotal.com/gui/file/15d39578460e878dd89e8911180494ff)|Win32 EXE|equationdrug|2009-12-16 21:27:13|msrstd.sys|
|[214f7a2c95bdc265888fbcd24e3587da](https://www.virustotal.com/gui/file/214f7a2c95bdc265888fbcd24e3587da)|Win32 EXE|equationdrug|2009-11-12 08:02:17|ATMDKDRV.SYS|
|[74de13b5ea68b3da24addc009f84baee](https://www.virustotal.com/gui/file/74de13b5ea68b3da24addc009f84baee)|Win32 EXE|Zbot|2009-09-22 22:12:57|/home/virustotal/sample/74DE13B5EA68B3DA24ADDC009F84BAEE|
|[5767b9d851d0c24e13eca1bfd16ea424](https://www.virustotal.com/gui/file/5767b9d851d0c24e13eca1bfd16ea424)|Win32 DLL|equationdrug|2009-08-04 08:32:46|mscfg32.dll|
|[ef4405930e6071ae1f7f6fa7d4f3397d](https://www.virustotal.com/gui/file/ef4405930e6071ae1f7f6fa7d4f3397d)|Win32 DLL|equationdrug|2009-08-04 06:00:32|/home/virustotal/sample/EF4405930E6071AE1F7F6FA7D4F3397D|
|[f6bf3ed3bcd466e5fd1cbaf6ba658716](https://www.virustotal.com/gui/file/f6bf3ed3bcd466e5fd1cbaf6ba658716)|Win32 EXE|equationdrug|2009-08-03 16:10:10| |
|[8d87a1845122bf090b3d8656dc9d60a8](https://www.virustotal.com/gui/file/8d87a1845122bf090b3d8656dc9d60a8)|Win32 EXE|equationdrug|2009-05-16 23:09:17|/home/virustotal/sample/8D87A1845122BF090B3D8656DC9D60A8|
|[ffb0b9b5b610191051a7bdf0806e1e47](https://www.virustotal.com/gui/file/ffb0b9b5b610191051a7bdf0806e1e47)|Win32 EXE|winnt|2009-03-18 11:20:17|ffb0b9b5b610191051a7bdf0806e1e47_b12c7d57507286bbbe36d7acf9b34c22c96606ffd904e3c23008399a4a50c047|
|[c4f8671c1f00dab30f5f88d684af1927](https://www.virustotal.com/gui/file/c4f8671c1f00dab30f5f88d684af1927)|Win32 EXE|equationdrug|2009-03-07 02:20:28|msndsrv.sys|
|[c3af66b9ce29efe5ee34e87b6e136e3a](https://www.virustotal.com/gui/file/c3af66b9ce29efe5ee34e87b6e136e3a)|Win32 EXE|equationdrug|2008-04-22 11:05:22|mscfg32.exe|
|[752af597e6d9fd70396accc0b9013dbe](https://www.virustotal.com/gui/file/752af597e6d9fd70396accc0b9013dbe)|Win32 DLL||2006-08-24 09:48:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/EquationGroup/EquationLaserInstaller.bin|
