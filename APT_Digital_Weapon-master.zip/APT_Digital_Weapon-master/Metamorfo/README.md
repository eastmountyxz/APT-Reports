**NAME:**  
Metamorfo  

**Description**:   
The attackers used various techniques to evade detection and infect unsuspecting Portuguese-speaking users with banking Trojans. Public cloud infrastructure is utilized to help deliver the different stages and play a particularly big role in delivering the malicious payload. Legitimate signed binaries are also abused to load malicious code.
  
**References**:  
https://www.fireeye.com/blog/threat-research/2018/04/metamorfo-campaign-targeting-brazilian-users.html