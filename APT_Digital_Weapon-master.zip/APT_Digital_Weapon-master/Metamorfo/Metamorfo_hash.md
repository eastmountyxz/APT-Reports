|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[d726b53461a4ec858925ed31cef15f1e](https://www.virustotal.com/gui/file/d726b53461a4ec858925ed31cef15f1e)|Win32 DLL||2018-03-12 18:49:31|d726b53461a4ec858925ed31cef15f1e.virus|
|[d3f845c84a2bd8e3589a6fbf395fea06](https://www.virustotal.com/gui/file/d3f845c84a2bd8e3589a6fbf395fea06)|Win32 DLL||2018-03-10 00:12:09|d3f845c84a2bd8e3589a6fbf395fea06.virus|
|[2365fb50eeb6c4476218507008d9a00b](https://www.virustotal.com/gui/file/2365fb50eeb6c4476218507008d9a00b)|Win32 DLL|Banbra|2018-03-09 08:58:08|2365fb50eeb6c4476218507008d9a00b.virus|
|[d9682356e78c3ebca4d001de760848b0](https://www.virustotal.com/gui/file/d9682356e78c3ebca4d001de760848b0)|Win32 DLL||2018-03-08 17:16:14|d9682356e78c3ebca4d001de760848b0.virus|
|[2999724b1aa19b8238d4217565e31c8e](https://www.virustotal.com/gui/file/2999724b1aa19b8238d4217565e31c8e)|Win32 EXE|autoit|2018-03-08 04:34:58|2999724b1aa19b8238d4217565e31c8e.virus|
|[330721de2a76eed2b461f24bab7b7160](https://www.virustotal.com/gui/file/330721de2a76eed2b461f24bab7b7160)|Win32 DLL||2018-03-07 22:21:52|330721de2a76eed2b461f24bab7b7160.virus|
|[6734245beda04dcf5af3793c5d547923](https://www.virustotal.com/gui/file/6734245beda04dcf5af3793c5d547923)|Win32 DLL|casbaneiro|2018-03-07 10:54:29|6734245beda04dcf5af3793c5d547923.virus|
|[a8b2b6e63daf4ca3e065d1751cac723b](https://www.virustotal.com/gui/file/a8b2b6e63daf4ca3e065d1751cac723b)|Win32 DLL||2018-03-07 02:01:33|a8b2b6e63daf4ca3e065d1751cac723b.virus|
|[a920b668079b2c1b502fdaee2dd2358f](https://www.virustotal.com/gui/file/a920b668079b2c1b502fdaee2dd2358f)|Win32 DLL|Banbra|2018-03-06 04:32:10|a920b668079b2c1b502fdaee2dd2358f.virus|
|[fe09217cc4119dedbe85d22ad23955a1](https://www.virustotal.com/gui/file/fe09217cc4119dedbe85d22ad23955a1)|Win32 DLL||2018-03-06 04:26:33|fe09217cc4119dedbe85d22ad23955a1.virus|
|[4610cdd9d737ecfa1067ac30022d793b](https://www.virustotal.com/gui/file/4610cdd9d737ecfa1067ac30022d793b)|Win32 DLL||2018-03-05 22:25:08|4610cdd9d737ecfa1067ac30022d793b.virus|
|[82e2c6b0b116855816497667553bdf11](https://www.virustotal.com/gui/file/82e2c6b0b116855816497667553bdf11)|Win32 DLL|Banbra|2018-03-04 00:32:19|82e2c6b0b116855816497667553bdf11.virus|
|[3e9622d1a6d7b924cefe7d3458070d98](https://www.virustotal.com/gui/file/3e9622d1a6d7b924cefe7d3458070d98)|Win32 EXE|Banload|2018-03-02 14:33:10|3e9622d1a6d7b924cefe7d3458070d98.virus|
|[f402a482fd96b0a583be2a265acd5e74](https://www.virustotal.com/gui/file/f402a482fd96b0a583be2a265acd5e74)|Win32 EXE||2018-03-02 13:43:39|f402a482fd96b0a583be2a265acd5e74.virus|
|[c2cc04be25f227b13bcb0b1d9811e2fe](https://www.virustotal.com/gui/file/c2cc04be25f227b13bcb0b1d9811e2fe)|Win32 DLL|Banbra|2018-03-02 11:20:15|c2cc04be25f227b13bcb0b1d9811e2fe.virus|
|[dd73f749d40146b6c0d2759ba78b1764](https://www.virustotal.com/gui/file/dd73f749d40146b6c0d2759ba78b1764)|Text|Banload|2018-03-02 10:49:25|icone.vbs|
|[f329107f795654bfc62374f8930d1e12](https://www.virustotal.com/gui/file/f329107f795654bfc62374f8930d1e12)|Win32 EXE||2018-03-01 19:08:55|myfile.exe|
|[860fa744d8c82859b41e00761c6e25f3](https://www.virustotal.com/gui/file/860fa744d8c82859b41e00761c6e25f3)|Win32 EXE|Banload|2018-03-01 18:34:01|myfile.exe|
|[789a021c051651dbc9e01c5d8c0ce129](https://www.virustotal.com/gui/file/789a021c051651dbc9e01c5d8c0ce129)|Win32 EXE||2018-03-01 12:43:48|789a021c051651dbc9e01c5d8c0ce129.virus|
|[68f818fa156d45889f36aeca5dc75a81](https://www.virustotal.com/gui/file/68f818fa156d45889f36aeca5dc75a81)|Win32 EXE||2018-02-28 18:53:04|68f818fa156d45889f36aeca5dc75a81.virus|
|[34a8dda75aea25d92cd66da53a718589](https://www.virustotal.com/gui/file/34a8dda75aea25d92cd66da53a718589)|Win32 DLL|tspy|2018-02-26 18:48:25|34a8dda75aea25d92cd66da53a718589.virus|
|[28a0968163b6e6857471305aee5c17e9](https://www.virustotal.com/gui/file/28a0968163b6e6857471305aee5c17e9)|Win32 DLL|casbaneiro|2018-02-23 17:57:14|28a0968163b6e6857471305aee5c17e9.virus|
|[1285205ae5dd5fa5544b3855b11b989d](https://www.virustotal.com/gui/file/1285205ae5dd5fa5544b3855b11b989d)|Win32 DLL||2018-02-23 16:45:22|1285205ae5dd5fa5544b3855b11b989d.virus|
|[88b808d8164e709df2ca99f73ead2e16](https://www.virustotal.com/gui/file/88b808d8164e709df2ca99f73ead2e16)|Win32 DLL||2018-02-22 16:37:21|88b808d8164e709df2ca99f73ead2e16.virus|
|[613563d7863b4f9f66590064b88164c8](https://www.virustotal.com/gui/file/613563d7863b4f9f66590064b88164c8)|Win32 DLL||2018-02-22 04:41:56|613563d7863b4f9f66590064b88164c8.virus|
|[3dd43e69f8d71fcc2704eb73c1ea7daf](https://www.virustotal.com/gui/file/3dd43e69f8d71fcc2704eb73c1ea7daf)|Win32 DLL||2018-02-21 18:15:05|3dd43e69f8d71fcc2704eb73c1ea7daf.virus|
|[d9d1e72165601012b9d959bd250997b3](https://www.virustotal.com/gui/file/d9d1e72165601012b9d959bd250997b3)|Text||2018-02-07 14:38:36|d9d1e72165601012b9d959bd250997b3.virus|
|[6d2cb9e726c9fac0fb36afc377be3aec](https://www.virustotal.com/gui/file/6d2cb9e726c9fac0fb36afc377be3aec)|Text||2015-07-31 05:08:26|C:\users\public\a0o1t4d6h7v3i5\id|
|[03e4f8327fbb6844e78fda7cdae2e8ad](https://www.virustotal.com/gui/file/03e4f8327fbb6844e78fda7cdae2e8ad)|Win32 EXE||2014-01-23 07:51:25|pvk2pfx|
|[181c8f19f974ad8a84b8673d487bbf0d](https://www.virustotal.com/gui/file/181c8f19f974ad8a84b8673d487bbf0d)|Win32 EXE||2011-03-01 18:20:27|CERTMGR.EXE|
|[f70ca5997caa3d837cd939c8ef56e6ef](https://www.virustotal.com/gui/file/f70ca5997caa3d837cd939c8ef56e6ef)|FPX||2020-03-25 01:31:20|C:\Users\Administrator\AppData\Local\Temp\msdc098755NC.msi|
|[479317545b259d30cfb63742ec9a45f4](https://www.virustotal.com/gui/file/479317545b259d30cfb63742ec9a45f4)|FPX||2020-03-17 04:27:17|SBK13783VBYB.msi|
|[0bc49d1402f1e6f527199a12653711fa](https://www.virustotal.com/gui/file/0bc49d1402f1e6f527199a12653711fa)|Win32 DLL|BestaFera|2020-03-16 10:12:29|C:\Sandbox\sv-user\DefaultBox\user\all\0ZnSYynX\TCiraIOL.dll|
|[b8f27ab146df02fa220ca955ca183669](https://www.virustotal.com/gui/file/b8f27ab146df02fa220ca955ca183669)|ZIP||2020-03-16 06:43:36|Unconfirmed 177264.crdownload|
|[ef192a6be51961fcf984c437b64475e3](https://www.virustotal.com/gui/file/ef192a6be51961fcf984c437b64475e3)|TXT||2020-03-04 10:58:07|14115-ef192a6be51961fcf984c437b64475e3.js|
|[f3a20a781bcc6122981ff9caa7ed5580](https://www.virustotal.com/gui/file/f3a20a781bcc6122981ff9caa7ed5580)|FPX|sLoad|2020-01-03 20:41:34|eb1e5eaea4ecc04b920bbd955c16b17f3d5ac3c580ea266ff5b9d589b8b49e0c.bin|
|[a3b4d222a755f43b34a0963f13f77500](https://www.virustotal.com/gui/file/a3b4d222a755f43b34a0963f13f77500)|Win32 DLL||2019-08-01 14:25:13|AICustAct.dll|
