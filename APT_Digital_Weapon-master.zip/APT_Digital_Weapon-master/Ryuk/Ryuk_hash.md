|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[32cbc69f85cc47d8e35dc20dfbda6948](https://www.virustotal.com/gui/file/32cbc69f85cc47d8e35dc20dfbda6948)|Win64 EXE|Ryuk|2019-01-03 00:58:58|795db7bdad1befdd3ad942be79715f6b0c5083d859901b81657b590c9628790f.bin|
|[7a7b1300e8b5a10424e08958a6fc15c1](https://www.virustotal.com/gui/file/7a7b1300e8b5a10424e08958a6fc15c1)|Win64 EXE|Ryuk|2018-12-31 12:15:17|AGsuy.exe|
|[40492c178079e65dfd5449bf899413b6](https://www.virustotal.com/gui/file/40492c178079e65dfd5449bf899413b6)|Win64 EXE|Ryuk|2018-12-26 20:26:23| |
