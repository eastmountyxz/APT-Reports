**NAME:**  
Ryuk  
  
**Description**:   
Ryuk is a ransomware that encrypts files on a compromised computer and then demands payment, typically in Bitcoin, to decrypt them. Cybercriminals had targeted over 100 US and international businesses with Ryuk ransomware since August 2018. It was being used exclusively for targeted attacks, with its main targets being the critical assets of its victims.

**References**:  
https://thenextweb.com/hardfork/2019/10/07/us-hospitals-pay-bitcoin-cryptocurrency-to-survive-ryuk-ransomware-attack/