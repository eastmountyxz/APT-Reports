**NAME:**  
TH-163  

**Description**:   
SLoad (tracked as TH-163) is the protagonist of an increasing and persistent wave of attacks against Italian organizations since Q3 2018 with high quality phishing emails. As reported by Proofpoint, the targeted countries include the UK and Canada as well.
  
**References**:  
https://securityaffairs.co/wordpress/92138/malware/sload-italian-attacks.html