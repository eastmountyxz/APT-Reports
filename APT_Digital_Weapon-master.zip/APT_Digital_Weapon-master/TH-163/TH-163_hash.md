|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c6a4d80bcf8dcbaedd202f7cbd0027c0](https://www.virustotal.com/gui/file/c6a4d80bcf8dcbaedd202f7cbd0027c0)|Text||2019-09-26 10:03:46|IT83440018268.pdf|
|[6427c20e2f2397f639ece0d3705ca8ea](https://www.virustotal.com/gui/file/6427c20e2f2397f639ece0d3705ca8ea)|Text||2019-09-26 10:00:49|IT83440018268.vbs|
|[407fd81983377f67cdef76693ac3d3b2](https://www.virustotal.com/gui/file/407fd81983377f67cdef76693ac3d3b2)|unknown||2019-09-16 14:59:33|web.ini|
|[4b4580a21ae1208bf92415b345d27318](https://www.virustotal.com/gui/file/4b4580a21ae1208bf92415b345d27318)|TXT||2020-01-16 14:38:06|main.ini|
|[4725d8b088a3cf4d3555bac07dbd5b73](https://www.virustotal.com/gui/file/4725d8b088a3cf4d3555bac07dbd5b73)|TXT||2020-01-13 10:30:40|sollecito-avviso-CU69151275241.vbs|
|[7cca0d5cc8df288737af6d6beacb28dd](https://www.virustotal.com/gui/file/7cca0d5cc8df288737af6d6beacb28dd)|ZIP||2020-01-13 10:25:09|sollecito-avviso-CU69151275241.zip|
