**NAME:**  
PoisonedNews

 
**Description**:   
PoisonedNews, a watering hole attack discovered by Trend Micro, targets iOS users in Hong Kong. The campaign uses links posted on multiple forums that supposedly lead to various news stories, meanwhile with a hidden iframe to load and execute malicious code. The malicious code contains exploits that target vulnerabilities present in iOS 12.1 and 12.2

  
**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/operation-poisoned-news-hong-kong-users-targeted-with-mobile-malware-via-local-news-links/
