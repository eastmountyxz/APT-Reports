|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[ec629f648434fc3d17e9561532d038c8](https://www.virustotal.com/gui/file/ec629f648434fc3d17e9561532d038c8)|Win32 EXE||2018-04-05 06:35:12|LSASS.exe|
|[d7115f8ddbc431c7968aebbc842d65d7](https://www.virustotal.com/gui/file/d7115f8ddbc431c7968aebbc842d65d7)|DOCM|GravityRAT|2018-04-04 07:34:19|documentx.doc|
|[e8a5e737e30b959f652025d53fb2c377](https://www.virustotal.com/gui/file/e8a5e737e30b959f652025d53fb2c377)|DOCX||2018-03-20 10:38:30|test456.docx|
|[82f88268b57c4af66518e1b1755cea9e](https://www.virustotal.com/gui/file/82f88268b57c4af66518e1b1755cea9e)|DOCX||2018-03-19 11:34:03|test2.docx|
|[90e7202fe117542b28a4ade0f81f2020](https://www.virustotal.com/gui/file/90e7202fe117542b28a4ade0f81f2020)|DOCX|o97m|2018-03-19 11:28:56|testnew1.docx|
|[d3ad39e58ccc1efb4b1895f264810bae](https://www.virustotal.com/gui/file/d3ad39e58ccc1efb4b1895f264810bae)|XLSX||2018-03-16 06:42:51|Book1.xlsx|
|[aeefb0068f33bf0f953666eab151ca0f](https://www.virustotal.com/gui/file/aeefb0068f33bf0f953666eab151ca0f)|XLSX||2018-03-16 06:02:03|book1test2.xlsx|
|[0c7f5034f9cefdc4723cdce69ee1fc2f](https://www.virustotal.com/gui/file/0c7f5034f9cefdc4723cdce69ee1fc2f)|DOCM|GravityRAT|2018-03-01 06:45:48|test123.doc|
|[a9e8d3a20a8f7486f798ad68b321ac82](https://www.virustotal.com/gui/file/a9e8d3a20a8f7486f798ad68b321ac82)|DOCM|GravityRAT|2018-03-01 06:27:51|test123.doc|
|[0c926bc924f2b1e843aec259e2bd5f42](https://www.virustotal.com/gui/file/0c926bc924f2b1e843aec259e2bd5f42)|DOCM|GravityRAT|2018-03-01 06:18:10|test123.doc|
|[3ca8df24f434419a25d3de9bc234f7de](https://www.virustotal.com/gui/file/3ca8df24f434419a25d3de9bc234f7de)|DOCM|GravityRAT|2018-03-01 06:16:01|test123.doc|
|[96cf8b0bd06a70a09774a38046cbd42a](https://www.virustotal.com/gui/file/96cf8b0bd06a70a09774a38046cbd42a)|DOCM|GravityRAT|2018-03-01 06:10:12|document3.doc|
|[64610f3ad087df79d932758e93f289d1](https://www.virustotal.com/gui/file/64610f3ad087df79d932758e93f289d1)|Win32 EXE|GravityRAT|2017-08-31 04:19:25|Intel Core.exe|
|[6899c2219764bac56007ce80021bfcbf](https://www.virustotal.com/gui/file/6899c2219764bac56007ce80021bfcbf)|Win32 EXE|GravityRAT|2017-08-08 08:32:05|18622269_1319089991459758_8391949054533842002_n.scr|
|[783a48640c0776932fc81925962f273b](https://www.virustotal.com/gui/file/783a48640c0776932fc81925962f273b)|Win32 EXE|GravityRAT|2016-12-22 08:06:10|systemInterrupts.exe|
