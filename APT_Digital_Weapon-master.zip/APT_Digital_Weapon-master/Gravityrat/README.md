**NAME:**  
Gravityrat  
 
**Description**:   
GravityRAT is a malware utilized in APT attacks targeting India with evolving features. The threat, which is identified by Talos, uses a WMI request in order to get the current temperature of the hardware. There are four versions in total, developed over two years. The actor took their time to ensure they were not within a virtual environment to avoid analysis. However, they did not attempt to obfuscate their .NET code.
  
**References**:  
https://blog.talosintelligence.com/2018/04/gravityrat-two-year-evolution-of-apt.html
