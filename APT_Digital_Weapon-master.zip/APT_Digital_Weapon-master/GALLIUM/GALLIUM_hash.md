|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[07de7a95efb47958b6f61e91e396f8e1](https://www.virustotal.com/gui/file/07de7a95efb47958b6f61e91e396f8e1)|Win64 EXE||2019-11-04 07:27:13|fe0e4ef832b62d49b43433e10c47dc51072959af93963c790892efc20ec422f1.sample|
|[a2d9b9d9e2207168206ea47644325cfc](https://www.virustotal.com/gui/file/a2d9b9d9e2207168206ea47644325cfc)|Win64 EXE||2018-11-20 06:02:06|simplify.exe|
|[3586f78ad5596f68536dfd75df54db1e](https://www.virustotal.com/gui/file/3586f78ad5596f68536dfd75df54db1e)|Win32 EXE||2018-11-20 02:41:53|9ae7c4a4e1cfe9b505c3a47e66551eb1357affee65bfefb0109d02f4e97c06dd.bin|
|[c1836091070bf23af23e9eaf62d45380](https://www.virustotal.com/gui/file/c1836091070bf23af23e9eaf62d45380)|Win64 EXE||2018-11-20 02:24:14|7ce9e1c5562c8a5c93878629a47fe6071a35d604ed57a8f918f3eadf82c11a9c.bin|
|[c990e02f274127e7be060f40c9c79e8b](https://www.virustotal.com/gui/file/c990e02f274127e7be060f40c9c79e8b)|Win32 EXE||2018-10-26 10:59:36|a370e47cb97b35f1ae6590d14ada7561d22b4a73be0cb6df7e851d85054b1ac3.bin|
|[9a97ddbb141d01ce0b1b994399cfb7dc](https://www.virustotal.com/gui/file/9a97ddbb141d01ce0b1b994399cfb7dc)|Win32 DLL||2018-10-18 19:29:58|ssMUIDLL.dll|
|[2e834d8dde313e992997cbda050a15f1](https://www.virustotal.com/gui/file/2e834d8dde313e992997cbda050a15f1)|Win64 EXE||2018-07-18 02:14:58|simplify_i64d.exe|
|[723a98a3b0f9db7e15533848abe1fdfb](https://www.virustotal.com/gui/file/723a98a3b0f9db7e15533848abe1fdfb)|Win32 EXE||2018-07-06 06:59:11|myfile.exe|
|[fee9bc26f55c2049e1b64616a442dc7b](https://www.virustotal.com/gui/file/fee9bc26f55c2049e1b64616a442dc7b)|Win64 EXE||2018-07-06 06:59:00|39_64d.exe|
|[55053850260a402fba7661a0c7920457](https://www.virustotal.com/gui/file/55053850260a402fba7661a0c7920457)|Win64 EXE||2018-04-28 08:21:51|simplify|
|[96f56b9aff235a11ed946b50344edabd](https://www.virustotal.com/gui/file/96f56b9aff235a11ed946b50344edabd)|Win64 EXE||2018-04-19 12:18:16|m-22.exe|
|[7824babea1ebfc326648659cb69544f3](https://www.virustotal.com/gui/file/7824babea1ebfc326648659cb69544f3)|Win32 EXE||2017-05-17 17:25:27| |
