**NAME:**  
Vicious Panda

 
**Description**:   
Check Point Research discovered a new campaign against the Mongolian public sector, which takes advantage of the Coronavirus scare, in order to deliver a previously unknown malware implant to the target. According to the report, it was tied to other operations which were carried out by the same anonymous group, dating back to at least 2016.

  
**References**:  
https://research.checkpoint.com/2020/vicious-panda-the-covid-campaign/
