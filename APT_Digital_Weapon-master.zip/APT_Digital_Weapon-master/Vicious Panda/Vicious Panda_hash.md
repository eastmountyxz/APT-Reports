|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[cd792384c1d70b9210a573b56a5ec035](https://www.virustotal.com/gui/file/cd792384c1d70b9210a573b56a5ec035)|Win64 DLL|Ursu|2020-05-18 11:02:51| |
|[a8dc0071a84720b55fda27b4042f352f](https://www.virustotal.com/gui/file/a8dc0071a84720b55fda27b4042f352f)|Win32 DLL||2020-04-08 07:19:10|a8dc0071a84720b55fda27b4042f352f.virus|
|[a4f695d4f912f27a193bdaed6f073128](https://www.virustotal.com/gui/file/a4f695d4f912f27a193bdaed6f073128)|Win32 DLL|Kryptik|2020-03-16 17:15:40|striketDxcOb.data|
|[a6cce77325e4465c78c7b7b3610e2787](https://www.virustotal.com/gui/file/a6cce77325e4465c78c7b7b3610e2787)|RTF|CVE-2017-11882|2020-03-16 10:29:42|strikeJBHeXb.data|
|[8b75bb1d547cf6af3569ff836379145b](https://www.virustotal.com/gui/file/8b75bb1d547cf6af3569ff836379145b)|Win32 DLL|Kryptik|2019-12-24 16:15:11|strikewUX1GY.data|
|[70ab82bfdc09ef5c5bc07e55c504a496](https://www.virustotal.com/gui/file/70ab82bfdc09ef5c5bc07e55c504a496)|Win32 DLL|Kryptik|2019-12-23 02:56:51|strikerpJALR.data|
|[3009db32ca8895a0f15f724ba12a6711](https://www.virustotal.com/gui/file/3009db32ca8895a0f15f724ba12a6711)|Win32 DLL|Ursu|2019-12-18 17:30:53|strikeRBFU3Y.data|
|[0d28743f8cbae195a81e437720866965](https://www.virustotal.com/gui/file/0d28743f8cbae195a81e437720866965)|RTF|CVE-2017-11882|2019-12-18 09:35:14|strikesGyK9Z.data|
|[7c986cfdf3fa28f560f2c63801424e1a](https://www.virustotal.com/gui/file/7c986cfdf3fa28f560f2c63801424e1a)|RTF|CVE-2017-11882|2019-12-18 09:33:43|strikewnbO9n.data|
|[9de7863f2fab2296dda74d1bf838e620](https://www.virustotal.com/gui/file/9de7863f2fab2296dda74d1bf838e620)|Win64 DLL|Kryptik|2019-11-29 14:14:13|strike04UUIG.exe|
|[73b097c610daf7136b9b4ea945c0fa44](https://www.virustotal.com/gui/file/73b097c610daf7136b9b4ea945c0fa44)|Win64 DLL|Kryptik|2019-11-21 21:57:18|strikefM2RYF.data|
|[4a13d87f18af155998308590e3a488e6](https://www.virustotal.com/gui/file/4a13d87f18af155998308590e3a488e6)|Win64 DLL|Kryptik|2019-11-18 14:48:36|strike3i4TLD.data|
|[c91268989ede3ab737fdcd71cea19d60](https://www.virustotal.com/gui/file/c91268989ede3ab737fdcd71cea19d60)|Win32 DLL|Ursu|2019-07-03 18:53:47|strikez4icIW.data|
|[d744b176835cd0093ee54a687eb80f3a](https://www.virustotal.com/gui/file/d744b176835cd0093ee54a687eb80f3a)|Win32 DLL|Kryptik|2019-07-03 15:59:59|strike0SqttM.dll|
|[07328ad6efcf16b532499cbb8daa7633](https://www.virustotal.com/gui/file/07328ad6efcf16b532499cbb8daa7633)|Win32 DLL|Ursu|2019-03-17 16:25:56|strikezIR1CF.data|
|[23dad71a3a55208d944c822c627d1a56](https://www.virustotal.com/gui/file/23dad71a3a55208d944c822c627d1a56)|RTF||2018-11-28 09:19:31|strikemHrIyh.data|
|[d8c9a9a8e8d7e8007c71aa72811b60f3](https://www.virustotal.com/gui/file/d8c9a9a8e8d7e8007c71aa72811b60f3)|Win32 EXE||2018-05-23 08:55:40|svchost.exe|
|[bffc3e2b7382d093fb7440cabbd7b1ba](https://www.virustotal.com/gui/file/bffc3e2b7382d093fb7440cabbd7b1ba)|Win32 DLL|Tiggre|2017-09-11 09:28:21|E:\sample\VTExpolit\2017-9-5\xxx\decry.tmp|
