**NAME:**  
Darkhotel  
  
**Alias**  
Inexsmar, DUBNIUM, Fallout Team, Karba, Luder, Nemim, Tapaoux, APT-C-06, Darkhotel  
  
**Description**:   
The activities of the DarkHotel APT actor came to light in November 2014, when Kaspersky published a report detailing a sophisticated cyberespionage campaign targeting business travelers in the Asia-Pacific region. The group has been around for nearly a decade and some researchers believe its members are Korean speakers.
The attackers targeted their victims using several methods, including through their hotel’s Wi-Fi, zero-day exploits and peer-to-peer (P2P) file sharing websites.
DarkHotel victims have been spotted in several countries, including North Korea, Russia, South Korea, Japan, Bangladesh, Thailand, Taiwan, China, the United States, India, Mozambique, Indonesia and Germany. Spear-phishing attacks are carried out by DarkHotel in recent years. Sever VBScript 0-day exploits were also used in the year of 2018.

  
**References**:  
https://www.anquanke.com/post/id/107813
