|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c5398516578328a835d9717421c5617b](https://www.virustotal.com/gui/file/c5398516578328a835d9717421c5617b)|Win32 EXE||2019-10-07 17:01:50|pcalua.exeHLegalCopyright|
|[fccaaab898715da863f24ba4a15656e8](https://www.virustotal.com/gui/file/fccaaab898715da863f24ba4a15656e8)|Win64 EXE||2019-10-06 18:11:47|sshkeypairgen.exe|
|[9e710dc0de8d39394109bc8d9a1f2a6e](https://www.virustotal.com/gui/file/9e710dc0de8d39394109bc8d9a1f2a6e)|Win32 EXE||2019-10-06 08:53:22|24b587280810fba9_srdsyncr.exe|
|[90921b35bb51c8db8f4fef6988d9fac2](https://www.virustotal.com/gui/file/90921b35bb51c8db8f4fef6988d9fac2)|Win32 EXE|Quasar|2019-08-22 07:51:30| |
|[bd50caef3fac72d7e29e90ee76b8c361](https://www.virustotal.com/gui/file/bd50caef3fac72d7e29e90ee76b8c361)|Win64 DLL||2019-08-22 07:47:05| |
|[d7f0cee4a3ca878e24c770b0a1874920](https://www.virustotal.com/gui/file/d7f0cee4a3ca878e24c770b0a1874920)|Win64 DLL||2019-08-22 07:32:32|d10c93adca609951266b33869dfa47ef5128e4f2a2a90856a2b0f6f178724ddc.bin|
|[dc8e7ee271e5f6ae7f1ed59021c95ef3](https://www.virustotal.com/gui/file/dc8e7ee271e5f6ae7f1ed59021c95ef3)|RTF|CVE-2017-0199|2019-07-18 12:02:58|msf.doc|
|[3d4d475838093afe2bffe891c34f3aca](https://www.virustotal.com/gui/file/3d4d475838093afe2bffe891c34f3aca)|GZIP||2019-07-10 22:07:33| |
|[8d44f75dc327548bb9025e0146f550db](https://www.virustotal.com/gui/file/8d44f75dc327548bb9025e0146f550db)|Win32 EXE|Zbot|2019-06-16 04:12:54|cryptsvccore.exe|
|[1a5c097878a6517d1b05fd21273b612f](https://www.virustotal.com/gui/file/1a5c097878a6517d1b05fd21273b612f)|Win32 EXE||2019-06-10 18:14:53|cp_cdis32.exe|
|[2d0e30a451b0efaa54313893703ae880](https://www.virustotal.com/gui/file/2d0e30a451b0efaa54313893703ae880)|Win32 EXE||2019-06-10 18:13:12|2d0e30a451b0efaa54313893703ae880.virobj|
|[f6584a8c185ba41c1072e31212f823d0](https://www.virustotal.com/gui/file/f6584a8c185ba41c1072e31212f823d0)|Win32 EXE||2019-06-10 14:31:25|Wextract|
|[bee1922ece9faf945278ba85a6544c6c](https://www.virustotal.com/gui/file/bee1922ece9faf945278ba85a6544c6c)|Win32 EXE||2019-06-10 14:31:23| |
|[f822ee5fb8e80585dcdd921bff143d4b](https://www.virustotal.com/gui/file/f822ee5fb8e80585dcdd921bff143d4b)|Win32 EXE||2019-06-10 14:31:21| |
|[6516880e48b4b0a0f1c2709d0be01203](https://www.virustotal.com/gui/file/6516880e48b4b0a0f1c2709d0be01203)|Win32 EXE||2019-06-10 14:30:26|Wextract|
|[e0c2e4949d4a6317d13b8db3d4c50749](https://www.virustotal.com/gui/file/e0c2e4949d4a6317d13b8db3d4c50749)|Win32 EXE||2019-06-10 14:28:45| |
|[a8e5b289c1353efc476c476085a122ec](https://www.virustotal.com/gui/file/a8e5b289c1353efc476c476085a122ec)|Win32 EXE||2019-06-10 14:26:04| |
|[6d40880a890cc92515855387f6e80bba](https://www.virustotal.com/gui/file/6d40880a890cc92515855387f6e80bba)|Win64 EXE||2019-03-15 17:25:36|mbmob.exe|
|[978ba6be4df6ba3ce8c88682e50f7e19](https://www.virustotal.com/gui/file/978ba6be4df6ba3ce8c88682e50f7e19)|Win32 EXE||2019-03-15 14:59:06|Sili Anti Virus Scanner.exe|
|[26ee6f7c33a40eb215b27340313c54cf](https://www.virustotal.com/gui/file/26ee6f7c33a40eb215b27340313c54cf)|RAR||2019-03-15 11:08:48|Unconfirmed 10525.crdownload|
|[70836f372a288014caea9ea779075910](https://www.virustotal.com/gui/file/70836f372a288014caea9ea779075910)|Win32 DLL||2019-03-08 18:13:52|myfile.exe|
|[cdf37af3853963438303f01f57d388d1](https://www.virustotal.com/gui/file/cdf37af3853963438303f01f57d388d1)|Win32 DLL||2019-03-08 07:40:40|myfile.exe|
|[d0694de0547b56a2da64966fab10dab6](https://www.virustotal.com/gui/file/d0694de0547b56a2da64966fab10dab6)|Win32 EXE||2019-03-08 02:18:22|DirectX11.exe|
|[cec4001f640f8993895a7cda682479a4](https://www.virustotal.com/gui/file/cec4001f640f8993895a7cda682479a4)|Win32 DLL|Konni|2018-08-30 11:40:28|codexgigas_be99b95e8051471f3eb7439ded9cc82801997eb7|
|[2730e5e390cb1f579e73911edf91b04b](https://www.virustotal.com/gui/file/2730e5e390cb1f579e73911edf91b04b)|DOC||2018-08-30 08:34:31|Pompeo tells China continued North Korea sanctions enforcement needed.doc|
|[468f0d5e987430384e4e8220df2e8584](https://www.virustotal.com/gui/file/468f0d5e987430384e4e8220df2e8584)|DOC||2018-08-01 07:53:13|article.doc|
|[66f24890c29353ae661f2d11be5336af](https://www.virustotal.com/gui/file/66f24890c29353ae661f2d11be5336af)|DOC||2018-07-29 10:08:04| |
|[c99478a064e90b2100e4275f93999def](https://www.virustotal.com/gui/file/c99478a064e90b2100e4275f93999def)|DOC||2018-07-03 11:07:10|中国移动广东公司ICT业务管理办法（2016试行）.doc|
|[64c4d56457516a646d10732f24214cf2](https://www.virustotal.com/gui/file/64c4d56457516a646d10732f24214cf2)|Win32 DLL||2018-05-08 00:30:20|/home/virustotal/sample/64C4D56457516A646D10732F24214CF2|
|[b48ddad351dd16e4b24f3909c53c8901](https://www.virustotal.com/gui/file/b48ddad351dd16e4b24f3909c53c8901)|RTF|CVE-2018-8174|2018-04-18 06:50:30|exp.doc_|
|[4b60d6bd743d0065b9d35075b9ad0dcc](https://www.virustotal.com/gui/file/4b60d6bd743d0065b9d35075b9ad0dcc)|Win32 EXE|Asruex|2018-02-16 16:32:35|winssmngr.exe|
|[28e434a304e99d3b01ae8ac557c8f256](https://www.virustotal.com/gui/file/28e434a304e99d3b01ae8ac557c8f256)|Win32 DLL|ursu|2018-01-04 04:30:12|ab49f9f8a5f0e07f0f229ad7667536e09ac155f7|
|[560d68c31980c26d2adab7406b61c651](https://www.virustotal.com/gui/file/560d68c31980c26d2adab7406b61c651)|Win32 EXE||2017-12-31 21:07:38|560d68c31980c26d2adab7406b61c651|
|[da0717899e3ccc1ba0e8d32774566219](https://www.virustotal.com/gui/file/da0717899e3ccc1ba0e8d32774566219)|unknown||2017-12-31 21:05:33|da0717899e3ccc1ba0e8d32774566219|
|[3dab0965ab27825ac10b3d8f50db86b6](https://www.virustotal.com/gui/file/3dab0965ab27825ac10b3d8f50db86b6)|Win32 EXE||2017-10-18 06:51:16|docto.exe|
|[e1312f6cab732d3073d788eb6273f6ce](https://www.virustotal.com/gui/file/e1312f6cab732d3073d788eb6273f6ce)|Win32 EXE|Asruex|2017-09-26 11:10:18|winssmngr.exe|
|[cf25bcd08845c4fccc5c57a738ab2c2b](https://www.virustotal.com/gui/file/cf25bcd08845c4fccc5c57a738ab2c2b)|Win32 EXE||2017-09-26 10:51:48|C:/Users/seongmin/Documents/VT2/malware/20170930/cf25bcd08845c4fccc5c57a738ab2c2b.vir|
|[db5748a2e8165e04dd09f35b61ed3abe](https://www.virustotal.com/gui/file/db5748a2e8165e04dd09f35b61ed3abe)|Win32 EXE|Zbot|2017-04-20 18:10:31|db5748a2e8165e04dd09f35b61ed3abe.bi|
|[9d1f784766ec154645bdf33cad211048](https://www.virustotal.com/gui/file/9d1f784766ec154645bdf33cad211048)|Win32 EXE||2016-09-29 06:57:26|coordination_assoc.scr|
|[cc1d0d69ad6cca26b0bda6f3e65597c5](https://www.virustotal.com/gui/file/cc1d0d69ad6cca26b0bda6f3e65597c5)|Win32 EXE|Zbot|2016-08-17 05:10:43|mzdsyncx.exe|
|[799c4e3af539cc3461f9f4faebf26485](https://www.virustotal.com/gui/file/799c4e3af539cc3461f9f4faebf26485)|Win32 EXE|Asruex|2016-08-02 21:26:09|winssmngr.exe|
|[bc99344bcd686ba01e6d282dab7128f0](https://www.virustotal.com/gui/file/bc99344bcd686ba01e6d282dab7128f0)|Win32 EXE||2016-07-31 18:00:17|WFP DPR Korea Country Brief (2016 July) Nutrition Support- Quarterly Monitoring Report in DPR Korea.scr|
|[977e4a2d13ab39a830eaabf01edc6d2d](https://www.virustotal.com/gui/file/977e4a2d13ab39a830eaabf01edc6d2d)|Win32 EXE||2016-07-13 13:40:11|977e4a2d13ab39a830eaabf01edc6d2d.virus|
|[f559586fd2061651e2ac6142b3256206](https://www.virustotal.com/gui/file/f559586fd2061651e2ac6142b3256206)|Win32 EXE||2016-07-05 15:12:25|4a5807bab603d3a0a5d36aaec75729310928a9a5|
|[1a70d7f1699e89c39f0917c2914830c9](https://www.virustotal.com/gui/file/1a70d7f1699e89c39f0917c2914830c9)|Win32 EXE||2016-07-03 16:50:31|1a70d7f1699e89c39f0917c2914830c9.virus|
|[9d0678cbc6f3fc3cecd4fff5a4ac3fee](https://www.virustotal.com/gui/file/9d0678cbc6f3fc3cecd4fff5a4ac3fee)|DOC||2016-06-27 11:56:59|Pyongyang Directory Group email JUNE 2016.doc|
|[9a92851c19be7a11b4f4dc6f88d4552f](https://www.virustotal.com/gui/file/9a92851c19be7a11b4f4dc6f88d4552f)|Win32 EXE||2016-06-16 11:17:30|mfgtsys.exe|
|[378675331f2042bf9113ad8312e9216a](https://www.virustotal.com/gui/file/378675331f2042bf9113ad8312e9216a)|Win32 EXE||2016-06-16 03:15:11|nrcgtrx.exe|
|[43f3b56c1c01b007c35197c703e4d6a6](https://www.virustotal.com/gui/file/43f3b56c1c01b007c35197c703e4d6a6)|Win32 EXE||2016-05-10 05:19:16|DSC3013.JPG.scr|
|[a205a28221c944e4d7e6afbff7f0c4e4](https://www.virustotal.com/gui/file/a205a28221c944e4d7e6afbff7f0c4e4)|Win32 EXE||2016-04-21 02:03:40|localfile~|
|[5ebfaf2316f6afd576d3c0cbaa5c9c1a](https://www.virustotal.com/gui/file/5ebfaf2316f6afd576d3c0cbaa5c9c1a)|LNK||2016-04-19 02:03:20|document.docx.lnk|
|[31eca1a31c283f0f345c83fb4f8f7b0b](https://www.virustotal.com/gui/file/31eca1a31c283f0f345c83fb4f8f7b0b)|LNK||2016-04-11 23:39:05|item.doc.lnk|
|[cc1de300172e2ec019f4d18fb33c6e1b](https://www.virustotal.com/gui/file/cc1de300172e2ec019f4d18fb33c6e1b)|Win32 EXE|Asruex|2016-04-04 20:27:16|mgrscfx.exe|
|[bea023cb4d32673dc9190b13c11df722](https://www.virustotal.com/gui/file/bea023cb4d32673dc9190b13c11df722)|Win32 EXE|Asruex|2016-03-23 06:39:00|wmscfx.exe|
|[05cef548b861c1f20f033b0adf536522](https://www.virustotal.com/gui/file/05cef548b861c1f20f033b0adf536522)|Win32 EXE|Zbot|2016-03-22 06:32:56|38.vir|
|[265f2c45f5dd6b970117e70e0aa93602](https://www.virustotal.com/gui/file/265f2c45f5dd6b970117e70e0aa93602)|Win32 EXE|Zbot|2016-02-25 01:58:48|cb3086f64dda4a5525ed883f99405c00893d2377|
|[c4af339469ef48f976aca34d6d3714a0](https://www.virustotal.com/gui/file/c4af339469ef48f976aca34d6d3714a0)|LNK||2016-02-24 15:43:34|article_draft.docx.lnk|
|[420190e59899d4401e07b1c0f5c7361c](https://www.virustotal.com/gui/file/420190e59899d4401e07b1c0f5c7361c)|Win32 EXE|Asruex|2016-02-18 19:07:18|out.gif.decrypted|
|[c0cd485d33c872568fd54dae92d7d683](https://www.virustotal.com/gui/file/c0cd485d33c872568fd54dae92d7d683)|Win32 DLL||2016-02-18 19:04:59|banana.jpg.decrypted|
|[ba0d4ebc43f559a040d4b82a08fcb6b9](https://www.virustotal.com/gui/file/ba0d4ebc43f559a040d4b82a08fcb6b9)|Win32 EXE||2016-02-12 06:18:38| |
|[eca4a364021b7449bc2288d6779f3909](https://www.virustotal.com/gui/file/eca4a364021b7449bc2288d6779f3909)|LNK||2016-02-08 16:32:36|document.docx.lnk|
|[e568aad37fd662b228b83d6168c538b4](https://www.virustotal.com/gui/file/e568aad37fd662b228b83d6168c538b4)|Win32 EXE||2016-02-05 18:50:47|e568aad37fd662b228b83d6168c538b4.virus|
|[f29a12d33d50b87872b55f241ee9c55d](https://www.virustotal.com/gui/file/f29a12d33d50b87872b55f241ee9c55d)|Win32 EXE|ASRUEX|2016-02-04 13:09:33|wrmscnd.exe|
|[3acdef50a42d038de579f5ced74eb97f](https://www.virustotal.com/gui/file/3acdef50a42d038de579f5ced74eb97f)|Win32 EXE|Zbot|2016-02-01 00:25:08|16f0b05d5e8546ab_vinmts.exe|
|[9e1574342f042501f8fa00adbd6707c8](https://www.virustotal.com/gui/file/9e1574342f042501f8fa00adbd6707c8)|Win32 EXE|Asruex|2016-01-30 22:08:08|9e1574342f042501f8fa00adbd6707c8.virus|
|[fe8b411eab82a5169a262a601025f186](https://www.virustotal.com/gui/file/fe8b411eab82a5169a262a601025f186)|Win32 EXE||2016-01-29 07:10:23|vinmts.exe|
|[367b34b33d0752fa6d8cbbb49a255569](https://www.virustotal.com/gui/file/367b34b33d0752fa6d8cbbb49a255569)|Win32 EXE|Asruex|2016-01-29 05:46:02|dmvwrx.exe|
|[ce379e13bcc3c85650050cc32983ba02](https://www.virustotal.com/gui/file/ce379e13bcc3c85650050cc32983ba02)|LNK||2016-01-28 22:54:49| |
|[46cd2305c3802f86c6471ac89e2a3512](https://www.virustotal.com/gui/file/46cd2305c3802f86c6471ac89e2a3512)|Win32 EXE|Zbot|2016-01-27 00:47:29|sshkeypairgen.exe|
|[a5ec201b518ce52c50cd8175ad79d5ea](https://www.virustotal.com/gui/file/a5ec201b518ce52c50cd8175ad79d5ea)|Win32 EXE|Zbot|2016-01-13 11:41:55|sshkeypairgen.exe|
|[d0399ca4c86909bc03ccf470534264c5](https://www.virustotal.com/gui/file/d0399ca4c86909bc03ccf470534264c5)|Win32 EXE|zapchast|2016-01-08 00:51:38|a25715108d2859595959879ff50085bc85969e9473ecc3d26dda24c4a17822c9.exe|
|[5f4c355c95927c5712e9deacd31a2fa8](https://www.virustotal.com/gui/file/5f4c355c95927c5712e9deacd31a2fa8)|Win32 EXE|zapchast|2016-01-08 00:51:05|41ecd81bc7df4b47_kernelol21.exe|
|[33c8a13ea2400806032b516ecfca743c](https://www.virustotal.com/gui/file/33c8a13ea2400806032b516ecfca743c)|Win32 EXE|Asruex|2016-01-05 10:11:24|doclog.exe|
|[d8a06811385e0fd463f215a43b366169](https://www.virustotal.com/gui/file/d8a06811385e0fd463f215a43b366169)|Win32 EXE|Zbot|2016-01-04 22:20:56|sshkeypairgen.exe|
|[06d9330a56373d4bc4f57e28b8827ed5](https://www.virustotal.com/gui/file/06d9330a56373d4bc4f57e28b8827ed5)|Flash||2015-12-29 23:53:37|0day.swf|
|[f882d730fa85c0659a1ebd88815a0cc8](https://www.virustotal.com/gui/file/f882d730fa85c0659a1ebd88815a0cc8)|Win32 EXE|Zbot|2015-12-19 08:29:29|svchosz|
|[eac466fb9be8f98c29bfe513949f2ab5](https://www.virustotal.com/gui/file/eac466fb9be8f98c29bfe513949f2ab5)|Win64 EXE||2015-11-30 06:02:19|RsaGen.exe|
|[891b5bbc60fab52620e446dcc0d85bda](https://www.virustotal.com/gui/file/891b5bbc60fab52620e446dcc0d85bda)|Win32 EXE||2015-11-25 08:06:01|mzdsyncx.exe|
|[5825372c87662c5b91f2b5080add9485](https://www.virustotal.com/gui/file/5825372c87662c5b91f2b5080add9485)|Win32 EXE||2015-11-19 18:30:17| |
|[4757414f3602eb5ff55b232faf383e80](https://www.virustotal.com/gui/file/4757414f3602eb5ff55b232faf383e80)|LNK||2015-11-10 05:35:05|photo.docx.lnk|
|[85d6d17c3005cf1b0793e6519b60f80b](https://www.virustotal.com/gui/file/85d6d17c3005cf1b0793e6519b60f80b)|Win32 EXE|Zbot|2015-11-06 08:59:44|2273236013c1ae52_doclog.exe|
|[caa34b1ce08ba3ab9d7f6b4e74bd18af](https://www.virustotal.com/gui/file/caa34b1ce08ba3ab9d7f6b4e74bd18af)|Win32 EXE||2015-11-04 16:18:35|c:\users\vt2\appdata\roaming\microsoft\common\explorers.exe|
|[7a32b39ac104071ddeb65acd27633c16](https://www.virustotal.com/gui/file/7a32b39ac104071ddeb65acd27633c16)|Win32 EXE||2015-11-04 07:49:21|doclog.exe|
|[311cba24e343f03e02521c0af1892ecb](https://www.virustotal.com/gui/file/311cba24e343f03e02521c0af1892ecb)|LNK||2015-10-21 03:34:16|sample.doc.lnk|
|[85d57879afe9bbcf270ef320d359198b](https://www.virustotal.com/gui/file/85d57879afe9bbcf270ef320d359198b)|Win32 EXE|ASRUEX|2015-10-20 15:51:55|taskmgdo.exe|
|[6decdbe40d7fbc522cf433c0f521ed6d](https://www.virustotal.com/gui/file/6decdbe40d7fbc522cf433c0f521ed6d)|Win32 EXE|Reconyc|2015-10-08 08:20:37|svchosf.exe|
|[b1f56a54309147b07dda54623fecbb89](https://www.virustotal.com/gui/file/b1f56a54309147b07dda54623fecbb89)|Win32 EXE|Zbot|2015-08-10 15:42:18|cryptshellmng.exe|
|[4d84720998eb6e358a1671f6eb1ef74e](https://www.virustotal.com/gui/file/4d84720998eb6e358a1671f6eb1ef74e)|Win32 EXE|Zbot|2015-07-29 14:35:21|cryptshellmng.exe|
|[61cc019c3141281073181c4ef1f4e524](https://www.virustotal.com/gui/file/61cc019c3141281073181c4ef1f4e524)|Win32 EXE|Zbot|2015-07-10 03:11:47|cryptsvccore.exe|
|[6b9e9b2dc97ff0b26a8a61ba95ca8ff6](https://www.virustotal.com/gui/file/6b9e9b2dc97ff0b26a8a61ba95ca8ff6)|HTML||2015-06-19 16:45:35|downloader.hta|
|[3d2e941ac48ae9d79380ca0f133f4a49](https://www.virustotal.com/gui/file/3d2e941ac48ae9d79380ca0f133f4a49)|Win32 EXE|Zbot|2015-06-17 09:47:36|cryptsvccore.exe|
|[fc78b15507e920b3ee405f843f48a7b3](https://www.virustotal.com/gui/file/fc78b15507e920b3ee405f843f48a7b3)|Win32 EXE|Zbot|2015-06-01 11:46:31|cryptsvccore.exe|
|[dc0de14d9d36d13a6c8a34b2c583e70a](https://www.virustotal.com/gui/file/dc0de14d9d36d13a6c8a34b2c583e70a)|Win32 EXE|dapato|2015-06-01 03:44:53|letter_‮gpj.scr|
|[5c74db6f755555ea99b51e1c68e796f9](https://www.virustotal.com/gui/file/5c74db6f755555ea99b51e1c68e796f9)|Win32 EXE|dynamer|2015-05-21 11:58:57|C:\Users\David\Desktop\schedule(6.1~6)_‮gpj.scr|
|[c3ae70b3012cc9b5c9ceb060a251715a](https://www.virustotal.com/gui/file/c3ae70b3012cc9b5c9ceb060a251715a)|Win32 EXE|dapato|2015-04-29 06:04:40|x|
|[5e01b8bc78afc6ecb3376c06cbceb680](https://www.virustotal.com/gui/file/5e01b8bc78afc6ecb3376c06cbceb680)|Win32 EXE|Zbot|2015-04-18 03:36:41|test|
|[fa67142728e40a2a4e97ccc6db919f2b](https://www.virustotal.com/gui/file/fa67142728e40a2a4e97ccc6db919f2b)|HTML||2015-04-03 05:19:00|E:\danger\photoviewer.hta-06Aug15.1123.txt|
|[33e278c5ba6bf1a545d45e17f7582512](https://www.virustotal.com/gui/file/33e278c5ba6bf1a545d45e17f7582512)|Win32 EXE||2015-03-27 07:35:23| |
|[da360e94e60267dce08e6d47fc1fcecc](https://www.virustotal.com/gui/file/da360e94e60267dce08e6d47fc1fcecc)|Win32 EXE||2015-03-24 18:52:54|cryptsvccore.exe|
|[77669d11c3248a6553d3c15cd1d8a60e](https://www.virustotal.com/gui/file/77669d11c3248a6553d3c15cd1d8a60e)|Win32 EXE||2015-02-10 11:48:22|77669d11c3248a6553d3c15cd1d8a60e|
|[ca7e5ff32b729d0d61340911a01a479a](https://www.virustotal.com/gui/file/ca7e5ff32b729d0d61340911a01a479a)|Win32 EXE||2014-11-17 01:03:23|ca7e5ff32b729d0d61340911a01a479a|
|[912a8c7cf1ad78cd4543bfb594c7db58](https://www.virustotal.com/gui/file/912a8c7cf1ad78cd4543bfb594c7db58)|Win32 EXE||2014-11-16 18:18:00|rusb|
|[39562e410bc3fb5a30aca8162b20bdd0](https://www.virustotal.com/gui/file/39562e410bc3fb5a30aca8162b20bdd0)|Win32 EXE||2014-10-29 00:12:23|test|
|[e85e0365b6f77cc2e9862f987b152a89](https://www.virustotal.com/gui/file/e85e0365b6f77cc2e9862f987b152a89)|Win32 EXE|dapato|2014-10-14 08:31:30|wcsntzgy.exe|
|[cd1134ad11d21b4626e28cf5a9eb6f0c](https://www.virustotal.com/gui/file/cd1134ad11d21b4626e28cf5a9eb6f0c)|Win32 EXE|Bublik|2014-10-01 04:20:26|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\CD1134AD11D21B4626E28CF5A9EB6F0C|
|[1fcaa239cf4d627078179f6de299f320](https://www.virustotal.com/gui/file/1fcaa239cf4d627078179f6de299f320)|Win32 EXE|tapaoux|2014-09-15 18:44:10|1fcaa239cf4d627078179f6de299f320.virobj|
|[852a9411a949add69386a72805c8cb05](https://www.virustotal.com/gui/file/852a9411a949add69386a72805c8cb05)|HTML||2014-08-23 19:20:44|38500359|
|[fe95141837ae86cb02a1bbf6a070cbb4](https://www.virustotal.com/gui/file/fe95141837ae86cb02a1bbf6a070cbb4)|Win32 EXE|ursu|2014-08-02 03:38:15|Explorer System Checker|
|[c49e6114fa3de4f823010e852d891896](https://www.virustotal.com/gui/file/c49e6114fa3de4f823010e852d891896)|Win32 EXE||2014-07-26 08:46:55|Catch.exe|
|[131c625a92dc721c5d4dae3fb65591fc](https://www.virustotal.com/gui/file/131c625a92dc721c5d4dae3fb65591fc)|Win32 DLL||2014-05-06 08:09:36|DLL|
|[12b88e36170472413a49ae71b1ac9a33](https://www.virustotal.com/gui/file/12b88e36170472413a49ae71b1ac9a33)|Win32 EXE|johnnie|2014-05-02 16:13:31|Catch.exe|
|[ad6fa828b6402befb66caaa44032ef87](https://www.virustotal.com/gui/file/ad6fa828b6402befb66caaa44032ef87)|Win32 EXE|Banload|2014-04-28 17:40:09|~.dat|
|[ede6a67f7956686f753819c46f496c84](https://www.virustotal.com/gui/file/ede6a67f7956686f753819c46f496c84)|Win32 EXE|jatif|2014-04-19 21:46:00|KernelMode.info_76b9b9b82e695719e6fcf6742ac828c606241da2424c7e9ce9d0f8bacc4fcff4.ViR|
|[4d9460e990da5b37a5bfffd47c22755a](https://www.virustotal.com/gui/file/4d9460e990da5b37a5bfffd47c22755a)|DOC|CVE-2012-0158|2014-04-08 08:12:09|Application.doc|
|[2e09cf1f9d2182dee048ec8520e2b903](https://www.virustotal.com/gui/file/2e09cf1f9d2182dee048ec8520e2b903)|Win32 EXE|Banload|2014-03-25 18:04:21|tilde.dat|
|[cdb2d7377a0d87e52d07ea24e8b5019d](https://www.virustotal.com/gui/file/cdb2d7377a0d87e52d07ea24e8b5019d)|DOC|CVE-2012-0158|2014-03-24 01:10:44|Application.doc|
|[2aac9d340620da09d96929ba570978c4](https://www.virustotal.com/gui/file/2aac9d340620da09d96929ba570978c4)|Win32 EXE||2014-03-23 15:47:23|Edown_mfc|
|[5f05acd53cfd91fb4dba3660ad1e3add](https://www.virustotal.com/gui/file/5f05acd53cfd91fb4dba3660ad1e3add)|Win32 EXE||2014-03-17 09:43:00|vt-upload-ynu9g|
|[061e3d50125dc78c86302b7cfa7e4935](https://www.virustotal.com/gui/file/061e3d50125dc78c86302b7cfa7e4935)|Win32 EXE||2014-03-06 07:32:23|serve|
|[93283599dbf3b2d47872dafae12afb21](https://www.virustotal.com/gui/file/93283599dbf3b2d47872dafae12afb21)|Win32 EXE||2014-03-06 04:47:18|IGFXSVC.EXE|
|[06ac12b8c51aec71cefcf8a507d82ce4](https://www.virustotal.com/gui/file/06ac12b8c51aec71cefcf8a507d82ce4)|Win32 EXE|Ramnit|2014-02-27 22:10:06|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\06AC12B8C51AEC71CEFCF8A507D82CE4|
|[0393036f35a7102a34fadfd77680b292](https://www.virustotal.com/gui/file/0393036f35a7102a34fadfd77680b292)|Win32 EXE|Ramnit|2014-02-27 09:23:17|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\0393036F35A7102A34FADFD77680B292|
|[032a7c67332a3abf6da179ed265e6e04](https://www.virustotal.com/gui/file/032a7c67332a3abf6da179ed265e6e04)|Win32 EXE||2014-02-26 17:26:38|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\032A7C67332A3ABF6DA179ED265E6E04|
|[043f0dcea6f6fbd1305571e6bf0fa78c](https://www.virustotal.com/gui/file/043f0dcea6f6fbd1305571e6bf0fa78c)|Win32 EXE|Ramnit|2014-02-26 16:21:40|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\043F0DCEA6F6FBD1305571E6BF0FA78C|
|[9eae89f27c8fbc5896fc7e540e4cfd4a](https://www.virustotal.com/gui/file/9eae89f27c8fbc5896fc7e540e4cfd4a)|Win32 EXE||2014-02-26 05:20:23|58fa595933d4de05e586d444a89fa11cc21b3cd8_KernelMode.info_f32cdc8ed6ed1787da7a9d7f9a4110deb419b4fbf20202ea752026abefa5951f.ViR|
|[23f7fe611ed2bd814bbdbfae457150b3](https://www.virustotal.com/gui/file/23f7fe611ed2bd814bbdbfae457150b3)|Win32 EXE|Ramnit|2014-02-26 05:19:05|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\23F7FE611ED2BD814BBDBFAE457150B3|
|[3165b7472a9dd45cde49538561cba59f](https://www.virustotal.com/gui/file/3165b7472a9dd45cde49538561cba59f)|Win32 EXE||2014-02-25 22:02:44|wmisvcctrl.exe|
|[1ec49ae6d535bfb3789d498f4fd0224f](https://www.virustotal.com/gui/file/1ec49ae6d535bfb3789d498f4fd0224f)|Win32 EXE||2014-02-25 19:00:47|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\1EC49AE6D535BFB3789D498F4FD0224F|
|[17c99725043fa1573fd650e57c3c75d3](https://www.virustotal.com/gui/file/17c99725043fa1573fd650e57c3c75d3)|Win32 EXE|Ramnit|2014-02-25 18:25:49|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\17C99725043FA1573FD650E57C3C75D3|
|[058efdf7d94c5da920a3c32cbadac2d0](https://www.virustotal.com/gui/file/058efdf7d94c5da920a3c32cbadac2d0)|Win32 EXE||2014-02-24 17:47:29|Ukino DreamNote|
|[1f9d915d331f7e363c39108f41145c44](https://www.virustotal.com/gui/file/1f9d915d331f7e363c39108f41145c44)|Win32 EXE||2014-02-23 22:25:00|f27e37f7cbbab344559640b37d63c7b1a48fe355_KernelMode.info_f9f7608d46fbdd1b700c69590c8ba913f977e8ae3fd4efd49cf5a82266910381.ViR|
|[a855b983f1f414461de0e813e2f72b24](https://www.virustotal.com/gui/file/a855b983f1f414461de0e813e2f72b24)|Win32 EXE||2014-02-23 21:13:13|e96af17666d488fd2c8212c82e1f4f2a79798b8a_KernelMode.info_5f9d069841b5cacbbc2ec63d6e0055a60e41ea30cc469f9c57ade582dc865635.ViR|
|[9d248e5cc726f2aa2fa4f06566a2d5b8](https://www.virustotal.com/gui/file/9d248e5cc726f2aa2fa4f06566a2d5b8)|Win32 EXE||2014-02-23 18:31:38|Tyakumoto|
|[99a2cca89d044148aa3379cdf2e899fa](https://www.virustotal.com/gui/file/99a2cca89d044148aa3379cdf2e899fa)|Win32 EXE||2014-02-20 21:00:35|8acfeea5875fe9ed2f3ed4fcd45481a42b24c044_KernelMode.info_76e505edb12c9a1f0b1cf70f0e88f68e3116dbad2e759cd7688bda07c9a20692.ViR|
|[98b07144f4f5cc95348b39d6bfaeb56a](https://www.virustotal.com/gui/file/98b07144f4f5cc95348b39d6bfaeb56a)|Win32 EXE||2014-02-20 20:50:19|DC2PC|
|[25102d64dbc9b6495c5713f3178dd7f1](https://www.virustotal.com/gui/file/25102d64dbc9b6495c5713f3178dd7f1)|Win32 EXE||2014-02-15 06:41:59|wmisvcctrl.exe|
|[b44a988d18264735f39efc2001b29c63](https://www.virustotal.com/gui/file/b44a988d18264735f39efc2001b29c63)|Win32 EXE||2014-01-27 17:36:15|8b5147e08b77381f1c067dea849b33f4e6d1c55d550c5db802af851962f44d2d.exe|
|[7a5256dda43cb459e99c0073f1e8f07b](https://www.virustotal.com/gui/file/7a5256dda43cb459e99c0073f1e8f07b)|Win32 EXE||2014-01-27 16:31:39|cfaea52682733dc39d4cd8324abb23e053f23a35_KernelMode.info_12811f786fb3a98c0eeff39d3faabc5824881bcd691fc1cc8f35d7ffaa707c03.ViR|
|[6f1a828a2490099a3ce9f873823cce7c](https://www.virustotal.com/gui/file/6f1a828a2490099a3ce9f873823cce7c)|Win32 EXE||2014-01-27 01:27:09|6F1A828A2490099A3CE9F873823CCE7C|
|[0b727001dfc90cc354bd2ccabe3c23a5](https://www.virustotal.com/gui/file/0b727001dfc90cc354bd2ccabe3c23a5)|Win32 EXE||2014-01-26 02:51:09|b78e8bf3498c500c8f5286aa911890b840a56032_KernelMode.info_90b4088896a05f8e448d76c9df08aa928207319dc898f7136eeca19225047709.ViR|
|[d46204e579808d520affcc71a7d35cda](https://www.virustotal.com/gui/file/d46204e579808d520affcc71a7d35cda)|Win32 EXE||2014-01-25 06:20:34|JoyToKey|
|[0fb91846ab9a4e9667c81154829f888b](https://www.virustotal.com/gui/file/0fb91846ab9a4e9667c81154829f888b)|Win32 EXE||2014-01-25 06:16:56|b4101bdbd0eb2167e79eb2597689ef5927af84e2_KernelMode.info_858ae3350ac3f7fc6ce235536e70b9eee1aef8df95fdc5d90bf67b825171e89a.ViR|
|[e4fe6fa6e540cdb77807401aa2121858](https://www.virustotal.com/gui/file/e4fe6fa6e540cdb77807401aa2121858)|Win32 EXE||2014-01-25 03:27:19|c40debee0e1ca58e2a25ba77d49b0e0175442529_KernelMode.info_0726fe9924c25eeab7665f5a70e1173a7f4008409890c9941f3b5f726d2b257a.ViR|
|[b1048d7d2464f27a19b2adbf310158b1](https://www.virustotal.com/gui/file/b1048d7d2464f27a19b2adbf310158b1)|Win32 EXE||2014-01-21 14:19:10|Catch.exe|
|[b07f6065011621c569fc2decd27056df](https://www.virustotal.com/gui/file/b07f6065011621c569fc2decd27056df)|Win32 EXE||2014-01-21 14:15:56|AxDecrypt.exe|
|[efda0c1d8593d3ab3a7c079b71a0f2bc](https://www.virustotal.com/gui/file/efda0c1d8593d3ab3a7c079b71a0f2bc)|Win32 EXE||2014-01-20 18:15:40|b167ebaca7eb71838aa80fce227a686da9706310_KernelMode.info_d0bc7eab93813faedf262503e231bfd1c7ce6b6feb3614d5d4bd32f32a735727.ViR|
|[0b6caacd4081d3b18e847a40c1b6a7f3](https://www.virustotal.com/gui/file/0b6caacd4081d3b18e847a40c1b6a7f3)|Win32 EXE||2014-01-20 18:03:16|62e9dc0cff017fea47ac0f7f65f86cdc24d9772f_KernelMode.info_d75ac656dd563ee593993b25704a50957d0f247c7a5c21f06aca887d47ab5e1f.ViR|
|[f2231ce84551fbd8a57e75fb07d7f6c0](https://www.virustotal.com/gui/file/f2231ce84551fbd8a57e75fb07d7f6c0)|Win32 EXE||2014-01-20 07:06:13|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\F2231CE84551FBD8A57E75FB07D7F6C0|
|[4f377a8344baa76afe9103ca843e315f](https://www.virustotal.com/gui/file/4f377a8344baa76afe9103ca843e315f)|Win32 EXE||2014-01-18 05:18:08|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\4F377A8344BAA76AFE9103CA843E315F|
|[9f08b8182c987181fe3f3906f7463eac](https://www.virustotal.com/gui/file/9f08b8182c987181fe3f3906f7463eac)|Win32 EXE||2014-01-17 13:24:14|wmisvcctrl.exe|
|[7d304a9cdcda75b1cb9537618f5ed398](https://www.virustotal.com/gui/file/7d304a9cdcda75b1cb9537618f5ed398)|Win32 EXE||2014-01-15 19:32:23|7D304A9CDCDA75B1CB9537618F5ED398.sample|
|[1ef21e634f9779280710e87ff17a83af](https://www.virustotal.com/gui/file/1ef21e634f9779280710e87ff17a83af)|Win32 EXE||2014-01-15 16:44:00|5e868de3ba743865dae56d1949ff7decec495335.codex|
|[68ca3d3fc4901d1af8d3adc3170af6ad](https://www.virustotal.com/gui/file/68ca3d3fc4901d1af8d3adc3170af6ad)|Win32 EXE||2014-01-15 15:54:26|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\68CA3D3FC4901D1AF8D3ADC3170AF6AD|
|[720af0fa1f2633b1b73c278a0a016559](https://www.virustotal.com/gui/file/720af0fa1f2633b1b73c278a0a016559)|Win32 EXE||2014-01-14 12:14:15|IrfanView Installer|
|[c2d00fef0659640c1345967d2f554278](https://www.virustotal.com/gui/file/c2d00fef0659640c1345967d2f554278)|Win32 EXE||2014-01-13 04:49:38|dx_PE_ (839).exe|
|[7bab3a69ab65b90e47d5cc0724531914](https://www.virustotal.com/gui/file/7bab3a69ab65b90e47d5cc0724531914)|Win32 EXE||2014-01-12 22:46:11|KernelMode.info_e921ab8160709c855161070ac6f2143d32893261ffae0f3b7bcbf52a0bc1fb32.ViR|
|[bc6a78142fa68af60e4edc06d28a2f28](https://www.virustotal.com/gui/file/bc6a78142fa68af60e4edc06d28a2f28)|Win32 EXE||2014-01-12 08:04:21|87158d8479b4d9478355eebe72b8cfeaef897ffb_KernelMode.info_95654eb553e3940fcbc82ffa72008d00f8d52faf8c37a712cd40b3aafe970ab2.ViR|
|[e5a31be7717c12a3cf9a173428ac7c38](https://www.virustotal.com/gui/file/e5a31be7717c12a3cf9a173428ac7c38)|Win32 EXE||2014-01-12 03:00:41|Windows 7 Activator.exe|
|[611c4440aa2587f54702e7e58b7be75f](https://www.virustotal.com/gui/file/611c4440aa2587f54702e7e58b7be75f)|Win32 EXE||2014-01-12 00:30:17|uTorrent.exe|
|[6d3839c312976ba96e89ab6a243aef8f](https://www.virustotal.com/gui/file/6d3839c312976ba96e89ab6a243aef8f)|Win32 EXE||2014-01-12 00:27:11|5de81f82bf32106b18adf81e007508a9092ca19b58e4e17796f82578299b19c3.exe|
|[56217179283737f5c46c0a64ebe28a82](https://www.virustotal.com/gui/file/56217179283737f5c46c0a64ebe28a82)|Win32 EXE||2014-01-11 23:27:19|TorBrowser|
|[033d922f3f56f9ea7c976f31107e366a](https://www.virustotal.com/gui/file/033d922f3f56f9ea7c976f31107e366a)|Win32 EXE||2014-01-11 17:23:19|updater.exe|
|[873f26caddfe1e9af18181d8f5f18368](https://www.virustotal.com/gui/file/873f26caddfe1e9af18181d8f5f18368)|Win32 EXE||2014-01-11 15:55:33|TorBrowser|
|[ebe6b78006ecffe1511f46c86d16f4aa](https://www.virustotal.com/gui/file/ebe6b78006ecffe1511f46c86d16f4aa)|Win32 DLL||2014-01-09 22:46:45|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\EBE6B78006ECFFE1511F46C86D16F4AA|
|[ad35db962130becfac1de2f803a119ae](https://www.virustotal.com/gui/file/ad35db962130becfac1de2f803a119ae)|Win32 EXE||2014-01-08 08:13:20|SISTERS|
|[9305008e17b0805118a6a9bb45493441](https://www.virustotal.com/gui/file/9305008e17b0805118a6a9bb45493441)|DOS EXE||2014-01-08 08:10:04|979888ad8da108d8c259207d2c66c3c6c071ad49_KernelMode.info_d6684a4aff4f0706c5a9818fb0b1a5f52cb22531c88d416e5950e28b67adfbdd.ViR|
|[7ad3b74bec51678622e21f57fb82e136](https://www.virustotal.com/gui/file/7ad3b74bec51678622e21f57fb82e136)|Win32 EXE||2014-01-08 07:19:28|8451a774e40be182504e4a82852af45074cfb16e_KernelMode.info_578cc3d6721db808eded6cde770f75c3cfcadeab323fab5871f44b201ce0a894.ViR|
|[752c351778a8a18245f132dafdc54599](https://www.virustotal.com/gui/file/752c351778a8a18245f132dafdc54599)|Win32 EXE||2014-01-08 07:16:48|gbgcupdate.exe|
|[8def236d23dea950d9b1b222cb9a463a](https://www.virustotal.com/gui/file/8def236d23dea950d9b1b222cb9a463a)|Win32 EXE||2014-01-08 00:09:31|unity-helper|
|[729a2f6c7e95075ff36947bc5811a5d3](https://www.virustotal.com/gui/file/729a2f6c7e95075ff36947bc5811a5d3)|Win32 EXE||2014-01-07 23:54:32|Autorun|
|[69fa0bfd74d0db4ad734b9944ea71ec3](https://www.virustotal.com/gui/file/69fa0bfd74d0db4ad734b9944ea71ec3)|Win32 EXE||2014-01-07 21:16:41|3d4d67709b3b36dd09d6db5a9b2f74602abfa6be.codex|
|[e2ed43a6bbb72c927a4e083768e47254](https://www.virustotal.com/gui/file/e2ed43a6bbb72c927a4e083768e47254)|Win32 EXE||2014-01-07 20:40:00|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\E2ED43A6BBB72C927A4E083768E47254|
|[53bc1a9d19aae7f783e019ec7613c366](https://www.virustotal.com/gui/file/53bc1a9d19aae7f783e019ec7613c366)|Win32 DLL||2014-01-07 16:52:07|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\53BC1A9D19AAE7F783E019EC7613C366|
|[1d399370e82b314ba20c21ff4ee82205](https://www.virustotal.com/gui/file/1d399370e82b314ba20c21ff4ee82205)|Win32 EXE||2014-01-06 07:29:17|SIW|
|[4e8ea6bfacf9766f25af12fd63b16ce9](https://www.virustotal.com/gui/file/4e8ea6bfacf9766f25af12fd63b16ce9)|Win32 EXE||2014-01-02 23:02:12|MsiX|
|[043c84cef3e011e3dc731d643a205f4e](https://www.virustotal.com/gui/file/043c84cef3e011e3dc731d643a205f4e)|Win32 EXE||2013-12-31 11:49:08|00b45c5d3da2bb33336a196bed0545c01c78d1c8.codex|
|[a47f6878da6480089c2ff3bdddbd7104](https://www.virustotal.com/gui/file/a47f6878da6480089c2ff3bdddbd7104)|Win32 EXE|tapaoux|2013-12-28 00:33:15|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A47F6878DA6480089C2FF3BDDDBD7104|
|[7f608ebfb9b1c81cb07eb8f26fd7647a](https://www.virustotal.com/gui/file/7f608ebfb9b1c81cb07eb8f26fd7647a)|Win32 EXE||2013-12-21 17:08:17|TextBoxTool.exe|
|[9c3b06ab28840239cf1d0ecf4a45f6f4](https://www.virustotal.com/gui/file/9c3b06ab28840239cf1d0ecf4a45f6f4)|Win32 EXE||2013-12-21 10:31:43|Systray-gDock|
|[42b9fea2ec56a90cefeecee3c84aade0](https://www.virustotal.com/gui/file/42b9fea2ec56a90cefeecee3c84aade0)|Win32 EXE||2013-12-19 19:33:14|KernelMode.info_58cfecb2308cdabb356371649ac082a127879290b20edba05ab75561671b52c5.ViR|
|[e52b7d5391152da89b1db64060ba96ae](https://www.virustotal.com/gui/file/e52b7d5391152da89b1db64060ba96ae)|Win32 EXE||2013-12-17 21:54:42|b12e475911e8464ce1b3389200f1473d551bb62c_KernelMode.info_9bfa356f71859ff0a0c97136cc795ed56edb0966e826c7bd988b89adafaaa971.ViR|
|[c25d146b4cf05f7aaa9aebbe8d1563db](https://www.virustotal.com/gui/file/c25d146b4cf05f7aaa9aebbe8d1563db)|Win32 EXE||2013-12-17 15:31:53|BFVComponent.exe|
|[6f7ec5ff103e4ee038a54816c6b9bc09](https://www.virustotal.com/gui/file/6f7ec5ff103e4ee038a54816c6b9bc09)|Win32 EXE||2013-12-16 08:41:19|290d4cb961aa6537e7afee820bdb08cb504fc901_KernelMode.info_275035630745793d55693edfb537775534ca75f4344c84b4b2d4047f6b71ddb6.ViR|
|[67b96c2265e44ccfad708c9387570ab4](https://www.virustotal.com/gui/file/67b96c2265e44ccfad708c9387570ab4)|Win32 EXE||2013-12-12 16:33:43|63781eba646820246d53d3b8d0d68903faa96fa5_KernelMode.info_1929616f0e2574e320e010dc5cef87f9affe2813b2238aeed6c10e67f7f8e480.ViR|
|[f7d0d5fc6b01a2e0f3a1c021bab49437](https://www.virustotal.com/gui/file/f7d0d5fc6b01a2e0f3a1c021bab49437)|Win32 EXE||2013-12-12 07:24:58|e3b3075c2dda893c78205bd830f81d61bf82478f_KernelMode.info_39bc909ff15a2b6987a53e9a836e0ed9426aeda4b34e41d5639afa39d306dc70.ViR|
|[b164febacafd2ab33f203fc5faecd531](https://www.virustotal.com/gui/file/b164febacafd2ab33f203fc5faecd531)|Win32 EXE||2013-12-12 05:43:20|pureplayer|
|[9a56bb6c022b3a2ab40d2b308ddf7015](https://www.virustotal.com/gui/file/9a56bb6c022b3a2ab40d2b308ddf7015)|Win32 EXE||2013-12-12 04:55:18|0bd189e1b0482b021dad59ea33c3fb8efdb3692a.codex|
|[9978ced410a7dfd3a21ff59cbe1e4303](https://www.virustotal.com/gui/file/9978ced410a7dfd3a21ff59cbe1e4303)|Win32 EXE||2013-12-12 03:16:19|7516894fe87166a699be782791515586cd0dc9c8_KernelMode.info_657b4e98139bd4e816caab0eaae7d0c3461e08e61ad1970a82114603108f5f0e.ViR|
|[51c1b9b3df00de5e08c4aa3a2b864a54](https://www.virustotal.com/gui/file/51c1b9b3df00de5e08c4aa3a2b864a54)|Win32 EXE||2013-12-09 12:00:23|KernelMode.info_949b1c4b06399b3a392e59e798e73d8aa2f6b42a2088fdfa219b01b117f10dc5.ViR|
|[a1467e57ea55030e45325d3987db9fca](https://www.virustotal.com/gui/file/a1467e57ea55030e45325d3987db9fca)|Win32 EXE||2013-12-05 04:35:09|6420d9a77b8daf81acccf13272d3c69c17b54f39_KernelMode.info_d208de537f267c2f85ce4da78bd41692fb97371f1782d36c50072c190dd579e2.ViR|
|[378177ddc1fd7d213b79c033da26327d](https://www.virustotal.com/gui/file/378177ddc1fd7d213b79c033da26327d)|Win32 EXE||2013-12-04 05:00:03|Catch.exe|
|[dd6c020e4a9c112c1776215b763f7525](https://www.virustotal.com/gui/file/dd6c020e4a9c112c1776215b763f7525)|Win32 EXE||2013-12-04 00:31:03|x3|
|[be7acfaf90c8fab44393345704dd2b69](https://www.virustotal.com/gui/file/be7acfaf90c8fab44393345704dd2b69)|Win32 EXE||2013-12-03 23:50:37|ssasv.exe|
|[6acd47c45a3e031411af351b3be5f82e](https://www.virustotal.com/gui/file/6acd47c45a3e031411af351b3be5f82e)|Win32 EXE||2013-12-03 15:54:41|Blader|
|[1ee6676e122fcd22e80b6ae0dc40c979](https://www.virustotal.com/gui/file/1ee6676e122fcd22e80b6ae0dc40c979)|Win32 EXE||2013-12-03 15:53:34|KernelMode.info_6102993eb00bd97832b74fd802b486abb7cb43712eccfe14c904413483c6df7f.ViR|
|[3260c9f881eb815b7ef3f5f295fc5174](https://www.virustotal.com/gui/file/3260c9f881eb815b7ef3f5f295fc5174)|Win32 DLL||2013-12-03 15:53:26|inspire.dll|
|[2431db868ebec1b967f5ad38abfd95c4](https://www.virustotal.com/gui/file/2431db868ebec1b967f5ad38abfd95c4)|Win32 EXE||2013-12-03 12:46:03|TipsExtend|
|[a6b0406dff68430aac6a5b738731e7d0](https://www.virustotal.com/gui/file/a6b0406dff68430aac6a5b738731e7d0)|Win32 EXE||2013-12-02 10:11:23|AliFileCheck.exe|
|[d73b08376c7cdf355d31b05a71c8c5ba](https://www.virustotal.com/gui/file/d73b08376c7cdf355d31b05a71c8c5ba)|Win32 EXE||2013-12-01 02:43:39|bf222e0a028a2bcbf6d4df529beea5db185fa97d_KernelMode.info_37a7ec5b6ff7733257634df01004c6d3cfa859fd7770fe9b1f06a6459f57d350.ViR|
|[f7084cf91278eb8176c815ec4e269851](https://www.virustotal.com/gui/file/f7084cf91278eb8176c815ec4e269851)|Win32 EXE|johnnie|2013-12-01 00:07:29|Catch.exe|
|[0d3e3fd44faa32e0d83b02c8b7cff49c](https://www.virustotal.com/gui/file/0d3e3fd44faa32e0d83b02c8b7cff49c)|Win32 EXE||2013-11-30 18:10:28|360AutoClean|
|[9bc355cbb5473f4f248f3e2be028ec0b](https://www.virustotal.com/gui/file/9bc355cbb5473f4f248f3e2be028ec0b)|Win32 EXE|johnnie|2013-11-28 10:04:13|Catch.exe|
|[57dfd2ec5401d9a3d68b4d125e1eb308](https://www.virustotal.com/gui/file/57dfd2ec5401d9a3d68b4d125e1eb308)|Win32 EXE|pswtool|2013-11-26 20:15:47|IGFXSVC.EXE|
|[aaeb3b0651720a3f37a0c2f57c92429c](https://www.virustotal.com/gui/file/aaeb3b0651720a3f37a0c2f57c92429c)|Win32 EXE||2013-11-26 05:02:22|KernelMode.info_883b99a236ceaeddc7cf30cb3a8cbdc7034fe977e5bf71cd98a23c12bdcca021.ViR|
|[39fc4a3ea44ab9822ed5e77808803727](https://www.virustotal.com/gui/file/39fc4a3ea44ab9822ed5e77808803727)|Win32 EXE||2013-11-18 09:43:24|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\39FC4A3EA44AB9822ED5E77808803727|
|[89de19ff50dd58eda2b136b65feb3fb0](https://www.virustotal.com/gui/file/89de19ff50dd58eda2b136b65feb3fb0)|Win32 EXE||2013-11-18 09:32:15|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\89DE19FF50DD58EDA2B136B65FEB3FB0|
|[0fe3daf9e8b69255e592c8af97d24649](https://www.virustotal.com/gui/file/0fe3daf9e8b69255e592c8af97d24649)|Win32 EXE|Zbot|2013-11-16 06:26:24|acroedit|
|[d580cab0c05dd78215fd6252934c240f](https://www.virustotal.com/gui/file/d580cab0c05dd78215fd6252934c240f)|Win32 EXE|Zbot|2013-11-08 21:45:45|KernelMode.info_4c5b1304aa255bb334e22ebd368ab9261532fa3dab2bb032ba634c2ea6db8999.ViR|
|[03a611a8c2f84e26c7b089d3f1640687](https://www.virustotal.com/gui/file/03a611a8c2f84e26c7b089d3f1640687)|Win32 EXE||2013-11-07 22:31:47|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\03A611A8C2F84E26C7B089D3F1640687|
|[6de1b481ae52fbacd7db84789a081b74](https://www.virustotal.com/gui/file/6de1b481ae52fbacd7db84789a081b74)|Win32 EXE||2013-10-28 09:12:17|Explorer System Checker|
|[03d35ef3fdf353fe4dc65f3d11137172](https://www.virustotal.com/gui/file/03d35ef3fdf353fe4dc65f3d11137172)|Win32 EXE||2013-10-23 04:01:30|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\03D35EF3FDF353FE4DC65F3D11137172|
|[26b7b5d019d7500efdb866f1d20d2000](https://www.virustotal.com/gui/file/26b7b5d019d7500efdb866f1d20d2000)|Win32 EXE||2013-10-22 16:26:01|KernelMode.info_bba3dda3733567019a876b734556005b0d9b727dadc55d215461d7e47dab808a.ViR|
|[c12fe91f0c39c2460ea304ffc250918d](https://www.virustotal.com/gui/file/c12fe91f0c39c2460ea304ffc250918d)|Win32 EXE||2013-10-21 21:01:26|wmisvcctrl.exe|
|[da6ed3cc582b4424c96b8ca73aaeb8ad](https://www.virustotal.com/gui/file/da6ed3cc582b4424c96b8ca73aaeb8ad)|Win32 EXE||2013-10-17 23:26:28|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\DA6ED3CC582B4424C96B8CA73AAEB8AD|
|[804dceb3fa2b9bcf65595109b9465bbc](https://www.virustotal.com/gui/file/804dceb3fa2b9bcf65595109b9465bbc)|Win32 EXE||2013-10-02 23:19:24|winmsgr.exe|
|[6bb1a12416c92f5ef12947e2dc5748f9](https://www.virustotal.com/gui/file/6bb1a12416c92f5ef12947e2dc5748f9)|Win32 EXE||2013-09-15 21:42:30|0d55b66b0416ff1093187d9a68724b80c72ed88d.codex|
|[4286ee45e9fcc2db3ddfad38426b7f50](https://www.virustotal.com/gui/file/4286ee45e9fcc2db3ddfad38426b7f50)|Win32 EXE||2013-09-10 21:44:34|49b973555890f1bda67a12a5927de1a9691005ca_KernelMode.info_85dffbf4e989fd9c86261cb8b790f198f7407fc63eace1601ab3a2494e4b4914.ViR|
|[2024679f61cf9ab60342eca58360737f](https://www.virustotal.com/gui/file/2024679f61cf9ab60342eca58360737f)|Win32 EXE|miner|2013-09-09 10:09:19|Edown_mfc|
|[2be3a8dd0059e291022ad32bbce0e5d1](https://www.virustotal.com/gui/file/2be3a8dd0059e291022ad32bbce0e5d1)|Win32 EXE||2013-09-02 11:56:07|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\2BE3A8DD0059E291022AD32BBCE0E5D1|
|[fe7efa9f0417ba001c058b513518f4cf](https://www.virustotal.com/gui/file/fe7efa9f0417ba001c058b513518f4cf)|Win32 EXE||2013-08-23 05:14:59|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\FE7EFA9F0417BA001C058B513518F4CF|
|[16e378d5f0a15fbd521b087c0951a2ab](https://www.virustotal.com/gui/file/16e378d5f0a15fbd521b087c0951a2ab)|Win32 EXE||2013-08-19 16:50:39|KernelMode.info_7b3b2e430cc41ab9df9526009b246adb0f1de75a680753f79819e284d0e73f6e.ViR|
|[21ba9d9d914d8140c1e34030e84213f4](https://www.virustotal.com/gui/file/21ba9d9d914d8140c1e34030e84213f4)|Win32 EXE||2013-08-17 23:04:24|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\21BA9D9D914D8140C1E34030E84213F4|
|[ed2119548aff161ff97d6837e6a08e84](https://www.virustotal.com/gui/file/ed2119548aff161ff97d6837e6a08e84)|Win32 EXE|roficor|2013-08-15 09:07:41|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\ED2119548AFF161FF97D6837E6A08E84|
|[27f2f32ba938b1747f28ffdd2f56c691](https://www.virustotal.com/gui/file/27f2f32ba938b1747f28ffdd2f56c691)|Win32 DLL||2013-08-14 20:55:48|27F2F32BA938B1747F28FFDD2F56C691.sample|
|[53dc9866fd77fe4933eea3c08666c7bb](https://www.virustotal.com/gui/file/53dc9866fd77fe4933eea3c08666c7bb)|Win32 EXE||2013-08-13 17:27:38|KernelMode.info_18d268d11f7d1e80fc195737f34d104745db691768decb994d5ec5588b81d086.ViR|
|[74d403244db05f7c294ca0777a9f7a9e](https://www.virustotal.com/gui/file/74d403244db05f7c294ca0777a9f7a9e)|Win32 DLL||2013-08-13 13:29:04|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\74D403244DB05F7C294CA0777A9F7A9E|
|[822871578022c1292c9cb051cceedfe2](https://www.virustotal.com/gui/file/822871578022c1292c9cb051cceedfe2)|Win32 EXE||2013-08-13 06:01:31|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\822871578022C1292C9CB051CCEEDFE2|
|[f5d745e7a575b7aecae302623acd6277](https://www.virustotal.com/gui/file/f5d745e7a575b7aecae302623acd6277)|Win32 DLL||2013-08-12 19:08:16|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\F5D745E7A575B7AECAE302623ACD6277|
|[16139ce9025274a388a4281fef65049e](https://www.virustotal.com/gui/file/16139ce9025274a388a4281fef65049e)|Win32 EXE|roficor|2013-08-12 19:05:59|6fb4721fa96cd7604e85335a4373e7b52b572904.codex|
|[9a2f2291686080a29f4c68bdc530887f](https://www.virustotal.com/gui/file/9a2f2291686080a29f4c68bdc530887f)|Win32 DLL||2013-08-12 19:03:20|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\9A2F2291686080A29F4C68BDC530887F|
|[173abb95e39f03415cd95b76e8a2f58f](https://www.virustotal.com/gui/file/173abb95e39f03415cd95b76e8a2f58f)|Win32 EXE||2013-08-12 19:02:39|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\173ABB95E39F03415CD95B76E8A2F58F|
|[8c01d9a2c13ebc8dc32956336a6bc4f5](https://www.virustotal.com/gui/file/8c01d9a2c13ebc8dc32956336a6bc4f5)|Win32 DLL||2013-08-12 18:30:11|8C01D9A2C13EBC8DC32956336A6BC4F5|
|[cdd5afba31e91706412ba58fff2b4d31](https://www.virustotal.com/gui/file/cdd5afba31e91706412ba58fff2b4d31)|Win32 DLL||2013-08-11 18:58:12|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\CDD5AFBA31E91706412BA58FFF2B4D31|
|[5dee5ad9f12f89fcf9fdcf07ebab3e5e](https://www.virustotal.com/gui/file/5dee5ad9f12f89fcf9fdcf07ebab3e5e)|Win32 DLL||2013-08-11 18:58:12|active.dll|
|[cf95ab8c4cc222088de00dbb20374d69](https://www.virustotal.com/gui/file/cf95ab8c4cc222088de00dbb20374d69)|Win32 DLL||2013-08-11 18:56:29|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\CF95AB8C4CC222088DE00DBB20374D69|
|[a7b226c220e1282320fca291a5100f93](https://www.virustotal.com/gui/file/a7b226c220e1282320fca291a5100f93)|Win32 EXE||2013-08-10 04:48:45|f274107ee34a09e08232ffbaa3fa4d6bf1e692e5_KernelMode.info_105016226d2f210bb569704b005c193ff7f26cd23744577090cd35dd34cc3372.ViR|
|[ed9f539ddabdab8a88491ee38f638b64](https://www.virustotal.com/gui/file/ed9f539ddabdab8a88491ee38f638b64)|Win32 EXE||2013-08-08 09:38:03|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\ED9F539DDABDAB8A88491EE38F638B64|
|[09e7b0ecd5530b8e87190dee0f362e13](https://www.virustotal.com/gui/file/09e7b0ecd5530b8e87190dee0f362e13)|Win32 EXE||2013-08-08 08:30:33|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\09E7B0ECD5530B8E87190DEE0F362E13|
|[9a0963dbee2361fa9cebaa6e0e517774](https://www.virustotal.com/gui/file/9a0963dbee2361fa9cebaa6e0e517774)|Win32 EXE||2013-08-04 16:41:49|103|
|[e8190374c3d962f5c2cbb5e30007216c](https://www.virustotal.com/gui/file/e8190374c3d962f5c2cbb5e30007216c)|Win32 EXE||2013-08-04 16:38:45|KernelMode.info_608da4d2771afebd72ba09d877e708e0a40d3a0ca9638a34360a4ee33eb75e10.ViR|
|[c5a9ec966196a03e53fd1869764d8507](https://www.virustotal.com/gui/file/c5a9ec966196a03e53fd1869764d8507)|Win32 EXE||2013-07-30 05:47:33|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\C5A9EC966196A03E53FD1869764D8507|
|[dd555740dcabb3dab3ea1fc71273e493](https://www.virustotal.com/gui/file/dd555740dcabb3dab3ea1fc71273e493)|Win32 EXE||2013-07-30 00:18:02|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\DD555740DCABB3DAB3EA1FC71273E493|
|[65460ec31dce97c456991ba5215d9c43](https://www.virustotal.com/gui/file/65460ec31dce97c456991ba5215d9c43)|Win32 EXE||2013-07-29 14:13:13|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\65460EC31DCE97C456991BA5215D9C43|
|[f602fe96deb8615ab8cefbd959e1d438](https://www.virustotal.com/gui/file/f602fe96deb8615ab8cefbd959e1d438)|Win32 EXE|tapaoux|2013-07-25 02:29:02|8119f075b901142e_snhtxx.exe|
|[5b7b8d3b844b4dbc22875a2a6866a862](https://www.virustotal.com/gui/file/5b7b8d3b844b4dbc22875a2a6866a862)|Win32 EXE||2013-07-21 11:55:18|5b7b8d3b844b4dbc22875a2a6866a862.vir|
|[c4ac4924544877cd100e53f1115c7df9](https://www.virustotal.com/gui/file/c4ac4924544877cd100e53f1115c7df9)|Win32 EXE||2013-07-20 02:20:09|KernelMode.info_ccc4b5fd8736fe67f2a6e49fd73b7e7bbe82ed51669e47f67179147a79c68315.ViR|
|[08b04d6ef94d2764bfafd1457eb0d2a0](https://www.virustotal.com/gui/file/08b04d6ef94d2764bfafd1457eb0d2a0)|Win32 EXE||2013-07-19 18:23:00|VirusShare_08b04d6ef94d2764bfafd1457eb0d2a0|
|[45b94e90cab94d9f873478151a80703d](https://www.virustotal.com/gui/file/45b94e90cab94d9f873478151a80703d)|Win32 EXE||2013-07-19 18:20:25|1afcf477db6534feeae4d346c067ed53482c4643.codex|
|[bf700fa187cc22d591e1ec4e7442145a](https://www.virustotal.com/gui/file/bf700fa187cc22d591e1ec4e7442145a)|Win32 EXE||2013-07-08 21:25:25|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\BF700FA187CC22D591E1EC4E7442145A|
|[48888cca68db492c87892524146e8ae3](https://www.virustotal.com/gui/file/48888cca68db492c87892524146e8ae3)|Win32 EXE||2013-07-01 21:29:45|48888CCA68DB492C87892524146E8AE3|
|[ad0f9ba1a355c5e8048c476736c90217](https://www.virustotal.com/gui/file/ad0f9ba1a355c5e8048c476736c90217)|Win32 EXE||2013-06-22 04:41:55|SDdown|
|[0d48f948b3c47d0c08e8ee026b8f4670](https://www.virustotal.com/gui/file/0d48f948b3c47d0c08e8ee026b8f4670)|Win32 EXE|jatif|2013-06-17 05:43:37|Edown_mfc|
|[ba87428a298f8acf258b2f4f814bd9b9](https://www.virustotal.com/gui/file/ba87428a298f8acf258b2f4f814bd9b9)|Win32 EXE||2013-06-16 17:21:07|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\BA87428A298F8ACF258B2F4F814BD9B9|
|[a6f55037cb02911c5624e70a67704156](https://www.virustotal.com/gui/file/a6f55037cb02911c5624e70a67704156)|Win32 EXE||2013-06-14 16:36:10|FirstSp|
|[e65fddac2ada261adcdcde87b4dc5540](https://www.virustotal.com/gui/file/e65fddac2ada261adcdcde87b4dc5540)|Win32 EXE||2013-06-13 15:24:17|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\E65FDDAC2ADA261ADCDCDE87B4DC5540|
|[5bbdb09ec6ec333a20de74fd430b2bc2](https://www.virustotal.com/gui/file/5bbdb09ec6ec333a20de74fd430b2bc2)|Win32 EXE||2013-06-13 11:04:10|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\5BBDB09EC6EC333A20DE74FD430B2BC2|
|[82ab0b8246c6677f9866b17794b72e2d](https://www.virustotal.com/gui/file/82ab0b8246c6677f9866b17794b72e2d)|Win32 EXE||2013-06-08 05:21:35|KernelMode.info_ab478166ea93e9dac3e37a9ad7457aa58249046003238e3b3bc5b9b45b09d7a8.exe|
|[a131d12bc9ab7983b984c81e5e7e108e](https://www.virustotal.com/gui/file/a131d12bc9ab7983b984c81e5e7e108e)|Win32 EXE||2013-06-07 06:48:32|FirstSp|
|[a49780f2da2067dd904135fad3af8a90](https://www.virustotal.com/gui/file/a49780f2da2067dd904135fad3af8a90)|Win32 EXE||2013-06-06 14:50:24|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A49780F2DA2067DD904135FAD3AF8A90|
|[c82ca00476d7e8532d055bf2cc2c9d59](https://www.virustotal.com/gui/file/c82ca00476d7e8532d055bf2cc2c9d59)|Win32 EXE||2013-05-14 08:39:18|DirectXchk.exe|
|[2600671b87dedbb50ca728285eb141b8](https://www.virustotal.com/gui/file/2600671b87dedbb50ca728285eb141b8)|Win32 DLL||2013-04-19 08:45:51|2600671b87dedbb50ca728285eb141b8.vir|
|[864cd4a59215a7db2740dfbe4a648053](https://www.virustotal.com/gui/file/864cd4a59215a7db2740dfbe4a648053)|Win32 EXE||2013-03-28 16:57:01|DmaUp3.exe|
|[35cd5ca2e33400a67345b00ef6db3ff6](https://www.virustotal.com/gui/file/35cd5ca2e33400a67345b00ef6db3ff6)|Win32 EXE||2013-03-22 06:13:53|35CD5CA2E33400A67345B00EF6DB3FF6.sample|
|[8cdd3b6c577a17b698333337dd1cf3e0](https://www.virustotal.com/gui/file/8cdd3b6c577a17b698333337dd1cf3e0)|Win32 EXE||2013-03-20 20:28:53|Get_ICR|
|[121a9ea93f3ed16a1b191187b16b7592](https://www.virustotal.com/gui/file/121a9ea93f3ed16a1b191187b16b7592)|Win32 DLL|roficor|2013-03-11 02:26:47|detect.dll|
|[0d75157d3f7fbf13264df3f8a18b3905](https://www.virustotal.com/gui/file/0d75157d3f7fbf13264df3f8a18b3905)|Win32 EXE||2013-02-19 17:28:14|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\0D75157D3F7FBF13264DF3F8A18B3905|
|[af26f60a80171c4337117133f1c2ba5f](https://www.virustotal.com/gui/file/af26f60a80171c4337117133f1c2ba5f)|Win32 DLL||2013-02-13 20:09:52|active.dll|
|[57099403f28d2ce79cba11469c8be971](https://www.virustotal.com/gui/file/57099403f28d2ce79cba11469c8be971)|Win32 DLL||2013-02-13 19:19:41|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\57099403F28D2CE79CBA11469C8BE971|
|[04461ee7c724b6805820df79e343aa49](https://www.virustotal.com/gui/file/04461ee7c724b6805820df79e343aa49)|Win32 EXE|injector|2013-02-13 13:13:56|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\04461EE7C724B6805820DF79E343AA49|
|[63409ddbd5316bae8e956595c81121ab](https://www.virustotal.com/gui/file/63409ddbd5316bae8e956595c81121ab)|Win32 EXE||2013-02-13 00:14:10|AdobeARM.exe|
|[131c5f8e98605f9d8074ca02fd1b9c34](https://www.virustotal.com/gui/file/131c5f8e98605f9d8074ca02fd1b9c34)|Win32 EXE||2013-02-12 08:37:34|KernelMode.info_2381ef2fce6e8fa52e2f7717c893576f362c0cc54cc0ffa343a3902feead7784.ViR|
|[70a0412d19d55bcab72e76c984694215](https://www.virustotal.com/gui/file/70a0412d19d55bcab72e76c984694215)|Win32 EXE||2013-02-01 19:42:40|Explorer System Checker|
|[18527b303c0afe91f5ae86d34b52eb29](https://www.virustotal.com/gui/file/18527b303c0afe91f5ae86d34b52eb29)|Win32 DLL||2013-01-29 15:06:34|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\18527B303C0AFE91F5AE86D34B52EB29|
|[35994a29128c08bed6f5d4aad28f102b](https://www.virustotal.com/gui/file/35994a29128c08bed6f5d4aad28f102b)|Win32 EXE||2013-01-17 05:42:41|LSUninst|
|[90f26c5c4b3c592352fcbddf41dc18aa](https://www.virustotal.com/gui/file/90f26c5c4b3c592352fcbddf41dc18aa)|Win32 EXE||2013-01-09 01:01:27|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\90F26C5C4B3C592352FCBDDF41DC18AA|
|[4a0fa9be43cc84b5beb0b484227edfcb](https://www.virustotal.com/gui/file/4a0fa9be43cc84b5beb0b484227edfcb)|Win32 EXE||2012-12-05 03:57:16|97698669fa290dfd9e0a374e09221b352302bf3e_KernelMode.info_cfcc7037196cef0c0566bb08f934c04e6ee3dfcb2085bc4c46bd059405c39c89.ViR|
|[255f7842c6f07a6a1500a30fb4d27d54](https://www.virustotal.com/gui/file/255f7842c6f07a6a1500a30fb4d27d54)|Win32 EXE||2012-12-04 20:49:45|malware.exe|
|[268d17f3763246ac27de7dc8024f23fa](https://www.virustotal.com/gui/file/268d17f3763246ac27de7dc8024f23fa)|Win32 EXE||2012-12-02 05:43:53|687b801a91383a1d3c7977e5cb27c68c7fbb83a8_KernelMode.info_fbee0422f1d775b6abd1a2bee86ec0644e9c18ee4c2631b09f0d3244c05b10d8.ViR|
|[1f29ec5ab8a7c2ccda21576f29cbb13b](https://www.virustotal.com/gui/file/1f29ec5ab8a7c2ccda21576f29cbb13b)|Win32 EXE||2012-11-22 23:18:33|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\1F29EC5AB8A7C2CCDA21576F29CBB13B|
|[a0b0389eb9bbfe1839d3da7a1995da3f](https://www.virustotal.com/gui/file/a0b0389eb9bbfe1839d3da7a1995da3f)|Win32 EXE||2012-11-17 13:51:13|Windows Service|
|[5cb91f0c3a1452176007dcc594ec02ce](https://www.virustotal.com/gui/file/5cb91f0c3a1452176007dcc594ec02ce)|Win32 EXE||2012-11-17 13:03:37|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\5CB91F0C3A1452176007DCC594EC02CE|
|[b7d1c3a03e92b24e9052e75ea381ea4a](https://www.virustotal.com/gui/file/b7d1c3a03e92b24e9052e75ea381ea4a)|Win32 EXE||2012-11-09 06:23:39|Windows Service|
|[fcd2458376398b0be09eaa34f4f4d091](https://www.virustotal.com/gui/file/fcd2458376398b0be09eaa34f4f4d091)|Win32 EXE|jatif|2012-11-08 19:21:25|fcd2458376398b0be09eaa34f4f4d091.vir|
|[83f0f16fb86d6f67ca158d66c195884e](https://www.virustotal.com/gui/file/83f0f16fb86d6f67ca158d66c195884e)|Win32 EXE|jatif|2012-10-29 07:13:05|3af81b40019faf5f32fd4860ab11ece3687a59a54df2b2b99e87af72df56434a.exe|
|[436b853cbc87ba3a99131ce2d64a512d](https://www.virustotal.com/gui/file/436b853cbc87ba3a99131ce2d64a512d)|Win32 EXE||2012-10-25 08:41:16|KernelMode.info_f806fe83eecb5ca990c4fe4b344ec52367480faa12f99432743af32193d54c36.ViR|
|[326b44e73fccece89326fd865da61f7f](https://www.virustotal.com/gui/file/326b44e73fccece89326fd865da61f7f)|Win32 EXE||2012-10-21 14:53:08|Windows Service|
|[a07db3237b6bd9789b5f1126ea7b0195](https://www.virustotal.com/gui/file/a07db3237b6bd9789b5f1126ea7b0195)|Win32 EXE||2012-10-20 16:00:28|5f8164553aae8b60eee401cf296e1bfcdfde07d5_KernelMode.info_0867c7d02dda064eb59656e7c175928d8ca63a9e58eae95d116fee4f5db41c50.ViR|
|[5f05b4aff89a07dbac9914ae3cf1314f](https://www.virustotal.com/gui/file/5f05b4aff89a07dbac9914ae3cf1314f)|Win32 EXE||2012-10-19 11:47:04|0be64d83e465beaac567ff41de244a750ade92d5_KernelMode.info_f7fafc73621f44cdd8994151537da12c665ae9953bab22360871af59ffd646fd.ViR|
|[965e7d4785d23ba6b6608c1245586eba](https://www.virustotal.com/gui/file/965e7d4785d23ba6b6608c1245586eba)|Win32 EXE||2012-10-09 08:30:08|BitComet.exe|
|[4d840625c5ca9a4f1cbd35d4b1ca2452](https://www.virustotal.com/gui/file/4d840625c5ca9a4f1cbd35d4b1ca2452)|Win32 EXE||2012-09-28 17:31:22|4d840625c5ca9a4f1cbd35d4b1ca2452|
|[522cd120fa4b1517a60fcf8be3e71ff4](https://www.virustotal.com/gui/file/522cd120fa4b1517a60fcf8be3e71ff4)|Win32 DLL||2012-09-26 10:17:57|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\522CD120FA4B1517A60FCF8BE3E71FF4|
|[151115ddf1cd4b474a9106cfebcb82e4](https://www.virustotal.com/gui/file/151115ddf1cd4b474a9106cfebcb82e4)|Win32 EXE||2012-09-20 11:06:15|Windows Service|
|[40591b4ba82e0347b33098f6652640d6](https://www.virustotal.com/gui/file/40591b4ba82e0347b33098f6652640d6)|Win32 EXE||2012-09-06 08:52:49|Dojuk|
|[4e01e648645d041d52af9dbb09e442ef](https://www.virustotal.com/gui/file/4e01e648645d041d52af9dbb09e442ef)|Win32 EXE||2012-08-30 17:58:59|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\4E01E648645D041D52AF9DBB09E442EF|
|[c34eb5aa60373119a03cfd90a5fea121](https://www.virustotal.com/gui/file/c34eb5aa60373119a03cfd90a5fea121)|Win32 EXE||2012-08-29 04:03:17|Windows Service|
|[41b816289a6a639f7f2a72b6c9e6a695](https://www.virustotal.com/gui/file/41b816289a6a639f7f2a72b6c9e6a695)|Win32 EXE||2012-08-29 02:32:31|41B816289A6A639F7F2A72B6C9E6A695.sample|
|[cdf5267225e6994b4670bf49ba50595a](https://www.virustotal.com/gui/file/cdf5267225e6994b4670bf49ba50595a)|Win32 EXE|jatif|2012-08-24 21:04:03|Windows Service|
|[9eeae870f22350694eb2e7a4852dbb7d](https://www.virustotal.com/gui/file/9eeae870f22350694eb2e7a4852dbb7d)|Win32 EXE||2012-08-23 15:23:40|Windows Service|
|[9ba119cf7107d6f4f910447c90c4985d](https://www.virustotal.com/gui/file/9ba119cf7107d6f4f910447c90c4985d)|Win32 EXE||2012-08-21 18:35:57|dwtrig20.exe|
|[15097b11e3898cb0be995e44a79431f2](https://www.virustotal.com/gui/file/15097b11e3898cb0be995e44a79431f2)|Win32 EXE||2012-08-01 04:15:15|googletoolbar.exe|
|[c322e499729291451437d46c6f05b920](https://www.virustotal.com/gui/file/c322e499729291451437d46c6f05b920)|Win32 EXE||2012-08-01 01:04:37|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\C322E499729291451437D46C6F05B920|
|[6a79c842a6edca3460b0026cd16c3670](https://www.virustotal.com/gui/file/6a79c842a6edca3460b0026cd16c3670)|Win32 EXE|tapaoux|2012-07-22 04:38:13|SETUP.EXE|
|[ec4be1af573e5c55023b35bd02efe394](https://www.virustotal.com/gui/file/ec4be1af573e5c55023b35bd02efe394)|Win32 EXE||2012-07-02 20:12:08|googletoolbar.exe|
|[275e0786b6294ffd05f45df435df842c](https://www.virustotal.com/gui/file/275e0786b6294ffd05f45df435df842c)|Win32 EXE||2012-06-22 08:00:01|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\275E0786B6294FFD05F45DF435DF842C|
|[65f7b330bcc7aeebf8d84afa0b23bf02](https://www.virustotal.com/gui/file/65f7b330bcc7aeebf8d84afa0b23bf02)|Win32 EXE||2012-05-07 06:07:55|50fcc294c5cba9ca4dc12613693798a5d412614a_KernelMode.info_0146c57cb02974db2bad93a85aae7d5681a4aa98aec6f214f72c280266ca619d.ViR|
|[236df260f858f9a6ca056bcdec6f754f](https://www.virustotal.com/gui/file/236df260f858f9a6ca056bcdec6f754f)|Win32 EXE||2012-04-27 23:49:44|54346d8a5228568b2acd14393bbbd8179ee85da8f816b71acf98d0e119b14b77.vir|
|[11e85a6e127802204561b6996d4224b6](https://www.virustotal.com/gui/file/11e85a6e127802204561b6996d4224b6)|Win32 EXE||2012-03-29 09:57:16|11E85A6E127802204561B6996D4224B6.sample|
|[e579157fb503b5cbd59ce66f5381575c](https://www.virustotal.com/gui/file/e579157fb503b5cbd59ce66f5381575c)|Win32 EXE||2012-03-14 20:39:57|KernelMode.info_324834d2339d57e0e598baed98ecb543a54a59fe904a77be79c44430b42f33e2.ViR|
|[6a37ba1bac5fb990fbd1c34effcb0b9d](https://www.virustotal.com/gui/file/6a37ba1bac5fb990fbd1c34effcb0b9d)|Win32 EXE||2012-02-22 08:20:52|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\6A37BA1BAC5FB990FBD1C34EFFCB0B9D|
|[178f7fe2d3a2bda46c0e78f679ca5a62](https://www.virustotal.com/gui/file/178f7fe2d3a2bda46c0e78f679ca5a62)|Win32 EXE||2012-02-13 00:32:47|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\178F7FE2D3A2BDA46C0E78F679CA5A62|
|[101244381e0590adecf5f2b18d1b6042](https://www.virustotal.com/gui/file/101244381e0590adecf5f2b18d1b6042)|Win32 EXE||2012-01-22 23:18:11|103|
|[05059c5a5e388e36eed09a9f8093db92](https://www.virustotal.com/gui/file/05059c5a5e388e36eed09a9f8093db92)|Win32 EXE||2012-01-22 16:06:46|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\05059C5A5E388E36EED09A9F8093DB92|
|[8c3fc5e341d7df51ea9b781a55908e82](https://www.virustotal.com/gui/file/8c3fc5e341d7df51ea9b781a55908e82)|Win32 EXE||2012-01-19 02:20:46|prtshgrd.exe|
|[3961cab50c32e8f32fe45836b9715ce5](https://www.virustotal.com/gui/file/3961cab50c32e8f32fe45836b9715ce5)|Win32 DLL||2012-01-09 03:55:19|/home/virustotal/sample/3961CAB50C32E8F32FE45836B9715CE5.9912C463|
|[06206fe97fed0f338fd02cb39ed63174](https://www.virustotal.com/gui/file/06206fe97fed0f338fd02cb39ed63174)|Win32 DLL||2012-01-06 03:37:55|06206FE97FED0F338FD02CB39ED63174|
|[a45e0f8a404d846289f3a223253e94a9](https://www.virustotal.com/gui/file/a45e0f8a404d846289f3a223253e94a9)|Win32 EXE||2012-01-06 03:33:32|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A45E0F8A404D846289F3A223253E94A9|
|[e271ba345eada5f56471c5413acf52f9](https://www.virustotal.com/gui/file/e271ba345eada5f56471c5413acf52f9)|Win32 EXE||2011-12-28 12:34:29|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\E271BA345EADA5F56471C5413ACF52F9|
|[72869fc63d0ba875dfc539d2bcd48e4d](https://www.virustotal.com/gui/file/72869fc63d0ba875dfc539d2bcd48e4d)|Win32 EXE||2011-11-26 10:13:15|FirstSp|
|[adab033d420206fcd2503643d443956e](https://www.virustotal.com/gui/file/adab033d420206fcd2503643d443956e)|Win32 EXE|jatif|2011-11-25 20:25:28|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\ADAB033D420206FCD2503643D443956E|
|[1b0c2c6c19404112306a78ecf366f90b](https://www.virustotal.com/gui/file/1b0c2c6c19404112306a78ecf366f90b)|Win32 EXE||2011-11-17 11:36:32|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\1B0C2C6C19404112306A78ECF366F90B|
|[e2b5c47156508a31b74a1f48e814fbe7](https://www.virustotal.com/gui/file/e2b5c47156508a31b74a1f48e814fbe7)|Win32 EXE||2011-11-15 03:09:26|Microsoft Help|
|[1300244219cb756df01536692edebdbb](https://www.virustotal.com/gui/file/1300244219cb756df01536692edebdbb)|Win32 EXE||2011-11-15 03:09:02|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\1300244219CB756DF01536692EDEBDBB|
|[a71f240abb41eb1e37ff240613d14277](https://www.virustotal.com/gui/file/a71f240abb41eb1e37ff240613d14277)|Win32 EXE||2011-10-21 23:17:08|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A71F240ABB41EB1E37FF240613D14277|
|[da6c390915639c853612cb665ac635f4](https://www.virustotal.com/gui/file/da6c390915639c853612cb665ac635f4)|Win32 EXE||2011-10-16 08:36:18|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\DA6C390915639C853612CB665AC635F4|
|[a9faa01c7cf7150054600fc2ab63e4b6](https://www.virustotal.com/gui/file/a9faa01c7cf7150054600fc2ab63e4b6)|Win32 EXE||2011-10-08 12:30:28|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A9FAA01C7CF7150054600FC2AB63E4B6|
|[b2b29dcb1251c8b1c380f00834297857](https://www.virustotal.com/gui/file/b2b29dcb1251c8b1c380f00834297857)|Win32 EXE||2011-09-09 21:48:16|reader_sl.exe|
|[f1368a2e56ae66587847a1655265d3c9](https://www.virustotal.com/gui/file/f1368a2e56ae66587847a1655265d3c9)|Win32 EXE||2011-08-29 06:53:09|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\F1368A2E56AE66587847A1655265D3C9|
|[9f56c7f03370692f1d4761ddb848daf5](https://www.virustotal.com/gui/file/9f56c7f03370692f1d4761ddb848daf5)|Win32 DLL||2011-08-26 23:31:09|9F56C7F03370692F1D4761DDB848DAF5.exe|
|[e9f89d406e32ca88c32ac22852c25841](https://www.virustotal.com/gui/file/e9f89d406e32ca88c32ac22852c25841)|Win32 EXE||2011-08-24 03:32:06|Adobe Systems Apps|
|[60af79fb0bd2c9f33375035609c931cb](https://www.virustotal.com/gui/file/60af79fb0bd2c9f33375035609c931cb)|Win32 EXE||2011-08-23 14:37:40|60AF79FB0BD2C9F33375035609C931CB.sample|
|[86b18e99072ba72d5d36bce9a00fc052](https://www.virustotal.com/gui/file/86b18e99072ba72d5d36bce9a00fc052)|Win32 EXE|keylogger|2011-08-19 21:02:47|86B18E99072BA72D5D36BCE9A00FC052|
|[44e520bec8a3e35f6f6ad52e97911e14](https://www.virustotal.com/gui/file/44e520bec8a3e35f6f6ad52e97911e14)|Win32 EXE||2011-08-17 22:33:39|44E520BEC8A3E35F6F6AD52E97911E14.sample|
|[42a3bb917778454fa96034ad4fb17832](https://www.virustotal.com/gui/file/42a3bb917778454fa96034ad4fb17832)|Win32 EXE|graftor|2011-07-22 18:34:50|42A3BB917778454FA96034AD4FB17832.sample|
|[0396f7af9842dc5c8c0df1a44c01068c](https://www.virustotal.com/gui/file/0396f7af9842dc5c8c0df1a44c01068c)|Win32 EXE||2011-07-22 07:06:56|VirusShare_0396f7af9842dc5c8c0df1a44c01068c|
|[3e38b8ccd38682ad4ec1f0fcfc1fb16a](https://www.virustotal.com/gui/file/3e38b8ccd38682ad4ec1f0fcfc1fb16a)|Win32 EXE||2011-07-13 19:05:45|a674b011637c0735740d3d51a5cd30c63343c536_KernelMode.info_402557e597c5f93cb35055c43335be5e7ab9de9cb088f3cd003e204ada2fbfe2.ViR|
|[697e77c5ef4cf91d5a84b0b3f0617887](https://www.virustotal.com/gui/file/697e77c5ef4cf91d5a84b0b3f0617887)|Win32 EXE||2011-07-06 13:54:30|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\697E77C5EF4CF91D5A84B0B3F0617887|
|[27db26077f849e26ba89fcafd2f0db92](https://www.virustotal.com/gui/file/27db26077f849e26ba89fcafd2f0db92)|Win32 EXE||2011-06-23 04:06:20|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\27DB26077F849E26BA89FCAFD2F0DB92|
|[1743dafa776677e232d20506858d9a4e](https://www.virustotal.com/gui/file/1743dafa776677e232d20506858d9a4e)|Win32 EXE||2011-06-22 17:01:59|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\1743DAFA776677E232D20506858D9A4E|
|[0367f890595cf28c6c195dfabae53ba5](https://www.virustotal.com/gui/file/0367f890595cf28c6c195dfabae53ba5)|Win32 EXE|injector|2011-06-15 22:13:56|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\0367F890595CF28C6C195DFABAE53BA5|
|[0bfc8e7fa0b026a8bf51bbea3d766890](https://www.virustotal.com/gui/file/0bfc8e7fa0b026a8bf51bbea3d766890)|Win32 EXE|jatif|2011-06-15 22:01:47|0BFC8E7FA0B026A8BF51BBEA3D766890|
|[a8151939085ce837b3a7deec58efa7b4](https://www.virustotal.com/gui/file/a8151939085ce837b3a7deec58efa7b4)|Win32 EXE||2011-05-20 19:31:56|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\A8151939085CE837B3A7DEEC58EFA7B4|
|[140b27db7d156d6a63281e1f6fc6075d](https://www.virustotal.com/gui/file/140b27db7d156d6a63281e1f6fc6075d)|Win32 EXE||2011-04-22 04:07:57|KernelMode.info_1ec2e4d02a89277afc0ee35d2d72009a5dbe96f88e1bc70bbfb3a9224478b7d5.ViR|
|[216088053dac46fcd95938568c469fa6](https://www.virustotal.com/gui/file/216088053dac46fcd95938568c469fa6)|Win32 EXE||2011-04-16 08:45:19|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\216088053DAC46FCD95938568C469FA6|
|[44300d48fccd5aaf27f4c863421c0d47](https://www.virustotal.com/gui/file/44300d48fccd5aaf27f4c863421c0d47)|Win32 EXE||2011-04-01 03:58:19|7300569a4fbf4721a118455e1a16ab42a5bcd07c8be47ddce1f873c4d92f2f0e.vir|
|[28b1569109fcae8cfcdcfbe9c4431b66](https://www.virustotal.com/gui/file/28b1569109fcae8cfcdcfbe9c4431b66)|Win32 EXE||2011-03-31 21:49:28|276b17244408e7e698e837a0a105c7c3857acfac37e2e837d4b10e6904fd9dc3.vir|
|[7c2eeda3bb66b2c29aa425ba74c780c3](https://www.virustotal.com/gui/file/7c2eeda3bb66b2c29aa425ba74c780c3)|unknown||2011-03-02 01:03:01|KernelMode.info_ec48b5ff11d77e9358bd4d8a93f79e4cc333dd953846ee5b670c59d7405eddfe.ViR|
|[f97ec1cc844914a9aa8dfa00d1ead62e](https://www.virustotal.com/gui/file/f97ec1cc844914a9aa8dfa00d1ead62e)|Win32 EXE||2011-01-27 06:11:25|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\F97EC1CC844914A9AA8DFA00D1EAD62E|
|[4d275adbd318f182fa0ec0275cf217b4](https://www.virustotal.com/gui/file/4d275adbd318f182fa0ec0275cf217b4)|Win32 EXE||2011-01-23 23:03:45|prtshgrd.exe|
|[4fc1b3dbf9dc44278f990d57913d96f6](https://www.virustotal.com/gui/file/4fc1b3dbf9dc44278f990d57913d96f6)|Win32 EXE||2011-01-07 18:08:01|4FC1B3DBF9DC44278F990D57913D96F6|
|[45a4c8c01ec94e1db83b86e05dc9e851](https://www.virustotal.com/gui/file/45a4c8c01ec94e1db83b86e05dc9e851)|Win32 EXE||2010-12-30 02:33:00|45A4C8C01EC94E1DB83B86E05DC9E851|
|[51eaec282b845bc54dbd4fbce5bb09d8](https://www.virustotal.com/gui/file/51eaec282b845bc54dbd4fbce5bb09d8)|Win32 EXE||2010-12-23 03:55:11|KernelMode.info_090ecf1fe5c493ddb70ff1c62d0ac0df0ad64896c4bc7169e3537628e3d6856a.ViR|
|[428eb3305d4d4c9a8831e1d54160ed65](https://www.virustotal.com/gui/file/428eb3305d4d4c9a8831e1d54160ed65)|Win32 EXE||2010-12-22 18:45:26|3449B1D75B5CBA3CC941A2CBAAF6D0E37D22F36A7F947721767E87C16F889E02.exe|
|[b6428851df75dc91bb46583b97d9a566](https://www.virustotal.com/gui/file/b6428851df75dc91bb46583b97d9a566)|Win32 EXE|arad|2010-12-22 16:53:56|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\B6428851DF75DC91BB46583B97D9A566|
|[51d3e2bd306495de50bfd0f2f4e19ae9](https://www.virustotal.com/gui/file/51d3e2bd306495de50bfd0f2f4e19ae9)|PPT||2010-12-22 16:32:59|CVE-2009-0556_PPS_2010-12-21_ChristmasMessages.pps=|
|[76dd289fa3dd8f36972593a006b771cc](https://www.virustotal.com/gui/file/76dd289fa3dd8f36972593a006b771cc)|Win32 EXE||2010-11-25 23:40:45|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\76DD289FA3DD8F36972593A006B771CC|
|[8f7a7d003cafa56c63e9402f553f9521](https://www.virustotal.com/gui/file/8f7a7d003cafa56c63e9402f553f9521)|Win32 EXE||2010-11-16 03:04:16|8F7A7D003CAFA56C63E9402F553F9521|
|[b4cbafc20d19b06a4ab670129a3ae5aa](https://www.virustotal.com/gui/file/b4cbafc20d19b06a4ab670129a3ae5aa)|Win32 EXE||2010-11-16 03:00:25|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\B4CBAFC20D19B06A4AB670129A3AE5AA|
|[0bd1677c0691c8a3c7327bf93b0a9e59](https://www.virustotal.com/gui/file/0bd1677c0691c8a3c7327bf93b0a9e59)|Win32 EXE|graftor|2010-10-31 19:10:33|VirusShare_0bd1677c0691c8a3c7327bf93b0a9e59|
|[08a41624e624d8fb26eeed7a3b1f5009](https://www.virustotal.com/gui/file/08a41624e624d8fb26eeed7a3b1f5009)|Win32 EXE||2010-10-19 12:17:15|KernelMode.info_43735fc143c20b157ea2a0854dc5a6acc5bb939ffe0281f2d95c26c1c0a2f8a7.ViR|
|[35a15355c96be225507ebed1ec434d57](https://www.virustotal.com/gui/file/35a15355c96be225507ebed1ec434d57)|Win32 EXE|graftor|2010-10-18 01:00:12|KernelMode.info_2e5a0550bccac2a818e339844b6f8d84def0ce54aeb8d5b75a666da8ee5cd953.ViR|
|[abdcde9cd1f9135e412f7bb0a9cafbc9](https://www.virustotal.com/gui/file/abdcde9cd1f9135e412f7bb0a9cafbc9)|Win32 EXE||2010-10-17 17:01:46|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\ABDCDE9CD1F9135E412F7BB0A9CAFBC9|
|[0bfbd26a1a6e3349606d37a8ece04627](https://www.virustotal.com/gui/file/0bfbd26a1a6e3349606d37a8ece04627)|Win32 EXE||2010-10-13 00:36:35|adobepatch.exe|
|[2b443cc331fec486a6ccbcfcd92e76a4](https://www.virustotal.com/gui/file/2b443cc331fec486a6ccbcfcd92e76a4)|Win32 EXE||2010-09-16 21:00:31|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\2B443CC331FEC486A6CCBCFCD92E76A4|
|[f47cdf5bfc7227382e18f8361249212b](https://www.virustotal.com/gui/file/f47cdf5bfc7227382e18f8361249212b)|Win32 EXE|injector|2010-09-10 13:33:55|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\F47CDF5BFC7227382E18F8361249212B|
|[2802c47b48cced7f1f027f3b278d6bb3](https://www.virustotal.com/gui/file/2802c47b48cced7f1f027f3b278d6bb3)|PDF||2010-09-10 02:33:52|vti-rescan|
|[55b125da1310d2b37f18ea4e2ae8192b](https://www.virustotal.com/gui/file/55b125da1310d2b37f18ea4e2ae8192b)|Win32 DLL||2010-09-09 01:23:18|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\55B125DA1310D2B37F18EA4E2AE8192B|
|[910a1f150a5de21f377cf771ed53261f](https://www.virustotal.com/gui/file/910a1f150a5de21f377cf771ed53261f)|Win32 DLL||2010-09-08 06:38:14|DLL|
|[687b8d2112f25e330820143ede7fedce](https://www.virustotal.com/gui/file/687b8d2112f25e330820143ede7fedce)|Win32 EXE||2010-09-07 05:11:45|wincrng.exe|
|[9c5cd8f4a5988acae6c2e2dce563446a](https://www.virustotal.com/gui/file/9c5cd8f4a5988acae6c2e2dce563446a)|PDF|pidief|2010-09-07 04:31:37|9da2b|
|[12df4869b3a885d71c8e871f1a1b0fde](https://www.virustotal.com/gui/file/12df4869b3a885d71c8e871f1a1b0fde)|Win32 EXE||2010-06-17 22:38:18|KernelMode.info_39514ebac4feec4eab0a385c99ada3b52f7c460d87a8b990f01ac90506928fa6.ViR|
|[3f39c6dea5311167cc7ff62befd4ea7e](https://www.virustotal.com/gui/file/3f39c6dea5311167cc7ff62befd4ea7e)|Win32 EXE||2010-06-07 20:06:10|3a0078d34029f2949d726ccffb429df300a49935.codex|
|[38b919f37501fc3d54f8f1b956448a92](https://www.virustotal.com/gui/file/38b919f37501fc3d54f8f1b956448a92)|Win32 EXE||2010-06-06 02:49:38|1b6e078d66b7f649431e26cb89cad3a196de3bd7.codex|
|[1971ee25847d246116835c7157cf7f89](https://www.virustotal.com/gui/file/1971ee25847d246116835c7157cf7f89)|Win32 EXE|PoisonIvy|2010-04-24 18:44:33|/home/vega/CONTAGIO/malware/wincfg.exe|
|[043d308bfda76e35122567cf933e1b2a](https://www.virustotal.com/gui/file/043d308bfda76e35122567cf933e1b2a)|Win32 EXE||2010-03-27 18:17:26|KernelMode.info_2db8a9c401911c7317e8a89c35d979d0e8e9ba718ae13a0a0cfedd957654ec10.ViR|
|[175aa0d1bdebfa60de29b90ab2c62189](https://www.virustotal.com/gui/file/175aa0d1bdebfa60de29b90ab2c62189)|Win32 DLL||2009-12-15 15:04:23|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\175AA0D1BDEBFA60DE29B90AB2C62189|
|[686738eb5bb8027c524303751117e8a9](https://www.virustotal.com/gui/file/686738eb5bb8027c524303751117e8a9)|Win32 EXE||2009-12-15 07:28:58|04.2009.12.20091215-05.msl_pe_1|
|[5607a3ccdaf748fd5cd2d1bec4a771bd](https://www.virustotal.com/gui/file/5607a3ccdaf748fd5cd2d1bec4a771bd)|Win32 EXE||2009-11-12 18:58:10|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\5607A3CCDAF748FD5CD2D1BEC4A771BD|
|[fda0320d1e28bc022e4d9e9aae544db4](https://www.virustotal.com/gui/file/fda0320d1e28bc022e4d9e9aae544db4)|Win32 EXE|tapaoux|2009-10-17 20:51:29|D:\temp\2014.12.19_tommy_399\2014.12.19_tommy_399\FDA0320D1E28BC022E4D9E9AAE544DB4|
|[da608f216594653a1716edd5734cd6e1](https://www.virustotal.com/gui/file/da608f216594653a1716edd5734cd6e1)|Win32 EXE||2009-09-11 09:58:53|da608f216594653a1716edd5734cd6e1_000156424_|
|[b5ab66687d53914a65447aacc8fb3e88](https://www.virustotal.com/gui/file/b5ab66687d53914a65447aacc8fb3e88)|Win32 EXE||2008-12-10 00:53:27|B5AB66687D53914A65447AACC8FB3E88|
|[29d76d34d8878f7ac703837ec774f26a](https://www.virustotal.com/gui/file/29d76d34d8878f7ac703837ec774f26a)|Win32 DLL||2008-08-09 10:27:45|da0a49a477910ea7_iconpop.dll|
|[1bfc1b606fc8aa85e1094b01b08eafd6](https://www.virustotal.com/gui/file/1bfc1b606fc8aa85e1094b01b08eafd6)|Win32 EXE|poison|2008-07-08 08:27:05|wins|
|[b2b51a85bdad70ff19534cd013c07f24](https://www.virustotal.com/gui/file/b2b51a85bdad70ff19534cd013c07f24)|Win32 EXE|Ursu|2020-09-21 12:27:25|b2b51a85bdad70ff19534cd013c07f24.virus|
|[39bceabd1df729ca500967ef577162a2](https://www.virustotal.com/gui/file/39bceabd1df729ca500967ef577162a2)|Win64 DLL|Razy|2020-06-29 04:36:53| |
|[8413ab4d5a950f81b40ceebc3f1e7273](https://www.virustotal.com/gui/file/8413ab4d5a950f81b40ceebc3f1e7273)|Win32 DLL|Wacatac|2020-05-13 20:19:31|dttcodexgigas.5a5738e2ec8af9f5400952be923e55a5780a8c55|
|[07858d5562766d8239a7c961feea087c](https://www.virustotal.com/gui/file/07858d5562766d8239a7c961feea087c)|Win32 EXE||2020-05-13 20:19:27|dttcodexgigas.bd8d0143ec75ef4c369f341c2786facbd9f73256|
|[615a0f818dc0ded2f138d6b3b2dfd6e5](https://www.virustotal.com/gui/file/615a0f818dc0ded2f138d6b3b2dfd6e5)|Win32 EXE||2020-05-13 13:14:24|cc7ac31689a392a2396f4f67d3621e65378604b16a2420ffc0af1e4b969c6689.sample|
|[08943bb237926dd1376d799a4afe797d](https://www.virustotal.com/gui/file/08943bb237926dd1376d799a4afe797d)|JPEG||2020-04-29 23:30:40|C:\Users\aETAdzjz\AppData\Local\Temp\image1.jpeg|
|[f6bb14997964930cae7d91f1250551c0](https://www.virustotal.com/gui/file/f6bb14997964930cae7d91f1250551c0)|Win64 DLL||2020-04-28 08:18:12|dump.bin|
|[25877aa787b213c67854a08452cdfc5b](https://www.virustotal.com/gui/file/25877aa787b213c67854a08452cdfc5b)|Win32 DLL|occamy|2020-04-23 03:50:17|98a4d7616ef386a106fe2251eda661c538336a3c7ca2a30a17839fafd8c481e9~|
|[aa6bb52bd5e3d8b21c113e5ab1a240ea](https://www.virustotal.com/gui/file/aa6bb52bd5e3d8b21c113e5ab1a240ea)|DOCX|Sagent|2020-04-10 08:10:27|afchunk2.docx|
|[0b04998eeb9fb22429a04e3d0e134548](https://www.virustotal.com/gui/file/0b04998eeb9fb22429a04e3d0e134548)|DOCX|Sagent|2020-04-10 04:50:15|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\8241aae5894a21bed9770c127289b4940b12f00571734ee13bcd2667164c6dc2|
|[6e47f8be989792800c019bc24dfb1a25](https://www.virustotal.com/gui/file/6e47f8be989792800c019bc24dfb1a25)|DOCX|Sagent|2020-04-10 01:15:03|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\4df6caa2f34ddf5f73be1da5e0f85067e7d76f091eadf58894ed74591cc90336|
|[5f564a755100d63b9c6374dabd1e5321](https://www.virustotal.com/gui/file/5f564a755100d63b9c6374dabd1e5321)|DOCX|Sagent|2020-04-09 21:32:14|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\8593458f602857c0f4416a6ac21f1671d951200b271cb34fc5d8b5f067b84b1c|
|[53984ef18c965b49eeb3686460ad540b](https://www.virustotal.com/gui/file/53984ef18c965b49eeb3686460ad540b)|DOCX|Sagent|2020-04-09 13:25:23|afchunk2.docx|
|[5d0faa109dcfda31ac2d493631e606c2](https://www.virustotal.com/gui/file/5d0faa109dcfda31ac2d493631e606c2)|DOCX|Sagent|2020-04-09 09:19:49|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\6bc5e121818830b4d5e74fa64894d2e4a4650289624c21e7e76559da165c8fbe|
|[7a5503b148e3a1d88ba9e07d95166159](https://www.virustotal.com/gui/file/7a5503b148e3a1d88ba9e07d95166159)|DOCX|Sagent|2020-04-09 08:21:22|afchunk2.docx|
|[cf133c06180f130c471c95b3a4ebd7a5](https://www.virustotal.com/gui/file/cf133c06180f130c471c95b3a4ebd7a5)|HTML|Sagent|2020-04-09 06:48:06|C:\Users\Administrator\AppData\Local\Temp\OfficeTemporary.sct|
|[4fa4c81a7d1b945b36403dc95943f01e](https://www.virustotal.com/gui/file/4fa4c81a7d1b945b36403dc95943f01e)|RTF|Sagent|2020-04-09 03:59:11|afchunk.rtf|
|[a211c80068304fb4a9acd7ab13720d55](https://www.virustotal.com/gui/file/a211c80068304fb4a9acd7ab13720d55)|DOCX|Sagent|2020-04-09 03:44:41|afchunk2 (2).docx|
|[1f3606dda801a6b7e6bd7cc0e8994241](https://www.virustotal.com/gui/file/1f3606dda801a6b7e6bd7cc0e8994241)|DOCX|Sagent|2020-04-09 03:32:12|afchunk2.docx|
|[d2ae4cd314969838ad2368dfb683caef](https://www.virustotal.com/gui/file/d2ae4cd314969838ad2368dfb683caef)|Win64 DLL||2020-04-08 10:25:02| |
|[c682d295b524fede3979383d75e522d8](https://www.virustotal.com/gui/file/c682d295b524fede3979383d75e522d8)|Win32 EXE|occamy|2020-04-08 02:12:57|./KISA_dataset_2020_train/d15fe07fda3f9265f5e9f13509e4ff79af446df576f02acecfc7158b0e8b0640.vir|
|[3e805824f80bba35ac06eafc80c6b6ad](https://www.virustotal.com/gui/file/3e805824f80bba35ac06eafc80c6b6ad)|Win64 EXE|Shelma|2020-04-07 17:37:30|lame_enc.dll|
|[f028d23cb4ea2c5dcf0a2b6bcaada0c0](https://www.virustotal.com/gui/file/f028d23cb4ea2c5dcf0a2b6bcaada0c0)|TXT|Sagent|2020-04-03 06:00:05|C:\ProgramData\slmgr.vbs|
|[3654c3fa86f19d253e4c70bdf5f3d158](https://www.virustotal.com/gui/file/3654c3fa86f19d253e4c70bdf5f3d158)|Win32 EXE||2020-04-01 16:37:32|%PROGRAMDATA%\identities\netwiz.exe|
|[e61ba12c33db1696715401d8fd0baae9](https://www.virustotal.com/gui/file/e61ba12c33db1696715401d8fd0baae9)|Win32 DLL||2020-04-01 16:29:49|%WINDIR%\syswow64\dpnom.dll|
|[7e4572db796e27848d23ea5d1e8604aa](https://www.virustotal.com/gui/file/7e4572db796e27848d23ea5d1e8604aa)|DOCX|CVE-2017-11882|2020-04-01 05:27:57|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\3b64f3fa9fa8afef5565d741868d30e829d1a8f3f4c563dc33a3505c1a630665|
|[74805c5477da842eb0798b95324f3a65](https://www.virustotal.com/gui/file/74805c5477da842eb0798b95324f3a65)|DOCX|Sagent|2020-04-01 04:51:20|accept.docx|
|[a32e1202257a2945bf0f878c58490af8](https://www.virustotal.com/gui/file/a32e1202257a2945bf0f878c58490af8)|Win32 EXE||2020-03-30 03:11:41|SangforUD.exe|
|[0342ed4d098f995680b0b60645f90e5c](https://www.virustotal.com/gui/file/0342ed4d098f995680b0b60645f90e5c)|Win32 EXE|Zbot|2020-03-18 09:41:55|rstimgr.dll|
|[4a52db18e3618f79983f0cb1dd83f34a](https://www.virustotal.com/gui/file/4a52db18e3618f79983f0cb1dd83f34a)|HTML||2020-03-16 13:14:58|C:\Users\Administrator\AppData\Local\Temp\googleofficechk.sct|
|[c803d412a5e86fa8de111b77f2a14523](https://www.virustotal.com/gui/file/c803d412a5e86fa8de111b77f2a14523)|RTF|CVE-2017-8570|2020-03-16 11:11:15|15451-c803d412a5e86fa8de111b77f2a14523.rtf|
|[d0ead87212b0573447f573639da49ff8](https://www.virustotal.com/gui/file/d0ead87212b0573447f573639da49ff8)|Win32 EXE||2020-03-12 08:20:36|ConsoleApplicatio2.exe|
|[c2adf8bf8d8e4409a4725d0334ed8aa6](https://www.virustotal.com/gui/file/c2adf8bf8d8e4409a4725d0334ed8aa6)|Win32 EXE||2020-03-12 08:20:29|C:\Users\aETAdzjz\AppData\Roaming\mIcrOsoft\winDows\starT meNu\progRams\startup\svupdate32.exe|
|[52e32de77509dcb406da3b81fb9055d7](https://www.virustotal.com/gui/file/52e32de77509dcb406da3b81fb9055d7)|DOCX|CVE-2017-8570|2020-03-12 06:35:53|afchunk2.docx|
|[f17d7098bde0b29441bfcd797812cf88](https://www.virustotal.com/gui/file/f17d7098bde0b29441bfcd797812cf88)|DOCX|CVE-2017-8570|2020-03-12 04:05:46|协议编号191287A.docx|
|[359d2d301455a95f8a2655965b386278](https://www.virustotal.com/gui/file/359d2d301455a95f8a2655965b386278)|RAR|CVE-2017-8570|2020-03-12 01:32:34|技術協議.rar|
|[bb72720bc4583c6c4c3caa883a7dec95](https://www.virustotal.com/gui/file/bb72720bc4583c6c4c3caa883a7dec95)|Win64 DLL|Razy|2020-03-09 10:55:55|C:\Windows\system32\msfte.dll|
|[e48b89715bf5e4c55eb5a1fed67865d9](https://www.virustotal.com/gui/file/e48b89715bf5e4c55eb5a1fed67865d9)|Win32 EXE|occamy|2020-03-09 10:55:55|c:\users\admini~1\appdata\local\temp\xbqjdvxata.exe|
|[03bd34a9ba4890f37ac8fed78feac199](https://www.virustotal.com/gui/file/03bd34a9ba4890f37ac8fed78feac199)|Win32 EXE|Glupteba|2020-03-09 10:55:55|C:\Windows\System32\Identities\bindsvc.exe|
|[ff5d43b210545f931ae80a847d1789bb](https://www.virustotal.com/gui/file/ff5d43b210545f931ae80a847d1789bb)|Win32 EXE||2020-03-09 10:55:55|C:\Users\Administrator\AppData\Local\Temp\wzbhqcoelq.exe|
|[186b2e42de0d2e58d070313bd6730243](https://www.virustotal.com/gui/file/186b2e42de0d2e58d070313bd6730243)|Win32 EXE|occamy|2020-03-09 10:53:51|?filepath=%2Fopt%2Fvarys%2Fmedia%2Fsample%2F&vthash=186b2e42de0d2e58d070313bd6730243&downfile=downfile|
|[545b498076a85dba0b883d51374c70c8](https://www.virustotal.com/gui/file/545b498076a85dba0b883d51374c70c8)|Win64 DLL||2020-02-05 05:37:13|545b498076a85dba0b883d51374c70c8.virus|
|[30ee2b1416871b25a2845e3c0bb2f7b6](https://www.virustotal.com/gui/file/30ee2b1416871b25a2845e3c0bb2f7b6)|Win32 DLL||2020-02-02 05:35:58|30ee2b1416871b25a2845e3c0bb2f7b6.virus|
|[a4129bd11e278866dbd4ca5d7ee8b722](https://www.virustotal.com/gui/file/a4129bd11e278866dbd4ca5d7ee8b722)|Win64 DLL|Razy|2020-01-30 18:39:16|67544534c38ead676d9cdb814d4f11571efa894b78434607dffef963fe3f2549.sample|
|[2c00d68c593bf8b4c32f3d4c5ff5563d](https://www.virustotal.com/gui/file/2c00d68c593bf8b4c32f3d4c5ff5563d)|TXT||2020-01-30 17:00:13|myvtfile.exe|
|[f54222f6864b65de1b3ff43974ab0ea5](https://www.virustotal.com/gui/file/f54222f6864b65de1b3ff43974ab0ea5)|DOS EXE||2020-01-30 16:50:39|user_list.exe|
|[ce2d85ea1a8c1922b6d60f2aee6cc81a](https://www.virustotal.com/gui/file/ce2d85ea1a8c1922b6d60f2aee6cc81a)|DOS EXE||2020-01-30 16:27:31|query_list.db|
|[eb1d5ddab34853d5b2b93033247a738c](https://www.virustotal.com/gui/file/eb1d5ddab34853d5b2b93033247a738c)|unknown||2020-01-30 16:19:39|C:\Users\Administrator\AppData\Local\Temp\query_list.bin|
|[7a7e108d2bb1082dabdddd95c9a09fe5](https://www.virustotal.com/gui/file/7a7e108d2bb1082dabdddd95c9a09fe5)|TXT||2020-01-29 10:14:21|myvtfile.exe|
|[9b79f3df96d3033c755e77b3c68e00f6](https://www.virustotal.com/gui/file/9b79f3df96d3033c755e77b3c68e00f6)|TXT||2020-01-26 19:07:47|myvtfile.exe|
|[23a8e9c21bd27494af9b804ea2018add](https://www.virustotal.com/gui/file/23a8e9c21bd27494af9b804ea2018add)|TXT||2020-01-26 18:27:56|164.js|
|[967fcf185634def5177f74b0f703bdc0](https://www.virustotal.com/gui/file/967fcf185634def5177f74b0f703bdc0)|Win32 EXE|Skeeyah|2020-01-24 21:46:49|SangforUD.exe|
|[6f324f8d3d8b9c7a80b40944fb82167a](https://www.virustotal.com/gui/file/6f324f8d3d8b9c7a80b40944fb82167a)|Win64 DLL||2020-01-23 20:07:55|query_list.exe|
|[6d8c949e8df241d4527c2b1727b0f84c](https://www.virustotal.com/gui/file/6d8c949e8df241d4527c2b1727b0f84c)|Win32 DLL|Ursu|2020-01-23 20:01:15|CVE-2020-0674.exe|
|[02fa09db4e0d17cbfd53b091817441db](https://www.virustotal.com/gui/file/02fa09db4e0d17cbfd53b091817441db)|unknown||2020-01-23 19:56:31|C:\Users\Administrator\AppData\Local\Temp\user_list.db|
|[c5d5cb99291fa4b2a68b5ea3ff9d9f9a](https://www.virustotal.com/gui/file/c5d5cb99291fa4b2a68b5ea3ff9d9f9a)|Win32 EXE||2020-01-21 00:02:13|SangforUD.exe|
|[74a1ef300d8d29f06958b9f383e61901](https://www.virustotal.com/gui/file/74a1ef300d8d29f06958b9f383e61901)|Win32 EXE|Zapchast|2020-01-13 18:44:58|sshkeypairgen.exe|
|[8aa069860d591119af2859856ad5f063](https://www.virustotal.com/gui/file/8aa069860d591119af2859856ad5f063)|Win64 DLL|Zbot|2019-11-27 09:40:17|lame_enc.dll|
|[a711d13de8badc06bb0a6566aeef5b99](https://www.virustotal.com/gui/file/a711d13de8badc06bb0a6566aeef5b99)|Win32 DLL||2019-11-27 09:02:54|4860000.exe|
|[b9013c4252103795c74b84547bfc212e](https://www.virustotal.com/gui/file/b9013c4252103795c74b84547bfc212e)|Win32 DLL||2019-11-27 08:48:25|6700000.exe|
|[f1f0033b446fca7894f8442421b2d94a](https://www.virustotal.com/gui/file/f1f0033b446fca7894f8442421b2d94a)|Win32 DLL||2019-11-27 08:40:54|3360000.exe|
|[2d958190c963b07fed077103d2c0c165](https://www.virustotal.com/gui/file/2d958190c963b07fed077103d2c0c165)|Win32 DLL||2019-11-27 08:26:59|61A90000.exe|
|[5ffd69b00c96c84e298edd74ec2994cd](https://www.virustotal.com/gui/file/5ffd69b00c96c84e298edd74ec2994cd)|Win32 DLL||2019-11-27 07:52:08|66C40000.exe|
|[4e744f7ad4db3c605b4707eec5ee5f34](https://www.virustotal.com/gui/file/4e744f7ad4db3c605b4707eec5ee5f34)|Win64 DLL||2018-05-17 09:36:31|svchost.exe.1bin.bin|
|[89849da283f0473bc6f5449d281f5bc8](https://www.virustotal.com/gui/file/89849da283f0473bc6f5449d281f5bc8)|Win64 DLL||2018-05-16 02:30:10|explorer.exe_0x5790000-0x34000.bin|
|[cd14348d154afbd3eac69c1d185433ee](https://www.virustotal.com/gui/file/cd14348d154afbd3eac69c1d185433ee)|Win64 DLL||2018-05-16 02:29:06|explorer.exe_0x5760000-0x2f000.bin|
|[dc0222f1e0868c3612a93ba2d83b99be](https://www.virustotal.com/gui/file/dc0222f1e0868c3612a93ba2d83b99be)|Win32 EXE||2016-08-15 19:17:21|Command line RAR|
