**NAME:**  
ChinaZ  

**Description**:  
An underground DDoS organization in China that deliver BillGates, DDOSClient and xorddos through SSH/Telnet brute forcing 
  
**References**:  

