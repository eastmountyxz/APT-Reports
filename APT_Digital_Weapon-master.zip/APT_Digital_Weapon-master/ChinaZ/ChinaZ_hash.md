|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5779ae6e3805eb1aeec6f31d650d932a](https://www.virustotal.com/gui/file/5779ae6e3805eb1aeec6f31d650d932a)|ELF executable||2019-12-10 16:06:53|777|
|[25c5d70a0403a1477d03f23fb54dc894](https://www.virustotal.com/gui/file/25c5d70a0403a1477d03f23fb54dc894)|ELF executable||2019-12-06 03:49:31|1888|
|[ce7e6794b97cd71e536cdc09de81955c](https://www.virustotal.com/gui/file/ce7e6794b97cd71e536cdc09de81955c)|ELF executable||2019-12-06 03:48:20|yk|
|[b1fcab441a1221b33206924f12af64a0](https://www.virustotal.com/gui/file/b1fcab441a1221b33206924f12af64a0)|ELF executable||2019-12-06 03:45:29|ccyk|
|[4bfc360791eda8959554af2239ee9d00](https://www.virustotal.com/gui/file/4bfc360791eda8959554af2239ee9d00)|Win32 EXE||2019-12-05 18:26:35|NewLinuxManager|
|[749fd0838956710aefa0b1e2d8b08bdc](https://www.virustotal.com/gui/file/749fd0838956710aefa0b1e2d8b08bdc)|Win32 EXE|Zegost|2019-03-08 19:33:52|TeamViewer|
|[5e004b2d3df9d17f540467b740be9122](https://www.virustotal.com/gui/file/5e004b2d3df9d17f540467b740be9122)|ELF executable||2019-02-15 12:41:27|yk|
|[4e0a5d7eab2f18a2d73da9e4c4757248](https://www.virustotal.com/gui/file/4e0a5d7eab2f18a2d73da9e4c4757248)|Win32 EXE||2019-01-13 19:16:32|yk.exe|
|[0fc0b8354e53c46d98d01e1cff696ffe](https://www.virustotal.com/gui/file/0fc0b8354e53c46d98d01e1cff696ffe)|ELF executable|Dofloo|2018-12-22 09:48:33|/home/wys/botnet_v2/botnet-procedure/169|
|[9f2716d4d94d65ff41b84bee50d9c259](https://www.virustotal.com/gui/file/9f2716d4d94d65ff41b84bee50d9c259)|Win32 EXE|Parite|2018-12-22 05:55:47|360sd.exe|
|[89df40df90cc346b6e8e9107ebb1151b](https://www.virustotal.com/gui/file/89df40df90cc346b6e8e9107ebb1151b)|Win32 EXE|FakeLPK|2018-12-19 17:25:07|lxck|
|[9a05553529e15156452dc060085705e2](https://www.virustotal.com/gui/file/9a05553529e15156452dc060085705e2)|ELF executable||2018-12-17 21:57:52|/home/wys/botnet_v2/botnet-procedure/17|
|[4e57d894c5aaf17cd3109b50b53e0125](https://www.virustotal.com/gui/file/4e57d894c5aaf17cd3109b50b53e0125)|ELF executable||2018-12-17 21:29:42|/media/ahmed/0f0b5179-b625-471d-a08b-8cc99742b63c/IoTmalware/Malware/IoTFiltered/a8d0928098cc43e7b9e8ba3b03507d342489dea832816dfc083c356b346f8a3d|
|[93a9a44b6c2ceca50f2c2e084b04b45c](https://www.virustotal.com/gui/file/93a9a44b6c2ceca50f2c2e084b04b45c)|ELF executable|Dofloo|2018-12-14 16:02:27|/home/wys/botnet_v2/botnet-procedure/8|
|[5e159906ddfd63936ff7472eb0f2ed47](https://www.virustotal.com/gui/file/5e159906ddfd63936ff7472eb0f2ed47)|ELF executable|ganiw|2018-12-08 14:34:01|/home/wys/botnet_v2/botnet-procedure/259|
|[cfe42bd537f0019bec42db0a2beb2f1e](https://www.virustotal.com/gui/file/cfe42bd537f0019bec42db0a2beb2f1e)|ELF executable|ganiw|2018-12-08 06:50:49|/home/wys/botnet_v2/botnet-procedure/170|
|[78519f9c9a363fb2330f6e9b59430462](https://www.virustotal.com/gui/file/78519f9c9a363fb2330f6e9b59430462)|Win32 EXE|Zegost|2018-12-04 13:04:15|360sd.exe|
|[1bfe8536fb3aadb83a8f5606535bf32c](https://www.virustotal.com/gui/file/1bfe8536fb3aadb83a8f5606535bf32c)|ELF executable||2018-12-02 07:01:30|/media/ahmed/0f0b5179-b625-471d-a08b-8cc99742b63c/IoTmalware/Malware/IoTFiltered/d97ffba4169df8b206f6fc588ba594e84539b321fae9247723d6b42940116fa5|
|[2dfaeb30abdded3b796cdb1ec659f8d3](https://www.virustotal.com/gui/file/2dfaeb30abdded3b796cdb1ec659f8d3)|ELF executable||2018-12-02 04:43:20|32|
|[7849351d7a47598c134aff817d2099f6](https://www.virustotal.com/gui/file/7849351d7a47598c134aff817d2099f6)|Win32 EXE|Zegost|2018-12-01 17:30:43|360sd.exe|
|[435b230c5632adf843ba572f8a56637f](https://www.virustotal.com/gui/file/435b230c5632adf843ba572f8a56637f)|ELF executable||2018-11-10 23:06:37|777|
|[99829ccdcb48d3acca98e8cd51e1d74c](https://www.virustotal.com/gui/file/99829ccdcb48d3acca98e8cd51e1d74c)|ELF executable||2018-11-01 23:19:15|777|
|[be4ae72855f18c3c464c42c227492fe6](https://www.virustotal.com/gui/file/be4ae72855f18c3c464c42c227492fe6)|ELF executable||2018-11-01 23:16:41|yk|
|[55b79fba4889272a81a15816c7770ae9](https://www.virustotal.com/gui/file/55b79fba4889272a81a15816c7770ae9)|Win32 EXE|Redosdru|2018-10-30 08:30:24|Copyright ? 2013|
|[c01e1cdc39d7f323c22ad6e3d12e10b7](https://www.virustotal.com/gui/file/c01e1cdc39d7f323c22ad6e3d12e10b7)|Win32 EXE|FakeLPK|2018-06-17 07:16:06|Server|
|[d623fe96c76ad49810ef05278d41b407](https://www.virustotal.com/gui/file/d623fe96c76ad49810ef05278d41b407)|Win32 EXE|Malex|2018-02-03 06:19:21|cxv?./ertw./re|
|[6e5d360dd3685ae951d159344ddabf8a](https://www.virustotal.com/gui/file/6e5d360dd3685ae951d159344ddabf8a)|Win32 EXE|FakeLPK|2017-12-13 20:45:54|Server|
