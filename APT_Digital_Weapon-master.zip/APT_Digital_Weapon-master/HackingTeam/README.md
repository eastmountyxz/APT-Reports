**NAME:**  
HackingTeam  
  
**Description**:   
HackingTeam was founded in 2003 by two Italian entrepreneurs. It is a Milan-based information technology company that sells offensive intrusion and surveillance capabilities to governments, law enforcement agencies and corporations
In July 2015, it suffered a damaging hack with 400GB of internal data – including the once-secret list of customers, internal communications, and spyware source code – leaked online. Since then, many 0-days collected by Hacking Team and became publicly available during the breach were used by several APT groups

**References**:  
https://www.welivesecurity.com/2018/03/09/new-traces-hacking-team-wild/