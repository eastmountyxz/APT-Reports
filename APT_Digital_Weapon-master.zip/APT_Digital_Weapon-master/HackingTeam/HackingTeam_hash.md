|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[8a64017953d0840323318bc224bab9c7](https://www.virustotal.com/gui/file/8a64017953d0840323318bc224bab9c7)|SWF|CVE-2018-15982|2018-12-25 12:17:25|swf_exploit|
|[1cbc626abbe10a4fae6abf0f405c35e2](https://www.virustotal.com/gui/file/1cbc626abbe10a4fae6abf0f405c35e2)|Win32 EXE||2018-11-30 06:24:45|backup.exe|
|[9c65fa48d29e8a0eb1ad80b10b3d9603](https://www.virustotal.com/gui/file/9c65fa48d29e8a0eb1ad80b10b3d9603)|DOCX|CVE-2018-15982|2018-11-29 10:10:13|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/CVE-2018-15982/33.bin|
|[04ce10ca99e31535eb1fcda821f5a24c](https://www.virustotal.com/gui/file/04ce10ca99e31535eb1fcda821f5a24c)|JPEG||2018-11-29 08:18:37|scan042.jpg|
|[92b1c50c3ddf8289e85cbb7f8eead077](https://www.virustotal.com/gui/file/92b1c50c3ddf8289e85cbb7f8eead077)|DOCX|CVE-2018-15982|2018-11-29 08:01:39|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/CVE-2018-15982/22.bin|
|[7d92dd6e2bff590437dad2cfa221d976](https://www.virustotal.com/gui/file/7d92dd6e2bff590437dad2cfa221d976)|Win32 EXE|miner|2018-10-03 21:59:17|c2a827cd8aefa54fb2f91b0f767292d9|
|[f49da7c983fe65ba301695188006d979](https://www.virustotal.com/gui/file/f49da7c983fe65ba301695188006d979)|Win32 EXE||2018-08-27 05:21:49|76a3e546ada90fb71192d48edbe0d9092c2a94bb.exe|
|[ee34f466491a5c5cd7423849f32b58f5](https://www.virustotal.com/gui/file/ee34f466491a5c5cd7423849f32b58f5)|SWF||2018-06-01 05:38:37|ee34f466491a5c5cd7423849f32b58f5.virus|
|[c8aaaa517277fb0dbb4bbf724245e663](https://www.virustotal.com/gui/file/c8aaaa517277fb0dbb4bbf724245e663)|XLSX|o97m|2018-05-31 19:46:54|c8aaaa517277fb0dbb4bbf724245e663.virus|
|[9d23cad207b2b5f9120f405bb70c295d](https://www.virustotal.com/gui/file/9d23cad207b2b5f9120f405bb70c295d)|Win32 EXE|graftor|2018-03-18 06:58:17|9dfc7e78892a9f18d2d15adbfa52cda379ddd963.exe|
|[20c8ebfd075669d5eeb6d9fbe2590860](https://www.virustotal.com/gui/file/20c8ebfd075669d5eeb6d9fbe2590860)|Win32 EXE||2018-03-18 06:57:05| |
|[70a937b2504b3ad6c623581424c7e53d](https://www.virustotal.com/gui/file/70a937b2504b3ad6c623581424c7e53d)|Android|Skygofree|2018-02-19 00:02:31|/home/spot/Desktop/2ndCodeGraphsExtension/Dataset/Malicious/Apps/9722d16ec5d19edca0c6f53ba7d5ca2df650fd6892ed5c2a7b279b2299487b0a|
|[c0618556e9ef16b35b042bc29aeb9291](https://www.virustotal.com/gui/file/c0618556e9ef16b35b042bc29aeb9291)|Win32 EXE||2018-02-10 14:32:50|Statement of the Saharawi government.exe|
|[0bc28ac5f2cadd524e7f443e06ad2a2b](https://www.virustotal.com/gui/file/0bc28ac5f2cadd524e7f443e06ad2a2b)|Android|Skygofree|2018-01-22 11:02:02|0bc28ac5f2cadd524e7f443e06ad2a2b.virus|
|[6bcc3559d7405f25ea403317353d905f](https://www.virustotal.com/gui/file/6bcc3559d7405f25ea403317353d905f)|Win32 EXE|Skygofree|2018-01-17 15:14:51|6bcc3559d7405f25ea403317353d905f.virus|
|[f673bb1d519138ced7659484c0b66c5b](https://www.virustotal.com/gui/file/f673bb1d519138ced7659484c0b66c5b)|Win32 EXE|Skygofree|2018-01-17 15:08:52|f673bb1d519138ced7659484c0b66c5b.virus|
|[55fb01048b6287eadcbd9a0f86d21adf](https://www.virustotal.com/gui/file/55fb01048b6287eadcbd9a0f86d21adf)|Win32 EXE|Skygofree|2018-01-17 14:59:09|55fb01048b6287eadcbd9a0f86d21adf.virus|
|[d3baa45ed342fbc5a56d974d36d5f73f](https://www.virustotal.com/gui/file/d3baa45ed342fbc5a56d974d36d5f73f)|Win32 EXE|Skygofree|2018-01-17 14:32:07|d3baa45ed342fbc5a56d974d36d5f73f.virus|
|[395f9f87df728134b5e3c1ca4d48e9fa](https://www.virustotal.com/gui/file/395f9f87df728134b5e3c1ca4d48e9fa)|Win32 EXE||2018-01-17 14:26:12|395f9f87df728134b5e3c1ca4d48e9fa.virus|
|[16311b16fd48c1c87c6476a455093e7a](https://www.virustotal.com/gui/file/16311b16fd48c1c87c6476a455093e7a)|Win32 EXE||2018-01-17 14:20:52|16311b16fd48c1c87c6476a455093e7a.virus|
|[a287a434a0d40833d3ebf5808950b858](https://www.virustotal.com/gui/file/a287a434a0d40833d3ebf5808950b858)|Android|Skygofree|2017-11-28 09:20:57|a287a434a0d40833d3ebf5808950b858.virus|
|[d6ca39fef03cf67f8ddc2a560874d80d](https://www.virustotal.com/gui/file/d6ca39fef03cf67f8ddc2a560874d80d)|Win32 EXE||2017-10-16 18:31:03|E:/virussign/malware/new_request/20171024/d6ca39fef03cf67f8ddc2a560874d80d.vir|
|[39fca709b416d8da592de3a3f714dce8](https://www.virustotal.com/gui/file/39fca709b416d8da592de3a3f714dce8)|Android|Skygofree|2017-10-03 18:42:03|Skygofree_exploits.zip|
|[7e6cb66a3623258444639d1fc2fd533f](https://www.virustotal.com/gui/file/7e6cb66a3623258444639d1fc2fd533f)|ZIP||2017-03-08 23:55:20|7e6cb66a3623258444639d1fc2fd533f.virus|
|[6964866106c0a353a7b91b580933c5d6](https://www.virustotal.com/gui/file/6964866106c0a353a7b91b580933c5d6)|ZIP|Skygofree|2017-03-08 23:55:19|6964866106c0a353a7b91b580933c5d6.virus|
|[d574d0049f797611589803643a8aa3c3](https://www.virustotal.com/gui/file/d574d0049f797611589803643a8aa3c3)|Android|Skygofree|2017-01-20 05:22:37|d574d0049f797611589803643a8aa3c3.virus|
|[3f0e8a3ad9fab04377b8e9a57a26f972](https://www.virustotal.com/gui/file/3f0e8a3ad9fab04377b8e9a57a26f972)|Android|Skygofree|2016-11-24 04:00:49|3f0e8a3ad9fab04377b8e9a57a26f972.virus|
|[d9c7349e807e0f12eaa67b2de522954f](https://www.virustotal.com/gui/file/d9c7349e807e0f12eaa67b2de522954f)|ZIP|Skygofree|2016-11-24 00:09:53|d9c7349e807e0f12eaa67b2de522954f.virus|
|[708445b8d358c254e861effffd4f819b](https://www.virustotal.com/gui/file/708445b8d358c254e861effffd4f819b)|Android|Skygofree|2016-11-23 20:08:58|708445b8d358c254e861effffd4f819b_Skygofree_pe.jar|
|[a2a8e8ac6f5fa5801395252e11afb356](https://www.virustotal.com/gui/file/a2a8e8ac6f5fa5801395252e11afb356)|Android|Skygofree|2016-11-02 10:33:00|a2a8e8ac6f5fa5801395252e11afb356.virus|
|[e56c0bb65c68e89921b4a8348976a0e9](https://www.virustotal.com/gui/file/e56c0bb65c68e89921b4a8348976a0e9)|Win32 EXE||2016-08-05 07:45:02|c:\!!Prace\!!To_do\e56c0bb65c68e89921b4a8348976a0e9|
|[6f5c89473c9e6baf741629549ec52fe1](https://www.virustotal.com/gui/file/6f5c89473c9e6baf741629549ec52fe1)|Win32 EXE||2016-01-30 00:56:34| |
|[80eab4d4b117ef420fe9cdd63d6a9b99](https://www.virustotal.com/gui/file/80eab4d4b117ef420fe9cdd63d6a9b99)|Win32 EXE||2015-11-24 14:54:54|D:\work\download\______samplesreview\samplesnew\Samples\e85c2eab4c9eea8d0c99e58199f313ca4e1d1735|
|[7f1f9fa306c2e71ecb96daefafadc6e3](https://www.virustotal.com/gui/file/7f1f9fa306c2e71ecb96daefafadc6e3)|Win32 EXE||2015-09-09 01:24:46| |
|[f3001d31503a2c610a6c490c24e87aba](https://www.virustotal.com/gui/file/f3001d31503a2c610a6c490c24e87aba)|Win32 EXE||2015-09-09 01:24:22| |
|[8f56458f3fb710c4c1d103e7e9951703](https://www.virustotal.com/gui/file/8f56458f3fb710c4c1d103e7e9951703)|Win32 EXE||2015-09-09 01:24:17| |
|[2612c832ffebbdb7dab7e5b8d1905390](https://www.virustotal.com/gui/file/2612c832ffebbdb7dab7e5b8d1905390)|Win32 EXE||2015-09-09 01:24:06|C:\gwhCUd\1DzCsDm6\i1YypTo.fon|
|[3af02e9efcf30224fee6dae3c1f41ede](https://www.virustotal.com/gui/file/3af02e9efcf30224fee6dae3c1f41ede)|Win32 EXE|Wacatac|2020-03-14 20:14:23|dttcodexgigas.426db001875e3c067dd6203f7798549e8b0ba6d4|
|[812c81bf15535e90dc479d6bd69dd426](https://www.virustotal.com/gui/file/812c81bf15535e90dc479d6bd69dd426)|Win32 EXE|Jatif|2020-03-14 17:00:29|812c81bf15535e90dc479d6bd69dd426.virus|
|[dcda748387c572ed1aa7424e26278f70](https://www.virustotal.com/gui/file/dcda748387c572ed1aa7424e26278f70)|Win32 EXE|Jatif|2020-03-09 04:06:33|dttcodexgigas.3335e8e643913ab7337f4c7373a475a771b2695c|
|[3f67b25082212393668c51710fe8191d](https://www.virustotal.com/gui/file/3f67b25082212393668c51710fe8191d)|Win32 EXE||2020-03-08 17:56:50|LiveNetTV.exe|
|[51a2646f7586c1864507d057ef1f3500](https://www.virustotal.com/gui/file/51a2646f7586c1864507d057ef1f3500)|Win32 EXE||2020-01-07 08:54:25|C:\Users\test2\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\java.exe|
|[b4692bb8776ab351a8104346b858aea5](https://www.virustotal.com/gui/file/b4692bb8776ab351a8104346b858aea5)|Win32 EXE||2019-10-18 21:44:52|RapidEXE|
