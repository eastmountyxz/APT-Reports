|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[9df776b9933fbf95e3d462e04729d074](https://www.virustotal.com/gui/file/9df776b9933fbf95e3d462e04729d074)|Win32 EXE|DanaBot|2019-05-22 10:44:10|AdobeReport.exe|
|[3fb5fb9001084de6c059d6731ae5ad38](https://www.virustotal.com/gui/file/3fb5fb9001084de6c059d6731ae5ad38)|Win32 DLL||2019-09-03 19:02:56|2-uupgut.dll|
|[394a95fe2701ce1243f251f2eeba132b](https://www.virustotal.com/gui/file/394a95fe2701ce1243f251f2eeba132b)|Win32 DLL||2019-09-03 13:44:29|xitne-pg.dll|
|[1ce7e8e160d5fbcf37fe57cc09ada5ef](https://www.virustotal.com/gui/file/1ce7e8e160d5fbcf37fe57cc09ada5ef)|Win32 DLL|TrickBot|2019-09-03 13:44:19|RunCal.dll|
|[3e0ffa47f028032ffb7d92664571c452](https://www.virustotal.com/gui/file/3e0ffa47f028032ffb7d92664571c452)|Win32 DLL||2019-09-03 13:44:15|uagug1sg.dll|
|[45030a534b36753be9bf38889612ad4a](https://www.virustotal.com/gui/file/45030a534b36753be9bf38889612ad4a)|Win32 EXE|MSILPerseus|2019-08-23 10:19:13|AppTrace.exe|
|[3d84e5a32b5f865e78d8df306585dd85](https://www.virustotal.com/gui/file/3d84e5a32b5f865e78d8df306585dd85)|Win32 EXE||2019-08-16 23:20:03|AppTrace.exe|
|[f0ed1d927eac00b44808ccc0bd9f7858](https://www.virustotal.com/gui/file/f0ed1d927eac00b44808ccc0bd9f7858)|XLS|o97m|2019-08-02 00:36:28|43ef6f87e2abc6551943557df7f345aeaf50c881772d953317fc7250b211ff9b.xls|
|[d47c5341d90c45a47bb36cb15b877d23](https://www.virustotal.com/gui/file/d47c5341d90c45a47bb36cb15b877d23)|Win32 DLL||2019-06-07 06:03:38|oyapmy9b.dll|
|[8a21995816c13cd82a154f3a94ffbce7](https://www.virustotal.com/gui/file/8a21995816c13cd82a154f3a94ffbce7)|Win32 EXE|MSILPerseus|2019-06-04 13:25:34|GooglUPDT.exe|
|[ae19ccc0a8148ca9247c403b08c28993](https://www.virustotal.com/gui/file/ae19ccc0a8148ca9247c403b08c28993)|Win32 DLL|Ursu|2019-05-25 01:10:49|UpdateCreator.dll|
|[4429adea1a05b0ae896b0386fbb2d069](https://www.virustotal.com/gui/file/4429adea1a05b0ae896b0386fbb2d069)|Win32 DLL||2019-05-25 01:10:49|z3payca3.dll|
|[0e0f45bcba82390ede020a88a13ce9c6](https://www.virustotal.com/gui/file/0e0f45bcba82390ede020a88a13ce9c6)|Win32 DLL||2019-05-24 20:24:04|yjzeuvgy.dll|
|[8486004b414f8e539669ba044f024cb5](https://www.virustotal.com/gui/file/8486004b414f8e539669ba044f024cb5)|XLS|o97m|2019-05-22 08:10:12|43ef6f87e2abc6551943557df7f345aeaf50c881772d953317fc7250b211ff9b.bin|
|[b5a1371aecc82ee00900e2928b9c1e02](https://www.virustotal.com/gui/file/b5a1371aecc82ee00900e2928b9c1e02)|XLS|EmoDldr|2019-02-26 07:39:51|t.xls|
|[132a9a296f6d3293b027ca537ffc4876](https://www.virustotal.com/gui/file/132a9a296f6d3293b027ca537ffc4876)|XLS|o97m|2019-02-26 07:38:16|t.xls|
|[a992c50c81c1fb4dd013dc24d2c46c43](https://www.virustotal.com/gui/file/a992c50c81c1fb4dd013dc24d2c46c43)|XLS|o97m|2019-02-26 07:02:46|v.xls|
|[3e4b4d80745aef047277fbae23cf33ab](https://www.virustotal.com/gui/file/3e4b4d80745aef047277fbae23cf33ab)|XLS|o97m|2019-02-26 06:45:27|v.xls|
|[1a870169bae77a749ff72bca589a114e](https://www.virustotal.com/gui/file/1a870169bae77a749ff72bca589a114e)|XLS|Wacatac|2019-02-25 13:13:28|v.xls|
|[7dd04bfaf4f0b50e32aa3c6828038dcd](https://www.virustotal.com/gui/file/7dd04bfaf4f0b50e32aa3c6828038dcd)|XLS||2019-02-25 13:12:54|v.xls|
|[b4173987b6de7cbbe950ccf90577af20](https://www.virustotal.com/gui/file/b4173987b6de7cbbe950ccf90577af20)|XLS|o97m|2019-02-25 13:12:03|v.xls|
|[23878d8632db7dd27bf4f7461013496a](https://www.virustotal.com/gui/file/23878d8632db7dd27bf4f7461013496a)|XLS||2019-02-25 13:11:25|v.xls|
|[4ec14fa3613ac183357e1ff03185f63a](https://www.virustotal.com/gui/file/4ec14fa3613ac183357e1ff03185f63a)|XLS||2019-02-25 13:10:15|v.xls|
|[4fc270244fd6deb9ad8c68d1b0ea8f63](https://www.virustotal.com/gui/file/4fc270244fd6deb9ad8c68d1b0ea8f63)|XLS|o97m|2019-02-25 13:08:46|v.xls|
|[da6809f83ad47a36b9f0df52bffa5476](https://www.virustotal.com/gui/file/da6809f83ad47a36b9f0df52bffa5476)|XLS||2019-02-25 13:07:38|v.xls|
|[d26b3c695f44082ba9351f6e470e6b03](https://www.virustotal.com/gui/file/d26b3c695f44082ba9351f6e470e6b03)|XLS||2019-02-25 13:06:54|v.xls|
|[ff676a8123e48452c291790f1dc49cb8](https://www.virustotal.com/gui/file/ff676a8123e48452c291790f1dc49cb8)|XLS|o97m|2019-02-25 13:01:50|v.xls|
|[8fab19ebc0562b9955bc3127296f0a1a](https://www.virustotal.com/gui/file/8fab19ebc0562b9955bc3127296f0a1a)|XLS||2019-02-25 13:01:07|v.xls|
|[e3329b100395e9349f5c58f11f6e0f26](https://www.virustotal.com/gui/file/e3329b100395e9349f5c58f11f6e0f26)|XLS||2019-02-25 12:59:03|v.xls|
|[f30a79eb0861e64d9f569bc678797314](https://www.virustotal.com/gui/file/f30a79eb0861e64d9f569bc678797314)|XLS|androidos|2019-02-25 12:57:29|v.xls|
|[3c218ef18e55ca7ce68acd6cc716e3f4](https://www.virustotal.com/gui/file/3c218ef18e55ca7ce68acd6cc716e3f4)|XLS||2019-02-25 12:56:40|v.xls|
|[da23ed988001f239b86cc52cb3e96b80](https://www.virustotal.com/gui/file/da23ed988001f239b86cc52cb3e96b80)|XLS|Sagent|2019-02-25 12:52:16|da23ed988001f239b86cc52cb3e96b80.virobj|
|[4e4cd9720c963682970a16bcf65c33dc](https://www.virustotal.com/gui/file/4e4cd9720c963682970a16bcf65c33dc)|XLS|o97m|2019-02-25 12:51:07|v.xls|
|[0b44f429e64b8c1b95e272d624ca0747](https://www.virustotal.com/gui/file/0b44f429e64b8c1b95e272d624ca0747)|XLS|Sagent|2019-02-25 12:47:09|v.xls|
|[915d5734d929bcda4940daf763485838](https://www.virustotal.com/gui/file/915d5734d929bcda4940daf763485838)|XLS|o97m|2019-02-25 12:44:55|v.xls|
|[64aad6b599059f65c2baa238f086cc5e](https://www.virustotal.com/gui/file/64aad6b599059f65c2baa238f086cc5e)|XLS|Sagent|2019-02-25 12:43:21|v.xls|
|[2453064182a0831579bc2d5d2b34b4b1](https://www.virustotal.com/gui/file/2453064182a0831579bc2d5d2b34b4b1)|XLS|Sagent|2019-02-25 12:39:59|v.xls|
|[91d0ee4bfef22003f03e119e34311420](https://www.virustotal.com/gui/file/91d0ee4bfef22003f03e119e34311420)|XLS|occamy|2019-02-25 12:38:44|91d0ee4bfef22003f03e119e34311420.virobj|
|[ce9cda67daa5babd6bef7541209a7497](https://www.virustotal.com/gui/file/ce9cda67daa5babd6bef7541209a7497)|XLS|Sagent|2019-02-25 12:36:44|v.xls|
|[3614fcd456ee18035ec39f5921f8f5ca](https://www.virustotal.com/gui/file/3614fcd456ee18035ec39f5921f8f5ca)|XLS|Sagent|2019-02-25 12:35:37|v.xls|
|[c7abbfe11ae78d22e0c81444aba9de99](https://www.virustotal.com/gui/file/c7abbfe11ae78d22e0c81444aba9de99)|XLS|Sagent|2019-02-25 12:34:05|v.xls|
|[7eda551dfbb9aeb5921be8d8284c41f5](https://www.virustotal.com/gui/file/7eda551dfbb9aeb5921be8d8284c41f5)|XLS|o97m|2019-02-25 12:20:01|install.xls|
|[30be2c3c189fb352d3f448722dfb61a6](https://www.virustotal.com/gui/file/30be2c3c189fb352d3f448722dfb61a6)|XLS|sagent|2019-02-25 12:17:32|install.xls|
|[7cbb5b32453f23fefa89e5bf4512db3f](https://www.virustotal.com/gui/file/7cbb5b32453f23fefa89e5bf4512db3f)|XLS||2019-02-25 12:16:01|install.xls|
|[ddaec1e4aab7e85a3289182a5ee8ce92](https://www.virustotal.com/gui/file/ddaec1e4aab7e85a3289182a5ee8ce92)|XLS||2019-02-25 12:15:02|install.xls|
|[55338b8d0dc9b1f7845936f97003ae7f](https://www.virustotal.com/gui/file/55338b8d0dc9b1f7845936f97003ae7f)|XLS||2019-02-25 12:12:07|install.xls|
|[d0de4c69f585fecf29bbc42b05dafaee](https://www.virustotal.com/gui/file/d0de4c69f585fecf29bbc42b05dafaee)|XLS||2019-02-25 12:10:50|install.xls|
|[a635bfcc8f5aadc75a903bef4ca6e486](https://www.virustotal.com/gui/file/a635bfcc8f5aadc75a903bef4ca6e486)|XLS||2019-02-25 12:07:18|install.xls|
|[f22e660731dca057474b190f82cf721b](https://www.virustotal.com/gui/file/f22e660731dca057474b190f82cf721b)|XLS||2019-02-25 11:37:49|install.xls|
|[20ee7950b4de6c1ab23f5d1f952c8ac9](https://www.virustotal.com/gui/file/20ee7950b4de6c1ab23f5d1f952c8ac9)|XLS||2019-02-25 11:36:38|install.xls|
|[c7b5afaeaf5b50c332192fc2f1c4123c](https://www.virustotal.com/gui/file/c7b5afaeaf5b50c332192fc2f1c4123c)|XLS|occamy|2019-02-25 11:34:22|install.xls|
|[bf7e9ad6a05bd56afd02a3ac79f4e8af](https://www.virustotal.com/gui/file/bf7e9ad6a05bd56afd02a3ac79f4e8af)|XLS|o97m|2019-02-25 11:33:16|install.xls|
|[02cc6e3757db65d9248d9d592e1db848](https://www.virustotal.com/gui/file/02cc6e3757db65d9248d9d592e1db848)|XLS||2019-02-25 11:18:39|install.xls|
|[e72fc1d2fa77b244f68d80c2f083063e](https://www.virustotal.com/gui/file/e72fc1d2fa77b244f68d80c2f083063e)|XLS||2019-02-25 11:17:29|install.xls|
|[499ee4dbe78749f0057a4a02b71fdc85](https://www.virustotal.com/gui/file/499ee4dbe78749f0057a4a02b71fdc85)|XLS|Sagent|2019-02-25 11:15:22|install.xls|
|[a8cbc7a945f190ba092052bce57057a6](https://www.virustotal.com/gui/file/a8cbc7a945f190ba092052bce57057a6)|XLS|Sagent|2019-02-25 11:13:58|install.xls|
|[09fb8e7b0839cd5df0a603b001ace584](https://www.virustotal.com/gui/file/09fb8e7b0839cd5df0a603b001ace584)|XLS|sagent|2019-02-25 11:12:56|install.xls|
|[2785cf1f4275a69c1788a9839fc05b8a](https://www.virustotal.com/gui/file/2785cf1f4275a69c1788a9839fc05b8a)|Win32 EXE|Tiggre|2019-02-23 18:07:21|AppTrace.exe|
|[74d1ebc08e20e7f04537c641677b408a](https://www.virustotal.com/gui/file/74d1ebc08e20e7f04537c641677b408a)|XLS||2019-02-23 12:52:54|TEST.xls|
|[5a34a5b2ff6da87028df65560cbde536](https://www.virustotal.com/gui/file/5a34a5b2ff6da87028df65560cbde536)|XLS||2019-02-23 12:50:13|TEST.xls|
|[19fb9bee00a4ee8305b919042158e3e7](https://www.virustotal.com/gui/file/19fb9bee00a4ee8305b919042158e3e7)|XLS||2019-02-23 12:46:59|TEST.xls5|
|[3178653a8ac7d7b1b9047348c434c576](https://www.virustotal.com/gui/file/3178653a8ac7d7b1b9047348c434c576)|XLS|o97m|2019-02-23 12:45:37|TEST.xls|
|[f08dcc319b705d733bcc112e5380f1dd](https://www.virustotal.com/gui/file/f08dcc319b705d733bcc112e5380f1dd)|XLS||2019-02-23 12:44:20|TEST.xls|
|[ad1e175693a18af51665cfca705f5330](https://www.virustotal.com/gui/file/ad1e175693a18af51665cfca705f5330)|XLS|o97m|2019-02-23 12:43:07|TEST.xls|
|[823f0ee63c05a9fd85285b465350d5d0](https://www.virustotal.com/gui/file/823f0ee63c05a9fd85285b465350d5d0)|XLS|o97m|2019-02-23 12:41:40|TEST.xls|
|[b473286465f67ac6a28375f742dbf91d](https://www.virustotal.com/gui/file/b473286465f67ac6a28375f742dbf91d)|XLS|o97m|2019-02-23 12:39:33|TEST.xls|
|[b7d2c9b02165961e8974ce917c40c2ac](https://www.virustotal.com/gui/file/b7d2c9b02165961e8974ce917c40c2ac)|XLS|Sagent|2019-02-23 12:37:29|TEST.xls|
|[80dbf8cf522cd076c56bd797341cf640](https://www.virustotal.com/gui/file/80dbf8cf522cd076c56bd797341cf640)|XLS|Sagent|2019-02-23 12:35:18|80dbf8cf522cd076c56bd797341cf640.virobj|
|[82304eadccc41384526e8b34c8b32ebd](https://www.virustotal.com/gui/file/82304eadccc41384526e8b34c8b32ebd)|XLS|Sagent|2019-02-23 12:31:57|TEST.xls|
|[464082dad67ce6fcadd869cfbd693a92](https://www.virustotal.com/gui/file/464082dad67ce6fcadd869cfbd693a92)|XLS|o97m|2019-02-23 11:57:49|1.xls|
|[baca439b098771b116b29606c4082f4d](https://www.virustotal.com/gui/file/baca439b098771b116b29606c4082f4d)|Win32 DLL||2019-01-11 17:51:13|RunCal.dll|
|[cdf4e1cf4f0ebfefb2aa0374984aa90a](https://www.virustotal.com/gui/file/cdf4e1cf4f0ebfefb2aa0374984aa90a)|Win32 EXE|occamy|2019-01-09 07:33:13|HPServerManager.exe|
|[592f7ea177612ec32e77732feb46a7c7](https://www.virustotal.com/gui/file/592f7ea177612ec32e77732feb46a7c7)|Win32 EXE|Disfa|2018-12-31 11:43:30|vmware_authd.exe|
|[96c75a6bf4a05c1a3768187f7bdff4b4](https://www.virustotal.com/gui/file/96c75a6bf4a05c1a3768187f7bdff4b4)|Win32 EXE|MSILPerseus|2018-12-27 11:13:31|HPServerManager.exe|
|[d571bf2a9be3e7bbcfb18c8535a18dd7](https://www.virustotal.com/gui/file/d571bf2a9be3e7bbcfb18c8535a18dd7)|Win32 DLL||2018-12-23 17:54:34|<CURRENT_DIR>\updates\5faaa283-a98c-481b-8347-8c3891b40ag8\updateengine.dll|
|[081c1044bb5df0b992bd4b743748d96a](https://www.virustotal.com/gui/file/081c1044bb5df0b992bd4b743748d96a)|Win32 EXE|occamy|2018-12-21 04:46:41|Google_Updates.exe|
|[96b4c1151f23160dd1e22d23bc56e158](https://www.virustotal.com/gui/file/96b4c1151f23160dd1e22d23bc56e158)|Win32 DLL||2018-10-26 16:30:33|UpdateCreator.dll|
|[587ca058d9c02cedf14ede98f0fffaf7](https://www.virustotal.com/gui/file/587ca058d9c02cedf14ede98f0fffaf7)|Win32 EXE|Tiggre|2018-10-23 11:11:30|GooglUPDT.exe|
|[909f6aa1abd31359a43fc329ce52d1d0](https://www.virustotal.com/gui/file/909f6aa1abd31359a43fc329ce52d1d0)|Win32 EXE|MSILPerseus|2018-09-14 08:25:10|GooglUPDT.exe|
|[ffa1c56e3dc61d8237b81212700b4ca6](https://www.virustotal.com/gui/file/ffa1c56e3dc61d8237b81212700b4ca6)|XLS|o97m|2018-09-13 16:56:49|attachment20181102-13327-rrk6tm.xls|
