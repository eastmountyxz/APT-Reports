**NAME:**  
HEXANE  
  
**Alias**  
LYCEUM, HEXANE  
  
**Description**:   
HEXANE, also known as LYCEUM, is a threat group targets organizations in sectors of strategic national importance, including oil and gas and possibly telecommunications. Secureworks pointed out that it may have been active as early as April 2018. Domain registrations suggest that a campaign in mid-2018 focused on South African targets. In May 2019, the threat group launched a campaign against oil and gas organizations in the Middle East.
  
**References**:  
https://www.secureworks.com/blog/lyceum-takes-center-stage-in-middle-east-campaign
