|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[a8ccb2fc5fec1b89f778d93096f8dd65](https://www.virustotal.com/gui/file/a8ccb2fc5fec1b89f778d93096f8dd65)|Win32 EXE||2016-01-06 03:01:35|A.tmp|
|[6c33223db475f072119fe51a2437a542](https://www.virustotal.com/gui/file/6c33223db475f072119fe51a2437a542)|Win32 EXE|Delf|2015-12-24 01:57:23|icmctr.dll/LegalCopyright|
|[0b176111ef7ec98e651ffbabf9b35a18](https://www.virustotal.com/gui/file/0b176111ef7ec98e651ffbabf9b35a18)|Win32 EXE|dynamer|2015-12-11 13:18:04|icmctr.dll/LegalCopyright|
