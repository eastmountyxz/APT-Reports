**NAME:**  
Buhtrap  
  
**Alias**  
RATPAK SPIDER, Buhtrap  

**Description**:   
Buhtrap has been active since 2014 while their first attacks against financial institutions were detected in August 2015. It focuses on banking clients as well as Russian and Ukrainian banks.
From August 2015 to February 2016, Buhtrap managed to conduct 13 successful attacks against Russian banks for a total amount of $25.7 million. The number of successful attacks against Ukrainian banks has not been identified.

**References**:  
http://www.welivesecurity.com/2015/11/11/operation-buhtrap-malware-distributed-via-ammyy-com/  
https://www.welivesecurity.com/2019/07/11/buhtrap-zero-day-espionage-campaigns/  

