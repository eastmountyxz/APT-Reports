|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[b54b618a9a6abd879e6703a9a4a53e94](https://www.virustotal.com/gui/file/b54b618a9a6abd879e6703a9a4a53e94)|DOCM|Banload|2019-06-03 08:43:41|6e820b5732cd8bb95546cf39aeb6babe90cf4cc7dde675b718710babcf1740b5.bin|
|[e50cae2066267dca70b8c52c9f4c2133](https://www.virustotal.com/gui/file/e50cae2066267dca70b8c52c9f4c2133)|Win32 EXE||2019-02-20 18:44:08|download01991.exe|
|[7cca9ee61d72f403b0158cbf39db985e](https://www.virustotal.com/gui/file/7cca9ee61d72f403b0158cbf39db985e)|Win32 EXE||2019-02-19 07:33:38|<LS_APPDATA>\tempnpb33.exe|
|[e75615e610d5d1588f2c66a37f73da94](https://www.virustotal.com/gui/file/e75615e610d5d1588f2c66a37f73da94)|Text||2019-02-13 16:27:26|myvtfile.exe|
|[4ce47693ba3af70725a14bad15dbdcd9](https://www.virustotal.com/gui/file/4ce47693ba3af70725a14bad15dbdcd9)|Text||2019-02-13 07:38:05|cd0892b7b36b2d943f472642190d00f11ee00591737bac40ab0da4a0af180238.bin|
|[c6d66c14ae265473bd89f127a439834c](https://www.virustotal.com/gui/file/c6d66c14ae265473bd89f127a439834c)|Win32 DLL||2019-02-12 19:22:28|%APPDATA%\yandex\punto switcher\user data\winmm.dll|
|[d72a094f0333964c74091652dfaca39f](https://www.virustotal.com/gui/file/d72a094f0333964c74091652dfaca39f)|Win32 EXE||2019-02-12 17:01:21|77.tmp|
|[664e95fbd9c4439c9800cc93f0474d1b](https://www.virustotal.com/gui/file/664e95fbd9c4439c9800cc93f0474d1b)|DOC|sagent|2019-02-12 08:11:30|7cef4b46501f605030427c3f0c6db5e190af8ea757d75533f900aada952da0a0.bin|
|[35be4860a6ea917a9f680f5d2faaa2e2](https://www.virustotal.com/gui/file/35be4860a6ea917a9f680f5d2faaa2e2)|DOC|sagent|2019-02-12 07:38:32|71d8407e948e2c2a14725196ed1786697e86bbc0cd7f71fd9d35cb13df3b28fd.bin|
|[aa690b8f97850356bb49cd4ae5d4851b](https://www.virustotal.com/gui/file/aa690b8f97850356bb49cd4ae5d4851b)|Win32 EXE||2019-01-23 08:15:38|myfile.exe|
|[2971c7fe58c597bdb720b44c8503a8b1](https://www.virustotal.com/gui/file/2971c7fe58c597bdb720b44c8503a8b1)|Win32 EXE||2018-12-19 15:51:06|tmp478D.tmp.exe|
|[faf833a1456e1bb85117d95c23892368](https://www.virustotal.com/gui/file/faf833a1456e1bb85117d95c23892368)|Win32 EXE|Upatre|2018-12-19 06:59:59|Акты сверки декабрь.exe|
|[82a2debcb1704944b8c87fc63a2ad853](https://www.virustotal.com/gui/file/82a2debcb1704944b8c87fc63a2ad853)|Win32 EXE|ammyy|2018-06-13 13:24:07|FZrgcj17Y5Fh1g8y0i|
|[7ddecaa263cf3f94c22c96fde346db5e](https://www.virustotal.com/gui/file/7ddecaa263cf3f94c22c96fde346db5e)|Win32 EXE|Kasidet|2018-06-13 12:56:21|%APPDATA%\dd8327bc-98b3-17a2-8a61-4c3b5e25409f\72c9b655-299a-741d-43c6-6de8275af19c.exe|
|[54717e6ba473fc2bd13701b02fc68102](https://www.virustotal.com/gui/file/54717e6ba473fc2bd13701b02fc68102)|Win32 EXE|ammyy|2018-06-13 08:37:05|AA_v3 (1).exe|
|[ce3b638d693484656650e665f911b60b](https://www.virustotal.com/gui/file/ce3b638d693484656650e665f911b60b)|Win32 EXE|agentwdcr|2018-06-13 08:12:46|Ammyy_Service.exe|
|[bdb52109b03f7fe67de814ed6f738152](https://www.virustotal.com/gui/file/bdb52109b03f7fe67de814ed6f738152)|Win32 EXE|Kasidet|2018-06-13 04:56:59|b|
|[9fa541af31a05360185c2bd475aab255](https://www.virustotal.com/gui/file/9fa541af31a05360185c2bd475aab255)|Win32 EXE|ammyy|2018-06-13 04:51:44|AA_v3.exe|
|[79d1a836423c7ee57b6127cf2930a9d9](https://www.virustotal.com/gui/file/79d1a836423c7ee57b6127cf2930a9d9)|Win32 EXE|buhtrap|2018-06-02 07:02:07|grabber.exe|
|[f36fe1716c9e38fa39186b63339ebee6](https://www.virustotal.com/gui/file/f36fe1716c9e38fa39186b63339ebee6)|DOC|o97m|2018-06-02 03:50:47|Project documents check list.doc|
|[12f65a68e13cd0d2592df43acc6bfbea](https://www.virustotal.com/gui/file/12f65a68e13cd0d2592df43acc6bfbea)|Win32 EXE||2015-12-15 08:54:30|Document.com|
|[3ee89dc8a2acd5bccaf814268715623f](https://www.virustotal.com/gui/file/3ee89dc8a2acd5bccaf814268715623f)|Win32 EXE||2014-11-21 05:38:51|6ced8d9045234155f6c549ebe7bddf9d41f6043e61c6a467ff5190e50ab68ada.bin|
|[467be8cd950e1263bb7aa616cc3eebf4](https://www.virustotal.com/gui/file/467be8cd950e1263bb7aa616cc3eebf4)|Win32 EXE||2014-11-21 05:36:16|8758c283fd27c2fc21a23867a0b2aa3f48abc74583619d9e3c0ec9e483861b87.bin|
|[1b8b3657bcebd8ed094b6e8e943cc458](https://www.virustotal.com/gui/file/1b8b3657bcebd8ed094b6e8e943cc458)|RTF|CVE-2012-0158|2014-11-21 02:35:37|ff5f695944b1b743c88745d642b04f04dd47bfd19e1c496024f5439f9d0cc87a.bin|
|[46d7770b7f62edeb8d5a5542113acf6e](https://www.virustotal.com/gui/file/46d7770b7f62edeb8d5a5542113acf6e)|Win32 DLL|buhtrap|2014-11-21 00:29:27|a0e98c0c3489ef4e752b527d2722e79c51ee55674801ed9bc1ccb905b95456c2.bin|
|[ce2151be577ab60777c9ee72a02ebbcb](https://www.virustotal.com/gui/file/ce2151be577ab60777c9ee72a02ebbcb)|Win32 EXE|ursu|2014-10-21 03:44:11|myfile.exe|
|[2dd786157bc8a6618bad11cb50e46ec4](https://www.virustotal.com/gui/file/2dd786157bc8a6618bad11cb50e46ec4)|RTF|CVE-2012-0158|2014-10-20 11:02:31|3163bee22a087279fe9b53bd1b74651ec3a1c1508f7cee137e6f9992cdcb683f.bin|
