**NAME:**  
APT-C-27  
  
**Alias**  
黄金鼠, Goldmouse, APT-C-27  
  
**Description**:   
APT-C-27 is located in the Syrian region with ability to attack Windows and Android platform. It was also mentioned out by Lookout in the Blackhat Europe 2018 while disclosing the Syrian Electronic Army’s mobile tool
  
**References**:  
https://i.blackhat.com/eu-18/Wed-Dec-5/eu-18-DelRosso-Under-the-SEA.pdf  
https://ti.qianxin.com/blog/articles/apt-c-27-(goldmouse):-suspected-target-attack-against-the-middle-east-with-winrar-exploit-en/
