|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[314e8105f28530eb0bf54891b9b3ff69](https://www.virustotal.com/gui/file/314e8105f28530eb0bf54891b9b3ff69)|ACE|CVE-2018-20250|2019-03-17 20:06:20| |
|[ec69819462f2c844255248bb90cae801](https://www.virustotal.com/gui/file/ec69819462f2c844255248bb90cae801)|Win32 EXE||2019-03-12 18:23:23|WriteString.exe|
|[36027a4abfb702107a103478f6af49be](https://www.virustotal.com/gui/file/36027a4abfb702107a103478f6af49be)|Win32 EXE|MSILPerseus|2019-03-12 18:15:54|New March.exe|
|[72df8c8bab5196ef4dce0dadd4c0887e](https://www.virustotal.com/gui/file/72df8c8bab5196ef4dce0dadd4c0887e)|Win32 EXE|MSILPerseus|2019-03-11 11:08:03|March.exe|
|[6e36f8ab2bbbba5b027ae3347029d1a3](https://www.virustotal.com/gui/file/6e36f8ab2bbbba5b027ae3347029d1a3)|Win32 EXE|Disfa|2019-03-05 21:06:17|March.exe|
|[1d3493a727c3bf3c93d8fd941ff8accd](https://www.virustotal.com/gui/file/1d3493a727c3bf3c93d8fd941ff8accd)|Win32 EXE|Kryptik|2019-03-05 21:05:16|March.exe|
|[2bdf97da0a1b3a40d12bf65f361e3baa](https://www.virustotal.com/gui/file/2bdf97da0a1b3a40d12bf65f361e3baa)|Win32 EXE||2019-03-05 21:04:52|March.exe|
|[9dafb0f428ef660d4923fe9f4f53bfc0](https://www.virustotal.com/gui/file/9dafb0f428ef660d4923fe9f4f53bfc0)|Win32 EXE|Disfa|2019-03-05 19:12:54|March.exe|
|[ed81446dd50034258e5ead2aa34b33ed](https://www.virustotal.com/gui/file/ed81446dd50034258e5ead2aa34b33ed)|Android||2019-03-05 08:50:34|chatsecureupdate2019.apk|
|[1cc32f2a351927777fc3b2ae5639f4d5](https://www.virustotal.com/gui/file/1cc32f2a351927777fc3b2ae5639f4d5)|Android||2019-03-01 20:05:42|/var/www/clean-mx/virusesevidence/output.123228152.txt|
|[83483a2ca251ac498aac2abe682063da](https://www.virustotal.com/gui/file/83483a2ca251ac498aac2abe682063da)|Win32 EXE|MSILPerseus|2019-02-04 08:47:54|December.exe|
|[f8460dddd3b56c4b17746111cba1cf4f](https://www.virustotal.com/gui/file/f8460dddd3b56c4b17746111cba1cf4f)|Android||2018-12-23 15:43:42|TelegramCrypt.apk|
|[5bc2de103000ca1495d4254b6608967f](https://www.virustotal.com/gui/file/5bc2de103000ca1495d4254b6608967f)|Android||2018-10-25 01:07:51|أبو أيوب - القريتين أبو محمد.apk|
|[bf6a9c0f3c53fb0cf851ed6f67a0c943](https://www.virustotal.com/gui/file/bf6a9c0f3c53fb0cf851ed6f67a0c943)|TXT||2018-10-18 21:40:48|CV.vbs|
|[58810256a122133b2852298f38605210](https://www.virustotal.com/gui/file/58810256a122133b2852298f38605210)|DOCX||2018-10-15 20:35:06|58810256a122133b2852298f38605210.virobj|
|[382788bb234b75a35b80ac69cb7ba306](https://www.virustotal.com/gui/file/382788bb234b75a35b80ac69cb7ba306)|Win32 EXE|Disfa|2018-07-25 13:20:35|382788bb234b75a35b80ac69cb7ba306.virus|
|[cf5e62ebbf4be2417b9d3849c3c3f9c9](https://www.virustotal.com/gui/file/cf5e62ebbf4be2417b9d3849c3c3f9c9)|Android||2018-07-18 09:59:14|whatsapp2018.apk|
|[f0d240bac174e38c831afdd80e50a992](https://www.virustotal.com/gui/file/f0d240bac174e38c831afdd80e50a992)|Android||2018-07-16 07:34:16|whatsapp2018.apk|
|[5de80e4b174f17776b07193a2280b252](https://www.virustotal.com/gui/file/5de80e4b174f17776b07193a2280b252)|Android||2018-07-16 07:34:04|telegram2018.apk|
|[f59cfb0b972fdf65baad7c37681d49ef](https://www.virustotal.com/gui/file/f59cfb0b972fdf65baad7c37681d49ef)|Android|androidos|2018-07-16 07:33:53|chatsecure2018.apk|
|[1dfbb58e3758e1d75beb424d4c1c426c](https://www.virustotal.com/gui/file/1dfbb58e3758e1d75beb424d4c1c426c)|Android|MSILPerseus|2018-07-02 17:43:42|30b6d0da04c0cc8c8b54ed9f248f7de340756bbb|
|[5fff1467d5e34acb487be731988dbbc4](https://www.virustotal.com/gui/file/5fff1467d5e34acb487be731988dbbc4)|Android||2018-06-25 21:15:45|d47a6adb7c7f02db6fef278ff32b3a1175b52c3f|
|[c741c654198a900653163ca7e9c5158c](https://www.virustotal.com/gui/file/c741c654198a900653163ca7e9c5158c)|Android||2018-05-27 04:54:17|7a90e7a4076be9f47211b0b52e03a91a728606fc|
|[6296586cf9a59b25d1b8ab3eeb0c2a33](https://www.virustotal.com/gui/file/6296586cf9a59b25d1b8ab3eeb0c2a33)|Android|androidos|2018-05-27 04:49:13|OfficeUpdate.apk|
|[bd251ce0f81089ceb6db6c5ead43cb8e](https://www.virustotal.com/gui/file/bd251ce0f81089ceb6db6c5ead43cb8e)|Win32 EXE||2018-04-03 17:31:21|WiNANd5ro16XP.exe|
|[e99b3a589fe9b8ee73ac57e6dfa712b7](https://www.virustotal.com/gui/file/e99b3a589fe9b8ee73ac57e6dfa712b7)|Android|androidos|2018-02-11 16:13:48|e99b3a589fe9b8ee73ac57e6dfa712b7.virus|
|[def07be7cd3584bd565b808f9d9103b5](https://www.virustotal.com/gui/file/def07be7cd3584bd565b808f9d9103b5)|Android|androidos|2018-02-11 15:46:25|def07be7cd3584bd565b808f9d9103b5.virus|
|[cb9759054dee65621ecf9c91018e4322](https://www.virustotal.com/gui/file/cb9759054dee65621ecf9c91018e4322)|Android||2018-02-10 16:01:48|cb9759054dee65621ecf9c91018e4322.virus|
|[405d28c207096120b92bf8338d2ed9f6](https://www.virustotal.com/gui/file/405d28c207096120b92bf8338d2ed9f6)|Android||2018-02-06 10:48:18|405d28c207096120b92bf8338d2ed9f6.virus|
|[e022aa83908625ca356782480881dd8d](https://www.virustotal.com/gui/file/e022aa83908625ca356782480881dd8d)|Android||2018-01-26 02:04:21|e022aa83908625ca356782480881dd8d.virus|
|[9f6a99a4bfddbf1efc72264252f691ef](https://www.virustotal.com/gui/file/9f6a99a4bfddbf1efc72264252f691ef)|Android||2018-01-26 02:04:13|9f6a99a4bfddbf1efc72264252f691ef.virus|
|[604035f7470a0de7b6169b218b30fe1e](https://www.virustotal.com/gui/file/604035f7470a0de7b6169b218b30fe1e)|Android||2018-01-25 00:08:47|604035f7470a0de7b6169b218b30fe1e.virus|
|[62d8a29ecae6bea296b2aeefa69814f7](https://www.virustotal.com/gui/file/62d8a29ecae6bea296b2aeefa69814f7)|Android|androidos|2018-01-21 18:08:26|62d8a29ecae6bea296b2aeefa69814f7.virus|
|[5232f720be177310c72ac004ed84f026](https://www.virustotal.com/gui/file/5232f720be177310c72ac004ed84f026)|Win32 EXE|msilperseus|2018-01-21 10:18:47|Svhost64.exe|
|[612cb35dbab698b11a63a8c93df1cf6b](https://www.virustotal.com/gui/file/612cb35dbab698b11a63a8c93df1cf6b)|Win32 EXE||2018-01-21 10:05:13|612cb35dbab698b11a63a8c93df1cf6b.virus|
|[090ba0eef20b8fdcefd619ddc634b440](https://www.virustotal.com/gui/file/090ba0eef20b8fdcefd619ddc634b440)|Android||2018-01-19 12:32:10|090ba0eef20b8fdcefd619ddc634b440.virus|
|[2fee5636f6ee5aff47385938477fcc98](https://www.virustotal.com/gui/file/2fee5636f6ee5aff47385938477fcc98)|Android|androidos|2018-01-15 09:09:39|2e1b39c86044e2e83515068198cd1c7cc598cd2c|
|[ea79617ba045e118ca26a0e39683700d](https://www.virustotal.com/gui/file/ea79617ba045e118ca26a0e39683700d)|Text||2017-12-08 05:40:15|ea79617ba045e118ca26a0e39683700d.virus|
|[21cae0f8b41d5094c88858135a2bafc6](https://www.virustotal.com/gui/file/21cae0f8b41d5094c88858135a2bafc6)|Android||2017-11-23 18:59:22|21cae0f8b41d5094c88858135a2bafc6.virus|
|[74f9549afd7ba8e25f0dfbd735ed2130](https://www.virustotal.com/gui/file/74f9549afd7ba8e25f0dfbd735ed2130)|Android|androidos|2017-11-20 17:33:04|74f9549afd7ba8e25f0dfbd735ed2130.virus|
|[a5a7ad37a06d0beac8da7ae1663db001](https://www.virustotal.com/gui/file/a5a7ad37a06d0beac8da7ae1663db001)|Android|androidos|2017-11-09 12:07:20|a5a7ad37a06d0beac8da7ae1663db001.virus|
|[99977cb5eafe40b9672c75010ae74398](https://www.virustotal.com/gui/file/99977cb5eafe40b9672c75010ae74398)|Win32 EXE|MSILPerseus|2017-10-26 08:17:16|Win64sysPack.exe|
|[cf507aa156fe856e74f22b80e83055fd](https://www.virustotal.com/gui/file/cf507aa156fe856e74f22b80e83055fd)|Android||2017-10-23 12:07:13|cf507aa156fe856e74f22b80e83055fd.virus|
|[3b8050b44700dec5cc7b2875549a3460](https://www.virustotal.com/gui/file/3b8050b44700dec5cc7b2875549a3460)|Android||2017-10-23 11:38:57|3b8050b44700dec5cc7b2875549a3460.virus|
|[ccf4a5d0f441c0e55fd871ebd229ccd7](https://www.virustotal.com/gui/file/ccf4a5d0f441c0e55fd871ebd229ccd7)|Android|androidos|2017-10-17 10:30:07|ccf4a5d0f441c0e55fd871ebd229ccd7.virus|
|[6fcadad1af1894f6678a4f46c2e168c2](https://www.virustotal.com/gui/file/6fcadad1af1894f6678a4f46c2e168c2)|Win32 EXE|Disfa|2017-10-05 17:03:51|6fcadad1af1894f6678a4f46c2e168c2.virus|
|[dc09543850d109fbb78f7c91badcda0d](https://www.virustotal.com/gui/file/dc09543850d109fbb78f7c91badcda0d)|Win32 EXE|MSILPerseus|2017-09-27 08:45:09|dc09543850d109fbb78f7c91badcda0d.virus|
|[bf1dd2bd62e34c467ac1bb3363c2a98b](https://www.virustotal.com/gui/file/bf1dd2bd62e34c467ac1bb3363c2a98b)|Text||2017-09-19 15:05:11|bf1dd2bd62e34c467ac1bb3363c2a98b.virus|
|[b7d1e20f814e9300a5b104f0a6f0c6f6](https://www.virustotal.com/gui/file/b7d1e20f814e9300a5b104f0a6f0c6f6)|Text||2017-09-19 15:04:50|b7d1e20f814e9300a5b104f0a6f0c6f6.virus|
|[d38bd978afca411e8e4fc10861485834](https://www.virustotal.com/gui/file/d38bd978afca411e8e4fc10861485834)|Win32 EXE|Disfa|2017-09-12 22:33:04|AowsCrypt2017.exe|
|[5fe4361fbe0f96f521b7ad08cf4fa5c2](https://www.virustotal.com/gui/file/5fe4361fbe0f96f521b7ad08cf4fa5c2)|Android|androidos|2017-07-26 13:36:10|MsOffice2017_en.apk|
|[442f82d42e0653b401aaa7e59d6a7561](https://www.virustotal.com/gui/file/442f82d42e0653b401aaa7e59d6a7561)|TXT||2017-07-20 21:38:14|%APPDATA%\microsoft\program.vbs|
|[571afc1fe6ec2deef5099435c3b112f7](https://www.virustotal.com/gui/file/571afc1fe6ec2deef5099435c3b112f7)|Win32 EXE|Disfa|2017-07-09 23:18:13|571afc1fe6ec2deef5099435c3b112f7.virus|
|[eb8cce73a5f983b94d5bf6a389ea09f0](https://www.virustotal.com/gui/file/eb8cce73a5f983b94d5bf6a389ea09f0)|unknown||2017-05-22 08:39:06|eb8cce73a5f983b94d5bf6a389ea09f0.virus|
|[1403bbaa9e0fcb5c9d9e8efeca95efa3](https://www.virustotal.com/gui/file/1403bbaa9e0fcb5c9d9e8efeca95efa3)|unknown|Nemucod|2017-05-21 16:01:45|1403bbaa9e0fcb5c9d9e8efeca95efa3.virus|
|[d774a45b9f865f2d3d045ead7d27d871](https://www.virustotal.com/gui/file/d774a45b9f865f2d3d045ead7d27d871)|Text||2017-05-12 12:15:15|d774a45b9f865f2d3d045ead7d27d871.virus|
|[d84a553f9f272c8e2e6db525fa4f9977](https://www.virustotal.com/gui/file/d84a553f9f272c8e2e6db525fa4f9977)|Win32 EXE|Disfa|2017-05-08 07:01:56|Server.exe|
|[871e4e5036c7909d6fd9f23285ff39b5](https://www.virustotal.com/gui/file/871e4e5036c7909d6fd9f23285ff39b5)|Win32 EXE|MSILPerseus|2017-05-04 01:07:06|1595747c1dd71c33a99b720821da420400daa033adcaa4c3d3b7fc34b527d60d.bin|
|[bdaaf37d1982a7221733c4cae17eccf8](https://www.virustotal.com/gui/file/bdaaf37d1982a7221733c4cae17eccf8)|Win32 EXE|keylogger|2017-05-03 07:10:32|76a75722021de6cbcabf6ea560ca2ac8ae817f0d659f9f363a74a9e1b14f0115.bin|
|[ad9c09bb6b22cb970706b5e3ffdf7621](https://www.virustotal.com/gui/file/ad9c09bb6b22cb970706b5e3ffdf7621)|Win32 EXE|cardinal|2017-04-21 17:05:00|ad9c09bb6b22cb970706b5e3ffdf7621.virus|
|[de83e22c323a3382fde98e4b7e6ddc3e](https://www.virustotal.com/gui/file/de83e22c323a3382fde98e4b7e6ddc3e)|Android||2017-04-06 10:26:53|System Package Update.apk|
|[e53e4db569e2886b960f8f5a7d9069ff](https://www.virustotal.com/gui/file/e53e4db569e2886b960f8f5a7d9069ff)|Android||2017-04-06 06:17:07|telegramupdate_2017.apk|
|[8ab2a456d8c0cdd5f541c53f925158f8](https://www.virustotal.com/gui/file/8ab2a456d8c0cdd5f541c53f925158f8)|Android||2017-02-11 01:30:43|8ab2a456d8c0cdd5f541c53f925158f8.virus|
|[59cc514938fa30b14f7d1d46f5fb493a](https://www.virustotal.com/gui/file/59cc514938fa30b14f7d1d46f5fb493a)|Android||2016-11-24 19:21:26| |
|[3f00799368f029c38cea4a1a56389ab7](https://www.virustotal.com/gui/file/3f00799368f029c38cea4a1a56389ab7)|unknown|Nemucod|2016-10-01 18:04:26|Malware (370).exe|
|[7bd1e63ac84e4cf511e54ac85b7af6fe](https://www.virustotal.com/gui/file/7bd1e63ac84e4cf511e54ac85b7af6fe)|Win32 EXE|Androm|2016-08-05 16:16:01|7bd1e63ac84e4cf511e54ac85b7af6fe.virus|
|[d94244732a762d9414587cce8d9836f8](https://www.virustotal.com/gui/file/d94244732a762d9414587cce8d9836f8)|Android||2016-06-06 12:55:21|/home/www/vhosts/files.uptodown.com/files/d94/d94244732a762d9414587cce8d9836f8|
|[b89e0d5a7329ee61fba7279dca14edf3](https://www.virustotal.com/gui/file/b89e0d5a7329ee61fba7279dca14edf3)|Win32 EXE||2016-02-18 20:27:35|chrome up.exe|
|[819cac2e71e2ed346a9b5e48077e786c](https://www.virustotal.com/gui/file/819cac2e71e2ed346a9b5e48077e786c)|Android||2015-12-22 01:40:08|filename|
|[7eacdf48061a5aa075e81e69e151a767](https://www.virustotal.com/gui/file/7eacdf48061a5aa075e81e69e151a767)|Android||2015-12-05 23:57:42|filename|
|[e448e46dd39b9398467e382128e538e4](https://www.virustotal.com/gui/file/e448e46dd39b9398467e382128e538e4)|Android||2015-11-27 17:01:42|e448e46dd39b9398467e382128e538e4.virus|
|[45c45e1afdd6232b08041576da590f12](https://www.virustotal.com/gui/file/45c45e1afdd6232b08041576da590f12)|Android||2015-11-23 04:18:47|app-debug.apk|
|[9dbda4346efae4daceac1e3ce6c23994](https://www.virustotal.com/gui/file/9dbda4346efae4daceac1e3ce6c23994)|Android||2015-11-23 03:23:58|app-release.apk|
|[e4197ea4e6fa6c1b7b053805cfa48b69](https://www.virustotal.com/gui/file/e4197ea4e6fa6c1b7b053805cfa48b69)|Android||2015-11-23 03:15:31|app-release.apk|
|[b010230cd1846226aae1b3b9b4a16ac7](https://www.virustotal.com/gui/file/b010230cd1846226aae1b3b9b4a16ac7)|Android||2015-11-23 03:11:41|app-release.apk|
|[75e8aeb6314ced58a0c40e0b88a969a6](https://www.virustotal.com/gui/file/75e8aeb6314ced58a0c40e0b88a969a6)|Win32 EXE|Disfa|2015-10-25 09:50:06| |
|[11b61b531a7bbc7668d7d346e4a17d5e](https://www.virustotal.com/gui/file/11b61b531a7bbc7668d7d346e4a17d5e)|Win32 EXE|kryptik|2015-10-19 16:33:25|NJ.exe|
|[d9b1e46a08cc5a5d4844193fffec4489](https://www.virustotal.com/gui/file/d9b1e46a08cc5a5d4844193fffec4489)|Win32 EXE|dynamer|2015-10-11 03:07:29|xor.exe|
|[558a6afb2353bd25da76d17b0f80193b](https://www.virustotal.com/gui/file/558a6afb2353bd25da76d17b0f80193b)|Win32 EXE|Kryptik|2015-10-03 15:33:16|non.exe|
|[f519e5b04bd9cbf76875c0d8dbbbc8b4](https://www.virustotal.com/gui/file/f519e5b04bd9cbf76875c0d8dbbbc8b4)|Win32 EXE|Disfa|2015-08-22 00:03:37|Server.exe|
|[b134dc4c1f69dd734417ac5125995bdb](https://www.virustotal.com/gui/file/b134dc4c1f69dd734417ac5125995bdb)|Win32 EXE|kazy|2015-08-14 23:52:20|medo.exe|
|[32ea9d96b6278f8040bf0bb4bbfa4418](https://www.virustotal.com/gui/file/32ea9d96b6278f8040bf0bb4bbfa4418)|Win32 EXE||2015-08-05 15:56:37|PePastebin.exe|
|[f739170918c50bea803b313d5cb0f470](https://www.virustotal.com/gui/file/f739170918c50bea803b313d5cb0f470)|Win32 EXE|Disfa|2015-07-29 16:31:13|C:\nH_wxA\NlA2.reg|
|[8848631aeaf33a166c9e623d430cb1bf](https://www.virustotal.com/gui/file/8848631aeaf33a166c9e623d430cb1bf)|Win32 EXE|Disfa|2015-07-09 17:08:26| |
|[55971412602747a98c3477b289ef2c9a](https://www.virustotal.com/gui/file/55971412602747a98c3477b289ef2c9a)|Win32 EXE|kazy|2015-05-23 02:48:09|IDMan.exe|
|[cf8ffe7f560b4d19aaaf93439101ef16](https://www.virustotal.com/gui/file/cf8ffe7f560b4d19aaaf93439101ef16)|Win32 EXE|razy|2015-04-22 14:38:07|Sanad_Awwad.exe|
|[b5d9b03020fff512934e2001805f9c0b](https://www.virustotal.com/gui/file/b5d9b03020fff512934e2001805f9c0b)|Win32 EXE|zapchast|2015-04-17 13:38:23|THE PRO SERVER S.exe|
|[a4e6c15984a86f2a102ad67fa870a844](https://www.virustotal.com/gui/file/a4e6c15984a86f2a102ad67fa870a844)|Win32 EXE||2015-04-14 02:05:40|SERVER PRO WEB.exe|
|[1b09ce9b782e56131103aad73016e329](https://www.virustotal.com/gui/file/1b09ce9b782e56131103aad73016e329)|Win32 EXE|Disfa|2015-02-15 14:27:20|a0j3bj2q.exe|
|[af73ca52a77402a178ee3594020e88c1](https://www.virustotal.com/gui/file/af73ca52a77402a178ee3594020e88c1)|Win32 EXE|Zbot|2015-02-10 20:14:16|af73ca52a77402a178ee3594020e88c1.virus|
|[b29f50770355a8a165dff87f4aede6f0](https://www.virustotal.com/gui/file/b29f50770355a8a165dff87f4aede6f0)|Win32 EXE|Zbot|2015-02-10 19:04:34|b29f50770355a8a165dff87f4aede6f0.virus|
|[6b2136a9ae899588769e9c0513be410e](https://www.virustotal.com/gui/file/6b2136a9ae899588769e9c0513be410e)|Win32 EXE|Kryptik|2015-01-25 23:03:00|isheriff_6b2136a9ae899588769e9c0513be410e.bin|
|[9231882b47475e327adc23f3b1f716f0](https://www.virustotal.com/gui/file/9231882b47475e327adc23f3b1f716f0)|Win32 EXE|Kryptik|2015-01-25 22:39:57|avast.exe|
|[17cc1c907ac19139a98fab34d78f7323](https://www.virustotal.com/gui/file/17cc1c907ac19139a98fab34d78f7323)|Win32 EXE|Kryptik|2015-01-25 14:43:15|avast.exe|
|[73dc99693709a12881681659292103e7](https://www.virustotal.com/gui/file/73dc99693709a12881681659292103e7)|Win32 EXE|Kryptik|2015-01-16 19:16:26|net.exe|
|[cc0db787872eac747c75d7bea6e75bf1](https://www.virustotal.com/gui/file/cc0db787872eac747c75d7bea6e75bf1)|Win32 EXE|Disfa|2014-12-01 23:33:55|myfile.exe|
|[d06f0950f2f3a0b069fa9cedfcbc7d43](https://www.virustotal.com/gui/file/d06f0950f2f3a0b069fa9cedfcbc7d43)|Win32 EXE|kazy|2014-11-07 04:56:43|CCleaner.exe|
|[c9adaec7775c19c06b91b3d45ff4687e](https://www.virustotal.com/gui/file/c9adaec7775c19c06b91b3d45ff4687e)|Win32 EXE|Disfa|2014-10-12 08:16:47|Clean medo sea.exe|
