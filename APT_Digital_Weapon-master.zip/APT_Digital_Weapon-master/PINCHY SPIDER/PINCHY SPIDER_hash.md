|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[78efe80384fa759964c9ea8bada3ac8d](https://www.virustotal.com/gui/file/78efe80384fa759964c9ea8bada3ac8d)|Win32 EXE|Gandcrab|2019-02-19 08:07:38|myfile.exe|
|[78d93945883911ff5e64057cf3c70e2e](https://www.virustotal.com/gui/file/78d93945883911ff5e64057cf3c70e2e)|Win32 EXE|Gandcrab|2019-02-19 08:04:07| |
|[2b1bcfc32cbee85ce86612955f1aa10e](https://www.virustotal.com/gui/file/2b1bcfc32cbee85ce86612955f1aa10e)|Win32 EXE|Gandcrab|2019-02-19 07:50:40| |
|[bdb769f7302b2035d81e34c5ed81ac55](https://www.virustotal.com/gui/file/bdb769f7302b2035d81e34c5ed81ac55)|Win32 EXE|Gandcrab|2019-02-19 07:46:06| |
|[754bb8fb4818d2cd0abf553376004b89](https://www.virustotal.com/gui/file/754bb8fb4818d2cd0abf553376004b89)|Win32 EXE|Gandcrab|2019-02-19 07:37:42|myfile.exe|
|[ba2960ce267dc0f11e2683679ce038f7](https://www.virustotal.com/gui/file/ba2960ce267dc0f11e2683679ce038f7)|Win32 EXE|Gandcrab|2019-02-18 17:16:37| |
|[25138cab15e7fe20852ab77135720ff5](https://www.virustotal.com/gui/file/25138cab15e7fe20852ab77135720ff5)|Win32 EXE|Kryptik|2019-02-07 18:08:37| |
|[60236fe463e180272b98cf8f93208a80](https://www.virustotal.com/gui/file/60236fe463e180272b98cf8f93208a80)|Win32 EXE|Gandcrab|2018-05-30 10:34:07|myfile.exe|
