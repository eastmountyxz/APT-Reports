**NAME:**  
PINCHY SPIDER   
**Description**:   
PINCHY SPIDER is the creator of GandCrab that targets the ransomware at enterprise environments. PINCHY SPIDER and its affiliates were found using techniques mainly associated with penetration testing teams as well as other adversary groups. It is also believed to be offering their share of profits to other entities spreading GandCrab.  
  
**References**:  
https://cyware.com/news/gandcrab-creator-pinchy-spider-and-its-affiliates-update-tactics-to-spread-the-ransomware-0f777fb1?from=singlemessage&isappinstalled=0&tdsourcetag=s_pcqq_aiomsg