|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[6ebe1824559814f2ccd6d8719aae6a1b](https://www.virustotal.com/gui/file/6ebe1824559814f2ccd6d8719aae6a1b)|Win32 DLL||2019-10-21 22:11:22| |
|[33e19a73a6a7387438a38f35da88a304](https://www.virustotal.com/gui/file/33e19a73a6a7387438a38f35da88a304)|Win32 DLL||2019-09-19 12:37:39|C:\Users\<USER>\AppData\Local\Temp\log.dll|
|[a9270294941453da3147638e35f08c83](https://www.virustotal.com/gui/file/a9270294941453da3147638e35f08c83)|RTF|CVE-2018-0802|2019-09-19 10:02:58|=?UTF-8?B?UXV5IHRyw6xuaCBDw6FjIG7GsOG7m2MuZG9j?=|
|[fa2a3369e6d17b44ce066035c0ef8c56](https://www.virustotal.com/gui/file/fa2a3369e6d17b44ce066035c0ef8c56)|Win32 EXE|zapchast|2019-09-11 17:43:11|.|
|[5e8b469d36e8d4b9c00c67bbba1af382](https://www.virustotal.com/gui/file/5e8b469d36e8d4b9c00c67bbba1af382)|RTF|CVE-2018-0802|2019-09-11 08:48:41|=?UTF-8?B?4Z6U4Z+S4Z6a4Z6S4Z624Z6T4Z6T4Z624Z6Z4Z6A4Z6K4Z+S4Z6L4Z624Z6TX+GeouGeguGfkuGeguGek+GetuGemeGegC5kb2M=?=|
|[8d0248a7c21ed7cb2edbc3da7ce5e3c8](https://www.virustotal.com/gui/file/8d0248a7c21ed7cb2edbc3da7ce5e3c8)|Win32 EXE||2019-05-31 09:02:51|untitled_paste|
|[c8749341801692c047cc184490a05671](https://www.virustotal.com/gui/file/c8749341801692c047cc184490a05671)|Win32 DLL|Farfli|2019-05-30 09:02:38| |
|[9ad1dba92734a53489180788a6b21856](https://www.virustotal.com/gui/file/9ad1dba92734a53489180788a6b21856)|Win32 DLL|Farfli|2019-05-26 19:18:58|.|
|[fc47442f175ff7e312a4aa4f5c8745b8](https://www.virustotal.com/gui/file/fc47442f175ff7e312a4aa4f5c8745b8)|RTF|CVE-2018-0802|2019-05-25 17:26:26| |
|[84553811a788dc617af0069d59f50946](https://www.virustotal.com/gui/file/84553811a788dc617af0069d59f50946)|Win32 DLL|Symmi|2019-05-13 13:04:27|3c14241e51a9594b44d1f9c661ccfaeb2c6f707f956d218fc052fa68aab0e3f6.sample|
|[148fc4784ff8bb0c98a7f94f34288f63](https://www.virustotal.com/gui/file/148fc4784ff8bb0c98a7f94f34288f63)|Win32 EXE|Farfli|2019-05-13 03:32:42|CIPHER|
|[8fbd5af45ed0f8ceb8c0d009afb5caf3](https://www.virustotal.com/gui/file/8fbd5af45ed0f8ceb8c0d009afb5caf3)|Win32 DLL|Farfli|2019-05-09 05:52:57|wsc.dll|
|[93f5aed88279e8f9d0c4e5051300f6d9](https://www.virustotal.com/gui/file/93f5aed88279e8f9d0c4e5051300f6d9)|Win32 EXE|Farfli|2019-05-09 05:47:29|CIPHER|
|[f0424ed16b435f0c7c802f3a17cbd9de](https://www.virustotal.com/gui/file/f0424ed16b435f0c7c802f3a17cbd9de)|RTF|CVE-2018-0802|2019-05-09 03:26:16|document.rtf|
|[2b7c320fac913060cf6295c075d61ad6](https://www.virustotal.com/gui/file/2b7c320fac913060cf6295c075d61ad6)|Win32 DLL|Farfli|2019-05-07 19:01:55|wsc.dll|
|[f34514118eb4689560cd6c0c654f26d9](https://www.virustotal.com/gui/file/f34514118eb4689560cd6c0c654f26d9)|RTF|CVE-2018-0802|2019-05-07 09:48:34|/var/www/clean-mx/virusesevidence/output.126542015.txt|
|[b3f8abe274cb6a5926bd5c3fc2168997](https://www.virustotal.com/gui/file/b3f8abe274cb6a5926bd5c3fc2168997)|RTF|CVE-2018-0802|2019-04-19 02:46:50|Giay moi hoi nghi.doc|
|[f4bf2740cc4085644e93ee88f81b3612](https://www.virustotal.com/gui/file/f4bf2740cc4085644e93ee88f81b3612)|XLS||2019-01-30 02:22:02|file_F7125EFB572709FD7D4ECEB8A7C5DE5C890F49AA|
|[60414d601afa0de045ede045eb30f4f2](https://www.virustotal.com/gui/file/60414d601afa0de045ede045eb30f4f2)|DOC||2019-01-30 02:20:44|file_E188CD6D0BFCBB3275A262BC37EAA9F075A0B3D7|
|[f4e23cf5d4eb9068e7e3ba617cae9088](https://www.virustotal.com/gui/file/f4e23cf5d4eb9068e7e3ba617cae9088)|DOCM||2019-01-08 03:26:11|CV gui PVN vv y kien cua UB ve gia han.doc|
|[94428718c5990a3da18574510526e59b](https://www.virustotal.com/gui/file/94428718c5990a3da18574510526e59b)|FPX||2018-12-26 03:16:53|abc|
|[144677eae4c22ffefcb85f623e9edfab](https://www.virustotal.com/gui/file/144677eae4c22ffefcb85f623e9edfab)|Win32 DLL||2018-12-25 19:03:34|Update.txt|
|[ecaa8635259218acfea1074b227065b2](https://www.virustotal.com/gui/file/ecaa8635259218acfea1074b227065b2)|DOC|sagent|2018-12-25 07:19:11|Cv chi dao.doc|
|[25d28218fd55f2540cd842b27831ac87](https://www.virustotal.com/gui/file/25d28218fd55f2540cd842b27831ac87)|Win32 DLL||2018-07-27 01:30:43|%WINDIR%\pla.dat|
|[d5679158937ce288837efe62bc1d9693](https://www.virustotal.com/gui/file/d5679158937ce288837efe62bc1d9693)|Win32 DLL||2018-07-20 11:39:33|PERFORMANCE LIB|
|[839be5a8da8c0a616fc441d50e2b5b51](https://www.virustotal.com/gui/file/839be5a8da8c0a616fc441d50e2b5b51)|FPX||2018-05-23 08:29:45|Music|
|[3f8ec71a975df6504738a12dd7fffd04](https://www.virustotal.com/gui/file/3f8ec71a975df6504738a12dd7fffd04)|Text|Banload|2018-04-20 13:38:34|Contributions to CNRP from USA.hta|
|[59811fb02e13f2cf7e41604444a9433b](https://www.virustotal.com/gui/file/59811fb02e13f2cf7e41604444a9433b)|Win32 DLL|Ursu|2018-04-18 05:58:27|URL|
|[3b329ae1c7a28d20e40b442e2a8ed319](https://www.virustotal.com/gui/file/3b329ae1c7a28d20e40b442e2a8ed319)|Win32 DLL||2018-04-17 10:51:00|URL|
|[f0264647be89d844e4db70f30bd60221](https://www.virustotal.com/gui/file/f0264647be89d844e4db70f30bd60221)|Win32 DLL||2018-03-17 13:27:26|f0264647be89d844e4db70f30bd60221.virus|
|[d14b9a4498202a711450414ff5bb64e4](https://www.virustotal.com/gui/file/d14b9a4498202a711450414ff5bb64e4)|Win32 DLL|Farfli|2018-03-15 19:28:28|ControlDll|
|[6f0a313d6a17729c7438d009d6286ed1](https://www.virustotal.com/gui/file/6f0a313d6a17729c7438d009d6286ed1)|Win32 DLL|Farfli|2018-03-15 19:24:58|ControlDll|
|[6290681895659b9063c58ef77e412799](https://www.virustotal.com/gui/file/6290681895659b9063c58ef77e412799)|Win32 DLL||2018-03-12 06:38:33|ControlDll|
|[44a4feddabb6614bad4c5243c6627c2e](https://www.virustotal.com/gui/file/44a4feddabb6614bad4c5243c6627c2e)|Win32 DLL|Farfli|2018-03-12 06:14:28|ControlDll|
|[2b47bfff7fd89e8c5b2deea65530ffa9](https://www.virustotal.com/gui/file/2b47bfff7fd89e8c5b2deea65530ffa9)|Win32 DLL||2018-03-11 23:29:34|ac8dcd3a660c9290c557596ea819547c4635d8e1|
|[046fad6789267d1d933a8b7a501a53f5](https://www.virustotal.com/gui/file/046fad6789267d1d933a8b7a501a53f5)|Win32 DLL|Farfli|2018-01-30 04:57:25|ControlDll|
|[031a1eacf31e09a6c9145498864a2e4c](https://www.virustotal.com/gui/file/031a1eacf31e09a6c9145498864a2e4c)|Win32 DLL||2018-01-25 10:52:23|Async Trace DLL|
|[4df5cc8d84f152807cacac9b263d616c](https://www.virustotal.com/gui/file/4df5cc8d84f152807cacac9b263d616c)|Win32 DLL|Farfli|2018-01-20 08:26:09|ControlDll|
|[fbf052d7ae5b9f6639a326233b1cd4da](https://www.virustotal.com/gui/file/fbf052d7ae5b9f6639a326233b1cd4da)|Win32 DLL|Ursu|2018-01-12 09:11:29|RunningDll|
|[7dc0579e704148d4a0767b956ef22a22](https://www.virustotal.com/gui/file/7dc0579e704148d4a0767b956ef22a22)|Win32 DLL|Farfli|2018-01-12 04:39:22|177906cb9170adc26082e44d9ad1b3fbdcba7c0b57e28b614c1b66cc4a99f906.bin|
|[275bd09ea7a6857712fa665dcee05483](https://www.virustotal.com/gui/file/275bd09ea7a6857712fa665dcee05483)|Win32 DLL||2018-01-11 17:17:51|RunningDll|
|[6954600f1efdf2e573151a75f42dcba3](https://www.virustotal.com/gui/file/6954600f1efdf2e573151a75f42dcba3)|Win32 DLL|Ursu|2018-01-10 22:13:49|b8528c8e325db76b139d46e9f29835382a1b48d8941c47060076f367539c2559.bin|
|[d00ab8344b78e5b76f5d9db2e777c953](https://www.virustotal.com/gui/file/d00ab8344b78e5b76f5d9db2e777c953)|Win32 DLL|Ursu|2018-01-10 08:40:09|df14de6b43f902ac8c35ecf0582ddb33e12e682700eb55dc4706b73f5aed40f6.bin|
|[19ed40d94e18f72981deba02956d5509](https://www.virustotal.com/gui/file/19ed40d94e18f72981deba02956d5509)|Win32 DLL||2017-10-21 02:22:39|Async Trace DLL|
|[77d13e9f04dec82e670a5afda0f2f14a](https://www.virustotal.com/gui/file/77d13e9f04dec82e670a5afda0f2f14a)|Win32 DLL||2017-04-05 12:48:44|77d13e9f04dec82e670a5afda0f2f14a.virus|
|[5ca90fcaf73159d2355d1bbfdaf37237](https://www.virustotal.com/gui/file/5ca90fcaf73159d2355d1bbfdaf37237)|Win32 DLL|Farfli|2017-03-23 07:38:13|RunningDll|
|[293b297852eed02726be916bc43c81f4](https://www.virustotal.com/gui/file/293b297852eed02726be916bc43c81f4)|Win32 DLL|Farfli|2017-03-11 20:55:45|RunningDll|
