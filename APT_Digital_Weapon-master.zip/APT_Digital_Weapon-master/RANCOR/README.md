**NAME:**  
RANCOR  
  
**Alias**  
Rancor group, RANCOR  
  
**Description**:   
Rancor, disclosed by PaloAlto, is a threat group that performed highly targeted attacks against the South East Asia region. It uses politically-motivated lures to entice victims to open malicious documents. Singapore and Cambodia are included, but not limited to its targeted countries.
The Rancor group’s attacks use two primary malware families named as DDKONG and PLAINTEE. DDKONG is used throughout the campaign and PLAINTEE appears to be new addition to these attackers’ toolkit.

  
**References**:  
https://researchcenter.paloaltonetworks.com/2018/06/unit42-rancor-targeted-attacks-south-east-asia-using-plaintee-ddkong-malware-families/
