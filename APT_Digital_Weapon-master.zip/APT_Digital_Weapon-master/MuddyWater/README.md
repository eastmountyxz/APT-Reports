**NAME:**  
MuddyWater  
  
**Alias**  
TEMP.Zagros, Seedworm, MuddyWater  

**Description**:   
MuddyWater, named by PaloAlto, carried out targeted attacks against the Middle East in 2017. Some other related attacks were observed against surrounding nations and beyond, including targets in India and the USA. MuddyWater attacks are characterized by the use of a slowly evolving PowerShell-based first stage backdoor called “POWERSTATS”.

**References**:  
https://researchcenter.paloaltonetworks.com/2017/11/unit42-muddying-the-water-targeted-attacks-in-the-middle-east/

