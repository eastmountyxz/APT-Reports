|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[3bdc5b98c56ed33e61ecb1f84f25cb05](https://www.virustotal.com/gui/file/3bdc5b98c56ed33e61ecb1f84f25cb05)|FPX||2019-11-26 13:24:26|vbaProject.bin|
|[7ed6c5e8c3ec4f9499eb793d69a06758](https://www.virustotal.com/gui/file/7ed6c5e8c3ec4f9499eb793d69a06758)|XLS||2019-10-28 11:50:06|905e3f74e5dcca58cf6bb3afaec888a3d6cb7529b6e4974e417b2c8392929148.bin|
|[b9ee416f2d9557be692abf448bf2f937](https://www.virustotal.com/gui/file/b9ee416f2d9557be692abf448bf2f937)|XLS||2019-10-17 05:29:38|7f31ab924bddc2f20697157f7cfa6ff25adfbbb50403052cccd05dc0e9faabc4.bin|
|[a9706c01de9364eab210ea73296bfe71](https://www.virustotal.com/gui/file/a9706c01de9364eab210ea73296bfe71)|XLS||2019-10-14 10:47:18|32c5d06a518a17daf825374449a5096e1109a1eb99c010bb2524b9b0ed6e3114.bin|
|[584479a1958a73720c4aebb52c59b21e](https://www.virustotal.com/gui/file/584479a1958a73720c4aebb52c59b21e)|XLS||2019-09-30 06:04:24|4a2db2c017b44834bfab8bd7ba107750d77cd1e62db0b4892ab3c053b2d64fae.bin|
|[269afae11cc9837e732019a03fa02fab](https://www.virustotal.com/gui/file/269afae11cc9837e732019a03fa02fab)|XLS||2019-09-30 06:03:46|1d768c6a5165cadf39ac68e4cc294399f09b48dfefd7bfd6d78e75ad882cd3f1.bin|
|[e18228bee6f1cf12eaf1bb4d5be587bf](https://www.virustotal.com/gui/file/e18228bee6f1cf12eaf1bb4d5be587bf)|XLS||2019-09-27 04:04:10|NeedDedicatedServer.xls|
|[5ef459908d5be0672b02cdfe4f606989](https://www.virustotal.com/gui/file/5ef459908d5be0672b02cdfe4f606989)|XLS||2019-09-27 01:04:15|20ec56029ec2dc6a0f86d172f12914d078fc679a8d01257394864413d01d7eda.bin|
|[32156247f900883d5106795ec103a624](https://www.virustotal.com/gui/file/32156247f900883d5106795ec103a624)|XLS||2019-09-27 01:02:10|eb1c21fcba6d04376a8cfd19fbd19203db68e13161049b70586ff509dc6e2175.bin|
|[66c783e41480e65e287081ff853cc737](https://www.virustotal.com/gui/file/66c783e41480e65e287081ff853cc737)|XLS||2019-09-27 01:01:26|ba0a74f2227e32f4cee2e7358979547cf15fd19ea6c72144773f087621bdb4b4.bin|
|[beb6a4354549ae4f5579f25865ea8967](https://www.virustotal.com/gui/file/beb6a4354549ae4f5579f25865ea8967)|Text||2019-09-17 11:44:56|rat.ps1|
|[2c3a634953a9a2c227a51e8eeac9f137](https://www.virustotal.com/gui/file/2c3a634953a9a2c227a51e8eeac9f137)|XLS||2019-09-10 08:10:13| |
|[9d0bfb81f450de8364327a4aaa67d9b3](https://www.virustotal.com/gui/file/9d0bfb81f450de8364327a4aaa67d9b3)|XLS||2019-09-08 23:14:37|2f69f7df7a2ab7b1803bb50b23ac17f7047b4651513bdff98dae5adee492c98f.bin|
|[8c4388c04b429b89c4add3825cf2e3c9](https://www.virustotal.com/gui/file/8c4388c04b429b89c4add3825cf2e3c9)|DOC||2019-09-05 23:44:20|Application Form_RUS_2019.doc|
|[1cd71f39ff9fb3bf269440b63c717195](https://www.virustotal.com/gui/file/1cd71f39ff9fb3bf269440b63c717195)|ZIP||2019-08-21 08:16:12|0db3e3fbc4fced262cb2602f4a6d94b5443c6ad1e2e59b6137ad3c1cc0520b75.bin|
|[4022bbb9df5d86226bd9a89f361c94b9](https://www.virustotal.com/gui/file/4022bbb9df5d86226bd9a89f361c94b9)|XLS||2019-08-18 13:34:51|f9cde44e0b4e43775b28ce8689f747038f83ea0389d510b1da41e63392f3a269.bin|
|[1633f9a283ee5a888ca623b87837b5b6](https://www.virustotal.com/gui/file/1633f9a283ee5a888ca623b87837b5b6)|DOC||2019-07-31 16:06:23|CV-Meryem-EN.doc|
|[50ac74eb38d6fa07d9f5e788d61a92cd](https://www.virustotal.com/gui/file/50ac74eb38d6fa07d9f5e788d61a92cd)|XLS||2019-07-09 17:14:36|64001be2fc9ccec320d48c75d2de8ad7cd74092065cb44fe35b38624d4493df0.bin|
|[5b5b3cb0948ee56ea761ed31d53c29ad](https://www.virustotal.com/gui/file/5b5b3cb0948ee56ea761ed31d53c29ad)|Text||2019-07-04 22:08:06|VirusShare_5b5b3cb0948ee56ea761ed31d53c29ad|
|[ef6df2575a557aaafe1422c482e74f1d](https://www.virustotal.com/gui/file/ef6df2575a557aaafe1422c482e74f1d)|DOCM||2019-07-02 18:55:09|TEST.doc|
|[c22f264efc9186dad8b5dfedc844a8bd](https://www.virustotal.com/gui/file/c22f264efc9186dad8b5dfedc844a8bd)|DOC||2019-07-02 18:54:10|Football2.doc|
|[2afb43542e4b0bd2e6105a1b769ff9d4](https://www.virustotal.com/gui/file/2afb43542e4b0bd2e6105a1b769ff9d4)|Text|foretype|2019-06-28 02:39:21|HTM.log|
|[daa7d4c40ffaa6cf4e4708747d3a9b37](https://www.virustotal.com/gui/file/daa7d4c40ffaa6cf4e4708747d3a9b37)|Win32 EXE||2019-06-24 10:44:21|1b63496313674770ea180cef8f96b0e3090af1b55023c51e64c71000f1b37560.exe|
|[f460780c1cad15c3883868cb5050375c](https://www.virustotal.com/gui/file/f460780c1cad15c3883868cb5050375c)|Text||2019-06-21 00:14:44|USERCa.jpeg|
|[176e56a418bc4c11783d6411aef94c38](https://www.virustotal.com/gui/file/176e56a418bc4c11783d6411aef94c38)|unknown||2019-06-21 00:12:57|antibiotic.vbe|
|[c40f77ca36bab83db36b463d2a561fbc](https://www.virustotal.com/gui/file/c40f77ca36bab83db36b463d2a561fbc)|Text||2019-06-19 16:51:06|plr.dat|
|[6e324aa68f21e5c794f17ed70102e214](https://www.virustotal.com/gui/file/6e324aa68f21e5c794f17ed70102e214)|unknown||2019-06-19 16:39:34|S0NN3.VbE|
|[8f416a523e272a751061f86e77b8cdad](https://www.virustotal.com/gui/file/8f416a523e272a751061f86e77b8cdad)|DOC||2019-06-18 10:30:09|Performance_Eval_Employee.doc|
|[b100c0cfbe59fa66cbb75de65c505ce2](https://www.virustotal.com/gui/file/b100c0cfbe59fa66cbb75de65c505ce2)|XLS||2019-06-17 18:04:37|b34893e23666ab3d1d1476a78eb8e921be41273f5a3b653f1d425801278be39b.bin|
|[9aaa2011a46c19d143e0d67bd66e13ce](https://www.virustotal.com/gui/file/9aaa2011a46c19d143e0d67bd66e13ce)|Text||2019-06-17 04:16:30|.jpeg|
|[d7b0eb2f80f415b3171651903ae74a03](https://www.virustotal.com/gui/file/d7b0eb2f80f415b3171651903ae74a03)|unknown||2019-06-12 06:58:55|pKio.vbE|
|[8eb40b005f78e4367e879bbdc6110732](https://www.virustotal.com/gui/file/8eb40b005f78e4367e879bbdc6110732)|DOC||2019-06-12 02:59:10|Gulnoza Nurullaeva.doc|
|[3eb23bc84083e252549e47dbd65b1f8f](https://www.virustotal.com/gui/file/3eb23bc84083e252549e47dbd65b1f8f)|DOC||2019-06-12 01:59:03|IMF Registration Form.doc|
|[1e8afda2721eff834ed9c87371a432fe](https://www.virustotal.com/gui/file/1e8afda2721eff834ed9c87371a432fe)|DOC|o97m|2019-05-30 04:07:35|7e7b6923f3e2ee919d1ea1c8f8d9a915c52392bd6f9ab515e4eb95fa42355991.bin|
|[34a072f42905f9de31523616e8f207b1](https://www.virustotal.com/gui/file/34a072f42905f9de31523616e8f207b1)|Text||2019-05-29 18:48:52|UserImage.png|
|[9d2da5228e21594ab46b4f5281d38b8f](https://www.virustotal.com/gui/file/9d2da5228e21594ab46b4f5281d38b8f)|unknown||2019-05-29 18:48:44|aulngr.vbe|
|[3cc5e7df7e9b0b216327ae7b451b8b90](https://www.virustotal.com/gui/file/3cc5e7df7e9b0b216327ae7b451b8b90)|DOCX|o97m|2019-05-28 16:24:01|TAJIKISTAN_INCORPORATE_E-GOVERMENT.docx|
|[8b3da6c97a53188e4af2d404dea654b6](https://www.virustotal.com/gui/file/8b3da6c97a53188e4af2d404dea654b6)|DOC|o97m|2019-05-28 06:42:59|Agency_Last_Section_Document.doc|
|[6cb076f1f42573c5c43083a89bcfe442](https://www.virustotal.com/gui/file/6cb076f1f42573c5c43083a89bcfe442)|DOC|o97m|2019-05-27 00:11:18|Zakupki_Agency on Public Procurement.doc|
|[72f92f81721fe832316f7b27ad328e17](https://www.virustotal.com/gui/file/72f92f81721fe832316f7b27ad328e17)|DOC|o97m|2019-05-26 14:13:46|4d72dcd33379fe7a34f9618e692f659fa9d318ab623168cd351c18ca3a805af1.bin|
|[1d669001a54a97c3f84b94396684f487](https://www.virustotal.com/gui/file/1d669001a54a97c3f84b94396684f487)|DOCX||2019-05-08 13:14:22|I_C_P.docx|
|[b0de46b50e209b185987010238fc65f0](https://www.virustotal.com/gui/file/b0de46b50e209b185987010238fc65f0)|DOC|o97m|2019-05-07 18:22:53|95c650a540ed5385bd1caff45ba06ff90dc0773d744efc4c2e4b29dda102fcce.bin|
|[692815cce754b02fe5085375cab1f7b2](https://www.virustotal.com/gui/file/692815cce754b02fe5085375cab1f7b2)|DOCX|o97m|2019-05-07 09:45:54|MinutesofMeeting-2May19.docx|
|[036f4400babdaa314ab5aa4a2c378e2f](https://www.virustotal.com/gui/file/036f4400babdaa314ab5aa4a2c378e2f)|DOC|o97m|2019-05-03 15:17:06|company information list.doc|
|[ebba800079b83fab2b2caa359e7abee3](https://www.virustotal.com/gui/file/ebba800079b83fab2b2caa359e7abee3)|Win32 EXE|Delf|2019-04-29 20:55:30|e2f82b074074955eeca3b0dd7b2831192bee49de329d5d4b36742c9721c8ad94.bin|
|[b1d6992df7a0aba6917ed4af52cbfca8](https://www.virustotal.com/gui/file/b1d6992df7a0aba6917ed4af52cbfca8)|FPX||2019-04-26 15:10:55|b1d6992df7a0aba6917ed4af52cbfca8.bin|
|[97bf0d6e11ee4118993ad9c4b959c916](https://www.virustotal.com/gui/file/97bf0d6e11ee4118993ad9c4b959c916)|DOC|o97m|2019-04-24 09:23:27|company information list.doc|
|[a063e7318b49dc1884d1a5f204bfa2a5](https://www.virustotal.com/gui/file/a063e7318b49dc1884d1a5f204bfa2a5)|DOCX||2019-04-21 21:43:38|Farzin_Karimi.docx|
|[a2aac37a137208966b49af3cbad1078f](https://www.virustotal.com/gui/file/a2aac37a137208966b49af3cbad1078f)|DOCX|o97m|2019-04-21 18:11:20|Farzin_Karimi.docx|
|[be61b0249f82838c85ce2bb0112245bc](https://www.virustotal.com/gui/file/be61b0249f82838c85ce2bb0112245bc)|DOCX|o97m|2019-04-21 18:08:10|Farzin_Karimi.docx|
|[875a25c82a3dfffe5a104f5a6edeeeb8](https://www.virustotal.com/gui/file/875a25c82a3dfffe5a104f5a6edeeeb8)|DOTM||2019-04-18 14:29:42|9389cf41e89a51860f918f29b55e34b5643264c990fe54273ffbbf5336a35a45.bin|
|[28ca1d5f6ac9a2e5c4d2e3b41276ffe2](https://www.virustotal.com/gui/file/28ca1d5f6ac9a2e5c4d2e3b41276ffe2)|DOCX|o97m|2019-04-18 13:40:30|ggm sigorta dosyasi.docx|
|[dbdd74a9ca6438675cdff52058026881](https://www.virustotal.com/gui/file/dbdd74a9ca6438675cdff52058026881)|DOC|sagent|2019-04-17 07:04:56|36be54812428b4967c3d25aafdc703567b42ad4536c089aefaef673ce36a958f.bin|
|[b41e0c8a2ce8e9de32b9f62b7c3ca047](https://www.virustotal.com/gui/file/b41e0c8a2ce8e9de32b9f62b7c3ca047)|DOCX|o97m|2019-04-16 11:21:50|=?UTF-8?B?Q3VtaHVyYmHFn2thbmzEscSfxLEgUHJvZ3JhbcSxIGhha2vEsW5kYSB5YXDEsWxhbiDDp2FsxLHFn21hbGFyIHNvbnVjdSBvbHXFn2FuIGVrdGVraSB0YXNsYcSfxLFuLmRvY3g=?=|
|[eabbb1a71e714e19e4b03a77dab68d88](https://www.virustotal.com/gui/file/eabbb1a71e714e19e4b03a77dab68d88)|DOCX|o97m|2019-04-16 05:30:18|Passport|
|[e45f4b641bb48aa110ff64ad59cbeb58](https://www.virustotal.com/gui/file/e45f4b641bb48aa110ff64ad59cbeb58)|DOCX||2019-04-15 15:55:13|e45f4b641bb48aa110ff64ad59cbeb58.docx|
|[547787bd44b667566c5587a002ccc82c](https://www.virustotal.com/gui/file/547787bd44b667566c5587a002ccc82c)|FPX|o97m|2019-04-15 13:32:40|c19095433ac4884d3205a59e61c90752ecb4e4fa6a84e21f49ed82d9ec48aa3c.bin|
|[195cdec884145a7fe9085f68f1bc795a](https://www.virustotal.com/gui/file/195cdec884145a7fe9085f68f1bc795a)|DOCX|sagent|2019-04-14 08:09:39|Az_rbaycan Respublikas_n_n _dliyy_ Nazirliyi.docx|
|[44912475958d7d3323633836fe62d41c](https://www.virustotal.com/gui/file/44912475958d7d3323633836fe62d41c)|ACE|CVE-2018-20250|2019-04-11 16:55:21|44912475958D7D3323633836FE62D41C.ace|
|[885dc879dc67b1adb31a40347fdaac1a](https://www.virustotal.com/gui/file/885dc879dc67b1adb31a40347fdaac1a)|DOC|o97m|2019-04-11 02:53:05|88e02850c575504bb4476f0d519cec8e6a562b72d17ed50b9d465d8e0de50093.bin|
|[eed599981c097944fa143e7d7f7e17b1](https://www.virustotal.com/gui/file/eed599981c097944fa143e7d7f7e17b1)|DOC|o97m|2019-04-09 08:40:15|ListOfHackedEmails.doc|
|[0638adf8fb4095d60fbef190a759aa9e](https://www.virustotal.com/gui/file/0638adf8fb4095d60fbef190a759aa9e)|DOC|o97m|2019-04-09 08:17:15|=?UTF-8?Q?SATEL_Teknolojisi_Lisans_S=C3=B6zle=C5=9Fmesi=5Fv5_hs=2Edoc?=|
|[0e916b0de0a112a4f3106cbaa01cff0f](https://www.virustotal.com/gui/file/0e916b0de0a112a4f3106cbaa01cff0f)|DOC|o97m|2019-04-08 12:42:48|README.txt|
|[b9a67ffb81420e68f9e5607cc200604a](https://www.virustotal.com/gui/file/b9a67ffb81420e68f9e5607cc200604a)|DOCX|sagent|2019-04-08 12:15:30|dab2cd3ddfe29a89b3d80830c6a4950952a44b6c97a664f1e9c182318ae5f4da.bin|
|[bfcec5556afffcb3f31754f3312d2ec7](https://www.virustotal.com/gui/file/bfcec5556afffcb3f31754f3312d2ec7)|DOC|Chanitor|2019-04-05 11:52:30|b2600ac9b83e5bb5f3d128dbb337ab1efcdc6ce404adb6678b062e95dbf10c93.txt|
|[5c6148619abb10bb3789dcfb32f759a6](https://www.virustotal.com/gui/file/5c6148619abb10bb3789dcfb32f759a6)|DOC|o97m|2019-04-04 21:12:12|F35-Specifications.doc|
|[7c538578597d5c66052500fbef91986c](https://www.virustotal.com/gui/file/7c538578597d5c66052500fbef91986c)|DOC|sagent|2019-04-04 13:16:31|9580aaca2e0cd607eaf54c3eb933e41538dc10cd341d41e3daa9185b2a6341c4.bin|
|[7680e8aef62594dc37a7fbb4b45c86b2](https://www.virustotal.com/gui/file/7680e8aef62594dc37a7fbb4b45c86b2)|DOCX|sagent|2019-04-04 09:50:11|ff349c8bf770ba09d3f9830e22ab6306c022f4bc1beb193b3b2cfe044f9d617b.bin|
|[e4f7e7c87e590281cce140e97cd0c664](https://www.virustotal.com/gui/file/e4f7e7c87e590281cce140e97cd0c664)|ZIP||2019-04-03 09:52:58|2ba871586176522fe75333e834c16025b01e1771e4c07bc13995adbfa77c45f5.bin|
|[592f0d9d7185eadab0509fdafdc305ab](https://www.virustotal.com/gui/file/592f0d9d7185eadab0509fdafdc305ab)|DOCX|sagent|2019-04-03 09:39:28|Nayatel.server.docx|
|[53b02fe863bdb5bfb7571bb20296887d](https://www.virustotal.com/gui/file/53b02fe863bdb5bfb7571bb20296887d)|DOC|sagent|2019-04-03 09:30:05| |
|[65978dd3d6b3a518f465676aa6bd876e](https://www.virustotal.com/gui/file/65978dd3d6b3a518f465676aa6bd876e)|DOCX||2019-04-03 07:24:48|Important Report.docx|
|[bb6fda2cdc852112544d2598a784d04f](https://www.virustotal.com/gui/file/bb6fda2cdc852112544d2598a784d04f)|DOC|sagent|2019-04-02 01:49:07|16433.jpg|
|[21aebece73549b3c4355a6060df410e9](https://www.virustotal.com/gui/file/21aebece73549b3c4355a6060df410e9)|DOC|o97m|2019-04-01 12:18:05|NETA_-T_bitak Siber G_venlik __birli_i Protokol__v5.doc|
|[f12bab5541a7d8ef4bbca81f6fc835a3](https://www.virustotal.com/gui/file/f12bab5541a7d8ef4bbca81f6fc835a3)|DOC|o97m|2019-04-01 08:54:23|16431.doc|
|[a7ef20b724541b078b222167ac72780e](https://www.virustotal.com/gui/file/a7ef20b724541b078b222167ac72780e)|ZIP|sagent|2019-04-01 08:52:20|6a441b2303aeb38309bf2cb70f1c97213b0fa2cf7a0f0f8251fe6dc9965ada3b.bin|
|[a066f5b93f4ac85e9adfe5ff3b10bc28](https://www.virustotal.com/gui/file/a066f5b93f4ac85e9adfe5ff3b10bc28)|DOCX|sagent|2019-04-01 08:50:59|741.docx|
|[8a004e93d7ee3b26d94156768bc0839d](https://www.virustotal.com/gui/file/8a004e93d7ee3b26d94156768bc0839d)|DOCX|o97m|2019-04-01 07:03:17|16431.docx|
|[88373d961f0bf9441becaf9f0d75ffa2](https://www.virustotal.com/gui/file/88373d961f0bf9441becaf9f0d75ffa2)|Win64 EXE||2019-03-25 08:38:03|31cf13e8579f0589424631c6be659480f9a204a50a54073e7d7fe6c9c81fa0db.bin|
|[2b938a9b20e7abcadd28a0f461a4e5d8](https://www.virustotal.com/gui/file/2b938a9b20e7abcadd28a0f461a4e5d8)|Text||2019-03-19 10:14:43|%PROGRAMDATA%\win32apisynclog.txt|
|[c8b271efec98e83a343933a32eff30d5](https://www.virustotal.com/gui/file/c8b271efec98e83a343933a32eff30d5)|Text||2019-03-19 10:14:43|%APPDATA%\microsoft\windows\start menu\programs\startup\win32apisynctskschdlr.bat|
|[d4de6b8ffcd878359315594515dd33c0](https://www.virustotal.com/gui/file/d4de6b8ffcd878359315594515dd33c0)|Text|cltrac|2019-03-19 10:14:39|%PROGRAMDATA%\win32apisync.bat|
|[cf3c731ca73ddec5d9cdd29c680c0f20](https://www.virustotal.com/gui/file/cf3c731ca73ddec5d9cdd29c680c0f20)|DOC|o97m|2019-03-19 04:30:06|4dd641df0f47cb7655032113343d53c0e7180d42e3549d08eb7cb83296b22f60-2.dms|
|[8a7b2167c14a0158b3e9a43453a3e8f3](https://www.virustotal.com/gui/file/8a7b2167c14a0158b3e9a43453a3e8f3)|DOC|o97m|2019-03-17 12:15:39|Gladiator.doc|
|[cfa845995b851aacdf40b8e6a5b87ba7](https://www.virustotal.com/gui/file/cfa845995b851aacdf40b8e6a5b87ba7)|DOC|o97m|2019-03-17 12:13:31|Gladiator.doc|
|[76f6c0bf075f9ae02a9a9e08cce1297d](https://www.virustotal.com/gui/file/76f6c0bf075f9ae02a9a9e08cce1297d)|DOC|o97m|2019-03-17 12:08:27|Gladiator.doc|
|[5c1af7d3dbb9bc455b793f1e3e0b2554](https://www.virustotal.com/gui/file/5c1af7d3dbb9bc455b793f1e3e0b2554)|DOC|o97m|2019-03-17 12:02:26|Gladiator.doc|
|[0d69debf5b805b0798429e5fca91cb99](https://www.virustotal.com/gui/file/0d69debf5b805b0798429e5fca91cb99)|DOC|o97m|2019-03-16 13:51:44|0d69debf5b805b0798429e5fca91cb99.doc|
|[a61b268e9bc9b7e6c9125cdbfb1c422a](https://www.virustotal.com/gui/file/a61b268e9bc9b7e6c9125cdbfb1c422a)|ZIP||2019-03-16 10:01:38|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/MuddyWaterAPT/Report-20190316.zip|
|[09aabd2613d339d90ddbd4b7c09195a9](https://www.virustotal.com/gui/file/09aabd2613d339d90ddbd4b7c09195a9)|DOC|o97m|2019-03-16 07:28:57|Gladiator_CRK.doc|
|[7debda78774ff5418a9fb88a1d297c1d](https://www.virustotal.com/gui/file/7debda78774ff5418a9fb88a1d297c1d)|Win64 EXE||2019-03-16 01:06:32|f1a69e2041ab8ab190d029d0e061f107ef1223b553e97c302e973a3b3c80f83e.bin|
|[806adc79e7ea3be50ef1d3974a16b7fb](https://www.virustotal.com/gui/file/806adc79e7ea3be50ef1d3974a16b7fb)|DOC|o97m|2019-03-12 11:19:36|93b749082651d7fc0b3caa9df81bad7617b3bd4475de58acfe953dfafc7b3987.doc|
|[46b138cf8645b457b2a8c4ebc79e06f1](https://www.virustotal.com/gui/file/46b138cf8645b457b2a8c4ebc79e06f1)|DOCM|o97m|2019-03-04 14:48:50|745b0e0793fc507d9e1ad7155beb7ac48f8a556e6ef06e43888cbefec3083f2f.bin|
|[cfeb9336bc59714e439931254f657002](https://www.virustotal.com/gui/file/cfeb9336bc59714e439931254f657002)|Win64 EXE||2019-03-04 10:08:14|config.exe|
|[e01d827d139bb933e34c7a35660b8728](https://www.virustotal.com/gui/file/e01d827d139bb933e34c7a35660b8728)|Text||2019-03-04 06:58:02|12.ps1|
|[febf7d5f01d8ddd584ae3b9f051f6338](https://www.virustotal.com/gui/file/febf7d5f01d8ddd584ae3b9f051f6338)|Win64 EXE||2019-03-02 19:48:02|Dropbox.exe|
|[dd2151e93aaa5c5f125b8e9739cc1a43](https://www.virustotal.com/gui/file/dd2151e93aaa5c5f125b8e9739cc1a43)|Win32 EXE|Delf|2019-03-02 09:34:02|CiscoAny.exe|
|[45c1afbe96d9bc77588fff5a0cb8bc7c](https://www.virustotal.com/gui/file/45c1afbe96d9bc77588fff5a0cb8bc7c)|Win32 EXE|Delf|2019-03-02 09:31:27|RT_4G|
|[ed490e756b349443694d9a14952a0816](https://www.virustotal.com/gui/file/ed490e756b349443694d9a14952a0816)|Text||2019-03-02 09:30:24|Powershell Payload.dat|
|[ca030353d63e19a715fa0fbfe30c6b1a](https://www.virustotal.com/gui/file/ca030353d63e19a715fa0fbfe30c6b1a)|Win32 EXE|Delf|2019-03-02 09:22:47|%APPDATA%\ciscoany.exe|
|[3dde37eeca45e7326058a9511cf126bc](https://www.virustotal.com/gui/file/3dde37eeca45e7326058a9511cf126bc)|DOCM|o97m|2019-03-02 09:12:36|67c3c5af27d19f25bc55c8e36ef19b57c03b211ce0637055721ae4b0e57011a7.bin|
|[c364869532f039795a82c990642294dd](https://www.virustotal.com/gui/file/c364869532f039795a82c990642294dd)|Android||2019-02-28 18:07:09|02f54da6c6f2f87ff7b713d46e058dedac1cedabd693643bb7f6dfe994b2105d.bin|
|[4a88256f5d39591957332c6b804e12c6](https://www.virustotal.com/gui/file/4a88256f5d39591957332c6b804e12c6)|DOCM|o97m|2019-02-28 16:53:57|5194f84cc52093bb4978167a9f2d5c0903e9de0b81ca20f492e4fc78b6a77655.bin|
|[bd62f7b1766154cc7adbb6cc42561b8e](https://www.virustotal.com/gui/file/bd62f7b1766154cc7adbb6cc42561b8e)|DOC||2019-02-28 11:39:35|=?UTF-8?B?U1BLIEtBTlVOIERFxJ7EsMWexLBLTMSwxJ7EsCBHxLBCIEfDllLDnMWew5wuZG9j?=|
|[0cb6d5a5bddf8c588a5546551997a8b6](https://www.virustotal.com/gui/file/0cb6d5a5bddf8c588a5546551997a8b6)|Win64 EXE||2019-02-20 08:49:22|57a9e2e6e715455827faefa982b4312b203189950fe285f1413174f5e812e408.bin|
|[932ab60bc42cf268fce7db20c6887c9d](https://www.virustotal.com/gui/file/932ab60bc42cf268fce7db20c6887c9d)|RAR|o97m|2019-02-13 06:33:58|d698c1d492332f312487e027d0665970b0462aceeeba3c91e762cff8579e7f72.bin|
|[935b5d01895e1bc88208fdfa0fad824b](https://www.virustotal.com/gui/file/935b5d01895e1bc88208fdfa0fad824b)|DOC|o97m|2019-02-13 06:32:51|3e6d39886d76ab3c08b26feae075e01e9fb3c90795fa52dd6c74e4ef8b590fe8.bin|
|[69e642fae31647bce22e119d69f81751](https://www.virustotal.com/gui/file/69e642fae31647bce22e119d69f81751)|DOC|o97m|2019-02-12 17:05:09|525ba2c8d35f6972ac8fcec8081ae35f6fe8119500be20a4113900fe57d6a0de.bin|
|[28ea7b3670b3fdf1ea41a50311a9c2ac](https://www.virustotal.com/gui/file/28ea7b3670b3fdf1ea41a50311a9c2ac)|RAR|o97m|2019-02-12 16:53:53|99e9a816e6b3fe7868b9c535ed13028f41089e0275eba1ba46ae7a62a7e47668.bin|
|[d2febfbe658461c92460fe7969772bda](https://www.virustotal.com/gui/file/d2febfbe658461c92460fe7969772bda)|Win32 EXE||2019-01-25 10:40:04| |
|[50cdfc2538c66fbc5bd723bc30e3133a](https://www.virustotal.com/gui/file/50cdfc2538c66fbc5bd723bc30e3133a)|DOCM|o97m|2019-01-24 20:57:20|NEW13.doc|
|[f1d9007fab75cad4a6a765d737ec2141](https://www.virustotal.com/gui/file/f1d9007fab75cad4a6a765d737ec2141)|Win32 EXE|agentwdcr|2019-01-22 17:40:06|f1d9007fab75cad4a6a765d737ec2141.virus|
|[b44ccd6939bdbc8f61c9e71a128b2613](https://www.virustotal.com/gui/file/b44ccd6939bdbc8f61c9e71a128b2613)|Win32 EXE|Delf|2019-01-16 16:44:16|.|
|[c5b5b42786938819686fd088d684c272](https://www.virustotal.com/gui/file/c5b5b42786938819686fd088d684c272)|Win32 EXE||2019-01-16 10:24:03|GoogleUpdate.exe|
|[072ce8858c7e5b3d71a9fa719613b107](https://www.virustotal.com/gui/file/072ce8858c7e5b3d71a9fa719613b107)|DOCM||2019-01-16 08:16:28|list.doc|
|[146cc97df36cb4cea39074652d069519](https://www.virustotal.com/gui/file/146cc97df36cb4cea39074652d069519)|Win64 EXE||2019-01-15 09:27:27|muddyc3.exe|
|[77be0d95a9f974226ccfc62c9aeae647](https://www.virustotal.com/gui/file/77be0d95a9f974226ccfc62c9aeae647)|Win32 EXE||2019-01-13 18:10:29|osp.exe|
|[f589af2ae8f1ace804ef5745feeb6d5c](https://www.virustotal.com/gui/file/f589af2ae8f1ace804ef5745feeb6d5c)|DOCM|Banload|2019-01-12 14:08:20|66733fe27591347f6b28bc7750ba1b47b2853f711adcdb1270951c6b92e795d6.bin|
|[1dae271ffc1841009104521e9c37e993](https://www.virustotal.com/gui/file/1dae271ffc1841009104521e9c37e993)|Win32 EXE||2019-01-11 08:12:11|GoogleUpdate.exe|
|[d4259eb8e3b90ac08c9337df84468e87](https://www.virustotal.com/gui/file/d4259eb8e3b90ac08c9337df84468e87)|Win32 EXE||2019-01-10 15:01:21|GoogleUpdate.exe|
|[92816bd34efb6f8b7149d6c2c1545d6a](https://www.virustotal.com/gui/file/92816bd34efb6f8b7149d6c2c1545d6a)|FPX|Banload|2019-01-10 14:49:49| |
|[9f092a060381db4ed63d4e96da5c8d54](https://www.virustotal.com/gui/file/9f092a060381db4ed63d4e96da5c8d54)|FPX|o97m|2019-01-10 14:45:09| |
|[44284b5eb3b6da8c988924907478adbd](https://www.virustotal.com/gui/file/44284b5eb3b6da8c988924907478adbd)|DOCM||2019-01-10 12:33:44|2-Admission-Letter -For Foreign Students.doc|
|[85b3f269251d805d3e2f78d37aeb1744](https://www.virustotal.com/gui/file/85b3f269251d805d3e2f78d37aeb1744)|DOCM||2019-01-10 12:33:04|3-New Law Updated for Client-VMP.doc|
|[4a3cfb80ab75900f40647b12d8d0f789](https://www.virustotal.com/gui/file/4a3cfb80ab75900f40647b12d8d0f789)|Email||2019-01-10 12:32:01|ZSl_m7S.eml|
|[38f3ad15741a41288fe19ebe09fa8049](https://www.virustotal.com/gui/file/38f3ad15741a41288fe19ebe09fa8049)|Email||2019-01-10 12:31:33|BOWn012.eml|
|[6f44e57c81414355e3d0d0dafdf1d80e](https://www.virustotal.com/gui/file/6f44e57c81414355e3d0d0dafdf1d80e)|Win32 EXE||2019-01-04 07:49:27|GoogleUpdate.exe|
|[99e5deeb8182ec199936f9cf2e41b173](https://www.virustotal.com/gui/file/99e5deeb8182ec199936f9cf2e41b173)|Android||2019-01-02 15:48:41|MagicTools2.apk|
|[8899c0dac9f6bb73ce750ae7b3250dbd](https://www.virustotal.com/gui/file/8899c0dac9f6bb73ce750ae7b3250dbd)|DOCM||2019-01-02 10:07:48|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/MuddyWaterAPT/2-Merve_Cooperation_CV.doc|
|[80560475839c012ec1871c523f3c78f2](https://www.virustotal.com/gui/file/80560475839c012ec1871c523f3c78f2)|Android||2018-12-31 16:37:10|dff2e39b2e008ea89a3d6b36dcd9b8c927fb501d60c1ad5a52ed1ffe225da2e2.bin|
|[f2fd6a2c1d5a4c922ad3b00eaac4d755](https://www.virustotal.com/gui/file/f2fd6a2c1d5a4c922ad3b00eaac4d755)|Android||2018-12-31 16:35:20|MagicTools.apk|
|[694a808415f268beaa5d34a11bf24d1a](https://www.virustotal.com/gui/file/694a808415f268beaa5d34a11bf24d1a)|Win64 DLL||2018-12-29 18:32:41|myfile.exe|
|[10ec3571596c30b9993b89f12d29d23c](https://www.virustotal.com/gui/file/10ec3571596c30b9993b89f12d29d23c)|Android||2018-12-26 03:20:32|9af8a93519d22ed04ffb9ccf6861c9df1b77dc5d22e0aeaff4a582dbf8660ba6.bin|
|[38896b2af36b44f0ab0b66ac8097a1cc](https://www.virustotal.com/gui/file/38896b2af36b44f0ab0b66ac8097a1cc)|Win32 EXE|razy|2018-12-19 09:12:41|svchosts.exe|
|[a93671ced24b7817f46bce89bb1accc5](https://www.virustotal.com/gui/file/a93671ced24b7817f46bce89bb1accc5)|Win32 EXE|razy|2018-12-16 11:04:44|svchosts.exe|
|[289715df00e1c7414ddd7f0751d5a298](https://www.virustotal.com/gui/file/289715df00e1c7414ddd7f0751d5a298)|Android|Kasandra|2018-12-11 03:25:20|de4a1622b498c1cc989be1a1480a23f4c4e9cd25e729a329cfadb7594c714358.bin|
|[837eaad1187fe9fbf91f9bc7c054f5d9](https://www.virustotal.com/gui/file/837eaad1187fe9fbf91f9bc7c054f5d9)|Win32 EXE||2018-12-05 16:05:07| |
|[f041f96ed1abdcc84157488aa51b62af](https://www.virustotal.com/gui/file/f041f96ed1abdcc84157488aa51b62af)|Win32 EXE||2018-12-05 16:05:00| |
|[a750e2885ed3c294de148864723f73e3](https://www.virustotal.com/gui/file/a750e2885ed3c294de148864723f73e3)|Win32 EXE|razy|2018-12-05 16:04:19|svchosts.exe|
|[fa200e715e856550c76f729604ebaf57](https://www.virustotal.com/gui/file/fa200e715e856550c76f729604ebaf57)|Win32 EXE||2018-12-05 16:04:01|Lisfon.exe|
|[8e3a42371d7af2c7d0bb4036c9fb0fe3](https://www.virustotal.com/gui/file/8e3a42371d7af2c7d0bb4036c9fb0fe3)|Win32 EXE||2018-12-05 16:03:54| |
|[54982c616098f6c6fbc48703922f15f4](https://www.virustotal.com/gui/file/54982c616098f6c6fbc48703922f15f4)|Win32 EXE||2018-12-05 16:03:30|Lisfon.exe|
|[f5dee1f9cd47dc7bae468da9732c862e](https://www.virustotal.com/gui/file/f5dee1f9cd47dc7bae468da9732c862e)|Win32 EXE|razy|2018-12-05 15:59:34|LisfonService.exe|
|[953970e953253717612813200a086f7c](https://www.virustotal.com/gui/file/953970e953253717612813200a086f7c)|Win64 EXE||2018-12-02 21:04:17|Mmap.exe|
|[5ff373bbdc20df7751d9f3d2fc9373a5](https://www.virustotal.com/gui/file/5ff373bbdc20df7751d9f3d2fc9373a5)|Win32 DLL||2018-11-29 17:09:32|png_2018.dll|
|[74d96d9b38be14fa186d0d8786f986e1](https://www.virustotal.com/gui/file/74d96d9b38be14fa186d0d8786f986e1)|Text||2018-11-28 08:49:12|%WINDIR%\temp\temp.jpg|
|[44c900bd374ebce1aac1f1e45958f0fe](https://www.virustotal.com/gui/file/44c900bd374ebce1aac1f1e45958f0fe)|DOC|o97m|2018-11-27 18:48:49|shakva-om.doc|
|[ebf4e134b61637d377aaa3824861debf](https://www.virustotal.com/gui/file/ebf4e134b61637d377aaa3824861debf)|Text||2018-11-27 15:11:08|icon.png|
|[23d237ca033a2f69c0866e4a10841c64](https://www.virustotal.com/gui/file/23d237ca033a2f69c0866e4a10841c64)|ZIP|sload|2018-11-27 06:16:04|shakva-om.zip|
|[0cf25597343240f88358c694d7ae7e0a](https://www.virustotal.com/gui/file/0cf25597343240f88358c694d7ae7e0a)|DOC|o97m|2018-11-26 11:35:34|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/MuddyWaterAPT/shakva-lb.doc.bin|
|[a256abb5da891f109acf8a496d9792c4](https://www.virustotal.com/gui/file/a256abb5da891f109acf8a496d9792c4)|ZIP|sload|2018-11-26 11:32:29|shakva-lb (1).zip|
|[9533003c5f7c718951a3171da03844fb](https://www.virustotal.com/gui/file/9533003c5f7c718951a3171da03844fb)|Win32 DLL||2018-11-22 13:59:29|dttcodexgigas.9e97cf4050fc052ae144fcecb33294c39a7a7672|
|[b897fa2a9a3067dfd919cc27c269b203](https://www.virustotal.com/gui/file/b897fa2a9a3067dfd919cc27c269b203)|DOC||2018-11-22 11:11:58|maliyeraporti (Gizli Bilgisi).doc|
|[127bd5e7f11977a07428837a2d2fa9f1](https://www.virustotal.com/gui/file/127bd5e7f11977a07428837a2d2fa9f1)|Win32 DLL||2018-11-20 21:05:18| |
|[6c303f68b97b72100637735cd2150393](https://www.virustotal.com/gui/file/6c303f68b97b72100637735cd2150393)|Win32 EXE|razy|2018-11-20 21:03:51|svchosts.exe|
|[3b6b74bf57746a31b7c8bdbb22282290](https://www.virustotal.com/gui/file/3b6b74bf57746a31b7c8bdbb22282290)|Win32 DLL||2018-11-19 16:26:50|3b6b74bf57746a31b7c8bdbb22282290.virobj|
|[ca9230a54f40a6a0fe52d7379459189c](https://www.virustotal.com/gui/file/ca9230a54f40a6a0fe52d7379459189c)|DOC|valyria|2018-11-19 14:26:08|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/MuddyWaterAPT/Cv.doc.bin|
|[8fbb83e448095d1c73ee1431abc15c80](https://www.virustotal.com/gui/file/8fbb83e448095d1c73ee1431abc15c80)|DOCM|w2km|2018-11-19 12:15:04|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT28,FancyBear/ZebrocyOct2018/Raport.doc|
|[5935522717aee842433a5de9d228a715](https://www.virustotal.com/gui/file/5935522717aee842433a5de9d228a715)|DOC|sload|2018-11-15 14:59:46|MyCv.doc|
|[2ae299e3693518104bf194d6257d5be6](https://www.virustotal.com/gui/file/2ae299e3693518104bf194d6257d5be6)|Win32 EXE||2018-10-24 13:04:02|LisfonService.exe|
|[2b8ab9112e34bb910055d85ec800db3f](https://www.virustotal.com/gui/file/2b8ab9112e34bb910055d85ec800db3f)|Win64 EXE|Stealer|2018-10-10 06:09:30| |
|[a19d8a2bc853b6bffe04a3131da0b0e2](https://www.virustotal.com/gui/file/a19d8a2bc853b6bffe04a3131da0b0e2)|Win32 EXE||2018-10-08 10:45:18|muddy.bin|
|[cf5c526d50a385ba289c08affbdc85ed](https://www.virustotal.com/gui/file/cf5c526d50a385ba289c08affbdc85ed)|Win32 EXE|razy|2018-10-08 10:03:03|svchosts.exe|
|[8863f175793a6410649e6675bd1ce009](https://www.virustotal.com/gui/file/8863f175793a6410649e6675bd1ce009)|Win32 EXE|Ursu|2018-10-07 06:23:57|LSASS.exe|
|[35c310a1f88e41e777bc2ac4bc5284d9](https://www.virustotal.com/gui/file/35c310a1f88e41e777bc2ac4bc5284d9)|Win32 EXE||2018-10-02 10:35:13|osport.exe|
|[540580f83dd8579423932e91660b68a8](https://www.virustotal.com/gui/file/540580f83dd8579423932e91660b68a8)|Win64 EXE||2018-09-30 10:43:42|3c75c2f7b299d9cc03a7ff91c568defaa39b4be02d58a75a85930ab23d2a2cff.bin|
|[e6e7661efb60b9aea7969a30e17ace19](https://www.virustotal.com/gui/file/e6e7661efb60b9aea7969a30e17ace19)|Win32 EXE|razy|2018-09-30 10:40:28|svchosts.exe|
|[671e6a53a25075b9ce3a6576ddaf5174](https://www.virustotal.com/gui/file/671e6a53a25075b9ce3a6576ddaf5174)|Android||2018-09-26 06:14:07|6b4d271a48d118843aee3dee4481fa2930732ed7075db3241a8991418f00d92b.bin|
|[1ff6007ad0e31f4061ae46d7d73d10e0](https://www.virustotal.com/gui/file/1ff6007ad0e31f4061ae46d7d73d10e0)|Win32 EXE||2018-09-25 10:16:15|3fee29fefe4aa9386a11a7a615dd052ff89e21d87eee0fff5d6f933d9384ede2.bin|
|[efbcdeff218740d6c4d94350e966fa3c](https://www.virustotal.com/gui/file/efbcdeff218740d6c4d94350e966fa3c)|Win64 EXE||2018-09-24 09:18:19|efdec1ad0830359632141186917fd32809360894e8c0a28c28d3d0a71f48ec2f.bin|
|[d3bf749bb4679ae405015ad2d0ad5631](https://www.virustotal.com/gui/file/d3bf749bb4679ae405015ad2d0ad5631)|Win64 EXE||2018-09-24 09:16:33|moddump.exe|
|[a9ec30226c83ba6d7abb8d2011cdae14](https://www.virustotal.com/gui/file/a9ec30226c83ba6d7abb8d2011cdae14)|DOC|o97m|2018-09-17 09:08:49|download|
|[e5683fb480353c0dec333a7573710748](https://www.virustotal.com/gui/file/e5683fb480353c0dec333a7573710748)|DOC|o97m|2018-09-11 05:18:26|G.B.doc|
|[d89742e4f80ad28860d489ce78f1f993](https://www.virustotal.com/gui/file/d89742e4f80ad28860d489ce78f1f993)|Win64 EXE||2018-07-15 09:50:40|uTzFShtdBtOZxF.exe|
|[c561e81e30316208925bfddb3cf3360a](https://www.virustotal.com/gui/file/c561e81e30316208925bfddb3cf3360a)|C++|phishing|2018-07-15 07:18:50|ptp.ps1|
|[5a42a712e3b3cfa1db32d9e3d832f8f1](https://www.virustotal.com/gui/file/5a42a712e3b3cfa1db32d9e3d832f8f1)|DOC|o97m|2018-07-10 14:17:16|=?UTF-8?Q?=C5=9Eikayetler_ve_ele=C5=9Ftiriler=2Edoc?=|
|[befc203d7fa4c91326791a73e6d6b4da](https://www.virustotal.com/gui/file/befc203d7fa4c91326791a73e6d6b4da)|Win64 EXE||2018-07-05 10:30:34|myfile.exe|
|[e7a6c57566d9523daa57fe16f52e377e](https://www.virustotal.com/gui/file/e7a6c57566d9523daa57fe16f52e377e)|C++||2018-07-05 10:28:41|template.ps1|
|[47ec75d3290add179ac5218d193bb9a8](https://www.virustotal.com/gui/file/47ec75d3290add179ac5218d193bb9a8)|Win64 EXE||2018-06-25 14:54:19|myfile.exe|
|[345b1ea293764df86506f97ba498cc5e](https://www.virustotal.com/gui/file/345b1ea293764df86506f97ba498cc5e)|Win64 EXE|phishing|2018-06-25 14:36:31|slaver.exe|
|[9f4044674100a8c28f9ed1b336c337ce](https://www.virustotal.com/gui/file/9f4044674100a8c28f9ed1b336c337ce)|DOC|o97m|2018-06-18 19:23:51|evil.doc|
|[4f873578956d2790101443f24e4bd4d3](https://www.virustotal.com/gui/file/4f873578956d2790101443f24e4bd4d3)|FPX|phishing|2018-06-18 12:31:56|~WRD0001.tmp|
|[ce2df2907ce543438c19cfaf6c14f699](https://www.virustotal.com/gui/file/ce2df2907ce543438c19cfaf6c14f699)|DOC|o97m|2018-06-11 07:49:16|ksu.edu.sa.doc|
|[851f083d29c5f8f411a7ad0392c4496c](https://www.virustotal.com/gui/file/851f083d29c5f8f411a7ad0392c4496c)|Win64 EXE||2018-05-31 00:10:52|484f78eb4a3bb69d62491fdb84f2c81b7ae131ec8452a04d6018a634e961cd6a.bin|
|[16ac1a2c1e1c3b49e1a3a48fb71cc74f](https://www.virustotal.com/gui/file/16ac1a2c1e1c3b49e1a3a48fb71cc74f)|DOC|o97m|2018-05-30 10:51:23|معلومات هامة.doc|
|[be62fc5b1576e0a8491519e10bab931d](https://www.virustotal.com/gui/file/be62fc5b1576e0a8491519e10bab931d)|FPX|phishing|2018-05-24 08:02:23|file.doc|
|[eb69fb45feb97af81c2f306564acc2da](https://www.virustotal.com/gui/file/eb69fb45feb97af81c2f306564acc2da)|DOC||2018-05-21 16:28:23|=?UTF-8?Q?=C3=B6nemli_rapor=2Edoc?=|
|[bb476622bcb0c666e12fbe4ccda8bbef](https://www.virustotal.com/gui/file/bb476622bcb0c666e12fbe4ccda8bbef)|DOC||2018-05-21 11:22:40|file.doc|
|[aa564e207926d06b8a59ba50ca2c543d](https://www.virustotal.com/gui/file/aa564e207926d06b8a59ba50ca2c543d)|DOC|w2km|2018-05-15 17:21:05|Early election.doc|
|[3c2a0d6d0ecf06f1be9ad411d06f7ba8](https://www.virustotal.com/gui/file/3c2a0d6d0ecf06f1be9ad411d06f7ba8)|DOC|o97m|2018-05-15 14:18:44|=?UTF-8?B?ecO2bmVyZ2UuZG9j?=|
|[f00fd318bf58586c29ab970132d1fd2a](https://www.virustotal.com/gui/file/f00fd318bf58586c29ab970132d1fd2a)|DOC||2018-05-15 14:16:28|=?UTF-8?Q?Gizli_Ko=C5=9Fullar=2Edoc?=|
|[e75443a5e825f69c75380b6dc76c6b50](https://www.virustotal.com/gui/file/e75443a5e825f69c75380b6dc76c6b50)|Win32 EXE||2018-05-10 04:53:57|TestService.exe|
|[864d6321be50f29e7a7a4bfab746245a](https://www.virustotal.com/gui/file/864d6321be50f29e7a7a4bfab746245a)|DOC|o97m|2018-05-09 13:22:18|DAMAMAX.doc|
|[59502e209aedf80e170e653306ca1553](https://www.virustotal.com/gui/file/59502e209aedf80e170e653306ca1553)|DOC|w2km|2018-05-08 22:03:17|İnkişaf üçün görüş.doc|
|[fdb4b4520034be269a65cfaee555c52e](https://www.virustotal.com/gui/file/fdb4b4520034be269a65cfaee555c52e)|DOC|Banload|2018-05-07 10:01:16|fdb4b4520034be269a65cfaee555c52e.virus|
|[665947cf7037a6772687b69279753cdf](https://www.virustotal.com/gui/file/665947cf7037a6772687b69279753cdf)|DOC|w2km|2018-05-06 07:38:46|mofa.gov.iq.doc|
|[ab4f947f4649b9ec28d182b02778aa69](https://www.virustotal.com/gui/file/ab4f947f4649b9ec28d182b02778aa69)|DOC||2018-05-05 04:38:52|Cabinet.doc|
|[f2b5373f32a4b9b3d34701ff973ba69c](https://www.virustotal.com/gui/file/f2b5373f32a4b9b3d34701ff973ba69c)|DOC||2018-05-04 06:48:52|=?UTF-8?B?VXl1xZ90dXJ1Y3Uga2HDp2Frw6fEsWzEscSfxLEuZG9j?=|
|[9bea3eb68ea0c215a17fa69f632d9020](https://www.virustotal.com/gui/file/9bea3eb68ea0c215a17fa69f632d9020)|Win32 EXE||2018-05-03 08:49:24|losi.exe|
|[f8902df9fe49a04f101d0bfb41a33028](https://www.virustotal.com/gui/file/f8902df9fe49a04f101d0bfb41a33028)|Win32 EXE||2018-05-03 05:50:38|losi.exe|
|[bde5a60a53bb00e5ccc03bf0f446d8df](https://www.virustotal.com/gui/file/bde5a60a53bb00e5ccc03bf0f446d8df)|unknown||2018-04-28 01:51:02|InstallConfNT.vbs|
|[9de49e507175ce42086f091f0e2f40f8](https://www.virustotal.com/gui/file/9de49e507175ce42086f091f0e2f40f8)|unknown||2018-04-28 01:50:25|WindowsNT.vbs|
|[cc1f6feec3b276387aa77a8cdb595f3f](https://www.virustotal.com/gui/file/cc1f6feec3b276387aa77a8cdb595f3f)|unknown||2018-04-28 01:48:28|WindowsNT.ini|
|[08acd1149b09bf6455c553f512b51085](https://www.virustotal.com/gui/file/08acd1149b09bf6455c553f512b51085)|DOC||2018-04-27 06:38:18|myfile.exe|
|[ae3e43d43f57f4f9a92cd1f9340b0eae](https://www.virustotal.com/gui/file/ae3e43d43f57f4f9a92cd1f9340b0eae)|Android||2018-04-26 01:37:31|e9617764411603ddd4e7f39603a4bdaf602e20126608b3717b1f6fcae60981f2.bin|
|[859191c40fb1d1508e8ca1bdfa56ac76](https://www.virustotal.com/gui/file/859191c40fb1d1508e8ca1bdfa56ac76)|Android||2018-04-25 17:50:11|SetaNews.apk|
|[4c5a5c236c9f4480b3d725f297673fad](https://www.virustotal.com/gui/file/4c5a5c236c9f4480b3d725f297673fad)|DOC|o97m|2018-04-20 05:22:09|gop.doc|
|[c8b0458c384fd34971875b1c753c9c7c](https://www.virustotal.com/gui/file/c8b0458c384fd34971875b1c753c9c7c)|DOC|o97m|2018-04-03 09:33:49|5c7d16bd89ef37fe02cac1851e7214a01636ee4061a80bfdbde3a2d199721a79.bin|
|[801f34abbf90ac2b4fb4b6289830cd16](https://www.virustotal.com/gui/file/801f34abbf90ac2b4fb4b6289830cd16)|DOC|o97m|2018-03-26 14:41:32|ECP.doc|
|[aa1e8d0e1c4d4eb9984124df003ea7f2](https://www.virustotal.com/gui/file/aa1e8d0e1c4d4eb9984124df003ea7f2)|DOC|o97m|2018-03-20 12:32:43|turkish armed forces|
|[9486593e4fb5a4d440093d54a3519187](https://www.virustotal.com/gui/file/9486593e4fb5a4d440093d54a3519187)|DOC||2018-03-12 10:06:50|Connectel .doc|
|[cd371d1d3bd7c8e2110587cfa8b7eaea](https://www.virustotal.com/gui/file/cd371d1d3bd7c8e2110587cfa8b7eaea)|DOC|o97m|2018-03-09 14:09:49|Virus3.doc|
|[1af32e03716ec596a09cd1d1b20d4904](https://www.virustotal.com/gui/file/1af32e03716ec596a09cd1d1b20d4904)|unknown||2018-03-09 13:17:34|1af32e03716ec596a09cd1d1b20d4904.virus|
|[25e515708868e73c30194a69d7bf8d2c](https://www.virustotal.com/gui/file/25e515708868e73c30194a69d7bf8d2c)|unknown||2018-03-09 13:16:11|25e515708868e73c30194a69d7bf8d2c.virus|
|[ce815f494f3d89bc3a63d28280bd5941](https://www.virustotal.com/gui/file/ce815f494f3d89bc3a63d28280bd5941)|XML||2018-03-05 14:11:04|ce815f494f3d89bc3a63d28280bd5941.virus|
|[b8939fa58fad8aa1ec271f6dae0b7255](https://www.virustotal.com/gui/file/b8939fa58fad8aa1ec271f6dae0b7255)|DOC||2018-03-05 13:53:58|b8939fa58fad8aa1ec271f6dae0b7255.virus|
|[f84914c30ae4e6b9b1f23d5c01e001ed](https://www.virustotal.com/gui/file/f84914c30ae4e6b9b1f23d5c01e001ed)|DOC|w2km|2018-03-05 12:41:29|f84914c30ae4e6b9b1f23d5c01e001ed.virus|
|[ff46053ad16728062c6e7235bc7e8deb](https://www.virustotal.com/gui/file/ff46053ad16728062c6e7235bc7e8deb)|DOC|o97m|2018-03-05 06:48:12|ff46053ad16728062c6e7235bc7e8deb.virus|
|[cc019683021a4ff05e84860b62676dc1](https://www.virustotal.com/gui/file/cc019683021a4ff05e84860b62676dc1)|DOC|w2km|2018-03-03 17:32:03|cc019683021a4ff05e84860b62676dc1.virus|
|[5de97ae178888f2dd222bb8a66060ac2](https://www.virustotal.com/gui/file/5de97ae178888f2dd222bb8a66060ac2)|DOC|w2km|2018-03-01 11:21:02|5de97ae178888f2dd222bb8a66060ac2.virus|
|[5466c8a099d1d30096775b1f4357d3cf](https://www.virustotal.com/gui/file/5466c8a099d1d30096775b1f4357d3cf)|DOC||2018-02-28 14:35:07|5466c8a099d1d30096775b1f4357d3cf.virus|
|[ffb8ea0347a3af3dd2ab1b4e5a1be18a](https://www.virustotal.com/gui/file/ffb8ea0347a3af3dd2ab1b4e5a1be18a)|DOC|w2km|2018-02-28 13:24:46|/home/wwwroot/topthreat/topthreat/uploads/20190906/dd7fd057be9f8b42b89ee92b0c4ccb7a.|
|[d632c8444aab1b43a663401e80c0bac4](https://www.virustotal.com/gui/file/d632c8444aab1b43a663401e80c0bac4)|DOC||2018-02-28 08:44:56|d632c8444aab1b43a663401e80c0bac4.virus|
|[bf310319d6ef95f69a45fc4f2d237ed4](https://www.virustotal.com/gui/file/bf310319d6ef95f69a45fc4f2d237ed4)|DOC|w2km|2018-02-27 03:52:40|myfile.exe|
|[24e1bd221ba3813ed7b6056136237587](https://www.virustotal.com/gui/file/24e1bd221ba3813ed7b6056136237587)|DOC|w2km|2018-02-26 06:27:21|24e1bd221ba3813ed7b6056136237587.virus|
|[37f7e6e5f073508e1ee552ebea5d200e](https://www.virustotal.com/gui/file/37f7e6e5f073508e1ee552ebea5d200e)|DOC|w2km|2018-02-23 10:43:17|37f7e6e5f073508e1ee552ebea5d200e.virus|
|[19c28fc2a8ac8a9a9032603d816b3076](https://www.virustotal.com/gui/file/19c28fc2a8ac8a9a9032603d816b3076)|XML||2018-02-21 08:36:26|19c28fc2a8ac8a9a9032603d816b3076.virus|
|[091b911a4122029b8ae9dc0fd942466d](https://www.virustotal.com/gui/file/091b911a4122029b8ae9dc0fd942466d)|unknown||2018-02-21 08:36:00|091b911a4122029b8ae9dc0fd942466d.virus|
|[d15aee026074fbd18f780fb51ec0632a](https://www.virustotal.com/gui/file/d15aee026074fbd18f780fb51ec0632a)|DOC||2018-02-20 13:10:56|d15aee026074fbd18f780fb51ec0632a.virus|
|[62094985dd9d56c9c89b47e47eb73207](https://www.virustotal.com/gui/file/62094985dd9d56c9c89b47e47eb73207)|DOC||2018-02-12 19:29:13|62094985dd9d56c9c89b47e47eb73207.virus|
|[88eacf8717b7ea126aeba0fa46a485ed](https://www.virustotal.com/gui/file/88eacf8717b7ea126aeba0fa46a485ed)|unknown||2018-02-12 19:23:03|88eacf8717b7ea126aeba0fa46a485ed.virus|
|[1e98bb89e3c80b5651279a43b44eaa04](https://www.virustotal.com/gui/file/1e98bb89e3c80b5651279a43b44eaa04)|unknown|valyria|2018-02-12 19:17:46|1e98bb89e3c80b5651279a43b44eaa04.virus|
|[7beb94f602e97785370fec2d059d54a5](https://www.virustotal.com/gui/file/7beb94f602e97785370fec2d059d54a5)|DOC|w2km|2018-02-12 10:58:07|MIT.doc|
|[c43f9aaf5ca1e7b86f0245b7ec0c57fa](https://www.virustotal.com/gui/file/c43f9aaf5ca1e7b86f0245b7ec0c57fa)|C++||2018-02-12 09:10:41|mojx.ps1|
|[d32d7c0b043e468613cdf7793ffd01ac](https://www.virustotal.com/gui/file/d32d7c0b043e468613cdf7793ffd01ac)|C++||2018-02-12 09:07:26|ash.ps1|
|[7a2ff07283ddc69d9f34cfa0d3c936d4](https://www.virustotal.com/gui/file/7a2ff07283ddc69d9f34cfa0d3c936d4)|DOC|w2km|2018-02-10 17:50:30|7a2ff07283ddc69d9f34cfa0d3c936d4.virus|
|[ddba713c20c232bcd60daf0ffabeffb8](https://www.virustotal.com/gui/file/ddba713c20c232bcd60daf0ffabeffb8)|Win32 EXE||2018-02-09 06:57:14|nt.exe|
|[c375bbf248592cee1a1999227457c300](https://www.virustotal.com/gui/file/c375bbf248592cee1a1999227457c300)|DOC||2018-02-08 06:58:06|c375bbf248592cee1a1999227457c300.virus|
|[94edf251b5fe7cc19488b5f0c3c3e359](https://www.virustotal.com/gui/file/94edf251b5fe7cc19488b5f0c3c3e359)|DOC|valyria|2018-02-06 13:24:05|94edf251b5fe7cc19488b5f0c3c3e359.virus|
|[18d984506999800af931b782f5470bcc](https://www.virustotal.com/gui/file/18d984506999800af931b782f5470bcc)|DOC|valyria|2018-01-31 12:38:43|18d984506999800af931b782f5470bcc.virus|
|[202f6909736fc52a9edde293444e331f](https://www.virustotal.com/gui/file/202f6909736fc52a9edde293444e331f)|C++||2018-01-30 19:32:13|ash.ps1|
|[488723b8e56dbaac8ccdc79499037d5f](https://www.virustotal.com/gui/file/488723b8e56dbaac8ccdc79499037d5f)|Win32 EXE||2018-01-29 17:51:20|dopass.exe|
|[e87ea47e91540700b31082515d2dc802](https://www.virustotal.com/gui/file/e87ea47e91540700b31082515d2dc802)|DOC|valyria|2018-01-28 15:40:14|e87ea47e91540700b31082515d2dc802.virus|
|[2c4c077dda1b23036055ae6c8f463b30](https://www.virustotal.com/gui/file/2c4c077dda1b23036055ae6c8f463b30)|unknown|valyria|2018-01-26 15:24:35|2c4c077dda1b23036055ae6c8f463b30.virus|
|[bdc7c2fb733d6a324b1783f8434027aa](https://www.virustotal.com/gui/file/bdc7c2fb733d6a324b1783f8434027aa)|unknown||2018-01-26 06:29:04|system.ps1|
|[cabdb258b73c0a6af3e667cb43dbe1b4](https://www.virustotal.com/gui/file/cabdb258b73c0a6af3e667cb43dbe1b4)|unknown||2018-01-25 19:10:19|cabdb258b73c0a6af3e667cb43dbe1b4.virus|
|[0e55fe78dd28b564970aa543c4396c37](https://www.virustotal.com/gui/file/0e55fe78dd28b564970aa543c4396c37)|DOC|w2km|2018-01-25 09:30:23|0e55fe78dd28b564970aa543c4396c37.virus|
|[5bd61a94e7698574eaf82ef277316463](https://www.virustotal.com/gui/file/5bd61a94e7698574eaf82ef277316463)|DOC||2018-01-23 12:12:10|/home/virustotal/sample/5BD61A94E7698574EAF82EF277316463|
|[79a6a989005cd3bdea7eefa758134c4b](https://www.virustotal.com/gui/file/79a6a989005cd3bdea7eefa758134c4b)|Win64 DLL||2018-01-20 01:31:18|fil815AA26B51CA0CAEDF327C3AA02F0DB8|
|[35e0117a78a9887e53a27615dd4bbb06](https://www.virustotal.com/gui/file/35e0117a78a9887e53a27615dd4bbb06)|Win64 DLL||2018-01-18 15:05:04|virt.bin|
|[faa4469d5cd90623312c86d651f2d930](https://www.virustotal.com/gui/file/faa4469d5cd90623312c86d651f2d930)|DOC|valyria|2018-01-18 12:23:43|ngn.tr.doc|
|[2ab9ac955be73c3319ccfdbd047bf51b](https://www.virustotal.com/gui/file/2ab9ac955be73c3319ccfdbd047bf51b)|Text||2018-01-09 04:13:37|2ab9ac955be73c3319ccfdbd047bf51b.virus|
|[bcec06060786dabfe8cd2c083e9e82cb](https://www.virustotal.com/gui/file/bcec06060786dabfe8cd2c083e9e82cb)|Text|Kryptik|2018-01-09 04:06:37|bcec06060786dabfe8cd2c083e9e82cb.virus|
|[7d8adc38962f588aef580aa733572b85](https://www.virustotal.com/gui/file/7d8adc38962f588aef580aa733572b85)|DOC||2018-01-08 19:18:45|7d8adc38962f588aef580aa733572b85.virus|
|[68e89d88b7cca6f12707d5a463c9d1d8](https://www.virustotal.com/gui/file/68e89d88b7cca6f12707d5a463c9d1d8)|DOC||2018-01-08 10:29:25|68e89d88b7cca6f12707d5a463c9d1d8.virus|
|[6c997726d502a68af2ac2e3563365852](https://www.virustotal.com/gui/file/6c997726d502a68af2ac2e3563365852)|DOC|valyria|2018-01-02 04:21:52|/home/virustotal/sample/6C997726D502A68AF2AC2E3563365852|
|[e4977728b537e82605ed4096d5ecdc47](https://www.virustotal.com/gui/file/e4977728b537e82605ed4096d5ecdc47)|Win32 EXE||2017-12-28 11:02:18|smb.exe|
|[d5f8932feeb3d70c624cef487e6aedcc](https://www.virustotal.com/gui/file/d5f8932feeb3d70c624cef487e6aedcc)|Text||2017-12-28 11:01:45|uac.js|
|[754b6e82227e03f8fa09125695d1067c](https://www.virustotal.com/gui/file/754b6e82227e03f8fa09125695d1067c)|Text||2017-12-20 17:35:39|ash.ps1|
|[7386faface4217820cecd6d175a9353b](https://www.virustotal.com/gui/file/7386faface4217820cecd6d175a9353b)|Win64 DLL||2017-12-20 16:05:36|test.exe|
|[11effc4a094894e947314fe8e3d26ae1](https://www.virustotal.com/gui/file/11effc4a094894e947314fe8e3d26ae1)|Android||2017-12-13 11:51:57|App-debug.apk|
|[9ad07503c7ee5097ff1d6746a98b9832](https://www.virustotal.com/gui/file/9ad07503c7ee5097ff1d6746a98b9832)|Win32 DLL||2017-11-08 13:41:18|C:\Users\Roman\Google Диск\CurrentAnalysis\__1440\roman\reflective_mimi_32|
|[cf3d8ee38a1c04d552d8fb8b80454c68](https://www.virustotal.com/gui/file/cf3d8ee38a1c04d552d8fb8b80454c68)|DOC|Banload|2017-11-08 09:31:17|cf3d8ee38a1c04d552d8fb8b80454c68.virus|
|[1de684f66a87cdf8485f95693d188596](https://www.virustotal.com/gui/file/1de684f66a87cdf8485f95693d188596)|DOC||2017-11-07 14:49:52|1de684f66a87cdf8485f95693d188596.virus|
|[989e9dcc2182e2b5903b9acea03be11d](https://www.virustotal.com/gui/file/989e9dcc2182e2b5903b9acea03be11d)|Win32 EXE||2017-10-03 21:57:54|cr.exe|
|[46670174f1ef34f2f619cfda603acb3b](https://www.virustotal.com/gui/file/46670174f1ef34f2f619cfda603acb3b)|Text|rozena|2017-08-20 13:22:15|ash.ps1|
|[e2ed0be977ab9e50055337ec8eb0ddf4](https://www.virustotal.com/gui/file/e2ed0be977ab9e50055337ec8eb0ddf4)|Win32 EXE||2017-08-14 05:38:06|la.exe|
|[50a538062f2027b6ff763f23bc3d1545](https://www.virustotal.com/gui/file/50a538062f2027b6ff763f23bc3d1545)|Text||2014-07-26 23:26:00|50a538062f2027b6ff763f23bc3d1545|
|[e3a8839230acb9c253dd9673ae0b4103](https://www.virustotal.com/gui/file/e3a8839230acb9c253dd9673ae0b4103)|ZIP||2020-07-15 17:11:23|C:\Users\AhmadFathy\Documents\Shj Municipility\Malware\7166882e-5e97-4915-881e-65bc910a124b|
|[7c12a63096a6b157564dc912e62b2773](https://www.virustotal.com/gui/file/7c12a63096a6b157564dc912e62b2773)|Win32 DLL||2020-07-15 17:11:14|C:\Users\AhmadFathy\Documents\Shj Municipility\Malware\43c4e63e-9377-440d-8b86-6d6e95fead91|
|[8ee07f579a0e5cf4c3ec2a3b68602963](https://www.virustotal.com/gui/file/8ee07f579a0e5cf4c3ec2a3b68602963)|Win64 EXE||2020-05-25 06:53:36|chisel.exe|
|[e23b59dbaac4dfd72b7c6353b35c301a](https://www.virustotal.com/gui/file/e23b59dbaac4dfd72b7c6353b35c301a)|LNK||2020-04-14 11:51:41| |
|[a3ce175ac1ca36b8c23c79cb657f3680](https://www.virustotal.com/gui/file/a3ce175ac1ca36b8c23c79cb657f3680)|LNK||2020-04-14 10:00:51| |
|[911c78fb9c916c487889178d2e51fd91](https://www.virustotal.com/gui/file/911c78fb9c916c487889178d2e51fd91)|TXT||2020-04-14 09:28:54| |
|[46f911014f1202e17936f627f34e6165](https://www.virustotal.com/gui/file/46f911014f1202e17936f627f34e6165)|XLS|o97m|2019-09-06 09:21:46|148839e013fee10ee5007f80de2e169778739e84d1bbb093f69b56060ceef73f.bin|
|[34f759180146dcce3990e2c61677d949](https://www.virustotal.com/gui/file/34f759180146dcce3990e2c61677d949)|TXT||2019-06-27 13:04:59|p.txt|
|[1f738218a4da659f3d58ff4abaa4edd7](https://www.virustotal.com/gui/file/1f738218a4da659f3d58ff4abaa4edd7)|DOC|sLoad|2019-06-27 08:53:08|letter.doc|
|[3d25c5d2678c2b65fe7335bc73a5f4f2](https://www.virustotal.com/gui/file/3d25c5d2678c2b65fe7335bc73a5f4f2)|TXT||2019-06-26 01:52:06|New Text Document.bat|
|[06d4ad9f46c34bc455c526d10777a946](https://www.virustotal.com/gui/file/06d4ad9f46c34bc455c526d10777a946)|TXT||2019-04-17 01:19:41|dttcodexgigas.2a1acc4482e14a17cc7a34840ac7c6278b1b6899|
|[fc210d63b612f6e7ecce1cdb588bcb97](https://www.virustotal.com/gui/file/fc210d63b612f6e7ecce1cdb588bcb97)|Text||2018-06-17 19:12:17|ameer3.bat|
|[2e40b75c20b2d40dc820f90de437022c](https://www.virustotal.com/gui/file/2e40b75c20b2d40dc820f90de437022c)|Win64 EXE||2018-02-08 09:05:27|c4599f05a8d44bd315da646064adcf2c90886a705a071f0650ee6d17b739d5c8.exe|
|[0b37c62da0464c830a68598b865f45eb](https://www.virustotal.com/gui/file/0b37c62da0464c830a68598b865f45eb)|TXT||2016-04-26 10:32:49|Invoke-Mimikatz.ps1|
|[6983f7001de10f4d19fc2d794c3eb534](https://www.virustotal.com/gui/file/6983f7001de10f4d19fc2d794c3eb534)|Win32 EXE||2012-12-18 21:06:50|c:\windows\rkxcukva.exe|
|[d1ab72db2bedd2f255d35da3da0d4b16](https://www.virustotal.com/gui/file/d1ab72db2bedd2f255d35da3da0d4b16)|Win32 EXE||2009-11-20 15:32:57|wscript.exe|
