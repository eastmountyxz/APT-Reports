**NAME:**  
Orangeworm  

**Description**:   
Orangeworm, named by Symantec, targeted organizations in the healthcare sector in the United States, Europe, and Asia since at least 2015, likely to perform corporate espionage. Related custom backdoor is called Trojan.Kwampirs.
  
**References**:  
https://www.symantec.com/blogs/threat-intelligence/orangeworm-targets-healthcare-us-europe-asia