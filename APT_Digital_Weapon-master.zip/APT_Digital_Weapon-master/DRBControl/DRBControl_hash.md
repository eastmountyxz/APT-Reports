|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[2bdc1fc71bf3e2e4c6cf51b975607fea](https://www.virustotal.com/gui/file/2bdc1fc71bf3e2e4c6cf51b975607fea)|Win32 DLL||2020-02-13 01:54:04|mpsvc.dll|
|[1a979f60b267ad7337c4f7dcbb4eb8b3](https://www.virustotal.com/gui/file/1a979f60b267ad7337c4f7dcbb4eb8b3)|unknown|CobaltStrike|2020-01-21 07:43:42|payload.bin|
|[20f37bbdb2bfe32587b14481feb96c48](https://www.virustotal.com/gui/file/20f37bbdb2bfe32587b14481feb96c48)|Win64 EXE||2019-12-06 15:55:52| |
|[cc6ef3686a116435518319c1e42db2bc](https://www.virustotal.com/gui/file/cc6ef3686a116435518319c1e42db2bc)|Win32 EXE|Flystudio|2019-12-01 01:30:48|cc6ef3686a116435518319c1e42db2bc.virus|
|[67cfecf2d777f3a3ff1a09752f06a7f5](https://www.virustotal.com/gui/file/67cfecf2d777f3a3ff1a09752f06a7f5)|ZIP||2019-11-14 05:06:59|google.zip|
|[d57f226f2ffac348b4e743310926e518](https://www.virustotal.com/gui/file/d57f226f2ffac348b4e743310926e518)|Win32 EXE|Waldek|2019-09-14 00:20:22|d57f226f2ffac348b4e743310926e518.virus|
|[3867793b2a9b42810a8f7ee5e6f18ee6](https://www.virustotal.com/gui/file/3867793b2a9b42810a8f7ee5e6f18ee6)|Win32 EXE||2019-08-19 01:00:38|lsass.exe|
|[490401bd2b4b373dc89af14d65584c26](https://www.virustotal.com/gui/file/490401bd2b4b373dc89af14d65584c26)|Win32 EXE||2019-08-03 03:37:07|HaoZipUpdate|
|[7087050e8c738bf52357cbc69e4c2a30](https://www.virustotal.com/gui/file/7087050e8c738bf52357cbc69e4c2a30)|unknown||2019-07-30 09:24:59|mpsvc.mui|
|[eaad3c54c7ab268d44cd36dbf1c27cb3](https://www.virustotal.com/gui/file/eaad3c54c7ab268d44cd36dbf1c27cb3)|Win64 DLL||2019-07-30 09:24:33|%PROGRAMDATA%\s\mpsvc.dll|
|[976b022c7dca71e0e4f56b5405be1894](https://www.virustotal.com/gui/file/976b022c7dca71e0e4f56b5405be1894)|unknown||2019-07-30 07:39:03|English.rtf|
|[387c21ba850d0dcc3aa8efccc788b49b](https://www.virustotal.com/gui/file/387c21ba850d0dcc3aa8efccc788b49b)|DOCX|Skeeyah|2019-06-18 07:48:19|截图.docx|
|[6a57d1cdf2cf78376d7ad9f5450583f8](https://www.virustotal.com/gui/file/6a57d1cdf2cf78376d7ad9f5450583f8)|unknown||2019-06-17 20:15:59|license.rtf|
|[c4164efa57204ad32aec2b0f1a12bb3a](https://www.virustotal.com/gui/file/c4164efa57204ad32aec2b0f1a12bb3a)|Win32 DLL|Ursu|2019-06-17 12:14:46|C4164EFA57204AD32AEC2B0F1A12BB3A.mlw|
|[371109f34bfe0120f4a16f5304463cbf](https://www.virustotal.com/gui/file/371109f34bfe0120f4a16f5304463cbf)|ZIP|Ursu|2019-06-17 12:04:14|KB3023607.zip|
|[c1c9bcbbbcce2ae5116ce82aec4a6dc8](https://www.virustotal.com/gui/file/c1c9bcbbbcce2ae5116ce82aec4a6dc8)|DOCX||2019-05-26 07:15:47|screen.docx|
|[3a8d74bc002e1acae49a64f3f77aac0b](https://www.virustotal.com/gui/file/3a8d74bc002e1acae49a64f3f77aac0b)|Win32 EXE|Skeeyah|2019-05-24 14:12:56|HaoZipUpdate|
|[bc226657cf8768585fffbe057510d082](https://www.virustotal.com/gui/file/bc226657cf8768585fffbe057510d082)|DOCX||2019-05-24 13:31:48|%E6%88%AA%E5%9B%BE.docx|
|[25ccaff20702c318062741e3afc00526](https://www.virustotal.com/gui/file/25ccaff20702c318062741e3afc00526)|DOCX|sLoad|2019-05-17 13:04:46|Pic.docx|
|[a0b23184394d2d931b12270341e689b3](https://www.virustotal.com/gui/file/a0b23184394d2d931b12270341e689b3)|unknown|Flystudio|2019-02-06 20:37:58| |
|[517882a348924dfa92e0dc6c5d1e525a](https://www.virustotal.com/gui/file/517882a348924dfa92e0dc6c5d1e525a)|Win32 EXE|occamy|2019-01-17 16:29:34|svchost.e|
|[5a6b3d1dcfec36af9607140f2867b819](https://www.virustotal.com/gui/file/5a6b3d1dcfec36af9607140f2867b819)|unknown|PlugX|2018-11-19 01:41:56|%ALLUSERSPROFILE%\medialoader\data.dat|
|[07d3ed362707585713f3dd183250da9e](https://www.virustotal.com/gui/file/07d3ed362707585713f3dd183250da9e)|Win32 EXE||2018-11-17 17:05:03|diskshawin.exe|
|[819438751867f2e52b4d587c6117e9d3](https://www.virustotal.com/gui/file/819438751867f2e52b4d587c6117e9d3)|Win32 DLL|PlugX|2018-09-25 13:10:55|rpcss.dll|
|[00afd74e51363f9ec4f3fef602b20578](https://www.virustotal.com/gui/file/00afd74e51363f9ec4f3fef602b20578)|Win32 EXE||2018-09-24 20:28:59|setup443.exe|
|[cdb176a97dce1b42af9e1d1c04506586](https://www.virustotal.com/gui/file/cdb176a97dce1b42af9e1d1c04506586)|Win64 DLL||2018-08-19 05:32:13|mpsvc.dll|
|[f267e9b788eb1ffa509d0d88e0c0cecc](https://www.virustotal.com/gui/file/f267e9b788eb1ffa509d0d88e0c0cecc)|Win32 EXE||2017-12-16 22:49:10|server.exe|
|[2a95062d862430242e2d19ca88a179df](https://www.virustotal.com/gui/file/2a95062d862430242e2d19ca88a179df)|DOCX||2017-09-13 10:17:27|f303b818bb53e5e1e5ad096ec7085c0d304ce94e|
|[aa4f7e8e45915a9f55a8b61604758ba3](https://www.virustotal.com/gui/file/aa4f7e8e45915a9f55a8b61604758ba3)|unknown||2017-05-04 02:48:56|English.rtf|
|[8d37de13f32a5ddfaf97311dadb5f2df](https://www.virustotal.com/gui/file/8d37de13f32a5ddfaf97311dadb5f2df)|CAB||2017-05-03 14:40:45|/var/www/clean-mx/virusesevidence/output.121888854.txt|
|[36b33c0cf94dacf7cee5b9a8143098d1](https://www.virustotal.com/gui/file/36b33c0cf94dacf7cee5b9a8143098d1)|Win32 DLL|Ursu|2016-11-24 06:12:50|%PROGRAMDATA%\googlesrv\goopdate.dll|
|[36d99c1b915544c1bc9110b22e884acb](https://www.virustotal.com/gui/file/36d99c1b915544c1bc9110b22e884acb)|Win32 EXE|dynamer|2016-09-15 10:42:20|%TEMP%\bypass.exe|
|[d76e1525c8998795867a17ed33573552](https://www.virustotal.com/gui/file/d76e1525c8998795867a17ed33573552)|Win32 EXE||2015-09-17 05:04:18|/1.exe|
|[ce996c1821021adf8e28e80a54e846a8](https://www.virustotal.com/gui/file/ce996c1821021adf8e28e80a54e846a8)|Win64 EXE||2015-05-12 19:01:01|c:\Program Files\Microsoft Security Client\MsMpEng.exe|
|[8cc83221870dd07144e63df594c391d9](https://www.virustotal.com/gui/file/8cc83221870dd07144e63df594c391d9)|Win32 EXE||2014-05-14 04:37:37|MsMpEng.exe|
|[a62a5f26216c2bd6643e030caca58be7](https://www.virustotal.com/gui/file/a62a5f26216c2bd6643e030caca58be7)|Win32 DLL||2014-02-05 05:00:19|sysprep.EXE|
