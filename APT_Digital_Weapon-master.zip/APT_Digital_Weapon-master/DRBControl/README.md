**NAME:**  
DRBControl

  
**Description**:   
Operation DRBControl, discovered by Trend Micro, is a cyberespionage campaign targeting gambling companies in Southeast Asia. It has several relations to well-known Winnti and Emissary Panda APT groups.

  
**References**:  
https://www.trendmicro.com/vinfo/us/security/news/cyber-attacks/operation-drbcontrol-uncovering-a-cyberespionage-campaign-targeting-gambling-companies-in-southeast-asia