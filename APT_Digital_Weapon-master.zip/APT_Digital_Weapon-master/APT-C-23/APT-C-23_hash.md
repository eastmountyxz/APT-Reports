|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[f65e5bb6e35a3e28c2c878824293d939](https://www.virustotal.com/gui/file/f65e5bb6e35a3e28c2c878824293d939)|Win32 EXE|Delf|2019-07-14 21:04:25|music-14072019-2-473575936542-34728623-mp3.exe|
|[ddf69fdd195deaca359d223f3ba90153](https://www.virustotal.com/gui/file/ddf69fdd195deaca359d223f3ba90153)|RAR|Delf|2019-07-14 16:15:11|music love.xz|
|[57a2f9250b07844f444e9bce8b3a75e3](https://www.virustotal.com/gui/file/57a2f9250b07844f444e9bce8b3a75e3)|ZIP|Delf|2019-07-14 09:36:24|music%20love.zip|
|[8b48cec7cb30ff0f02b06c51aa15f24f](https://www.virustotal.com/gui/file/8b48cec7cb30ff0f02b06c51aa15f24f)|Android||2019-03-19 12:35:43|Upgrade.apk|
|[f5a5a440afa5132ad9ce723ed73cb1c5](https://www.virustotal.com/gui/file/f5a5a440afa5132ad9ce723ed73cb1c5)|Win32 EXE|Delf|2019-02-11 11:40:21|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APTC23/AnnualReportFeb.bin|
|[e121531a15f2eaa34dce89f3fec70cfd](https://www.virustotal.com/gui/file/e121531a15f2eaa34dce89f3fec70cfd)|Win32 EXE|Delf|2018-11-07 13:23:48|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APTC23/HexDownload.exe.bin|
|[6eff53e85a9ce9f1d99c812270093581](https://www.virustotal.com/gui/file/6eff53e85a9ce9f1d99c812270093581)|Win32 EXE|Delf|2018-10-22 22:57:50|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APTC23/MicropsiaRAT2018.bin|
|[9b40a4dabff639125a19599cca941ea1](https://www.virustotal.com/gui/file/9b40a4dabff639125a19599cca941ea1)|Android|androidos|2018-08-13 06:47:35|5dd46064501235c0d02ae9155d6d5f0b526703a8244da5d8299f590b427a3c2e.apk|
|[c95fe8de4dd4c770a61e5361898322e8](https://www.virustotal.com/gui/file/c95fe8de4dd4c770a61e5361898322e8)|Android||2018-08-10 21:13:41|3azqs8Bbuw-RR-WfLGnZ20180812-11568-pg8wfj|
|[183ec3f5e014f2eaebbdca1e94b5b946](https://www.virustotal.com/gui/file/183ec3f5e014f2eaebbdca1e94b5b946)|Android||2018-08-10 20:28:48|zFUWAe87M9sot9qUiV4x20180812-11549-1tn69f1|
|[2a2175eb4ecf720ba7cb62af1cb6cc9a](https://www.virustotal.com/gui/file/2a2175eb4ecf720ba7cb62af1cb6cc9a)|Android||2018-08-10 20:13:11|-ghyZVZvx7EVVR-kx1QJ20180812-27158-1v71lmc|
|[0bb965ca6a122ce124cd6905494e1aea](https://www.virustotal.com/gui/file/0bb965ca6a122ce124cd6905494e1aea)|Android||2018-08-10 19:59:12|RBurqSB4WWcV9PjPgKr520180812-7424-1aeflxr|
|[f1933220de03dbce36daabda0f75efa8](https://www.virustotal.com/gui/file/f1933220de03dbce36daabda0f75efa8)|Android||2018-08-10 13:21:27|f1933220de03dbce36daabda0f75efa8.apk|
|[f9f6155ca91b3d444095051cb344f9b1](https://www.virustotal.com/gui/file/f9f6155ca91b3d444095051cb344f9b1)|Android||2018-08-10 13:17:11|Z7vnaXgrCzWzkyhxqm-o20180812-10864-1ipqiua|
|[62786d8387ab005ad0c47ea0e397a68b](https://www.virustotal.com/gui/file/62786d8387ab005ad0c47ea0e397a68b)|Android||2018-08-10 13:08:29|Dm7BY3YH1B_Jn4E-7rPW20180812-20514-uiwmz6|
|[16619b1c34c1f44ec12dbe68c366ffb5](https://www.virustotal.com/gui/file/16619b1c34c1f44ec12dbe68c366ffb5)|Android||2018-08-10 13:05:06|t2myJyh7SZEZCBhkkpy-20180812-30209-188xas1|
|[9fed5deaedec3f7aa82f08f12c93b63f](https://www.virustotal.com/gui/file/9fed5deaedec3f7aa82f08f12c93b63f)|Android|androidos|2018-08-10 12:19:50|ssrmUthiu63bzswyb8JH20180812-11623-pq3vet|
|[0d482c58049c5e930b9a844f4a5f84d4](https://www.virustotal.com/gui/file/0d482c58049c5e930b9a844f4a5f84d4)|Android||2018-08-10 12:09:17|0d482c58049c5e930b9a844f4a5f84d4.apk|
|[738b3370230bd3168a97a7171d17ed64](https://www.virustotal.com/gui/file/738b3370230bd3168a97a7171d17ed64)|Win32 EXE||2018-07-17 11:52:53|SearchProtocolHost.exe|
|[2c30676af207b3bbb81af097cfd94e88](https://www.virustotal.com/gui/file/2c30676af207b3bbb81af097cfd94e88)|Android|androidos|2018-07-09 14:12:43|BSDYPGkF28gXZiWVQ2fb20180801-26096-xzjwj|
|[20d460df4ea1f3d3f4671595812d70ee](https://www.virustotal.com/gui/file/20d460df4ea1f3d3f4671595812d70ee)|Android||2018-07-05 09:11:23|WhatsApp_Update (1).apk|
|[af0eeb210cdb22579166928f8a57bfc3](https://www.virustotal.com/gui/file/af0eeb210cdb22579166928f8a57bfc3)|Win32 EXE||2018-06-18 09:46:16|af0eeb210cdb22579166928f8a57bfc3.virus|
|[b144fc9e80ea1c835a46442972c69593](https://www.virustotal.com/gui/file/b144fc9e80ea1c835a46442972c69593)|Android||2018-06-13 11:36:33| |
|[4a3a4f53b464383b83d9a29a0d41f632](https://www.virustotal.com/gui/file/4a3a4f53b464383b83d9a29a0d41f632)|Android||2018-06-13 10:51:18| |
|[b7dc0bc679a3dc342fb00a29b1c02966](https://www.virustotal.com/gui/file/b7dc0bc679a3dc342fb00a29b1c02966)|Android||2018-06-11 23:34:12| |
|[4fda51cd2228057d2325f1a47c9c1079](https://www.virustotal.com/gui/file/4fda51cd2228057d2325f1a47c9c1079)|Android||2018-06-11 23:12:09| |
|[88f0568f5c3dc15894ccf74860aaf316](https://www.virustotal.com/gui/file/88f0568f5c3dc15894ccf74860aaf316)|Win32 EXE||2018-06-11 20:46:30|88f0568f5c3dc15894ccf74860aaf316.virus|
|[fd49128e46d226d70ef3729bd228d6c4](https://www.virustotal.com/gui/file/fd49128e46d226d70ef3729bd228d6c4)|Android||2018-06-11 18:55:04| |
|[e5fa0f05720b726b1e88b1943b2ca202](https://www.virustotal.com/gui/file/e5fa0f05720b726b1e88b1943b2ca202)|Android||2018-06-11 14:18:59| |
|[11d5e083edb22a3d0f7537732d1b1a53](https://www.virustotal.com/gui/file/11d5e083edb22a3d0f7537732d1b1a53)|Android|bitrep|2018-06-11 11:10:15| |
|[29c1a710d0a0669aba6bc3660ed5e667](https://www.virustotal.com/gui/file/29c1a710d0a0669aba6bc3660ed5e667)|Android||2018-06-11 10:54:56| |
|[810a7b41656a0583f564def062ce2695](https://www.virustotal.com/gui/file/810a7b41656a0583f564def062ce2695)|Android||2018-06-11 06:12:09| |
|[137a5accfff9b62d886b031e2bf9223b](https://www.virustotal.com/gui/file/137a5accfff9b62d886b031e2bf9223b)|Android||2018-06-11 06:11:04| |
|[dcc9485edfffa64d78789403d81992c1](https://www.virustotal.com/gui/file/dcc9485edfffa64d78789403d81992c1)|Android||2018-06-11 03:36:02| |
|[50f08051149b31c23262a4014c1c3ca5](https://www.virustotal.com/gui/file/50f08051149b31c23262a4014c1c3ca5)|Android||2018-06-10 20:35:00| |
|[54753ae15f8b550f1fa540ccbc0408a7](https://www.virustotal.com/gui/file/54753ae15f8b550f1fa540ccbc0408a7)|Android|bitrep|2018-06-10 20:16:11|qBAkXufk7YNG9mDYzzMs20180807-29593-1c4erw4|
|[21ad6eed6cc52a723f51fc425035067b](https://www.virustotal.com/gui/file/21ad6eed6cc52a723f51fc425035067b)|Android||2018-06-10 19:44:15| |
|[26ca0e3b4f7f435793a466ff0ccbaa45](https://www.virustotal.com/gui/file/26ca0e3b4f7f435793a466ff0ccbaa45)|Android||2018-06-10 16:46:40| |
|[de199f48f056d8f2a925f3a27de6b5bd](https://www.virustotal.com/gui/file/de199f48f056d8f2a925f3a27de6b5bd)|Android|bitrep|2018-06-07 08:46:46| |
|[05443e9ad15eda809117c88d9e85caa1](https://www.virustotal.com/gui/file/05443e9ad15eda809117c88d9e85caa1)|Android||2018-06-07 08:20:44| |
|[35c3aef1347d629bf4e03b34b48a510d](https://www.virustotal.com/gui/file/35c3aef1347d629bf4e03b34b48a510d)|Android||2018-06-06 06:50:39| |
|[c5ba37c70cb2ab1d6a51a75b9c1448e3](https://www.virustotal.com/gui/file/c5ba37c70cb2ab1d6a51a75b9c1448e3)|Android||2018-06-06 06:35:54| |
|[e5421878b39b03b6bdab730d5938a97c](https://www.virustotal.com/gui/file/e5421878b39b03b6bdab730d5938a97c)|Android||2018-06-05 20:21:06| |
|[6a43d50d0f8e57877e4578858fb753a0](https://www.virustotal.com/gui/file/6a43d50d0f8e57877e4578858fb753a0)|Android||2018-06-05 19:53:21| |
|[0e569e38563a0244e1118d972938e7c7](https://www.virustotal.com/gui/file/0e569e38563a0244e1118d972938e7c7)|Android|bitrep|2018-06-05 18:32:38|b6abeffe986eb38e411a4fe956280e2028d8bef699d9dd3244bde721a99b1dee.zip|
|[10a9dc21e97be61e93088a746fab52a6](https://www.virustotal.com/gui/file/10a9dc21e97be61e93088a746fab52a6)|Android||2018-06-05 18:30:56|5f3b4eddcc72598721b9ca395d1e5881acbd4fc562e09b688b2d42f65d3a4a93.zip|
|[c71e240d12be3ef64d0ad85c715aa490](https://www.virustotal.com/gui/file/c71e240d12be3ef64d0ad85c715aa490)|Android|bitrep|2018-06-02 06:37:19|Tetegram Installer7.3.1.apk|
|[9dcc05e3a855fd9fdef790801039c09c](https://www.virustotal.com/gui/file/9dcc05e3a855fd9fdef790801039c09c)|Android||2018-06-02 06:29:45|wh_update.apk|
|[28fa66f42c6216fe7c628d3d589db114](https://www.virustotal.com/gui/file/28fa66f42c6216fe7c628d3d589db114)|Win32 EXE||2018-05-28 09:24:50|28fa66f42c6216fe7c628d3d589db114.virus|
|[5ae06be54ea7911cad447523002144e7](https://www.virustotal.com/gui/file/5ae06be54ea7911cad447523002144e7)|Win32 EXE||2018-05-15 15:49:43|5ae06be54ea7911cad447523002144e7.virus|
|[83c7f971ffae27e01f12704fb43d5c04](https://www.virustotal.com/gui/file/83c7f971ffae27e01f12704fb43d5c04)|Android||2018-04-25 23:54:51| |
|[fd8c8ae6a261b0e88df06236c5b70be6](https://www.virustotal.com/gui/file/fd8c8ae6a261b0e88df06236c5b70be6)|Win32 EXE|razy|2018-04-22 04:26:15|Interenet Assistant.exe|
|[3b33d2b36990a7a4519a1c1ea127cc15](https://www.virustotal.com/gui/file/3b33d2b36990a7a4519a1c1ea127cc15)|Android||2018-04-21 00:56:13|3b33d2b36990a7a4519a1c1ea127cc15.virus|
|[81881a0841deaa0ef1ea92c51d8c8845](https://www.virustotal.com/gui/file/81881a0841deaa0ef1ea92c51d8c8845)|Win32 EXE||2018-04-20 04:19:07|Win Graphic Driver.exe|
|[a3dc31c456508df7dfac8349eb0d2b65](https://www.virustotal.com/gui/file/a3dc31c456508df7dfac8349eb0d2b65)|DOC||2018-04-18 08:47:09|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/TheBigBangAPT.doc|
|[18864d22331fc6503641f128226aaea8](https://www.virustotal.com/gui/file/18864d22331fc6503641f128226aaea8)|Win32 EXE||2018-04-17 09:50:44|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/GazaAPTGroup/ImplantBigBang.bin|
|[2f8face85084bea8adacac36ee2f641f](https://www.virustotal.com/gui/file/2f8face85084bea8adacac36ee2f641f)|Win32 EXE||2018-04-17 09:48:54|التقرير الإعلامي الشهري.exe|
|[c7173b137cfdcedc21ea424b66691a57](https://www.virustotal.com/gui/file/c7173b137cfdcedc21ea424b66691a57)|Android||2018-04-17 03:32:39|c7173b137cfdcedc21ea424b66691a57.virus|
|[e1de374f37a85ef6e9f46aed612bf1b8](https://www.virustotal.com/gui/file/e1de374f37a85ef6e9f46aed612bf1b8)|Android||2018-04-17 03:32:24|e1de374f37a85ef6e9f46aed612bf1b8.virus|
|[69fb0491a4e5fb459005e79b26f121a4](https://www.virustotal.com/gui/file/69fb0491a4e5fb459005e79b26f121a4)|Android||2018-03-30 17:41:25|69fb0491a4e5fb459005e79b26f121a4.virus|
|[eb655395e12db9ce0aa75b7892bcfd8a](https://www.virustotal.com/gui/file/eb655395e12db9ce0aa75b7892bcfd8a)|Android||2018-03-17 16:19:08|VirusShare_eb655395e12db9ce0aa75b7892bcfd8a|
|[667230ef2ea63a338dfe8db6a3fb12cc](https://www.virustotal.com/gui/file/667230ef2ea63a338dfe8db6a3fb12cc)|Android|androidos|2018-03-17 10:03:33|667230ef2ea63a338dfe8db6a3fb12cc.virus|
|[5cdec47f1ce3bd76853c78e403dcbc5b](https://www.virustotal.com/gui/file/5cdec47f1ce3bd76853c78e403dcbc5b)|Android||2018-03-16 17:10:55|5cdec47f1ce3bd76853c78e403dcbc5b.virus|
|[b0984e189c1af81d3288e28936ff0a82](https://www.virustotal.com/gui/file/b0984e189c1af81d3288e28936ff0a82)|Android||2018-03-05 12:50:19|b0984e189c1af81d3288e28936ff0a82.virus|
|[4f803a88b518d75d08ce65bb7a9818e3](https://www.virustotal.com/gui/file/4f803a88b518d75d08ce65bb7a9818e3)|Android||2018-03-01 20:03:52|4f803a88b518d75d08ce65bb7a9818e3|
|[789c0cb1d2cdabcb5538683b58374881](https://www.virustotal.com/gui/file/789c0cb1d2cdabcb5538683b58374881)|Win32 EXE||2018-02-27 18:00:57|789c0cb1d2cdabcb5538683b58374881.virus|
|[5e494e94053b73d01b20d48f8d8e0758](https://www.virustotal.com/gui/file/5e494e94053b73d01b20d48f8d8e0758)|Win32 EXE|Banload|2018-02-19 14:24:59|vlc|
|[b9165bad0c4ce343e015ed844268271f](https://www.virustotal.com/gui/file/b9165bad0c4ce343e015ed844268271f)|Android||2018-02-13 20:22:33|b9165bad0c4ce343e015ed844268271f.virus|
|[172a0c3086da7d98c6084fb7fe8e800d](https://www.virustotal.com/gui/file/172a0c3086da7d98c6084fb7fe8e800d)|Android||2018-02-12 23:21:02|172a0c3086da7d98c6084fb7fe8e800d.virus|
|[24a35852d72a2a8eac1b5d3582b04c54](https://www.virustotal.com/gui/file/24a35852d72a2a8eac1b5d3582b04c54)|Android||2018-02-12 06:07:15|24a35852d72a2a8eac1b5d3582b04c54.virus|
|[4101b87b1e30e52282768ce5c1b82a90](https://www.virustotal.com/gui/file/4101b87b1e30e52282768ce5c1b82a90)|Android||2018-02-11 08:50:40|99631c8fb08da1387ddd8b16318ce9669ca9e29c|
|[25c2e3b2ed107f0682875a4f4d0cbd80](https://www.virustotal.com/gui/file/25c2e3b2ed107f0682875a4f4d0cbd80)|Android||2018-01-31 20:46:12|25c2e3b2ed107f0682875a4f4d0cbd80.virus|
|[e3246b90334c641ce6e34b53f6602a02](https://www.virustotal.com/gui/file/e3246b90334c641ce6e34b53f6602a02)|Android||2018-01-25 09:22:07|e3246b90334c641ce6e34b53f6602a02.virus|
|[664fbc697b374ddaf02de0de31109929](https://www.virustotal.com/gui/file/664fbc697b374ddaf02de0de31109929)|Android||2018-01-19 12:55:27|NS7M9crjgSZbKU-msTm620180807-29139-cn9noz|
|[afcf567d10cc3fe5b6963dbcd5a3e111](https://www.virustotal.com/gui/file/afcf567d10cc3fe5b6963dbcd5a3e111)|Android||2018-01-17 09:03:03|afcf567d10cc3fe5b6963dbcd5a3e111.virus|
|[d5003f979ebdf97695cf755427c1fb25](https://www.virustotal.com/gui/file/d5003f979ebdf97695cf755427c1fb25)|Android||2018-01-16 22:21:02|/home/ubuntu/site_disks/jsa.live/files/13271297.apk|
|[ea123702bcd889f358f52a5df288ac96](https://www.virustotal.com/gui/file/ea123702bcd889f358f52a5df288ac96)|Android||2018-01-10 11:16:01|ea123702bcd889f358f52a5df288ac96.virus|
|[880010844a226d8b586bdad423cd424c](https://www.virustotal.com/gui/file/880010844a226d8b586bdad423cd424c)|Android||2018-01-10 07:36:27|880010844a226d8b586bdad423cd424c.virus|
|[f8e754d791edbafc760510bf30012b0b](https://www.virustotal.com/gui/file/f8e754d791edbafc760510bf30012b0b)|Android||2018-01-07 13:02:19|/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/i0ld028a85sg9it3bj92d1hbtkq7qenq/1515326400000/07674850865767386831/*/0B97LrzGnTM61SW1GT1pnSC1LWWs|
|[0db81370c3ff514a8a93c54d992bf10a](https://www.virustotal.com/gui/file/0db81370c3ff514a8a93c54d992bf10a)|Android||2018-01-05 12:11:49|0db81370c3ff514a8a93c54d992bf10a.virus|
|[d3b5204d71327eb9558354936a03d27f](https://www.virustotal.com/gui/file/d3b5204d71327eb9558354936a03d27f)|Android||2018-01-05 00:20:42|d3b5204d71327eb9558354936a03d27f.virus|
|[7441c35b4c3038ea7c6b22324e48c2da](https://www.virustotal.com/gui/file/7441c35b4c3038ea7c6b22324e48c2da)|Android||2018-01-03 17:07:55|7441c35b4c3038ea7c6b22324e48c2da.virus|
|[52f877007be5197d2c857894d53d9176](https://www.virustotal.com/gui/file/52f877007be5197d2c857894d53d9176)|Android|androidos|2017-12-30 23:57:40|52f877007be5197d2c857894d53d9176.virus|
|[f1a64d507515449a06ff9f267ae1042e](https://www.virustotal.com/gui/file/f1a64d507515449a06ff9f267ae1042e)|Android||2017-12-29 19:42:09|/home/ubuntu/site_disks/jsa.live/files/16186417.apk|
|[f6f1553efea628435108abeba25ce321](https://www.virustotal.com/gui/file/f6f1553efea628435108abeba25ce321)|Android||2017-12-26 09:56:39|f6f1553efea628435108abeba25ce321.virus|
|[7b0196dbb918af22d5585dea6fd339b0](https://www.virustotal.com/gui/file/7b0196dbb918af22d5585dea6fd339b0)|Android|bitrep|2017-12-26 07:44:21|7b0196dbb918af22d5585dea6fd339b0.virus|
|[2a3f9c87aae0658a19069a8d6481008d](https://www.virustotal.com/gui/file/2a3f9c87aae0658a19069a8d6481008d)|Android|bitrep|2017-12-19 00:25:20|2a3f9c87aae0658a19069a8d6481008d.virus|
|[f57e1ba3e3b759301ce3a8287b57a75d](https://www.virustotal.com/gui/file/f57e1ba3e3b759301ce3a8287b57a75d)|Android||2017-12-18 11:02:52|f57e1ba3e3b759301ce3a8287b57a75d.virus|
|[92f2c86cf9942f8d390fbc90d4686c41](https://www.virustotal.com/gui/file/92f2c86cf9942f8d390fbc90d4686c41)|Android||2017-12-16 19:21:49|1024-d5c0fba9a66eb5558b82ba10a9785434dcb9c9e6|
|[f9de98d1825095ea49135212c1d8b016](https://www.virustotal.com/gui/file/f9de98d1825095ea49135212c1d8b016)|Android|androidos|2017-12-12 04:02:15|f9de98d1825095ea49135212c1d8b016.virus|
|[26540ae6018a924d43a1cc0b5fb7f807](https://www.virustotal.com/gui/file/26540ae6018a924d43a1cc0b5fb7f807)|Android|androidos|2017-12-08 19:08:32|26540ae6018a924d43a1cc0b5fb7f807.virus|
|[e8dfa1a7cf756b9dbe864ef1df6e8706](https://www.virustotal.com/gui/file/e8dfa1a7cf756b9dbe864ef1df6e8706)|Android|androidos|2017-12-04 12:44:27|e8dfa1a7cf756b9dbe864ef1df6e8706.virus|
|[9cedeae7cc5c71dad5f8f2a303efa3a1](https://www.virustotal.com/gui/file/9cedeae7cc5c71dad5f8f2a303efa3a1)|Android|androidos|2017-12-02 20:13:58|9cedeae7cc5c71dad5f8f2a303efa3a1.virus|
|[9c6a604203d35002458fde61e4adf724](https://www.virustotal.com/gui/file/9c6a604203d35002458fde61e4adf724)|Android||2017-11-28 16:58:51|9c6a604203d35002458fde61e4adf724.virus|
|[2e57f58f13c3a4ebe2b3b26b38708516](https://www.virustotal.com/gui/file/2e57f58f13c3a4ebe2b3b26b38708516)|Android||2017-11-25 20:23:29|2e57f58f13c3a4ebe2b3b26b38708516.virus|
|[cb7779635de27e920fdc2a7ce7a30477](https://www.virustotal.com/gui/file/cb7779635de27e920fdc2a7ce7a30477)|Android|androidos|2017-11-25 17:14:06|cb7779635de27e920fdc2a7ce7a30477.virus|
|[24908a1b942acd533030bd51629006a9](https://www.virustotal.com/gui/file/24908a1b942acd533030bd51629006a9)|Android||2017-10-30 23:22:59|24908a1b942acd533030bd51629006a9.virus|
|[c89b74b8e4ffa1e84f8f291f50745adc](https://www.virustotal.com/gui/file/c89b74b8e4ffa1e84f8f291f50745adc)|Android||2017-10-28 02:38:53|c89b74b8e4ffa1e84f8f291f50745adc.virus|
|[a4f3bdbb33de033c39b80cc693261db4](https://www.virustotal.com/gui/file/a4f3bdbb33de033c39b80cc693261db4)|Android||2017-10-25 19:37:59|a4f3bdbb33de033c39b80cc693261db4.virus|
|[f5771a3ade8d34af023c3e74f7a58e5f](https://www.virustotal.com/gui/file/f5771a3ade8d34af023c3e74f7a58e5f)|Android||2017-10-21 18:27:41|f5771a3ade8d34af023c3e74f7a58e5f.virus|
|[9aceb002e71b7a15bded15f18c07267b](https://www.virustotal.com/gui/file/9aceb002e71b7a15bded15f18c07267b)|Android||2017-10-14 08:41:25|9aceb002e71b7a15bded15f18c07267b.virus|
|[caba5fdb21cff3b63ed76f440d4cbbe7](https://www.virustotal.com/gui/file/caba5fdb21cff3b63ed76f440d4cbbe7)|Android||2017-10-09 16:06:34|caba5fdb21cff3b63ed76f440d4cbbe7.virus|
|[b369b38fbaae41484300856b8d2a1544](https://www.virustotal.com/gui/file/b369b38fbaae41484300856b8d2a1544)|Android||2017-09-20 21:34:45|MeetCam.apk|
|[21d984fdf4b503edd325ed01d4c25320](https://www.virustotal.com/gui/file/21d984fdf4b503edd325ed01d4c25320)|Android||2017-09-20 21:31:11|MEET.apk|
|[15dca70d17ca9e146362784a81217032](https://www.virustotal.com/gui/file/15dca70d17ca9e146362784a81217032)|Android||2017-09-15 07:53:05|15dca70d17ca9e146362784a81217032.virus|
|[bad78190170b5ed204702fda8f17eb5a](https://www.virustotal.com/gui/file/bad78190170b5ed204702fda8f17eb5a)|Android||2017-09-14 07:45:15|bad78190170b5ed204702fda8f17eb5a.virus|
|[557fdf84855510862e479d84d156b2fd](https://www.virustotal.com/gui/file/557fdf84855510862e479d84d156b2fd)|Android||2017-09-03 22:36:28|557fdf84855510862e479d84d156b2fd.virus|
|[82e6e64f0f7265fcc69b9a834e0e41de](https://www.virustotal.com/gui/file/82e6e64f0f7265fcc69b9a834e0e41de)|Android||2017-08-14 16:17:04|82e6e64f0f7265fcc69b9a834e0e41de.virus|
|[b2c7ff62da02bbc61936f67104c4da35](https://www.virustotal.com/gui/file/b2c7ff62da02bbc61936f67104c4da35)|Android||2017-08-08 10:26:29|b2c7ff62da02bbc61936f67104c4da35.virus|
|[a7ccd77302da4143c7c4ec5e18246c99](https://www.virustotal.com/gui/file/a7ccd77302da4143c7c4ec5e18246c99)|Android||2017-08-07 06:49:53|/home/spot/Desktop/ELMDetection/ClusterEnsemble2/VirusTotalGooglePlay/Malware/cf2d7545b1f5ec57142727f795e07e85b84cbfe9a8b9f75aa5219495c746d853|
|[0f2dfdc4f12b7b739a9f156fc46ceb8a](https://www.virustotal.com/gui/file/0f2dfdc4f12b7b739a9f156fc46ceb8a)|Android||2017-08-03 00:16:25|/8n5nukq9x6cg/bxlijc2ado3ap33/best_chat-.apk|
|[53847984ba6f31971e5848b75fdd9bc0](https://www.virustotal.com/gui/file/53847984ba6f31971e5848b75fdd9bc0)|Android||2017-07-31 20:10:22|53847984ba6f31971e5848b75fdd9bc0.virus|
|[baf4bbe7733c64392dd568236bd45ce3](https://www.virustotal.com/gui/file/baf4bbe7733c64392dd568236bd45ce3)|Android||2017-07-25 20:16:48|baf4bbe7733c64392dd568236bd45ce3.virus|
|[e0c12821f1573f143cf93137f655d08e](https://www.virustotal.com/gui/file/e0c12821f1573f143cf93137f655d08e)|Android||2017-07-11 13:06:48|e0c12821f1573f143cf93137f655d08e.virus|
|[c5eb82e759a4bc6b4a586a7b23cc8925](https://www.virustotal.com/gui/file/c5eb82e759a4bc6b4a586a7b23cc8925)|Android||2017-07-06 11:28:44|c5eb82e759a4bc6b4a586a7b23cc8925.virus|
|[b76a8428cb7b9d7aa4390e1f61e99bf9](https://www.virustotal.com/gui/file/b76a8428cb7b9d7aa4390e1f61e99bf9)|Android||2017-07-02 03:12:58|/home/spot/Desktop/2ndCodeGraphsExtension/Obfuscation/MalwareApks/46976081c1bcec4daa9701fbe373010c0bcb17463359a91556f09339522b6a13|
|[21b1bbe19fc1df71027aa3b14f956679](https://www.virustotal.com/gui/file/21b1bbe19fc1df71027aa3b14f956679)|Android||2017-06-06 18:35:57|21b1bbe19fc1df71027aa3b14f956679.virus|
|[ea67a4a35930cfa8a3fd663e265fd991](https://www.virustotal.com/gui/file/ea67a4a35930cfa8a3fd663e265fd991)|Android||2017-06-02 14:35:31|ea67a4a35930cfa8a3fd663e265fd991.virus|
|[6afc698831f534f0cbf6798b172d9451](https://www.virustotal.com/gui/file/6afc698831f534f0cbf6798b172d9451)|Android||2017-05-31 02:20:37|6afc698831f534f0cbf6798b172d9451.virus|
|[afca5f94700a83924944f1683092ce42](https://www.virustotal.com/gui/file/afca5f94700a83924944f1683092ce42)|Android||2017-05-31 02:20:34|afca5f94700a83924944f1683092ce42.virus|
|[cf2263b6f9a0d0ffc7b773ebd9b43a4e](https://www.virustotal.com/gui/file/cf2263b6f9a0d0ffc7b773ebd9b43a4e)|Android||2017-05-29 09:48:20|update facebook.apk|
|[2e2c74bb56577b68c2f3c0b61f7cc891](https://www.virustotal.com/gui/file/2e2c74bb56577b68c2f3c0b61f7cc891)|Android||2017-05-26 01:07:56|updatefacebook.apk|
|[466915777eb3e0b57021188532f3eeb7](https://www.virustotal.com/gui/file/466915777eb3e0b57021188532f3eeb7)|Android||2017-05-25 20:05:11|update facebook.apk|
|[1d9e31787d6eb88d95f2c6a0cbe60ba3](https://www.virustotal.com/gui/file/1d9e31787d6eb88d95f2c6a0cbe60ba3)|Android||2017-05-25 19:00:22|update facebook.apk|
|[5ac1a4d07ea0e7dd1b1e0d777a5a304c](https://www.virustotal.com/gui/file/5ac1a4d07ea0e7dd1b1e0d777a5a304c)|Android||2017-05-25 18:13:49|update_facebook.apk|
|[d8f4966cb08fdcf628bd0a5af76d75d0](https://www.virustotal.com/gui/file/d8f4966cb08fdcf628bd0a5af76d75d0)|Android||2017-05-24 12:19:49|/1/4/e/4ebb385b0bf460d8561c39af8b69144bfe8c7a4d8607b157784674de653b9a05.file|
|[c1e6ef4ccce494546c1810f8894439c0](https://www.virustotal.com/gui/file/c1e6ef4ccce494546c1810f8894439c0)|Android|androidos|2017-05-16 20:03:58|gnat|
|[457e0a16b1b544ada28f08b92c1c518f](https://www.virustotal.com/gui/file/457e0a16b1b544ada28f08b92c1c518f)|Android||2017-04-27 12:39:57|b6abeffe986eb38e411a4fe956280e2028d8bef699d9dd3244bde721a99b1dee|
|[1c58678fa1ffec5f2f6fdaed54dd6a81](https://www.virustotal.com/gui/file/1c58678fa1ffec5f2f6fdaed54dd6a81)|Android||2017-03-29 02:20:12|1c58678fa1ffec5f2f6fdaed54dd6a81.virus|
|[0be8a35a4818bb7e7404edbbe7431cb0](https://www.virustotal.com/gui/file/0be8a35a4818bb7e7404edbbe7431cb0)|Android||2017-03-22 09:26:27|line.apk|
|[eedbf1f7a0d392d4cea2ad58ed30a72e](https://www.virustotal.com/gui/file/eedbf1f7a0d392d4cea2ad58ed30a72e)|Android||2017-03-19 05:36:16|eedbf1f7a0d392d4cea2ad58ed30a72e.virus|
|[6462bdc3c6a5efb11e066853a757164a](https://www.virustotal.com/gui/file/6462bdc3c6a5efb11e066853a757164a)|Win32 EXE|msilperseus|2017-03-16 16:00:56|Loader.exe|
|[55347a2677d5c7716bbcd4c20c363d15](https://www.virustotal.com/gui/file/55347a2677d5c7716bbcd4c20c363d15)|Android||2017-03-13 02:17:40|55347a2677d5c7716bbcd4c20c363d15.virus|
|[8d527c848d667945f65cc59315ed5ee7](https://www.virustotal.com/gui/file/8d527c848d667945f65cc59315ed5ee7)|Android||2017-03-13 02:17:37|8d527c848d667945f65cc59315ed5ee7.virus|
|[6ad1f9fc5ba68bcd1e6868d44980690d](https://www.virustotal.com/gui/file/6ad1f9fc5ba68bcd1e6868d44980690d)|Android||2017-03-13 02:17:24|6ad1f9fc5ba68bcd1e6868d44980690d.virus|
|[78919ee718f9bd683d75b466e4ba70fb](https://www.virustotal.com/gui/file/78919ee718f9bd683d75b466e4ba70fb)|DOS EXE|msilperseus|2017-03-04 21:40:06| |
|[b076ec4e69ada4900b16807b45d1a53d](https://www.virustotal.com/gui/file/b076ec4e69ada4900b16807b45d1a53d)|DOS EXE||2017-03-04 21:33:14| |
|[bd2a0c55765eb01644346760983dc814](https://www.virustotal.com/gui/file/bd2a0c55765eb01644346760983dc814)|Win32 EXE||2017-03-02 21:22:56|Loader.exe|
|[79d499693b9444155d99e19ce9a9a155](https://www.virustotal.com/gui/file/79d499693b9444155d99e19ce9a9a155)|Win32 EXE||2017-03-02 10:02:32|Loader.exe|
|[a0582988c774eebeeba2798ccb04b27f](https://www.virustotal.com/gui/file/a0582988c774eebeeba2798ccb04b27f)|Win32 EXE||2017-03-02 06:28:54|Windows Media Help.exe|
|[5040d49c11069c43a15cf4d3921b5218](https://www.virustotal.com/gui/file/5040d49c11069c43a15cf4d3921b5218)|Win32 EXE|BestaFera|2017-03-02 06:27:09|System Media Update.exe|
|[14afcccac89c31782f5150ae1c8c6267](https://www.virustotal.com/gui/file/14afcccac89c31782f5150ae1c8c6267)|Win32 EXE||2017-02-28 15:01:46|Loader.exe|
|[15b923d32ba8efdfee719d503921b91d](https://www.virustotal.com/gui/file/15b923d32ba8efdfee719d503921b91d)|Win32 EXE||2017-02-28 09:41:18|VLC|
|[cf79d4d6d911e4c864114ddc2faef750](https://www.virustotal.com/gui/file/cf79d4d6d911e4c864114ddc2faef750)|Android||2017-02-28 00:54:00|cf79d4d6d911e4c864114ddc2faef750.virus|
|[97ae35d36c7434ef770e1a7fead55276](https://www.virustotal.com/gui/file/97ae35d36c7434ef770e1a7fead55276)|Win32 EXE|dynamer|2017-02-27 09:09:21|testproj.exe|
|[cb336cea05ef664c2796209770f5d624](https://www.virustotal.com/gui/file/cb336cea05ef664c2796209770f5d624)|Win32 EXE|dynamer|2017-02-27 09:04:25|f26caee34184b6a5_igfxtray.exe|
|[79e5f56d244044aab2f6760147524c57](https://www.virustotal.com/gui/file/79e5f56d244044aab2f6760147524c57)|Win32 EXE|dynamer|2017-02-27 09:03:22|testproj.exe|
|[7897cf3de02a5dfcfd2c32d8c0e08f58](https://www.virustotal.com/gui/file/7897cf3de02a5dfcfd2c32d8c0e08f58)|Win32 EXE|dynamer|2017-02-26 09:47:19|Player|
|[869eeb38d25a9366a3a5d62d1b15d940](https://www.virustotal.com/gui/file/869eeb38d25a9366a3a5d62d1b15d940)|Win32 EXE|BestaFera|2017-02-19 17:48:03|869eeb38d25a9366a3a5d62d1b15d940.virus|
|[679a56919384a182d633035bc7607f89](https://www.virustotal.com/gui/file/679a56919384a182d633035bc7607f89)|Win32 EXE||2017-02-18 05:55:33|679a56919384a182d633035bc7607f89.virus|
|[059a50b5c1bb8bc7944d897984dfb784](https://www.virustotal.com/gui/file/059a50b5c1bb8bc7944d897984dfb784)|Win32 EXE|Delf|2017-02-14 22:46:06|Win10Shell.exe|
|[0eba499c6dd0bcf26bb818e0c916b76c](https://www.virustotal.com/gui/file/0eba499c6dd0bcf26bb818e0c916b76c)|Win32 EXE||2017-02-14 20:01:59|Rape Egyption Girl-87634764238-786782346783-78432632478349579242.mp4.exe|
|[063f50b4546755efe06bdd4f0422511d](https://www.virustotal.com/gui/file/063f50b4546755efe06bdd4f0422511d)|Android|androidos|2017-02-14 19:37:02|update.apk|
|[f046ac1705e31f5d7654e6ba0b5ae772](https://www.virustotal.com/gui/file/f046ac1705e31f5d7654e6ba0b5ae772)|Win32 EXE|BestaFera|2017-02-13 16:52:31| |
|[b6507e6ff1bda8b105d3712a038017d6](https://www.virustotal.com/gui/file/b6507e6ff1bda8b105d3712a038017d6)|Win32 EXE|kasperagent|2017-02-12 15:35:05|Update|
|[ba062c23a468c803abe787d23350807c](https://www.virustotal.com/gui/file/ba062c23a468c803abe787d23350807c)|Win32 EXE||2017-02-12 11:26:15|VLC|
|[116d824285c32a2bdc6ca5443db8b3ce](https://www.virustotal.com/gui/file/116d824285c32a2bdc6ca5443db8b3ce)|Win32 EXE|kasperagent|2017-02-12 08:46:00|mkplayer.exe|
|[8868202fa4fa91dba59516fbba23e296](https://www.virustotal.com/gui/file/8868202fa4fa91dba59516fbba23e296)|Win32 EXE|BestaFera|2017-02-09 10:49:37|Update File Manager.exe|
|[42cbf5a26fe6ca3a0789de502d107a39](https://www.virustotal.com/gui/file/42cbf5a26fe6ca3a0789de502d107a39)|Win32 EXE|BestaFera|2017-02-09 10:47:57|Update Windows Service.exe|
|[11cdabb1a13205c6d4f43206f674b055](https://www.virustotal.com/gui/file/11cdabb1a13205c6d4f43206f674b055)|Win32 EXE|kasperagent|2017-02-05 05:42:33|Update|
|[80967033133d4d744bd82266bed76b86](https://www.virustotal.com/gui/file/80967033133d4d744bd82266bed76b86)|Win32 EXE|strictor|2017-02-01 14:12:52|Update|
|[20f9250a1fd7534c5d749321c7c28304](https://www.virustotal.com/gui/file/20f9250a1fd7534c5d749321c7c28304)|Win32 EXE|kasperagent|2017-01-31 19:57:51|Update|
|[5a05c515dc7fbc7a144c0eb929d7a9c0](https://www.virustotal.com/gui/file/5a05c515dc7fbc7a144c0eb929d7a9c0)|Win32 EXE||2017-01-31 09:05:11|Samsung Magician.exe|
|[47430323db04c1b86b46e65e26ba72d2](https://www.virustotal.com/gui/file/47430323db04c1b86b46e65e26ba72d2)|Win32 EXE|BestaFera|2017-01-29 08:07:14|Win10Shell.exe|
|[82630eb054431d84420e8cec59370741](https://www.virustotal.com/gui/file/82630eb054431d84420e8cec59370741)|Win32 EXE|Zbot|2017-01-25 21:24:30|WindowsUpdateService.exe|
|[304bf45f84b6e5659babb1dd5108d6e2](https://www.virustotal.com/gui/file/304bf45f84b6e5659babb1dd5108d6e2)|Win64 EXE|dynamer|2017-01-25 12:39:27|Wextract|
|[206a6e7d382d792551cfcd8110c00f39](https://www.virustotal.com/gui/file/206a6e7d382d792551cfcd8110c00f39)|Win32 EXE|starter|2017-01-25 09:30:51|206a6e7d382d792551cfcd8110c00f39.virus|
|[789ed8c1e3f9b1a77a5b6a43c09d2590](https://www.virustotal.com/gui/file/789ed8c1e3f9b1a77a5b6a43c09d2590)|Win32 EXE|BestaFera|2017-01-23 17:00:32|council_of_ministres_decision_15679863995_022654697794218_jpg.exe|
|[aef91731409b82100f7129c236869da8](https://www.virustotal.com/gui/file/aef91731409b82100f7129c236869da8)|Win32 EXE||2017-01-22 09:11:22|WindowsHelp.exe|
|[e73821e1767efde88b1aef203fe65136](https://www.virustotal.com/gui/file/e73821e1767efde88b1aef203fe65136)|Win32 EXE|BestaFera|2017-01-21 05:00:43|e73821e1767efde88b1aef203fe65136.virus|
|[a9b9af173ba34fed95e89482e2f6863c](https://www.virustotal.com/gui/file/a9b9af173ba34fed95e89482e2f6863c)|Win32 EXE|Zbot|2017-01-21 01:15:16|a9b9af173ba34fed95e89482e2f6863c.virus|
|[d9fba5b780cc029873a70cf22f5c9cac](https://www.virustotal.com/gui/file/d9fba5b780cc029873a70cf22f5c9cac)|Android||2017-01-17 12:26:09|LINE.apk|
|[356c76586babdde4717098675e762900](https://www.virustotal.com/gui/file/356c76586babdde4717098675e762900)|Win32 EXE|BestaFera|2017-01-17 11:05:27|update file manager.exe|
|[b525e5ceb7c06e2e94c1604224d2c4dd](https://www.virustotal.com/gui/file/b525e5ceb7c06e2e94c1604224d2c4dd)|Win32 EXE|BestaFera|2017-01-17 11:04:11|win10shell.exe|
|[071373765a35fd03bd6d61fd1dfe505b](https://www.virustotal.com/gui/file/071373765a35fd03bd6d61fd1dfe505b)|Win32 EXE|BestaFera|2017-01-17 11:04:04|updatetools.exe|
|[56ab37da8336a4a9a80ec9bda2659930](https://www.virustotal.com/gui/file/56ab37da8336a4a9a80ec9bda2659930)|Win32 EXE|BestaFera|2017-01-15 23:19:09|Geneva_Meeting_Center_784785673722346_9823644728509001_doc.exe|
|[090edcc95e38d27e686b6329c3bee8fd](https://www.virustotal.com/gui/file/090edcc95e38d27e686b6329c3bee8fd)|Win32 EXE|BestaFera|2017-01-15 23:17:53|3634(1)_487886_10152599432711675287_25093124132199354_n_PDF.exe|
|[a6b571bb79a8ddfac8bbf70d744fd9c0](https://www.virustotal.com/gui/file/a6b571bb79a8ddfac8bbf70d744fd9c0)|RAR||2017-01-15 19:55:32|a6b571bb79a8ddfac8bbf70d744fd9c0.virus|
|[5b2dc3b75f1944b73c2101ff1077f690](https://www.virustotal.com/gui/file/5b2dc3b75f1944b73c2101ff1077f690)|Win32 EXE|Zbot|2017-01-15 13:47:25|f482eef9bf78c083acb1b4c98e3b4bb3|
|[5823f265f46614a005b6367d211eafb7](https://www.virustotal.com/gui/file/5823f265f46614a005b6367d211eafb7)|Win32 EXE|Ramnit|2017-01-13 01:43:05|Update|
|[2bb84cfe548fec7fb123d7e46cf67ff4](https://www.virustotal.com/gui/file/2bb84cfe548fec7fb123d7e46cf67ff4)|Win32 EXE||2017-01-10 08:21:24|C:\\Users\\Dan\\Downloads\\6e461a8430f251db38e8911dbacd1e72bce47a89c28956115b702d13ae2b8e3b|
|[4e5f20b8b025830fad872a56cb892d7c](https://www.virustotal.com/gui/file/4e5f20b8b025830fad872a56cb892d7c)|Win32 EXE||2017-01-09 13:29:27|VLC|
|[09e4e6fa85b802c46bc121fcaecc5666](https://www.virustotal.com/gui/file/09e4e6fa85b802c46bc121fcaecc5666)|Win32 EXE|MSILPerseus|2017-01-08 16:19:03|Loader.exe|
|[ad44d53c15fdb39e1460cae6423d1a23](https://www.virustotal.com/gui/file/ad44d53c15fdb39e1460cae6423d1a23)|Win32 EXE|Zbot|2017-01-08 16:18:06| |
|[51e5fb808aef2a65eab53b2ccea57dd3](https://www.virustotal.com/gui/file/51e5fb808aef2a65eab53b2ccea57dd3)|Win32 EXE|adoc|2017-01-04 09:57:36|Terminal.exe.bin|
|[037410c7ec88795f8cf352104001ea99](https://www.virustotal.com/gui/file/037410c7ec88795f8cf352104001ea99)|Win32 EXE|kasperagent|2017-01-04 09:38:00|Update|
|[1b89ac0f5b4ce671e818c87de26938ad](https://www.virustotal.com/gui/file/1b89ac0f5b4ce671e818c87de26938ad)|Win32 EXE||2016-12-29 12:08:59|RaedSituation_Home_Security_487886_10152599711675287_2509_pdf.exe|
|[4c1eec2b9b6eefa49ff9f5fd87e77482](https://www.virustotal.com/gui/file/4c1eec2b9b6eefa49ff9f5fd87e77482)|Win32 EXE|BestaFera|2016-12-27 12:36:10|اعادة هيكلة الأجهزة الأمنية_27-12-2016_564534234_pdf.exe|
|[f8dae94ad3a1e36c2cf58ba253544ece](https://www.virustotal.com/gui/file/f8dae94ad3a1e36c2cf58ba253544ece)|Win32 EXE|kasperagent|2016-12-26 21:36:33|MX Update|
|[ceef61be02dd90cb8d14742a3aaab362](https://www.virustotal.com/gui/file/ceef61be02dd90cb8d14742a3aaab362)|Win32 EXE|kasperagent|2016-12-23 21:39:14|Update|
|[662ae23476cc0ef97deaaf97c1ee64b9](https://www.virustotal.com/gui/file/662ae23476cc0ef97deaaf97c1ee64b9)|Win32 EXE|Delf|2016-12-23 09:52:15|E:\sample\事件分析\沙漠猎鹰\4299fbfe74f671ee2c36d71bc808437c\windows_shell_update.exe_|
|[211e03c5894f9cc8180bbda80e6fa537](https://www.virustotal.com/gui/file/211e03c5894f9cc8180bbda80e6fa537)|Android||2016-12-22 22:18:36| |
|[06410f97ec2a6bc76f693c07735e99d6](https://www.virustotal.com/gui/file/06410f97ec2a6bc76f693c07735e99d6)|Win32 EXE|strictor|2016-12-22 08:45:22|Update|
|[3dc99568080033d6772a71fc56875687](https://www.virustotal.com/gui/file/3dc99568080033d6772a71fc56875687)|Win32 EXE|MSILPerseus|2016-12-22 08:45:08|Loader.exe|
|[220dd77f7bbbd7ca5fef105e6ab8e35e](https://www.virustotal.com/gui/file/220dd77f7bbbd7ca5fef105e6ab8e35e)|Win32 EXE|MSILPerseus|2016-12-22 01:32:05|Loader.exe|
|[e6da1e8bf6b6ffc52c56788500e98eb6](https://www.virustotal.com/gui/file/e6da1e8bf6b6ffc52c56788500e98eb6)|Win32 EXE||2016-12-21 15:22:59|VLC|
|[0c97e922b62d2497e37c5c01a807f2ae](https://www.virustotal.com/gui/file/0c97e922b62d2497e37c5c01a807f2ae)|Win32 EXE|strictor|2016-12-21 10:48:29|Update|
|[c0dc81e3a45709ccd07984d9248a9c1c](https://www.virustotal.com/gui/file/c0dc81e3a45709ccd07984d9248a9c1c)|Win32 EXE||2016-12-21 10:45:50|Loader.exe|
|[a111af210dc777621f79edffb6bed6f3](https://www.virustotal.com/gui/file/a111af210dc777621f79edffb6bed6f3)|Win32 EXE|Delf|2016-12-16 14:33:21|e1e613027958bbd7f24e648959aafe57|
|[4572eb0381a86916f8e62514ffac0459](https://www.virustotal.com/gui/file/4572eb0381a86916f8e62514ffac0459)|Android||2016-12-13 17:44:59| |
|[2fd81bb4b270791fad5936b4efd3e0df](https://www.virustotal.com/gui/file/2fd81bb4b270791fad5936b4efd3e0df)|Win32 EXE|BestaFera|2016-12-13 13:46:13| |
|[0d40eb7d51a4a5ae61bedad3ffee3d56](https://www.virustotal.com/gui/file/0d40eb7d51a4a5ae61bedad3ffee3d56)|Win32 EXE|Zbot|2016-12-13 13:45:20|ملخص إجتماعات اليوم_13-12-2016 -1564863-56478_doc.exe|
|[b5792f6671ba5b407a455766ed80fb22](https://www.virustotal.com/gui/file/b5792f6671ba5b407a455766ed80fb22)|Win32 EXE||2016-12-12 17:47:52|VLC|
|[1feadd0f95d84d878c22534f6ef0bedc](https://www.virustotal.com/gui/file/1feadd0f95d84d878c22534f6ef0bedc)|Android||2016-12-12 12:20:45| |
|[ac9131660f6a614162a01e8cc8948d52](https://www.virustotal.com/gui/file/ac9131660f6a614162a01e8cc8948d52)|Win32 EXE|BestaFera|2016-12-09 20:46:28| |
|[3ef88081662712f123d438b44e399c12](https://www.virustotal.com/gui/file/3ef88081662712f123d438b44e399c12)|Win32 EXE|BestaFera|2016-12-09 20:45:19|The details of the assassination of President Arafat_06-12-2016_docx.exe|
|[1381c805f00552ad0e467acee867b29e](https://www.virustotal.com/gui/file/1381c805f00552ad0e467acee867b29e)|Win32 EXE||2016-12-08 14:45:28| |
|[4eeb610eb430fbdc6eefb0932dcb5475](https://www.virustotal.com/gui/file/4eeb610eb430fbdc6eefb0932dcb5475)|Win32 EXE|kasperagent|2016-12-08 08:47:43|Loader.Properties.Resources.resources|
|[c2cb6380a492ee8ded3a694229383505](https://www.virustotal.com/gui/file/c2cb6380a492ee8ded3a694229383505)|Win32 EXE||2016-12-07 11:16:33|Loader.exe|
|[7dd560d8cee99f4126b50dca52854a5e](https://www.virustotal.com/gui/file/7dd560d8cee99f4126b50dca52854a5e)|Win32 EXE|msilperseus|2016-12-06 06:26:34|Loader.exe|
|[d7825036eb4802fe9a690c852a65eef5](https://www.virustotal.com/gui/file/d7825036eb4802fe9a690c852a65eef5)|Win32 EXE|BestaFera|2016-12-04 07:56:07| |
|[f030defa9578b8994f9802ac2c062cd7](https://www.virustotal.com/gui/file/f030defa9578b8994f9802ac2c062cd7)|Win32 EXE||2016-12-04 07:55:29|ملخص إجتماعات اليوم_pdf.exe|
|[c548cea3b6d00776f322182a77e94ae5](https://www.virustotal.com/gui/file/c548cea3b6d00776f322182a77e94ae5)|Win32 EXE|kasperagent|2016-12-03 13:03:04|MX Update|
|[bd5c3997307fd02175f1ec797596160c](https://www.virustotal.com/gui/file/bd5c3997307fd02175f1ec797596160c)|Win32 EXE|kasperagent|2016-12-03 03:06:11|MX Update|
|[7103143145440360cca5c9da7a19eaf7](https://www.virustotal.com/gui/file/7103143145440360cca5c9da7a19eaf7)|Win32 EXE|kasperagent|2016-12-03 02:51:21|MX Update|
|[e82ddb04d2f6b7d1327c9c7f7edf3086](https://www.virustotal.com/gui/file/e82ddb04d2f6b7d1327c9c7f7edf3086)|Win32 EXE|msilperseus|2016-12-03 01:33:25|Loader.exe|
|[ed8589ef50d6552011f0e867f17b0dac](https://www.virustotal.com/gui/file/ed8589ef50d6552011f0e867f17b0dac)|Win32 EXE|kasperagent|2016-12-03 01:32:15|MX Update|
|[1507ebfa9c6fe407c8b8fd44c1019b12](https://www.virustotal.com/gui/file/1507ebfa9c6fe407c8b8fd44c1019b12)|Win32 EXE|MSILPerseus|2016-12-02 19:16:57|Loader.exe|
|[9c4026002ab1615aaeab941c2f900386](https://www.virustotal.com/gui/file/9c4026002ab1615aaeab941c2f900386)|Win32 EXE|msilperseus|2016-12-02 05:52:36|Loader.exe|
|[ce066f4dbba840e8bc16cd7793b1dd0a](https://www.virustotal.com/gui/file/ce066f4dbba840e8bc16cd7793b1dd0a)|Win32 EXE||2016-12-01 14:45:24|Loader.exe|
|[5891445552a501176fd0a493c6d5659b](https://www.virustotal.com/gui/file/5891445552a501176fd0a493c6d5659b)|Android|androidos|2016-11-30 14:23:13|private_pic.apk|
|[ae67b0b632230a887bef7a112432aa0d](https://www.virustotal.com/gui/file/ae67b0b632230a887bef7a112432aa0d)|Win32 EXE|kasperagent|2016-11-25 02:10:26|MX Update|
|[ad6ede2e93230802568b59b5bab52bd8](https://www.virustotal.com/gui/file/ad6ede2e93230802568b59b5bab52bd8)|Android|androidos|2016-11-24 13:41:41|31a609d0896e49da3a46e3805cb92c0269f3f738|
|[4fd4aca3f00507c7dd778efceb4b2f85](https://www.virustotal.com/gui/file/4fd4aca3f00507c7dd778efceb4b2f85)|Win32 EXE||2016-11-19 00:35:12|أهم نقاط إجتماع ذكرى الرئيس الراحل أبوعمار رحمه الله - ورقة رقم 1- page number1.jpg.exe|
|[bf376ffc368ddc88d62f47bda82ecf0a](https://www.virustotal.com/gui/file/bf376ffc368ddc88d62f47bda82ecf0a)|Win32 EXE||2016-11-19 00:31:26|bf376ffc368ddc88d62f47bda82ecf0a.virus|
|[83a1ebc2cb4c2923003470b1662785c9](https://www.virustotal.com/gui/file/83a1ebc2cb4c2923003470b1662785c9)|Win32 EXE||2016-11-18 05:24:19|Win10Shell.exe|
|[205dcaeb61b90c89a2f27de2b9c8b531](https://www.virustotal.com/gui/file/205dcaeb61b90c89a2f27de2b9c8b531)|Win32 EXE||2016-11-18 05:22:32|205dcaeb61b90c89a2f27de2b9c8b531.virus|
|[1aeea730e836f9ae71f2d252d8621f97](https://www.virustotal.com/gui/file/1aeea730e836f9ae71f2d252d8621f97)|Win32 EXE|adoc|2016-11-17 10:01:42|ITM1|
|[401f2ad5d53e8b387e43801a0353508a](https://www.virustotal.com/gui/file/401f2ad5d53e8b387e43801a0353508a)|Win32 EXE||2016-11-17 10:00:52|Jawwal- New Every Day - Hamla جوال -حملة كل يوم جديد.jpg.exe|
|[d0e2dd20690262b4e468739dff8ffd36](https://www.virustotal.com/gui/file/d0e2dd20690262b4e468739dff8ffd36)|Win32 EXE||2016-11-16 21:30:17|Loader.exe|
|[19aa2acda92b14c79acb181ca7796bd0](https://www.virustotal.com/gui/file/19aa2acda92b14c79acb181ca7796bd0)|Win32 EXE|MSILPerseus|2016-11-16 14:19:09|Loader.exe|
|[8c9053a747cd508d499f5277ae7f33f9](https://www.virustotal.com/gui/file/8c9053a747cd508d499f5277ae7f33f9)|Win32 EXE|Delf|2016-11-14 16:41:23|xxxx.exe|
|[84e2d5d5ebcddeec32c6538b121d8301](https://www.virustotal.com/gui/file/84e2d5d5ebcddeec32c6538b121d8301)|Win32 EXE|BestaFera|2016-11-14 14:56:04|Virus.exe|
|[ddc685e809af307eecd84454ff8c588d](https://www.virustotal.com/gui/file/ddc685e809af307eecd84454ff8c588d)|Win32 EXE|BestaFera|2016-11-14 08:56:24| |
|[86366fc738db6033ae8d56570be9b7b4](https://www.virustotal.com/gui/file/86366fc738db6033ae8d56570be9b7b4)|Win32 EXE|strictor|2016-11-14 08:55:46|Donald-Trump-impersonator-hits-with-bikini-clad-models -hot models.mp4.exe|
|[927d544fe71cdd65acf3148acebc30c2](https://www.virustotal.com/gui/file/927d544fe71cdd65acf3148acebc30c2)|Win32 EXE|BestaFera|2016-11-13 11:25:13|drop.exe|
|[9e95bd742995e58f27fa4513db92a4c0](https://www.virustotal.com/gui/file/9e95bd742995e58f27fa4513db92a4c0)|Android||2016-11-13 09:10:03|index.html?md5=9e95bd742995e58f27fa4513db92a4c0%0D|
|[78b65852b20fbf2a6b2319a1746b6d80](https://www.virustotal.com/gui/file/78b65852b20fbf2a6b2319a1746b6d80)|Win32 EXE|msilperseus|2016-11-09 03:50:10|Loader.exe|
|[978f1d1051e5bd0b691e7007c3a742db](https://www.virustotal.com/gui/file/978f1d1051e5bd0b691e7007c3a742db)|Win32 EXE|strictor|2016-11-08 13:54:54|MX Update|
|[775c128456a53dec85305a1e78ed5edf](https://www.virustotal.com/gui/file/775c128456a53dec85305a1e78ed5edf)|Win32 EXE|strictor|2016-11-06 21:11:44|MX Update|
|[7fae6a64cde709261e488e96da7eb52c](https://www.virustotal.com/gui/file/7fae6a64cde709261e488e96da7eb52c)|Android|androidos|2016-11-06 13:25:58|7fae6a64cde709261e488e96da7eb52c.virus|
|[1a602a60afe163a1cf4dae1f82d39e4d](https://www.virustotal.com/gui/file/1a602a60afe163a1cf4dae1f82d39e4d)|Android||2016-11-06 06:46:38|com.app.privatepic.apk|
|[e3113604b6e0287648d42cc7051bbec5](https://www.virustotal.com/gui/file/e3113604b6e0287648d42cc7051bbec5)|Win32 EXE|strictor|2016-11-04 02:35:47|MX Update|
|[9bf0f6192d7d92191135ec73ec460c9e](https://www.virustotal.com/gui/file/9bf0f6192d7d92191135ec73ec460c9e)|ZIP|msilperseus|2016-11-04 00:23:20|downloadfile_____________.zip|
|[240105a1510f6e4f5c40a64c98971bac](https://www.virustotal.com/gui/file/240105a1510f6e4f5c40a64c98971bac)|Win32 EXE|MSILPerseus|2016-11-03 16:00:13|Loader.exe|
|[41799f40626f26d8337a7724ef3d1938](https://www.virustotal.com/gui/file/41799f40626f26d8337a7724ef3d1938)|Win32 EXE|msilperseus|2016-11-03 15:16:56|Loader.exe|
|[258e8336628e8f6f4dffbbfd3967d64e](https://www.virustotal.com/gui/file/258e8336628e8f6f4dffbbfd3967d64e)|ZIP|msilperseus|2016-11-03 13:22:32|/home/virustotal/sample/258E8336628E8F6F4DFFBBFD3967D64E|
|[ee8e6929c64c32bd1a86ea8c50802a09](https://www.virustotal.com/gui/file/ee8e6929c64c32bd1a86ea8c50802a09)|Win32 EXE||2016-10-29 17:37:47|Loader.exe|
|[0e069bd6cb62731473822334a2c15353](https://www.virustotal.com/gui/file/0e069bd6cb62731473822334a2c15353)|Win32 EXE|msilperseus|2016-10-29 17:27:44|Loader.exe|
|[9075d79f9fec1df5689cca2218d406cd](https://www.virustotal.com/gui/file/9075d79f9fec1df5689cca2218d406cd)|Win32 EXE|msilperseus|2016-10-29 17:16:17|Loader.exe|
|[ee017b839131d5ee7891e1dd7b163d84](https://www.virustotal.com/gui/file/ee017b839131d5ee7891e1dd7b163d84)|Android||2016-10-28 17:00:41|207274577|
|[cf89ffc87287673727f57c307a2f329d](https://www.virustotal.com/gui/file/cf89ffc87287673727f57c307a2f329d)|Android||2016-10-27 10:38:34|cf89ffc87287673727f57c307a2f329d.virus|
|[5cfc132b66f523b1ce907d9aea1ea199](https://www.virustotal.com/gui/file/5cfc132b66f523b1ce907d9aea1ea199)|Android||2016-10-26 20:25:25|com.app.privatepic.apk|
|[a3c4effb16ac5710d5099d260220b488](https://www.virustotal.com/gui/file/a3c4effb16ac5710d5099d260220b488)|Win32 EXE|BestaFera|2016-10-24 15:51:32|ITM1|
|[d91e3a1beb5a523a7cbdcb46edfe6d76](https://www.virustotal.com/gui/file/d91e3a1beb5a523a7cbdcb46edfe6d76)|Win32 EXE|BestaFera|2016-10-24 15:50:49|2.exe|
|[968c1eb13bb073e376f6c3c4e71640be](https://www.virustotal.com/gui/file/968c1eb13bb073e376f6c3c4e71640be)|Android||2016-10-23 08:17:54|com.app.privatepic.apk|
|[1e369cf9d270464352e1cec6e55b56f7](https://www.virustotal.com/gui/file/1e369cf9d270464352e1cec6e55b56f7)|Android|androidos|2016-10-21 14:34:29|1e369cf9d270464352e1cec6e55b56f7.virus|
|[0414afcf37f60c63c280698c840a612d](https://www.virustotal.com/gui/file/0414afcf37f60c63c280698c840a612d)|Android||2016-10-21 14:27:28| |
|[68f3417ccabef6cf6ce3ab9e299e681e](https://www.virustotal.com/gui/file/68f3417ccabef6cf6ce3ab9e299e681e)|Android||2016-10-20 15:15:29| |
|[f9155cabbdccc70f5ac86e754986c0a7](https://www.virustotal.com/gui/file/f9155cabbdccc70f5ac86e754986c0a7)|Win32 EXE|Delf|2016-10-19 05:25:41|f9155cabbdccc70f5ac86e754986c0a7.virus|
|[ca24f2ff1b3a93215f30f499f6dfcc9a](https://www.virustotal.com/gui/file/ca24f2ff1b3a93215f30f499f6dfcc9a)|Win32 EXE|BestaFera|2016-10-13 04:41:16|ITM1|
|[78771eafed8984e240a85e98e97c97e8](https://www.virustotal.com/gui/file/78771eafed8984e240a85e98e97c97e8)|Win32 EXE|BestaFera|2016-10-13 04:40:33|78771eafed8984e240a85e98e97c97e8.virus|
|[c1b94ee243c5de0b58d6295a8d054db2](https://www.virustotal.com/gui/file/c1b94ee243c5de0b58d6295a8d054db2)|RAR|BestaFera|2016-10-11 06:58:56|quds.rar|
|[ec3186de5be92eff578c20b7c572f7a3](https://www.virustotal.com/gui/file/ec3186de5be92eff578c20b7c572f7a3)|Win32 EXE|msilperseus|2016-10-10 09:05:45|Loader.exe|
|[79902094e6d5b7fa06a31e99841d0a71](https://www.virustotal.com/gui/file/79902094e6d5b7fa06a31e99841d0a71)|Win32 EXE||2016-10-09 09:55:50|System Settings Broker|
|[f57f7736e4b4cb05d9bbb20660947d6d](https://www.virustotal.com/gui/file/f57f7736e4b4cb05d9bbb20660947d6d)|Win32 EXE||2016-10-08 12:00:56|Loader.exe|
|[19a234422f6f1c21906121ad5878e480](https://www.virustotal.com/gui/file/19a234422f6f1c21906121ad5878e480)|Win32 EXE|MSILPerseus|2016-10-07 10:37:14|Loader.exe|
|[88afd6bbd9f35b3c1c49b667250b95f8](https://www.virustotal.com/gui/file/88afd6bbd9f35b3c1c49b667250b95f8)|Win32 EXE||2016-10-07 10:02:31|Loader.exe|
|[6a5c4d9a83135b745a8714f22f694c9a](https://www.virustotal.com/gui/file/6a5c4d9a83135b745a8714f22f694c9a)|Win32 EXE|kasperagent|2016-10-06 13:53:03| |
|[fe23fa6df4d8fb500859f0f76e92552d](https://www.virustotal.com/gui/file/fe23fa6df4d8fb500859f0f76e92552d)|Win32 EXE|MSILPerseus|2016-10-06 13:53:01|Loader.exe|
|[e4d0049e5fef02c013b22fd9f5018272](https://www.virustotal.com/gui/file/e4d0049e5fef02c013b22fd9f5018272)|Win32 EXE|MSILPerseus|2016-10-06 02:05:18|Loader.exe|
|[5c0e7ab56cdfb0a4dbf0f455e9233fed](https://www.virustotal.com/gui/file/5c0e7ab56cdfb0a4dbf0f455e9233fed)|Win32 EXE|kasperagent|2016-10-03 15:49:41| |
|[96d5c2a040fac48ce80d8a435c577d70](https://www.virustotal.com/gui/file/96d5c2a040fac48ce80d8a435c577d70)|Win32 EXE||2016-10-03 04:06:11| |
|[1c2ad73d6b74bcb24081ce56fb8c679f](https://www.virustotal.com/gui/file/1c2ad73d6b74bcb24081ce56fb8c679f)|Win32 EXE||2016-10-03 04:03:30|khaliji.exe|
|[2c8216106a32319ea6e3634583f317a7](https://www.virustotal.com/gui/file/2c8216106a32319ea6e3634583f317a7)|Win32 EXE||2016-10-02 21:56:08|khaliji.exe|
|[5731692c40e4836462280ece7bc0f7de](https://www.virustotal.com/gui/file/5731692c40e4836462280ece7bc0f7de)|Win32 EXE|MSILPerseus|2016-10-02 10:10:54|Loader.exe|
|[da22659738065a611a9a491a2332ed6a](https://www.virustotal.com/gui/file/da22659738065a611a9a491a2332ed6a)|Android||2016-09-29 06:00:25|C:\Users\Target\Desktop\lv-chat.apk|
|[acc903afe22dcf0eb5f046dcd8db41c1](https://www.virustotal.com/gui/file/acc903afe22dcf0eb5f046dcd8db41c1)|Android||2016-09-28 10:42:31|secure_photos.apk|
|[bd75af219f417413a4e0fae8cd89febd](https://www.virustotal.com/gui/file/bd75af219f417413a4e0fae8cd89febd)|Win32 EXE|Zbot|2016-09-27 09:18:33|22.exe|
|[222880b8db346a91e05b72a31b8496f7](https://www.virustotal.com/gui/file/222880b8db346a91e05b72a31b8496f7)|Win32 EXE|Zbot|2016-09-27 09:16:48|1s1.exe|
|[15605e6e3faa6750acb4f04fd224e78b](https://www.virustotal.com/gui/file/15605e6e3faa6750acb4f04fd224e78b)|Win32 EXE|kasperagent|2016-09-27 09:15:09|11.exe|
|[9f4023f2aefc8c4c261bfdd4bd911952](https://www.virustotal.com/gui/file/9f4023f2aefc8c4c261bfdd4bd911952)|Win32 EXE|kasperagent|2016-09-27 09:13:52|2223.exe|
|[058769ba93223bede0ba601926693ddc](https://www.virustotal.com/gui/file/058769ba93223bede0ba601926693ddc)|Win32 EXE|kasperagent|2016-09-27 09:11:32|222.exe|
|[07e47f06c5ed05a062e674f8d11b01d8](https://www.virustotal.com/gui/file/07e47f06c5ed05a062e674f8d11b01d8)|Win32 EXE|Zbot|2016-09-27 09:06:36|taskwin.exe|
|[2fd3fda18ed858c5e51e424ebbad94c0](https://www.virustotal.com/gui/file/2fd3fda18ed858c5e51e424ebbad94c0)|Win32 EXE||2016-09-27 07:53:35|Loader.exe|
|[d0d9d6d74f9405cdc924760e3d460d84](https://www.virustotal.com/gui/file/d0d9d6d74f9405cdc924760e3d460d84)|Win32 EXE|Delf|2016-09-22 08:21:40|d0d9d6d74f9405cdc924760e3d460d84.virus|
|[882cab29144e1cb9e0512b8f1103b2da](https://www.virustotal.com/gui/file/882cab29144e1cb9e0512b8f1103b2da)|Win32 EXE||2016-08-31 16:47:43|882cab29144e1cb9e0512b8f1103b2da.virus|
|[71d505e3abfecd86cf76bb854e60a813](https://www.virustotal.com/gui/file/71d505e3abfecd86cf76bb854e60a813)|Win32 EXE||2016-08-30 01:12:19|khaliji.exe|
|[83937cd798833e7bb504ded1cdbbfbfa](https://www.virustotal.com/gui/file/83937cd798833e7bb504ded1cdbbfbfa)|RAR||2016-08-29 21:46:29|khaliji.rar|
|[abf252b04d689a2a5720530e6c0252b0](https://www.virustotal.com/gui/file/abf252b04d689a2a5720530e6c0252b0)|Win32 EXE||2016-08-29 17:12:40|487886_10152599711675287693822349087_25087648787392423999354_n.mp4.exe|
|[0ff48807e2580d8ec1cc7fbcae2437da](https://www.virustotal.com/gui/file/0ff48807e2580d8ec1cc7fbcae2437da)|RAR||2016-08-29 13:46:04|0ff48807e2580d8ec1cc7fbcae2437da.virus|
|[f0d7aee24f3a5108bcc8860ffeb10496](https://www.virustotal.com/gui/file/f0d7aee24f3a5108bcc8860ffeb10496)|Win32 EXE||2016-08-27 12:54:24|Tasreeb.exe|
|[ec6c6334946cb48bb2fd646a1966edf9](https://www.virustotal.com/gui/file/ec6c6334946cb48bb2fd646a1966edf9)|Win32 EXE|dynamer|2016-08-27 12:54:15|ITM1|
|[77d2289102b8155c3902d1bdf05508c2](https://www.virustotal.com/gui/file/77d2289102b8155c3902d1bdf05508c2)|RAR||2016-08-27 09:17:29|77d2289102b8155c3902d1bdf05508c2.virus|
|[20ba6461306aba555c2db3e86e4f959b](https://www.virustotal.com/gui/file/20ba6461306aba555c2db3e86e4f959b)|Win32 EXE|kasperagent|2016-08-19 20:47:41|20ba6461306aba555c2db3e86e4f959b.virus|
|[fcea715854365bc43a624f938d6edfcb](https://www.virustotal.com/gui/file/fcea715854365bc43a624f938d6edfcb)|Win32 EXE||2016-07-26 00:05:54|m:\x\40c5eaea273d0ab4f078fd5887b9fcfd2715faa2c4bfbda66ec3967d5058545a.exe|
|[f7b0dbc09c3fbef3e0a287e84ca8cebd](https://www.virustotal.com/gui/file/f7b0dbc09c3fbef3e0a287e84ca8cebd)|Win32 EXE|Zbot|2016-07-14 20:37:01|f7b0dbc09c3fbef3e0a287e84ca8cebd.virus|
|[cd38d10f4bc730b40be1f80b3034e31e](https://www.virustotal.com/gui/file/cd38d10f4bc730b40be1f80b3034e31e)|Win32 EXE||2016-07-14 18:05:52|/home/virustotal/sample/CD38D10F4BC730B40BE1F80B3034E31E|
|[44cc31ab34deb9fb1d78b6b337043bc6](https://www.virustotal.com/gui/file/44cc31ab34deb9fb1d78b6b337043bc6)|Android|androidos|2016-07-13 20:04:58|44cc31ab34deb9fb1d78b6b337043bc6.virus|
|[d665bfe8632b1b3194eb68d09237c58f](https://www.virustotal.com/gui/file/d665bfe8632b1b3194eb68d09237c58f)|Win32 EXE||2016-07-13 01:50:10|ì¨ ê ïªã¤ éªí¤ åï éãéç¡ é¥êïê¡ !.scr|
|[f0dd2e20d2dbfeb9cf1bbd9dad0f3826](https://www.virustotal.com/gui/file/f0dd2e20d2dbfeb9cf1bbd9dad0f3826)|Win32 EXE||2016-07-12 05:12:16| |
|[5bbb5604bc0f656545dfcbb09820d61a](https://www.virustotal.com/gui/file/5bbb5604bc0f656545dfcbb09820d61a)|Win32 EXE|Delf|2016-07-09 19:55:56|18d8d51e-b8e6-11e8-9965-ec9a744775ac|
|[4299fbfe74f671ee2c36d71bc808437c](https://www.virustotal.com/gui/file/4299fbfe74f671ee2c36d71bc808437c)|Win32 EXE||2016-07-09 16:11:30|????? ????? 2016---??????--????----????---Palestine-Tawjehi-------.xsl.scr|
|[c74703264e464ac0153157d8d257cb29](https://www.virustotal.com/gui/file/c74703264e464ac0153157d8d257cb29)|Android||2016-06-12 12:41:02|b0b9c140cc57b3e8f39e7323fbca0a2eef75335a|
|[a44eac0c1a6e25c9d61dc33ef70b6978](https://www.virustotal.com/gui/file/a44eac0c1a6e25c9d61dc33ef70b6978)|Win32 EXE|kasperagent|2016-05-26 22:34:10|livePCsupport.exe|
|[c945ef969a544b020c681ac25d591867](https://www.virustotal.com/gui/file/c945ef969a544b020c681ac25d591867)|Android|androidos|2016-05-25 21:35:10|c945ef969a544b020c681ac25d591867.virus|
|[271c61699eb2a673b8543e9377ce7a0a](https://www.virustotal.com/gui/file/271c61699eb2a673b8543e9377ce7a0a)|Win32 EXE|kasperagent|2016-05-06 21:18:10|studio_photos.pdf .scr|
|[a42cc1ed872160ee51eaae83d6d3027c](https://www.virustotal.com/gui/file/a42cc1ed872160ee51eaae83d6d3027c)|Win32 EXE|kasperagent|2016-05-06 21:18:05|2016030202.jpg .scr|
|[9277c5bc50aa7a32f4c3dabe7ebb0b23](https://www.virustotal.com/gui/file/9277c5bc50aa7a32f4c3dabe7ebb0b23)|Win32 EXE|kasperagent|2016-05-06 21:18:03|2016030201.jpg .scr|
|[72cc13ce73c357cab63d6ba491d2d7df](https://www.virustotal.com/gui/file/72cc13ce73c357cab63d6ba491d2d7df)|Win32 EXE|Zbot|2016-04-19 20:54:09|MkPlayer.exe|
|[129c5c9ee71b9d46fcb9e789900c2394](https://www.virustotal.com/gui/file/129c5c9ee71b9d46fcb9e789900c2394)|Win32 EXE|kasperagent|2016-04-19 10:55:06|2016030201.jpg .scr|
|[a99fbfe3001f579224467092ffb68a30](https://www.virustotal.com/gui/file/a99fbfe3001f579224467092ffb68a30)|Win32 EXE|kasperagent|2016-04-19 05:57:58|لماذا اقتحم السنوار منزل شتيوي.doc.scr|
|[c4a2e6d6e7811352eb9102a0479a9265](https://www.virustotal.com/gui/file/c4a2e6d6e7811352eb9102a0479a9265)|Win32 EXE|Zbot|2016-04-18 03:16:26|c4a2e6d6e7811352eb9102a0479a9265.virus|
|[1f1108963c01115b8baffb6535b36a5c](https://www.virustotal.com/gui/file/1f1108963c01115b8baffb6535b36a5c)|Win32 EXE|Zbot|2016-04-16 04:51:01| |
|[30be94c1b6444deca5e1944cae7af009](https://www.virustotal.com/gui/file/30be94c1b6444deca5e1944cae7af009)|Win32 EXE|dynamer|2016-04-11 14:44:12|Wextract|
|[90b4fbd59d799a9ea9410881d1a72e80](https://www.virustotal.com/gui/file/90b4fbd59d799a9ea9410881d1a72e80)|Win32 EXE|Zbot|2016-04-11 13:37:23|C:/Users/seongmin/Documents/VT2/malware/20170828/90b4fbd59d799a9ea9410881d1a72e80.vir|
|[2663a331a4c0e0360b7c7834cf7d2138](https://www.virustotal.com/gui/file/2663a331a4c0e0360b7c7834cf7d2138)|Win32 EXE|Zbot|2016-04-11 11:13:08|Windows_Services_Update.exe|
|[fe3f29aff51dc9673bc30f85c0005f64](https://www.virustotal.com/gui/file/fe3f29aff51dc9673bc30f85c0005f64)|Win32 EXE||2016-04-11 09:55:48|Wextract|
|[4012afd54ecb4b4e01f524a9f1d11a09](https://www.virustotal.com/gui/file/4012afd54ecb4b4e01f524a9f1d11a09)|Win32 EXE||2016-04-11 07:10:16|AngelinaJolie15.scr|
|[be99a259abdd09eaf5ccdf1ff4fd0a84](https://www.virustotal.com/gui/file/be99a259abdd09eaf5ccdf1ff4fd0a84)|Win32 EXE|Zbot|2016-04-10 23:11:09|Windows_Services_Update.exe|
|[9e5cbd13cf51b95040fa1d4a8369b3df](https://www.virustotal.com/gui/file/9e5cbd13cf51b95040fa1d4a8369b3df)|Win32 EXE|Zbot|2016-04-10 20:56:50|Windows_Services_Update.exe|
|[1dc2a1a323f6745d3bfd8ef12aea5c2c](https://www.virustotal.com/gui/file/1dc2a1a323f6745d3bfd8ef12aea5c2c)|Win32 EXE||2016-04-10 18:32:51|Wextract|
|[69d1cceb045ff819111a624326340602](https://www.virustotal.com/gui/file/69d1cceb045ff819111a624326340602)|Win32 EXE||2016-04-10 15:09:20|Wextract|
|[09e3f6439205672bb41911b20f685305](https://www.virustotal.com/gui/file/09e3f6439205672bb41911b20f685305)|Win32 EXE||2016-04-10 11:18:51|AngelinaJolie12.scr|
|[3b909498cf8f87767c7c0437ba5214d3](https://www.virustotal.com/gui/file/3b909498cf8f87767c7c0437ba5214d3)|Win32 EXE||2016-04-10 07:37:09|AngelinaJolie17.scr|
|[30265105f1efc626e0b6eab9e5ba4292](https://www.virustotal.com/gui/file/30265105f1efc626e0b6eab9e5ba4292)|Win32 EXE||2016-04-07 20:41:46|30265105f1efc626e0b6eab9e5ba4292.virus|
|[877b69d3a4a1107bed3de216d63097e1](https://www.virustotal.com/gui/file/877b69d3a4a1107bed3de216d63097e1)|Win32 EXE|Zbot|2016-04-02 08:51:27|WindowsUpdateService.exe|
|[0513cc7750a207fdb62b2ecf655a32bc](https://www.virustotal.com/gui/file/0513cc7750a207fdb62b2ecf655a32bc)|Win64 EXE||2016-04-02 08:35:16|Wextract|
|[bf1c8ff4541075312d7c2eef667510e4](https://www.virustotal.com/gui/file/bf1c8ff4541075312d7c2eef667510e4)|Win64 EXE|Zbot|2016-03-30 02:33:58|Wextract|
|[7af2778d0c5d2b01ebbb928cdd2c4579](https://www.virustotal.com/gui/file/7af2778d0c5d2b01ebbb928cdd2c4579)|Win32 EXE||2016-03-30 02:28:47|Nicole010.scr|
|[c8df50c71ef03450ed3b65b773266185](https://www.virustotal.com/gui/file/c8df50c71ef03450ed3b65b773266185)|Win32 EXE|Zbot|2016-03-30 02:10:42|Windows_Service_Update.exe|
|[a2ed15750fb200a5e158adf3930da99a](https://www.virustotal.com/gui/file/a2ed15750fb200a5e158adf3930da99a)|Win32 EXE|Zbot|2016-03-29 17:30:54|MkPlayer.exe|
|[b6c65ddb88b9ebf4e5de37d802daa61b](https://www.virustotal.com/gui/file/b6c65ddb88b9ebf4e5de37d802daa61b)|Win32 EXE|Zbot|2016-03-23 15:46:30| |
|[3b3e19eb59b1c0e0f1849a9c94ce87c7](https://www.virustotal.com/gui/file/3b3e19eb59b1c0e0f1849a9c94ce87c7)|Win32 EXE|Zbot|2016-03-21 09:21:54|Windows_Service_Update.exe|
|[f8f5b9d839be111797336f095c5155e1](https://www.virustotal.com/gui/file/f8f5b9d839be111797336f095c5155e1)|Win64 EXE||2016-03-21 09:05:23|Wextract|
|[7472cec8eff3d46a95c6446cee42664a](https://www.virustotal.com/gui/file/7472cec8eff3d46a95c6446cee42664a)|Win32 EXE||2016-03-21 08:48:48|Nicole Kidman.scr|
|[5ae2b492adabd26f8993eb7882f3e0d4](https://www.virustotal.com/gui/file/5ae2b492adabd26f8993eb7882f3e0d4)|Win32 EXE|Zbot|2016-03-20 08:31:53|WindowsUpdateService.exe|
|[650ea6fafd903eb1f733f6969ce285db](https://www.virustotal.com/gui/file/650ea6fafd903eb1f733f6969ce285db)|Win64 EXE|Zbot|2016-03-20 08:15:08|Wextract|
|[2c74dfe9b135414b26a16b1da524212a](https://www.virustotal.com/gui/file/2c74dfe9b135414b26a16b1da524212a)|Win32 EXE|dynamer|2016-03-20 07:59:00|Love04.scr|
|[d97819d9bcfd51df406a105c73abe943](https://www.virustotal.com/gui/file/d97819d9bcfd51df406a105c73abe943)|Win32 EXE|Zbot|2016-03-18 06:34:34|WindowsUpdateService.exe|
|[6f42e0522b807d2b90aaf050a7be7f44](https://www.virustotal.com/gui/file/6f42e0522b807d2b90aaf050a7be7f44)|Win64 EXE|Zbot|2016-03-17 22:09:05|Wextract|
|[55dc61056837ec8829c0f3c8e85cb7b3](https://www.virustotal.com/gui/file/55dc61056837ec8829c0f3c8e85cb7b3)|Win32 EXE|starter|2016-03-17 12:17:44|Love06.scr|
|[bcfaa94b32794cb15f2f2ee94e62f8fb](https://www.virustotal.com/gui/file/bcfaa94b32794cb15f2f2ee94e62f8fb)|Win32 EXE|Zbot|2016-02-21 16:36:15|VLC.exe|
|[11d5c0f9ac173d39d56df971eb39871c](https://www.virustotal.com/gui/file/11d5c0f9ac173d39d56df971eb39871c)|Win32 EXE|kasperagent|2016-02-21 07:55:41|21طلقة تواجه مصر.doc.scr|
|[a43786be4753a8c334fe1a56c6c3cde4](https://www.virustotal.com/gui/file/a43786be4753a8c334fe1a56c6c3cde4)|Win32 EXE|strictor|2016-02-17 17:08:37|VLC.exe|
|[c6e91b8e890acc9a7d229e25eddd5456](https://www.virustotal.com/gui/file/c6e91b8e890acc9a7d229e25eddd5456)|Win32 EXE|kasperagent|2016-02-15 09:47:38|c6e91b8e890acc9a7d229e25eddd5456.virus|
|[a62df9622812975e8286406e4becaf11](https://www.virustotal.com/gui/file/a62df9622812975e8286406e4becaf11)|Win32 EXE|Zbot|2016-02-14 17:52:47|MKplayer.exe|
|[c16ec71e62918453ebc2682ae3181bda](https://www.virustotal.com/gui/file/c16ec71e62918453ebc2682ae3181bda)|Win32 EXE||2015-10-21 13:30:19|DATA.scr|
|[7ada27b89b68bf294f547ed64b45ebc0](https://www.virustotal.com/gui/file/7ada27b89b68bf294f547ed64b45ebc0)|Win32 EXE|kasperagent|2015-10-21 13:30:18|N.M.A.scr|
|[121e39a5b83376b5e1dc3d3262bffafa](https://www.virustotal.com/gui/file/121e39a5b83376b5e1dc3d3262bffafa)|Win32 EXE|Zbot|2015-10-12 19:25:10|Faces of love Explicit video mp4.scr|
|[f63c43dbaf805c9321ec61ea64d70781](https://www.virustotal.com/gui/file/f63c43dbaf805c9321ec61ea64d70781)|Win32 EXE||2015-10-12 12:35:32|VLC media player.exe|
|[558f4c4f0b03d00625f551e943fb4e11](https://www.virustotal.com/gui/file/558f4c4f0b03d00625f551e943fb4e11)|Win32 EXE|Zbot|2015-10-11 14:48:33|happy-pirthdy.scr|
|[bff8b8c7d07d31c281b504d095ef8de1](https://www.virustotal.com/gui/file/bff8b8c7d07d31c281b504d095ef8de1)|Win32 EXE|Zbot|2015-10-08 16:03:24|doniaaa.scr|
|[dc59cd0ed1aba2692bad6dfe13bbf8b2](https://www.virustotal.com/gui/file/dc59cd0ed1aba2692bad6dfe13bbf8b2)|Win32 EXE|Zbot|2015-10-08 16:03:22|suzzzan.scr|
|[1e4d141f50380c3dd83885e00081a2f8](https://www.virustotal.com/gui/file/1e4d141f50380c3dd83885e00081a2f8)|Win32 EXE|kasperagent|2015-10-08 14:16:05|heeend.scr|
|[86ea790bee92bf054a245d07a3bfa02c](https://www.virustotal.com/gui/file/86ea790bee92bf054a245d07a3bfa02c)|Win32 EXE|kasperagent|2015-10-08 11:40:26|myfile.exe|
|[aa565dabb57563bb9c1310bd239c18cc](https://www.virustotal.com/gui/file/aa565dabb57563bb9c1310bd239c18cc)|Win32 EXE|Zbot|2015-10-08 11:36:43|Donea Amjd Video mp4.scr|
|[b607580b0c5f463d7ac54fc500a4f298](https://www.virustotal.com/gui/file/b607580b0c5f463d7ac54fc500a4f298)|Win32 EXE|Zbot|2015-10-08 11:36:42|Suzan Batheesh Video mp4?.scr|
|[721ae60bbc28c8992f1476b393ee5210](https://www.virustotal.com/gui/file/721ae60bbc28c8992f1476b393ee5210)|Win32 EXE|Zbot|2015-10-07 20:33:54|DE2.exe|
|[c01b725e0cb4ea76cc9d70ef2301622f](https://www.virustotal.com/gui/file/c01b725e0cb4ea76cc9d70ef2301622f)|Win32 EXE|kasperagent|2015-08-18 07:58:08|????? ????                                                                               .scr|
|[0b0d561d832e7382d9b6b73aada91a96](https://www.virustotal.com/gui/file/0b0d561d832e7382d9b6b73aada91a96)|Win32 EXE|kasperagent|2015-08-17 15:03:06|___.doc|
|[d1f1a0c736e5f7867802aa7fbba9f35f](https://www.virustotal.com/gui/file/d1f1a0c736e5f7867802aa7fbba9f35f)|Win32 EXE||2015-08-14 14:39:42| |
|[fc8cb7e39d5b54740f0cf3d44e3de5e1](https://www.virustotal.com/gui/file/fc8cb7e39d5b54740f0cf3d44e3de5e1)|Win32 EXE||2015-08-13 03:31:49|skype.exe|
|[03b14dff4714e11e6cfa5f78d976a432](https://www.virustotal.com/gui/file/03b14dff4714e11e6cfa5f78d976a432)|Win32 EXE||2015-08-12 03:22:31|myfile.exe|
|[52b32d172579640474a4537744fc522e](https://www.virustotal.com/gui/file/52b32d172579640474a4537744fc522e)|Win32 EXE|kasperagent|2015-08-10 07:19:45|????? ???? ????????? .scr|
|[f1105cb2d34b0b98f8298584c11f66dc](https://www.virustotal.com/gui/file/f1105cb2d34b0b98f8298584c11f66dc)|Win32 EXE|kasperagent|2015-08-09 09:25:30|قواعد هامة للمجاهدين .scr|
|[440bb797002b2cae03987f7395405795](https://www.virustotal.com/gui/file/440bb797002b2cae03987f7395405795)|Win32 EXE|kasperagent|2015-08-09 09:21:08|jsx.exe|
|[8a574181ed2efe4c2b02efd9a4ac0ece](https://www.virustotal.com/gui/file/8a574181ed2efe4c2b02efd9a4ac0ece)|Win32 EXE|kasperagent|2015-08-06 15:49:37|N.exe|
|[34ffb9375de5fb2e5d976316000e561d](https://www.virustotal.com/gui/file/34ffb9375de5fb2e5d976316000e561d)|Android|androidos|2010-08-16 07:49:58|E:\whiteset_benny\brut.googlemaps_f61b10e24cf228f1dc6fae34db749beb901d6c86|
|[0b6775113343412fcd75d8b35d2c1520](https://www.virustotal.com/gui/file/0b6775113343412fcd75d8b35d2c1520)|Android||2020-03-04 11:41:19|New_Mygram_IM.apk|
|[0b6775113343412fcd75d8b35d2c1520](https://www.virustotal.com/gui/file/0b6775113343412fcd75d8b35d2c1520)|Android||2020-03-04 11:41:19|New_Mygram_IM.apk|
|[63a0c10dfd3e89683a476fa7e319e017](https://www.virustotal.com/gui/file/63a0c10dfd3e89683a476fa7e319e017)|Android||2020-10-14 07:51:05|MyGramIM.signed.apk|
|[471313cb47c6165ec74088fafb9a5545](https://www.virustotal.com/gui/file/471313cb47c6165ec74088fafb9a5545)|Win32 EXE||2020-10-12 10:40:09|6Tb1ay5kTdAd2Ma29N0wHz2ixgEd7xh4K9F5onZ4.exe|
|[006b96fd401a462f084664bbb58344f9](https://www.virustotal.com/gui/file/006b96fd401a462f084664bbb58344f9)|DOCX||2020-10-11 08:26:10|C:\Users\<USER>\AppData\Local\Temp\cv AYA ALI 888.docx|
|[c12b3336f5efc8e83fcace6f81b27642](https://www.virustotal.com/gui/file/c12b3336f5efc8e83fcace6f81b27642)|Win32 EXE|Delf|2020-10-11 08:23:56|cv AYA ALI 888_8630973_43897309634.exe|
|[c76402446b83840dd2d3635522874f8c](https://www.virustotal.com/gui/file/c76402446b83840dd2d3635522874f8c)|Android||2020-10-04 20:01:27|WhispersTalk.apk|
|[0425bc5de50da34fb7be133851a3193d](https://www.virustotal.com/gui/file/0425bc5de50da34fb7be133851a3193d)|Android||2020-06-21 12:48:33|/1/5/4/54f2aa690954ddfcd72e0915147378dd9a7228954b05c54da3605611b2d5a55e.file|
|[6903e3646c29f4f8a2187880025123f1](https://www.virustotal.com/gui/file/6903e3646c29f4f8a2187880025123f1)|GZIP||2020-06-15 02:15:38| |
|[46cd3890b5d6586bfcc940beb7d6bfe4](https://www.virustotal.com/gui/file/46cd3890b5d6586bfcc940beb7d6bfe4)|Android||2020-06-11 13:46:50|Telegram.apk|
|[af0e580b67938afaeb783b72cf2a1c61](https://www.virustotal.com/gui/file/af0e580b67938afaeb783b72cf2a1c61)|Android||2020-06-10 12:11:55|Telegram.apk|
|[c117c946094f3a1bbc5ef714873ce183](https://www.virustotal.com/gui/file/c117c946094f3a1bbc5ef714873ce183)|Win32 EXE|occamy|2020-05-13 09:05:22|WindowsHelpCort.exe|
|[f303e8ef98e6326545838cee0105cd4e](https://www.virustotal.com/gui/file/f303e8ef98e6326545838cee0105cd4e)|Android||2020-04-15 23:03:05|PureTalk.apk|
|[d35ff5620e18bf5aba1d2396828436ca](https://www.virustotal.com/gui/file/d35ff5620e18bf5aba1d2396828436ca)|Android||2020-04-14 12:46:42|New_Mygram_IM121.apk|
|[ccc7a35a3977e2a4859f1dc8becca6b7](https://www.virustotal.com/gui/file/ccc7a35a3977e2a4859f1dc8becca6b7)|Android||2020-04-14 12:43:24|New_Mygram_IM121.apk|
|[8d8c011ae462913386f63974bd239a60](https://www.virustotal.com/gui/file/8d8c011ae462913386f63974bd239a60)|Android||2020-03-17 11:55:41|android_q.apk|
|[1eb1923e959490ee9f67687c7faec697](https://www.virustotal.com/gui/file/1eb1923e959490ee9f67687c7faec697)|Win32 EXE|Delf|2020-02-26 06:53:36|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[8d50262448d0c174fc30c02e20ca55ff](https://www.virustotal.com/gui/file/8d50262448d0c174fc30c02e20ca55ff)|Win32 EXE|Strictor|2020-02-24 05:18:55|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[46871f3082e2d33f25111a46dfafd0a6](https://www.virustotal.com/gui/file/46871f3082e2d33f25111a46dfafd0a6)|Win32 EXE|Strictor|2020-02-16 07:08:10|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[817861fce29bac3b28f06615b4f1803f](https://www.virustotal.com/gui/file/817861fce29bac3b28f06615b4f1803f)|DOC|o97m|2020-02-02 12:52:19|السيرة الذاتية منال1.doc|
|[a7cf4df8315c62dbebfbfea7553ef749](https://www.virustotal.com/gui/file/a7cf4df8315c62dbebfbfea7553ef749)|Win32 EXE|Strictor|2020-01-29 11:08:26|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[09cd0da3fb00692e714e251bb3ee6342](https://www.virustotal.com/gui/file/09cd0da3fb00692e714e251bb3ee6342)|Win32 EXE|Delf|2020-01-22 19:22:17|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[e8effd3ad2069ff8ff6344b85fc12dd6](https://www.virustotal.com/gui/file/e8effd3ad2069ff8ff6344b85fc12dd6)|Win32 EXE||2020-01-22 12:29:16|80fb33854bf54ceac731aed91c677d8fb933d1593eb95447b06bd9b80f562ed2.sample|
|[91f83b03651bb4d1c0a40e29fc2c92a1](https://www.virustotal.com/gui/file/91f83b03651bb4d1c0a40e29fc2c92a1)|DOC|Sagent|2020-01-22 08:41:44|b33f22b967a5be0e886d479d47d6c9d35c6639d2ba2e14ffe42e7d2e5b11ad80.doc.bin|
|[20d21c75b92be3cfcd5f69a3ef1deed2](https://www.virustotal.com/gui/file/20d21c75b92be3cfcd5f69a3ef1deed2)|Win32 EXE||2020-01-20 12:09:44|617132.exe|
|[3296b51479c7540331233f47ed7c38dd](https://www.virustotal.com/gui/file/3296b51479c7540331233f47ed7c38dd)|Win32 EXE|Delf|2020-01-14 09:58:48|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[90cdf5ab3b741330e5424061c7e4b2e2](https://www.virustotal.com/gui/file/90cdf5ab3b741330e5424061c7e4b2e2)|Win32 EXE|Zbot|2019-12-21 09:07:07|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[9bb70dfa2e39be46278fb19764a6149a](https://www.virustotal.com/gui/file/9bb70dfa2e39be46278fb19764a6149a)|Win32 EXE|Zbot|2019-12-16 21:05:24|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[4d9b6b0e7670dd5919b188cb71d478c0](https://www.virustotal.com/gui/file/4d9b6b0e7670dd5919b188cb71d478c0)|Win32 EXE||2019-12-11 19:25:41|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[edc3b146a5103051b39967246823ca09](https://www.virustotal.com/gui/file/edc3b146a5103051b39967246823ca09)|Win32 EXE|Graftor|2019-12-09 22:25:47|%PROGRAMDATA%\syncdownoptzhostproc.exe|
|[fc5b2c81debf30d251d5220097c2f846](https://www.virustotal.com/gui/file/fc5b2c81debf30d251d5220097c2f846)|Win32 EXE||2019-11-08 21:46:54|fc5b2c81debf30d251d5220097c2f846.virus|
|[dd8485d87d8998d47de4f5dfcc9213e1](https://www.virustotal.com/gui/file/dd8485d87d8998d47de4f5dfcc9213e1)|Android|androidos|2019-05-21 10:58:06|29ac6e5719aeb0cba63b837ca2cbdb6483044ed5a885c457f6858ae61e2dd4da.bin|
