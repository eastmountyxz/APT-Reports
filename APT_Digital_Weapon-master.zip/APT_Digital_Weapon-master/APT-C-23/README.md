**NAME:**  
APT-C-23  
  
**Alias**  
双尾蝎, Arid Viper, Desert Falcon, AridViper, Big Bang, APT-C-23  

**Description**:   
Since May 2016, APT-C-23 carried out organized and persistent attacks against important areas such as Palestinian educational institutions and military institutions. Native Arabic-speaking cybercriminals have built advanced methods and tools to deliver, hide and operate malware to compromise Windows and Android platform used by specific targets.

Subsequently, some foreign security vendors also linked the Big Bang attack to APT-C-23.

  
**References**:  
https://ti.qianxin.com/uploads/2018/01/26/f41a337e10e992f17986af386a62c7ad.pdf
