**NAME:**  
Outlaw  

**Description**:   
Outlaw group, uncovered by TrendMicro, distributes Botnet for cryptocurrency mining, scanning, and brute-force. The attacking bot used a tool called haiduc to search the internet for systems to attack.
  
**References**:  
https://blog.trendmicro.com/trendlabs-security-intelligence/outlaw-group-distributes-botnet-for-cryptocurrency-mining-scanning-and-brute-force/
