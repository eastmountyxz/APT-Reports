**NAME:**  
MartyMcFly  

**Description**:   
MartyMcFly is first discovered by Yoroi and found to targeting Italian naval industries. Kaspersky exposed a wider threat extension across multiple countries such as: Germany, Spain, and India. The group conducts massive campaigns that involve sending phishing emails to various companies, some of which are critical infrastructure facilities. The objective of such groups is to steal financial data and money.

**References**:  
https://blog.yoroi.company/research/the-martymcfly-investigation-anchors-chain-case/