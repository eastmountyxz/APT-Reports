|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[66b239615333c3eefb8d4bfb9999291e](https://www.virustotal.com/gui/file/66b239615333c3eefb8d4bfb9999291e)|Win32 EXE|Quasar|2018-10-12 10:25:39|GEqy87.exe|
|[fdc10df508d4747a6bffbfa5e72bbb42](https://www.virustotal.com/gui/file/fdc10df508d4747a6bffbfa5e72bbb42)|Win32 EXE|LokiBot|2018-10-09 15:19:05|GEqy87.exe|
|[5c947b48e737648118288cb04d2abd7b](https://www.virustotal.com/gui/file/5c947b48e737648118288cb04d2abd7b)|FPX||2018-10-09 11:50:47|QUOTATION= MARINE SPARE PARTS|
|[7c9576123a35749c1699f53a1206577e](https://www.virustotal.com/gui/file/7c9576123a35749c1699f53a1206577e)|PDF|phishing|2018-08-20 20:45:47|Marine_Engine_Spare__Parts_Order.pdf|
|[4cd270fd943448d595bfd6b0b638ad10](https://www.virustotal.com/gui/file/4cd270fd943448d595bfd6b0b638ad10)|HTML|phishing|2017-07-22 20:59:59|myfile.exe|
