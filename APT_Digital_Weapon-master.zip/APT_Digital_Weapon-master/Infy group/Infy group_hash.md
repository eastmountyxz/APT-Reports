|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[2a1294ac176e9949362f088fa45df777](https://www.virustotal.com/gui/file/2a1294ac176e9949362f088fa45df777)|Win32 EXE||2018-01-09 04:49:26|SWSOC.EXE|
|[70c447c9e71c8e6bd336670119e8df1b](https://www.virustotal.com/gui/file/70c447c9e71c8e6bd336670119e8df1b)|Win32 EXE||2017-03-20 04:50:43|70c447c9e71c8e6bd336670119e8df1b.virus|
|[ac8d334c5f519d5d146e7949036be964](https://www.virustotal.com/gui/file/ac8d334c5f519d5d146e7949036be964)|Win32 EXE||2016-04-15 12:05:53| |
|[4b6e12709a2e708e682296d00383e0d8](https://www.virustotal.com/gui/file/4b6e12709a2e708e682296d00383e0d8)|Win32 EXE|Delf|2016-04-15 12:01:55| |
|[aa4cfb13a699eafb60e4ea0fb602f144](https://www.virustotal.com/gui/file/aa4cfb13a699eafb60e4ea0fb602f144)|Win32 DLL|Delf|2016-03-18 18:52:18|airplugin.v1.7.5.dll|
|[bd5c838a2f00dd5fd9ab9ebe0cb2528e](https://www.virustotal.com/gui/file/bd5c838a2f00dd5fd9ab9ebe0cb2528e)|Win32 EXE|Delf|2016-03-18 18:52:07|28758901_ins3504.exe|
|[47fcbd8058ec08f2da3ff184b4de0d79](https://www.virustotal.com/gui/file/47fcbd8058ec08f2da3ff184b4de0d79)|Win32 EXE|Delf|2016-02-25 00:11:34| |
|[6e6bc3d845aa23c2fa38f361c5b93814](https://www.virustotal.com/gui/file/6e6bc3d845aa23c2fa38f361c5b93814)|Win32 DLL|Delf|2016-02-25 00:08:24| |
|[5598951815d4c39a9ad76188354666b5](https://www.virustotal.com/gui/file/5598951815d4c39a9ad76188354666b5)|Win32 EXE|Delf|2016-02-24 23:39:21| |
|[f8edf0879030e511bad759a9fe588a15](https://www.virustotal.com/gui/file/f8edf0879030e511bad759a9fe588a15)|Win32 EXE|Emotet|2016-01-15 13:41:31|/mnt/staging/thomas/extracted/samples_20151223/f8edf0879030e511bad759a9fe588a15|
|[69b075a20f94532f8f82100a418de1f2](https://www.virustotal.com/gui/file/69b075a20f94532f8f82100a418de1f2)|Win32 DLL|Delf|2016-01-14 00:49:19| |
|[ba5e2404e99f874eae7ba4a4179a5a0d](https://www.virustotal.com/gui/file/ba5e2404e99f874eae7ba4a4179a5a0d)|Win32 EXE|Delf|2016-01-14 00:49:10| |
|[cdcb1bf7a92c206be4f2f8493424f97b](https://www.virustotal.com/gui/file/cdcb1bf7a92c206be4f2f8493424f97b)|Win32 EXE||2016-01-13 17:00:41|cdcb1bf7a92c206be4f2f8493424f97b.virus|
|[1018960f13469a54e48eb4468b119d24](https://www.virustotal.com/gui/file/1018960f13469a54e48eb4468b119d24)|Win32 DLL||2016-01-13 06:43:02|1018960f13469a54e48eb4468b119d24.virus|
|[c30614492d31e60511fb8b28fea653ef](https://www.virustotal.com/gui/file/c30614492d31e60511fb8b28fea653ef)|Win32 DLL|Symmi|2015-12-27 17:35:12| |
|[d78d5dcbab09d3f1276dd825d74a55be](https://www.virustotal.com/gui/file/d78d5dcbab09d3f1276dd825d74a55be)|Win32 EXE||2015-12-19 06:10:58|95.exe|
|[16089210258939642c427188e70b3c2b](https://www.virustotal.com/gui/file/16089210258939642c427188e70b3c2b)|Win32 EXE||2015-12-18 20:45:36|ins7634.exe|
|[9f6f3cad4657ee521b4c9a6099ebd3f5](https://www.virustotal.com/gui/file/9f6f3cad4657ee521b4c9a6099ebd3f5)|Win32 DLL|Symmi|2015-12-17 18:43:30| |
|[2fce0cc603d4a8b23c86d47bf55ad570](https://www.virustotal.com/gui/file/2fce0cc603d4a8b23c86d47bf55ad570)|Win32 EXE|Delf|2015-12-06 00:55:39| |
|[e9117eda1f943c53a02942d2e7039fb2](https://www.virustotal.com/gui/file/e9117eda1f943c53a02942d2e7039fb2)|Win32 DLL|Delf|2015-12-05 16:55:45|mpro365.dll|
|[6e4e52cf69e37d2d540a431f23d7015a](https://www.virustotal.com/gui/file/6e4e52cf69e37d2d540a431f23d7015a)|Win32 EXE|Delf|2015-12-03 11:19:56|c:\Windows\system32\ipconfig.exe|
|[1a918a850892c2ca5480702c64c3454c](https://www.virustotal.com/gui/file/1a918a850892c2ca5480702c64c3454c)|Win32 EXE||2015-12-03 03:20:54|v28n1f1.tmp|
|[17e0b1e735f43bd15662325f37ad3816](https://www.virustotal.com/gui/file/17e0b1e735f43bd15662325f37ad3816)|Win32 DLL|Delf|2015-12-03 03:19:23|C__DOCUME~1_ADMINI~1_LOCALS~1_Temp_tmp8630_mpro263.dllx|
|[c4d8b12a70cf01df681712f1a2ddf0fb](https://www.virustotal.com/gui/file/c4d8b12a70cf01df681712f1a2ddf0fb)|Win32 DLL||2015-11-21 18:47:29| |
|[ded4f175d84044c10fe1d3a629918f67](https://www.virustotal.com/gui/file/ded4f175d84044c10fe1d3a629918f67)|Win32 EXE|Delf|2015-10-29 06:10:02|d718e6a861fc74cd47626fdb5dd8559a|
|[6852787a390630ba38920c2998e60151](https://www.virustotal.com/gui/file/6852787a390630ba38920c2998e60151)|Win32 DLL|ursu|2015-10-26 00:58:04| |
|[d1a25ebf70a88fd76c3a7501733f1e24](https://www.virustotal.com/gui/file/d1a25ebf70a88fd76c3a7501733f1e24)|Win32 DLL|ursu|2015-10-11 11:08:15| |
|[d78149cd7ee8a37ced029d168ed776e9](https://www.virustotal.com/gui/file/d78149cd7ee8a37ced029d168ed776e9)|Win32 DLL|ursu|2015-10-05 06:21:24|airplugin.v3.35.8.dll|
|[d9da6c95fb6a5cbefb2fcac169c61b59](https://www.virustotal.com/gui/file/d9da6c95fb6a5cbefb2fcac169c61b59)|Win32 EXE||2015-10-02 00:44:06|c:\Windows\system32\grpconv.exe|
|[bb8bff333eb1fb47b1b020b5696e00f3](https://www.virustotal.com/gui/file/bb8bff333eb1fb47b1b020b5696e00f3)|Win32 DLL|Delf|2015-07-20 13:40:12| |
|[ef389dde0e84fb495e9b59c61293f525](https://www.virustotal.com/gui/file/ef389dde0e84fb495e9b59c61293f525)|Win32 DLL||2015-07-06 17:10:32| |
|[95f0b3a442f0f14746d367e4273c787b](https://www.virustotal.com/gui/file/95f0b3a442f0f14746d367e4273c787b)|Win32 EXE|Delf|2015-06-21 09:12:27|m:\dailytesters\vl\0\0D1B2B005A5B28D44553F65C6CE15945\fe8152039bb75a2dda018cb8afd6f2ff0137865ce2cf04adc40ced85d2dd995a.exe|
|[83e90ccf2523cce6dec582cdc3ddf76b](https://www.virustotal.com/gui/file/83e90ccf2523cce6dec582cdc3ddf76b)|PPT||2015-06-17 19:09:38|dunya.pps|
|[fcee2e1dd2188d28bd0530c46ca66ab4](https://www.virustotal.com/gui/file/fcee2e1dd2188d28bd0530c46ca66ab4)|Win32 DLL||2015-06-12 21:10:01| |
|[0c4794ee8211d030fbaf72ffd028b302](https://www.virustotal.com/gui/file/0c4794ee8211d030fbaf72ffd028b302)|Win32 EXE||2015-06-12 21:09:57| |
|[b4b1d37845a5448ba394c751fc481d63](https://www.virustotal.com/gui/file/b4b1d37845a5448ba394c751fc481d63)|Win32 EXE|dynamer|2015-06-12 04:10:19|c5b8e9a40e93f8663733051ceef5636ea55647f2|
|[303b7700fb36ec54c20a0e2bef38a9cd](https://www.virustotal.com/gui/file/303b7700fb36ec54c20a0e2bef38a9cd)|Win32 EXE|Delf|2015-06-10 22:34:43|m:\dailytesters\vl\4\47EC05A079A0DAC22EB42AC6FA1BC581\48B5E5BDBC1E5FD2D46D85482888923BDA6896EAB491AD25FE0DE4B84D68CC2A.EXE|
|[a161fc64a9c659264d0a897201a1b51d](https://www.virustotal.com/gui/file/a161fc64a9c659264d0a897201a1b51d)|Win32 DLL||2015-06-10 22:34:40| |
|[12973584deae59421ed99e3adde993ee](https://www.virustotal.com/gui/file/12973584deae59421ed99e3adde993ee)|Win32 DLL||2015-05-30 19:54:07| |
|[5cccc95e3795c347d1609c62f3127da5](https://www.virustotal.com/gui/file/5cccc95e3795c347d1609c62f3127da5)|Win32 EXE||2015-05-30 00:47:40|5cccc95e3795c347d1609c62f3127da5.virus|
|[f37bbbf212ad212dbcbf45e771226f70](https://www.virustotal.com/gui/file/f37bbbf212ad212dbcbf45e771226f70)|Win32 DLL|Zbot|2015-05-11 08:25:52|mpro977.dll|
|[29cc209a96cea4fe241373c784fed35c](https://www.virustotal.com/gui/file/29cc209a96cea4fe241373c784fed35c)|Win32 EXE|dynamer|2015-05-11 04:07:16|8de437bcfe5e95826ad996cec44b7a09897c4a5d|
|[1955f324552812e3fc8f4513cc058674](https://www.virustotal.com/gui/file/1955f324552812e3fc8f4513cc058674)|Win32 DLL|Zbot|2015-04-17 09:13:47|mpro842.dll|
|[5ab14c2503fca14ca416d3bc0ae62a8d](https://www.virustotal.com/gui/file/5ab14c2503fca14ca416d3bc0ae62a8d)|Win32 EXE||2015-04-17 01:13:45|ins221.exe|
|[e2f6adfa24b9750746cdae6ee15b3b56](https://www.virustotal.com/gui/file/e2f6adfa24b9750746cdae6ee15b3b56)|Win32 DLL|Symmi|2015-03-10 11:41:20|mpro764.cp_|
|[72207024854e6c8e83996f3baa659e6b](https://www.virustotal.com/gui/file/72207024854e6c8e83996f3baa659e6b)|Win32 DLL|Delf|2015-03-09 11:12:11|mpro480.dll|
|[9f926c3ce839f5c2cce936cf7424da0c](https://www.virustotal.com/gui/file/9f926c3ce839f5c2cce936cf7424da0c)|Win32 DLL|Symmi|2015-03-07 18:26:32|C:/Users/seongmin/Documents/VT2/malware/20170925/9f926c3ce839f5c2cce936cf7424da0c.vir|
|[1f6886dd68f7d1e02f6de08d43432487](https://www.virustotal.com/gui/file/1f6886dd68f7d1e02f6de08d43432487)|Win32 EXE||2015-02-18 03:51:58|m:\realfinalset\finalset\#\ESET\W\Win32.Spy.Delf.PYX trojan\3821bb3594c35f82dcab1423019e997cb4d7f66ac4ce96a41ec0260c6ac8eb84.exe|
|[7e9552cbe1afdb03cedff301f2080f9c](https://www.virustotal.com/gui/file/7e9552cbe1afdb03cedff301f2080f9c)|Win32 DLL|Zbot|2015-02-17 19:51:34| |
|[260687b5a29d9a8947d514acae695ad4](https://www.virustotal.com/gui/file/260687b5a29d9a8947d514acae695ad4)|PPT|Delf|2015-01-22 13:27:45|260687b5a29d9a8947d514acae695ad4|
|[44e6101ee0d2a267dd5a71de9ff3d49b](https://www.virustotal.com/gui/file/44e6101ee0d2a267dd5a71de9ff3d49b)|Win32 DLL|Symmi|2014-12-13 20:05:36|airplugin.v8.2.9.cpl|
|[cc6fd51232b35cff84b6c3d9bfc6be4c](https://www.virustotal.com/gui/file/cc6fd51232b35cff84b6c3d9bfc6be4c)|PPT|bitrep|2014-12-01 19:43:30|kheir.pps|
|[bc8c1f72d0813c281c9a1e4a3fb10f5e](https://www.virustotal.com/gui/file/bc8c1f72d0813c281c9a1e4a3fb10f5e)|Win32 EXE|Ursu|2014-11-26 03:57:08|bc8c1f72d0813c281c9a1e4a3fb10f5e|
|[4462402c80795fec584b0fef4b30ecf3](https://www.virustotal.com/gui/file/4462402c80795fec584b0fef4b30ecf3)|Win32 DLL|ursu|2014-11-25 08:35:16|e1594635c803869664092de0ffb1cfad21fe467a|
|[25fee0f3a3296a624db0dff85fbddb79](https://www.virustotal.com/gui/file/25fee0f3a3296a624db0dff85fbddb79)|Win32 EXE||2014-11-25 00:35:06|ins714.exe|
|[df70cff8cabf0cfc1eb9754020982c49](https://www.virustotal.com/gui/file/df70cff8cabf0cfc1eb9754020982c49)|Win32 EXE||2014-10-14 11:34:36|vt-upload-Hkxng|
|[086f4d1411e2209bb321d3fa75bf0a6f](https://www.virustotal.com/gui/file/086f4d1411e2209bb321d3fa75bf0a6f)|Win32 EXE|Delf|2014-10-14 10:44:07|vt-upload-aEeAI|
|[55d11e996ef37a99ddbedc9847dcc55b](https://www.virustotal.com/gui/file/55d11e996ef37a99ddbedc9847dcc55b)|Win32 DLL|Symmi|2014-10-07 21:28:08|mpro721.cpl|
|[ffad81c9cc9a6d1bd77b29c5be16d1b0](https://www.virustotal.com/gui/file/ffad81c9cc9a6d1bd77b29c5be16d1b0)|PPT||2014-10-07 18:39:54|2.ppt|
|[591d59fcc263dfc4f5c4aed12aea7f0c](https://www.virustotal.com/gui/file/591d59fcc263dfc4f5c4aed12aea7f0c)|PPT|tspy|2014-10-04 08:13:07|4e37491e7a25c029c5ec6738c57f9d08d551162baf276d9fb576b6849badaf5a.ppt|
|[c6f27fe0ba7a877fecdc6227454d052f](https://www.virustotal.com/gui/file/c6f27fe0ba7a877fecdc6227454d052f)|Win32 DLL|Symmi|2014-09-30 11:19:25|C:/Users/seongmin/Documents/VT2/malware/20170827/c6f27fe0ba7a877fecdc6227454d052f.vir|
|[0cdb7ea63cd53ac9a99a9e8c6b7d98dd](https://www.virustotal.com/gui/file/0cdb7ea63cd53ac9a99a9e8c6b7d98dd)|Win32 EXE||2014-09-29 09:23:08|4398d635849ba7c909d62c6cea76e7ae875fd0d998d6e606e7e343b4194857b7.exe|
|[7c8e950c3adcbbcca2c8b54614566ec7](https://www.virustotal.com/gui/file/7c8e950c3adcbbcca2c8b54614566ec7)|Win32 DLL|Delf|2014-09-23 10:10:03|airplugin.v1.68.7.dll|
|[b74c6fbb8c0812797c726395b3bd812e](https://www.virustotal.com/gui/file/b74c6fbb8c0812797c726395b3bd812e)|Win32 EXE|Delf|2014-09-23 02:10:25|ins200.exe|
|[7b681f3bfa2b30b5fc909b130bbafd50](https://www.virustotal.com/gui/file/7b681f3bfa2b30b5fc909b130bbafd50)|PPT||2014-09-21 09:45:29|ayande.ir.pps|
|[6a963c5f650d6e3d56062eb0789e4a8b](https://www.virustotal.com/gui/file/6a963c5f650d6e3d56062eb0789e4a8b)|Win32 DLL|Delf|2014-08-13 06:01:14|6a963c5f650d6e3d56062eb0789e4a8b|
|[17234fa07e77ddb2a05f221e6aa9d335](https://www.virustotal.com/gui/file/17234fa07e77ddb2a05f221e6aa9d335)|Win32 EXE|Ursu|2014-08-11 12:21:10|SWSOC.EXE|
|[fd33a6c08159d1f688fe927076c1e441](https://www.virustotal.com/gui/file/fd33a6c08159d1f688fe927076c1e441)|Win32 DLL|Symmi|2014-08-10 09:10:05|vt-upload-KsD3y|
|[12d2cab3480c706f956da4a22c15ddb3](https://www.virustotal.com/gui/file/12d2cab3480c706f956da4a22c15ddb3)|Win32 DLL|Zbot|2014-07-08 11:25:57|vt-upload-9fG2n|
|[4ad5cc8dcf847be7c8787c02f06a5427](https://www.virustotal.com/gui/file/4ad5cc8dcf847be7c8787c02f06a5427)|Win32 EXE|Delf|2014-07-06 16:16:10|v000141f1.tmp|
|[b985a36d00033365bfd9b39cc95242b9](https://www.virustotal.com/gui/file/b985a36d00033365bfd9b39cc95242b9)|Win32 DLL|Delf|2014-07-03 10:15:40|vt-upload-aIONv|
|[eccc160b9e5a2caf4437896dd04bf6f6](https://www.virustotal.com/gui/file/eccc160b9e5a2caf4437896dd04bf6f6)|Win32 DLL|Delf|2014-06-27 04:40:16|eccc160b9e5a2caf4437896dd04bf6f6|
|[e99dd650695b19b7eb57868ee4251052](https://www.virustotal.com/gui/file/e99dd650695b19b7eb57868ee4251052)|Win32 DLL|Zbot|2014-06-25 10:13:30|e99dd650695b19b7eb57868ee4251052|
|[1c9c491dc0e20ca1a46677f9b5552ff3](https://www.virustotal.com/gui/file/1c9c491dc0e20ca1a46677f9b5552ff3)|Win32 DLL|Zbot|2014-06-25 10:07:22|1c9c491dc0e20ca1a46677f9b5552ff3|
|[109f613a3db75b78a8f2fc4f4d9c1aa3](https://www.virustotal.com/gui/file/109f613a3db75b78a8f2fc4f4d9c1aa3)|Win32 DLL|Symmi|2014-06-25 09:46:36|vt-upload-cMljp|
|[7cf09004bfb2833253d0d9faaadbbc2c](https://www.virustotal.com/gui/file/7cf09004bfb2833253d0d9faaadbbc2c)|Win32 DLL|Symmi|2014-06-25 09:12:53|7cf09004bfb2833253d0d9faaadbbc2c|
|[aa220955c78d5c4077249555d958dcb0](https://www.virustotal.com/gui/file/aa220955c78d5c4077249555d958dcb0)|Win32 DLL|Zbot|2014-06-25 08:58:08|aa220955c78d5c4077249555d958dcb0|
|[5e5709043f1113d87b309e91b3cfae7e](https://www.virustotal.com/gui/file/5e5709043f1113d87b309e91b3cfae7e)|Win32 EXE|Delf|2014-06-21 09:19:29|vt-upload-c3xOG|
|[99f4fdbbed01c6cccd014350d14b5817](https://www.virustotal.com/gui/file/99f4fdbbed01c6cccd014350d14b5817)|Win32 DLL||2014-05-28 03:28:58|mpro145.cpl|
|[d2bad8e2f9c5c813c1ab4c76ba9f9ab6](https://www.virustotal.com/gui/file/d2bad8e2f9c5c813c1ab4c76ba9f9ab6)|Win32 DLL|Symmi|2014-05-10 06:54:26|airplugin.v1.36.1.cpl|
|[cb635b1ff7443252cf3686a5a8c40efa](https://www.virustotal.com/gui/file/cb635b1ff7443252cf3686a5a8c40efa)|Win32 DLL||2014-05-05 07:50:13|vt-upload-tcIht|
|[0bec1d0a2487653801ed24422a89433b](https://www.virustotal.com/gui/file/0bec1d0a2487653801ed24422a89433b)|Win32 DLL|Symmi|2014-04-24 08:53:44|mpro419.cpl|
|[fcb02cdd979b12a25befef990977072a](https://www.virustotal.com/gui/file/fcb02cdd979b12a25befef990977072a)|Win32 EXE|Delf|2014-03-25 07:22:55|vti-rescan|
|[e3ecde087e1fc5a33cc04ab076e3d373](https://www.virustotal.com/gui/file/e3ecde087e1fc5a33cc04ab076e3d373)|Win32 EXE|Delf|2014-03-23 08:32:24|vt-upload-jO8bk|
|[7eab33c7b51c62b9396a75630f29090b](https://www.virustotal.com/gui/file/7eab33c7b51c62b9396a75630f29090b)|Win32 EXE|Delf|2014-03-20 11:15:56|/tmp/vt-upload-tzp9uP|
|[e88599c90a6884cd8341975e60ab6db9](https://www.virustotal.com/gui/file/e88599c90a6884cd8341975e60ab6db9)|Win32 DLL|Delf|2014-03-20 07:39:16|airplugin.v0.34.9.cpl|
|[94d9590903fd123329de054f6988a17e](https://www.virustotal.com/gui/file/94d9590903fd123329de054f6988a17e)|Win32 EXE|Delf|2014-03-20 07:34:48|vti-rescan|
|[80b1f897b670c27a30c9eca9e3d7d604](https://www.virustotal.com/gui/file/80b1f897b670c27a30c9eca9e3d7d604)|Win32 EXE||2014-03-05 20:10:20|80b1f897b670c27a30c9eca9e3d7d604|
|[c5eeae78cb820186f5f1acad6f1039af](https://www.virustotal.com/gui/file/c5eeae78cb820186f5f1acad6f1039af)|Win32 DLL|Symmi|2014-01-27 06:38:29|vt-upload-Hcrr1|
|[09f8655f862f0074b6648df4dd2bcc8b](https://www.virustotal.com/gui/file/09f8655f862f0074b6648df4dd2bcc8b)|Win32 DLL|Symmi|2013-12-01 19:32:11|5248b0eb5f568fab79208c49f3da2715e3aaa89a|
|[f15f75a3f633c334087be5005e5d60ce](https://www.virustotal.com/gui/file/f15f75a3f633c334087be5005e5d60ce)|Win32 DLL|Symmi|2013-11-26 02:45:42|e1d6e3abc2f3e63e450a4f09cf7551d9c37cccb9|
|[0c8c1e8b3ccab7b01f7a9246a994ee49](https://www.virustotal.com/gui/file/0c8c1e8b3ccab7b01f7a9246a994ee49)|Win32 DLL|Symmi|2013-11-22 23:33:33|c7e925ed4a5cc01bb4ddc7b3bbea641a6e1f1e4a|
|[2546f1499a347bfd7dbe79828560f043](https://www.virustotal.com/gui/file/2546f1499a347bfd7dbe79828560f043)|Win32 EXE|Delf|2013-11-09 00:42:39|vt-upload-fy8df|
|[123506172c5d84d2c2d046edd66a57c0](https://www.virustotal.com/gui/file/123506172c5d84d2c2d046edd66a57c0)|Win32 DLL|Symmi|2013-11-06 19:58:35|123506172c5d84d2c2d046edd66a57c0.virobj|
|[e64ceb2c9b2c8ba8709a139f6ba27ff6](https://www.virustotal.com/gui/file/e64ceb2c9b2c8ba8709a139f6ba27ff6)|Win32 EXE|Delf|2013-11-06 19:58:33|iOlYf6F3LW|
|[f1c06830c806dc0aaa6c9283bdc1777d](https://www.virustotal.com/gui/file/f1c06830c806dc0aaa6c9283bdc1777d)|Win32 EXE||2013-10-19 01:46:33|f1c06830c806dc0aaa6c9283bdc1777d|
|[8c7ec022ef9b6e8e30b6761da0975aea](https://www.virustotal.com/gui/file/8c7ec022ef9b6e8e30b6761da0975aea)|Win32 EXE|Delf|2013-10-14 23:21:22|4ffa56b27768139c394f6714d6582f7a687f7751|
|[7a6e9a6e87e1e43ad188f18ae42f470f](https://www.virustotal.com/gui/file/7a6e9a6e87e1e43ad188f18ae42f470f)|PPT||2013-10-01 11:28:11|yadesh bekheir.pp|
|[efbd383d5a5516445820b013d8f8e207](https://www.virustotal.com/gui/file/efbd383d5a5516445820b013d8f8e207)|Win32 EXE|Delf|2013-09-29 11:07:20|a1597e7855a3483012ca44191baeeaa758e4a2ef|
|[5acba38d707f3d5015e64550c7689c05](https://www.virustotal.com/gui/file/5acba38d707f3d5015e64550c7689c05)|Win32 DLL|Symmi|2013-09-27 02:16:03|bd60d2ce407e2fd08308521b0ad423f4d9ec15ca|
|[10eee810f70b9aee5d2784b79539f880](https://www.virustotal.com/gui/file/10eee810f70b9aee5d2784b79539f880)|Win32 EXE|Delf|2013-09-12 10:37:51|10eee810f70b9aee5d2784b79539f880|
|[f83ec55fe1c92f95656350deb44e804a](https://www.virustotal.com/gui/file/f83ec55fe1c92f95656350deb44e804a)|Win32 EXE||2013-09-09 22:10:37|vt-upload-VFL64|
|[79a07963b57d0bbae1625cf582d2a55a](https://www.virustotal.com/gui/file/79a07963b57d0bbae1625cf582d2a55a)|Win32 DLL|Symmi|2013-09-05 05:14:58|vt-upload-Q3rYW|
|[31e100ec9c9cf0ecef328a79b60a6455](https://www.virustotal.com/gui/file/31e100ec9c9cf0ecef328a79b60a6455)|Win32 EXE|Delf|2013-09-03 15:27:17|ins2845.exe|
|[578677cc3e31dab487280dc50c90ac4c](https://www.virustotal.com/gui/file/578677cc3e31dab487280dc50c90ac4c)|Win32 DLL|Delf|2013-09-03 15:26:35|mpro36.cpl|
|[91b7beb61cb7f7f7b42429d389477063](https://www.virustotal.com/gui/file/91b7beb61cb7f7f7b42429d389477063)|Win32 EXE|dynamer|2013-08-29 03:11:17|8e3c73c2de4ceffcb7110a70bd0e1ac8556adca3|
|[8ae6139ba59a6d94d82a97464f185c16](https://www.virustotal.com/gui/file/8ae6139ba59a6d94d82a97464f185c16)|Win32 EXE|Delf|2013-08-28 01:35:49|9265ef13f0729b9a359cd0332be1f69536953757|
|[2b2ef3be4cdb0c7046fc19965f5f37ff](https://www.virustotal.com/gui/file/2b2ef3be4cdb0c7046fc19965f5f37ff)|Win32 DLL|Zbot|2013-08-26 12:58:46|059b541efcd1f6ea807899266d358dd1439568ee|
|[8d2ab6bf1ded4e1f588385865bc9574a](https://www.virustotal.com/gui/file/8d2ab6bf1ded4e1f588385865bc9574a)|Win32 EXE||2013-08-13 07:05:19|eae18d723301da5f7ea641f121634a3c02393b3e|
|[cf1168f3e17150def9f5024055184fb6](https://www.virustotal.com/gui/file/cf1168f3e17150def9f5024055184fb6)|Win32 EXE||2013-08-13 06:26:56|6b9248d2917611498cf61926544c49e24971ed5b|
|[bd3c5fb34f164df13eeaa75aae16eff4](https://www.virustotal.com/gui/file/bd3c5fb34f164df13eeaa75aae16eff4)|Win32 EXE||2013-08-13 05:47:08|fc65453c482f5b6f81516c04b09b62a54d98a77a|
|[e6a5b2f98260f707d237bbc0a9f451c8](https://www.virustotal.com/gui/file/e6a5b2f98260f707d237bbc0a9f451c8)|Win32 EXE|Delf|2013-08-10 13:03:51|6d1e5771564bebbec6a240b88a803a268bb244e1|
|[10edd365e7353200c88c4fa2595a1c57](https://www.virustotal.com/gui/file/10edd365e7353200c88c4fa2595a1c57)|Win32 EXE|Delf|2013-08-10 07:46:37|1d1150b3954ecb8623ac5f26310a75c1f5c24c28|
|[1831809c397b0c285146df1335efbf5f](https://www.virustotal.com/gui/file/1831809c397b0c285146df1335efbf5f)|Win32 EXE||2013-08-10 04:53:39|b0985d52b0a2947096234cae9f372eb2dff4345d|
|[d718e6a861fc74cd47626fdb5dd8559a](https://www.virustotal.com/gui/file/d718e6a861fc74cd47626fdb5dd8559a)|Win32 EXE|Delf|2013-07-31 07:27:54|hcrtf.exe|
|[9c487d0d0a17ff44f5c8f5bd5b7687cf](https://www.virustotal.com/gui/file/9c487d0d0a17ff44f5c8f5bd5b7687cf)|Win32 EXE|Delf|2013-07-29 21:04:31|68715f2f73444826dcedf38d2492bf73392919d7|
|[35d0338f6d82f97442c1da865b6bc644](https://www.virustotal.com/gui/file/35d0338f6d82f97442c1da865b6bc644)|Win32 EXE|Delf|2013-07-29 04:55:08|7f73f4475a55a0cedf9146d9a4f1b9b9cde7d752|
|[baf685816ef9f71b85f2fd15df63be53](https://www.virustotal.com/gui/file/baf685816ef9f71b85f2fd15df63be53)|Win32 EXE|Delf|2013-07-26 15:48:00|d994f9ad0a4d8b398130e03565472621870d30aa|
|[9942a1f59cd48b27931977c400328a68](https://www.virustotal.com/gui/file/9942a1f59cd48b27931977c400328a68)|Win32 EXE||2013-07-26 07:12:27|vt-upload-pkj7c|
|[2c2a582705477443060d3277fb85e059](https://www.virustotal.com/gui/file/2c2a582705477443060d3277fb85e059)|Win32 EXE|Zbot|2013-07-26 06:37:31|vt-upload-5rp9F|
|[b15b59e56988d3a815a1c77b52689bf0](https://www.virustotal.com/gui/file/b15b59e56988d3a815a1c77b52689bf0)|Win32 EXE|Delf|2013-07-20 21:39:14|vt-upload-gbceK|
|[f1139f9162bb2e18d2db4793745aa139](https://www.virustotal.com/gui/file/f1139f9162bb2e18d2db4793745aa139)|Win32 EXE|Delf|2013-07-17 13:32:52|\sonas\share\samples\f1\13\9f\91\f1139f9162bb2e18d2db4793745aa139.0973fae855d2148367aa31b8c54f2ae709f9cea6|
|[48fe8cd9e6de8d5fae5f34785d4ac6d5](https://www.virustotal.com/gui/file/48fe8cd9e6de8d5fae5f34785d4ac6d5)|Win32 EXE|Delf|2013-06-21 11:12:29|\sonas\share\samples\48\fe\8c\d9\48fe8cd9e6de8d5fae5f34785d4ac6d5.a51ad699c85b2c88bae1d6682fd9fd7857e5ef5e|
|[6bc1aea97e7b420b0993eff794ed2aeb](https://www.virustotal.com/gui/file/6bc1aea97e7b420b0993eff794ed2aeb)|Win32 EXE|Delf|2013-06-21 06:43:15|460ce7d0cebde4ad1280647ecf1b7564d08f0223|
|[9d80a85f363ac47612432d68959a7de5](https://www.virustotal.com/gui/file/9d80a85f363ac47612432d68959a7de5)|Win32 EXE|Delf|2013-06-11 20:18:35|vt-upload-vSORT|
|[9955f33e1f605bfe29b91b9efe242fb0](https://www.virustotal.com/gui/file/9955f33e1f605bfe29b91b9efe242fb0)|Win32 EXE||2013-06-07 21:20:33|9955f33e1f605bfe29b91b9efe242fb0|
|[99ceb97edf9c8e6850f858ca4319c885](https://www.virustotal.com/gui/file/99ceb97edf9c8e6850f858ca4319c885)|Win32 EXE||2013-05-14 16:03:17|ins5471.exe|
|[9b9011532583aa3d4c626e932cad26ac](https://www.virustotal.com/gui/file/9b9011532583aa3d4c626e932cad26ac)|Win32 EXE|Zbot|2013-05-08 01:42:00|vt-upload-zfi1D|
|[5dc7347bafd0874be2430b71953738e6](https://www.virustotal.com/gui/file/5dc7347bafd0874be2430b71953738e6)|Win32 EXE|Delf|2013-05-08 01:21:28|vt-upload-xYXgA|
|[3f679d89e54f89a008bdd25d64cd46ed](https://www.virustotal.com/gui/file/3f679d89e54f89a008bdd25d64cd46ed)|Win32 EXE|Delf|2013-05-07 08:11:52|hcrtf.exe|
|[190d4104d774527106fa28d5df4e3fd2](https://www.virustotal.com/gui/file/190d4104d774527106fa28d5df4e3fd2)|Win32 EXE||2013-04-13 17:34:58|vt-upload-4ItVn|
|[0b3ee491ac8a3a4f67a3981bbcd773a9](https://www.virustotal.com/gui/file/0b3ee491ac8a3a4f67a3981bbcd773a9)|Win32 EXE||2013-04-12 19:53:07|0b3ee491ac8a3a4f67a3981bbcd773a9|
|[9d56d42b3d9a4f025926eeb54592c017](https://www.virustotal.com/gui/file/9d56d42b3d9a4f025926eeb54592c017)|Win32 EXE|Delf|2013-04-10 20:55:36|\sonas\share\samples\9d\56\d4\2b\9d56d42b3d9a4f025926eeb54592c017.1ba82f8df27175d4927e61ec5976cef849492f9c|
|[763259b197082bd81233aed55749275f](https://www.virustotal.com/gui/file/763259b197082bd81233aed55749275f)|Win32 EXE|Delf|2013-03-18 06:32:45|enteng.exe|
|[a1ae4368352542f5f81ac072c3c00f11](https://www.virustotal.com/gui/file/a1ae4368352542f5f81ac072c3c00f11)|Win32 EXE|Delf|2013-03-17 18:25:47|\sonas\share\samples\a1\ae\43\68\a1ae4368352542f5f81ac072c3c00f11.3f55f99d787ec0adc8470045eb2da5a0490f7080|
|[b3cb5132f9f7f3225952e461d5a813e7](https://www.virustotal.com/gui/file/b3cb5132f9f7f3225952e461d5a813e7)|Win32 EXE|Delf|2013-03-09 20:55:04|vt-upload-Oafcy|
|[dc7d20a327c20c75b9e2cd45adc5aee5](https://www.virustotal.com/gui/file/dc7d20a327c20c75b9e2cd45adc5aee5)|Win32 EXE|Delf|2013-03-07 08:01:31|\sonas\share\samples\dc\7d\20\a3\dc7d20a327c20c75b9e2cd45adc5aee5.55f5af790957e869aabb32b69d57912e3057a793|
|[1906dc3bc8d5086af55ad7902a550d45](https://www.virustotal.com/gui/file/1906dc3bc8d5086af55ad7902a550d45)|Win32 EXE||2013-03-01 18:51:25|vt-upload-mqKI0|
|[2e4756bbc331661137b928e4a77e8c26](https://www.virustotal.com/gui/file/2e4756bbc331661137b928e4a77e8c26)|Win32 EXE||2013-03-01 18:21:22|vt-upload-qFO7C|
|[dbc1bed3a44619c834b6b22bba46b20c](https://www.virustotal.com/gui/file/dbc1bed3a44619c834b6b22bba46b20c)|Win32 EXE|Delf|2013-03-01 18:08:36|vt-upload-feAjl|
|[3ecaacd6ccdcbb0fe149f68db964a308](https://www.virustotal.com/gui/file/3ecaacd6ccdcbb0fe149f68db964a308)|Win32 EXE|Delf|2013-03-01 17:54:25|vt-upload-RStXi|
|[c60abc691aeb768b73509886bec89e6d](https://www.virustotal.com/gui/file/c60abc691aeb768b73509886bec89e6d)|Win32 EXE|Zbot|2013-03-01 17:35:03|c60abc691aeb768b73509886bec89e6d|
|[c1a7bd517cfc88c17176a65e82a5bea9](https://www.virustotal.com/gui/file/c1a7bd517cfc88c17176a65e82a5bea9)|Win32 EXE|dynamer|2013-03-01 17:29:02|c1a7bd517cfc88c17176a65e82a5bea9|
|[a0ce7cb65688e16fe7cecbb5ee75ad16](https://www.virustotal.com/gui/file/a0ce7cb65688e16fe7cecbb5ee75ad16)|Win32 EXE|Zbot|2013-03-01 17:27:27|vt-upload-L4H7B|
|[9d1109ab2e0c382cc2839dffb0a41aa8](https://www.virustotal.com/gui/file/9d1109ab2e0c382cc2839dffb0a41aa8)|Win32 EXE||2013-03-01 11:50:41|\sonas\share\samples\9d\11\09\ab\9d1109ab2e0c382cc2839dffb0a41aa8|
|[43816893d27145e37cd3dbad22f29377](https://www.virustotal.com/gui/file/43816893d27145e37cd3dbad22f29377)|Win32 EXE|Delf|2013-03-01 10:44:17|\sonas\share\samples\43\81\68\93\43816893d27145e37cd3dbad22f29377|
|[6f4d9b956180e74b17fe3c29063f5691](https://www.virustotal.com/gui/file/6f4d9b956180e74b17fe3c29063f5691)|Win32 EXE|Delf|2013-03-01 04:54:25|\sonas\share\samples\6f\4d\9b\95\6f4d9b956180e74b17fe3c29063f5691|
|[1a8c12cb5a07aae016d33015f589bfb2](https://www.virustotal.com/gui/file/1a8c12cb5a07aae016d33015f589bfb2)|Win32 EXE||2013-02-28 16:19:45|vt-upload-u0JJ8|
|[c4c1c7722cfdf5ecc66b387dd4a37405](https://www.virustotal.com/gui/file/c4c1c7722cfdf5ecc66b387dd4a37405)|Win32 EXE||2013-02-28 14:31:15|c4c1c7722cfdf5ecc66b387dd4a37405|
|[ed82c1d1a09f1382a9bb279c06eccd0f](https://www.virustotal.com/gui/file/ed82c1d1a09f1382a9bb279c06eccd0f)|Win32 EXE|Zbot|2013-02-22 16:50:13|vt-upload-J86AD|
|[d89d3297c9c310e3cdc67f92d8585025](https://www.virustotal.com/gui/file/d89d3297c9c310e3cdc67f92d8585025)|Win32 EXE|dynamer|2013-02-22 16:07:22|vt-upload-xIncF|
|[4e768baed3dc75c224c6eb1671654e98](https://www.virustotal.com/gui/file/4e768baed3dc75c224c6eb1671654e98)|Win32 EXE|Delf|2013-02-22 15:12:59|\sonas\share\samples\4e\76\8b\ae\4e768baed3dc75c224c6eb1671654e98|
|[13eb94e02912da06072246789aa1a8a8](https://www.virustotal.com/gui/file/13eb94e02912da06072246789aa1a8a8)|Win32 EXE||2013-02-21 16:10:57|vt-upload-lxz0E|
|[6588d0b81d0491d7c1cd7ef88c2c1494](https://www.virustotal.com/gui/file/6588d0b81d0491d7c1cd7ef88c2c1494)|Win32 EXE||2013-02-18 14:09:10|1905C1E692FCAFDD60303C625C36A57460464CABE808539407E943D4C39D025B__PEFILE__OFFSET=0xe82.bin|
|[b07d49c1c9f6958b7a96b3c87e039cf2](https://www.virustotal.com/gui/file/b07d49c1c9f6958b7a96b3c87e039cf2)|Win32 EXE||2013-02-18 13:08:40|drop/b07d49c1c9f6958b7a96b3c87e0|
|[2a7bea7f4391327c7d3f9bae58e40c03](https://www.virustotal.com/gui/file/2a7bea7f4391327c7d3f9bae58e40c03)|Win32 EXE|Delf|2013-02-17 19:56:44|vt-upload-emgNc|
|[b2ef1ef6c9815385a0526de99a3a382b](https://www.virustotal.com/gui/file/b2ef1ef6c9815385a0526de99a3a382b)|Win32 EXE||2013-02-16 21:08:23|\sonas\share\samples\b2\ef\1e\f6\b2ef1ef6c9815385a0526de99a3a382b|
|[926c851ae6bea03f97cb3c2f17c6204d](https://www.virustotal.com/gui/file/926c851ae6bea03f97cb3c2f17c6204d)|Win32 EXE|Delf|2013-02-15 19:14:54|926c851ae6bea03f97cb3c2f17c6204d|
|[18713529ff40b366b162c276333b62ce](https://www.virustotal.com/gui/file/18713529ff40b366b162c276333b62ce)|Win32 EXE||2013-02-15 16:23:43|\sonas\share\samples\18\71\35\29\18713529ff40b366b162c276333b62ce|
|[7a64fef96e69f58bd52abdff97cc95a5](https://www.virustotal.com/gui/file/7a64fef96e69f58bd52abdff97cc95a5)|Win32 EXE|Delf|2013-02-15 09:38:11|7a64fef96e69f58bd52abdff97cc95a5.virus|
|[9a78686ffb97a9942867785c7df54811](https://www.virustotal.com/gui/file/9a78686ffb97a9942867785c7df54811)|Win32 EXE|Delf|2013-02-12 15:26:41|9a78686ffb97a9942867785c7df54811|
|[05e79fe215b04d78f1008960f10be60d](https://www.virustotal.com/gui/file/05e79fe215b04d78f1008960f10be60d)|Win32 EXE||2013-02-12 07:40:33|test|
|[8a1f29d4fea917b8548cb9a936126daa](https://www.virustotal.com/gui/file/8a1f29d4fea917b8548cb9a936126daa)|Win32 EXE||2013-02-11 12:10:14|enteng.exe|
|[2a817c1d6bad99430c9eace0a6008a75](https://www.virustotal.com/gui/file/2a817c1d6bad99430c9eace0a6008a75)|Win32 EXE||2013-02-10 14:53:27|\sonas\share\samples\2a\81\7c\1d\2a817c1d6bad99430c9eace0a6008a75|
|[d101106f8551a38eb9a11fc1da903a67](https://www.virustotal.com/gui/file/d101106f8551a38eb9a11fc1da903a67)|Win32 EXE||2013-02-09 20:46:39|d101106f8551a38eb9a11fc1da903a67|
|[0a07888d4ad0ba8c83e8cbe555ba7810](https://www.virustotal.com/gui/file/0a07888d4ad0ba8c83e8cbe555ba7810)|Win32 EXE|Delf|2013-02-09 10:17:29|0a07888d4ad0ba8c83e8cbe555ba7810|
|[513b77a133f8d4f7c1e2a7ed150cd97c](https://www.virustotal.com/gui/file/513b77a133f8d4f7c1e2a7ed150cd97c)|Win32 EXE||2013-02-07 18:06:35|\sonas\share\samples\51\3b\77\a1\513b77a133f8d4f7c1e2a7ed150cd97c|
|[0d7909ab4f933b56f7727726c2b1aa78](https://www.virustotal.com/gui/file/0d7909ab4f933b56f7727726c2b1aa78)|Win32 EXE||2013-02-06 06:29:22|0d7909ab4f933b56f7727726c2b1aa78|
|[e019892328a1dc5a952d8fec4280863b](https://www.virustotal.com/gui/file/e019892328a1dc5a952d8fec4280863b)|Win32 EXE|Delf|2013-02-02 02:15:35|\sonas\share\samples\e0\19\89\23\e019892328a1dc5a952d8fec4280863b|
|[038bd4efdecd4381c2b51ac101816747](https://www.virustotal.com/gui/file/038bd4efdecd4381c2b51ac101816747)|Win32 EXE|Delf|2013-02-01 05:47:56|vxBK6wpH|
|[403bfd88f3d24710993c9b1aaaab7ae2](https://www.virustotal.com/gui/file/403bfd88f3d24710993c9b1aaaab7ae2)|Win32 EXE|Delf|2013-01-31 14:05:36|\sonas\share\samples\40\3b\fd\88\403bfd88f3d24710993c9b1aaaab7ae2|
|[3b2336e09cfea5e2c1c430ec371dcb0b](https://www.virustotal.com/gui/file/3b2336e09cfea5e2c1c430ec371dcb0b)|Win32 EXE||2013-01-29 19:18:44|3b2336e09cfea5e2c1c430ec371dcb0b|
|[b9c55a7acecc3509b057b34e0a749c88](https://www.virustotal.com/gui/file/b9c55a7acecc3509b057b34e0a749c88)|Win32 EXE||2013-01-29 19:14:18|b9c55a7acecc3509b057b34e0a749c88|
|[12b6ce12e581aca530324bcd256de512](https://www.virustotal.com/gui/file/12b6ce12e581aca530324bcd256de512)|Win32 EXE|Delf|2013-01-25 10:24:40|\sonas\share\samples\12\b6\ce\12\12b6ce12e581aca530324bcd256de512|
|[85f37501477284f032c3d3981c5a8a75](https://www.virustotal.com/gui/file/85f37501477284f032c3d3981c5a8a75)|Win32 EXE||2013-01-18 15:58:37|vt-upload-rETka|
|[8448f958a6acdb606f6f1242a963f845](https://www.virustotal.com/gui/file/8448f958a6acdb606f6f1242a963f845)|Win32 EXE||2013-01-17 18:34:42|\sonas\share\samples\84\48\f9\58\8448f958a6acdb606f6f1242a963f845|
|[e9d468c72e9ffa3962d09abd0c586772](https://www.virustotal.com/gui/file/e9d468c72e9ffa3962d09abd0c586772)|Win32 EXE|Delf|2013-01-13 13:13:33|rrseviclo4|
|[426a4471537a4d926a5b1f1119294787](https://www.virustotal.com/gui/file/426a4471537a4d926a5b1f1119294787)|Win32 EXE||2012-11-22 09:10:44|RcGtnYUl|
|[ed15da7cdc85f8e7e2527646944c7010](https://www.virustotal.com/gui/file/ed15da7cdc85f8e7e2527646944c7010)|Win32 EXE|Delf|2012-10-09 22:43:22|ed15da7cdc85f8e7e2527646944c7010|
|[ad24c8c54e467d235faaa85f3a98a55a](https://www.virustotal.com/gui/file/ad24c8c54e467d235faaa85f3a98a55a)|Win32 EXE|Delf|2012-10-09 04:55:27|ad24c8c54e467d235faaa85f3a98a55a|
|[1ba3363da3130cc41ca152b4a8302809](https://www.virustotal.com/gui/file/1ba3363da3130cc41ca152b4a8302809)|Win32 EXE|Delf|2012-10-05 13:01:18|1ba3363da3130cc41ca152b4a8302809|
|[5252efdc70dcbb53713454099fd10277](https://www.virustotal.com/gui/file/5252efdc70dcbb53713454099fd10277)|Win32 EXE||2012-10-04 10:04:21|5252efdc70dcbb53713454099fd10277.exe|
|[32ecd6aea9d252bfd1c19efcb614ed9f](https://www.virustotal.com/gui/file/32ecd6aea9d252bfd1c19efcb614ed9f)|Win32 EXE||2012-09-30 04:07:07|1acb2e942d0c73214155ced4f7f11b84c2f92a3988e6203b817a98ba91ebca2a.vir|
|[eb7e6a84f018692ad6a1a58f530c14e0](https://www.virustotal.com/gui/file/eb7e6a84f018692ad6a1a58f530c14e0)|Win32 EXE|Delf|2012-09-16 17:45:44|eb7e6a84f018692ad6a1a58f530c14e0|
|[dcce201e25afac6f0d8ac5bf1b2ebcaf](https://www.virustotal.com/gui/file/dcce201e25afac6f0d8ac5bf1b2ebcaf)|Win32 EXE|Delf|2012-09-02 12:27:37|pondiv.ht|
|[80ca98965c7c3fa89fd85f8823544ff4](https://www.virustotal.com/gui/file/80ca98965c7c3fa89fd85f8823544ff4)|Win32 EXE|Delf|2012-08-10 21:11:55|354dd026033764ece26f3248e1cbaa504bcd2c556794921498b3b083be42b437.vir|
|[2417fb8f148afc6daad2dddce19b5e7d](https://www.virustotal.com/gui/file/2417fb8f148afc6daad2dddce19b5e7d)|Win32 EXE||2012-08-03 14:25:03|fa64128c14c8a517e7d60b317896139db8e86b5f1a831c45cbcbcc1b62c14a3e.vir|
|[0bd433d843a83c5fa816329dd9444c8e](https://www.virustotal.com/gui/file/0bd433d843a83c5fa816329dd9444c8e)|Win32 EXE||2012-06-16 15:05:03|a4dcefc5ee2ac4b7e6de5340ed9b0a8587a5eb612b3c05c8a88a08574a6b55f0.vir|
|[b43b56a5167d0c73c324c68e8e55253a](https://www.virustotal.com/gui/file/b43b56a5167d0c73c324c68e8e55253a)|Win32 EXE||2012-06-12 05:36:05|e74c3b68554d7d4df8e8fac34ca743cd06337d2728fb278943a2a990b5083757.vir|
|[2409f03128690bc063aa6b8b160f6f35](https://www.virustotal.com/gui/file/2409f03128690bc063aa6b8b160f6f35)|Win32 EXE|Delf|2012-06-07 13:23:07|9370b0cd2a4d6affa4ab9a575ff9349b68c85b0b0dca3bfc08a0f8f8a66875f5.exe|
|[a3b576495b790f43327cf38a7a28d1a6](https://www.virustotal.com/gui/file/a3b576495b790f43327cf38a7a28d1a6)|Win32 EXE|Delf|2012-05-29 21:50:05|bfe7c595cd62735531d899ea9eb4f136baba528e0861c3295cde21165c49691a.vir|
|[eae5749af7bcfab51342ec3947264587](https://www.virustotal.com/gui/file/eae5749af7bcfab51342ec3947264587)|Win32 EXE|Delf|2012-05-29 20:23:52|4d1ca3d0a71862d0fd828310aa2750509b4647de3506acf7a417b088091ad56b.vir|
|[b61b26c9862e74772a864afcbf4feba4](https://www.virustotal.com/gui/file/b61b26c9862e74772a864afcbf4feba4)|PPSX||2012-05-22 16:58:51|ba ham delan.ppsx|
|[beef98ff03885a41ca0d70dcbe738bf2](https://www.virustotal.com/gui/file/beef98ff03885a41ca0d70dcbe738bf2)|Win32 EXE|Delf|2012-05-13 01:31:31|da972bbefc73e20fd3fd14d2ef4efb2bf17fff2d44888ec457c093b5255a298e.vir|
|[23326a8d4a09f74d033e46e1dc6d0e16](https://www.virustotal.com/gui/file/23326a8d4a09f74d033e46e1dc6d0e16)|Win32 EXE|Delf|2011-07-12 10:13:50|8d8b9dcbc8c54316ac0cc3fb69058f75449ff60ffe62023f236201011920f91e.vir|
|[06a3cdf1f52bbbbc3fbddbd80366c459](https://www.virustotal.com/gui/file/06a3cdf1f52bbbbc3fbddbd80366c459)|Win32 EXE|Delf|2007-08-16 11:08:39|06a3cdf1f52bbbbc3fbddbd80366c459|
