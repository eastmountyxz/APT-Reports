**NAME:**  
Infy group 
  
**Alias**  
APT-C-07, Infy group, Operation Mermaid, APT-C-007, 美人鱼  
  
**Description**:   
  It is an offshore APT organization that targets government agencies and has been attacking the Danish Ministry of Foreign Affairs for up to six years of cyber espionage. Related attacks can be traced back to April 2010, and the most recent attack was in January 2016.  

**References**:  
https://ti.qianxin.com/uploads/2018/01/26/ea9d6d29c2218746acaf87a68a2bbc1e.pdf  
http://researchcenter.paloaltonetworks.com/2016/05/prince-of-persia-infy-malware-active-in-decade-of-targeted-attacks
