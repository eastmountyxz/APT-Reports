**NAME:**  
Matryoshka  

**Description**:   
Matryoshka, discovered by Fortinet, is a series of attacks targeted at service centers in Russia. These attacks use forged emails, malicious Office documents with exploits, and a commercial version of a RAT that is tucked into five different layers of protective packers.

**References**:  
https://www.fortinet.com/blog/threat-research/non-russion-matryoshka-russian-service-centers-under-attack.html  