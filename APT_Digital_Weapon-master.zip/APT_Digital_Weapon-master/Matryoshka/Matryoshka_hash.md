|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[51bf77d9ed6715ff3263a7e21e01554d](https://www.virustotal.com/gui/file/51bf77d9ed6715ff3263a7e21e01554d)|Win32 EXE|razy|2018-03-31 17:36:44|/var/www/clean-mx/virusesevidence/output.113049832.txt|
|[4e7a323af0a135a0824c19d0ffd2a6ea](https://www.virustotal.com/gui/file/4e7a323af0a135a0824c19d0ffd2a6ea)|Win32 EXE|Kryptik|2018-03-31 09:30:22|myfile.exe|
|[e2ad0e78a83563cd6fa2e233f3a7ec70](https://www.virustotal.com/gui/file/e2ad0e78a83563cd6fa2e233f3a7ec70)|Win32 EXE|Disfa|2018-03-31 09:11:07|c:\users\USER\appdata\local\temp\thfdfdnewa-.txt|
|[286f4504d9373c5f8523e7daa9337cba](https://www.virustotal.com/gui/file/286f4504d9373c5f8523e7daa9337cba)|XLSX|CVE-2017-11882|2018-03-31 01:07:47|Samsung ASC engineer code creation request form.xlsx|
|[eb811625308df525a531897b516c4971](https://www.virustotal.com/gui/file/eb811625308df525a531897b516c4971)|Win32 EXE|Disfa|2018-03-30 10:00:18|service.exe|
|[7c7f0c04fb6e469ae97375894fefc934](https://www.virustotal.com/gui/file/7c7f0c04fb6e469ae97375894fefc934)|XLSX|CVE-2017-11882|2018-03-30 06:50:33|29-03-2018 Yazılım Listesi.xlsx|
|[6be98892addb486306a2dc2517c4cc80](https://www.virustotal.com/gui/file/6be98892addb486306a2dc2517c4cc80)|Win32 EXE|razy|2018-03-29 14:24:31|6be98892addb486306a2dc2517c4cc80.virobj|
|[b3ced1499b96fe354940c65ebe40fb87](https://www.virustotal.com/gui/file/b3ced1499b96fe354940c65ebe40fb87)|Win32 EXE||2018-03-29 03:27:35|/var/www/clean-mx/virusesevidence/output.112967454.txt|
|[bef03c99ee5d6e578f6c64da0e34788e](https://www.virustotal.com/gui/file/bef03c99ee5d6e578f6c64da0e34788e)|Win32 EXE|dynamer|2018-03-28 09:54:46|msgmanager|
|[9406317fd923fb79a5bfb0b187d51135](https://www.virustotal.com/gui/file/9406317fd923fb79a5bfb0b187d51135)|XLSX|CVE-2017-11882|2018-03-28 03:09:19|Symptom_and_repair_code_list.xlsx|
|[3a14b91a8a3311d7b0b41428ede12694](https://www.virustotal.com/gui/file/3a14b91a8a3311d7b0b41428ede12694)|Win32 EXE|MSILPerseus|2018-03-27 10:08:07|ef8fe9afc0053e6a_svhost.exe|
|[bb42022c54140f70a258f66fa7c3bbc1](https://www.virustotal.com/gui/file/bb42022c54140f70a258f66fa7c3bbc1)|Win32 EXE|dynamer|2018-03-27 07:15:52|imm.exe|
|[8f1d4566d66225e5ae8876c8208752c2](https://www.virustotal.com/gui/file/8f1d4566d66225e5ae8876c8208752c2)|Win32 EXE|msilperseus|2018-03-27 05:48:09|net.exe|
|[0de1f82771a87ffb9819c65773b19d91](https://www.virustotal.com/gui/file/0de1f82771a87ffb9819c65773b19d91)|Win32 EXE||2018-03-27 02:33:03|DASEUL_Launcher.exe|
|[9b626f2676e47611820878323bf2c6a0](https://www.virustotal.com/gui/file/9b626f2676e47611820878323bf2c6a0)|Win32 EXE|Disfa|2018-03-26 07:45:16|9b626f2676e47611820878323bf2c6a0.virobj|
|[148e5cff8feb43db3a0fcdf4af7a48b7](https://www.virustotal.com/gui/file/148e5cff8feb43db3a0fcdf4af7a48b7)|Win32 EXE||2018-03-24 15:27:22|iTools|
|[b39fe5feb345050f4cc2260bf1bbd577](https://www.virustotal.com/gui/file/b39fe5feb345050f4cc2260bf1bbd577)|Win32 EXE|razy|2018-03-24 08:54:33|3b22104396ad12ffaf4d9a94134ba42d3e70d548|
|[1b4f204c668d78e2498a117d40ef3e5f](https://www.virustotal.com/gui/file/1b4f204c668d78e2498a117d40ef3e5f)|XLSX|CVE-2017-8570|2018-01-19 08:50:22|Par ºa Harici Kay-¦tlar  Bayrak Elektronik 22.01.2018.xlsx|
