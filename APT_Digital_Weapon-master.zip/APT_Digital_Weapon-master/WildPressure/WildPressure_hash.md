|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[17b1a05fc367e52aada7bde07714666b](https://www.virustotal.com/gui/file/17b1a05fc367e52aada7bde07714666b)|Win32 EXE||2019-10-04 20:40:21|17b1a05fc367e52aada7bde07714666b.virus|
|[a76991f15d6b4f43fba419eca1a8e741](https://www.virustotal.com/gui/file/a76991f15d6b4f43fba419eca1a8e741)|Win32 EXE|Ursu|2019-05-31 18:38:34|%PROGRAMDATA%\micapp\windows\<SAMPLE.EXE>|
