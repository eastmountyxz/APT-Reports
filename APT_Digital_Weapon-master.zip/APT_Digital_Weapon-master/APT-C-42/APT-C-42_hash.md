|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|

|[d24de5bb4f3b903e91e8ad31ddbee520](https://www.virustotal.com/gui/file/d24de5bb4f3b903e91e8ad31ddbee520)|Win64 EXE||2020-09-09 08:15:26| |
|[429be60f0e444f4d9ba1255e88093721](https://www.virustotal.com/gui/file/429be60f0e444f4d9ba1255e88093721)|Win32 EXE|WellMess|2020-02-27 03:41:12|m.exe|
|[e58b8de07372b9913ca2fbd3b103bb8f](https://www.virustotal.com/gui/file/e58b8de07372b9913ca2fbd3b103bb8f)|Win32 EXE|Ursu|2020-01-20 23:46:49|e58b8de07372b9913ca2fbd3b103bb8f.virus|
|[8777a9796565effa01b03cf1cea9d24d](https://www.virustotal.com/gui/file/8777a9796565effa01b03cf1cea9d24d)|ELF executable||2019-07-30 08:05:56|ksoftirqd|
