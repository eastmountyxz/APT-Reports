**NAME:**  
TOOHASH
  
**Alias**  
Wolfsbane, TOOHASH, 狼毒草  
  
**Description**:  
In July 2018, the Venus Chenchen Eye Safety Research Team captured a new class of targeted attack samples, dating back to the organization’s earliest activity in 2013, which named the APT organization “狼毒草” and considered it The organization is very familiar with Chinese. It was also found that its early samples were related to TOOHASH disclosed by G DATA. 
  
**References**:  
https://mp.weixin.qq.com/s?__biz=MzA3NDQ0MzkzMA==&mid=2651677009&idx=1&sn=44a9f62303ffcf154c11b46fdfa9de55&chksm=84867ca4b3f1f5b2316119a2892d4d19adef3542aa5adc0d70ed9493d0468b2b96a387adc3b4&scene=0#rd
