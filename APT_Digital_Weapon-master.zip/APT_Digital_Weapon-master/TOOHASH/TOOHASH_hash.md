|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[ecc8245568b5dc1d74d0be6073eafa2d](https://www.virustotal.com/gui/file/ecc8245568b5dc1d74d0be6073eafa2d)|Win32 EXE|creprote|2019-03-16 23:04:44|dttcodexgigas.b822521633475c9ca6181689275bea3cc96b4d9a|
|[d4e2aadbc0ac414ac5a778da67251c02](https://www.virustotal.com/gui/file/d4e2aadbc0ac414ac5a778da67251c02)|Win32 EXE||2019-03-16 15:07:08|Microsoft MFC Program|
|[5cc7038f67114bfb64e0c23223d902b1](https://www.virustotal.com/gui/file/5cc7038f67114bfb64e0c23223d902b1)|Win32 DLL||2018-07-24 23:21:22|.|
|[09a9bf5e8de0d9cfe3684b6df98b6d0d](https://www.virustotal.com/gui/file/09a9bf5e8de0d9cfe3684b6df98b6d0d)|Win64 DLL||2018-07-24 05:47:19|codexgigas_49316f134954b3c6f883d0b5d5e33caeb813eb8d|
|[a53a725a27eace541e52fc095e7af699](https://www.virustotal.com/gui/file/a53a725a27eace541e52fc095e7af699)|Win32 EXE||2018-07-23 23:00:05|main|
|[415027680047ed31fa5a84c94a46d582](https://www.virustotal.com/gui/file/415027680047ed31fa5a84c94a46d582)|Win32 DLL||2018-04-27 09:30:08|wmext|
|[4dbd68d3741d46170d2585aae4336b80](https://www.virustotal.com/gui/file/4dbd68d3741d46170d2585aae4336b80)|Win32 EXE||2016-03-31 15:45:21|tmpolicy (1).dll|
|[caf3e9500934f89ae4ddf3c6b093af23](https://www.virustotal.com/gui/file/caf3e9500934f89ae4ddf3c6b093af23)|Win32 DLL|bitrep|2014-12-05 11:40:55|caf3e9500934f89ae4ddf3c6b093af23|
|[0c0a3784c3530e820f57da076ea1fc8b](https://www.virustotal.com/gui/file/0c0a3784c3530e820f57da076ea1fc8b)|Win32 DLL|graftor|2014-12-05 11:40:54|0c0a3784c3530e820f57da076ea1fc8b|
|[f87e765e583e1ead4e0dd56430c469fd](https://www.virustotal.com/gui/file/f87e765e583e1ead4e0dd56430c469fd)|Win32 DLL|dynamer|2014-12-05 11:40:54|f87e765e583e1ead4e0dd56430c469fd|
|[d4691e06bca3a32c9283d2787b0e40b3](https://www.virustotal.com/gui/file/d4691e06bca3a32c9283d2787b0e40b3)|Win32 DLL||2014-12-05 11:40:54|d4691e06bca3a32c9283d2787b0e40b3|
|[bf4e5e6bef4acc33aea06f770407477e](https://www.virustotal.com/gui/file/bf4e5e6bef4acc33aea06f770407477e)|Win32 DLL|bitrep|2014-12-05 11:40:54|bf4e5e6bef4acc33aea06f770407477e|
|[b45caf646f94ace23cfa367c5d202944](https://www.virustotal.com/gui/file/b45caf646f94ace23cfa367c5d202944)|Win32 DLL||2014-12-05 11:40:54|b45caf646f94ace23cfa367c5d202944|
|[e0ee55a01de565ee145ed769ca3deddd](https://www.virustotal.com/gui/file/e0ee55a01de565ee145ed769ca3deddd)|Win32 EXE|tiggre|2014-12-05 03:40:55|e0ee55a01de565ee145ed769ca3deddd|
|[6b5e9eb8eccfd4336ff8910f646dd199](https://www.virustotal.com/gui/file/6b5e9eb8eccfd4336ff8910f646dd199)|Win32 EXE|Ursu|2014-12-05 03:40:54|6b5e9eb8eccfd4336ff8910f646dd199|
|[5ebd4452848879202414a46a09cd2eab](https://www.virustotal.com/gui/file/5ebd4452848879202414a46a09cd2eab)|Win32 DLL||2014-09-30 08:00:30|5ebd4452848879202414a46a09cd2eab|
|[ed416eda209e91079a829cc97d57e287](https://www.virustotal.com/gui/file/ed416eda209e91079a829cc97d57e287)|Win32 EXE||2014-03-11 03:57:57|Microsoft MFC Program|
|[2857455281e50a80593708e63d68c48f](https://www.virustotal.com/gui/file/2857455281e50a80593708e63d68c48f)|Win32 EXE||2014-02-13 04:06:41|vti-rescan|
|[22b955536f27b397f68f22172f8496c2](https://www.virustotal.com/gui/file/22b955536f27b397f68f22172f8496c2)|Win32 EXE|creprote|2014-02-13 01:50:48|Microsoft MFC Program|
|[b9ea262ac271a72a5310bd0d0561b007](https://www.virustotal.com/gui/file/b9ea262ac271a72a5310bd0d0561b007)|Win32 DLL|graftor|2014-01-09 12:23:12|b9ea262ac271a72a5310bd0d0561b007|
|[4afda3513ef0f5563f1e77f01dbaed7c](https://www.virustotal.com/gui/file/4afda3513ef0f5563f1e77f01dbaed7c)|Win32 EXE|bitrep|2014-01-07 00:58:49|4afda3513ef0f5563f1e77f01dbaed7c|
|[a7a40f633e3edc3e36e1dd27c57374b1](https://www.virustotal.com/gui/file/a7a40f633e3edc3e36e1dd27c57374b1)|Win32 DLL||2014-01-06 16:46:02|04ac29fa7a80ce3daa3f844fd90de8b791cbf27b.codex|
|[a3355ad88ba0802be7e4db0a68394718](https://www.virustotal.com/gui/file/a3355ad88ba0802be7e4db0a68394718)|Win32 EXE|dynamer|2014-01-06 15:48:44|a3355ad88ba0802be7e4db0a68394718|
|[8d263d5dae035e3d97047171e1cbf841](https://www.virustotal.com/gui/file/8d263d5dae035e3d97047171e1cbf841)|XLS|CVE-2012-0158|2014-01-06 09:42:15|102年尾牙、103年春酒精緻菜單.xls|
|[0ad60b49fc47581d19ca2f4e2fc6a6bb](https://www.virustotal.com/gui/file/0ad60b49fc47581d19ca2f4e2fc6a6bb)|Win32 EXE|Zbot|2013-07-25 12:38:33|archives/0ad60b49fc47581d19ca2f4e2fc6a6bb|
|[12ee78564ebcb5e203d2991d5ac21ace](https://www.virustotal.com/gui/file/12ee78564ebcb5e203d2991d5ac21ace)|Win32 EXE|Ursu|2013-05-18 01:02:51|61aa9073194879040f1b58c0ba448d7b624ded09cace71b498bc2a5d6b385099.vir|
|[7251073c67db6421049ee2baf4f31b62](https://www.virustotal.com/gui/file/7251073c67db6421049ee2baf4f31b62)|Rich Text Format||2013-05-17 12:27:28|18f018d3d49cb195bd5f59c43dba08caebe2029d732e7de46656550661df8531.rtf|
|[2ec306ef507402037e9c1eeb81276152](https://www.virustotal.com/gui/file/2ec306ef507402037e9c1eeb81276152)|XLS|CVE-2012-0158|2013-05-17 12:23:20|文件列表.xls|
|[bf4fc457359c6396a360202eee2cc29f](https://www.virustotal.com/gui/file/bf4fc457359c6396a360202eee2cc29f)|Win32 EXE|Ursu|2013-04-25 09:23:42|bf4fc457359c6396a360202eee2cc29f|
|[2e4c52e2f424a233f0d5cfa143b4778f](https://www.virustotal.com/gui/file/2e4c52e2f424a233f0d5cfa143b4778f)|Win32 EXE|Zbot|2013-01-23 00:52:05|2e4c52e2f424a233f0d5cfa143b4778f|
|[367ad9dd9e263a55d2820b88910b336a](https://www.virustotal.com/gui/file/367ad9dd9e263a55d2820b88910b336a)|Win32 EXE|occamy|2012-12-10 13:09:48|367ad9dd9e263a55d2820b88910b336a|
|[39c5f3f134520bfb70a770de61185d49](https://www.virustotal.com/gui/file/39c5f3f134520bfb70a770de61185d49)|Win32 EXE|Zbot|2012-10-23 21:37:05|39c5f3f134520bfb70a770de61185d49|
|[272f23dce6d07f1be9bf2669b99e1530](https://www.virustotal.com/gui/file/272f23dce6d07f1be9bf2669b99e1530)|Win32 EXE|Zbot|2012-10-23 07:13:33|272f23dce6d07f1be9bf2669b99e1530|
|[f035bce5e0a7e570743c128927a026e1](https://www.virustotal.com/gui/file/f035bce5e0a7e570743c128927a026e1)|Win32 EXE|Zbot|2012-10-18 18:03:16|f035bce5e0a7e570743c128927a026e1|
|[3415e9e50be4de0903d607a2514b23e5](https://www.virustotal.com/gui/file/3415e9e50be4de0903d607a2514b23e5)|Win32 EXE|Zbot|2012-10-18 17:32:58|theth9_|
|[1ed0286b4967d9590900faadab8a4926](https://www.virustotal.com/gui/file/1ed0286b4967d9590900faadab8a4926)|Win32 EXE|Zbot|2012-10-18 10:57:34|hticth.co|
|[3bd5de1f1cd29171709358920d311018](https://www.virustotal.com/gui/file/3bd5de1f1cd29171709358920d311018)|Win32 EXE|Zbot|2012-10-18 03:29:22|strevele4.ex|
|[2e1a5d92343fce92136592f208ca7160](https://www.virustotal.com/gui/file/2e1a5d92343fce92136592f208ca7160)|Win32 EXE|Zbot|2012-09-26 10:48:51|vti-rescan|
|[205e00d44ec0ff5f5c737fa4553e387a](https://www.virustotal.com/gui/file/205e00d44ec0ff5f5c737fa4553e387a)|Win32 EXE|dynamer|2012-09-04 09:26:51|vti-rescan|
|[fd11d2f0f1d388404de4bb8d872ac897](https://www.virustotal.com/gui/file/fd11d2f0f1d388404de4bb8d872ac897)|Win32 EXE|Zbot|2011-09-21 23:26:46|FD11D2F0F1D388404DE4BB8D872AC897|
|[74697ae5fa114222d8d7f8442e57305d](https://www.virustotal.com/gui/file/74697ae5fa114222d8d7f8442e57305d)|Win32 EXE||2011-09-05 08:42:29|0a5ff533b32ed6e2369a1f9a240e0203e47a74fc.codex|
