|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[99670267cbece5f5cc3ce92efd5bb04b](https://www.virustotal.com/gui/file/99670267cbece5f5cc3ce92efd5bb04b)|Win64 DLL|agentwdcr|2018-09-04 22:14:26|99670267cbece5f5cc3ce92efd5bb04b.virus|
|[e2bd4044fab4214c4aa7dd65d65fca21](https://www.virustotal.com/gui/file/e2bd4044fab4214c4aa7dd65d65fca21)|Win32 EXE||2018-06-04 08:04:56|1|
|[efe3518ee7d62299d01b7882f72ffd0a](https://www.virustotal.com/gui/file/efe3518ee7d62299d01b7882f72ffd0a)|Win32 EXE||2018-05-15 15:41:30|efe3518ee7d62299d01b7882f72ffd0a.virus|
|[80e7a7789286d3fb69f083f1a2dddbe6](https://www.virustotal.com/gui/file/80e7a7789286d3fb69f083f1a2dddbe6)|Win32 EXE||2018-05-11 17:45:31|80e7a7789286d3fb69f083f1a2dddbe6.virus|
|[32b8d08e67cf509236ae8142fbeb30b3](https://www.virustotal.com/gui/file/32b8d08e67cf509236ae8142fbeb30b3)|Win32 EXE||2018-04-07 15:24:09|8c2e729bc086921062e214b7e4c9c4ddf324a0fa53b4ed106f1341cfe8274fe4.exe|
