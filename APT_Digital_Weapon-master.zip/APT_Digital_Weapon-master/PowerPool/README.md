**NAME:**  
PowerPool  

**Description**:   
PowerPool, disclosed by ESET, has a small number of victims in Chile, Germany, India, Philippine, Poland, Russia, the United Kingdom, the United States and Ukraine. The attack group utilizes Symbolic Link (.slk) files to distribute their malware and exploits zero-day vulnerability in the wild, only two days after its disclosure.
  
**References**:  
https://www.welivesecurity.com/2018/09/05/powerpool-malware-exploits-zero-day-vulnerability/
