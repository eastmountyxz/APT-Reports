|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[2e8d758b9bce51d25ea500d7b4ce4774](https://www.virustotal.com/gui/file/2e8d758b9bce51d25ea500d7b4ce4774)|Win32 DLL||2019-12-11 21:22:26|dttcodexgigas.2ff25745be760769157950d61e5cea308cc0a7ae|
|[8a133a382499e08811dceadcbe07357e](https://www.virustotal.com/gui/file/8a133a382499e08811dceadcbe07357e)|Win32 DLL||2019-11-21 10:16:09|fc7af68ce038b59bcdcee88e46c630036d98aeb6514580ebba0392c37114e57b.sample|
|[5af6c9c49012dabd1468dcfa3f3e49a1](https://www.virustotal.com/gui/file/5af6c9c49012dabd1468dcfa3f3e49a1)|RTF|CVE-2017-11882|2018-12-09 10:46:48|Academic_32.doc|
|[f8858db5b412deb29800458201912b37](https://www.virustotal.com/gui/file/f8858db5b412deb29800458201912b37)|RTF|o97m|2018-07-11 16:07:21|attachment|
|[3c51c89078139337c2c92e084bb0904c](https://www.virustotal.com/gui/file/3c51c89078139337c2c92e084bb0904c)|C||2018-06-04 06:46:02|TOP_NEWS_Japan_to_Support_the_Election.js|
|[5d6ad552f1d1b5cfe99ddb0e2bb51fd7](https://www.virustotal.com/gui/file/5d6ad552f1d1b5cfe99ddb0e2bb51fd7)|C||2018-06-04 06:35:09|Philippines-draws-three-hard-new-lines-on-china .js|
|[217d40ccd91160c152e5fce0143b16ef](https://www.virustotal.com/gui/file/217d40ccd91160c152e5fce0143b16ef)|TXT||2018-06-04 04:33:52|CNR.Movement.mp4.js|
|[e413b45a04bf5f812912772f4a14650f](https://www.virustotal.com/gui/file/e413b45a04bf5f812912772f4a14650f)|TXT||2018-06-01 07:26:28|[pdf]Interview-Questions.pdf.js|
|[cf027a4829c9364d40dcab3f14c1f6b7](https://www.virustotal.com/gui/file/cf027a4829c9364d40dcab3f14c1f6b7)|C||2018-05-23 09:34:42|[docx]Interview-Questions.docx.js|
|[f223e4175649fa2e34271db8c968db12](https://www.virustotal.com/gui/file/f223e4175649fa2e34271db8c968db12)|RTF|o97m|2018-01-31 02:34:04|9d0c4ec62abe79e754eaa2fd7696f98441bc783781d8656065cddfae3dbf503e.bin|
|[bd9e4c82bf12c4e7a58221fc52fed705](https://www.virustotal.com/gui/file/bd9e4c82bf12c4e7a58221fc52fed705)|Win32 EXE||2017-12-24 14:28:34|VirusShare_bd9e4c82bf12c4e7a58221fc52fed705|
|[392f48d32de4cac9949ab7ecab393ba8](https://www.virustotal.com/gui/file/392f48d32de4cac9949ab7ecab393ba8)|RTF|CVE-2017-11882|2017-12-22 07:59:25|Question about story.doc|
|[aca7037286b64b0da05c9708d647c013](https://www.virustotal.com/gui/file/aca7037286b64b0da05c9708d647c013)|RTF|o97m|2017-12-06 18:13:06|Questions about the story.rtf|
|[89e36574ece95178c511705a999a4e6e](https://www.virustotal.com/gui/file/89e36574ece95178c511705a999a4e6e)|RTF|CVE-2017-11882|2017-11-19 16:35:25|c63ccc5c08c3863d7eb330b69f96c1bcf1e031201721754132a4c4d0baff36f8.rtf|
|[6e843ef4856336fe3ef4ed27a4c792b1](https://www.virustotal.com/gui/file/6e843ef4856336fe3ef4ed27a4c792b1)|Win32 DLL|CobaltStrike|2017-08-16 15:30:56|myfile.exe|
|[3eb6f85ac046a96204096ab65bbd3e7e](https://www.virustotal.com/gui/file/3eb6f85ac046a96204096ab65bbd3e7e)|Win32 DLL||2017-08-04 16:18:02|green.ddd|
|[40528e368d323db0ac5c3f5e1efe4889](https://www.virustotal.com/gui/file/40528e368d323db0ac5c3f5e1efe4889)|Win32 EXE||2017-06-19 18:56:12|mt.exe|
|[3fefa55daeb167931975c22df3eca20a](https://www.virustotal.com/gui/file/3fefa55daeb167931975c22df3eca20a)|Win64 DLL||2017-03-23 06:04:29|filedata|
|[a9e7539c1ebe857bae6efceefaa9dd16](https://www.virustotal.com/gui/file/a9e7539c1ebe857bae6efceefaa9dd16)|Win64 DLL|winnti|2015-10-23 04:09:23| |
|[97da0784fddfef932d7d31884f088b40](https://www.virustotal.com/gui/file/97da0784fddfef932d7d31884f088b40)|XLS||2015-10-02 07:02:19|/home/virustotal/sample/97DA0784FDDFEF932D7D31884F088B40|
|[e1f88bc02e9bd15cecc7ae97a009e0d2](https://www.virustotal.com/gui/file/e1f88bc02e9bd15cecc7ae97a009e0d2)|XLS|emodldr|2015-05-27 01:20:00|/home/virustotal/sample/E1F88BC02E9BD15CECC7AE97A009E0D2|
|[d1de5bf033ee31da7babc6fa270f55bb](https://www.virustotal.com/gui/file/d1de5bf033ee31da7babc6fa270f55bb)|XLS||2015-04-07 00:25:51|/home/virustotal/sample/D1DE5BF033EE31DA7BABC6FA270F55BB|
|[c0326d13c9619ebf6ee302cebda6cbfe](https://www.virustotal.com/gui/file/c0326d13c9619ebf6ee302cebda6cbfe)|XLS|o97m|2015-01-18 05:07:39|/home/virustotal/sample/C0326D13C9619EBF6EE302CEBDA6CBFE|
|[7ae50fe69debbfda23a9ae28e1a8df9f](https://www.virustotal.com/gui/file/7ae50fe69debbfda23a9ae28e1a8df9f)|DOCX|o97m|2020-06-22 08:32:30|77ef350639b767ce0a748f94f723a6a88609c67be485b9d8ff8401729b8003d2.bin|
|[dbfa006d64f39cde78b0efda1373309c](https://www.virustotal.com/gui/file/dbfa006d64f39cde78b0efda1373309c)|Win64 DLL||2020-06-17 11:46:48|c:\users\public\sl2.tmp|
|[8114e5e15d4086843cf33e3fca7c945b](https://www.virustotal.com/gui/file/8114e5e15d4086843cf33e3fca7c945b)|DOTM|sLoad|2020-06-17 09:45:12|145daf50aefb7beec32556fd011e10c9eaa71e356649edfce4404409c1e8fa30.bin|
|[afbe00e755a2cf963f0eedbb4e310198](https://www.virustotal.com/gui/file/afbe00e755a2cf963f0eedbb4e310198)|DOCX|sLoad|2020-06-17 08:31:43|ab541df861c6045a17006969dac074a7d300c0a8edd0a5815c8b871b62ecdda7.bin|
|[e9ff489de21c9ff9addef54891ba099e](https://www.virustotal.com/gui/file/e9ff489de21c9ff9addef54891ba099e)|ZIP|sLoad|2020-06-17 08:14:17|523cbdaf31ddc920e5b6c873f3ab42fb791fb4c9d1f4d9e6a7f174105d4f72a1.bin|
|[ccbdda7217ba439dfb6bbc6c3bd594f8](https://www.virustotal.com/gui/file/ccbdda7217ba439dfb6bbc6c3bd594f8)|Win32 DLL||2019-12-11 18:31:11|c:\users\public\sl1.tmp|
|[a827d521181462a45a7077ae3c20c9b5](https://www.virustotal.com/gui/file/a827d521181462a45a7077ae3c20c9b5)|DOCX||2019-11-21 09:04:01|f3186dafca8b032f5b942d81b66d3ab631dc41463d3c8d319f1a0a374f809cdf.bin|
|[5fe8dcdfe9e3c4e56e004b2eebf50ab3](https://www.virustotal.com/gui/file/5fe8dcdfe9e3c4e56e004b2eebf50ab3)|XLS|occamy|2019-09-09 03:44:56|5fe8dcdfe9e3c4e56e004b2eebf50ab3.NP|
|[fe1247780b31bbb9f54a65d3ba17058f](https://www.virustotal.com/gui/file/fe1247780b31bbb9f54a65d3ba17058f)|FPX|occamy|2019-08-20 13:39:02|ed86c10fa96755c0958e84efc66963d6cad72181052b315501dfde3fa89faae9.bin|
|[d81db8c4485f79b4b85226cab4f5b8f9](https://www.virustotal.com/gui/file/d81db8c4485f79b4b85226cab4f5b8f9)|Win32 DLL|Athena|2019-08-19 18:01:27|.|
|[4c89d5d8016581060d9781433cfb0bb5](https://www.virustotal.com/gui/file/4c89d5d8016581060d9781433cfb0bb5)|DOCX|Athena|2019-08-19 04:43:19|d736646093708001e0c1ccd81bc7188f685316858c256e6d81dd69923459a9eb.bin|
|[b427c7253451268ca97de38be04bf59a](https://www.virustotal.com/gui/file/b427c7253451268ca97de38be04bf59a)|Win32 DLL|occamy|2019-07-26 00:50:57|d99d308027b57f14cb4a6100ef5460f353e708f93ee442e296b9613017e5e0f7.sample|
|[cf94796a07b6082b9e348eef934de97a](https://www.virustotal.com/gui/file/cf94796a07b6082b9e348eef934de97a)|Win32 DLL||2019-07-25 08:11:52|0f0f51d50dfb4912991537df670c158f8191e81c8280043c19fd6f40b3d78aed.bin|
|[6889c7905df000b874bfc2d782512877](https://www.virustotal.com/gui/file/6889c7905df000b874bfc2d782512877)|DOCX|occamy|2019-07-24 20:56:34|Azmin Ali sex video.docx|
|[f744481a4c4a7c811ffc7dee3b58b1ff](https://www.virustotal.com/gui/file/f744481a4c4a7c811ffc7dee3b58b1ff)|DOCX|occamy|2019-07-24 14:39:16|SENARAI JAWATANKUASA MPP 2018-2022_ROS.docx|
|[ae342bf6b1bd0401a42aae374f961fc6](https://www.virustotal.com/gui/file/ae342bf6b1bd0401a42aae374f961fc6)|FPX|Ursu|2019-03-27 13:12:36|ceb6e517caf3ce3b1335399352018953dee50b7ac6e06b436be8f1dccd351602.bin|
|[01b5276fdfda2043980cbce19117aaa0](https://www.virustotal.com/gui/file/01b5276fdfda2043980cbce19117aaa0)|DOCX|Ursu|2019-03-27 08:19:49|fce38b7bb25817ccaf921d5ac96f4e6c9b865fbe020204af5cf34b604868d1fa.bin|
|[4c47ca6ecf04cfe312eb276022a0c381](https://www.virustotal.com/gui/file/4c47ca6ecf04cfe312eb276022a0c381)|Win32 DLL|Ursu|2019-03-27 07:47:01|myfile.exe|
|[89a81ea2b9ee9dd65d0a82b094099b43](https://www.virustotal.com/gui/file/89a81ea2b9ee9dd65d0a82b094099b43)|Win32 DLL|Shelma|2019-03-06 16:10:29|myfile.exe|
|[7233ad2ba31d98ff5dd47db1b5a9fe7c](https://www.virustotal.com/gui/file/7233ad2ba31d98ff5dd47db1b5a9fe7c)|DOCX|Shelma|2019-02-16 08:22:48|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\a96b6cc3baa612fbeece348418959f25b4eee729b82fb63f2d926ced06bed9ed|
|[3cb38f7574e8ea97db53d3857830fcc4](https://www.virustotal.com/gui/file/3cb38f7574e8ea97db53d3857830fcc4)|DOCX|o97m|2018-12-05 11:16:48|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\4e90ad68383b8ab8d540f87f9cb6bdcb1e71c91e313d2933ed05aed083835fb9|
|[3ca84fe6cec9bf2e2abac5a8f1e0a8d2](https://www.virustotal.com/gui/file/3ca84fe6cec9bf2e2abac5a8f1e0a8d2)|DOCX|o97m|2018-08-24 01:05:41|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\24bf66592aa12794505d2b970373ef32c8aa6ebb0905552acd3e49744c7e5c8b|
|[850a163ce1f9cff0367854038d8cfa7e](https://www.virustotal.com/gui/file/850a163ce1f9cff0367854038d8cfa7e)|Win32 EXE||2013-10-17 20:59:49|LogiMailApp.exe|
