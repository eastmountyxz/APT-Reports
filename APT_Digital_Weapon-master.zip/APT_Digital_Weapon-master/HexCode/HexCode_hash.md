|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[471d7a42b9c87074e8dab4d679469fb7](https://www.virustotal.com/gui/file/471d7a42b9c87074e8dab4d679469fb7)|Win32 EXE|Athena|2019-08-30 11:33:54|Завершена дипломатическая миссия Посла Казахстана в Кыргызстане (29082019).exe|
|[52a4368870c22f9dec361f9508e93ef5](https://www.virustotal.com/gui/file/52a4368870c22f9dec361f9508e93ef5)|Win32 EXE||2019-03-27 05:42:55|dttcodexgigas.4264e92de9b775fd34df05a6fd0cf49d2ca64dce|
|[db8d20e972c73adf2f00251f6328921c](https://www.virustotal.com/gui/file/db8d20e972c73adf2f00251f6328921c)|Win32 EXE||2019-03-27 02:27:29|db8d20e972c73adf2f00251f6328921c.virus|
|[df382f3149558a3796c142515abbd6f4](https://www.virustotal.com/gui/file/df382f3149558a3796c142515abbd6f4)|Win32 EXE||2019-02-12 15:22:39|Blue Wireless|
|[e7835653876bf987ab6aeb42467af4c3](https://www.virustotal.com/gui/file/e7835653876bf987ab6aeb42467af4c3)|Win32 EXE||2018-11-06 09:09:50|taskhost.exe|
|[ef7df193af3f10c2e78f6cebce68f38d](https://www.virustotal.com/gui/file/ef7df193af3f10c2e78f6cebce68f38d)|DOC||2018-03-13 11:37:10||
|[ad7f32a5bcbd2b50844a559901098702](https://www.virustotal.com/gui/file/ad7f32a5bcbd2b50844a559901098702)|Win32 EXE|dynamer|2016-06-20 01:09:44|taskmgs.exe|
|[79732834c8b298db639358ae5b9f6689](https://www.virustotal.com/gui/file/79732834c8b298db639358ae5b9f6689)|DOCM||2020-03-04 14:10:31|СВОДНАЯ БАЗА ИНОСТРАННЫХ ЖУРНАЛИСТОВ(626 чел.).docm|
