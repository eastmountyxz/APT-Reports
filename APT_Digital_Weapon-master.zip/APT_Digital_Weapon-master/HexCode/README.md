**NAME:**  
HexCode  

**Description**:   
HexCode, named by ThreatBook, becomes active since at least 2016 and carries out long-term attacks on government, foreign affairs, intelligence agencies, medical and health departments in Western and Eastern Europe countries. This attack group is suspected to be from Russia.
  
**References**:  
https://www.secrss.com/articles/14309
