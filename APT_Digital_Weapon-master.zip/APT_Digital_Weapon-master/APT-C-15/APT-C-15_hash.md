|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[453c829c2b7f504e28b554927f4bc1f2](https://www.virustotal.com/gui/file/453c829c2b7f504e28b554927f4bc1f2)|Android||2019-03-21 23:21:51|nms-swiftclinic.apk|
|[28c3759bccb1578b9e094920a32813ef](https://www.virustotal.com/gui/file/28c3759bccb1578b9e094920a32813ef)|Android||2017-11-25 22:40:33|28c3759bccb1578b9e094920a32813ef.virus|
|[1c9f350373bdfe2c72625d8d9132b073](https://www.virustotal.com/gui/file/1c9f350373bdfe2c72625d8d9132b073)|Android||2017-11-23 22:14:37|1c9f350373bdfe2c72625d8d9132b073.virus|
|[9eb2a874c022a8be7534ba006d44f699](https://www.virustotal.com/gui/file/9eb2a874c022a8be7534ba006d44f699)|Android||2017-07-10 10:58:05|9eb2a874c022a8be7534ba006d44f699.virus|
|[20647f395a044de094c48f24505a2f02](https://www.virustotal.com/gui/file/20647f395a044de094c48f24505a2f02)|Android||2017-03-22 00:02:28|20647f395a044de094c48f24505a2f02.virus|
|[b00f5e53cc654a3ac7a0e72cd3b5f5d3](https://www.virustotal.com/gui/file/b00f5e53cc654a3ac7a0e72cd3b5f5d3)|Android||2015-06-10 16:48:55|b00f5e53cc654a3ac7a0e72cd3b5f5d3.virus|
|[c80b3fb9293a932b4e814a32e7ca76d3](https://www.virustotal.com/gui/file/c80b3fb9293a932b4e814a32e7ca76d3)|Win32 EXE|Disfa|2014-07-15 19:03:35|3yaz4tba.exe|
|[52f461a133e95328ccd9ba7f70e2f3e6](https://www.virustotal.com/gui/file/52f461a133e95328ccd9ba7f70e2f3e6)|Win32 EXE||2014-07-15 13:14:08|3yaz4tba.exe|
