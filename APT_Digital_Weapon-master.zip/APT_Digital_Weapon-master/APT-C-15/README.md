**NAME:**  
APT-C-15  
  
**Alias**  
人面狮, Sphinx, APT-C-15  
  
**Description**:   
APT-C-15 is related to cyber espionage activities in the Middle East targeting countries such as Egypt and Israel to steal confidential information. Related attacks could trace back to December 2011 and was quite active from June 2014 to November 2015.
  
**References**:  
https://ti.qianxin.com/uploads/2018/01/26/554041d1d8ead9711ca04b1dc8daa744.pdf
