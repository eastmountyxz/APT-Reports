|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[1f6375a4a6cac6a12172c87eff7cafce](https://www.virustotal.com/gui/file/1f6375a4a6cac6a12172c87eff7cafce)|Android||2020-07-31 12:38:10|Mltqana.apk|
|[d7f7a907cd1dc1d34695759d4669409b](https://www.virustotal.com/gui/file/d7f7a907cd1dc1d34695759d4669409b)|Win32 EXE|Disfa|2020-04-25 05:41:25|d7f7a907cd1dc1d34695759d4669409b.virus|
|[f67674f89e1c9727ea6aeffd71949748](https://www.virustotal.com/gui/file/f67674f89e1c9727ea6aeffd71949748)|Win32 EXE||2020-01-21 11:38:29|up4net-mltqanainst.exe|
|[7958aab62e49c69ef8f64765a377788c](https://www.virustotal.com/gui/file/7958aab62e49c69ef8f64765a377788c)|Win32 EXE|Johnnie|2019-08-24 12:44:31|C:\google\client.exe|
|[a228ba347cc2ca2b97f0c1e6e5e07558](https://www.virustotal.com/gui/file/a228ba347cc2ca2b97f0c1e6e5e07558)|Android||2019-05-03 21:46:09|/1/c/7/c77a066c9774e12d6a49589196463c1c96244225dde6b3a6f5af1b7dac34f46c.file|
|[9da77984d89f70705f9fa9c7dd904f5a](https://www.virustotal.com/gui/file/9da77984d89f70705f9fa9c7dd904f5a)|Win32 EXE|Kryptik|2019-02-03 04:59:50|Client1.exe|
|[8a8b2e08c4087735ca214640f52a7215](https://www.virustotal.com/gui/file/8a8b2e08c4087735ca214640f52a7215)|Android||2018-08-07 11:16:35|client.apk|
|[6f7b51344e8956325859a2ec37ac2d25](https://www.virustotal.com/gui/file/6f7b51344e8956325859a2ec37ac2d25)|Win32 EXE|Barys|2018-07-28 05:10:19|syystme.exe|
|[dc32f1e2c8e46a283522f680689df577](https://www.virustotal.com/gui/file/dc32f1e2c8e46a283522f680689df577)|Win32 EXE|SamSam|2018-06-15 06:29:40|4.exe|
|[ca0697a4cb47108dc2322b09de1868e0](https://www.virustotal.com/gui/file/ca0697a4cb47108dc2322b09de1868e0)|Win32 EXE|Ursu|2018-05-11 04:47:55|ca0697a4cb47108dc2322b09de1868e0.virobj|
|[d6ba589af24ff96e9c1f356398243156](https://www.virustotal.com/gui/file/d6ba589af24ff96e9c1f356398243156)|Win32 EXE|MSILPerseus|2018-05-09 19:14:22|5552.exe|
|[6ecd6914eb992734dfbca11cd41afb07](https://www.virustotal.com/gui/file/6ecd6914eb992734dfbca11cd41afb07)|Win32 EXE|Ursu|2018-03-22 18:25:28|079d8afd17f29e432a42e7b0895c6a895e00b7d7|
|[80bbdc982ed7d5728c9005f1713db4c7](https://www.virustotal.com/gui/file/80bbdc982ed7d5728c9005f1713db4c7)|Android|Wacatac|2017-12-02 12:15:23|80bbdc982ed7d5728c9005f1713db4c7|
|[57ac433c6ae67fa45699b8b08fb04142](https://www.virustotal.com/gui/file/57ac433c6ae67fa45699b8b08fb04142)|Win32 EXE|Disfa|2017-11-15 20:00:29|1000-60ef8cf5b798ba5b89d361b8befc7047863214ab|
|[ec9ccaf9a8e0421748c3460f76289a48](https://www.virustotal.com/gui/file/ec9ccaf9a8e0421748c3460f76289a48)|Win32 EXE|Disfa|2017-11-15 18:55:52|system.exe|
|[32e3e9106c57f1089c136fe78dfe5e38](https://www.virustotal.com/gui/file/32e3e9106c57f1089c136fe78dfe5e38)|Win32 EXE|Disfa|2017-11-15 18:41:10|system.exe|
|[de7cfef57b848a8d7f0a1d4828d6f1ed](https://www.virustotal.com/gui/file/de7cfef57b848a8d7f0a1d4828d6f1ed)|Win32 EXE|Ursu|2017-11-15 09:40:59|clien.exe|
|[fe8b2df29417a27881f4727c35aae61e](https://www.virustotal.com/gui/file/fe8b2df29417a27881f4727c35aae61e)|Win32 EXE|Ursu|2017-11-15 09:35:41|clien.exe|
|[291d4bdbab778d045aedd11788762e82](https://www.virustotal.com/gui/file/291d4bdbab778d045aedd11788762e82)|Win32 EXE|Ursu|2017-11-15 09:35:05|clien.exe|
|[ce0f944b84b823e1267175d6b4f5cdbd](https://www.virustotal.com/gui/file/ce0f944b84b823e1267175d6b4f5cdbd)|Win32 EXE|Disfa|2017-11-14 22:13:08|clien.exe|
|[72425aac85ead205e3d26392fb414e1d](https://www.virustotal.com/gui/file/72425aac85ead205e3d26392fb414e1d)|Win32 EXE|Ursu|2017-11-14 02:02:37|clien.exe|
|[9e1ef7349b74d0be83d7374909937c47](https://www.virustotal.com/gui/file/9e1ef7349b74d0be83d7374909937c47)|Win32 EXE|Disfa|2017-11-13 09:36:08|1010-8f5155bff264571fcb8cb5c63e89aa80a0a7392c|
|[10335258e279c1ec346e9bedae2776dd](https://www.virustotal.com/gui/file/10335258e279c1ec346e9bedae2776dd)|Win32 EXE|Razy|2017-11-13 05:20:46|system.exe|
|[04b37c5776e2a2424d47472fc3e9aaf5](https://www.virustotal.com/gui/file/04b37c5776e2a2424d47472fc3e9aaf5)|Win32 EXE|Razy|2017-11-12 18:11:08|%APPDATA%\microsoft\windows\start menu\programs\startup\300f2ef33b4edc11780392d2a3c73606.exe|
|[a6bea852441fd3a2658d4882f1823492](https://www.virustotal.com/gui/file/a6bea852441fd3a2658d4882f1823492)|Win32 EXE|Disfa|2017-11-12 09:45:14|system.exe|
|[81b910bed85a80781aafadde79832405](https://www.virustotal.com/gui/file/81b910bed85a80781aafadde79832405)|Win32 EXE|Razy|2017-11-12 09:24:22|1010-a20d3e5f8e3fd9a06edebe9d9bfaf48e500a9810|
|[c238894641abfeb9411f7e9ffb1999f4](https://www.virustotal.com/gui/file/c238894641abfeb9411f7e9ffb1999f4)|Win32 EXE|Disfa|2017-11-10 21:31:22|1010-57e75b0f68782ad7f5071c6b9c58ca28dc272f96|
|[f4a2b85463cea2d05ca672069acfa364](https://www.virustotal.com/gui/file/f4a2b85463cea2d05ca672069acfa364)|Android||2017-10-29 04:47:32| |
|[e846dc1ab2fdeae0f02faf9f92626a9e](https://www.virustotal.com/gui/file/e846dc1ab2fdeae0f02faf9f92626a9e)|Win32 EXE|Razy|2017-10-28 06:11:33|system.exe|
|[be6e448595e3a98ddd11c3cfb49e51e6](https://www.virustotal.com/gui/file/be6e448595e3a98ddd11c3cfb49e51e6)|Win32 EXE|Disfa|2017-10-28 06:05:27|E:/virussign/malware/new_request/20171029/be6e448595e3a98ddd11c3cfb49e51e6.vir|
|[f68578468ff8fd930079871643277b9e](https://www.virustotal.com/gui/file/f68578468ff8fd930079871643277b9e)|Win32 EXE|Disfa|2017-10-28 06:01:38|E:/virussign/malware/new_request/20171029/f68578468ff8fd930079871643277b9e.vir|
|[bd4d1f6a435639fc6f01af26237e0a31](https://www.virustotal.com/gui/file/bd4d1f6a435639fc6f01af26237e0a31)|Win32 EXE|Razy|2017-10-28 03:20:46|system.exe|
|[78fc9320dc84109cd50d17379fada888](https://www.virustotal.com/gui/file/78fc9320dc84109cd50d17379fada888)|Win32 EXE||2017-10-27 16:13:19|egchat_5.4.4.exe|
|[1455f631b08b4c7a4ae1c5c8c319d64f](https://www.virustotal.com/gui/file/1455f631b08b4c7a4ae1c5c8c319d64f)|Win32 EXE|Disfa|2017-10-25 08:47:07|E:/virussign/malware/new_request/20171028/1455f631b08b4c7a4ae1c5c8c319d64f.vir|
|[508c7f8c30c558c3c5bdbdb3f6a8b1c9](https://www.virustotal.com/gui/file/508c7f8c30c558c3c5bdbdb3f6a8b1c9)|Win32 EXE|Xtreme|2017-10-22 20:26:57|c6dc4a940e6793e903c9ff4e556796391a2a4d45|
|[98bc19c0196a9e12a334adf5c505a78d](https://www.virustotal.com/gui/file/98bc19c0196a9e12a334adf5c505a78d)|Win32 EXE|Disfa|2017-02-19 06:40:35|%TEMP%\system.exe|
|[fec9ff0cd85e820ac779ea25e3fefb24](https://www.virustotal.com/gui/file/fec9ff0cd85e820ac779ea25e3fefb24)|Android|Kasandra|2017-02-12 16:44:43|2.apk|
