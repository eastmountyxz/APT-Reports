**NAME:**  
APT-C-44
 

**Description**:   
APT-C-44 has targeted the Arabic-speaking region for three years since 2017 with dual-platform payloads on Windows and Android. It mainly uses phishing and third-party hosting websites to delivery payload and social media to spread. The victims are mainly located in Arab region including those with military background.

  
**References**:  
https://mp.weixin.qq.com/s/gWOIRNPLVqX761LW8x-S5g