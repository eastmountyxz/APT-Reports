**NAME:**  
APT-C-01 
  
**Alias**  
穷奇, APT-C-01, 绿斑, GreenSpot, 白海豚, 毒云藤  

**Description**:  
APT-C-01, uncovered by QiAnXin Threat Intelligence Center, is an APT group located in Taiwan, China. The earliest activity could trace back to the year of 2007.
  
**References**:  
https://ti.qianxin.com/uploads/2018/09/20/6f8ad451646c9eda1f75c5d31f39f668.pdf