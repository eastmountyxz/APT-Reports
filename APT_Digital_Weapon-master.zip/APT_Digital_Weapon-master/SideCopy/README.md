**NAME:**  
SideCopy
 

**Description**:   
SideCopy is active from early 2019 and misleads the security community by copying TTPs that point at the Sidewinder APT group.

  
**References**:  
https://www.seqrite.com/documents/en/white-papers/Seqrite-WhitePaper-Operation-SideCopy.pdf