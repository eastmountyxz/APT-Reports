|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[ec885733d385c50954bdbb8b76e8b33d](https://www.virustotal.com/gui/file/ec885733d385c50954bdbb8b76e8b33d)|Win32 DLL||2019-10-23 20:36:55|sqlite3|
|[6cec260af40675ff2ae731ae3f76706b](https://www.virustotal.com/gui/file/6cec260af40675ff2ae731ae3f76706b)|TXT||2019-10-10 08:06:24|resources[1].js|
|[14503cc985d8a9517fa530293865dae4](https://www.virustotal.com/gui/file/14503cc985d8a9517fa530293865dae4)|Win32 DLL||2019-09-17 19:58:43|CIAsmbly|
|[923beee2e2b26bbad1ace665ca7cd1de](https://www.virustotal.com/gui/file/923beee2e2b26bbad1ace665ca7cd1de)|TXT||2019-09-12 17:47:27|923beee2e2b26bbad1ace665ca7cd1de.js|
|[df4cca6a27d6a2f463124fb69a014155](https://www.virustotal.com/gui/file/df4cca6a27d6a2f463124fb69a014155)|TXT||2019-09-10 06:29:03|df4cca6a27d6a2f463124fb69a014155.js|
|[fe2d6b4511ac81221684a5f6a0634a4b](https://www.virustotal.com/gui/file/fe2d6b4511ac81221684a5f6a0634a4b)|Win32 DLL||2019-09-07 12:50:04|libcef|
|[302461e359118d3b8024dab1c75e7ff9](https://www.virustotal.com/gui/file/302461e359118d3b8024dab1c75e7ff9)|Win32 DLL||2019-07-12 16:49:08|CIAsmbly|
|[0eb7ac6d2d99d702ecc8b86ff90b0aac](https://www.virustotal.com/gui/file/0eb7ac6d2d99d702ecc8b86ff90b0aac)|Win64 DLL||2019-05-15 10:30:47|7a207137e7b234e680116aa071f049c8472e4fb5990a38dab264d0a4cde126df.bin|
|[031dd207c8276bcc5b41825f0a3e31b0](https://www.virustotal.com/gui/file/031dd207c8276bcc5b41825f0a3e31b0)|Text||2019-04-05 23:10:16|bkvlhwa0|
|[70f299ab247519e2dda8e172ae346277](https://www.virustotal.com/gui/file/70f299ab247519e2dda8e172ae346277)|Win32 DLL||2019-03-04 14:25:16|dragext|
|[89314a469de69addafff5b5d7a96071d](https://www.virustotal.com/gui/file/89314a469de69addafff5b5d7a96071d)|Win32 DLL||2019-03-01 17:15:31|intl.dll|
|[3b9646bf2d791e5ef4633e802f23e305](https://www.virustotal.com/gui/file/3b9646bf2d791e5ef4633e802f23e305)|Win32 DLL||2019-02-26 22:27:20|39236 (1).txt|
|[c6899904284c57f9ccca1b5bd26a59d8](https://www.virustotal.com/gui/file/c6899904284c57f9ccca1b5bd26a59d8)|Win32 DLL||2019-02-26 22:26:49|dragext|
|[f6dd749965d737b22278e73d32969ab8](https://www.virustotal.com/gui/file/f6dd749965d737b22278e73d32969ab8)|Text||2019-02-26 03:03:14|42zce9xj|
|[fe148b212b26e43c9f9e736a8e463e1f](https://www.virustotal.com/gui/file/fe148b212b26e43c9f9e736a8e463e1f)|TXT|Kryptik|2019-02-14 15:48:51|/home/ubuntu/pastes/G4bY1D2P.posh|
|[5ffa5b6e579549f76535e9f7d2715e99](https://www.virustotal.com/gui/file/5ffa5b6e579549f76535e9f7d2715e99)|TXT||2019-02-12 11:06:03|info.hta|
|[e03fe420460eff84474532f0de5cc2fc](https://www.virustotal.com/gui/file/e03fe420460eff84474532f0de5cc2fc)|Text||2019-02-07 09:44:50|payload.txt|
|[93d21cc0464667250ef627ca8d5b2f78](https://www.virustotal.com/gui/file/93d21cc0464667250ef627ca8d5b2f78)|Text||2019-02-06 23:32:55|payload.txt|
|[18728712eb7f28ec0c0869cfa335a36a](https://www.virustotal.com/gui/file/18728712eb7f28ec0c0869cfa335a36a)|Text||2019-02-05 06:28:07|payload_bypass.txt|
|[16cd90eec02a1d6f998f9037bb889b19](https://www.virustotal.com/gui/file/16cd90eec02a1d6f998f9037bb889b19)|Text|Kryptik|2019-02-05 03:29:06|/home/ubuntu/pastes/BKVLHWa0.posh|
|[46d781620afc536afa25381504059612](https://www.virustotal.com/gui/file/46d781620afc536afa25381504059612)|Text|Kryptik|2019-02-05 00:45:02|YAm4QnE7|
|[8452d52034d3b2cb612dbc59ed609163](https://www.virustotal.com/gui/file/8452d52034d3b2cb612dbc59ed609163)|Text|Kryptik|2019-02-04 15:05:03|HPpvY00Q|
|[06b7299d664a7fe0bac74c72462e80e5](https://www.virustotal.com/gui/file/06b7299d664a7fe0bac74c72462e80e5)|Text|rozena|2019-02-03 18:22:34|.|
|[8c099a15a19b6e5b29a3794abf8a5878](https://www.virustotal.com/gui/file/8c099a15a19b6e5b29a3794abf8a5878)|Text|Kryptik|2019-02-01 13:05:02|p5U9siCD|
|[8ba211c5e31e0be9c83e4197753d3abc](https://www.virustotal.com/gui/file/8ba211c5e31e0be9c83e4197753d3abc)|Text|rozena|2019-02-01 10:46:29|evil.hta|
|[55f7105c276465db827c9572e562b551](https://www.virustotal.com/gui/file/55f7105c276465db827c9572e562b551)|Text||2019-02-01 06:26:55|6a1be30c9854bf7f97ebd6fb2ef85e527279dbebd8f700980718febbf53f4d6a.bat.bin|
|[e5f8345468bafa45b1085c5d29c489fe](https://www.virustotal.com/gui/file/e5f8345468bafa45b1085c5d29c489fe)|Text||2019-01-31 09:14:37|Copy.bat|
|[32ea267296c8694c0b5f5baeacf34b0e](https://www.virustotal.com/gui/file/32ea267296c8694c0b5f5baeacf34b0e)|Text|Kryptik|2019-01-30 11:45:02|wrehJuGp|
|[5532dcb20cd2df242a29740415100f30](https://www.virustotal.com/gui/file/5532dcb20cd2df242a29740415100f30)|Text|rozena|2019-01-26 03:49:18|/home/ubuntu/pastes/tDAbbY52.posh|
|[86a26fd727e426ba63f20934d201e452](https://www.virustotal.com/gui/file/86a26fd727e426ba63f20934d201e452)|Text|rozena|2019-01-24 15:47:49|0v6RiYEY.posh|
|[34187a34d0a3c5d63016c26346371b54](https://www.virustotal.com/gui/file/34187a34d0a3c5d63016c26346371b54)|Text|megacortex|2019-01-24 13:52:28|kill.bat|
|[5c0bf7033362bb5c4b92b9b21c2f2253](https://www.virustotal.com/gui/file/5c0bf7033362bb5c4b92b9b21c2f2253)|Text||2019-01-22 20:54:14|test.bat|
|[3dd9097c30ee1af788caef49feca1db6](https://www.virustotal.com/gui/file/3dd9097c30ee1af788caef49feca1db6)|Text||2019-01-22 13:42:40|Mzd1HFrN.posh|
|[bd0b64c323cb3a1e9dccb390e94cf4f6](https://www.virustotal.com/gui/file/bd0b64c323cb3a1e9dccb390e94cf4f6)|Text||2019-01-19 00:55:02|/home/ubuntu/pastes/KVwVMtN3.posh|
|[32e973f590ca2103c2ecf7731ed4019c](https://www.virustotal.com/gui/file/32e973f590ca2103c2ecf7731ed4019c)|Text||2019-01-15 18:16:20|myvtfile.exe|
|[94495f518f7e2593d02ce574824fc69f](https://www.virustotal.com/gui/file/94495f518f7e2593d02ce574824fc69f)|TXT||2019-01-09 16:30:43|eventinformation-tellurium-group.hta|
|[9fa269146c721b15874c1c463596cb88](https://www.virustotal.com/gui/file/9fa269146c721b15874c1c463596cb88)|Text||2019-01-05 14:37:31|powershell.hta|
|[1ac0c982323f0329c24262f434d606b9](https://www.virustotal.com/gui/file/1ac0c982323f0329c24262f434d606b9)|Text||2018-12-27 07:00:51|a.vir|
|[c9c2029d21f0632c7ca1571b10276117](https://www.virustotal.com/gui/file/c9c2029d21f0632c7ca1571b10276117)|TXT|Kryptik|2018-12-23 18:19:09|znR3rgbs.posh|
|[a346beb5ac9c272e2125ba46a60c5cda](https://www.virustotal.com/gui/file/a346beb5ac9c272e2125ba46a60c5cda)|Text|rozena|2018-12-20 09:32:50|evil.hta|
|[33ca7cc9cd8fe3eaa947f958d5ddcec9](https://www.virustotal.com/gui/file/33ca7cc9cd8fe3eaa947f958d5ddcec9)|TXT||2018-12-12 12:37:06| |
|[db011f0b578a72b36053d1ecdcf8cabf](https://www.virustotal.com/gui/file/db011f0b578a72b36053d1ecdcf8cabf)|Text|rozena|2018-12-11 22:24:07|071d5c44d21c365c13133d46b93a94bc.js|
|[bd3f29e8ff220e4ce457caa2a21229ec](https://www.virustotal.com/gui/file/bd3f29e8ff220e4ce457caa2a21229ec)|Text|rozena|2018-12-11 20:33:24|payload.txt|
|[3907460c7b05f903770adf48edc1d273](https://www.virustotal.com/gui/file/3907460c7b05f903770adf48edc1d273)|TXT||2018-12-11 19:51:36|1.hta|
|[1f3914b136add78a50b085a521512205](https://www.virustotal.com/gui/file/1f3914b136add78a50b085a521512205)|HTML|rozena|2018-12-11 19:35:42|BitGroupPricelistPS2019.hta|
|[ad1823edcac1babe11f111a3bcbc9f29](https://www.virustotal.com/gui/file/ad1823edcac1babe11f111a3bcbc9f29)|Text||2018-12-11 15:18:07|evil.hta|
|[4e7368de856618a015e6b1d359872c92](https://www.virustotal.com/gui/file/4e7368de856618a015e6b1d359872c92)|Text|rozena|2018-12-07 13:31:42|H:\rebelshare\evtfwd.bat|
|[550523632356c952bf12b4981451584f](https://www.virustotal.com/gui/file/550523632356c952bf12b4981451584f)|TXT|Kryptik|2018-11-30 05:03:20| |
|[c9141a83dfcee3fbfe0f09123031e4f7](https://www.virustotal.com/gui/file/c9141a83dfcee3fbfe0f09123031e4f7)|Text||2018-11-28 21:59:11| |
|[55ebbcbe9939274277249b078c3f4071](https://www.virustotal.com/gui/file/55ebbcbe9939274277249b078c3f4071)|Text|injector|2018-11-28 21:46:07|execute.bat|
|[879a1590504780bf9ffa681b262ef392](https://www.virustotal.com/gui/file/879a1590504780bf9ffa681b262ef392)|Text|rozena|2018-11-28 14:40:16|071d5c44d21c365c13133d46b93a94bc.js|
|[2f5c3b24e27cbfae639c2a0d58d32661](https://www.virustotal.com/gui/file/2f5c3b24e27cbfae639c2a0d58d32661)|HTML|rozena|2018-11-28 04:56:36|start.hta|
|[8c9903db02a29847d04d0fd81dd67046](https://www.virustotal.com/gui/file/8c9903db02a29847d04d0fd81dd67046)|Text|rozena|2018-11-23 21:11:39|nox.hta|
|[988ba93160b218f211254cf9aedee1d5](https://www.virustotal.com/gui/file/988ba93160b218f211254cf9aedee1d5)|Text||2018-11-20 04:23:21|PowerShellEncoded-Cobalt.Strike|
|[c73568746c551dee85853fad9bb3fb59](https://www.virustotal.com/gui/file/c73568746c551dee85853fad9bb3fb59)|Text||2018-10-27 02:48:51|myvtfile.exe|
|[ed543f9f62c075aa2c372e52a8ea970a](https://www.virustotal.com/gui/file/ed543f9f62c075aa2c372e52a8ea970a)|Text|rozena|2018-10-24 15:50:34|myvtfile.exe|
|[c4ea4126448fffed260cc4e698dfe402](https://www.virustotal.com/gui/file/c4ea4126448fffed260cc4e698dfe402)|Text|rozena|2018-10-22 19:21:03|myvtfile.exe|
|[12597de0e709e44442418e89721b9140](https://www.virustotal.com/gui/file/12597de0e709e44442418e89721b9140)|Win32 EXE|Ryuk|2018-10-10 12:22:46|/home/seclab/Documents/meseum_data/only_using_data_set/indexing/12597de0e709e44442418e89721b9140.vir|
|[524ddd7c6931ad3ef4c1e34688fd33c4](https://www.virustotal.com/gui/file/524ddd7c6931ad3ef4c1e34688fd33c4)|C||2018-10-10 10:09:06|apt_wilted_tulip.yar|
|[716e976e96fc2baf4ba818c2ab94513c](https://www.virustotal.com/gui/file/716e976e96fc2baf4ba818c2ab94513c)|Text||2018-09-17 09:09:56|myvtfile.exe|
|[3c5575ce80e0847360cd2306c64b51a0](https://www.virustotal.com/gui/file/3c5575ce80e0847360cd2306c64b51a0)|Win64 EXE|Ryuk|2018-09-06 07:57:31|de708f2807f96938e5eb0295d5ebfee870b34dd0cb70708607d4e1adf767ce7b.bin|
|[87858b384219cc6256f2bdb5eafaa646](https://www.virustotal.com/gui/file/87858b384219cc6256f2bdb5eafaa646)|Text|shelma|2018-08-27 13:54:20|ps.bat|
|[39702286994d7023b3d002cf31e1a6ad](https://www.virustotal.com/gui/file/39702286994d7023b3d002cf31e1a6ad)|Win32 DLL||2018-04-17 03:50:11|tt|
|[67a53bd24ee8499fed79c8c368e05f7a](https://www.virustotal.com/gui/file/67a53bd24ee8499fed79c8c368e05f7a)|Win32 EXE||2017-11-25 00:21:05|Dll Launcher|
|[413df8eb260b183003a5a1e009734f52](https://www.virustotal.com/gui/file/413df8eb260b183003a5a1e009734f52)|Win32 DLL|Ursu|2020-01-09 18:54:42|intl.dll|
|[9b3ec7553b079f413565a7f61c8efd3c](https://www.virustotal.com/gui/file/9b3ec7553b079f413565a7f61c8efd3c)|Win32 DLL|occamy|2019-03-08 09:44:16|intl.dll|
