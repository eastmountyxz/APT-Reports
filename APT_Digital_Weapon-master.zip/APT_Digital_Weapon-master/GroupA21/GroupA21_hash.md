|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[6a271282fe97322d49e9692891332ad7](https://www.virustotal.com/gui/file/6a271282fe97322d49e9692891332ad7)|Win32 EXE|Tiggre|2019-10-17 17:22:48|.|
|[791253aded5df197d9db441a6fe2eb4e](https://www.virustotal.com/gui/file/791253aded5df197d9db441a6fe2eb4e)|LNK||2019-10-17 10:37:59|Eligibilty.pdf.lnk|
|[d2579dfd4899e58aebc965b060725b21](https://www.virustotal.com/gui/file/d2579dfd4899e58aebc965b060725b21)|ZIP||2019-10-15 09:29:09|Registration_Details.zip|
|[671e6489dd838c51a76922c45935a4b7](https://www.virustotal.com/gui/file/671e6489dd838c51a76922c45935a4b7)|RAR||2019-07-12 16:51:33|shipment.rar|
|[02e81e2ba998919f1716b881505f2a89](https://www.virustotal.com/gui/file/02e81e2ba998919f1716b881505f2a89)|LNK||2019-05-26 02:29:22| |
|[3aa327948d02d24d6139ae89564ff791](https://www.virustotal.com/gui/file/3aa327948d02d24d6139ae89564ff791)|ZIP||2019-05-25 23:24:28|CNS_Guidelines_2019.zip|
|[dbcfb692afc730bc9b219b1ae2955977](https://www.virustotal.com/gui/file/dbcfb692afc730bc9b219b1ae2955977)|Win32 EXE|Johnnie|2019-04-10 20:44:47| |
|[1255eb3e81ec17d030da6884e0d3c724](https://www.virustotal.com/gui/file/1255eb3e81ec17d030da6884e0d3c724)|Win32 EXE|Blocker|2019-03-16 04:44:36|9bc75c69ead3c8ae7297911c3603cecc3f3d3c739cd5ebb60b111af1939c6952.exe|
|[9c9ff19affff6d62e72e618f2b7284da](https://www.virustotal.com/gui/file/9c9ff19affff6d62e72e618f2b7284da)|RTF|CVE-2017-11882|2019-02-25 10:46:31|Pay_Slip2.txt|
|[6a19e8a202dfdb11bf3aaf9e53f8776a](https://www.virustotal.com/gui/file/6a19e8a202dfdb11bf3aaf9e53f8776a)|ELF executable||2019-02-20 05:50:23|intern|
|[d160d0845b654c3aa23552ac0a3725a7](https://www.virustotal.com/gui/file/d160d0845b654c3aa23552ac0a3725a7)|Win32 EXE|Athena|2019-01-01 04:16:22|Betrayal_of_Pakistan_by_China.exe|
|[3d6aab4e4e055b9c50837c6adc97e060](https://www.virustotal.com/gui/file/3d6aab4e4e055b9c50837c6adc97e060)|Win32 EXE|Blocker|2018-12-11 08:48:05|ISI_Role_Sino-PAK_Nuclear_Deal.exe|
|[b0114e499ba0e395835930e68d5b5c87](https://www.virustotal.com/gui/file/b0114e499ba0e395835930e68d5b5c87)|RTF|CVE-2017-11882|2018-07-05 05:58:16|Car%20Sticker.rtf|
|[aa3e090597357ccbc49db04d521bde12](https://www.virustotal.com/gui/file/aa3e090597357ccbc49db04d521bde12)|RTF|CVE-2017-11882|2018-05-08 07:01:29|MV_Sticker.rtf|
|[9e3aed500f8b9e4a1021c74476e9d778](https://www.virustotal.com/gui/file/9e3aed500f8b9e4a1021c74476e9d778)|Win32 EXE||2018-03-05 05:53:27|Emergency-Contact-Numbers.pdf.exe|
|[851985058cbbc3ff93ff71a2edc4104a](https://www.virustotal.com/gui/file/851985058cbbc3ff93ff71a2edc4104a)|Win32 EXE|razy|2018-02-09 12:36:20|205a3085d06cbf66d30cc5a2614390027fe75ee2|
|[ab88bef8a85aae29dbd6efc3137f227f](https://www.virustotal.com/gui/file/ab88bef8a85aae29dbd6efc3137f227f)|DOCM|w2km|2018-01-08 22:07:55|learnObot.docm|
|[c671362015dab11c0b552d8b4112825a](https://www.virustotal.com/gui/file/c671362015dab11c0b552d8b4112825a)|Win32 EXE||2017-07-20 12:36:46|Karachi%20GOlf%20Club%20Newsletter%20june%202017.pdf.exe|
|[98cc17985510ee4c259447b7c4a2a684](https://www.virustotal.com/gui/file/98cc17985510ee4c259447b7c4a2a684)|Win32 EXE|Strictor|2017-05-12 06:51:13|loc.exe|
