**NAME:**  
GroupA21
 

**Description**:   
GroupA21, named by ThreatBook, is a new APT organization that has been active since at least 2017, mainly targeting countries in South Asia to carry out cyber espionage activities. The organization’s attack tactics are somewhat similar to the SideWinder and Bitter APT groups with Indian backgrounds

  
**References**:  
https://x.threatbook.cn/nodev4/vb4/article?threatInfoID=2398