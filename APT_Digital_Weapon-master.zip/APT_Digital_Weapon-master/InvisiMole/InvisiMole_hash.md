|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[851a4f13928a5edb3859a21a8041908e](https://www.virustotal.com/gui/file/851a4f13928a5edb3859a21a8041908e)|Win32 DLL||2019-11-06 05:56:54|851a4f13928a5edb3859a21a8041908e.virus|
|[0a663f781913a8ca81359ba77b00086f](https://www.virustotal.com/gui/file/0a663f781913a8ca81359ba77b00086f)|Win64 DLL||2019-09-15 20:26:01|NlsModels0022|
|[a4f67ff7548284ec5c1f8aedcdee8a5d](https://www.virustotal.com/gui/file/a4f67ff7548284ec5c1f8aedcdee8a5d)|Win64 DLL||2019-09-15 20:25:44|NlsModels0019|
|[fa2edd8a24266f9ecccea44b4b47100f](https://www.virustotal.com/gui/file/fa2edd8a24266f9ecccea44b4b47100f)|Win64 EXE|Razy|2019-09-15 20:20:23|AlcRmv|
|[9ab9a66c6157875f12aa282b290336c2](https://www.virustotal.com/gui/file/9ab9a66c6157875f12aa282b290336c2)|Win64 DLL|Zapchast|2019-09-14 00:25:38|./KISA_dataset_2020_train/a16b3f8aa869aebb61ae770f9701d918c4a814a4502f46a93e904d38084d23b2.vir|
