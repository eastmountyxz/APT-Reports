**NAME:**  
InvisiMole 

**Description**:   
InvisiMole was disclosed by ESET in 2018. In June 2020, ESET discovered its attacks cooperated with Gamaredon against the military and foreign affairs departments of Eastern Europe. InvisiMole's TCP downloader was downloaded by Gamaredon's .NET downloader.

**References**:  
https://www.welivesecurity.com/2018/06/07/invisimole-equipped-spyware-undercover/