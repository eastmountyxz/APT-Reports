**NAME:**  
Tortoiseshell  
  
**Alias**  
Tortoiseshell Group, Tortoiseshell  
 
**Description**:   
Tortoiseshell, uncovered by Symantec, targets IT providers in Saudi Arabia in what appears to be supply chain attacks with the end goal of compromising the IT providers’ customers since at least July 2018.
  
**References**:  
https://www.symantec.com/blogs/threat-intelligence/tortoiseshell-apt-supply-chain