|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[dbc79b43edf56d75092b91589ad1d594](https://www.virustotal.com/gui/file/dbc79b43edf56d75092b91589ad1d594)|Win32 EXE||2019-09-25 09:05:49|HMH.exe|
|[83858d72745976b3e53d9bb4268ba283](https://www.virustotal.com/gui/file/83858d72745976b3e53d9bb4268ba283)|Win32 EXE||2019-09-25 09:05:38|HMH.exe|
|[2145e7ec1488adcd882169bf17df245b](https://www.virustotal.com/gui/file/2145e7ec1488adcd882169bf17df245b)|Win32 EXE|Ursu|2019-09-05 13:37:48|Dllhost.exe|
|[c5cdf5166d7b5c443ebc2fd0f3f884f8](https://www.virustotal.com/gui/file/c5cdf5166d7b5c443ebc2fd0f3f884f8)|Win32 EXE|razy|2019-09-05 13:37:48|Liderc.exe|
|[a194e3bf830104922295c37e6d19d9a2](https://www.virustotal.com/gui/file/a194e3bf830104922295c37e6d19d9a2)|Win32 EXE||2019-09-05 13:35:21|HMH.exe|
|[2c41680a26c5376aa14557798414d440](https://www.virustotal.com/gui/file/2c41680a26c5376aa14557798414d440)|Win32 EXE|Ursu|2019-08-31 04:46:03|Keylogger.exe|
|[1919c62cf0e26402e5aa44fe1399e7fd](https://www.virustotal.com/gui/file/1919c62cf0e26402e5aa44fe1399e7fd)|Win32 EXE||2019-06-25 17:24:46|nazer.exe|
|[87ef4162c257b6aebd8323f3f877daae](https://www.virustotal.com/gui/file/87ef4162c257b6aebd8323f3f877daae)|Win32 EXE||2019-06-25 12:16:10|shining.exe|
|[9dd7c75b1c175ac99868969449f77d3e](https://www.virustotal.com/gui/file/9dd7c75b1c175ac99868969449f77d3e)|Win32 EXE||2019-04-17 16:33:22|mscorsvw.exe|
|[4b91c32383d837c4e1b685cd80801887](https://www.virustotal.com/gui/file/4b91c32383d837c4e1b685cd80801887)|Win32 EXE||2019-01-14 00:48:42|PremiumPack.exe|
|[e4e77302e17ddcfbadf8517909d49664](https://www.virustotal.com/gui/file/e4e77302e17ddcfbadf8517909d49664)|Win32 EXE||2019-01-14 00:14:25|Golder.exe|
|[ab49024f1fd6597b47ecddbfee6d1f43](https://www.virustotal.com/gui/file/ab49024f1fd6597b47ecddbfee6d1f43)|Win32 EXE||2019-01-14 00:07:36|Golder.exe|
|[1c7d8a88c3244e094124bb3a148f32bb](https://www.virustotal.com/gui/file/1c7d8a88c3244e094124bb3a148f32bb)|Win32 EXE||2019-01-13 23:20:30|Golder.exe|
|[b0eeaa1bd7b5dbd4e712a38a0a9b497c](https://www.virustotal.com/gui/file/b0eeaa1bd7b5dbd4e712a38a0a9b497c)|Win32 EXE|Ursu|2019-01-13 22:49:53|mscorsvw.exe|
|[d2870d1d08020ed9633e91f91931953b](https://www.virustotal.com/gui/file/d2870d1d08020ed9633e91f91931953b)|Win32 EXE|razy|2018-08-20 16:06:54|BAK.exe|
|[d02e828d2451400c93cf17e9d1d495e4](https://www.virustotal.com/gui/file/d02e828d2451400c93cf17e9d1d495e4)|Win32 EXE||2018-08-20 14:36:14|mscorsvw.exe|
|[11be0f1dfa9dd7073593f2da7aa4297e](https://www.virustotal.com/gui/file/11be0f1dfa9dd7073593f2da7aa4297e)|Win32 EXE|razy|2018-06-02 16:56:53|BAK.exe|
