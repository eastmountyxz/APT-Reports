**NAME:**  
WindShift  

**Description**:   
WindShift targeted specific individuals working in government department and critical infrastructure across the Middle East. Weaknesses of Apple Mac products were exploited to attack victims in that region.
  
**References**:  
https://www.forbes.com/sites/thomasbrewster/2018/08/30/apple-mac-loophole-breached-in-middle-east-hacks/#55d4ac96fd65  
https://gsec.hitb.org/materials/sg2018/D1%20COMMSEC%20-%20In%20the%20Trails%20of%20WINDSHIFT%20APT%20-%20Taha%20Karim.pdf
