|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5f7e94912a1134aa7b2ffc83d4fb45b8](https://www.virustotal.com/gui/file/5f7e94912a1134aa7b2ffc83d4fb45b8)|Mach-O executable||2017-06-22 10:10:24|usrnode|
|[6aa546f5a0831cf49ec6509c5002a1c6](https://www.virustotal.com/gui/file/6aa546f5a0831cf49ec6509c5002a1c6)|ZIP||2017-06-22 09:51:47|NPC_Agenda_230617.zip|
|[b21c7068efbd36c665773f8f68de269f](https://www.virustotal.com/gui/file/b21c7068efbd36c665773f8f68de269f)|Mach-O executable||2017-05-27 15:07:27|3085c2ad23f35a2ac0a3a87631991eeb9497dbe68d19c8dd2869578a33ecba0d.bin|
|[ff044de5e7a58d5125ba822ca379db2d](https://www.virustotal.com/gui/file/ff044de5e7a58d5125ba822ca379db2d)|ZIP||2017-05-27 15:07:25|Scandal_Report_2017.zip|
|[c211dff0d9ecff416a1bf5a588ec2d5d](https://www.virustotal.com/gui/file/c211dff0d9ecff416a1bf5a588ec2d5d)|Mach-O executable||2017-03-29 20:50:10|usrnode|
|[36284fdcd2c9cf53973adcae9d5144d1](https://www.virustotal.com/gui/file/36284fdcd2c9cf53973adcae9d5144d1)|ZIP||2017-03-29 20:47:58|36284fdcd2c9cf53973adcae9d5144d1.virus|
|[c68a856ec8f4529147ce9fd3a77d7865](https://www.virustotal.com/gui/file/c68a856ec8f4529147ce9fd3a77d7865)|Mach-O executable||2017-03-29 20:46:14|/Users/user1/Library/Final_Presentation.app/Contents/MacOS/usrnode|
|[190fde5eca774936d78e37f73b2ff1fa](https://www.virustotal.com/gui/file/190fde5eca774936d78e37f73b2ff1fa)|ZIP||2017-03-29 20:44:04|Final_Presentation.zip|
|[abee498c414d2b760f5973cf74ef1155](https://www.virustotal.com/gui/file/abee498c414d2b760f5973cf74ef1155)|ZIP||2014-01-21 17:39:44|OSX_Update.zip|
