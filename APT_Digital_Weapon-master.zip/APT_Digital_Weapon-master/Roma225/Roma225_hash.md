|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[df632e25c32e8f8ad75ed3c50dd1cd47](https://www.virustotal.com/gui/file/df632e25c32e8f8ad75ed3c50dd1cd47)|Win32 EXE||2018-12-20 17:17:17|ScreenBooking4.exe|
|[a089efd7dd9180f9b726594bb6cf81ae](https://www.virustotal.com/gui/file/a089efd7dd9180f9b726594bb6cf81ae)|Win32 EXE||2018-12-18 07:20:52|/home/matheus/Documents/projetos/nsc_getmlwr/samples/20181218T094344/e8a765ec824881e1e78defd7c011da735f3e3b954aaf93a4282b6455a1b9afcc|
|[cdb34c32c48c0f2dd387dbf277b4b8ce](https://www.virustotal.com/gui/file/cdb34c32c48c0f2dd387dbf277b4b8ce)|PPT||2018-12-14 14:14:49|4211e091dfb33523d675d273bdc109ddecf4ee1c1f5f29e8c82b9d0344dbb6a1.bin|
