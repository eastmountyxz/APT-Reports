**NAME:**  
Roma225  
  
**Description**:   
The enigmatic Roma225 campaign utilizes espionage malware implant weaponized to target companies in the Italian automotive sector. The malware was spread through well written phishing email trying to impersonate a senior partner of one of the major Brazilian business law firms.
  
**References**:  
https://blog.yoroi.company/research/the-enigmatic-roma225-campaign/

