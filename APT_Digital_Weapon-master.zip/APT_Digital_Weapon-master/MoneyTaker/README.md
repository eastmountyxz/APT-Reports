**NAME:**  
MoneyTaker  

**Description**:   
MoneyTaker is an attack group uncovered by Group-IB. This group, primarily been targeting card processing systems, including the AWS CBR and SWIFT, has conducted over 20 successful attacks on financial institutions and legal firms in the USA, UK and Russia. In addition to banks, the MoneyTaker group has attacked law firms and also financial software vendors.
  
**References**:  
https://www.bleepingcomputer.com/news/security/moneytaker-hacker-group-steals-millions-from-us-and-russian-banks/  
https://www.group-ib.com/resources/reports/money-taker.html  
https://www.group-ib.com/blog/moneytaker  