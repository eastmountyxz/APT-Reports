|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5103b12ebf2ca605a97fa43c3b5f8a5c](https://www.virustotal.com/gui/file/5103b12ebf2ca605a97fa43c3b5f8a5c)|Win64 EXE||2017-08-30 12:03:48|C:\Users\Valilon\Downloads\Telegram Desktop\lpe\lpe\cve.exe|
|[7d56c9886ac2ba8c2532c4bed687563c](https://www.virustotal.com/gui/file/7d56c9886ac2ba8c2532c4bed687563c)|Win32 EXE|injector|2017-02-06 16:36:35|184-315240.exe|
|[a7093b39f2eec51d72821cb4634c6128](https://www.virustotal.com/gui/file/a7093b39f2eec51d72821cb4634c6128)|Win64 EXE|dynamer|2017-01-11 16:47:35|a7093b39f2eec51d72821cb4634c6128_windows-kernel-exploits_MS16-135_41015.exe|
|[8b1b5d1c8430ec16735e5ded94112b18](https://www.virustotal.com/gui/file/8b1b5d1c8430ec16735e5ded94112b18)|Win64 EXE||2016-11-29 14:38:31|C:\Users\iav_lab\Downloads\1\test64.exe|
|[09a7f9813f6de28f2d7bcba032390662](https://www.virustotal.com/gui/file/09a7f9813f6de28f2d7bcba032390662)|Win32 EXE||2016-11-29 01:33:53|test32.exe|
|[892bd36a8b253b92c7140fee7ebf5003](https://www.virustotal.com/gui/file/892bd36a8b253b92c7140fee7ebf5003)|Win64 EXE||2016-11-24 00:16:31|892bd36a8b253b92c7140fee7ebf5003_ASLRSideChannelAttack.exe|
|[70d8729ca630dd3b0f9a62998642ec76](https://www.virustotal.com/gui/file/70d8729ca630dd3b0f9a62998642ec76)|Win32 EXE||2016-11-17 15:20:11|test_21211|
|[6fcc13563aad936c7d0f3165351cb453](https://www.virustotal.com/gui/file/6fcc13563aad936c7d0f3165351cb453)|Win32 EXE||2016-11-11 03:13:33|093c81f|
|[f2dd31298e7d29441e825b3862b9ad0b](https://www.virustotal.com/gui/file/f2dd31298e7d29441e825b3862b9ad0b)|Win32 EXE||2016-11-10 21:08:04| |
|[38920633d7c41c6dea875114e205748d](https://www.virustotal.com/gui/file/38920633d7c41c6dea875114e205748d)|Text||2016-10-27 20:27:24|winstart.jpg|
|[369ad5f7bc9a555f3395059978c720bb](https://www.virustotal.com/gui/file/369ad5f7bc9a555f3395059978c720bb)|Win32 EXE|Zbot|2016-09-26 08:55:18|Ex_List|
|[b9464a8af8274d6188ae5035aced49b2](https://www.virustotal.com/gui/file/b9464a8af8274d6188ae5035aced49b2)|DOS EXE|Zbot|2012-10-26 04:34:23|cbcs.exe|
