**NAME:**  
Snake Wine  
  
**Alias**  
ChChes, Snake Wine  
  
**Description**:   
Snake Wine group, named by Cylance, has proven to be highly adaptable and has continued to adopt new tactics in order to establish footholds inside victim environments. The group starts to build and utilize their existing current attack infrastructure and has special interests in Japanese government, education, and commerce.
  
**References**:  
https://www.cylance.com/en_us/blog/the-deception-project-a-new-japanese-centric-threat.html

