|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[7823375b1a90865b8c5729ff65d76822](https://www.virustotal.com/gui/file/7823375b1a90865b8c5729ff65d76822)|Win64 DLL||2019-09-10 14:31:43|oci.dll|
|[a3d0334721f3f0ec5cccecb6a18b416b](https://www.virustotal.com/gui/file/a3d0334721f3f0ec5cccecb6a18b416b)|Win32 DLL||2019-09-10 12:03:46|gSOAP_license|
|[d864d3bf4371dc43bdb5b8c7e24ebd4b](https://www.virustotal.com/gui/file/d864d3bf4371dc43bdb5b8c7e24ebd4b)|Win32 EXE||2019-09-05 00:36:04|app|
|[7c9abfbe13eaea24879d57394b84d7d9](https://www.virustotal.com/gui/file/7c9abfbe13eaea24879d57394b84d7d9)|Win32 DLL|TSCookie|2019-08-27 10:19:28|WINMM.dll|
|[d30e6f1876351292b0b21ef3603367cd](https://www.virustotal.com/gui/file/d30e6f1876351292b0b21ef3603367cd)|Win32 DLL||2019-08-02 11:33:00|ucrtlib.dll|
|[1a7fa25d84026513e3fb35af26bad443](https://www.virustotal.com/gui/file/1a7fa25d84026513e3fb35af26bad443)|Win32 DLL||2019-06-25 19:53:17|ADvantage sqlite|
|[c0e18e364d8b3b01d9217180ee002769](https://www.virustotal.com/gui/file/c0e18e364d8b3b01d9217180ee002769)|unknown||2019-06-25 13:35:45|UsrClass.dat|
|[03909af5cf762d31545f622f4f12dc5a](https://www.virustotal.com/gui/file/03909af5cf762d31545f622f4f12dc5a)|Win32 EXE||2019-05-20 05:17:56|Asus Webstorage Upate.exe|
|[b6da67211f6f9cf62f6cac5d52edd4a4](https://www.virustotal.com/gui/file/b6da67211f6f9cf62f6cac5d52edd4a4)|PNG||2019-05-16 14:51:31|fav.ico|
|[c78beff838f4c57be9044996c25eca7d](https://www.virustotal.com/gui/file/c78beff838f4c57be9044996c25eca7d)|Win32 EXE|TSCookie|2019-05-15 06:45:14| |
|[862a28038951e1f4a7ffd77d3b47458d](https://www.virustotal.com/gui/file/862a28038951e1f4a7ffd77d3b47458d)|Win32 DLL|TSCookie|2019-05-14 01:04:35|ComDlgInDll|
|[19153e7d43f1f5e3b937e91b5ccc601d](https://www.virustotal.com/gui/file/19153e7d43f1f5e3b937e91b5ccc601d)|Win32 EXE|TSCookie|2019-05-14 00:45:03|driver.exe|
|[7e6a7e83bf84d081f4fd8a2c0cb1e32f](https://www.virustotal.com/gui/file/7e6a7e83bf84d081f4fd8a2c0cb1e32f)|Win32 EXE||2019-05-10 09:50:02|ASUSWebStorageSyncAgent2.3.0.595.exe.bin|
|[caa9dfd4e618febac24fbe35c770eab3](https://www.virustotal.com/gui/file/caa9dfd4e618febac24fbe35c770eab3)|Win32 EXE|TSCookie|2019-05-07 08:35:13|ASUSWebStorageSyncAgent2.4.3.612.exe|
|[29d3dc7cb55365bb84b1a34c18918fc0](https://www.virustotal.com/gui/file/29d3dc7cb55365bb84b1a34c18918fc0)|unknown||2019-04-09 07:35:35|Language.dat|
|[66f79700fe4209e26cbb33a76c705492](https://www.virustotal.com/gui/file/66f79700fe4209e26cbb33a76c705492)|Win32 EXE|TSCookie|2018-12-12 00:49:44| |
|[b56929ebde84c5e258e6e7820c4de19b](https://www.virustotal.com/gui/file/b56929ebde84c5e258e6e7820c4de19b)|Win32 EXE|TSCookie|2018-12-11 00:01:17| |
|[520f7ad06eaef69babdb048cb5aa67a1](https://www.virustotal.com/gui/file/520f7ad06eaef69babdb048cb5aa67a1)|Win32 EXE||2018-11-15 07:21:22|iTunesHelper.exe|
|[73e3b72ddd2ea71518d4108865d8c82c](https://www.virustotal.com/gui/file/73e3b72ddd2ea71518d4108865d8c82c)|Win32 EXE|Symmi|2018-11-14 08:36:30|audio.exe|
|[c2050ec8b38eb02d2dc3cd67b6a7bc73](https://www.virustotal.com/gui/file/c2050ec8b38eb02d2dc3cd67b6a7bc73)|Win32 EXE||2018-09-18 05:04:36|winlogon|
|[886cedd85d6d4f65233cd1ae844d41e7](https://www.virustotal.com/gui/file/886cedd85d6d4f65233cd1ae844d41e7)|Win32 EXE|injector|2018-09-13 18:07:57|體驗台灣－浪漫情侶之旅－聽濤篇１_Listening to the sea‮cod.exe|
|[34e38d4b970be9f19b6f29c83023b498](https://www.virustotal.com/gui/file/34e38d4b970be9f19b6f29c83023b498)|Win32 EXE||2018-07-28 01:47:01|34e38d4b970be9f19b6f29c83023b498.vir|
|[f80c1d0023009c8d0e6c719787369c88](https://www.virustotal.com/gui/file/f80c1d0023009c8d0e6c719787369c88)|Win32 EXE|TSCookie|2018-07-19 07:05:08|f80c1d0023009c8d0e6c719787369c88.vir|
|[eec1281ce79f811a0000325a9131f40f](https://www.virustotal.com/gui/file/eec1281ce79f811a0000325a9131f40f)|Win32 EXE||2018-07-11 09:31:18| |
|[07f81dd3bd6ba8a390aaeccad86d931b](https://www.virustotal.com/gui/file/07f81dd3bd6ba8a390aaeccad86d931b)|Win32 EXE|TSCookie|2018-06-21 20:31:53| |
|[e67ec6d1aee7ff6286a445dc20900de5](https://www.virustotal.com/gui/file/e67ec6d1aee7ff6286a445dc20900de5)|Win32 EXE|TSCookie|2018-06-19 01:48:01| |
|[d2eef6b303f8523ac17476b596e50b9f](https://www.virustotal.com/gui/file/d2eef6b303f8523ac17476b596e50b9f)|Win32 EXE|TSCookie|2018-06-18 07:31:10| |
|[78d84dcac923ec0fd4b0f522f9139a79](https://www.virustotal.com/gui/file/78d84dcac923ec0fd4b0f522f9139a79)|Win32 EXE||2018-05-11 21:14:21|PIconStartup.exe|
|[cd1c40dce4a2440e45c5dce33f33f74e](https://www.virustotal.com/gui/file/cd1c40dce4a2440e45c5dce33f33f74e)|Win32 EXE||2018-04-14 12:37:34|PIconStartup.exe|
|[761ef01cacf2dadc39894bbf2b1497e0](https://www.virustotal.com/gui/file/761ef01cacf2dadc39894bbf2b1497e0)|Win32 EXE|TSCookie|2018-03-21 11:28:15|wmpnetwk.exe|
|[870afc08ab61bae14737863be9da89f9](https://www.virustotal.com/gui/file/870afc08ab61bae14737863be9da89f9)|Win32 EXE|TSCookie|2018-02-08 23:34:53|hspfgdsgsag|
|[0fbac0f3ed71cc41c427f69a8a306296](https://www.virustotal.com/gui/file/0fbac0f3ed71cc41c427f69a8a306296)|Win32 EXE|TSCookie|2018-02-07 04:59:22|JUNIPERNETWORKS.EXE|
|[90e421fda3f5245738e78963d78294df](https://www.virustotal.com/gui/file/90e421fda3f5245738e78963d78294df)|Win32 EXE|Symmi|2018-01-28 04:34:39|DRIVER.EXE-|
|[8a99dd73d756a7a82de5cf1f86394a8c](https://www.virustotal.com/gui/file/8a99dd73d756a7a82de5cf1f86394a8c)|Win32 DLL|TSCookie|2018-01-23 01:13:54|8a99dd73d756a7a82de5cf1f86394a8c.virus|
|[66a48063fefd7388017549045ce61dff](https://www.virustotal.com/gui/file/66a48063fefd7388017549045ce61dff)|Win32 EXE||2018-01-18 06:13:04|66a48063fefd7388017549045ce61dff.virus|
|[bbc5d571955bd8fc9f17bb85db44069a](https://www.virustotal.com/gui/file/bbc5d571955bd8fc9f17bb85db44069a)|Win32 EXE|TSCookie|2018-01-02 10:36:24|myfile.exe|
|[c6cd766b34472a34bc53093acf161540](https://www.virustotal.com/gui/file/c6cd766b34472a34bc53093acf161540)|Win32 EXE|TSCookie|2017-12-21 11:55:17|c6cd766b34472a34bc53093acf161540.virus|
|[0bc0eb5f107d020d7b600e61c77bfb04](https://www.virustotal.com/gui/file/0bc0eb5f107d020d7b600e61c77bfb04)|Win32 EXE|TSCookie|2017-12-21 11:55:02|burnin.exe|
|[37bf2df225650b39c9874ecf392a9a9b](https://www.virustotal.com/gui/file/37bf2df225650b39c9874ecf392a9a9b)|Win32 EXE|Symmi|2017-12-20 07:27:41|surface.exe|
|[76b464c98790d8f01e02d24b53f4486d](https://www.virustotal.com/gui/file/76b464c98790d8f01e02d24b53f4486d)|Win32 EXE|Symmi|2017-12-19 15:03:34|surface.exe|
|[47a0e644aae76b040aaecf7f7b75404b](https://www.virustotal.com/gui/file/47a0e644aae76b040aaecf7f7b75404b)|Win32 EXE|Symmi|2017-12-19 12:57:12|surface.exe|
|[299d0c5f43e59fc9415d70816aee56c6](https://www.virustotal.com/gui/file/299d0c5f43e59fc9415d70816aee56c6)|RTF|Symmi|2017-12-19 01:25:17|（更正以此為准）書面資料-院長指示事項辦理情形表.rtf|
|[c22937cee87b45ba18c16318533648fb](https://www.virustotal.com/gui/file/c22937cee87b45ba18c16318533648fb)|RTF|Symmi|2017-12-14 00:51:46|25a473ec43acfe80182d3fd6cd9cf87ac362a18b78a554bf1dda8d9dc05bee08 (1)|
|[1e0905f399e8c935eb08806037187f4b](https://www.virustotal.com/gui/file/1e0905f399e8c935eb08806037187f4b)|Win32 EXE||2017-10-23 02:43:08|1e0905f399e8c935eb08806037187f4b.virus|
|[a66689bbbe0917d79bd0668bd54ad53f](https://www.virustotal.com/gui/file/a66689bbbe0917d79bd0668bd54ad53f)|Win32 EXE|TSCookie|2017-09-20 01:16:18|C:/Users/seongmin/Documents/VT2/malware/20170927/a66689bbbe0917d79bd0668bd54ad53f.vir|
|[3470568793761e75d72eb0c99a4bb6ec](https://www.virustotal.com/gui/file/3470568793761e75d72eb0c99a4bb6ec)|Win32 EXE||2017-09-14 05:28:18|C:/Users/seongmin/Documents/VT2/malware/20170920/3470568793761e75d72eb0c99a4bb6ec.vir|
|[55cf79bfd02b0cf36a524e7b813b686b](https://www.virustotal.com/gui/file/55cf79bfd02b0cf36a524e7b813b686b)|Win32 EXE|graftor|2017-09-06 12:02:55|55cf79bfd02b0cf36a524e7b813b686b.virus|
|[5fc4a20161b6d95d5bd0c0567472c4b0](https://www.virustotal.com/gui/file/5fc4a20161b6d95d5bd0c0567472c4b0)|Win32 EXE||2017-09-06 06:31:28|Bluthmon.exe|
|[c56f890e9a3e4d9ffd2aba80d95b2f89](https://www.virustotal.com/gui/file/c56f890e9a3e4d9ffd2aba80d95b2f89)|Win32 EXE||2017-09-06 01:14:55|auditpoll.exe|
|[64841350aca9f0c347c29a46c839e7db](https://www.virustotal.com/gui/file/64841350aca9f0c347c29a46c839e7db)|Win32 EXE|barys|2017-09-04 01:19:56|power.exe|
|[40baab1fdb4f4221b33b7200dbb8e491](https://www.virustotal.com/gui/file/40baab1fdb4f4221b33b7200dbb8e491)|Win64 DLL||2017-07-06 19:11:20|40baab1fdb4f4221b33b7200dbb8e491.virus|
|[ca3ae36b2f48e49e317731db93988fcc](https://www.virustotal.com/gui/file/ca3ae36b2f48e49e317731db93988fcc)|Win32 DLL|Zbot|2017-07-06 19:02:28|ca3ae36b2f48e49e317731db93988fcc.virus|
|[814788af2d9cb539206365984af329a3](https://www.virustotal.com/gui/file/814788af2d9cb539206365984af329a3)|Win64 EXE|Kivars|2017-07-06 18:32:06|814788af2d9cb539206365984af329a3.virus|
|[70b31b12a5ba644de0093970af9866b8](https://www.virustotal.com/gui/file/70b31b12a5ba644de0093970af9866b8)|Win32 EXE|TSCookie|2017-07-06 17:11:21|70b31b12a5ba644de0093970af9866b8.virus|
|[18c409071622553a1d66e0a02d261f7f](https://www.virustotal.com/gui/file/18c409071622553a1d66e0a02d261f7f)|Win32 EXE||2017-04-27 08:41:34|~TEMP2853.EXE|
|[ac7a5d7d094beeb0022ebd4123fe7814](https://www.virustotal.com/gui/file/ac7a5d7d094beeb0022ebd4123fe7814)|Win32 EXE||2017-04-25 02:54:10|powermanager.exe|
|[b3dfe482568c508bc21f8da8a291f2cd](https://www.virustotal.com/gui/file/b3dfe482568c508bc21f8da8a291f2cd)|Win32 EXE|TSCookie|2017-04-21 07:12:08|msgrinst.exe|
|[1d6d1b6cd719f0346760b5be8fe4e236](https://www.virustotal.com/gui/file/1d6d1b6cd719f0346760b5be8fe4e236)|Win32 EXE|TSCookie|2017-04-12 11:43:42|1d6d1b6cd719f0346760b5be8fe4e236.virus|
|[cb27838f3c48af8702877d4ca36cca31](https://www.virustotal.com/gui/file/cb27838f3c48af8702877d4ca36cca31)|Win32 EXE|TSCookie|2017-04-11 12:46:13|temp.exe_NG|
|[296dcc2bd1f6359466ff068c8001bbec](https://www.virustotal.com/gui/file/296dcc2bd1f6359466ff068c8001bbec)|Win32 EXE|Zbot|2017-04-02 22:01:33|Bluthmon.exe|
|[a2bfef210952aa4177ec03000b231228](https://www.virustotal.com/gui/file/a2bfef210952aa4177ec03000b231228)|Win32 EXE|Zbot|2017-03-29 22:27:25|a2bfef210952aa4177ec03000b231228.virus|
|[49f63cfca889f754b16c354a3ab0c8f5](https://www.virustotal.com/gui/file/49f63cfca889f754b16c354a3ab0c8f5)|Win32 EXE||2017-03-29 07:53:27|surface.exe|
|[6b120a47b2a198d45bae677dc6b4078e](https://www.virustotal.com/gui/file/6b120a47b2a198d45bae677dc6b4078e)|Win32 EXE|graftor|2017-03-23 03:21:41|6b120a47b2a198d45bae677dc6b4078e.virus|
|[263fcd049ac2bfff425846e6c2cd6818](https://www.virustotal.com/gui/file/263fcd049ac2bfff425846e6c2cd6818)|Win32 EXE||2017-03-23 02:52:13|263fcd049ac2bfff425846e6c2cd6818.virus|
|[ca7fb87835e1a053643187e46716a495](https://www.virustotal.com/gui/file/ca7fb87835e1a053643187e46716a495)|Win32 EXE|dynamer|2017-03-20 07:49:34|crypto.exe|
|[07cb79937b35c2ed92cd671a59bc0d37](https://www.virustotal.com/gui/file/07cb79937b35c2ed92cd671a59bc0d37)|Win32 DLL|Zbot|2017-03-20 05:41:09|dmserver|
|[4394686ea01639c9a516929d0662bb70](https://www.virustotal.com/gui/file/4394686ea01639c9a516929d0662bb70)|Win32 EXE|Androm|2017-03-16 09:50:22|4394686ea01639c9a516929d0662bb70.virus|
|[7163a7326321ce88f14c2156c29f8386](https://www.virustotal.com/gui/file/7163a7326321ce88f14c2156c29f8386)|Win32 EXE||2017-03-10 22:06:50|7163a7326321ce88f14c2156c29f8386.virus|
|[edd052b476be6aab5b3e9a83461ab51b](https://www.virustotal.com/gui/file/edd052b476be6aab5b3e9a83461ab51b)|Win32 EXE|strictor|2017-03-08 05:28:11|algs.exe|
|[e8b4a73a2f661df4b1970af81028cb03](https://www.virustotal.com/gui/file/e8b4a73a2f661df4b1970af81028cb03)|Win32 EXE|graftor|2017-02-20 07:42:29|e8b4a73a2f661df4b1970af81028cb03.virus|
|[7745f7a89aa20da8d681fee4f25741df](https://www.virustotal.com/gui/file/7745f7a89aa20da8d681fee4f25741df)|Win32 EXE|Kryptik|2017-02-09 07:35:03|inetinfo.exe|
|[d39b01a44f1487c4bb3c68a528438144](https://www.virustotal.com/gui/file/d39b01a44f1487c4bb3c68a528438144)|Win32 EXE|Zbot|2017-02-09 07:28:28|Bluthmon.exe|
|[6d28c30cd57855ebd1e4b2c3fbaad749](https://www.virustotal.com/gui/file/6d28c30cd57855ebd1e4b2c3fbaad749)|ELF executable|Bifrose|2017-02-09 06:23:18|client_38.bin|
|[9c1f66b9db71396f4e746c8dcdbad17e](https://www.virustotal.com/gui/file/9c1f66b9db71396f4e746c8dcdbad17e)|Win32 EXE|TSCookie|2017-02-07 05:59:43|9c1f66b9db71396f4e746c8dcdbad17e.virus|
|[80954b330883569635f83f396f551093](https://www.virustotal.com/gui/file/80954b330883569635f83f396f551093)|Win32 EXE||2017-01-30 11:44:59|1.exe|
|[3d356c2d84c39bab9fcb1fea1a132f6a](https://www.virustotal.com/gui/file/3d356c2d84c39bab9fcb1fea1a132f6a)|Win32 EXE|dynamer|2017-01-29 21:40:57|3d356c2d84c39bab9fcb1fea1a132f6a.virus|
|[32549e52c76cacf4a4725340c5eaaabd](https://www.virustotal.com/gui/file/32549e52c76cacf4a4725340c5eaaabd)|Win32 EXE|Zbot|2017-01-22 09:21:29|Bluthmon.exe|
|[f99fa1c64e4e7b17cb45c7727e38bfa1](https://www.virustotal.com/gui/file/f99fa1c64e4e7b17cb45c7727e38bfa1)|Win32 EXE|strictor|2017-01-20 13:48:27|f99fa1c64e4e7b17cb45c7727e38bfa1.virus|
|[59c37da9478b54cc3ae52d19546e7731](https://www.virustotal.com/gui/file/59c37da9478b54cc3ae52d19546e7731)|Win32 EXE||2017-01-04 08:50:33|c:\windows\adobe32.exe|
|[e0d4b60dcdf8d0dfd118b43cbca91a0a](https://www.virustotal.com/gui/file/e0d4b60dcdf8d0dfd118b43cbca91a0a)|Win32 EXE|Symmi|2016-12-22 02:33:06|C:\Users\AVC\Desktop\x\4842c5403372ead4fd28a26f2e1dfc139541e71bcf574e62c7c18b9cfc406674.exe|
|[d86df4f012398a9ea8742e62685415a1](https://www.virustotal.com/gui/file/d86df4f012398a9ea8742e62685415a1)|Win32 EXE|barys|2016-12-09 16:39:30|d86df4f012398a9ea8742e62685415a1.virus|
|[0db2c1195c97fc909b6fdb4b09227457](https://www.virustotal.com/gui/file/0db2c1195c97fc909b6fdb4b09227457)|Win32 EXE|Zbot|2016-12-04 01:30:49|Bluthmon.exe|
|[dc60b65a6082e800ac555d39aca18c1b](https://www.virustotal.com/gui/file/dc60b65a6082e800ac555d39aca18c1b)|Win32 EXE|dynamer|2016-12-02 06:15:30|1051130工業局局長接見黃肇嘉總經理談話資料‮xcod.scr|
|[b050f044f26ed93ae573633934fd2135](https://www.virustotal.com/gui/file/b050f044f26ed93ae573633934fd2135)|Win32 EXE|graftor|2016-11-24 01:18:52|掃描軟體 Retina相關更新資訊PRE‮XCOD.SCR|
|[ec7c6b43beec56df72cb74dd28b5b1d2](https://www.virustotal.com/gui/file/ec7c6b43beec56df72cb74dd28b5b1d2)|Win32 EXE|dynamer|2016-11-23 04:45:40|ec7c6b43beec56df72cb74dd28b5b1d2.virus|
|[8cada1784cde740b6ed40f27f9116bbe](https://www.virustotal.com/gui/file/8cada1784cde740b6ed40f27f9116bbe)|Win32 EXE|TSCookie|2016-11-17 15:57:42|E5436200014_VoLTESR & VoLTESW相關問題1117.DOCX.SCR|
|[7f84dea46b4e29911604a2afaf1c57ab](https://www.virustotal.com/gui/file/7f84dea46b4e29911604a2afaf1c57ab)|Win32 EXE|dynamer|2016-11-07 22:04:03| |
|[c64778a2ddcc66db666e63ca6781ef3f](https://www.virustotal.com/gui/file/c64778a2ddcc66db666e63ca6781ef3f)|Win32 EXE||2016-11-07 22:02:40|c64778a2ddcc66db666e63ca6781ef3f.virus|
|[57c0114780d2860a3adbae095c72a97d](https://www.virustotal.com/gui/file/57c0114780d2860a3adbae095c72a97d)|Win32 EXE||2016-11-07 08:38:21|57C0114780D2860A3ADBAE095C72A97D.EXE|
|[49243b0142ef1a604dad88a6ad98ec0a](https://www.virustotal.com/gui/file/49243b0142ef1a604dad88a6ad98ec0a)|Win32 EXE||2016-10-28 17:31:46|49243b0142ef1a604dad88a6ad98ec0a.virus|
|[41835606c2776880e7f540187cf2925f](https://www.virustotal.com/gui/file/41835606c2776880e7f540187cf2925f)|Win32 EXE|TSCookie|2016-10-20 03:24:06|drivers.exe|
|[c74a645b0a52812f026f5cfe6d168f40](https://www.virustotal.com/gui/file/c74a645b0a52812f026f5cfe6d168f40)|Win32 EXE|dynamer|2016-10-13 10:31:50|hkcmd.exe|
|[0fbf6146e6478d9a6945341a45885400](https://www.virustotal.com/gui/file/0fbf6146e6478d9a6945341a45885400)|Win32 EXE||2016-10-13 10:25:30|auditpoll.exe|
|[28ded83e93dea7b119d78096a8e06161](https://www.virustotal.com/gui/file/28ded83e93dea7b119d78096a8e06161)|Win32 EXE||2016-10-12 03:08:51|28ded83e93dea7b119d78096a8e06161.virus|
|[462372c1f7f27ad12cc452dbb3358122](https://www.virustotal.com/gui/file/462372c1f7f27ad12cc452dbb3358122)|Win32 EXE|dynamer|2016-10-04 23:26:10| |
|[7f92dab9133fb818b807aefe6d09cc1c](https://www.virustotal.com/gui/file/7f92dab9133fb818b807aefe6d09cc1c)|Win32 EXE|TSCookie|2016-09-30 15:42:51|7f92dab9133fb818b807aefe6d09cc1c.virus|
|[eb67c8be4b0cbbf073e7361d314d28d3](https://www.virustotal.com/gui/file/eb67c8be4b0cbbf073e7361d314d28d3)|Win32 EXE|graftor|2016-09-09 02:47:08|eb67c8be4b0cbbf073e7361d314d28d3.virus|
|[b14f8f099e4ebbaf4312eb86d739267f](https://www.virustotal.com/gui/file/b14f8f099e4ebbaf4312eb86d739267f)|Win32 EXE|Zbot|2016-08-24 21:40:38|Bluthmon.exe|
|[468571266346f4b659b948a67e8ab005](https://www.virustotal.com/gui/file/468571266346f4b659b948a67e8ab005)|Win32 EXE||2016-08-12 08:17:55|Bluthmon.exe|
|[fc466b631a2f3938fc58e478850fb30b](https://www.virustotal.com/gui/file/fc466b631a2f3938fc58e478850fb30b)|unknown||2016-08-03 18:20:28|D:\virus\client\jsjrwxy.dat|
|[80f5b06896490cd6fd79bf0074047017](https://www.virustotal.com/gui/file/80f5b06896490cd6fd79bf0074047017)|Win32 DLL||2016-08-03 13:58:37|c:\windows\system32\vrarpcg.dll|
|[15a575f8e3b696a65914f87a1369e4a0](https://www.virustotal.com/gui/file/15a575f8e3b696a65914f87a1369e4a0)|unknown||2016-08-03 10:20:35|D:\virus\client\apjcap32.dat|
|[3b5c64fe37cf68e78e7b2d9c5b6da958](https://www.virustotal.com/gui/file/3b5c64fe37cf68e78e7b2d9c5b6da958)|unknown||2016-08-03 10:20:28|D:\virus\client\cfkctl32.rs|
|[b755ecf702dd89cbe94d8f4084951409](https://www.virustotal.com/gui/file/b755ecf702dd89cbe94d8f4084951409)|Win64 DLL||2016-08-03 10:06:42|c:\windows\system32\naturallamgrage6.dll|
|[43156f1d4797e9d895814bd63dc83f92](https://www.virustotal.com/gui/file/43156f1d4797e9d895814bd63dc83f92)|Win64 DLL||2016-08-03 10:06:19|c:\windows\system32\pdlptrac.dll|
|[e31b4634fa0b077fbb52deb7e0df7588](https://www.virustotal.com/gui/file/e31b4634fa0b077fbb52deb7e0df7588)|unknown||2016-07-29 01:57:18|slbrlisp.nls|
|[0929230644a301857bac09379257883a](https://www.virustotal.com/gui/file/0929230644a301857bac09379257883a)|Win32 EXE||2016-07-25 20:14:31| |
|[e99caf9396d5eb501a3dc414c5c59f7f](https://www.virustotal.com/gui/file/e99caf9396d5eb501a3dc414c5c59f7f)|Win32 DLL||2016-07-25 18:38:17|kABSynmProvider.dll|
|[22c82ab51cee269a760ca47c22e57f0f](https://www.virustotal.com/gui/file/22c82ab51cee269a760ca47c22e57f0f)|Win32 DLL||2016-07-25 17:50:02|wwsiitPS.dll|
|[88454daafe8a66e1861f0d52152f0969](https://www.virustotal.com/gui/file/88454daafe8a66e1861f0d52152f0969)|unknown||2016-07-25 10:36:37|wihvideo.rs|
|[774cf53a9d7ae4f8646b695d8417e2fb](https://www.virustotal.com/gui/file/774cf53a9d7ae4f8646b695d8417e2fb)|Win32 DLL|Zbot|2016-07-25 10:35:10|wgbOCAHelpermgqn3.dll|
|[630d2815175ba60da1a92a93a6d36973](https://www.virustotal.com/gui/file/630d2815175ba60da1a92a93a6d36973)|unknown||2016-07-25 09:51:36|fasMisPlugin.efi|
|[0516a97505315a53efcb9452a849f60d](https://www.virustotal.com/gui/file/0516a97505315a53efcb9452a849f60d)|unknown|Bifrose|2016-07-25 07:48:26|\\loopfs1\c$\WINDOWS\system32\cswbse.dll|
|[6c3fd725a76d134473062288934ff31c](https://www.virustotal.com/gui/file/6c3fd725a76d134473062288934ff31c)|Win32 EXE||2016-07-21 13:05:58|Bluthmon.exe|
|[15b1847e491e788a02cf1b884d0548ea](https://www.virustotal.com/gui/file/15b1847e491e788a02cf1b884d0548ea)|Win32 EXE||2016-07-20 15:23:03|\\looptpdc1\d$\virus\trust32.exe|
|[0349120bf7ab458f924e335a6ad8a2d1](https://www.virustotal.com/gui/file/0349120bf7ab458f924e335a6ad8a2d1)|Win32 EXE||2016-07-20 14:57:02|\\symantec10\c$\WINDOWS\system32\loop32.exe|
|[96be4a1c418f10c50659bab0b25b9115](https://www.virustotal.com/gui/file/96be4a1c418f10c50659bab0b25b9115)|Win32 EXE|dynamer|2016-07-12 04:09:08|PluginManager.exe|
|[93b68ae2023940bb2e8506d6131d9d27](https://www.virustotal.com/gui/file/93b68ae2023940bb2e8506d6131d9d27)|Win32 EXE|kryptik|2016-07-07 18:27:55|93b68ae2023940bb2e8506d6131d9d27.virus|
|[662edc1100e2d8863bf713ae47985245](https://www.virustotal.com/gui/file/662edc1100e2d8863bf713ae47985245)|Win32 EXE|TSCookie|2016-07-06 17:56:32|662edc1100e2d8863bf713ae47985245.virus|
|[8820d713e7052abe411cccb92c365783](https://www.virustotal.com/gui/file/8820d713e7052abe411cccb92c365783)|Win32 EXE||2016-07-04 04:50:25|Bluthmon.exe|
|[5bc08352ad0ca4b3727bd7c509515693](https://www.virustotal.com/gui/file/5bc08352ad0ca4b3727bd7c509515693)|Win32 EXE||2016-06-30 09:44:37|winsvc_exe_3168_172_x_x.22.exe|
|[dad24b8d395b714fcc2a2e775416cdf6](https://www.virustotal.com/gui/file/dad24b8d395b714fcc2a2e775416cdf6)|Win64 DLL||2016-06-29 09:02:20|omsdahastore.dll|
|[d152bfd10a93bf3db0fcacbc34555e9a](https://www.virustotal.com/gui/file/d152bfd10a93bf3db0fcacbc34555e9a)|Win32 EXE||2016-06-28 02:41:53|cftmon.exe|
|[5633009e7ce55be0213e76c74fdcf9d6](https://www.virustotal.com/gui/file/5633009e7ce55be0213e76c74fdcf9d6)|Win32 EXE||2016-06-27 08:56:16|5633009e7ce55be0213e76c74fdcf9d6.virus|
|[b2559336f0e73830a411ce6032474d6e](https://www.virustotal.com/gui/file/b2559336f0e73830a411ce6032474d6e)|Win32 EXE|dynamer|2016-06-18 11:32:40| |
|[61736d1624f6da0f50e14d9ea7b70491](https://www.virustotal.com/gui/file/61736d1624f6da0f50e14d9ea7b70491)|Win32 EXE|TSCookie|2016-06-04 22:37:11|lXwLy5yM57|
|[9a9344b749bbc80e70e79bda3be5b659](https://www.virustotal.com/gui/file/9a9344b749bbc80e70e79bda3be5b659)|Win32 EXE|TSCookie|2016-05-05 01:33:51|desktop.exe|
|[eae2ea929c754a6d65e2b216e5d32e7a](https://www.virustotal.com/gui/file/eae2ea929c754a6d65e2b216e5d32e7a)|Win32 EXE|Zbot|2016-05-01 11:58:38|Bluthmon.exe|
|[c40b172d7e99335e1724dc8ba18a42d7](https://www.virustotal.com/gui/file/c40b172d7e99335e1724dc8ba18a42d7)|Win32 EXE||2016-04-20 05:00:07|c40b172d7e99335e1724dc8ba18a42d7.virus|
|[c1e7627cd9c0ba0a3734e4d4f6f84d21](https://www.virustotal.com/gui/file/c1e7627cd9c0ba0a3734e4d4f6f84d21)|Win32 EXE||2016-04-18 16:20:06|2.exe|
|[9af63f645a9f16ef9c632a91377f8640](https://www.virustotal.com/gui/file/9af63f645a9f16ef9c632a91377f8640)|Win32 EXE|TSCookie|2016-03-29 06:24:21|virussign.com_9af63f645a9f16ef9c632a91377f8640.vir|
|[089d583667b28c2182be1b65b74c2ffb](https://www.virustotal.com/gui/file/089d583667b28c2182be1b65b74c2ffb)|Win32 EXE|graftor|2016-03-28 10:09:52|????????0328??? xcod.exe|
|[50ee06096d78ca5eff8d19de8aacf76e](https://www.virustotal.com/gui/file/50ee06096d78ca5eff8d19de8aacf76e)|ZIP|graftor|2016-03-28 10:09:17|八大智庫連絡方式0328更新檔.zip|
|[cab9d743c0868f7edfe11fa9fb99262b](https://www.virustotal.com/gui/file/cab9d743c0868f7edfe11fa9fb99262b)|Win32 EXE|blocker|2016-03-09 23:25:40| |
|[c8edfbeec6cbc5de1d81da33311e2536](https://www.virustotal.com/gui/file/c8edfbeec6cbc5de1d81da33311e2536)|Win32 EXE|Zbot|2015-12-08 09:21:29|Bluthmon.exe|
|[9e529a8fbc25cc73bafc1e9d881f320f](https://www.virustotal.com/gui/file/9e529a8fbc25cc73bafc1e9d881f320f)|Win32 EXE|TSCookie|2015-12-08 09:16:15|IMEKRIG.EXE|
|[82beb3713cb6cf4fedd007a17a230dfd](https://www.virustotal.com/gui/file/82beb3713cb6cf4fedd007a17a230dfd)|Win32 EXE|TSCookie|2015-11-27 07:20:27|受影響之設備型.scr|
|[87e4c2f3fc77de36732ddafaa06d0d48](https://www.virustotal.com/gui/file/87e4c2f3fc77de36732ddafaa06d0d48)|Win32 EXE|TSCookie|2015-11-26 05:38:30|105年海軍計劃簡報|
|[d302b17ed604bdb83e5c87976f8f8284](https://www.virustotal.com/gui/file/d302b17ed604bdb83e5c87976f8f8284)|Win32 EXE|TSCookie|2015-11-19 03:14:14|???_????revi?xcod.scr|
|[9f76aac6218bbc8e3d534c3c125397bf](https://www.virustotal.com/gui/file/9f76aac6218bbc8e3d534c3c125397bf)|Win32 EXE|TSCookie|2015-11-18 08:34:54|今周刊需求部分調整_‮xcod.scr|
|[1c29543429e48a5bf21597fae1fd28a6](https://www.virustotal.com/gui/file/1c29543429e48a5bf21597fae1fd28a6)|Win32 DLL||2015-11-17 16:28:44|1c29543429e48a5bf21597fae1fd28a6.dll|
|[c93f739173d9d864b015043f35147e4a](https://www.virustotal.com/gui/file/c93f739173d9d864b015043f35147e4a)|Win32 EXE|TSCookie|2015-11-17 14:09:06|????_?fdp.scr|
|[c1df226093bc665efaa5f4b2b5673d08](https://www.virustotal.com/gui/file/c1df226093bc665efaa5f4b2b5673d08)|Win32 EXE|TSCookie|2015-11-13 05:17:35|詢答系統伺服器異常問題匯總_revi‮fdp.scr|
|[ec07db228c8b271a3e9b030325ad6a56](https://www.virustotal.com/gui/file/ec07db228c8b271a3e9b030325ad6a56)|Win32 EXE|dapato|2015-11-11 02:15:45|5f8e8ee2cc3bb2a4_D59F.tmp|
|[87375cc6cdf60fc92c973ca984946e7f](https://www.virustotal.com/gui/file/87375cc6cdf60fc92c973ca984946e7f)|Win32 EXE|Injector|2015-11-10 10:48:03|000.exe|
|[784fb61263dd430e4a344565f8b0692c](https://www.virustotal.com/gui/file/784fb61263dd430e4a344565f8b0692c)|Win32 EXE||2015-11-04 01:45:31|libgmodule-2.0-0|
|[bd917f5ac3dc380a6fc53c60c9223deb](https://www.virustotal.com/gui/file/bd917f5ac3dc380a6fc53c60c9223deb)|Win32 EXE|Zbot|2015-10-23 00:52:54|Bluthmon.exe|
|[ab9b323901bcf38b8b990db3cae2b596](https://www.virustotal.com/gui/file/ab9b323901bcf38b8b990db3cae2b596)|Win32 EXE||2015-10-22 17:15:21|c:\Windows\system32\RmClient.exe|
|[9c863613cc5890067a9733eb15cf749e](https://www.virustotal.com/gui/file/9c863613cc5890067a9733eb15cf749e)|Win32 EXE|Upatre|2015-10-20 05:58:43|2015???????????.exe|
|[8edf98a3e38cf8e2a5414f2ff9a1c2a6](https://www.virustotal.com/gui/file/8edf98a3e38cf8e2a5414f2ff9a1c2a6)|RAR|Upatre|2015-10-20 03:38:02|國關年會議程及注意事項final.z|
|[c6c5b4de5cc10418e2f14305d6541bd4](https://www.virustotal.com/gui/file/c6c5b4de5cc10418e2f14305d6541bd4)|Win32 EXE||2015-09-21 19:32:34|afca2ad28ad19a323c9acfd08a9309e856c5ec1b.exe|
|[ea475f5a99ae4f81d23be81bdcfbb6ac](https://www.virustotal.com/gui/file/ea475f5a99ae4f81d23be81bdcfbb6ac)|Win32 EXE||2015-09-10 09:33:59|m.dll|
|[791dbd6071c8d5e04fcaad95b9b6a039](https://www.virustotal.com/gui/file/791dbd6071c8d5e04fcaad95b9b6a039)|DOC|CVE-2012-0158|2015-09-08 05:32:35|蔡英文的國際戰略.doc|
|[123a97612de9089409ad512f3bb2379a](https://www.virustotal.com/gui/file/123a97612de9089409ad512f3bb2379a)|Win32 EXE|graftor|2015-08-24 12:30:19|9EED.tmp|
|[7021e319704ba7bddcdc37716a5c879e](https://www.virustotal.com/gui/file/7021e319704ba7bddcdc37716a5c879e)|Win32 EXE|Zbot|2015-08-24 12:28:37|Bluthmon.exe|
|[e6cda5a52729142dd7a070a3290dfbd2](https://www.virustotal.com/gui/file/e6cda5a52729142dd7a070a3290dfbd2)|Win32 EXE|Zbot|2015-08-19 01:41:39|update.exe|
|[2f13e0bc12badbe63b92a7edabeb02a3](https://www.virustotal.com/gui/file/2f13e0bc12badbe63b92a7edabeb02a3)|Win32 EXE|Zbot|2015-08-18 07:37:29|brsv.exe|
|[2dd69621a4853e69d0ea18eec05d6f7e](https://www.virustotal.com/gui/file/2dd69621a4853e69d0ea18eec05d6f7e)|Win32 EXE|Zbot|2015-08-17 00:49:12|brsrv.exe|
|[7d166e7a86084eeae5f42211ace8622c](https://www.virustotal.com/gui/file/7d166e7a86084eeae5f42211ace8622c)|Win32 EXE|injector|2015-07-31 23:34:03|1040805_????2015???????????(???).exe|
|[a54ef716802bfdcdf362e433efd0edab](https://www.virustotal.com/gui/file/a54ef716802bfdcdf362e433efd0edab)|RAR|graftor|2015-07-31 23:33:35|2015年東亞海域和平論壇安排.xz|
|[d016d961bf0cf4b3aec5619b1b5ebc60](https://www.virustotal.com/gui/file/d016d961bf0cf4b3aec5619b1b5ebc60)|Win32 EXE|TSCookie|2015-07-30 11:00:17|sttray.exe|
|[b3c586acf3abaf3162dadf3f02466177](https://www.virustotal.com/gui/file/b3c586acf3abaf3162dadf3f02466177)|Win32 EXE|Zbot|2015-07-28 06:56:38|bswix.exe|
|[42b091f63548fccbbd87f8c06b632dda](https://www.virustotal.com/gui/file/42b091f63548fccbbd87f8c06b632dda)|SWF||2015-07-15 11:08:14|x|
|[55ee1bb20f6d0838b763acd9044fc6e7](https://www.virustotal.com/gui/file/55ee1bb20f6d0838b763acd9044fc6e7)|Win32 EXE|Zbot|2015-07-13 01:44:19|brsr.exe|
|[cb713b544dce5a2505e393f6587aaa47](https://www.virustotal.com/gui/file/cb713b544dce5a2505e393f6587aaa47)|DOCX|TSCookie|2015-07-13 01:44:09|1.docx|
|[09d1ebf1a6c10083f8d66003418e6e06](https://www.virustotal.com/gui/file/09d1ebf1a6c10083f8d66003418e6e06)|Win32 EXE||2015-07-11 19:30:12| |
|[1902e1ff022ff6f1d612d0a1174424a4](https://www.virustotal.com/gui/file/1902e1ff022ff6f1d612d0a1174424a4)|DOCX|TSCookie|2015-07-10 05:46:06|附件-參加人數統計.docx|
|[6ea02a64df51ab2f12530ffd2e3688de](https://www.virustotal.com/gui/file/6ea02a64df51ab2f12530ffd2e3688de)|Win32 EXE||2015-07-09 17:40:32|m:\dailytesters\##\_ESET\A\a variant of Win32.Agent.WTA.gen trojan\83b23ead5299ecd77b17c7fdae4dcf4122d5921bd1dd80bf0ccf7780ef95f4d7.exe|
|[3da2ad2d32f02172623cc5dfb342e43c](https://www.virustotal.com/gui/file/3da2ad2d32f02172623cc5dfb342e43c)|Win32 EXE||2015-07-06 07:48:09|nagrest.exe|
|[aab34c345d93fe7d5ac2d06ef1463106](https://www.virustotal.com/gui/file/aab34c345d93fe7d5ac2d06ef1463106)|Win32 EXE|dynamer|2015-07-02 05:19:26|winbt.exe|
|[3b30e94191d82f3566de058a60c4ce41](https://www.virustotal.com/gui/file/3b30e94191d82f3566de058a60c4ce41)|Win32 EXE||2015-07-02 03:49:28|AdobeARM.exe|
|[1c00baebd1d2979a1009652dbc58c1fd](https://www.virustotal.com/gui/file/1c00baebd1d2979a1009652dbc58c1fd)|Win32 EXE|Zbot|2015-06-29 06:56:18|Bluthmon.exe|
|[cc18bdaf99fa701796518db86e651702](https://www.virustotal.com/gui/file/cc18bdaf99fa701796518db86e651702)|Win32 EXE||2015-06-29 02:03:16|eaudio3.exe|
|[bd0153175ada800165b395d61c9fff45](https://www.virustotal.com/gui/file/bd0153175ada800165b395d61c9fff45)|Win32 EXE||2015-06-23 11:29:06|IntelControl.exe|
|[5f06d234fc285ee9f127f95206696796](https://www.virustotal.com/gui/file/5f06d234fc285ee9f127f95206696796)|Win32 EXE|TSCookie|2015-06-23 03:28:56|c:\program files\common files\java\java update\jucheck.exe|
|[1134972f093ab1ef08b912cabbc43b39](https://www.virustotal.com/gui/file/1134972f093ab1ef08b912cabbc43b39)|Win32 EXE||2015-05-29 03:50:36|Bluthmon.exe|
|[1d9ac897612ca687c37e66702d19b292](https://www.virustotal.com/gui/file/1d9ac897612ca687c37e66702d19b292)|Win32 EXE||2015-05-21 01:10:06|c:\documents and settings\all users\application data\microsoft\msghts.exe|
|[7a00205cdb74c1d5811cc3c44739a348](https://www.virustotal.com/gui/file/7a00205cdb74c1d5811cc3c44739a348)|Win32 EXE||2015-05-18 14:43:26|Bluthmon.exe|
|[9b6f818f769655c8618ae0420bc994ec](https://www.virustotal.com/gui/file/9b6f818f769655c8618ae0420bc994ec)|Win32 EXE||2015-05-15 03:31:07|\psf\Home\Desktop\MJIB\蒙藏\2015-05-12-2sed\llssrv.exe|
|[391889a2af035ac6e7640d7058b5cfc1](https://www.virustotal.com/gui/file/391889a2af035ac6e7640d7058b5cfc1)|Win32 EXE||2015-05-14 08:42:19|scrss.exe|
|[3406ce96eaafd68fa469af2409ad6ffe](https://www.virustotal.com/gui/file/3406ce96eaafd68fa469af2409ad6ffe)|Win32 EXE||2015-05-07 13:25:45|Bluthmon.exe|
|[486ddfcbf2403c65d3e7954cc69b505f](https://www.virustotal.com/gui/file/486ddfcbf2403c65d3e7954cc69b505f)|Win32 EXE||2015-04-28 08:13:12| |
|[8b3837345303c0d00ca91d30e9cf6ede](https://www.virustotal.com/gui/file/8b3837345303c0d00ca91d30e9cf6ede)|Win32 EXE||2015-04-28 04:20:56|csrss.exe_|
|[e1811b1da49535dd91f6ab086d3ff1f6](https://www.virustotal.com/gui/file/e1811b1da49535dd91f6ab086d3ff1f6)|Win32 EXE||2015-04-24 22:49:25|Firefox_unpacked.exe|
|[b9b6488f990a96a1c2f5c3e99a43a212](https://www.virustotal.com/gui/file/b9b6488f990a96a1c2f5c3e99a43a212)|Win32 EXE|Zbot|2015-04-03 14:13:25|Bluthmon.exe|
|[c752a2caf765ee7718277c7c028a8a9a](https://www.virustotal.com/gui/file/c752a2caf765ee7718277c7c028a8a9a)|Win32 DLL|Kivars|2015-04-03 01:50:26|file32_2.exe|
|[a6b48f5675c55b124908dd11635919ac](https://www.virustotal.com/gui/file/a6b48f5675c55b124908dd11635919ac)|Win32 EXE|Zbot|2015-03-19 04:34:19|Bluthmon.exe|
|[b90b0ff065be669d4d882a2861115ea5](https://www.virustotal.com/gui/file/b90b0ff065be669d4d882a2861115ea5)|DOC|CVE-2012-0158|2015-03-18 07:48:07|=?big5?B?oXWyu7RJrEuhdri5uq6y7qWiwXChQaSjqfGx87dqtE0uZG9j?=|
|[2339bb4005da17cc84fa9e86a8d7983a](https://www.virustotal.com/gui/file/2339bb4005da17cc84fa9e86a8d7983a)|Win32 DLL||2015-03-17 02:01:29|ADVPACK32|
|[5557ffbc41d28cf5608598fba50d0f0e](https://www.virustotal.com/gui/file/5557ffbc41d28cf5608598fba50d0f0e)|Win32 EXE||2015-03-17 01:59:51|libgmodule-2.0-0|
|[639637d46f64f4e0164e704be98c7c67](https://www.virustotal.com/gui/file/639637d46f64f4e0164e704be98c7c67)|Win32 EXE||2015-03-05 21:16:44|Bluthmon.exe|
|[f5cce3e8c5d8d24edca83ae34d505d61](https://www.virustotal.com/gui/file/f5cce3e8c5d8d24edca83ae34d505d61)|DOC|CVE-2012-0158|2015-03-05 08:56:48|Liberty times net 0305.doc|
|[3cc380f2e0f333e064f37626631962e6](https://www.virustotal.com/gui/file/3cc380f2e0f333e064f37626631962e6)|Win32 EXE|TSCookie|2015-03-05 03:11:58|立法院104年度資訊系統升級計畫‮cod..scr|
|[7a1b0e86d2c7da3f52c74a4ce4b675af](https://www.virustotal.com/gui/file/7a1b0e86d2c7da3f52c74a4ce4b675af)|Win32 EXE||2015-02-28 06:41:59|Bluthmon.exe|
|[04c8da84416ebd980fa1adc40e90a74e](https://www.virustotal.com/gui/file/04c8da84416ebd980fa1adc40e90a74e)|Win64 DLL||2015-02-25 03:18:09|nsrinit.dll|
|[abf10fa008bbbe5394237df9e52a5169](https://www.virustotal.com/gui/file/abf10fa008bbbe5394237df9e52a5169)|unknown||2015-02-25 02:51:10|libuni.jar|
|[0fe677c8ff4d1e880527e4128b79bb34](https://www.virustotal.com/gui/file/0fe677c8ff4d1e880527e4128b79bb34)|Win64 EXE|PoisonIvy|2015-02-24 09:43:11|nsrexecd|
|[7e506e90a2308231874f56f24feb9be7](https://www.virustotal.com/gui/file/7e506e90a2308231874f56f24feb9be7)|Win32 DLL||2015-02-12 15:08:03|ADVPACK32|
|[414f712f5150c04782f7c037a849a8b2](https://www.virustotal.com/gui/file/414f712f5150c04782f7c037a849a8b2)|unknown||2015-02-09 08:30:14|VMwareRes.pkg|
|[e448666cf15651eff32e7296f2f57206](https://www.virustotal.com/gui/file/e448666cf15651eff32e7296f2f57206)|Win32 EXE||2015-01-29 09:34:44|e448666cf15651eff32e7296f2f57206|
|[525c25e293b3d30186b75cce5c5c4c8d](https://www.virustotal.com/gui/file/525c25e293b3d30186b75cce5c5c4c8d)|Win64 DLL||2015-01-29 05:53:37|VmUpgradeNT|
|[bc6b1264f9dfebdde7a4b94ff0f61c83](https://www.virustotal.com/gui/file/bc6b1264f9dfebdde7a4b94ff0f61c83)|Win32 EXE|TSCookie|2015-01-28 09:02:51|imekrimg.exe|
|[f3ebe8a08320fe1106e3932873a44bfe](https://www.virustotal.com/gui/file/f3ebe8a08320fe1106e3932873a44bfe)|Win32 EXE|Upatre|2015-01-28 09:00:01|AdobeARM.exe|
|[69b4467e347dcf360ef7d2dd2a869601](https://www.virustotal.com/gui/file/69b4467e347dcf360ef7d2dd2a869601)|Win32 EXE|TSCookie|2015-01-22 19:44:53|69b4467e347dcf360ef7d2dd2a869601|
|[bf0435f7030af4f2a7f715dc12fdecce](https://www.virustotal.com/gui/file/bf0435f7030af4f2a7f715dc12fdecce)|Win32 DLL|poison|2015-01-15 08:39:49|libBEScrypto_1_0_0_6.dll|
|[96604774e3034b41ff43dc2e4619ab70](https://www.virustotal.com/gui/file/96604774e3034b41ff43dc2e4619ab70)|Win32 EXE||2015-01-14 02:40:56|BESClient|
|[0fd48bd160854bea6e9df66a9451b9ed](https://www.virustotal.com/gui/file/0fd48bd160854bea6e9df66a9451b9ed)|Win32 EXE||2015-01-13 07:16:53|CGEnvDetectATL.exe|
|[8c2e717c09cee5234bec059decc04fbc](https://www.virustotal.com/gui/file/8c2e717c09cee5234bec059decc04fbc)|RAR||2014-12-30 07:56:42|imekrimg.rar|
|[f0d23a1d2db6f1c52e446f1f0c09ab98](https://www.virustotal.com/gui/file/f0d23a1d2db6f1c52e446f1f0c09ab98)|RAR||2014-12-30 07:56:33|fsupdate.rar|
|[fda02aaff2ea8c91283f1041257cf36f](https://www.virustotal.com/gui/file/fda02aaff2ea8c91283f1041257cf36f)|Win32 EXE|dynamer|2014-12-30 04:37:32|fsupdate.exe|
|[f9fb509be917ac38f440e716fa66a332](https://www.virustotal.com/gui/file/f9fb509be917ac38f440e716fa66a332)|Win32 EXE||2014-12-30 04:37:28|imekrimg.exe|
|[187d4a946f494ec56c28466551ec768a](https://www.virustotal.com/gui/file/187d4a946f494ec56c28466551ec768a)|Win32 DLL||2014-12-28 00:37:36|ADVPACK32|
|[eb83262ff12ae0839058adefb7276edb](https://www.virustotal.com/gui/file/eb83262ff12ae0839058adefb7276edb)|Win32 EXE|Zbot|2014-11-28 19:46:54|Bluthmon.exe|
|[39909b486f7afe4725ae1b73019390f4](https://www.virustotal.com/gui/file/39909b486f7afe4725ae1b73019390f4)|ELF executable|Bifrose|2014-11-28 15:55:50|trusted-bk|
|[4a4ea45cb850e4decd5fdb23909ea728](https://www.virustotal.com/gui/file/4a4ea45cb850e4decd5fdb23909ea728)|ELF executable|Bifrose|2014-11-15 01:07:04|rmif|
|[4085f90f6934422921bd8602f0a975c0](https://www.virustotal.com/gui/file/4085f90f6934422921bd8602f0a975c0)|Win32 EXE||2014-11-13 02:42:17|4085f90f6934422921bd8602f0a975c0.virobj|
|[b0969efc34fe6d06542942b14295305b](https://www.virustotal.com/gui/file/b0969efc34fe6d06542942b14295305b)|Win32 EXE||2014-11-13 02:07:04|update.exe|
|[cea5d1fcf92da7212bcdc2989a3518e7](https://www.virustotal.com/gui/file/cea5d1fcf92da7212bcdc2989a3518e7)|Win32 EXE||2014-11-12 18:09:30|cea5d1fcf92da7212bcdc2989a3518e7|
|[18ca4159820c1766f358de2ffc92a271](https://www.virustotal.com/gui/file/18ca4159820c1766f358de2ffc92a271)|Win32 EXE|TSCookie|2014-11-11 01:35:30|??????????????_??????fdp..scr|
|[4446ba673bc5c2adf31823301a4fdd3a](https://www.virustotal.com/gui/file/4446ba673bc5c2adf31823301a4fdd3a)|Win32 EXE|injector|2014-11-11 01:33:52|??????????????_??????cod..scr|
|[22ede86834e0060a88d6f45ce3982277](https://www.virustotal.com/gui/file/22ede86834e0060a88d6f45ce3982277)|RAR||2014-11-11 01:30:18|??????????????_?????doc.rar|
|[9bb0135b4808331933490d4749d30c11](https://www.virustotal.com/gui/file/9bb0135b4808331933490d4749d30c11)|RAR||2014-11-11 01:29:47|奪命病毒：伊波拉家庭預防手冊_無國界醫生.rar|
|[289286f8289b707d41e74a199a88be64](https://www.virustotal.com/gui/file/289286f8289b707d41e74a199a88be64)|Win32 EXE|blocker|2014-11-07 15:34:35|Bluthmon.exe|
|[c6dc9f750f5fddb01f92ab22b062b80a](https://www.virustotal.com/gui/file/c6dc9f750f5fddb01f92ab22b062b80a)|PPSX||2014-11-04 15:16:44|electionsSW.ppsx|
|[69d83dd95abf0f3e9cccaf30d909d8ab](https://www.virustotal.com/gui/file/69d83dd95abf0f3e9cccaf30d909d8ab)|Win32 EXE|Zbot|2014-11-02 22:56:14|Bluthmon.exe|
|[5a7d8fe286333416796cefc19b0f5cba](https://www.virustotal.com/gui/file/5a7d8fe286333416796cefc19b0f5cba)|Win32 EXE|Zbot|2014-10-31 08:22:38|Bluthmon.exe|
|[e9a0ee534db37006dcd53812f7f0665e](https://www.virustotal.com/gui/file/e9a0ee534db37006dcd53812f7f0665e)|Win32 DLL||2014-10-21 23:49:31|ADVPACK32|
|[87af1c51d21d13899db75f675b1faa87](https://www.virustotal.com/gui/file/87af1c51d21d13899db75f675b1faa87)|Win32 EXE|Zbot|2014-10-19 16:15:44|Bluthmon.exe|
|[4bcb99623c05fc2abaa1b4090b0bee6c](https://www.virustotal.com/gui/file/4bcb99623c05fc2abaa1b4090b0bee6c)|Win32 EXE|Zbot|2014-10-13 02:29:32|Bluthmon.exe|
|[79f1af23d5ab729a3071d1f4c2a0606f](https://www.virustotal.com/gui/file/79f1af23d5ab729a3071d1f4c2a0606f)|Win32 EXE|Zbot|2014-10-13 02:29:04|XX20141013.SCR|
|[3902c3d82c5a0a5c7f03280f1979cd08](https://www.virustotal.com/gui/file/3902c3d82c5a0a5c7f03280f1979cd08)|Win32 EXE|Kivars|2014-10-05 00:25:50|3902c3d82c5a0a5c7f03280f1979cd08|
|[5b83dcd3f6615e9b18104088523eaaf3](https://www.virustotal.com/gui/file/5b83dcd3f6615e9b18104088523eaaf3)|Win32 EXE|Zbot|2014-09-19 10:29:29|Bluthmon.exe|
|[dee1f09ef83a041555ce8b1f3effab01](https://www.virustotal.com/gui/file/dee1f09ef83a041555ce8b1f3effab01)|Win32 EXE||2014-09-17 10:28:39|word.exe|
|[04a420981c8724b654b30ecb13a1b9a5](https://www.virustotal.com/gui/file/04a420981c8724b654b30ecb13a1b9a5)|Win32 EXE|TSCookie|2014-09-16 07:54:03|wuaclt.WWB|
|[63b7225115eaef8c4e3512f167c47633](https://www.virustotal.com/gui/file/63b7225115eaef8c4e3512f167c47633)|Win32 DLL||2014-09-11 07:42:54|ADVPACK32|
|[73add080471429445ecba08d95f03b01](https://www.virustotal.com/gui/file/73add080471429445ecba08d95f03b01)|DOC|CVE-2012-0158|2014-09-03 08:15:12|tt.doc|
|[59e9af5b230f46df15e076cd6dd82d1e](https://www.virustotal.com/gui/file/59e9af5b230f46df15e076cd6dd82d1e)|Win32 EXE|Zbot|2014-08-28 06:37:50|C:\Users\2099\AppData\Local\Microsoft\Windows\jusched.exe|
|[b04fab560ac090e0ff3f1c602f3fcfd7](https://www.virustotal.com/gui/file/b04fab560ac090e0ff3f1c602f3fcfd7)|Win32 EXE||2014-08-08 07:04:17|vti-rescan|
|[644dc1a6a1c658ba25c3772f71269bea](https://www.virustotal.com/gui/file/644dc1a6a1c658ba25c3772f71269bea)|Win32 DLL||2014-08-07 16:15:01|ADVPACK32|
|[e5761a294e7955bf234f7dd38b980633](https://www.virustotal.com/gui/file/e5761a294e7955bf234f7dd38b980633)|Win32 EXE||2014-08-06 01:58:32|PATCH64.EXE|
|[dbeb16d8745a9b9b0daf946d2caecae0](https://www.virustotal.com/gui/file/dbeb16d8745a9b9b0daf946d2caecae0)|Win32 EXE||2014-08-01 08:05:33|Bluthmon.exe|
|[acc03ef1eef25c397972ae27087621a6](https://www.virustotal.com/gui/file/acc03ef1eef25c397972ae27087621a6)|Win32 EXE||2014-08-01 08:05:16|Bluthmon.exe|
|[97fdb683e7b56bdf198d2b4c0e9b2715](https://www.virustotal.com/gui/file/97fdb683e7b56bdf198d2b4c0e9b2715)|Win32 EXE|bitrep|2014-07-31 02:57:31|Bluthmon.exe|
|[9d93d082d9374e2db1ec03979fed1136](https://www.virustotal.com/gui/file/9d93d082d9374e2db1ec03979fed1136)|Win32 DLL||2014-07-16 04:55:27|ADVPACK32|
|[73fabddce8887d0253503daa4a50fdf7](https://www.virustotal.com/gui/file/73fabddce8887d0253503daa4a50fdf7)|Win32 EXE||2014-07-15 06:04:49|wuaclt.exe|
|[3088e79df5e905a78e1661eef33109cb](https://www.virustotal.com/gui/file/3088e79df5e905a78e1661eef33109cb)|Win32 DLL||2014-07-10 07:23:55|ADVPACK32|
|[6a0a0dc835f0606aab1efd9a7f426906](https://www.virustotal.com/gui/file/6a0a0dc835f0606aab1efd9a7f426906)|Win32 DLL||2014-07-07 07:33:10|ADVPACK32|
|[1423e253f7a8954ca3c74432b5e4d038](https://www.virustotal.com/gui/file/1423e253f7a8954ca3c74432b5e4d038)|Win32 EXE|Zbot|2014-06-27 08:30:19|vt-upload-cdbof|
|[cb612bd16abae8bdbd551e78278988f4](https://www.virustotal.com/gui/file/cb612bd16abae8bdbd551e78278988f4)|Win32 EXE|graftor|2014-06-23 10:52:56|vt-upload-BHXVZ|
|[a735b9c81e6cffd576abd914cc635aea](https://www.virustotal.com/gui/file/a735b9c81e6cffd576abd914cc635aea)|Win32 EXE|injector|2014-06-23 09:31:42|e155399cccb1ec1c15805b7ce97db58106403a8eda4d58f5d13ae278b8d208bf.vir|
|[76055e90b1e1e9d67139c7645c21092e](https://www.virustotal.com/gui/file/76055e90b1e1e9d67139c7645c21092e)|Win32 EXE|injector|2014-06-23 08:25:22|vt-upload-VxxEG|
|[3c4fe121835467d056a77b60eaf3257b](https://www.virustotal.com/gui/file/3c4fe121835467d056a77b60eaf3257b)|Win32 EXE||2014-06-16 08:01:15|Bluthmon.exe|
|[5708d6c871e56833020be00fcac9b4fa](https://www.virustotal.com/gui/file/5708d6c871e56833020be00fcac9b4fa)|Win32 EXE||2014-06-16 08:00:07|Bluthmon.exe|
|[87835a271ff098d7a0a44e45be83a9d8](https://www.virustotal.com/gui/file/87835a271ff098d7a0a44e45be83a9d8)|7ZIP||2014-06-16 01:13:14|20140613.7z|
|[dcd88df79393a92bbf29824580649d0c](https://www.virustotal.com/gui/file/dcd88df79393a92bbf29824580649d0c)|Win32 EXE|blocker|2014-06-15 01:29:19|Bluthmon.exe|
|[fa4bb0c43fcfaaa4d98d6322c376281d](https://www.virustotal.com/gui/file/fa4bb0c43fcfaaa4d98d6322c376281d)|Win32 EXE||2014-06-15 01:25:06|???????????.exe|
|[58ebad50377af27347a4a216625ec8c7](https://www.virustotal.com/gui/file/58ebad50377af27347a4a216625ec8c7)|Win32 EXE||2014-06-06 08:52:21|vti-rescan|
|[23b1717f7690f2670585ce42abcf07c0](https://www.virustotal.com/gui/file/23b1717f7690f2670585ce42abcf07c0)|Win32 EXE||2014-06-04 07:20:01|Bluthmon.exe|
|[e5c8b3017d309a7383c9504d7e318596](https://www.virustotal.com/gui/file/e5c8b3017d309a7383c9504d7e318596)|Win32 EXE|Zbot|2014-06-02 10:18:54|1d272f4e98b7e7d0649725ca04b268ba459d98c0|
|[737c6923effeee58717f613db304955a](https://www.virustotal.com/gui/file/737c6923effeee58717f613db304955a)|Win32 EXE|dynamer|2014-05-25 05:55:51|vt-upload-TML6W|
|[7fbeaa329ceb7deb0077d9c95b99883f](https://www.virustotal.com/gui/file/7fbeaa329ceb7deb0077d9c95b99883f)|Win32 EXE|injector|2014-05-25 05:55:50|vt-upload-TML6W|
|[601a4718678a290c004b531b498e40fa](https://www.virustotal.com/gui/file/601a4718678a290c004b531b498e40fa)|Win32 EXE||2014-05-23 16:21:00|2014TASPAA完整版議程‮fdp.scr|
|[1c498d8aa332b89a1430145e7cfcd43b](https://www.virustotal.com/gui/file/1c498d8aa332b89a1430145e7cfcd43b)|Win32 DLL||2014-05-21 07:32:55|ADVPACK32|
|[c68804a180b7bb55d132e92d769268bd](https://www.virustotal.com/gui/file/c68804a180b7bb55d132e92d769268bd)|Win32 EXE||2014-05-21 07:32:24|libgmodule-2.0|
|[e56be630165e040d733cc3706dae1d06](https://www.virustotal.com/gui/file/e56be630165e040d733cc3706dae1d06)|Win32 EXE||2014-05-17 04:27:57|513ce01bcf1fd6a089a501fa00999f04e34b97edaf68f8d52e00b358741e2451.exe.000|
|[6a97ff47b8d715be62305ff15fb47332](https://www.virustotal.com/gui/file/6a97ff47b8d715be62305ff15fb47332)|Win32 EXE||2014-05-01 08:43:58|wscntfy.exe|
|[32a2f6a5e152669b9b9987daf91722d8](https://www.virustotal.com/gui/file/32a2f6a5e152669b9b9987daf91722d8)|Win32 EXE||2014-05-01 02:28:28|inetcfg.exe|
|[0f8c95206cbfe067d0333185b37de467](https://www.virustotal.com/gui/file/0f8c95206cbfe067d0333185b37de467)|Win32 EXE|bitrep|2014-05-01 00:50:56|Bluthmon.exe|
|[808e8a7ff27e284bbd07cee65403b66c](https://www.virustotal.com/gui/file/808e8a7ff27e284bbd07cee65403b66c)|Win32 EXE||2014-04-23 15:52:56|be68deeef2f1d6556a61df8a7b283d01168fd471|
|[65a4384fcbe3d010a57a8530b27e0a4e](https://www.virustotal.com/gui/file/65a4384fcbe3d010a57a8530b27e0a4e)|Win32 EXE||2014-04-17 05:57:57|vti-rescan|
|[f196ba5da72feb9de9454bb1a6862a66](https://www.virustotal.com/gui/file/f196ba5da72feb9de9454bb1a6862a66)|Win32 EXE|Kivars|2014-04-11 16:21:05|isheriff_f196ba5da72feb9de9454bb1a6862a66.bin|
|[5bb14699b14e48608d43f51c56b88a04](https://www.virustotal.com/gui/file/5bb14699b14e48608d43f51c56b88a04)|Win32 EXE||2014-03-29 05:13:55|vt-upload-bMGry|
|[2a233c4f6571a2fc3342d6edf3c1e98d](https://www.virustotal.com/gui/file/2a233c4f6571a2fc3342d6edf3c1e98d)|Win32 EXE||2014-03-28 13:47:02|2.tmp|
|[73993f9f448449f0c5c6977664cfd8fa](https://www.virustotal.com/gui/file/73993f9f448449f0c5c6977664cfd8fa)|Win32 EXE||2014-03-28 05:33:50|20140120014233_46245sadfjkqwpoe[fqjweifj[qweiojkqds[pfakodsopakfw0ek[2930921-023jjd02ew?gpj.exe|
|[f7675431685701edb506ffebc182f6ef](https://www.virustotal.com/gui/file/f7675431685701edb506ffebc182f6ef)|Win32 EXE|graftor|2014-03-28 05:33:50|20140120014253_46730j9ewj9wefjw9qef8qw9ef8jqw9ef8w9ejf0q2wdoiewjiu2h3e82dhqdhqwduid? gpj.exe|
|[64ec5419edd9ff050d839845a0a5bea3](https://www.virustotal.com/gui/file/64ec5419edd9ff050d839845a0a5bea3)|Win32 EXE||2014-03-28 05:33:50|20140120014300_936185228309128394318522830912839431852283091283943185228309128394317eqwq?gpj.exe|
|[391974cd1e5338938faf7f9a22ee3bf5](https://www.virustotal.com/gui/file/391974cd1e5338938faf7f9a22ee3bf5)|Win32 EXE||2014-03-28 05:33:50|20140120014535_852283091283943185228309128394318522830912839431qwerqfasdfasexxxaazde?gpj.exe|
|[2a94c32c20dd4632e0a5084b134e6344](https://www.virustotal.com/gui/file/2a94c32c20dd4632e0a5084b134e6344)|Win32 EXE||2014-03-28 05:33:50|20140120014236_36516jewqjf0297h23wd6yg6syg26h7eugh36t26t51af7re73t56rt16w7y8712yw?gpj.exe|
|[f0c1cc799d56d58f528f41039895f8f8](https://www.virustotal.com/gui/file/f0c1cc799d56d58f528f41039895f8f8)|Win32 EXE|graftor|2014-03-28 05:33:50|20140120014304_6164223324123412341252283091283943ewqerqwrwerqsafadsfaeefwew?gpj.exe|
|[7ca58dd5daa70dd5dc278070512eb394](https://www.virustotal.com/gui/file/7ca58dd5daa70dd5dc278070512eb394)|Win32 EXE|injector|2014-03-28 05:31:09|??????????????? 2_Mapl?cod.exe|
|[b7bf246b1481b24ff262cd03c53caf15](https://www.virustotal.com/gui/file/b7bf246b1481b24ff262cd03c53caf15)|Win32 EXE|injector|2014-03-28 05:31:08|???????????????_Light sea?cod.exe|
|[410ceb4d5008887a66587130d57adeee](https://www.virustotal.com/gui/file/410ceb4d5008887a66587130d57adeee)|Win32 EXE|graftor|2014-03-28 05:31:08|???????????????_Mapl?cod.exe|
|[1c460850b55125a7d1f554ee0203fa25](https://www.virustotal.com/gui/file/1c460850b55125a7d1f554ee0203fa25)|Win32 EXE|graftor|2014-03-28 05:31:08|????????????????_Listening to the sea?cod.exe|
|[cf128ba5945102e1b1a089032f2e4bc1](https://www.virustotal.com/gui/file/cf128ba5945102e1b1a089032f2e4bc1)|Win32 EXE|dynamer|2014-03-28 05:31:08|??????????????? 1_Lak?cod.exe|
|[402627c57c6127187c7ee1ba9b4e11ad](https://www.virustotal.com/gui/file/402627c57c6127187c7ee1ba9b4e11ad)|RAR|graftor|2014-03-28 05:25:11|=?utf-8?B?5rKZ5a2Q6KKr5pS+5aSnMzAw5YCNLnJhcg==?=|
|[413a34cb61e954c4e82a63875cce9a67](https://www.virustotal.com/gui/file/413a34cb61e954c4e82a63875cce9a67)|RAR|injector|2014-03-28 05:24:59|=?big5?B?xenF56V4xleh0K72uqmxoatRpKeuyC5yYXI=?=|
|[8a81e6a62d3bdcffe074807d7173840f](https://www.virustotal.com/gui/file/8a81e6a62d3bdcffe074807d7173840f)|Win32 EXE||2014-03-28 05:15:47|vt-upload-Nchgq|
|[c6e098547bace9c4844dd99230a525b8](https://www.virustotal.com/gui/file/c6e098547bace9c4844dd99230a525b8)|Win32 EXE||2014-03-27 03:00:24|20140120014229_516660803261460394824sdfasdjfij2ifiwoqejf[wefqweiofjqpowefo1huwegtwqehiuh?gpj.exe|
|[9d014bc00ecb311db63beeadf0d8bb19](https://www.virustotal.com/gui/file/9d014bc00ecb311db63beeadf0d8bb19)|Win32 EXE|TSCookie|2014-03-14 03:17:21|wuau.exe|
|[ea1a6799ee02bcadf70b34f7801e525f](https://www.virustotal.com/gui/file/ea1a6799ee02bcadf70b34f7801e525f)|Win32 EXE|dynamer|2014-03-14 03:16:39|APEC運輸部門業務通訊.exe|
|[6ff0374bf169ddedaf2654c94b985617](https://www.virustotal.com/gui/file/6ff0374bf169ddedaf2654c94b985617)|Win32 EXE||2014-02-20 01:54:38|IMTC65.exe|
|[2f0309a2aa1229af5f7222ce16385494](https://www.virustotal.com/gui/file/2f0309a2aa1229af5f7222ce16385494)|Win32 DLL||2014-01-17 16:13:15|ADVPACK32|
|[1f817bf205e5e5bcf4543d36e3865805](https://www.virustotal.com/gui/file/1f817bf205e5e5bcf4543d36e3865805)|Win32 DLL||2014-01-15 06:47:21|ADVPACK32|
|[6d4afed614975eb519261a6a60fc2a26](https://www.virustotal.com/gui/file/6d4afed614975eb519261a6a60fc2a26)|Win32 DLL||2013-12-29 11:04:28|ADVPACK32|
|[f956a68ea6de05207cc80c9f022077c1](https://www.virustotal.com/gui/file/f956a68ea6de05207cc80c9f022077c1)|Win32 DLL||2013-11-06 14:47:16|ADVPACK32|
|[5fd4021c123a7144b3857134f5baf212](https://www.virustotal.com/gui/file/5fd4021c123a7144b3857134f5baf212)|Win32 DLL||2013-11-04 19:31:19|ADVPACK32|
|[45ed3086b3d03b253f8746a174a060d1](https://www.virustotal.com/gui/file/45ed3086b3d03b253f8746a174a060d1)|Win32 EXE||2013-11-03 22:38:01|45ed3086b3d03b253f8746a174a060d1|
|[61d318aacfd97961a9248f696025177e](https://www.virustotal.com/gui/file/61d318aacfd97961a9248f696025177e)|Win32 EXE|Fortis|2013-10-30 03:00:38|vti-rescan|
|[2267326efac998fa4ddbc7d8e3940c0d](https://www.virustotal.com/gui/file/2267326efac998fa4ddbc7d8e3940c0d)|Win32 EXE||2013-10-17 06:31:14|IMTC65.exe|
|[660b315cdd0c0c53b76b7a1f5858247d](https://www.virustotal.com/gui/file/660b315cdd0c0c53b76b7a1f5858247d)|Win32 EXE|bitrep|2013-10-15 11:34:13|libgmodule-2.0-0|
|[7ec147dce6b31d1f03583e67244cac9e](https://www.virustotal.com/gui/file/7ec147dce6b31d1f03583e67244cac9e)|Win32 EXE||2013-10-15 08:30:09|libgmodule-2.0-0|
|[8d31ebecdf790a80175d358212b3dd19](https://www.virustotal.com/gui/file/8d31ebecdf790a80175d358212b3dd19)|Win32 EXE|Zbot|2013-10-08 15:07:27|Bluthmon.exe|
|[67dc872fd92d66a4589f9ac58e5f1bd9](https://www.virustotal.com/gui/file/67dc872fd92d66a4589f9ac58e5f1bd9)|Win32 DLL||2013-09-25 17:54:02|ADVPACK32|
|[17cece9c7bbe0c2d6c37056742a7a7e9](https://www.virustotal.com/gui/file/17cece9c7bbe0c2d6c37056742a7a7e9)|Win32 EXE||2013-09-24 08:34:54|spoolv.exe|
|[811ad8d894c461c446843de4a9a3fd42](https://www.virustotal.com/gui/file/811ad8d894c461c446843de4a9a3fd42)|Win32 EXE||2013-09-23 03:08:50|Bluthmon.exe|
|[5e72bcafef281999bafeff7b9085dc7c](https://www.virustotal.com/gui/file/5e72bcafef281999bafeff7b9085dc7c)|Win32 EXE||2013-09-18 07:30:57|81d95b6d926a804117fcb67d01a1c6718510bf8c81de41f3f16e41b09ba07839.exe|
|[dd929e715c48baf6239407af6a99abb0](https://www.virustotal.com/gui/file/dd929e715c48baf6239407af6a99abb0)|Win32 EXE|Kivars|2013-09-14 03:28:17|doc.exe.infected|
|[a11d30dcfb8cedcb56dad172b213f388](https://www.virustotal.com/gui/file/a11d30dcfb8cedcb56dad172b213f388)|Win32 EXE|Kryptik|2013-09-11 01:56:12|Bluthmon.exe|
|[259ce74e8a6ddc2507efa64371f3d45e](https://www.virustotal.com/gui/file/259ce74e8a6ddc2507efa64371f3d45e)|Win32 EXE||2013-09-06 05:55:02|?1???????.exe|
|[89eb892d945034e549118cda2120c17d](https://www.virustotal.com/gui/file/89eb892d945034e549118cda2120c17d)|RAR|graftor|2013-09-06 05:54:06|國家發展前瞻規劃第1次工作會議資料.rar|
|[28da4707d69de5cc3d544d6a90fff8ff](https://www.virustotal.com/gui/file/28da4707d69de5cc3d544d6a90fff8ff)|Win32 EXE||2013-09-06 01:59:56|Bluthmon.exe|
|[f2f1156cc008c30dcd33033110a3e279](https://www.virustotal.com/gui/file/f2f1156cc008c30dcd33033110a3e279)|Win32 EXE||2013-08-30 20:36:55|dc019e5c2daec396c8bba65575bab14f002f3d14|
|[cad875330c25231211fc9a416c3846b7](https://www.virustotal.com/gui/file/cad875330c25231211fc9a416c3846b7)|Win32 EXE||2013-08-29 08:37:40|Bluthmon.exe|
|[6b022a8cea1bd0e3b511961c7f12da0e](https://www.virustotal.com/gui/file/6b022a8cea1bd0e3b511961c7f12da0e)|Win32 EXE||2013-08-29 07:36:37|igfxers.exe|
|[7fac9853964641d792e4751928cacd1a](https://www.virustotal.com/gui/file/7fac9853964641d792e4751928cacd1a)|Win32 DLL||2013-08-29 02:16:46|1bffab46823f621249e6192372c4119e6ee9995e|
|[ba8713a1f4dd00798de34c7eab82f08d](https://www.virustotal.com/gui/file/ba8713a1f4dd00798de34c7eab82f08d)|Win32 DLL||2013-08-27 19:26:34|ADVPACK32|
|[c288f4729f7cdce991dcf7c2b156e854](https://www.virustotal.com/gui/file/c288f4729f7cdce991dcf7c2b156e854)|Win32 EXE|TSCookie|2013-08-27 13:40:29|vti-rescan|
|[5010095d4e20af88822ebf01fb7ba8bb](https://www.virustotal.com/gui/file/5010095d4e20af88822ebf01fb7ba8bb)|Win32 DLL||2013-08-25 06:09:46|ADVPACK32|
|[61d10a3d4d3a10f1e458e1efa799472a](https://www.virustotal.com/gui/file/61d10a3d4d3a10f1e458e1efa799472a)|Win32 DLL|TSCookie|2013-08-09 10:42:51|8ca9fc3d4d92677f2788d1fbb252883ce016df7a|
|[cfc48c66c7630653faa136ba83617cb0](https://www.virustotal.com/gui/file/cfc48c66c7630653faa136ba83617cb0)|Win32 EXE|Fortis|2013-08-09 02:12:07|????????_????(???).exe|
|[842e7ed1d9a3148c706e2f5e80e01735](https://www.virustotal.com/gui/file/842e7ed1d9a3148c706e2f5e80e01735)|RAR||2013-08-09 01:40:13|兩岸服務貿易協議影響評估及後續協商議題.rar|
|[f1cd5ad6d849816c48ae6b29f0705a03](https://www.virustotal.com/gui/file/f1cd5ad6d849816c48ae6b29f0705a03)|Win32 DLL||2013-08-07 09:38:56|ADVPACK32|
|[fd016b952c98a8be9c51c44d2a288c71](https://www.virustotal.com/gui/file/fd016b952c98a8be9c51c44d2a288c71)|Win32 EXE|blocker|2013-08-07 03:04:30|III郵件帳號管理.exe|
|[3a17eb2f7cefbb332944b65188667176](https://www.virustotal.com/gui/file/3a17eb2f7cefbb332944b65188667176)|Win32 DLL||2013-07-18 03:36:50|ADVPACK32|
|[77e8503f721a715a5309f89c88f1da8c](https://www.virustotal.com/gui/file/77e8503f721a715a5309f89c88f1da8c)|Win32 EXE|TSCookie|2013-07-15 06:06:38|mozila.exe|
|[0566703ccda6c60816ef1d8d917aa7b0](https://www.virustotal.com/gui/file/0566703ccda6c60816ef1d8d917aa7b0)|Win32 EXE||2013-07-06 14:44:27|0566703ccda6c60816ef1d8d917aa7b0|
|[6b18b1e939e5a06303220ee16f045a50](https://www.virustotal.com/gui/file/6b18b1e939e5a06303220ee16f045a50)|Win32 EXE||2013-07-01 02:38:48|????????.exe|
|[062bcc4ed28b41bab70d7efc2e8b1b11](https://www.virustotal.com/gui/file/062bcc4ed28b41bab70d7efc2e8b1b11)|RAR||2013-07-01 02:38:22|兩岸服務貿易協議文本及後續協商議題.rar|
|[463d74f0085a613c44dc9ded28ba903d](https://www.virustotal.com/gui/file/463d74f0085a613c44dc9ded28ba903d)|Win32 EXE|graftor|2013-06-26 01:44:08|海峽兩岸服務貿易協議.exe|
|[8907d4e0ec913f09185a5f4898849ab6](https://www.virustotal.com/gui/file/8907d4e0ec913f09185a5f4898849ab6)|Win32 DLL||2013-05-31 11:56:24|ADVPACK32|
|[0f7a5c9f8d99301e328edb043fa3f5c4](https://www.virustotal.com/gui/file/0f7a5c9f8d99301e328edb043fa3f5c4)|Win32 EXE||2013-05-31 11:55:58|libgmodule-2.0|
|[5a133e8588f6bdecff91682d370f567d](https://www.virustotal.com/gui/file/5a133e8588f6bdecff91682d370f567d)|Win32 DLL||2013-05-29 16:32:21|tpauto.dll|
|[1a05cdb6c0acf27a1a1fdae85c109a54](https://www.virustotal.com/gui/file/1a05cdb6c0acf27a1a1fdae85c109a54)|Win32 DLL||2013-05-14 08:31:19|ADVPACK32|
|[de1ef16ede897cf4185d4b0e1662d6f1](https://www.virustotal.com/gui/file/de1ef16ede897cf4185d4b0e1662d6f1)|Win32 EXE||2013-05-14 08:30:53|libgmodule-2.0|
|[588057b600c8d48b5475ee8b8715f281](https://www.virustotal.com/gui/file/588057b600c8d48b5475ee8b8715f281)|Win32 DLL||2013-05-03 13:37:36|ADVPACK32|
|[73108c848c3ca5f51e866504de4ec342](https://www.virustotal.com/gui/file/73108c848c3ca5f51e866504de4ec342)|Win32 DLL||2013-04-09 17:55:49|ADVPACK32|
|[ae1bacc1223486ac3baa8e4d5244ace4](https://www.virustotal.com/gui/file/ae1bacc1223486ac3baa8e4d5244ace4)|Win32 EXE|Kivars|2013-04-07 06:46:18|\sonas\share\samples\ae\1b\ac\c1\ae1bacc1223486ac3baa8e4d5244ace4.4eb78ce1b91dc5f4f25877ca1109f2a41f2193b3|
|[b36fa6c0823d34d3a9b68ce7a84b1fe5](https://www.virustotal.com/gui/file/b36fa6c0823d34d3a9b68ce7a84b1fe5)|Win32 EXE||2013-04-03 02:26:54|igfx.exe|
|[6c145f1ad75de785a75903a4a5d485e8](https://www.virustotal.com/gui/file/6c145f1ad75de785a75903a4a5d485e8)|Win32 EXE|Sisron|2013-03-27 19:42:14|\sonas\share\samples\6c\14\5f\1a\6c145f1ad75de785a75903a4a5d485e8.2b536b2fb1b5cc333b0216045840a37b959b3a46|
|[03823081d5de20d03cf85259ae7ee47c](https://www.virustotal.com/gui/file/03823081d5de20d03cf85259ae7ee47c)|Win32 EXE||2013-03-22 05:46:52|03823081d5de20d03cf85259ae7ee47c|
|[1d87a00f54a16f9c0ee135731296eb58](https://www.virustotal.com/gui/file/1d87a00f54a16f9c0ee135731296eb58)|Win32 EXE||2013-03-18 22:45:04|Bluthmon.exe|
|[4892a108c084f7471b601194957ec431](https://www.virustotal.com/gui/file/4892a108c084f7471b601194957ec431)|Win32 EXE||2013-03-18 09:49:47|Bluthmon.exe|
|[06da906db043f7e8b603490f834716cb](https://www.virustotal.com/gui/file/06da906db043f7e8b603490f834716cb)|Win32 DLL||2013-03-17 23:08:30|ADVPACK32|
|[5699884869d8796ab33416c3af5305a2](https://www.virustotal.com/gui/file/5699884869d8796ab33416c3af5305a2)|Win32 EXE||2013-01-09 01:09:26|Bluthmon.exe|
|[dc2b8aefe8bd08f196ea7a6f0caa2764](https://www.virustotal.com/gui/file/dc2b8aefe8bd08f196ea7a6f0caa2764)|Win32 EXE||2012-12-28 09:25:05|1024-03a0de5a253b58d901ddb131efccf87f8b306071|
|[f77bd5d0d0b85c0fb2f986d952891071](https://www.virustotal.com/gui/file/f77bd5d0d0b85c0fb2f986d952891071)|Win32 EXE|malagent|2012-12-27 04:44:20|Bluthmon.exe|
|[926f008ef342ae1cc138687ff68a424a](https://www.virustotal.com/gui/file/926f008ef342ae1cc138687ff68a424a)|Win32 EXE||2012-12-25 00:45:04|b35283766cd9591a71aeca0b332787147dbba3ca|
|[850dddde6a671a0d41ede1326fa438af](https://www.virustotal.com/gui/file/850dddde6a671a0d41ede1326fa438af)|Win32 DLL||2012-12-07 02:39:00|ADVPACK32|
|[593d2f1113836a49cb27cef3ce699933](https://www.virustotal.com/gui/file/593d2f1113836a49cb27cef3ce699933)|Win32 EXE||2012-11-27 07:22:31|6717ae15807168fdf356ac6ec3db5bb57522d9e7e44f0d31e8307fabb609a1f8.vir|
|[aa86c3fb648c0d210b85f5e96aabc3c5](https://www.virustotal.com/gui/file/aa86c3fb648c0d210b85f5e96aabc3c5)|Win32 DLL||2012-11-16 01:40:59|ADVPACK32|
|[3d341703a981388b3fde70173a172f89](https://www.virustotal.com/gui/file/3d341703a981388b3fde70173a172f89)|Win32 EXE||2012-11-10 23:16:26|drop/3d341703a981388b3fde70173a1|
|[63d453db999cb3a9b388180b7364d43c](https://www.virustotal.com/gui/file/63d453db999cb3a9b388180b7364d43c)|Win32 EXE||2012-11-10 14:28:34|lerovier8|
|[f60de91238d965455629b12694fb9dbc](https://www.virustotal.com/gui/file/f60de91238d965455629b12694fb9dbc)|Win32 EXE||2012-11-02 09:44:13|drop/f60de91238d965455629b12694f|
|[21328d7653dafaf14e15eefd3260568a](https://www.virustotal.com/gui/file/21328d7653dafaf14e15eefd3260568a)|Win32 EXE|TSCookie|2012-10-31 07:44:23|21328d7653dafaf14e15eefd3260568a|
|[6d355a4339f92d6056f2708194213440](https://www.virustotal.com/gui/file/6d355a4339f92d6056f2708194213440)|Win32 EXE||2012-10-24 10:38:03|d32f25e9dde5bbbe95c5cd494ec932a6dc5e2592e7b40c9f8052766eaa4e12ee.vir|
|[3214cdac71fa4313d195eb81eace4db8](https://www.virustotal.com/gui/file/3214cdac71fa4313d195eb81eace4db8)|Win32 EXE||2012-10-13 13:29:10|3214cdac71fa4313d195eb81eace4db8.exe.malware|
|[f8921be180cbc9bbedb63dc07eb8365b](https://www.virustotal.com/gui/file/f8921be180cbc9bbedb63dc07eb8365b)|Win32 DLL||2012-10-09 02:48:16|ADVPACK32|
|[1fe7391ac994bf37d7ccb9c7358c4419](https://www.virustotal.com/gui/file/1fe7391ac994bf37d7ccb9c7358c4419)|Win32 EXE||2012-09-26 14:31:23|1FE7391AC994BF37D7CCB9C7358C4419|
|[65f4245e3e7f80c47c7e5b7aa23c5920](https://www.virustotal.com/gui/file/65f4245e3e7f80c47c7e5b7aa23c5920)|Win32 EXE||2012-09-25 12:52:52|Bluthmon.exe|
|[5694a226f66e3b07aeb188a54304b371](https://www.virustotal.com/gui/file/5694a226f66e3b07aeb188a54304b371)|Win32 EXE|Injecto|2012-09-10 17:17:30|5694a226f66e3b07aeb188a54304b371.exe|
|[34a0be585725b0076e017c8fcb0fc180](https://www.virustotal.com/gui/file/34a0be585725b0076e017c8fcb0fc180)|Win32 EXE|Zbot|2012-08-10 01:06:16|34A0BE585725B0076E017C8FCB0FC180.bin|
|[455aa863278828122b40eb4c29875551](https://www.virustotal.com/gui/file/455aa863278828122b40eb4c29875551)|Win32 EXE|Zbot|2012-07-31 07:36:54|42e469cf8b815faae94fbd49cc91af212d4d8a3a4ef57ca5b8b13e97753e8d1c.vir|
|[c0c78511fe4c39e9f66a43d8536c7390](https://www.virustotal.com/gui/file/c0c78511fe4c39e9f66a43d8536c7390)|Win32 DLL|Zbot|2012-06-29 05:25:12|ADVPACK32|
|[4c4647f35c0583fbb87ce4a7322d6028](https://www.virustotal.com/gui/file/4c4647f35c0583fbb87ce4a7322d6028)|Win32 EXE||2012-06-14 01:41:32|wualctler.exe|
|[e800e6041eee5f288fdfd7ac9df1ec9e](https://www.virustotal.com/gui/file/e800e6041eee5f288fdfd7ac9df1ec9e)|Win32 EXE||2012-06-11 09:54:32|5dc97a61bf0fd09e1471b667b89f1c008fe4f81d837091a4b67ba467d4510d69.vir|
|[b08e0d592f704bd4f9e44c538b37eea4](https://www.virustotal.com/gui/file/b08e0d592f704bd4f9e44c538b37eea4)|Win32 EXE|kazy|2012-06-11 08:27:24|spoolsv.exe|
|[1b90ace1ab9c30382b9347d6131471a8](https://www.virustotal.com/gui/file/1b90ace1ab9c30382b9347d6131471a8)|Win32 EXE|TSCookie|2012-05-23 16:15:25|c303bab9e2655739ee85adf92cc9e9c9b1e4371dddeb9270cbbb81f34f4f96b9.vir|
|[305d1985ba1996b4ca677229eaaf3ffd](https://www.virustotal.com/gui/file/305d1985ba1996b4ca677229eaaf3ffd)|Win32 EXE||2011-08-29 17:12:24|vti-rescan|
|[be3f9dcaa387a26b096acf4ced39ea2f](https://www.virustotal.com/gui/file/be3f9dcaa387a26b096acf4ced39ea2f)|Win32 DLL|Zbot|2011-03-29 05:15:10|ADVPACK32|
|[9be7bb0bcd93d46d9d9665666f217ed1](https://www.virustotal.com/gui/file/9be7bb0bcd93d46d9d9665666f217ed1)|ELF executable||2020-10-20 02:26:41|apached|
|[0fbb54af3585af0a14a3797580b78468](https://www.virustotal.com/gui/file/0fbb54af3585af0a14a3797580b78468)|ELF executable||2020-10-19 09:01:16|sample-5B5F8C4611510C11D413CB2BEF70867E584F003210968F97E0C54E6D37BA8D8D (1).bin|
|[048d188bad124dfe492ba1d77e9ff5ab](https://www.virustotal.com/gui/file/048d188bad124dfe492ba1d77e9ff5ab)|Win32 EXE|Symmi|2020-01-29 04:25:21| |
