**NAME:**  
BlackTech  
  
**Alias**  
PLEAD, Shrouded Crossbow, Waterbear, Radio Panda, BlackTech  
  
**Description**:   
BlackTech is an APT group operating against targets in East Asia, such as Japan and China (Hong Kong, Taiwan). BlackTech’s campaigns are likely designed to steal their target’s technology. There are three associated campaigns: PLEAD, Shrouded Crossbow and Waterbea
  
**References**:  
https://www.welivesecurity.com/2018/07/09/certificates-stolen-taiwanese-tech-companies-plead-malware-campaign/  
https://blog.trendmicro.com/trendlabs-security-intelligence/following-trail-blacktech-cyber-espionage-campaigns/