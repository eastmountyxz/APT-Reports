|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5e64a2834ff4cb089991e9757d766336](https://www.virustotal.com/gui/file/5e64a2834ff4cb089991e9757d766336)|Win32 EXE||2020-04-01 01:14:54|chrome.exe|
|[8c11c4d799f05425fd043f5cae27109c](https://www.virustotal.com/gui/file/8c11c4d799f05425fd043f5cae27109c)|Win32 EXE||2020-03-31 22:46:15|1d9ca05b3d4eef1034991cc4f020852f563e25b541bf5cb40db11b01c49231d1.bin|
|[6dc5f8282df76f4045f75fea3277df41](https://www.virustotal.com/gui/file/6dc5f8282df76f4045f75fea3277df41)|Win32 EXE|Dapato|2020-01-25 00:39:10|%PROGRAMDATA%\intel\intelsyc.exe|
|[d9ce60d3504a5ff8e639ba94c674a4a1](https://www.virustotal.com/gui/file/d9ce60d3504a5ff8e639ba94c674a4a1)|Win32 EXE|Strictor|2019-12-10 01:23:22|chrome.exe|
|[7eb0c103ae21189ad9ad4a9804293b22](https://www.virustotal.com/gui/file/7eb0c103ae21189ad9ad4a9804293b22)|Win32 EXE|Strictor|2019-12-04 15:17:30|chrome.exe|
|[b21af331b1752a70360b5d8dc9013f3f](https://www.virustotal.com/gui/file/b21af331b1752a70360b5d8dc9013f3f)|Win32 EXE|Strictor|2019-12-04 02:54:46|chrome.exe|
|[ed081a869d30bb90b76552c83bd784c8](https://www.virustotal.com/gui/file/ed081a869d30bb90b76552c83bd784c8)|Win32 EXE||2019-11-07 08:49:37|chrome.exe|
|[53cb974caf909eedcd86d2f80e75ad0a](https://www.virustotal.com/gui/file/53cb974caf909eedcd86d2f80e75ad0a)|Win32 EXE||2019-11-02 21:56:37|chrome.exe|
|[ad7a4333bc364df3d4fa00b13cbbbeb4](https://www.virustotal.com/gui/file/ad7a4333bc364df3d4fa00b13cbbbeb4)|Win32 EXE||2019-10-01 16:22:46|2e8a34aa4e887ba413735d3ece7863921eaabdc5a494ff6354fb551f26dc561b.bin|
|[3989ac9efb6a725918bd1810765d30b3](https://www.virustotal.com/gui/file/3989ac9efb6a725918bd1810765d30b3)|Win32 EXE||2019-09-22 12:31:58|1f8bac00e4f611d0feec7255eeb88038460000002a0a0fe7c4ac0ee9a1b9f79c.bin|
|[481dd1a37c86fda68bced0ecb2f47597](https://www.virustotal.com/gui/file/481dd1a37c86fda68bced0ecb2f47597)|Win32 EXE||2019-09-13 00:41:29|c7dae984195717c76a9b221081b9c9a20de8d20b55b68add647ee34685b93fb9.bin|
|[11a16e109dbaf2fd080d8490328de5a1](https://www.virustotal.com/gui/file/11a16e109dbaf2fd080d8490328de5a1)|Win32 EXE||2019-08-14 08:12:57|drive.exe|
|[15b6f83c87679ce08a90c47af24be095](https://www.virustotal.com/gui/file/15b6f83c87679ce08a90c47af24be095)|Win32 EXE||2019-08-07 07:04:01|drive.exe|
|[4ed966921ce01da67aee6b805c944035](https://www.virustotal.com/gui/file/4ed966921ce01da67aee6b805c944035)|Win32 EXE||2019-08-07 02:51:26|fab653516b446cfc5bbb8c5f44dd20006d43101b4afba27a8fc655ba6d2f48b1.bin|
|[527f024ae456775ee5e92924213fe363](https://www.virustotal.com/gui/file/527f024ae456775ee5e92924213fe363)|Win32 EXE||2019-08-01 04:43:21|drive.exe|
|[a66a5def5f1fb03515b4da2ddb263d09](https://www.virustotal.com/gui/file/a66a5def5f1fb03515b4da2ddb263d09)|Win32 EXE||2019-08-01 03:17:51|drive.exe|
|[237ad5f5e95e49b9f209dda4685255f2](https://www.virustotal.com/gui/file/237ad5f5e95e49b9f209dda4685255f2)|Win32 EXE||2019-07-31 22:58:27|56857be1565973640f14e8c0ad0358d80081c94761b92dab21eb212d619c7737.bin|
|[11294e27491b496e36ca7db9f363adcd](https://www.virustotal.com/gui/file/11294e27491b496e36ca7db9f363adcd)|Win32 EXE||2019-07-30 10:43:17|c5ddd77d147246d53684d9eb5bd5b6734af12e2f790847b73b7ed716dce407b4.bin|
|[154fb76435897c46d7089c3eac43bd48](https://www.virustotal.com/gui/file/154fb76435897c46d7089c3eac43bd48)|Win32 EXE|occamy|2018-12-29 16:42:17|UDPDownloader.exe|
|[2a4b875fd9c2f77b2c4271eaaa210921](https://www.virustotal.com/gui/file/2a4b875fd9c2f77b2c4271eaaa210921)|Win32 EXE|occamy|2018-12-28 18:33:38|e026cb5d1f6472ff56648cb3e48257ef449713d6331023ae1f3b29863a4680a4.bin|
|[30ebc096037ba8629bde89119f75829a](https://www.virustotal.com/gui/file/30ebc096037ba8629bde89119f75829a)|Win32 EXE|occamy|2018-12-28 18:33:35|./KISA_dataset_2020_train/ad505cbc942a0a0b71f2bc2508250464c648b436cf2c762899e385971c955519.vir|
|[0be3b12918ad10638c8b1b6fb2ae3bd8](https://www.virustotal.com/gui/file/0be3b12918ad10638c8b1b6fb2ae3bd8)|Win32 EXE||2018-12-28 18:33:34|818680|
