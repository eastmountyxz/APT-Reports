**NAME:**  
Storm Cloud
 

**Description**:   
According to Volexity, the Storm Cloud has been observed targeting Tibetan organizations since at least 2018 and may share the same background with Holy water targeted attacks uncovered by Kaspersky.

  
**References**:  
https://www.volexity.com/blog/2020/03/31/storm-cloud-unleashed-tibetan-community-focus-of-highly-targeted-fake-flash-campaign/