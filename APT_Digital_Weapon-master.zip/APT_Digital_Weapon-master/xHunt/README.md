**NAME:**  
xHunt  
  
**Alias**  
SectorD01, xHunt  

**Description**:   
xHunt, uncovered by PaloAlto, is an attack campaign on Kuwait shipping and transportation organizations. The names of the tools collected include backdoor tools Sakabota, Hisoka, Netero and Killua. These tools not only use HTTP for their command and control (C2) channels, but some use DNS tunneling or emails to communicate with their C2 as well.
  
**References**:  
https://unit42.paloaltonetworks.com/xhunt-campaign-attacks-on-kuwait-shipping-and-transportation-organizations/