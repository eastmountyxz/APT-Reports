**NAME:**  
GlassRAT  
  
**Probably operating from**:  
  
**Description**:   
  
**References**:  
