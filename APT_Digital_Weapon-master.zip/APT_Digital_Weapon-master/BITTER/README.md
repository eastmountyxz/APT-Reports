**NAME:**  
BITTER  
  
**Alias**  
蔓灵花  

**Description**:  
The BITTER attack began in November 2013 while without being observed for many years. The attackers could compromise Windows and Android platform but their background is not yet clear.
The first sample appeared in November 2013, and many of the rest are compile from July 2015 to September 2016. Samples targeting Chinese victims are compiled from May to September 2016. Related network activities are concentrated in September and C2s are still alive.
The QiAnXin Threat Intelligence Center subsequently discovered that the attack group utilized the InPage vulnerability and pointed out the relationship to Confucius and APT-C-09.

**References**:  
https://www.anomali.com/blog/suspected-bitter-apt-continues-targeting-government-of-china-and-chinese-organizations
