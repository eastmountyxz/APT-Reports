|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[362e677b331813d8a947992e86ef4e6d](https://www.virustotal.com/gui/file/362e677b331813d8a947992e86ef4e6d)|Win32 EXE||2019-12-17 10:22:24|document.docx.scr|
|[31bcb31b2125297c08ddebaadd3479c3](https://www.virustotal.com/gui/file/31bcb31b2125297c08ddebaadd3479c3)|JPEG||2019-11-29 09:22:20|kipr.jpg|
|[06ae12974694b6bbbade3097ee25afff](https://www.virustotal.com/gui/file/06ae12974694b6bbbade3097ee25afff)|Win32 DLL||2019-11-28 15:15:18|skydriveshell64.bin|
|[707b75d6c9eb5eae30b10f6353ecab4d](https://www.virustotal.com/gui/file/707b75d6c9eb5eae30b10f6353ecab4d)|Win32 EXE||2019-11-28 15:15:10|X098765432198.bin|
|[78441abdff82636f9527d22ac0109be7](https://www.virustotal.com/gui/file/78441abdff82636f9527d22ac0109be7)|RTF||2019-11-28 10:54:36|update|
|[a0dcbd63716b264f868cd38d7c4b494d](https://www.virustotal.com/gui/file/a0dcbd63716b264f868cd38d7c4b494d)|DOCX||2019-11-28 08:45:44|LIST_OF_ALL__COMMERCIAL_COUNSELLORS_AT_MISSIONS_ABROAD.docx|
|[3c25a6f5e2b047214afb4c907f10cd47](https://www.virustotal.com/gui/file/3c25a6f5e2b047214afb4c907f10cd47)|Win32 EXE||2019-11-07 06:20:04|g.txt|
|[02dd4a91651b0ddade7f32d040a27ed0](https://www.virustotal.com/gui/file/02dd4a91651b0ddade7f32d040a27ed0)|DOCX||2019-11-07 05:48:48|E-passport record.docx|
|[e421808b24c1ebd4cf0a078c6e66ded8](https://www.virustotal.com/gui/file/e421808b24c1ebd4cf0a078c6e66ded8)|Win32 EXE||2019-10-28 20:21:39|servicce.exe|
|[49b9a0fdf026019b76df0f03722b0d88](https://www.virustotal.com/gui/file/49b9a0fdf026019b76df0f03722b0d88)|Win32 EXE||2019-10-28 20:19:58|MSAService.exe|
|[79a1e1d2ea5c629f60ef00a96ec4d0fe](https://www.virustotal.com/gui/file/79a1e1d2ea5c629f60ef00a96ec4d0fe)|Win32 EXE||2019-10-28 20:17:47|onedriveManager|
|[11864ec73e6226f52a1e6e4074b33e89](https://www.virustotal.com/gui/file/11864ec73e6226f52a1e6e4074b33e89)|Win32 EXE||2019-10-15 08:39:33|65f95dc2a18a66bdd04868f1e9b86e569aeb8306eed5f2af9bc6f92c356db7fb.bin|
|[44e936f5f02fa3fdf5925ba9fbd486e5](https://www.virustotal.com/gui/file/44e936f5f02fa3fdf5925ba9fbd486e5)|Win32 EXE||2019-10-15 08:38:46|e63ea0b7e7eb61f09344de7112cc73ccab2c8a07cc8b43bb26ae2fe4dd2e7592.bin|
|[d884f6d37c0202935db1a54c7f0a79ed](https://www.virustotal.com/gui/file/d884f6d37c0202935db1a54c7f0a79ed)|Win32 EXE||2019-10-15 08:37:58|6daa922a43d7d062dd0fd8dd4bebeeb7a14b938a2e93962226f3cec4d66f1b94.bin|
|[31a36d4a30668a8743193e788cb2aa2b](https://www.virustotal.com/gui/file/31a36d4a30668a8743193e788cb2aa2b)|FPX||2019-10-15 03:12:47|audio.msi|
|[c87641a13843682ae16a5da18ffee654](https://www.virustotal.com/gui/file/c87641a13843682ae16a5da18ffee654)|Win32 EXE||2019-10-13 07:38:29|engineblock-2.jpg                                                                                                                                           .exe|
|[d8c76c736a3285378bc82ea9cd3c972d](https://www.virustotal.com/gui/file/d8c76c736a3285378bc82ea9cd3c972d)|Win32 EXE||2019-10-12 21:51:52|b8de51def4498908426b71e358538626ec2a1682e6c67a17e18054a3aa1a423b.bin|
|[a24d5a8f6a916fe976face1f145cf297](https://www.virustotal.com/gui/file/a24d5a8f6a916fe976face1f145cf297)|Win32 EXE||2019-10-12 17:44:35|MSAService.exe|
|[4bfff2480fb6eaa0ef82abb0092c2586](https://www.virustotal.com/gui/file/4bfff2480fb6eaa0ef82abb0092c2586)|Win32 EXE||2019-10-10 07:58:51|9319421ff52d7ea4cca08d1cc7064f9ed5b19ee19dbdde182a0e51325632df88.bin|
|[fbc56c2dadab05e78c995f57bf50bce5](https://www.virustotal.com/gui/file/fbc56c2dadab05e78c995f57bf50bce5)|FPX||2019-10-04 21:44:35|ausetup.msi|
|[385669b61ed72a379ff53e5e48f20515](https://www.virustotal.com/gui/file/385669b61ed72a379ff53e5e48f20515)|Win32 EXE||2019-09-24 12:22:05|MSAService.exe|
|[46ef2c0db107b794516dc2b2622e44ad](https://www.virustotal.com/gui/file/46ef2c0db107b794516dc2b2622e44ad)|Win32 EXE||2019-09-24 12:19:40|audiodq.exe|
|[c831af87ab876bd774784eb8f3338b4b](https://www.virustotal.com/gui/file/c831af87ab876bd774784eb8f3338b4b)|Win32 EXE||2019-09-19 18:53:25|lsap|
|[4b0e5c5c4e0e22f2dfeef0531e021072](https://www.virustotal.com/gui/file/4b0e5c5c4e0e22f2dfeef0531e021072)|Win32 EXE|keylogger|2019-09-09 09:31:50|igfxsrvk|
|[fc572eec5ae8b38428259c5d8fc5a05f](https://www.virustotal.com/gui/file/fc572eec5ae8b38428259c5d8fc5a05f)|Win32 EXE||2019-09-09 07:47:14| |
|[8831eac19d1a1c30697057fa501d063f](https://www.virustotal.com/gui/file/8831eac19d1a1c30697057fa501d063f)|Win32 EXE||2019-09-08 15:26:47|e43996356b7533eb2d576c6a7ccae1ad7c13293a34d4e1aad44239f1f53da323.bin|
|[b5c66d01d0e96b04702030ed23add415](https://www.virustotal.com/gui/file/b5c66d01d0e96b04702030ed23add415)|Win32 EXE||2019-09-07 20:26:42|b5c66d01d0e96b04702030ed23add415.virus|
|[226d33f02acb6b8d0a1b9ecf4f7a1752](https://www.virustotal.com/gui/file/226d33f02acb6b8d0a1b9ecf4f7a1752)|DOCX|CVE-2018-0802|2019-09-06 19:50:45| |
|[69ae79eb16251f16c3512adf7926cc7f](https://www.virustotal.com/gui/file/69ae79eb16251f16c3512adf7926cc7f)|DOCX|CVE-2018-0802|2019-09-05 06:32:12|error.docx|
|[9e2de3e2fecd8c1df5d3f857012fab59](https://www.virustotal.com/gui/file/9e2de3e2fecd8c1df5d3f857012fab59)|Win32 EXE||2019-09-05 04:22:01|audiodq.exe|
|[60be2c5fc67acfdfc82d31cb92cae369](https://www.virustotal.com/gui/file/60be2c5fc67acfdfc82d31cb92cae369)|Win32 EXE||2019-09-04 12:31:42|wcmc|
|[596ec0f90c25fdbe3d8ade3f4ea4cd38](https://www.virustotal.com/gui/file/596ec0f90c25fdbe3d8ade3f4ea4cd38)|Win32 EXE||2019-09-04 12:31:07|ctf|
|[05c680cedd27d794aeeca41d4aa9b390](https://www.virustotal.com/gui/file/05c680cedd27d794aeeca41d4aa9b390)|Win32 EXE||2019-09-04 12:26:47|wcmc|
|[314c251ea0f92ec66905225b1825b945](https://www.virustotal.com/gui/file/314c251ea0f92ec66905225b1825b945)|Win32 EXE||2019-09-04 12:21:37|wcmc|
|[165733a5d931691480df1fb6baa70080](https://www.virustotal.com/gui/file/165733a5d931691480df1fb6baa70080)|Win32 EXE||2019-09-04 12:21:33|lsap|
|[ee5cce5261ea94cd6bd82f7453f88a68](https://www.virustotal.com/gui/file/ee5cce5261ea94cd6bd82f7453f88a68)|Win32 EXE||2019-09-04 12:21:24|lsap|
|[eff53665630785e3e9541ddaa93b6240](https://www.virustotal.com/gui/file/eff53665630785e3e9541ddaa93b6240)|Win32 EXE||2019-09-04 12:20:50|wcmc|
|[07bcf640143a378d5e8fdda25cfa74ec](https://www.virustotal.com/gui/file/07bcf640143a378d5e8fdda25cfa74ec)|Win32 EXE||2019-09-04 08:40:02|=?UTF-8?B?5Lit5Zu95paw55qE5a+55aSW5a6J5YWo5pS/562WLmRvY3ggICAgICAgICAgICAuZXhl?=|
|[5de9bea650eeb7956ba41a5bef1d3bb2](https://www.virustotal.com/gui/file/5de9bea650eeb7956ba41a5bef1d3bb2)|Win32 EXE|Ursu|2019-09-04 08:32:13|2019 Seminar.doc                                                                                  .exe|
|[81e2ba41f51e153e4aa9978ec21eb49d](https://www.virustotal.com/gui/file/81e2ba41f51e153e4aa9978ec21eb49d)|DOCX||2019-09-02 05:50:22|SCAN006.docx|
|[3267e32c9388e9d09ead4a30a692469e](https://www.virustotal.com/gui/file/3267e32c9388e9d09ead4a30a692469e)|TXT|CVE-2018-0802|2019-08-24 02:49:58|wehsd|
|[73c297f059dd94671ca4e4c7dbfa6241](https://www.virustotal.com/gui/file/73c297f059dd94671ca4e4c7dbfa6241)|Win32 EXE||2019-08-23 12:23:48|wehs|
|[b4d2587e96b40e440d808be42b2a9842](https://www.virustotal.com/gui/file/b4d2587e96b40e440d808be42b2a9842)|Android||2019-08-23 07:35:44|AnsarFoundation.apk|
|[02c2a68ce9a35f5f0e1b3456e09d6cc9](https://www.virustotal.com/gui/file/02c2a68ce9a35f5f0e1b3456e09d6cc9)|DOCX|CVE-2018-0802|2019-08-23 04:32:08|Urgent Action.docx|
|[6d918c08f971dbb058da414df1611010](https://www.virustotal.com/gui/file/6d918c08f971dbb058da414df1611010)|Android||2019-08-08 04:07:35|IMGY00415.apk|
|[4248532827dbf4f444e342cb9179a786](https://www.virustotal.com/gui/file/4248532827dbf4f444e342cb9179a786)|Win32 EXE||2019-08-05 12:52:37|FontCache Notify Tool|
|[6ec5738b2661042055ee55afd67a2838](https://www.virustotal.com/gui/file/6ec5738b2661042055ee55afd67a2838)|Rich Text Format|CVE-2017-11882|2019-08-05 11:56:56|pq|
|[eec2828cb4a9032ab1177bb472f1977b](https://www.virustotal.com/gui/file/eec2828cb4a9032ab1177bb472f1977b)|Win32 EXE||2019-08-01 11:58:07|lsasw|
|[d8b2cd8ebb8272fcc8ddac8da7e48e01](https://www.virustotal.com/gui/file/d8b2cd8ebb8272fcc8ddac8da7e48e01)|Win32 EXE||2019-07-27 17:22:14| |
|[e10f3172489811ed3ba6f53edce91851](https://www.virustotal.com/gui/file/e10f3172489811ed3ba6f53edce91851)|Win32 EXE|johnnie|2019-07-20 17:11:06|winlog.exe|
|[1d2e23effc225880cadb7ee56dff25cf](https://www.virustotal.com/gui/file/1d2e23effc225880cadb7ee56dff25cf)|Android|androidos|2019-07-16 11:32:19|P-Hub Premium.apk|
|[d6a5e6b77914db9a161037f796bb90e2](https://www.virustotal.com/gui/file/d6a5e6b77914db9a161037f796bb90e2)|Win32 EXE||2019-07-03 05:55:17|5dd080b9ad4bc5c58c0ced31829ccada.ex_|
|[ccb18f9c47636134e3483dc86369204a](https://www.virustotal.com/gui/file/ccb18f9c47636134e3483dc86369204a)|Win32 EXE||2019-07-03 04:00:55|14197b5d1cc4789edabe976a844cd98a1464bae1cf0899e2f7ae7657f67d085b.sample|
|[303f01e8ce9488ca7c1b265a8768cce0](https://www.virustotal.com/gui/file/303f01e8ce9488ca7c1b265a8768cce0)|FPX||2019-07-02 10:59:17|Court_Notice.inp|
|[5dd080b9ad4bc5c58c0ced31829ccada](https://www.virustotal.com/gui/file/5dd080b9ad4bc5c58c0ced31829ccada)|FPX||2019-07-02 10:58:58|Press_Note.inp|
|[ae02f2f8100de5f9f155f4b8ce3e494e](https://www.virustotal.com/gui/file/ae02f2f8100de5f9f155f4b8ce3e494e)|Win32 EXE||2019-05-29 08:37:45|lsap|
|[ca31368f3cb82161db4f062554c9995b](https://www.virustotal.com/gui/file/ca31368f3cb82161db4f062554c9995b)|Win32 EXE||2019-05-16 20:37:04|ca31368f3cb82161db4f062554c9995b.virus|
|[72eb6896fa9326f38d3745cc442611dc](https://www.virustotal.com/gui/file/72eb6896fa9326f38d3745cc442611dc)|Win32 EXE||2019-05-15 20:57:27|bed4d6bdf25808e5d3f8bcb42ae24de873417a1f5553e2a9df92fbee2c77da37.bin|
|[9a55c9aaaf1959be364519c4810de4c5](https://www.virustotal.com/gui/file/9a55c9aaaf1959be364519c4810de4c5)|FPX||2019-05-03 10:43:09|staff training  Dte .inp|
|[4d2a11bbed6711be3dcc9e3988645e10](https://www.virustotal.com/gui/file/4d2a11bbed6711be3dcc9e3988645e10)|Win32 EXE||2019-04-12 20:40:16|myfile.exe|
|[07fb2d3eff044e40f8115a1398c92266](https://www.virustotal.com/gui/file/07fb2d3eff044e40f8115a1398c92266)|Win32 EXE|johnnie|2019-04-01 05:03:15|winevc|
|[6bb5614223a21db411b1cb3ed29465f5](https://www.virustotal.com/gui/file/6bb5614223a21db411b1cb3ed29465f5)|Win32 EXE|Ursu|2019-03-19 10:14:54|audiodq.exe|
|[8c4e65d14b69a8403ec7847438f6842b](https://www.virustotal.com/gui/file/8c4e65d14b69a8403ec7847438f6842b)|Win32 EXE||2019-03-19 06:36:33|=?UTF-8?B?56eY5a+G5paH5Lu2X19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fLjExMQ==?=|
|[86e3e98c1e69f887e23d119d0d30d51c](https://www.virustotal.com/gui/file/86e3e98c1e69f887e23d119d0d30d51c)|Win32 DLL||2019-02-10 01:49:24|c:\programdata\mso\olmapi32.dll|
|[0e6b00a6e09a94a3f30b5a527db51ac1](https://www.virustotal.com/gui/file/0e6b00a6e09a94a3f30b5a527db51ac1)|Win32 EXE||2019-02-01 09:26:16|lsap.exe|
|[3dcc9ac06cd5318f247be0d73c8c1d1d](https://www.virustotal.com/gui/file/3dcc9ac06cd5318f247be0d73c8c1d1d)|Win32 EXE||2019-01-18 18:25:53|Windows Application Services|
|[3452b13832585c2cf9dcb5fdb4ac3fc3](https://www.virustotal.com/gui/file/3452b13832585c2cf9dcb5fdb4ac3fc3)|Win32 EXE||2019-01-18 04:38:03|audiodq.exe|
|[5d8b4fae792e009e8be4d3f2cab38de0](https://www.virustotal.com/gui/file/5d8b4fae792e009e8be4d3f2cab38de0)|Win32 EXE||2019-01-13 05:31:22|CTFmon|
|[feb46b161275f0b89f1f1da2cca93084](https://www.virustotal.com/gui/file/feb46b161275f0b89f1f1da2cca93084)|Win32 EXE||2019-01-12 17:40:31|winprt|
|[46234ad73c6d2c1a24cd9eabee1c718e](https://www.virustotal.com/gui/file/46234ad73c6d2c1a24cd9eabee1c718e)|Win32 EXE||2019-01-12 15:56:52|winprt|
|[158bacf0610c761563a55385b0dfd0bd](https://www.virustotal.com/gui/file/158bacf0610c761563a55385b0dfd0bd)|Win32 EXE||2019-01-12 15:26:00|winprt|
|[8d42c01180be7588a2a68ad96dd0cf85](https://www.virustotal.com/gui/file/8d42c01180be7588a2a68ad96dd0cf85)|Win32 EXE|Ursu|2019-01-08 09:28:42|winprt|
|[53d6ed9a3e56785ccbee9b73b14ec62c](https://www.virustotal.com/gui/file/53d6ed9a3e56785ccbee9b73b14ec62c)|Win32 EXE|occamy|2019-01-04 14:17:46|winsvc.exe|
|[a098d91f04eb259bf27432e81a9c523b](https://www.virustotal.com/gui/file/a098d91f04eb259bf27432e81a9c523b)|Win32 EXE||2019-01-02 17:33:37|Windows Application Services|
|[e4abdd40f7d1adb3f139940438484695](https://www.virustotal.com/gui/file/e4abdd40f7d1adb3f139940438484695)|TXT|CVE-2018-0802|2019-01-02 06:41:54|article_amy.doc|
|[fc516905e3237f1aa03a38a0dde84b52](https://www.virustotal.com/gui/file/fc516905e3237f1aa03a38a0dde84b52)|Win32 EXE||2018-12-25 02:45:01|winsvc.exe|
|[1c2a3aa370660b3ac2bf0f41c342373b](https://www.virustotal.com/gui/file/1c2a3aa370660b3ac2bf0f41c342373b)|Win32 EXE||2018-12-23 11:04:28|winsvc.exe|
|[7cc0b212d1b8ceb808c250495d83bae4](https://www.virustotal.com/gui/file/7cc0b212d1b8ceb808c250495d83bae4)|Win32 EXE||2018-12-18 18:32:33|CTFmon|
|[488f39e81fa6ab497062631595da2bb8](https://www.virustotal.com/gui/file/488f39e81fa6ab497062631595da2bb8)|Rich Text Format|CVE-2018-0802|2018-12-18 07:12:35|cocktail and the dinner in last week of dec.doc|
|[5fb3f028542a2e61313d64d8e8f87c01](https://www.virustotal.com/gui/file/5fb3f028542a2e61313d64d8e8f87c01)|Win32 EXE||2018-12-06 08:26:44|winprt|
|[694040b229562b8dca9534c5301f8d73](https://www.virustotal.com/gui/file/694040b229562b8dca9534c5301f8d73)|Win32 EXE|razy|2018-11-26 17:42:41|smtpldr|
|[227c0d4cfad228b0421f3c04bfed9a28](https://www.virustotal.com/gui/file/227c0d4cfad228b0421f3c04bfed9a28)|Win32 EXE|Ursu|2018-11-20 21:07:56|winprt|
|[b694f3b1ef7ff302c339a51c3f0f50f3](https://www.virustotal.com/gui/file/b694f3b1ef7ff302c339a51c3f0f50f3)|Win32 EXE||2018-11-20 00:17:24|Taskhost.exe|
|[f099cd511e9d10d80105d96f29dd28b7](https://www.virustotal.com/gui/file/f099cd511e9d10d80105d96f29dd28b7)|Win32 EXE|dapato|2018-11-16 03:14:13|lsms.exe|
|[26d175ac27b4554885b5c3d2ec9c6769](https://www.virustotal.com/gui/file/26d175ac27b4554885b5c3d2ec9c6769)|Win32 EXE||2018-11-07 17:23:52|wusa.exe|
|[f9aeac76f92f8b2ddc253b3f53248c1d](https://www.virustotal.com/gui/file/f9aeac76f92f8b2ddc253b3f53248c1d)|Win32 EXE|Ursu|2018-11-07 17:19:38|winprt|
|[aa2ed003ae8a2ccaa999aad38898d060](https://www.virustotal.com/gui/file/aa2ed003ae8a2ccaa999aad38898d060)|TXT|CVE-2018-0802|2018-11-06 17:46:39|598df34f07951cae93432e9f848ecd78e88bba1122a81a8f680a81843373b125.bin|
|[a1bdb1889d960e424920e57366662a59](https://www.virustotal.com/gui/file/a1bdb1889d960e424920e57366662a59)|Win32 EXE||2018-11-05 18:09:07|C:\intel\logs\audiodq.exe|
|[be171b4df9b7db48c67f31c678421bfd](https://www.virustotal.com/gui/file/be171b4df9b7db48c67f31c678421bfd)|Win32 EXE||2018-11-05 13:48:07|regdl|
|[23a8ce358b16128f1ca291a284c0f6ef](https://www.virustotal.com/gui/file/23a8ce358b16128f1ca291a284c0f6ef)|Win32 EXE||2018-11-05 08:39:31|Draft Review of the Agreement.exe|
|[74aeaeaca968ff69139b2e2c84dc6fa6](https://www.virustotal.com/gui/file/74aeaeaca968ff69139b2e2c84dc6fa6)|FPX||2018-11-02 05:32:15| |
|[3205a122930f1c60636cbc5efae29863](https://www.virustotal.com/gui/file/3205a122930f1c60636cbc5efae29863)|Win32 EXE||2018-10-25 02:46:36|winsvc.exe|
|[c3f5add704f2c540f3dd345f853e2d84](https://www.virustotal.com/gui/file/c3f5add704f2c540f3dd345f853e2d84)|Win32 EXE||2018-09-26 11:12:48|winprt|
|[61a107fee55e13e67a1f6cbc9183d0a4](https://www.virustotal.com/gui/file/61a107fee55e13e67a1f6cbc9183d0a4)|RTF|CVE-2017-11882|2018-09-26 10:27:53|SOP for Retrieval of Mobile Data Records.doc|
|[863f2bfed6e8e1b8b4516e328c8ba41b](https://www.virustotal.com/gui/file/863f2bfed6e8e1b8b4516e328c8ba41b)|FPX||2018-09-26 10:17:58|SOP for Retrieval of Mobile Data Records.inp|
|[d428d8d696f6043d1b7c3551bde76a88](https://www.virustotal.com/gui/file/d428d8d696f6043d1b7c3551bde76a88)|Win32 EXE|occamy|2018-09-18 19:53:58|winsvc.exe|
|[8dda6f85f06b5952beaabbfea9e28cdd](https://www.virustotal.com/gui/file/8dda6f85f06b5952beaabbfea9e28cdd)|Win32 EXE||2018-09-13 04:33:42|winprt|
|[4f9ef6f18e4c641621f4581a5989284c](https://www.virustotal.com/gui/file/4f9ef6f18e4c641621f4581a5989284c)|Win32 DLL|Andromeda|2018-08-15 15:28:35|705487b3deaf5f2ffa3240208044015e836cf4b32ef817154e23cb9f5859993f.bin|
|[ce2a6437a308dfe777dec42eec39d9ea](https://www.virustotal.com/gui/file/ce2a6437a308dfe777dec42eec39d9ea)|FPX||2018-07-20 10:48:09|7ef9b59cb57193fb62039602596723189fcdb5986590ca4e55edb1d0034f2faf.bin|
|[82ae76f208bd4af3e3b015ef438b41c9](https://www.virustotal.com/gui/file/82ae76f208bd4af3e3b015ef438b41c9)|Win32 EXE||2018-06-14 22:12:54|ctftool.exe|
|[4e2f667ec58b0bf00294bde765fc5f55](https://www.virustotal.com/gui/file/4e2f667ec58b0bf00294bde765fc5f55)|Win32 EXE||2018-06-14 14:19:23|ctftool.exe|
|[c02a0f4d81ef6a144810671e957e930b](https://www.virustotal.com/gui/file/c02a0f4d81ef6a144810671e957e930b)|Rich Text Format|CVE-2017-11882|2018-06-13 04:35:36|Live_agree.doc|
|[38ba17b9ae3a4a4733d716c2ecade70d](https://www.virustotal.com/gui/file/38ba17b9ae3a4a4733d716c2ecade70d)|Win32 EXE||2018-06-09 04:42:31|igfxserv|
|[afed882f6af66810d7637ebcd8287ddc](https://www.virustotal.com/gui/file/afed882f6af66810d7637ebcd8287ddc)|Win32 DLL|razy|2018-05-30 15:17:19|ripped.ex|
|[a3349c8be3fa567b1894dd8c9bfd9695](https://www.virustotal.com/gui/file/a3349c8be3fa567b1894dd8c9bfd9695)|Win32 EXE||2018-05-15 08:50:57|/home/virustotal/sample/A3349C8BE3FA567B1894DD8C9BFD9695|
|[4cbfd989a44cf8f1a0025bbd07069d19](https://www.virustotal.com/gui/file/4cbfd989a44cf8f1a0025bbd07069d19)|Win32 EXE|scar|2018-05-15 06:17:45|winlog|
|[7195c706fab11b258c769649c7e4cce0](https://www.virustotal.com/gui/file/7195c706fab11b258c769649c7e4cce0)|Win32 EXE||2018-05-06 10:39:52|audiodq.exe|
|[9ce5bad6578431f7fff51d00fdc30b14](https://www.virustotal.com/gui/file/9ce5bad6578431f7fff51d00fdc30b14)|Win32 EXE||2018-05-03 11:08:50|toolsd.exe|
|[fd42d02ea05af684c7523d5d5719e55c](https://www.virustotal.com/gui/file/fd42d02ea05af684c7523d5d5719e55c)|Win32 EXE||2018-04-26 12:06:35|audiodq.exe|
|[62bb4224d8e8ec5c3495090b09b52e1c](https://www.virustotal.com/gui/file/62bb4224d8e8ec5c3495090b09b52e1c)|Win32 EXE||2018-04-25 12:52:19| |
|[ef8b828e2d2e7e0f2fc22f15db9d9f30](https://www.virustotal.com/gui/file/ef8b828e2d2e7e0f2fc22f15db9d9f30)|Win32 EXE||2018-04-08 02:59:36|ef8b828e2d2e7e0f2fc22f15db9d9f30.virobj|
|[9d5be49ad857e5d5fcea6c897d72bc25](https://www.virustotal.com/gui/file/9d5be49ad857e5d5fcea6c897d72bc25)|Win32 EXE||2018-02-16 04:44:16|myfile.exe|
|[25689fc7581840e851c3140aa8c3ac8b](https://www.virustotal.com/gui/file/25689fc7581840e851c3140aa8c3ac8b)|Win32 EXE||2018-02-02 15:50:02|winprt|
|[1b5439d7e32c0e8cfca5597fb1458844](https://www.virustotal.com/gui/file/1b5439d7e32c0e8cfca5597fb1458844)|Win32 EXE||2018-01-25 04:16:40|/home/virustotal/sample/1B5439D7E32C0E8CFCA5597FB1458844|
|[d8a99cbb5f362410cada141183656d98](https://www.virustotal.com/gui/file/d8a99cbb5f362410cada141183656d98)|Win32 EXE||2018-01-23 18:17:50|/home/virustotal/sample/D8A99CBB5F362410CADA141183656D98|
|[f98676a090d4c3999127077b1650d25c](https://www.virustotal.com/gui/file/f98676a090d4c3999127077b1650d25c)|Win32 EXE||2018-01-23 09:58:12|/home/virustotal/sample/F98676A090D4C3999127077B1650D25C|
|[a57c1e4d6c0b040337fa110b8ec4345b](https://www.virustotal.com/gui/file/a57c1e4d6c0b040337fa110b8ec4345b)|Win32 EXE||2018-01-21 22:33:49|/home/virustotal/sample/A57C1E4D6C0B040337FA110B8EC4345B|
|[534b2aa8d65bdc16cd6ad6a36f11d13b](https://www.virustotal.com/gui/file/534b2aa8d65bdc16cd6ad6a36f11d13b)|Win32 EXE||2018-01-18 05:35:46|/home/virustotal/sample/534B2AA8D65BDC16CD6AD6A36F11D13B|
|[3574f71132f123136aa2c4808d9c8540](https://www.virustotal.com/gui/file/3574f71132f123136aa2c4808d9c8540)|Win32 EXE||2018-01-18 05:34:26|3574f71132f123136aa2c4808d9c8540.virobj|
|[c838173e082861089416b5e37244efb9](https://www.virustotal.com/gui/file/c838173e082861089416b5e37244efb9)|Win32 EXE||2018-01-17 19:36:04|/home/virustotal/sample/C838173E082861089416B5E37244EFB9|
|[3c4bed8d649375050dba3a3a8df87d12](https://www.virustotal.com/gui/file/3c4bed8d649375050dba3a3a8df87d12)|Win32 EXE||2018-01-15 21:12:26|igfxsrv|
|[adb46f52791b5e3ba26256daf3936dc8](https://www.virustotal.com/gui/file/adb46f52791b5e3ba26256daf3936dc8)|Win32 EXE||2018-01-15 21:12:14|df541e3783e86d2eacd97512ea291e434865d7df|
|[e152b5b7e9079f689ebaaa9b8fe2ed66](https://www.virustotal.com/gui/file/e152b5b7e9079f689ebaaa9b8fe2ed66)|RTF|CVE-2017-11882|2018-01-07 09:28:57|NamesOfMaldiviansReturning.doc|
|[5a0ebd1e74694b262e08041c27414b1d](https://www.virustotal.com/gui/file/5a0ebd1e74694b262e08041c27414b1d)|Win32 EXE||2018-01-03 05:26:46|wcmc|
|[84c96f8dd42d79679ce1e5dee643c58b](https://www.virustotal.com/gui/file/84c96f8dd42d79679ce1e5dee643c58b)|Win32 EXE|johnnie|2018-01-02 05:21:58|igfxsrv|
|[68a1ca909e2fa34b5ffe42fa62312766](https://www.virustotal.com/gui/file/68a1ca909e2fa34b5ffe42fa62312766)|Win32 EXE||2017-12-27 02:51:24|winlog|
|[3b0611a0c55364a6460c019b3e278cbf](https://www.virustotal.com/gui/file/3b0611a0c55364a6460c019b3e278cbf)|Win32 EXE|Athena|2017-12-01 05:03:17|wills|
|[8de8b89d053e17eb0fd003528b91c20f](https://www.virustotal.com/gui/file/8de8b89d053e17eb0fd003528b91c20f)|RTF|CVE-2012-0158|2017-11-30 09:04:16|Railway Cooperation.doc|
|[efec7464f07633415cbc36a97b900587](https://www.virustotal.com/gui/file/efec7464f07633415cbc36a97b900587)|Win32 EXE||2017-11-22 07:49:12|igfxsrv|
|[cc58dd8592555ff6275196e62af3242e](https://www.virustotal.com/gui/file/cc58dd8592555ff6275196e62af3242e)|Win32 EXE||2017-11-22 04:52:30|myfile.exe|
|[e39629316b4bf049fc9704dd00e41b6a](https://www.virustotal.com/gui/file/e39629316b4bf049fc9704dd00e41b6a)|RTF|CVE-2012-0158|2017-11-21 07:17:14|/home/virustotal/sample/E39629316B4BF049FC9704DD00E41B6A|
|[e402c05ce9c46c0cf2f4e3db6f0ba4b5](https://www.virustotal.com/gui/file/e402c05ce9c46c0cf2f4e3db6f0ba4b5)|Win32 EXE|Zbot|2017-11-16 07:01:49|15Mar201|
|[fec0ca2056d679a63ca18cb132223332](https://www.virustotal.com/gui/file/fec0ca2056d679a63ca18cb132223332)|Win32 EXE|Delf|2017-11-03 10:22:00|fec0ca2056d679a63ca18cb132223332_tRbcrUKvpBM.Exe|
|[386f8503a69ca2e69a4f44b538855b05](https://www.virustotal.com/gui/file/386f8503a69ca2e69a4f44b538855b05)|Win32 EXE||2017-11-03 09:50:02|1024-12cdc34081200a2dd14864ddb27a370208802d4c|
|[ae5f389be9058c241a237965304d7bf5](https://www.virustotal.com/gui/file/ae5f389be9058c241a237965304d7bf5)|Win32 EXE||2017-10-26 10:44:22|Insight|
|[525105d4f6904d567a98fac2eb25873e](https://www.virustotal.com/gui/file/525105d4f6904d567a98fac2eb25873e)|Win32 EXE|keylogger|2017-10-12 08:01:15|igfxsrv|
|[6a3f0de81242e55a35571a6a231c5b2c](https://www.virustotal.com/gui/file/6a3f0de81242e55a35571a6a231c5b2c)|Win32 EXE||2017-10-04 10:10:40|D:/working_board/dataset/unused/malware/vir_VT/20171012/6a3f0de81242e55a35571a6a231c5b2c.vir|
|[5b942290149f5666ddfb1e2dd81a03ea](https://www.virustotal.com/gui/file/5b942290149f5666ddfb1e2dd81a03ea)|Win32 EXE||2017-10-02 04:38:55|15Mar201|
|[33b1e07651f7b8654e8174de8415c134](https://www.virustotal.com/gui/file/33b1e07651f7b8654e8174de8415c134)|Win32 EXE||2017-09-24 07:03:14|crystal|
|[ecca8f4c7e14bbc1e3a06b9f8a41b53a](https://www.virustotal.com/gui/file/ecca8f4c7e14bbc1e3a06b9f8a41b53a)|Win32 EXE|Zbot|2017-09-20 05:08:19|15Mar201|
|[a89a7481273b873fab1aba09ae8d3483](https://www.virustotal.com/gui/file/a89a7481273b873fab1aba09ae8d3483)|Win32 EXE||2017-09-18 08:21:13|sv.exe|
|[9f29e983967129916869a1b322764919](https://www.virustotal.com/gui/file/9f29e983967129916869a1b322764919)|RTF|CVE-2012-0158|2017-09-14 11:54:19|Mail Access SOP Cred.doc|
|[2fcfae21ccf1dfd106aef422a27560bf](https://www.virustotal.com/gui/file/2fcfae21ccf1dfd106aef422a27560bf)|Win32 EXE||2017-09-07 13:59:03|Insight|
|[9682bb80d1d31f10fa028359c975001d](https://www.virustotal.com/gui/file/9682bb80d1d31f10fa028359c975001d)|RTF|CVE-2012-0158|2017-09-06 07:27:27|Mail Access Report.doc|
|[4eb646b034c7f365212fd7491a94659d](https://www.virustotal.com/gui/file/4eb646b034c7f365212fd7491a94659d)|Win32 EXE||2017-08-19 16:46:45|C:/Users/seongmin/Documents/VT2/malware/20170824/4eb646b034c7f365212fd7491a94659d.vir|
|[bfc8d68fca03f4752897c552b7984523](https://www.virustotal.com/gui/file/bfc8d68fca03f4752897c552b7984523)|Win32 EXE||2017-08-11 09:01:18|Home|
|[eb0ed8837657dbdca041522f67f8f69e](https://www.virustotal.com/gui/file/eb0ed8837657dbdca041522f67f8f69e)|DOCX|CVE-2015-2545|2017-08-11 08:50:10|eps-mht-dwn.doc|
|[05d6bda7744d6fa1e08c3bf7afca8c41](https://www.virustotal.com/gui/file/05d6bda7744d6fa1e08c3bf7afca8c41)|Win32 EXE||2017-07-23 13:03:28|05d6bda7744d6fa1e08c3bf7afca8c41|
|[f55425fc550f19b5a7d95a8f9f0eda46](https://www.virustotal.com/gui/file/f55425fc550f19b5a7d95a8f9f0eda46)|Win32 EXE||2017-07-22 16:51:51|myfile.exe|
|[1960ac9d5b1192a9b2bfec15842cf3d1](https://www.virustotal.com/gui/file/1960ac9d5b1192a9b2bfec15842cf3d1)|PPSX||2017-07-21 20:16:51|c9b8db3732fb73f1cd5e993dd47b59a96b6723b5|
|[6a374c356b9dc65c63e83750c5eb30ff](https://www.virustotal.com/gui/file/6a374c356b9dc65c63e83750c5eb30ff)|Win32 EXE||2017-07-15 17:27:11|6a374c356b9dc65c63e83750c5eb30ff.virus|
|[7b711b794d3607babcb0917134099f31](https://www.virustotal.com/gui/file/7b711b794d3607babcb0917134099f31)|Win32 EXE||2017-07-07 05:57:06|crystal|
|[dac9f9bf6d7fe264f220932c2e73bde3](https://www.virustotal.com/gui/file/dac9f9bf6d7fe264f220932c2e73bde3)|Win32 EXE|Zbot|2017-05-21 16:57:11|dac9f9bf6d7fe264f220932c2e73bde3.virus|
|[99197cd2eef1b446f396b20d6bc3bb24](https://www.virustotal.com/gui/file/99197cd2eef1b446f396b20d6bc3bb24)|Win32 EXE||2017-05-21 16:45:48|crystal|
|[10cacca80ef5767206969f75e03432f1](https://www.virustotal.com/gui/file/10cacca80ef5767206969f75e03432f1)|Win32 EXE||2017-05-15 21:10:20|10cacca80ef5767206969f75e03432f1.virus|
|[8da2dbb5f6171e0908674a69d412335b](https://www.virustotal.com/gui/file/8da2dbb5f6171e0908674a69d412335b)|Win32 EXE||2017-05-08 11:36:57|D:\APEX_Verification\8-may-2017\EP\8da2dbb5f6171e0908674a69d412335b|
|[c009cc06ea2a0bf320884700a48ab835](https://www.virustotal.com/gui/file/c009cc06ea2a0bf320884700a48ab835)|Win32 EXE||2017-05-05 16:47:55|wsmgr|
|[20472cf5d5d8328387f824b12f6b39ca](https://www.virustotal.com/gui/file/20472cf5d5d8328387f824b12f6b39ca)|Win32 EXE|blocker|2017-04-02 00:47:38|wsmgr|
|[de668364fc3ab1a225e75008f8a58ae4](https://www.virustotal.com/gui/file/de668364fc3ab1a225e75008f8a58ae4)|Win32 EXE||2017-03-18 05:58:22|vCpxAM5pPB|
|[2ba337190f86affb65f0d232f44b7d52](https://www.virustotal.com/gui/file/2ba337190f86affb65f0d232f44b7d52)|Win32 EXE||2017-03-18 05:58:19|KashmirKillingAndFreedomPics.exe|
|[be15e8ed4f245b41a6168e6719c6058f](https://www.virustotal.com/gui/file/be15e8ed4f245b41a6168e6719c6058f)|Win32 EXE||2017-03-11 02:38:14|wsmgr|
|[0db977b162c88b5383091c135adcd88a](https://www.virustotal.com/gui/file/0db977b162c88b5383091c135adcd88a)|Win32 EXE||2017-03-04 02:00:11|igfxsr.exe|
|[17875cd7c118256e6d285a79cb234c78](https://www.virustotal.com/gui/file/17875cd7c118256e6d285a79cb234c78)|Win32 EXE|dynamer|2017-03-03 23:16:09|17875cd7c118256e6d285a79cb234c78.virus|
|[bb450ecec5321cf2c9fc098309a47fa7](https://www.virustotal.com/gui/file/bb450ecec5321cf2c9fc098309a47fa7)|Win32 EXE||2016-11-19 21:35:37|tasklist|
|[8f2036f35444c8ac5c33de4806d4c4f4](https://www.virustotal.com/gui/file/8f2036f35444c8ac5c33de4806d4c4f4)|Win32 EXE||2016-11-19 21:32:58|iexpo|
|[4a4a5901208dfbbf30d7ae2b75aa5091](https://www.virustotal.com/gui/file/4a4a5901208dfbbf30d7ae2b75aa5091)|Win32 EXE||2016-11-16 21:15:33|light|
|[9e8a774f352d8819528c8bfc12d7097b](https://www.virustotal.com/gui/file/9e8a774f352d8819528c8bfc12d7097b)|Win32 EXE||2016-11-05 16:06:31|tasklist|
|[a1a5416f6e9c20cb370d6a9152c3e2e7](https://www.virustotal.com/gui/file/a1a5416f6e9c20cb370d6a9152c3e2e7)|Win32 EXE||2016-10-11 10:00:23|tasklist|
|[b89e1cb807779f405c5b7cd122880e2e](https://www.virustotal.com/gui/file/b89e1cb807779f405c5b7cd122880e2e)|Win32 EXE|dynamer|2016-10-10 11:27:30|MWOW.EXE|
|[b284eed6807f41346f1e0b33945bd26b](https://www.virustotal.com/gui/file/b284eed6807f41346f1e0b33945bd26b)|Win32 EXE||2016-10-09 05:36:32|b284eed6807f41346f1e0b33945bd26b.virus|
|[c1958fa4ce470358407083ef394bbd54](https://www.virustotal.com/gui/file/c1958fa4ce470358407083ef394bbd54)|Win32 EXE||2016-10-09 00:41:12|/home/virustotal/sample/C1958FA4CE470358407083EF394BBD54|
|[db0f6127448c0f798d853ff672194237](https://www.virustotal.com/gui/file/db0f6127448c0f798d853ff672194237)|Win32 EXE||2016-09-20 10:20:47|tasklist|
|[2b07e054a1abb2941e5e70fba652a211](https://www.virustotal.com/gui/file/2b07e054a1abb2941e5e70fba652a211)|Win32 EXE||2016-09-18 07:13:15|wmiservice|
|[8bc60bf82bd0bc7afc77b26ed465614d](https://www.virustotal.com/gui/file/8bc60bf82bd0bc7afc77b26ed465614d)|Win32 EXE|graftor|2016-09-17 09:30:38|wmsv|
|[9ac9bfe7a3f5d21b65013e4f7f47f1c4](https://www.virustotal.com/gui/file/9ac9bfe7a3f5d21b65013e4f7f47f1c4)|Win32 EXE|dynamer|2016-09-06 06:32:56|WMInstaller|
|[cee5af57ac60b023f2c715388e34f6db](https://www.virustotal.com/gui/file/cee5af57ac60b023f2c715388e34f6db)|RTF|CVE-2012-0158|2016-09-03 15:00:42|/home/virustotal/sample/CEE5AF57AC60B023F2C715388E34F6DB|
|[9c44f4cead367612a7219d63f73f63ba](https://www.virustotal.com/gui/file/9c44f4cead367612a7219d63f73f63ba)|Rich Text Format|CVE-2012-0158|2016-08-16 08:51:06|cv_nafisa.doc|
|[d73471dec55bf0064b6fcd09a55b69dc](https://www.virustotal.com/gui/file/d73471dec55bf0064b6fcd09a55b69dc)|Win32 EXE|dynamer|2016-08-06 09:23:22|MWOW.EXE|
|[6e855944d171a3acbb64635dbe7a9c62](https://www.virustotal.com/gui/file/6e855944d171a3acbb64635dbe7a9c62)|Win32 EXE||2016-07-25 09:02:45|MWOW.EXE|
|[3aa252c9c859464e2db912cd6140f125](https://www.virustotal.com/gui/file/3aa252c9c859464e2db912cd6140f125)|Win32 EXE||2016-07-06 05:50:51|wsmgr|
|[d4a0aef19d9e284faf4854c8f4fc660d](https://www.virustotal.com/gui/file/d4a0aef19d9e284faf4854c8f4fc660d)|Win32 EXE||2016-07-04 06:50:15|iexpo|
|[b5d73517bb02545e8776db4c8a66b62a](https://www.virustotal.com/gui/file/b5d73517bb02545e8776db4c8a66b62a)|RTF|CVE-2012-0158|2016-06-30 07:14:37|/home/virustotal/sample/B5D73517BB02545E8776DB4C8A66B62A|
|[546df801ab370bc8062f15b2ac723572](https://www.virustotal.com/gui/file/546df801ab370bc8062f15b2ac723572)|Win32 EXE|scar|2016-05-26 08:34:51|wsmgr|
|[c669a30e0ade24502415868b282d111d](https://www.virustotal.com/gui/file/c669a30e0ade24502415868b282d111d)|Win32 EXE||2016-05-06 08:25:33|iexpo|
|[f413ad5233cdf707fd1cddd53b858027](https://www.virustotal.com/gui/file/f413ad5233cdf707fd1cddd53b858027)|Win32 EXE||2016-04-27 03:39:53|lsms.exe|
|[ec9734731dc25a3fd84582f7060c6bac](https://www.virustotal.com/gui/file/ec9734731dc25a3fd84582f7060c6bac)|Win32 EXE||2016-04-04 19:12:11|wuauser|
|[f8f960bd176083ae3968cac93e479d4b](https://www.virustotal.com/gui/file/f8f960bd176083ae3968cac93e479d4b)|Win32 EXE|dynamer|2016-03-11 08:16:09|wmiservice|
|[cca845b31e6b64fb7deaede5cddc5fbe](https://www.virustotal.com/gui/file/cca845b31e6b64fb7deaede5cddc5fbe)|FPX|CVE-2012-0158|2016-02-11 11:47:57|/home/virustotal/sample/CCA845B31E6B64FB7DEAEDE5CDDC5FBE|
|[9848d1b4ffd6a7a62d988a7d56218ded](https://www.virustotal.com/gui/file/9848d1b4ffd6a7a62d988a7d56218ded)|Win32 EXE||2016-01-26 01:08:03|cohost|
|[e89c8053c2713e9859862570d7be5a4c](https://www.virustotal.com/gui/file/e89c8053c2713e9859862570d7be5a4c)|Win32 EXE|graftor|2016-01-21 13:28:56|cohost|
|[40104c29731304ba1c6aa4f05dfdaf26](https://www.virustotal.com/gui/file/40104c29731304ba1c6aa4f05dfdaf26)|Win32 EXE||2015-12-25 08:18:58|conshos|
|[dbd3b380a3fca0ca33362027bd1ba7a3](https://www.virustotal.com/gui/file/dbd3b380a3fca0ca33362027bd1ba7a3)|Win32 EXE||2015-12-09 11:27:16|dllhost|
|[65c53bd6fe7c5569881fd53023c3d40a](https://www.virustotal.com/gui/file/65c53bd6fe7c5569881fd53023c3d40a)|Win32 EXE||2015-12-09 10:54:18|conshos|
|[448b8af1a6757aa5b827b382777ab3de](https://www.virustotal.com/gui/file/448b8af1a6757aa5b827b382777ab3de)|Android||2015-12-03 13:22:32|/home/virustotal/sample/448B8AF1A6757AA5B827B382777AB3DE|
|[3d163cc7329ed049d3e32b5d11586236](https://www.virustotal.com/gui/file/3d163cc7329ed049d3e32b5d11586236)|RTF|CVE-2014-1761|2015-08-27 06:21:17|/home/virustotal/sample/3D163CC7329ED049D3E32B5D11586236|
|[05e83dcbc9e55386841722131d4a80f7](https://www.virustotal.com/gui/file/05e83dcbc9e55386841722131d4a80f7)|Win32 EXE||2015-08-25 06:20:18|spooler|
|[af263ce87ac39fc921cdea0cd9868df6](https://www.virustotal.com/gui/file/af263ce87ac39fc921cdea0cd9868df6)|Win32 EXE||2015-08-18 14:05:13|spooler|
|[f2047c7a66bd4dd95af12dde01c0e31b](https://www.virustotal.com/gui/file/f2047c7a66bd4dd95af12dde01c0e31b)|Win32 EXE||2014-12-02 18:07:05|svchsrv.exe|
|[0b2c62981d374fa9a291283b9743f123](https://www.virustotal.com/gui/file/0b2c62981d374fa9a291283b9743f123)|Win32 EXE|graftor|2014-10-01 00:46:26|svchsrv.exe|
|[a9d71a4587a8a24a09deb7c0431e3b43](https://www.virustotal.com/gui/file/a9d71a4587a8a24a09deb7c0431e3b43)|Win32 EXE||2014-05-02 08:48:24|cryss|
|[34ae127d269b718933a248c990faba03](https://www.virustotal.com/gui/file/34ae127d269b718933a248c990faba03)|Win32 EXE||2020-10-16 06:45:57|34ae127d269b718933a248c990faba03+b52a2c0566ddbef2dcdff2d1a2e3bf6833375e9f_msapp.exe .vir|
|[f4daf0eccf9972bdefb79fbf9f7fb6ee](https://www.virustotal.com/gui/file/f4daf0eccf9972bdefb79fbf9f7fb6ee)|Win32 EXE|Disfa|2020-10-16 06:31:14|MicrosoftServices.exe|
|[c48a87cce4ace4a40702f9fae82509d3](https://www.virustotal.com/gui/file/c48a87cce4ace4a40702f9fae82509d3)|Win32 EXE||2020-09-14 06:11:34|msessential.exe|
|[0650e1bd642f67843d8f8f1a9f61ff10](https://www.virustotal.com/gui/file/0650e1bd642f67843d8f8f1a9f61ff10)|Win32 EXE||2020-09-09 07:11:34|MicrosoftServices.exe|
|[a39aa2ecbbb50c97727503e23ce7b8c6](https://www.virustotal.com/gui/file/a39aa2ecbbb50c97727503e23ce7b8c6)|Win32 EXE||2020-09-09 05:53:07|msass|
|[569d721e44e1a31a53aeaa0e514ad794](https://www.virustotal.com/gui/file/569d721e44e1a31a53aeaa0e514ad794)|LNK||2020-09-04 08:57:58|Income tax Savings for 2020-2021.lnk|
|[d89560ec4dbb0ca75734b39009d089e5](https://www.virustotal.com/gui/file/d89560ec4dbb0ca75734b39009d089e5)|Win32 EXE||2020-08-25 05:56:30|rkftl.exe|
|[0a23faaf405c629e9202cbc90611b576](https://www.virustotal.com/gui/file/0a23faaf405c629e9202cbc90611b576)|FPX||2020-08-25 04:53:38|MsAulis.msi|
|[c9d7b9e1d2eadb8657ec84ff2d20b98c](https://www.virustotal.com/gui/file/c9d7b9e1d2eadb8657ec84ff2d20b98c)|XLS||2020-08-24 10:13:30|43de6a87a2cda98e922e80ecf8661cf02c20f0c0a1b5fb057687be8119e45f03.bin|
|[660a678cd7202475cf0d2c48b4b52bab](https://www.virustotal.com/gui/file/660a678cd7202475cf0d2c48b4b52bab)|Win32 EXE|Graftor|2020-08-21 09:27:44|lsap|
|[868157228b5bf0faeac5e31aa682e8a5](https://www.virustotal.com/gui/file/868157228b5bf0faeac5e31aa682e8a5)|Win32 EXE||2020-08-19 09:58:16|_ECE805C7D8A840A0B07A54CFA3057BC3|
|[b2cbcc1beea28ea743f1dd2829460c86](https://www.virustotal.com/gui/file/b2cbcc1beea28ea743f1dd2829460c86)|FPX||2020-08-19 02:52:14|sgi.msi|
|[f383bafdb255c27bad478a207a9951c8](https://www.virustotal.com/gui/file/f383bafdb255c27bad478a207a9951c8)|Win32 EXE|Wacatac|2020-08-08 06:34:05|crashreporter.exe|
|[4e548b5597f995b42decd7591ba4212e](https://www.virustotal.com/gui/file/4e548b5597f995b42decd7591ba4212e)|RTF||2020-08-08 06:32:50|c:\users\admini~1\appdata\local\temp\letter to adp for clearance of crvs 20200720.doc|
|[33479ed79317d1d93bc2912f6c12f196](https://www.virustotal.com/gui/file/33479ed79317d1d93bc2912f6c12f196)|Win32 EXE||2020-08-06 12:18:08|crashreporter.exe|
|[ecdfadf4bba9205396e127a04449701e](https://www.virustotal.com/gui/file/ecdfadf4bba9205396e127a04449701e)|Win32 EXE|Virlock|2020-08-06 08:05:21|\ProgramData\VqYccUMM\awwcUMUo.exe|
|[761570587a2f92eea1512ff159ccef29](https://www.virustotal.com/gui/file/761570587a2f92eea1512ff159ccef29)|FPX||2020-07-24 15:00:26|e739aa7dda183b2a39bd2b27e5a4bf055d149e78d2c1f7f71c103b7f0e54ac8b.bin|
|[6516bedffc29d38b6694c9c4fe5133e0](https://www.virustotal.com/gui/file/6516bedffc29d38b6694c9c4fe5133e0)|Win32 EXE||2020-06-29 17:52:07|windows update|
|[df0cd6ac04f08a3c46546bc238dbacb1](https://www.virustotal.com/gui/file/df0cd6ac04f08a3c46546bc238dbacb1)|FPX|Wacatac|2020-06-29 13:07:46|rt.msi|
|[f10a8736d4005d15ff4a5f3ad4be834c](https://www.virustotal.com/gui/file/f10a8736d4005d15ff4a5f3ad4be834c)|DOCX|CVE-2018-0802|2020-06-29 11:35:27|National Network Security.docx|
|[c789eb63e852eed12758a3d53b5f51c7](https://www.virustotal.com/gui/file/c789eb63e852eed12758a3d53b5f51c7)|Android||2020-06-22 14:20:18| |
|[29dddd86e3f8518478ec27447ba17bd5](https://www.virustotal.com/gui/file/29dddd86e3f8518478ec27447ba17bd5)|Android|androidos|2020-06-17 22:26:31|29dddd86e3f8518478ec27447ba17bd5.virus|
|[c0a7c73b36adc5213651c934eeab9b68](https://www.virustotal.com/gui/file/c0a7c73b36adc5213651c934eeab9b68)|Win32 EXE||2020-06-15 11:26:45|_0A0EC917567B4A9DBD0F641A556E050E|
|[e74fe954d273f8904f1c2fea966abbe4](https://www.virustotal.com/gui/file/e74fe954d273f8904f1c2fea966abbe4)|Win32 EXE|Graftor|2020-04-01 08:06:02|lsap|
|[0e1db2219402ec254b150a4f6d8b0b02](https://www.virustotal.com/gui/file/0e1db2219402ec254b150a4f6d8b0b02)|Android||2020-03-31 04:56:18|0e1db2219402ec254b150a4f6d8b0b02.virus|
|[692ff450aec14aca235cd92e6c52a960](https://www.virustotal.com/gui/file/692ff450aec14aca235cd92e6c52a960)|Android||2020-03-12 06:16:53|ImageView.apk|
|[bbe4ae55f828e020c32e215f4d152cc3](https://www.virustotal.com/gui/file/bbe4ae55f828e020c32e215f4d152cc3)|Win32 EXE|PlugX|2020-03-05 23:57:04|./KISA_dataset_2020_train/1a7b2cb84af0cdab14e2f2032c3b2c208bfadf5b5e6dbf2fd5d66239bf4705c7.vir|
|[f6b250aff0e2f5b592a6753c4fdb4475](https://www.virustotal.com/gui/file/f6b250aff0e2f5b592a6753c4fdb4475)|Win32 EXE|Johnnie|2020-02-27 22:27:21|rgdl|
|[99dd93a189fd734fb00246a7a37014d3](https://www.virustotal.com/gui/file/99dd93a189fd734fb00246a7a37014d3)|Win32 EXE|Johnnie|2020-02-21 05:16:20|rgdl|
|[42c2d7aeb8a98df09c624a9605849927](https://www.virustotal.com/gui/file/42c2d7aeb8a98df09c624a9605849927)|Android|Bitrep|2020-01-22 13:07:51|3bc782eec12f2a0988f83403c59cb5f8212a2ca9fef8001573aea9a0ae3898ab.bin|
|[4987f36c8c90ef2075e41f8a2964754f](https://www.virustotal.com/gui/file/4987f36c8c90ef2075e41f8a2964754f)|Android||2019-12-01 03:20:35|4987f36c8c90ef2075e41f8a2964754f.virus|
|[9782e1f021fff363b4a6ee196e1aa9cb](https://www.virustotal.com/gui/file/9782e1f021fff363b4a6ee196e1aa9cb)|Win32 EXE||2019-10-27 01:00:36|/var/www/clean-mx/virusesevidence/output.144508816.txt|
|[68f0fb35fa7ad061b621a6b4c48155b2](https://www.virustotal.com/gui/file/68f0fb35fa7ad061b621a6b4c48155b2)|Android|Wacatac|2019-10-21 02:20:31|68f0fb35fa7ad061b621a6b4c48155b2.virus|
|[ee85b2657ca5a1798b645d61e8f5080c](https://www.virustotal.com/gui/file/ee85b2657ca5a1798b645d61e8f5080c)|Android|Wacatac|2019-10-17 02:17:13|ImageViewer360.apk|
|[8914bb179f13dcb31d73030db5f15b8d](https://www.virustotal.com/gui/file/8914bb179f13dcb31d73030db5f15b8d)|RAR|Johnnie|2019-09-23 07:18:09|PunjabPoliceContactsUpdate.rar|
|[746adb944ae2dbf57c49a721404e0125](https://www.virustotal.com/gui/file/746adb944ae2dbf57c49a721404e0125)|Win32 EXE||2019-07-29 07:57:48|audiodq.exe|
|[cbb32c303d06aa4d2dba713936e70f5c](https://www.virustotal.com/gui/file/cbb32c303d06aa4d2dba713936e70f5c)|Android||2019-05-29 06:55:51|PrivateChat.apk|
|[ea3b4cde5ef86acfe2971345a2d57cc0](https://www.virustotal.com/gui/file/ea3b4cde5ef86acfe2971345a2d57cc0)|Android|Wacatac|2018-12-21 09:05:55|voicemail.apk|
|[f92ed513fb83e7418654c4ee2a89bed5](https://www.virustotal.com/gui/file/f92ed513fb83e7418654c4ee2a89bed5)|Android||2018-10-03 12:18:19|Image_Viewer.apk|
|[d20c6731e278a1d3202b4caa0902afa8](https://www.virustotal.com/gui/file/d20c6731e278a1d3202b4caa0902afa8)|Android||2018-08-22 20:27:27|Dawn News Official.apk|
|[d7c21a239999e055ef9a08a0e6207552](https://www.virustotal.com/gui/file/d7c21a239999e055ef9a08a0e6207552)|Android|Wacatac|2018-06-13 08:28:31|/home/kinetic/Desktop/malwareDataset/malwareAPK/2018/VirusShare_d7c21a239999e055ef9a08a0e6207552|
|[6d3dcb9ad491628488feb9de6e092144](https://www.virustotal.com/gui/file/6d3dcb9ad491628488feb9de6e092144)|Android||2018-01-17 12:39:21|TrueIslam.apk|
|[de931e107d293303dd1ee7e4776d4ec7](https://www.virustotal.com/gui/file/de931e107d293303dd1ee7e4776d4ec7)|Android|Bitrep|2018-01-17 12:36:33|=?UTF-8?B?6JOd5YWJ5omL5py66Ziy5q+S6auY57qn54mI5pysLmFwaw==?=|
|[b0d55ccc06573230f2f74b9e85b5a6c9](https://www.virustotal.com/gui/file/b0d55ccc06573230f2f74b9e85b5a6c9)|Android||2017-05-03 19:23:52| |
|[9edf73b04609e7c3dada1f1807c11a33](https://www.virustotal.com/gui/file/9edf73b04609e7c3dada1f1807c11a33)|Android||2016-01-26 18:57:45|WhatsAppActivation.apk|
|[8aff67a6b4f3e398b912f8405beb5319](https://www.virustotal.com/gui/file/8aff67a6b4f3e398b912f8405beb5319)|Android|Wacatac|2014-12-09 05:05:18|da4271c7e3e6e796c1cc64c837f63e0580e0d8773e6166e83e91a2ed54f3946d.bin|
