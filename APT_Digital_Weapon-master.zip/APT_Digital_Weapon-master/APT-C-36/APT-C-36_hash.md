|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[9fb15f35f6c2ba4727cba53fb95c1179](https://www.virustotal.com/gui/file/9fb15f35f6c2ba4727cba53fb95c1179)|unknown|o97m|2019-03-20 19:04:26|Denuncia Virtual en su contra.doc|
|[b5887fc368cc6c6f490b4a8a4d8cc469](https://www.virustotal.com/gui/file/b5887fc368cc6c6f490b4a8a4d8cc469)|Win32 EXE|injector|2019-02-17 17:21:59|ba.exe|
|[ef9f19525e7862fb71175c0bbfe74247](https://www.virustotal.com/gui/file/ef9f19525e7862fb71175c0bbfe74247)|Win32 EXE|AZORult|2019-02-14 08:02:55|dinu.exe|
|[0c97d7f6a1835a3fe64c1c625ea109ed](https://www.virustotal.com/gui/file/0c97d7f6a1835a3fe64c1c625ea109ed)|unknown|o97m|2019-02-13 09:44:58|Registraduria Nacional - Notificacion cancelacion cedula de ciudadania.doc|
|[4daacd7f717e567e25afd46cbf0250c0](https://www.virustotal.com/gui/file/4daacd7f717e567e25afd46cbf0250c0)|Win32 EXE|ursu|2019-01-31 12:54:15|4daacd7f717e567e25afd46cbf0250c0.virobj|
|[f2776ed4189f9c85c66dd78a94c13ca2](https://www.virustotal.com/gui/file/f2776ed4189f9c85c66dd78a94c13ca2)|Win32 EXE|Kryptik|2019-01-18 20:11:44|dii.exe|
|[e7d8f836ddba549a5e94ad09086be126](https://www.virustotal.com/gui/file/e7d8f836ddba549a5e94ad09086be126)|Win32 EXE|Kryptik|2019-01-16 02:59:50|pm.exe|
|[9db2ac3c28cb34ae54508fab90a0fde7](https://www.virustotal.com/gui/file/9db2ac3c28cb34ae54508fab90a0fde7)|Win32 EXE|imminent|2019-01-10 21:11:12|nd.exe|
|[9b3250409072ce5b4e4bc467f29102d2](https://www.virustotal.com/gui/file/9b3250409072ce5b4e4bc467f29102d2)|Win32 EXE|Andromeda|2019-01-01 16:58:15|myfile.exe|
|[43c58adee9cb4ef968bfc14816a4762b](https://www.virustotal.com/gui/file/43c58adee9cb4ef968bfc14816a4762b)|Win32 EXE|Andromeda|2018-12-29 01:17:54|ppp.exe|
|[f2d81d242785ee17e7af2725562e5eae](https://www.virustotal.com/gui/file/f2d81d242785ee17e7af2725562e5eae)|Win32 EXE|Kryptik|2018-12-27 16:35:06|bff.exe|
|[afb80e29c0883fbff96de4f06d7c3aca](https://www.virustotal.com/gui/file/afb80e29c0883fbff96de4f06d7c3aca)|Win32 EXE|imminent|2018-12-26 22:48:30|bff.exe|
|[940d7a7b6f364fbcb95a3a77eb2f44b4](https://www.virustotal.com/gui/file/940d7a7b6f364fbcb95a3a77eb2f44b4)|Win32 EXE|Kryptik|2018-12-24 08:10:05|binff.exe|
|[519ece9d56d4475f0b1287c0d22ebfc2](https://www.virustotal.com/gui/file/519ece9d56d4475f0b1287c0d22ebfc2)|Win32 EXE|Kryptik|2018-12-21 18:53:31|bb.exe|
|[7a2d4c22005397950bcd4659dd8ec249](https://www.virustotal.com/gui/file/7a2d4c22005397950bcd4659dd8ec249)|Win32 EXE|Kryptik|2018-12-21 06:17:15|bff.exe|
|[4e7251029eb4069ba4bf6605ee30a610](https://www.virustotal.com/gui/file/4e7251029eb4069ba4bf6605ee30a610)|Win32 EXE|Andromeda|2018-12-19 16:35:53|bff.exe|
|[df91ac31038dda3824b7258c65009808](https://www.virustotal.com/gui/file/df91ac31038dda3824b7258c65009808)|Win32 EXE|Kryptik|2018-12-18 06:17:57|hj.exe|
|[50064c54922a98dc1182c481e5af6dd4](https://www.virustotal.com/gui/file/50064c54922a98dc1182c481e5af6dd4)|Win32 EXE|Andromeda|2018-12-17 11:46:16|bf.exe|
|[a3f0468657e66c72f67b7867b4c03b0f](https://www.virustotal.com/gui/file/a3f0468657e66c72f67b7867b4c03b0f)|Win32 EXE|Andromeda|2018-12-16 20:02:31|seb.exe|
|[3205464645148d393eac89d085b49afe](https://www.virustotal.com/gui/file/3205464645148d393eac89d085b49afe)|Win32 EXE||2018-12-14 17:40:20|/vt/peelf/3205464645148d393eac89d085b49afe|
|[0915566735968b4ea5f5dadbf7d585cc](https://www.virustotal.com/gui/file/0915566735968b4ea5f5dadbf7d585cc)|Win32 EXE||2018-12-14 15:58:52|bif.exe|
|[5dee0ff120717a6123f1e9c05b5bdbc2](https://www.virustotal.com/gui/file/5dee0ff120717a6123f1e9c05b5bdbc2)|Win32 EXE|AZORult|2018-12-14 13:47:20|ww.exe|
|[a1c29db682177b252d7298fed0c18ebe](https://www.virustotal.com/gui/file/a1c29db682177b252d7298fed0c18ebe)|Win32 EXE|Kryptik|2018-12-13 18:04:26|fbi.exe|
|[f3d22437fae14bcd3918d00f17362aad](https://www.virustotal.com/gui/file/f3d22437fae14bcd3918d00f17362aad)|Win32 EXE|NetwiredRC|2018-12-10 01:53:23|so.exe|
|[b3be31800a8fe329f7d73171dd9d8fe2](https://www.virustotal.com/gui/file/b3be31800a8fe329f7d73171dd9d8fe2)|Win32 EXE|Kryptik|2018-12-05 23:41:58|bing.exe|
|[b9d9083f182d696341a54a4f3a17271f](https://www.virustotal.com/gui/file/b9d9083f182d696341a54a4f3a17271f)|Win32 EXE|Fareit|2018-12-04 16:18:51|binf.exe|
|[7fb75146bf6fba03df81bf933a7eb97d](https://www.virustotal.com/gui/file/7fb75146bf6fba03df81bf933a7eb97d)|unknown|o97m|2018-12-04 14:22:04|Dian su deuda a la fecha.doc|
|[0e874e8859c3084f7df5fdfdce4cf5e2](https://www.virustotal.com/gui/file/0e874e8859c3084f7df5fdfdce4cf5e2)|Win32 EXE|Kryptik|2018-12-04 14:10:04|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/ulfff.exe.false|
|[4354cb04d0ac36dab76606c326bcb187](https://www.virustotal.com/gui/file/4354cb04d0ac36dab76606c326bcb187)|Win32 EXE|Kryptik|2018-11-29 15:47:28|ccc.exe|
|[b6691f01e6c270e6ff3bde0ad9d01fff](https://www.virustotal.com/gui/file/b6691f01e6c270e6ff3bde0ad9d01fff)|unknown||2018-11-28 19:23:59|Dian Embargo Prima de Navidad.doc|
|[f7eb9a41fb41fa7e5b992a75879c71e7](https://www.virustotal.com/gui/file/f7eb9a41fb41fa7e5b992a75879c71e7)|Win32 EXE|Kryptik|2018-11-28 08:22:07|fin.exe|
|[a7cc22a454d392a89b62d779f5b0c724](https://www.virustotal.com/gui/file/a7cc22a454d392a89b62d779f5b0c724)|Win32 EXE|Kryptik|2018-11-19 21:43:53|/data/cfs/malshare/a7cc22a454d392a89b62d779f5b0c724|
|[ccf912e3887cae5195d35437e92280c4](https://www.virustotal.com/gui/file/ccf912e3887cae5195d35437e92280c4)|Win32 EXE|Kryptik|2018-11-19 11:08:22|pm.exe|
|[0a4c0d8994ab45e5e6968463333429e8](https://www.virustotal.com/gui/file/0a4c0d8994ab45e5e6968463333429e8)|Win32 EXE|Kryptik|2018-11-16 20:13:49|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/om.exe.false|
|[3155a8d95873411cb8930b992c357ec4](https://www.virustotal.com/gui/file/3155a8d95873411cb8930b992c357ec4)|Win32 EXE|imminent|2018-11-16 05:00:43|datt.exe|
|[476657db56e3199d9b56b580ea13ddc0](https://www.virustotal.com/gui/file/476657db56e3199d9b56b580ea13ddc0)|unknown|o97m|2018-11-15 19:25:44|Reporte Negativo como codeudor.doc|
|[51591a026b0962572605da4f8ecc7b1f](https://www.virustotal.com/gui/file/51591a026b0962572605da4f8ecc7b1f)|unknown|o97m|2018-11-09 03:33:46|Orden de comparendo multa detallada.doc|
|[f1e85e3876ddb88acd07e97c417191f4](https://www.virustotal.com/gui/file/f1e85e3876ddb88acd07e97c417191f4)|Win32 EXE|Kryptik|2018-11-06 03:33:26|up.exe|
|[f90fcf64000e8d378eec8a3965cff10a](https://www.virustotal.com/gui/file/f90fcf64000e8d378eec8a3965cff10a)|Win32 EXE|Kryptik|2018-11-04 14:40:41|mil.exe|
|[53774d4cbd044b26ed09909c7f4d32b3](https://www.virustotal.com/gui/file/53774d4cbd044b26ed09909c7f4d32b3)|Win32 EXE|Kryptik|2018-11-01 19:37:03|jue.exe|
|[6d1e586fbbb5e1f9fbcc31ff2fbe3c8c](https://www.virustotal.com/gui/file/6d1e586fbbb5e1f9fbcc31ff2fbe3c8c)|Win32 EXE|Kryptik|2018-10-31 22:06:47|lun.exe|
|[e3dad905cecdcf49aa503c001c82940d](https://www.virustotal.com/gui/file/e3dad905cecdcf49aa503c001c82940d)|Win32 EXE|Kryptik|2018-10-31 04:28:35|mar.exe|
|[60daac2b50cb0a8bd86060d1c288cae2](https://www.virustotal.com/gui/file/60daac2b50cb0a8bd86060d1c288cae2)|Win32 EXE|Kryptik|2018-10-28 20:36:36|fii.exe|
|[46665f9b602201f86eef6b39df618c4a](https://www.virustotal.com/gui/file/46665f9b602201f86eef6b39df618c4a)|unknown|o97m|2018-10-26 15:22:29|Orden de comparendo N\xc2\xb0 5098.doc|
|[edef2170607979246d33753792967dcf](https://www.virustotal.com/gui/file/edef2170607979246d33753792967dcf)|Win32 EXE|Androm|2018-10-25 15:49:32|lo.exe|
|[5065d3062bf1b8074b0ec09f146708ba](https://www.virustotal.com/gui/file/5065d3062bf1b8074b0ec09f146708ba)|Email||2018-10-24 02:18:17|eml|
|[b4ab56d5feef2a35071cc70c40e03382](https://www.virustotal.com/gui/file/b4ab56d5feef2a35071cc70c40e03382)|unknown||2018-10-22 19:27:29|Reporte fraude desde su dirrecion ip.doc|
|[19487e0cbfdb687538c15e1e45f9b805](https://www.virustotal.com/gui/file/19487e0cbfdb687538c15e1e45f9b805)|RAR||2018-10-22 18:36:53|Reporte fraude desde su dirrecion ip (3).rar|
|[8ec736a9a718877b32f113b4c917a97a](https://www.virustotal.com/gui/file/8ec736a9a718877b32f113b4c917a97a)|Win32 EXE||2018-10-19 19:38:56|imm.exe|
|[5be9be1914b4f420728a39fdb060415e](https://www.virustotal.com/gui/file/5be9be1914b4f420728a39fdb060415e)|Win32 EXE|AgentTesla|2018-10-19 14:33:34|inmi2.exe|
|[a91157a792de47d435df66cccd825b3f](https://www.virustotal.com/gui/file/a91157a792de47d435df66cccd825b3f)|unknown|o97m|2018-10-17 19:55:11|C:\Users\kenneth.ubeda\Desktop\Migracion colombia proceso pendiente 509876.doc|
|[ee5531fb614697a70c38a9c8f6891ed6](https://www.virustotal.com/gui/file/ee5531fb614697a70c38a9c8f6891ed6)|unknown|o97m|2018-10-04 21:37:03|BoardingPass.doc|
|[27a9ca89aaa7cef1ccb12ddefa7350af](https://www.virustotal.com/gui/file/27a9ca89aaa7cef1ccb12ddefa7350af)|unknown|o97m|2018-09-20 10:37:15|455be8a4210b84f0e93dd96f7a0eec4ef9816d47c11e28cf7104647330a03f6d.bin|
|[cc73036ceb913014874a1d751b5bdad8](https://www.virustotal.com/gui/file/cc73036ceb913014874a1d751b5bdad8)|Email||2018-09-20 08:12:21|eml|
|[27902600b54cdc45cfe1148f10213d07](https://www.virustotal.com/gui/file/27902600b54cdc45cfe1148f10213d07)|Email||2018-09-18 09:03:07|7e04eb32a4799280e343ac00e430a43f31f092d9332802074a127b58141e89e0|
|[763fe5a0f9f4f90bdc0e563518469566](https://www.virustotal.com/gui/file/763fe5a0f9f4f90bdc0e563518469566)|Win32 EXE|AgentTesla|2018-09-14 16:20:13|dianvif.exe|
|[5ba378dd04df51b88a37f90d768b9cf4](https://www.virustotal.com/gui/file/5ba378dd04df51b88a37f90d768b9cf4)|Email||2018-09-14 09:03:36|2136b0a348eaf151ec56a382e67f67335588c6dfdf56fd9a31bea2c2f3fc4529|
|[a355597a4dd13b3f882db243d47d57ee](https://www.virustotal.com/gui/file/a355597a4dd13b3f882db243d47d57ee)|RAR||2018-09-13 19:29:02|Dian Embargo Bancario|
|[ecccdbb43f60c629ef034b1f401c7fee](https://www.virustotal.com/gui/file/ecccdbb43f60c629ef034b1f401c7fee)|unknown|o97m|2018-09-13 19:16:39|Dian Embargo Bancario|
|[e575fd8d5e85f0151ff8b8376a7de70e](https://www.virustotal.com/gui/file/e575fd8d5e85f0151ff8b8376a7de70e)|Email||2018-09-08 09:03:30|606ab55908947fe9fb9a6b5fb079e8b94ae195362697e3477112795a34818398|
|[e3050e63631ccdf69322dc89bf715667](https://www.virustotal.com/gui/file/e3050e63631ccdf69322dc89bf715667)|unknown||2018-09-04 00:43:35|Citacion Fiscalia general de la Nacion Proceso 305351T.doc|
|[99b258e9e06158cfa17ee235a280773a](https://www.virustotal.com/gui/file/99b258e9e06158cfa17ee235a280773a)|RAR||2018-09-03 16:17:41|Citacion Fiscalia general de la Nacion Proceso 305351T.rar|
|[6b56baeba602b4a0b8de99cea6c69d69](https://www.virustotal.com/gui/file/6b56baeba602b4a0b8de99cea6c69d69)|Email||2018-08-30 09:03:46|93e222e6dc2395fc6ee250776b28bc4cd567263ed62d4e7095dc055f5987f6c5|
|[b8d37b89e94467e63e96570b45c28ec8](https://www.virustotal.com/gui/file/b8d37b89e94467e63e96570b45c28ec8)|FPX||2018-08-30 04:48:52|correo sospechoso.msg|
|[1733079217ac6b8f1699b91abfb5d578](https://www.virustotal.com/gui/file/1733079217ac6b8f1699b91abfb5d578)|Win32 EXE|AgentTesla|2018-08-28 13:53:41|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/sef.exe.false|
|[33ed9ff45755f1aa36cb182a241b51f2](https://www.virustotal.com/gui/file/33ed9ff45755f1aa36cb182a241b51f2)|Email||2018-08-28 09:03:02|3a7360aac0ff41a5179ba9ac6671fb9bc28b43ae1e6a1412e61bfb3fd5a8a547|
|[ea5b820b061ff01c8da527033063a905](https://www.virustotal.com/gui/file/ea5b820b061ff01c8da527033063a905)|unknown|o97m|2018-08-28 03:03:13|Fiscalia proceso 305351T.doc|
|[77fec4fa8e24d580c4a3e8e58c76a297](https://www.virustotal.com/gui/file/77fec4fa8e24d580c4a3e8e58c76a297)|RAR||2018-08-27 17:25:11|Fiscalia proceso 305351T.rar|
|[cbbd2b9a9dc854d9e58a15f350012cb6](https://www.virustotal.com/gui/file/cbbd2b9a9dc854d9e58a15f350012cb6)|unknown||2018-08-09 22:24:41|IMPORTANTE IMPORTANT.doc|
|[30ecfee4ae0ae72cf645c716bef840a0](https://www.virustotal.com/gui/file/30ecfee4ae0ae72cf645c716bef840a0)|Win32 EXE||2018-08-03 15:52:15|procesofiscalia305351.exe|
|[e2f9aabb2e7969efd71694e749093c8b](https://www.virustotal.com/gui/file/e2f9aabb2e7969efd71694e749093c8b)|Win32 EXE|Kryptik|2018-08-03 15:05:33|/home/seclab/Documents/meseum_data/only_using_data_set/vir/using_vir_all_data/indexing/e2f9aabb2e7969efd71694e749093c8b.vir|
|[95aaa7c95a6075cfe3659cd87f7c785e](https://www.virustotal.com/gui/file/95aaa7c95a6075cfe3659cd87f7c785e)|Email||2018-08-02 12:09:58|test2.eml|
|[66f332ee6b6e6c63f4f94eed6fb32805](https://www.virustotal.com/gui/file/66f332ee6b6e6c63f4f94eed6fb32805)|unknown||2018-08-01 20:10:45|Codigo Tarjeta Exito Regalo.doc|
|[3be90f2bb307ce1f57d5285dee6b15bc](https://www.virustotal.com/gui/file/3be90f2bb307ce1f57d5285dee6b15bc)|unknown|o97m|2018-08-01 19:17:35|Reporte Datacredito.doc|
|[73da81e4b4e9af05f94170e133e9c3e3](https://www.virustotal.com/gui/file/73da81e4b4e9af05f94170e133e9c3e3)|Email||2018-07-31 09:04:25|207d6fd16187abf748703a80b11d7557ad60c8eea25d7399cfe01a48c59cee04|
|[3c859878b2cb643813f967136dee666d](https://www.virustotal.com/gui/file/3c859878b2cb643813f967136dee666d)|FPX||2018-07-30 23:26:32|RV WARNING - ENCRYPTED ATTACHMENT NOT VIRUS SCANNED  IMPORTANTE  Adjuntamos el listado con fotografias de los 3 unicos funcionarios autorizados que llegaran a su hogar esta semana para el censo nacional de poblacion.msg|
|[4bbfc852774dd0a13ebe6541413160bb](https://www.virustotal.com/gui/file/4bbfc852774dd0a13ebe6541413160bb)|TXT|o97m|2018-07-30 18:46:52|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/Downloads.doc.false|
|[592c9b2947ca31916167386edd0a4936](https://www.virustotal.com/gui/file/592c9b2947ca31916167386edd0a4936)|RAR||2018-07-30 15:27:19|2498233a889031e89c6963bb45ae9982c46ded3cb65c1a226b13a9c5d9a2b1d4.bin|
|[688b7c8278aad4a0cc36b2af7960f32c](https://www.virustotal.com/gui/file/688b7c8278aad4a0cc36b2af7960f32c)|TXT|o97m|2018-07-27 04:12:28|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/fotos.doc.false|
|[c654ad00856161108b90c5d0f2afbda1](https://www.virustotal.com/gui/file/c654ad00856161108b90c5d0f2afbda1)|Win32 EXE|Kryptik|2018-07-20 00:56:28|c654ad00856161108b90c5d0f2afbda1.vir|
|[19d4a9aee1841e3aee35e115fe81b6ab](https://www.virustotal.com/gui/file/19d4a9aee1841e3aee35e115fe81b6ab)|Win32 EXE|Kryptik|2018-07-17 16:24:40|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/ul.exe.false|
|[7b69e3aaba970c25b40fad29a564a0cf](https://www.virustotal.com/gui/file/7b69e3aaba970c25b40fad29a564a0cf)|Win32 EXE||2018-07-16 18:11:14|tg.exe|
|[f2d5cb747110b43558140c700dbf0e5e](https://www.virustotal.com/gui/file/f2d5cb747110b43558140c700dbf0e5e)|Email|Banload|2018-07-16 14:38:22|eml|
|[1bc52faf563eeda4207272d8c57f27cb](https://www.virustotal.com/gui/file/1bc52faf563eeda4207272d8c57f27cb)|Win32 EXE|Kryptik|2018-07-14 20:48:28|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/rnu.exe.false|
|[2d52f51831bb09c03ef6d4237df554f3](https://www.virustotal.com/gui/file/2d52f51831bb09c03ef6d4237df554f3)|Win32 EXE|Kryptik|2018-07-12 15:47:15|imi.exe|
|[3de286896c8eb68a21a6dcf7dae8ec97](https://www.virustotal.com/gui/file/3de286896c8eb68a21a6dcf7dae8ec97)|unknown|Banload|2018-07-11 19:05:24|Registraduria Nacional del Estado Civil -Proceso inicado.doc|
|[b6e43837f79015fd0e05c4f4b2f30fa5](https://www.virustotal.com/gui/file/b6e43837f79015fd0e05c4f4b2f30fa5)|RAR|Banload|2018-07-11 13:27:15|Registraduria Nacional del Estado Civil -Proceso inicado.rar|
|[352c40f10055b5c8c7e1e11a5d3d5034](https://www.virustotal.com/gui/file/352c40f10055b5c8c7e1e11a5d3d5034)|Win32 EXE|Kryptik|2018-06-20 18:13:13|fe.exe|
|[ce589e5e6f09b603097f215b0fb3b738](https://www.virustotal.com/gui/file/ce589e5e6f09b603097f215b0fb3b738)|unknown|o97m|2018-06-19 22:46:51|estado de cuenta.mht|
|[20c57c5efa39d963d3a1470c5b1e0b36](https://www.virustotal.com/gui/file/20c57c5efa39d963d3a1470c5b1e0b36)|Win32 EXE|Kryptik|2018-06-19 22:20:03|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/APT-C-36/Qgsuqekxr.exe.false|
|[3751c0eeb2ce63c98fae0510f11e7cfc](https://www.virustotal.com/gui/file/3751c0eeb2ce63c98fae0510f11e7cfc)|Email||2018-06-16 01:03:40|ac36636dd40cb0abb6c7cc859011f60a4f0b6430cb6b9e984fb90615ce8f4b50|
|[a644f05ec4a73eb9ccae05a2e9a1fb5c](https://www.virustotal.com/gui/file/a644f05ec4a73eb9ccae05a2e9a1fb5c)|Email||2018-06-16 01:02:35|f6e5ec3ef2aa3f3767ef436f82353029fc2e74f4ae2f7b9726c923105aa6a9ae|
|[531007db30b66c75e5f6009012b3fea6](https://www.virustotal.com/gui/file/531007db30b66c75e5f6009012b3fea6)|Email||2018-06-16 01:02:29|5444cde68dc9ece56db35c187d139e1ce4fde0e0dfaf136fac74349b9f4ae05e|
|[16d3f85f03c72337338875a437f017b4](https://www.virustotal.com/gui/file/16d3f85f03c72337338875a437f017b4)|unknown||2018-06-15 21:01:32|estado de cuenta.doc|
|[fecb2bb53f4b51715be5cc95cfb8546f](https://www.virustotal.com/gui/file/fecb2bb53f4b51715be5cc95cfb8546f)|RAR||2018-06-14 22:01:25|Malware_RAR_4d16474fb192db0bb77dce0b607a19c88f460f783084aaee84df8acd4f05519d|
|[3a255e93b193ce654a5b1c05178f7e3b](https://www.virustotal.com/gui/file/3a255e93b193ce654a5b1c05178f7e3b)|unknown|o97m|2018-06-14 20:08:22|estado de cuenta.doc|
|[aaf04ac5d630081210a8199680dd2d4f](https://www.virustotal.com/gui/file/aaf04ac5d630081210a8199680dd2d4f)|Win32 EXE|Kryptik|2018-05-30 15:03:06|wibh.exe|
|[e9e4ded00a733fdee91ee142436242f4](https://www.virustotal.com/gui/file/e9e4ded00a733fdee91ee142436242f4)|Win32 EXE|Kryptik|2018-05-29 20:38:27|wiu.exe|
|[9a9167abad9fcab18e02ef411922a7c3](https://www.virustotal.com/gui/file/9a9167abad9fcab18e02ef411922a7c3)|unknown|o97m|2018-05-29 19:41:04|comparendo electronico.doc|
|[8518ad447419a4e30b7d19c62953ccaf](https://www.virustotal.com/gui/file/8518ad447419a4e30b7d19c62953ccaf)|Win32 EXE|Kryptik|2018-05-22 15:17:05|Wnlada.exe|
|[662b76db18768727b623885da26ca3f5](https://www.virustotal.com/gui/file/662b76db18768727b623885da26ca3f5)|Email||2018-05-22 01:02:19|b3b4bdb6778cecc4495bacabb209ce02adcbfe72919175bc71317d95cbb990d6|
|[e770a4fbada35417fb5f021353c22d55](https://www.virustotal.com/gui/file/e770a4fbada35417fb5f021353c22d55)|Win32 EXE|Kryptik|2018-05-18 19:18:37|bsneet.exe|
|[91cd02997b7a9b0db23f9f6377315333](https://www.virustotal.com/gui/file/91cd02997b7a9b0db23f9f6377315333)|unknown|o97m|2018-05-18 18:01:02|credito solicitado.doc|
|[f486cdf5ef6a1992e6806b677a59b22a](https://www.virustotal.com/gui/file/f486cdf5ef6a1992e6806b677a59b22a)|RAR||2018-05-18 16:34:20|credito solicitado.rar|
|[b0ed1d7b16dcc5456b8cf2b5f76707d6](https://www.virustotal.com/gui/file/b0ed1d7b16dcc5456b8cf2b5f76707d6)|Win32 EXE|Kryptik|2018-05-03 20:53:15|reteta.exe|
|[fd436dc13e043122236915d7b03782a5](https://www.virustotal.com/gui/file/fd436dc13e043122236915d7b03782a5)|unknown||2018-05-03 01:20:43|text.doc|
|[7fd5b900cf1c8a9c3787e8107a94b2eb](https://www.virustotal.com/gui/file/7fd5b900cf1c8a9c3787e8107a94b2eb)|Email||2018-05-02 22:24:37|approval_box_20180502222202.eml|
|[0e6533dde4d850bb7254a5f3b152a623](https://www.virustotal.com/gui/file/0e6533dde4d850bb7254a5f3b152a623)|RAR||2018-05-02 19:36:32|Proceso Pendiente Migracion Colombia.rar|
|[42f6f0345d197c20aa749db1b65ee55e](https://www.virustotal.com/gui/file/42f6f0345d197c20aa749db1b65ee55e)|Win32 EXE||2018-05-02 14:59:28|mw.exe|
|[d0cd207ae63850be7d0f5f9bea798fda](https://www.virustotal.com/gui/file/d0cd207ae63850be7d0f5f9bea798fda)|Win32 EXE|Kryptik|2018-04-30 21:15:10|amidon.exe|
|[e2771285fe692ee131cbc072e1e9c85d](https://www.virustotal.com/gui/file/e2771285fe692ee131cbc072e1e9c85d)|Win32 EXE|Kryptik|2018-04-29 22:28:01|dee.exe|
|[eb2ea99918d39b90534db3986806bf0c](https://www.virustotal.com/gui/file/eb2ea99918d39b90534db3986806bf0c)|unknown||2018-04-29 04:16:33|Proceso Pendiente Migracion Colombia (2).doc|
|[ac1988382e3bcb734b60908efa80d3a5](https://www.virustotal.com/gui/file/ac1988382e3bcb734b60908efa80d3a5)|Win32 EXE|Kryptik|2018-04-28 20:41:14|ww.exe|
|[cf906422ad12fed1c64cf0a021e0f764](https://www.virustotal.com/gui/file/cf906422ad12fed1c64cf0a021e0f764)|unknown||2018-04-26 17:26:04|Migracion colombia Proceso pendiente.doc - copia.nono.txt|
|[ad2c940af4c10f43a4bdb6f88a447c85](https://www.virustotal.com/gui/file/ad2c940af4c10f43a4bdb6f88a447c85)|Win32 EXE|Kryptik|2018-04-26 00:54:26|w.jpg|
|[bf95e540fd6e155a36b27ad04e7c8369](https://www.virustotal.com/gui/file/bf95e540fd6e155a36b27ad04e7c8369)|unknown||2018-04-25 23:31:21|Migracion colombia Proceso pendiente.mht|
|[b0687578284b1d20b9b45a34aaa4a592](https://www.virustotal.com/gui/file/b0687578284b1d20b9b45a34aaa4a592)|unknown||2018-04-06 19:07:49|sanci%C3%B3n%20declaracion%20de%20renta.doc|
|[a4985c0b71be336a85e4e11f804a8a32](https://www.virustotal.com/gui/file/a4985c0b71be336a85e4e11f804a8a32)|TXT|Banload|2020-07-13 19:49:07|49e48be00ac7f8fe131aaf2592c0b97b7435d91ff6a6ad1724c8a50f11f70c50.bin|
|[c80968dcd5c47e8a11cfd8c5339de701](https://www.virustotal.com/gui/file/c80968dcd5c47e8a11cfd8c5339de701)|PDF|PhishingSite|2020-04-26 03:54:53|Comunicado.pdf|
