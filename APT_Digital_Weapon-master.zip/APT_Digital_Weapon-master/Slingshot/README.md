**NAME:**  
Slingshot  

**Description**:   
Slingshot, uncovered by Kaspersky, compromised thousands of devices through breached routers in various African and Middle Eastern countries, including Afghanistan, Iraq, Kenya, Sudan, Somalia, Turkey and Yemen.

It is reported that Slingshot represents a U.S. military program run out of Joint Special Operations Command (JSOC), a component of Special Operations Command (SOCOM). It helped the military and intelligence community collect information about terrorists by infecting computers they commonly used.

  
**References**:  
https://securelist.com/apt-slingshot/84312/  