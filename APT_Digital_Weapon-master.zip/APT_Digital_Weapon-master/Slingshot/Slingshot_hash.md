|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c638169aaa777d4f6eae43205a39e274](https://www.virustotal.com/gui/file/c638169aaa777d4f6eae43205a39e274)|Win64 DLL||2018-03-09 17:34:41| |
|[6637dbcc6059a1e2e45956d98a3ea590](https://www.virustotal.com/gui/file/6637dbcc6059a1e2e45956d98a3ea590)|Win32 DLL||2018-03-09 17:34:34|scesrv|
|[87a28a99697452a37fc229b3aa3afe97](https://www.virustotal.com/gui/file/87a28a99697452a37fc229b3aa3afe97)|Win32 DLL||2018-03-09 17:34:07|/media/freddie/Seagate Expansion Drive/aptmalware/SampleLibraryAUG2019/SLINGSHOT/SlingShot.bin|
|[64f705e55545a371e0f5e599cfbae5e9](https://www.virustotal.com/gui/file/64f705e55545a371e0f5e599cfbae5e9)|Win64 DLL||2018-03-09 17:33:49|scesrv|
