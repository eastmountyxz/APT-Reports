**NAME:**  
Aggah  

**Description**:   
Aggah is an attack campaign identified by PaloAlto that targets not only Middle East countries but also the United States, and throughout Europe and Asia. Related delivery documents follow the same process to ultimately install RevengeRAT hosted on Pastebin.
  
**References**:  
https://unit42.paloaltonetworks.com/aggah-campaign-bit-ly-blogspot-and-pastebin-used-for-c2-in-large-scale-campaign/