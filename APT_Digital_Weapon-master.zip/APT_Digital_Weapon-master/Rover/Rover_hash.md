|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[abab23b21c7ce03871bf80b5da21c4b8](https://www.virustotal.com/gui/file/abab23b21c7ce03871bf80b5da21c4b8)|Rich Text Format||2016-01-22 11:08:59|Questionnaire.doc|
|[48d2b0a87178cf80ea679245552aaf46](https://www.virustotal.com/gui/file/48d2b0a87178cf80ea679245552aaf46)|Rich Text Format||2015-12-30 04:29:00| |
|[5834f5cf2bb98af5c27dc96a7dca02b2](https://www.virustotal.com/gui/file/5834f5cf2bb98af5c27dc96a7dca02b2)|Rich Text Format||2015-12-28 23:19:55|Appreciation_letter.doc|
|[d38e974aded02406a4ce0681012f4232](https://www.virustotal.com/gui/file/d38e974aded02406a4ce0681012f4232)|Rich Text Format|CVE-2010-3333|2015-12-19 19:59:55|Appreciation_letter.doc|
|[dd1193622b17460f51aba88f7f37a800](https://www.virustotal.com/gui/file/dd1193622b17460f51aba88f7f37a800)|Win32 EXE||2015-12-11 14:21:14|windowssecurityservice3.exe|
|[56a85e6066c304a53f4a8e7ed0e7e1d7](https://www.virustotal.com/gui/file/56a85e6066c304a53f4a8e7ed0e7e1d7)|Win32 EXE||2015-12-05 00:31:04|56a85e6066c304a53f4a8e7ed0e7e1d7.virus|
|[76429f8515768f9f5def697e71071f51](https://www.virustotal.com/gui/file/76429f8515768f9f5def697e71071f51)|Win32 EXE||2015-12-04 16:43:04|76429f8515768f9f5def697e71071f51.virus|
