**NAME:**  
Rover  
  
**Probably operating from**:  
  
**Description**:   
  
**References**:  
