**NAME:**  
Cold River  
  
**Description**:   
Cold River targets Middle Eastern organizations largely from the Lebanon and United Arab Emirates. The sophisticated threat actor making malicious use of DNS tunneling as well as the Django python framework for C2 activities.
  
**References**:  
https://www.lastline.com/labsblog/threat-actor-cold-river-network-traffic-analysis-and-a-deep-dive-on-agent-drable/  