**NAME:**  
Mustang Panda  
  
**Alias**  
Temp.Hex, HoneyMyte, Mustang Panda, Mustang Panda  
  
**Description**:   
Mustang Panda, reported by CrowdStrike, targets non-governmental organizations (NGOs) in general, but uses Mongolian language decoys and themes, suggesting this actor has a specific focus on gathering intelligence on Mongolia. These campaigns involve the use of shared malware like Poison Ivy or PlugX.
  
**References**:  
https://www.crowdstrike.com/blog/meet-crowdstrikes-adversary-of-the-month-for-june-mustang-panda/