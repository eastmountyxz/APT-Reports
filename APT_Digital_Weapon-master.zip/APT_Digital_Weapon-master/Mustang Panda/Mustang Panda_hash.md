|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[5781a2b62de1f3301e38394607b03d79](https://www.virustotal.com/gui/file/5781a2b62de1f3301e38394607b03d79)|LNK||2019-12-16 05:03:26|CV_NTTra.pdf.lnk|
|[aa115f20472e78a068c1bbf739c443bf](https://www.virustotal.com/gui/file/aa115f20472e78a068c1bbf739c443bf)|LNK||2019-08-29 13:56:29|vai tro cua nhan dan.doc.lnk|
|[ca775717d000888a7f71a5907b9c9208](https://www.virustotal.com/gui/file/ca775717d000888a7f71a5907b9c9208)|LNK||2019-08-29 13:56:25|tieu luan ve quyen lam chu cua nhan dan.docx.lnk|
|[f62dfc4999d624d01e94b89946ec1036](https://www.virustotal.com/gui/file/f62dfc4999d624d01e94b89946ec1036)|LNK||2019-08-29 13:56:21|sach tham khao Bo mon.docx.lnk|
|[05cf906b750eb335125695da42f4eafc](https://www.virustotal.com/gui/file/05cf906b750eb335125695da42f4eafc)|LNK||2019-08-29 01:27:41|TCO BT 574.doc.lnk|
|[49bdce3afdb2bb8996ec1f7500b6bd0c](https://www.virustotal.com/gui/file/49bdce3afdb2bb8996ec1f7500b6bd0c)|LNK||2019-08-26 11:11:49|26-08-2019_850_SNgV-BD.doc.lnk|
|[9a180107efb15a00e64db3ce6394328d](https://www.virustotal.com/gui/file/9a180107efb15a00e64db3ce6394328d)|LNK||2019-08-26 06:28:40|32_1.PDF.lnk|
|[5f094cb3b92524fced2731c57d305e78](https://www.virustotal.com/gui/file/5f094cb3b92524fced2731c57d305e78)|LNK||2019-08-19 06:11:32|fb3e3d9671bb733fcecd6900def15b9a6b4f36b0a35bdc769b0a69bc5fb7e40d.bin|
|[0d3fbc842a430f5367d480dd1b74449b](https://www.virustotal.com/gui/file/0d3fbc842a430f5367d480dd1b74449b)|Win32 EXE||2019-08-15 12:39:14|NATIONAL SECURITY CONCEPT OF MONGOLIA.exe|
|[748de2b2aa1fa23fa5996f287437af1b](https://www.virustotal.com/gui/file/748de2b2aa1fa23fa5996f287437af1b)|LNK||2019-07-27 00:36:55|cf56ee00be8ca49d150d85dcb6d2f336.jpg.lnk|
|[9b39e1f72cf4acffd45f45f08483abf0](https://www.virustotal.com/gui/file/9b39e1f72cf4acffd45f45f08483abf0)|LNK||2019-07-22 05:27:14|d89a88edfb0108141e149db338044387af498e4b37d0b58c23b2365ff3ba557a.bin|
|[6198d625ada7389aac276731cdebb500](https://www.virustotal.com/gui/file/6198d625ada7389aac276731cdebb500)|LNK||2019-07-19 06:02:33|GIAYMOI.doc.lnk|
|[08f25a641e8361495a415c763fbb9b71](https://www.virustotal.com/gui/file/08f25a641e8361495a415c763fbb9b71)|LNK||2019-06-28 13:43:52| |
|[11adda734fc67b9cfdf61396de984559](https://www.virustotal.com/gui/file/11adda734fc67b9cfdf61396de984559)|LNK||2019-06-28 11:48:33| |
|[e5a23e8a2c0f98850b1a43b595c08e63](https://www.virustotal.com/gui/file/e5a23e8a2c0f98850b1a43b595c08e63)|Win32 EXE||2019-06-13 05:08:12|DSR & CSR of Special Branch Sind.exe|
|[43067f28dc5208d4a070cf3cc92e29fb](https://www.virustotal.com/gui/file/43067f28dc5208d4a070cf3cc92e29fb)|LNK||2019-06-10 19:24:17| |
|[4fe276edc21ec5f2540c2babd81c8653](https://www.virustotal.com/gui/file/4fe276edc21ec5f2540c2babd81c8653)|LNK||2019-06-06 09:37:18|S_2019_50_E.lnk|
|[9ff1d3af1f39a37c0dc4ceeb18cc37dc](https://www.virustotal.com/gui/file/9ff1d3af1f39a37c0dc4ceeb18cc37dc)|LNK||2019-06-05 18:28:25| |
|[165f8683681a4b136be1f9d6ea7f00ce](https://www.virustotal.com/gui/file/165f8683681a4b136be1f9d6ea7f00ce)|LNK||2019-05-30 11:00:09|unknown_vietnamese_hta_lnk_polyglot_decoy_doc.lnk|
|[0617cad9e5d559356c43d4037c86227f](https://www.virustotal.com/gui/file/0617cad9e5d559356c43d4037c86227f)|Win32 DLL||2017-07-25 07:06:46|goopdate.dll|
|[4754dfaf0a10710c061767acc3adf0e3](https://www.virustotal.com/gui/file/4754dfaf0a10710c061767acc3adf0e3)|Win32 EXE||2020-05-09 05:33:51|C:\Users\Public\f.exe|
|[721a7ddd34d801a883bfc8a1e6349a21](https://www.virustotal.com/gui/file/721a7ddd34d801a883bfc8a1e6349a21)|LNK||2020-05-08 03:15:53|C:\Users\ADMINI~1\AppData\Local\Temp\ocmsa(30-03-2020).lnk|
|[d3ee0db7e36a88b4b446a5baae8eddf9](https://www.virustotal.com/gui/file/d3ee0db7e36a88b4b446a5baae8eddf9)|RAR||2020-04-15 23:12:23|2020-04-14.rar|
|[4f8ff5e70647dbc5d91326346c393729](https://www.virustotal.com/gui/file/4f8ff5e70647dbc5d91326346c393729)|TXT||2020-03-20 16:15:34|9sOXN6Ltf0afe7.js__|
|[eefeb76d26338e09958aae5d81479178](https://www.virustotal.com/gui/file/eefeb76d26338e09958aae5d81479178)|XML|PlugX|2020-03-20 09:41:47|9d52d8f10673518cb9f19153ddbe362acc7ca885974a217a52d1ee8257f22cfc.bin|
|[37f78b1ad43959a788162f560bdc9c79](https://www.virustotal.com/gui/file/37f78b1ad43959a788162f560bdc9c79)|CAB||2020-03-20 06:42:14|oGhPGUDC03tURV.tmp|
|[a70a55e62c963d58817e5087fe9fe7e3](https://www.virustotal.com/gui/file/a70a55e62c963d58817e5087fe9fe7e3)|PDF||2020-03-19 18:26:20|a70a55e62c963d58817e5087fe9fe7e3.virus|
|[3a2438dd2c13c48ce7867a9ebefc9e5a](https://www.virustotal.com/gui/file/3a2438dd2c13c48ce7867a9ebefc9e5a)|PDF||2020-03-19 17:42:01|3a2438dd2c13c48ce7867a9ebefc9e5a.virus|
|[9ca4f31fb9707adc43d9b7e630b2cf26](https://www.virustotal.com/gui/file/9ca4f31fb9707adc43d9b7e630b2cf26)|PDF||2020-03-19 17:05:17|35d3948845.pdf|
|[fb525e13cb82ea91b9d7576e3078674c](https://www.virustotal.com/gui/file/fb525e13cb82ea91b9d7576e3078674c)|PDF||2020-03-18 17:51:31|fb525e13cb82ea91b9d7576e3078674c.virus|
|[dc0d41af833054bc8fd6fa3894fed188](https://www.virustotal.com/gui/file/dc0d41af833054bc8fd6fa3894fed188)|PDF||2020-03-18 16:30:30|7ed0de28.pdf|
|[e7fab8e420dd74157bc4dcc5ab396dc8](https://www.virustotal.com/gui/file/e7fab8e420dd74157bc4dcc5ab396dc8)|Win32 EXE|Fareit|2020-03-18 03:10:02|INKAMINERETUNA|
|[8a228725fe66ab52a62eb44687ad0680](https://www.virustotal.com/gui/file/8a228725fe66ab52a62eb44687ad0680)|Win32 EXE|Nanobot|2020-03-18 02:00:00|apisetschema.exe|
|[19fda4048f29fbf6e0c9e0a4b8bd0946](https://www.virustotal.com/gui/file/19fda4048f29fbf6e0c9e0a4b8bd0946)|PDF|PhishingSite|2020-03-17 23:59:35|fef686a7addb46744c7940c50f65fe99227791d4c442a0fcd6b7c07ec6087a6f.bin|
|[c1d8966fa1bd7aee41b2c4ad731407d3](https://www.virustotal.com/gui/file/c1d8966fa1bd7aee41b2c4ad731407d3)|unknown||2020-03-17 19:56:57|b578a237587054f351f71bd41bede49197f77a1409176f839ebde105f3aee44c.bin|
|[a61ab959038859f3a185ab688271894c](https://www.virustotal.com/gui/file/a61ab959038859f3a185ab688271894c)|PDF||2020-03-17 04:15:41|30848e3a8d825.pdf|
|[e53ce7efb47a1ea67fa8df6621f2294b](https://www.virustotal.com/gui/file/e53ce7efb47a1ea67fa8df6621f2294b)|PDF||2020-03-17 01:45:27|e53ce7efb47a1ea67fa8df6621f2294b.virus|
|[98051bcea1ec152a80c6acaa4e46a069](https://www.virustotal.com/gui/file/98051bcea1ec152a80c6acaa4e46a069)|PDF||2020-03-16 21:14:31|98051bcea1ec152a80c6acaa4e46a069.virus|
|[13c26ea1dc3a2fee403a7913f6f66c03](https://www.virustotal.com/gui/file/13c26ea1dc3a2fee403a7913f6f66c03)|ZIP|Adwind|2020-03-16 12:41:59|a0429e87a6ac0e2f0a4067dbd88fef53c94bfce7b46959d31031e37612f58f85.bin|
|[3382348f9618058dde3aacffcb34982e](https://www.virustotal.com/gui/file/3382348f9618058dde3aacffcb34982e)|Android|Hqwar|2020-03-16 03:59:41|f57a44bec2f7af2da443f068edb0a743f9625ac3a9d686393bacb8e72274b5de.bin|
|[f908dc8852f659dd43a8dc25f3d74c2e](https://www.virustotal.com/gui/file/f908dc8852f659dd43a8dc25f3d74c2e)|PDF||2020-03-15 18:05:48|f908dc8852f659dd43a8dc25f3d74c2e.virus|
|[660159f431b5f8ec8c4fed0298168d1a](https://www.virustotal.com/gui/file/660159f431b5f8ec8c4fed0298168d1a)|Android||2020-03-15 15:25:28|avist.apk|
|[62a5677e30343bc14078b97148d67036](https://www.virustotal.com/gui/file/62a5677e30343bc14078b97148d67036)|PDF||2020-03-15 12:51:26|zodezipepikibut.pdf|
|[71b3db4cf0a03c8650c140e023a06793](https://www.virustotal.com/gui/file/71b3db4cf0a03c8650c140e023a06793)|PDF||2020-03-15 12:51:21|boxupobepirolot.pdf|
|[21a51a834372ab11fba72fb865d6830e](https://www.virustotal.com/gui/file/21a51a834372ab11fba72fb865d6830e)|LNK||2020-03-15 10:34:04|C:\Users\Administrator\AppData\Local\Temp\covid.pdf.lnk|
|[bb512de5decd3a2428407660ff57678c](https://www.virustotal.com/gui/file/bb512de5decd3a2428407660ff57678c)|PDF||2020-03-15 08:50:37|bb512de5decd3a2428407660ff57678c.virus|
|[a89607c9515caeb1d784439a1ee1f208](https://www.virustotal.com/gui/file/a89607c9515caeb1d784439a1ee1f208)|ZIP||2020-03-15 08:04:19|covid.zip|
|[2e1ea39e25dde32a9a36078ac59db814](https://www.virustotal.com/gui/file/2e1ea39e25dde32a9a36078ac59db814)|PDF|Hoax|2020-03-13 01:01:56|1de32bad3cdc8ef.pdf|
|[1e85dd017cd9f9d856e5943e8824009e](https://www.virustotal.com/gui/file/1e85dd017cd9f9d856e5943e8824009e)|PDF||2020-03-12 21:25:05|1e85dd017cd9f9d856e5943e8824009e.virus|
|[595149b8dcab35fde269a86d0bd74756](https://www.virustotal.com/gui/file/595149b8dcab35fde269a86d0bd74756)|Win32 EXE||2020-03-12 17:13:54|437fa296f078bbef6cc0db8a284f040674ff70048d89f0e2878044053cc6cf34.bin|
|[45a0797b74db206615e92050ecf7b31e](https://www.virustotal.com/gui/file/45a0797b74db206615e92050ecf7b31e)|Win32 EXE||2020-03-12 09:11:43|OCTAVICROADW|
|[3bc7a303e48a39b0582cb6aa888b6f49](https://www.virustotal.com/gui/file/3bc7a303e48a39b0582cb6aa888b6f49)|PDF||2020-03-11 21:11:55|3bc7a303e48a39b0582cb6aa888b6f49.virus|
|[c9184430cfd1e72ff9213e67f73b06c2](https://www.virustotal.com/gui/file/c9184430cfd1e72ff9213e67f73b06c2)|Win32 EXE|Disfa|2020-03-11 18:54:24|/1/1/d/1d8eef52ad178c5ff2344ec0d821b796686d5a35a303bd0656b8506a5efaa271.file|
|[ec517204fbcf7a980d137b116afa946d](https://www.virustotal.com/gui/file/ec517204fbcf7a980d137b116afa946d)|Win32 EXE||2020-03-11 18:29:42|%TEMP%\wgrtjwg.exe|
|[0a648ccc4c7ce4f4315adc22878c49c2](https://www.virustotal.com/gui/file/0a648ccc4c7ce4f4315adc22878c49c2)|TXT|Banload|2020-03-11 16:51:07|dd4e0a45af01b740dd516db513e8eccc47b7c7efc8da10fc9ce05029118459a6.bin|
|[fd648c3b7495abbe86b850587e2e5431](https://www.virustotal.com/gui/file/fd648c3b7495abbe86b850587e2e5431)|Win32 EXE||2020-03-11 14:38:18|./KISA_dataset_2020_train/002c9e0578a8b76f626e59b755a8aac18b5d048f1cc76e2c12f68bc3dd18b124.vir|
|[83d04f21515c7e6316f9cd0bb393a118](https://www.virustotal.com/gui/file/83d04f21515c7e6316f9cd0bb393a118)|Win32 DLL||2020-03-11 14:36:25|OINFO12.OCX|
|[405f2f6fa2077552fa848bb740bd5ffd](https://www.virustotal.com/gui/file/405f2f6fa2077552fa848bb740bd5ffd)|Win32 EXE|Kryptik|2020-03-11 14:20:20|Official communication by Ferribiella Italy-CORONAVIRUS 11.03.2020_EN.exe|
|[4efc395c3cd44646e2bfb9680932b811](https://www.virustotal.com/gui/file/4efc395c3cd44646e2bfb9680932b811)|RTF|Sagent|2020-03-11 07:36:13|CORONA TREATMENT.doc|
|[8ff6621ecf76a5632dc7ca459f3e5a89](https://www.virustotal.com/gui/file/8ff6621ecf76a5632dc7ca459f3e5a89)|DOCM|Sagent|2020-03-10 03:11:48|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\114c8e5626d3ed69b21e3760eb61bd6764e4284bc617fca275e056705507bae6|
|[faf5ef01f4a9bf2aba7ede67dcc5a2d4](https://www.virustotal.com/gui/file/faf5ef01f4a9bf2aba7ede67dcc5a2d4)|PDF||2020-03-08 21:33:52|faf5ef01f4a9bf2aba7ede67dcc5a2d4.virus|
|[13d61974d2db537bdb0504cfc53b74a7](https://www.virustotal.com/gui/file/13d61974d2db537bdb0504cfc53b74a7)|FPX||2020-03-06 08:37:06|e3556d6ba5e705b85599b70422928165c8d4130074029a8dcd04a33f4d1aa858.bin|
|[415591d11cf6aeb940ac92c904a1f26a](https://www.virustotal.com/gui/file/415591d11cf6aeb940ac92c904a1f26a)|Win32 DLL|Zbot|2020-03-06 04:28:31|79375c0c05243354f8ba2735bcd086dc8b53af709d87da02f9206685095bb035.bin|
|[0de06292c0010a4e8f453806373e68d4](https://www.virustotal.com/gui/file/0de06292c0010a4e8f453806373e68d4)|unknown||2020-03-06 04:24:38|b62d35d8edae874a994fff12ec085a0bf879c66b3c97fd13fe0a335b497342e5.bin|
|[e5ce3207e8e7019bd0f0963956267128](https://www.virustotal.com/gui/file/e5ce3207e8e7019bd0f0963956267128)|PDF|Hoax|2020-03-05 07:10:48|c721faa015.pdf|
|[af5ce343c7e4c64319c658c87b85f9a6](https://www.virustotal.com/gui/file/af5ce343c7e4c64319c658c87b85f9a6)|PDF|Hoax|2020-03-05 06:51:23|zuxudod.pdf|
|[a4b7fe08900074b6a103d2cf36730421](https://www.virustotal.com/gui/file/a4b7fe08900074b6a103d2cf36730421)|LNK||2020-03-05 05:43:16|Chi Thi cua thu tuong nguyen xuan phuc.lnk|
|[60c89b54029442c5e131f01ff08f84c9](https://www.virustotal.com/gui/file/60c89b54029442c5e131f01ff08f84c9)|RAR||2020-03-05 03:12:57|Chi Thi cua thu tuong nguyen xuan phuc.rar|
|[0f794d6c6646a260558e9d638ae060c9](https://www.virustotal.com/gui/file/0f794d6c6646a260558e9d638ae060c9)|LNK||2020-03-04 04:10:36|C:\Users\Administrator\AppData\Local\Temp\03-01-1.lnk|
|[24af885e38d7ca7912824f2470e5e6be](https://www.virustotal.com/gui/file/24af885e38d7ca7912824f2470e5e6be)|RAR||2020-03-04 01:36:37|03-01-1.rar|
|[002e017b97eda9eaae523a0a9a518d84](https://www.virustotal.com/gui/file/002e017b97eda9eaae523a0a9a518d84)|PDF||2020-03-03 03:10:12|002e017b97eda9eaae523a0a9a518d84.virus|
|[26b95d45df0744d11cf1d91f5629ba87](https://www.virustotal.com/gui/file/26b95d45df0744d11cf1d91f5629ba87)|PDF||2020-03-03 02:45:34|tavojetejelora.pdf|
|[2d79034d853b32423b1e06c3f27bfc61](https://www.virustotal.com/gui/file/2d79034d853b32423b1e06c3f27bfc61)|PDF||2020-03-03 02:10:21|2d79034d853b32423b1e06c3f27bfc61.virus|
|[0fb5cc4ac25234239d291e40b47c98d3](https://www.virustotal.com/gui/file/0fb5cc4ac25234239d291e40b47c98d3)|PDF|Hoax|2020-03-02 21:55:45|0fb5cc4ac25234239d291e40b47c98d3.virus|
|[fc00964131a8c9407ba77484e724fc9d](https://www.virustotal.com/gui/file/fc00964131a8c9407ba77484e724fc9d)|LNK||2020-02-27 07:04:47|02-21-1.lnk|
|[a0d41e87bf259ce882c4977d79fa806a](https://www.virustotal.com/gui/file/a0d41e87bf259ce882c4977d79fa806a)|RAR||2020-02-27 04:24:18|02-21-1.rar|
|[f59c558d9b33a25ac8b32f495f6fd035](https://www.virustotal.com/gui/file/f59c558d9b33a25ac8b32f495f6fd035)|Win32 EXE|Remcos|2020-02-24 02:33:53|C:\Users\Administrator\AppData\Local\Temp\POEA HEALTH ADVISORY re-2020 Novel Corona Virus.pdf.exe|
|[fc20439e60e168f7bc5b1afd0a31e015](https://www.virustotal.com/gui/file/fc20439e60e168f7bc5b1afd0a31e015)|PDF||2020-02-23 13:50:17|fc20439e60e168f7bc5b1afd0a31e015.virus|
|[b0ef3735aaf9ea9de69848d7131c6942](https://www.virustotal.com/gui/file/b0ef3735aaf9ea9de69848d7131c6942)|PDF||2020-02-23 13:25:27|877a488accdb8fff30cdd1e810d2c0762384726d8086b768076fc03dd0f0d51b.bin|
|[a0045f26111de6b079dc0bffd5aef4e6](https://www.virustotal.com/gui/file/a0045f26111de6b079dc0bffd5aef4e6)|PDF|PhishingSite|2020-02-22 05:50:56|8985979.pdf|
|[4b30f50d1a8f8c12bca8fd436c1469fd](https://www.virustotal.com/gui/file/4b30f50d1a8f8c12bca8fd436c1469fd)|PDF||2020-02-22 05:30:48|4b30f50d1a8f8c12bca8fd436c1469fd.virus|
|[b3f496ce13ff6fed1048399e1fc89403](https://www.virustotal.com/gui/file/b3f496ce13ff6fed1048399e1fc89403)|PDF|Banload|2020-02-21 21:25:59|b3f496ce13ff6fed1048399e1fc89403.virus|
|[7b4a3d320a888059a6328a61f21d9095](https://www.virustotal.com/gui/file/7b4a3d320a888059a6328a61f21d9095)|PDF||2020-02-21 19:05:36|7b4a3d320a888059a6328a61f21d9095.virus|
|[8bd336d4dcdc4f45a9a5c72d5791f6a8](https://www.virustotal.com/gui/file/8bd336d4dcdc4f45a9a5c72d5791f6a8)|PDF|Hoax|2020-02-17 11:56:07|2042241.pdf|
|[55879cddb0e18c34aaa992d24690e0e7](https://www.virustotal.com/gui/file/55879cddb0e18c34aaa992d24690e0e7)|PDF|Hoax|2020-02-16 17:56:34|2a060e9d2c0a9.pdf|
|[320cde0e1b34e03f0ea393a0483b6798](https://www.virustotal.com/gui/file/320cde0e1b34e03f0ea393a0483b6798)|PDF|Hoax|2020-02-16 13:46:19|320cde0e1b34e03f0ea393a0483b6798.virus|
|[b08dc707dcbc1604cfd73b97dc91a44c](https://www.virustotal.com/gui/file/b08dc707dcbc1604cfd73b97dc91a44c)|XLSM|CVE-2017-8570|2020-02-05 13:39:39|fc7c04af29790f0e7240770dcea60ac8fbeb51e2827ae284481845d7bd8bc978.bin|
|[3519b57181da2548b566d3c49f2bae18](https://www.virustotal.com/gui/file/3519b57181da2548b566d3c49f2bae18)|DOCX|o97m|2020-02-05 09:35:51|C:\Users\ttzaf\Google Drive\M.Sc\Jupiter_N_Projects\Research\Paper_02\2nd_paper_Data\DOCX\Malicious\Malicious_DOCX_14916_Merged_on_18_06_2020\Malicious_Raw_Attachments\1\32bf0fcc3145d58baa9fcb092a756ca8aa8aee3fa2f7ffd3e87943920df75b0f|
|[1557d751b7a760a39ec743e27ad2af58](https://www.virustotal.com/gui/file/1557d751b7a760a39ec743e27ad2af58)|Win32 DLL|Zbot|2020-01-27 13:31:09|1557d751b7a760a39ec743e27ad2af58.virus|
|[7b08ba75432c4e38d75fd73b2b6131bf](https://www.virustotal.com/gui/file/7b08ba75432c4e38d75fd73b2b6131bf)|Win32 DLL|Zbot|2020-01-21 08:12:32|hex.dll|
|[9d011c5386747b0dc0e7433e33cf733f](https://www.virustotal.com/gui/file/9d011c5386747b0dc0e7433e33cf733f)|Win32 DLL|Zbot|2020-01-19 17:36:34|%HOME%\unpack\AAM UpdatesHtA\hex.dll|
|[eafaba7898e149895b36ee488e3d579c](https://www.virustotal.com/gui/file/eafaba7898e149895b36ee488e3d579c)|Win32 DLL|Zbot|2020-01-18 05:32:48|eafaba7898e149895b36ee488e3d579c.virus|
|[b061d981d224454ffd8d692cf7ee92b7](https://www.virustotal.com/gui/file/b061d981d224454ffd8d692cf7ee92b7)|Win32 DLL|Zbot|2020-01-12 08:03:33|C:\Users\<USER>\AppData\Local\Temp\hex.dll|
|[52458a05108d930be7e1a009e1de3c9e](https://www.virustotal.com/gui/file/52458a05108d930be7e1a009e1de3c9e)|Win32 DLL|Zbot|2019-12-08 09:36:21|52458a05108d930be7e1a009e1de3c9e.virus|
|[e5c1203db93533740298de22581762d6](https://www.virustotal.com/gui/file/e5c1203db93533740298de22581762d6)|Win32 DLL||2019-11-22 08:22:58|hex.dll|
|[8fb95eb3fde30ed58829d49b62b77f40](https://www.virustotal.com/gui/file/8fb95eb3fde30ed58829d49b62b77f40)|Win32 DLL|Zbot|2019-03-21 06:11:59|hex.dll|
|[28c6f235946fd694d2634c7a2f24c1ba](https://www.virustotal.com/gui/file/28c6f235946fd694d2634c7a2f24c1ba)|Win32 EXE||2014-02-22 20:24:11|EHttpSrv.exe|
|[371e896d818784934bd1456296b99cbe](https://www.virustotal.com/gui/file/371e896d818784934bd1456296b99cbe)|Win32 EXE||2009-05-04 03:32:06|OInfoP12|
