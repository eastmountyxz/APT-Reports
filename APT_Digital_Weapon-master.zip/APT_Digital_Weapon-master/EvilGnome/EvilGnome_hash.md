|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[997a43976b11604836798045827648a6](https://www.virustotal.com/gui/file/997a43976b11604836798045827648a6)|sh script|shell|2019-07-04 10:54:28|setup.sh|
|[dcfc3cb0ca5ea83d835af6979a9b85c1](https://www.virustotal.com/gui/file/dcfc3cb0ca5ea83d835af6979a9b85c1)|ELF executable||2019-07-04 10:54:22|gnome-shell-ext|
|[9605cde5a7482e591c03bd24ab219154](https://www.virustotal.com/gui/file/9605cde5a7482e591c03bd24ab219154)|sh script|shell|2019-07-04 10:54:20|gnome-shell-ext.sh|
