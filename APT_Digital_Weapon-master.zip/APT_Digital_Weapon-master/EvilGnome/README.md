**NAME:**  
EvilGnome  
  
**Description**:   
EvilGnome, discovered by Intezer, is a Linux backdoor disguised as a Gnome extension. Intezer’s investigation into EvilGnome yielded several similarities between the threat actors behind EvilGnome and Gamaredon Group
  
**References**:  
https://www.intezer.com/blog-evilgnome-rare-malware-spying-on-linux-desktop-users/ 
