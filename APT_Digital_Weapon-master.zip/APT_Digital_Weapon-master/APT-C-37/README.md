**NAME:**  
APT-C-37  
  
**Alias**  
拍拍熊
  
**Description**:   
APT-C-37, also known as Pat Bear, has launched an organized, planned, and targeted long-term uninterrupted attack against an armed organization. Both Windows and Android are the targeted systems.
Payload is delivered mainly through watering-hole attacks. One of the C2 is located in the Middle East inside the same network used by Golden Mouse.

**References**:  
http://blogs.360.cn/post/analysis-of-apt-c-37.html