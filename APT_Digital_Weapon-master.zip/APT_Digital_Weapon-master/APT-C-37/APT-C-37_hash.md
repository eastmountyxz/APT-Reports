|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[9094df33aa0d6b1dd4efaf34e91a05c4](https://www.virustotal.com/gui/file/9094df33aa0d6b1dd4efaf34e91a05c4)|TXT||2019-11-10 04:57:31|1c3f370c2dc9ff3c68fb11e33b991883c7aedc97d03b88b00870c1b2d5758c3b.bin|
|[390f975c877c2c9e10c3e564fcb1d963](https://www.virustotal.com/gui/file/390f975c877c2c9e10c3e564fcb1d963)|TXT||2019-11-08 07:45:00|dv.zip|
|[4fa306739fd3ecc75b0ee202a614061d](https://www.virustotal.com/gui/file/4fa306739fd3ecc75b0ee202a614061d)|Win32 EXE||2019-11-07 14:43:17|ae41437ded018ed2f5545731a189a85584ed8152b4a5935c0eeac669d69e4a3b.bin|
|[7bcbe8cc5a05df9fcea4e7e52bd00d79](https://www.virustotal.com/gui/file/7bcbe8cc5a05df9fcea4e7e52bd00d79)|TXT||2019-11-07 14:00:18|3ea3f1c03e5272aa37de7333a809afebc200ad473c72489fe75bb7e296959fb4.bin|
|[964e7b04a905e90821217f1c09d33e55](https://www.virustotal.com/gui/file/964e7b04a905e90821217f1c09d33e55)|TXT||2019-11-06 14:00:41|f_Skoifa.vbs|
|[6e62856152eb198b457487e1eed94d76](https://www.virustotal.com/gui/file/6e62856152eb198b457487e1eed94d76)|Win32 EXE||2019-11-05 13:15:26|اجتماع لجنة الانتخابات – إقليم الشمال .exe|
|[bf14b74f212cf642c83a34f633732b5d](https://www.virustotal.com/gui/file/bf14b74f212cf642c83a34f633732b5d)|Win32 EXE||2019-10-23 12:16:07|تعميم.exe|
|[212a1fe299b8a0b27bc02562a090b46a](https://www.virustotal.com/gui/file/212a1fe299b8a0b27bc02562a090b46a)|DOCX||2019-10-04 06:42:56|Newsaj.docx|
|[e2448384afff94f2cc825d0a6c285e35](https://www.virustotal.com/gui/file/e2448384afff94f2cc825d0a6c285e35)|Win32 EXE||2019-10-04 02:10:30|تقييم الحالة الفلسطينية 2019.exe|
|[18bbad1bb492a395a5496d0859edcb71](https://www.virustotal.com/gui/file/18bbad1bb492a395a5496d0859edcb71)|TXT||2019-09-05 20:31:51|%TEMP%\ss.vbs|
|[a2834efe87a05c87116896d281855403](https://www.virustotal.com/gui/file/a2834efe87a05c87116896d281855403)|Win32 EXE||2019-08-29 05:56:11|ccccccccvvvvvvvvvv.exe|
|[c8f9cbb347d5687be5c5b71e3ffea4aa](https://www.virustotal.com/gui/file/c8f9cbb347d5687be5c5b71e3ffea4aa)|Win32 EXE||2019-08-29 05:55:23|cccccccccc.exe|
|[0cd6e0765317b9f251670033fc296bbd](https://www.virustotal.com/gui/file/0cd6e0765317b9f251670033fc296bbd)|DOCX||2019-08-27 08:50:24|news.docx|
|[45e8c947b0ab082d3facab579aefda2a](https://www.virustotal.com/gui/file/45e8c947b0ab082d3facab579aefda2a)|Win32 EXE||2019-08-27 04:15:53|zzz.exe|
|[0992b87c510d4cd135e02e432fcb492b](https://www.virustotal.com/gui/file/0992b87c510d4cd135e02e432fcb492b)|ZIP||2019-08-26 10:50:11|=?UTF-8?B?2YHYttmK2K3YqSDYrNiv2YrYr9ipINmE2KPYrdivINmC2YrYp9iv2KfYqiDYrdmF2KfYsy56aXA=?=|
|[391a60cee3caee78a4d2dc62ceb4b87e](https://www.virustotal.com/gui/file/391a60cee3caee78a4d2dc62ceb4b87e)|DOCX||2019-08-09 07:29:19|bian.docx|
|[8b1371c992e14533c950e6ddf265deba](https://www.virustotal.com/gui/file/8b1371c992e14533c950e6ddf265deba)|Text||2019-08-08 10:53:28|down2|
|[d18c3c09869559591e7251ac321091ce](https://www.virustotal.com/gui/file/d18c3c09869559591e7251ac321091ce)|Text||2019-08-08 10:53:11|down|
|[74ef1c5905200ea664a603a67554422b](https://www.virustotal.com/gui/file/74ef1c5905200ea664a603a67554422b)|Win32 EXE||2019-08-08 09:54:27|=?UTF-8?B?2KjZitin2YYg2LnYp9im2YTYqSDYsdi22YjYp9mGLmV4ZQ==?=|
|[4333a9e5d6de6e12b368f5a943a30a0e](https://www.virustotal.com/gui/file/4333a9e5d6de6e12b368f5a943a30a0e)|Android||2019-02-16 12:27:25|/1/0/9/0947f155f80b5dc1f7f396fde605c8af96bc2bf1f2b99c1818a0c20bb4088ddb.file|
|[f66d99406819ca96b47d7ff0881a0a1a](https://www.virustotal.com/gui/file/f66d99406819ca96b47d7ff0881a0a1a)|Android|Kasandra|2018-10-27 12:38:47|WhatsApp_Test (3).apk|
|[31aad6045f403fcd397e19cad4f80d1f](https://www.virustotal.com/gui/file/31aad6045f403fcd397e19cad4f80d1f)|Android|Kasandra|2018-10-25 15:04:35|WhatsApp_Test (2).apk|
|[b87f516b2ee0e6df09510f75b16c25ef](https://www.virustotal.com/gui/file/b87f516b2ee0e6df09510f75b16c25ef)|Android|Kasandra|2018-10-25 14:57:28|WhatsApp_Test.apk|
|[1daf7e38d8d918e8e087ad590b299218](https://www.virustotal.com/gui/file/1daf7e38d8d918e8e087ad590b299218)|Android||2018-10-23 11:37:05|1.apk|
|[484d74ebd0e3586e2ff694017dcaa9e3](https://www.virustotal.com/gui/file/484d74ebd0e3586e2ff694017dcaa9e3)|Android|Kasandra|2018-06-28 00:09:54|FlashPlayer.apk|
|[1d5e36be4b94289f214447964ede688d](https://www.virustotal.com/gui/file/1d5e36be4b94289f214447964ede688d)|Android|Kasandra|2017-10-21 16:30:49|altb_alnabawe.apk|
|[7d50a9bd474a7c5878ac8e0e4a183a8b](https://www.virustotal.com/gui/file/7d50a9bd474a7c5878ac8e0e4a183a8b)|Android||2017-10-13 16:41:46|Sawarim.apk|
|[b7d12ab736b41d503e93a0bd6125cf62](https://www.virustotal.com/gui/file/b7d12ab736b41d503e93a0bd6125cf62)|Android|Kasandra|2017-09-23 23:38:44|b7d12ab736b41d503e93a0bd6125cf62.virus|
|[bb2d1238c8418cde13128e91f1a77ae7](https://www.virustotal.com/gui/file/bb2d1238c8418cde13128e91f1a77ae7)|Android||2017-09-05 15:10:38|Sawarim.apk|
|[80382a7f2eb4f292a28554bc95b57938](https://www.virustotal.com/gui/file/80382a7f2eb4f292a28554bc95b57938)|Android||2017-08-17 22:58:55|232071434.apk|
|[bef2dddd8892a4985879971cf437d79b](https://www.virustotal.com/gui/file/bef2dddd8892a4985879971cf437d79b)|Android|Kasandra|2017-07-26 02:31:08|bef2dddd8892a4985879971cf437d79b.virus|
|[a41c5f227ac2816355ce4cf650993749](https://www.virustotal.com/gui/file/a41c5f227ac2816355ce4cf650993749)|Android|Kasandra|2017-07-19 02:25:13|a41c5f227ac2816355ce4cf650993749.virus|
|[71d0cea1bee13d1e36b5a53788001b85](https://www.virustotal.com/gui/file/71d0cea1bee13d1e36b5a53788001b85)|Android|Kasandra|2017-07-19 02:21:59|71d0cea1bee13d1e36b5a53788001b85.virus|
|[51f7d6fec2be62fc29cfb94f52803428](https://www.virustotal.com/gui/file/51f7d6fec2be62fc29cfb94f52803428)|Android|Kasandra|2017-06-18 02:27:26|51f7d6fec2be62fc29cfb94f52803428.virus|
|[dc1ede8e2d3206b04cb95b6ae62f43e0](https://www.virustotal.com/gui/file/dc1ede8e2d3206b04cb95b6ae62f43e0)|Android|Kasandra|2017-06-08 03:31:22|myfile.exe|
|[1eb8e8667ed7d2a07076e3d240207613](https://www.virustotal.com/gui/file/1eb8e8667ed7d2a07076e3d240207613)|Android|Kasandra|2017-06-03 02:21:37|1eb8e8667ed7d2a07076e3d240207613.virus|
|[6d6961ced0e77c28f881db579301a927](https://www.virustotal.com/gui/file/6d6961ced0e77c28f881db579301a927)|Win32 EXE||2017-05-15 18:56:10|sys64.exe|
|[d52f57b6597e55c40c21b0f8c763cd69](https://www.virustotal.com/gui/file/d52f57b6597e55c40c21b0f8c763cd69)|unknown||2017-05-13 10:16:01|Adobe_FlashPlayer_installX86.vbs|
|[e6e676df8250a7b930b2d016458225e2](https://www.virustotal.com/gui/file/e6e676df8250a7b930b2d016458225e2)|Win32 EXE|MSILPerseus|2017-05-10 16:11:47|client.exe|
|[ba1249123e808e744aeb96753bc119d4](https://www.virustotal.com/gui/file/ba1249123e808e744aeb96753bc119d4)|Win32 EXE|MSILPerseus|2017-05-10 13:24:46|client.exe|
|[d9153bdf30e0a3ab31601e43d85c9949](https://www.virustotal.com/gui/file/d9153bdf30e0a3ab31601e43d85c9949)|Win32 EXE|Quasar|2017-05-10 00:00:19|SystemIU.exe|
|[d2c40e2183cf18855c36ddd14f8e966f](https://www.virustotal.com/gui/file/d2c40e2183cf18855c36ddd14f8e966f)|Win32 EXE|Quasar|2017-05-10 00:00:07|Adobe_FlashPlayerX86_64.exe.exe|
|[8c49833f76b17fdaafe5130f249312ca](https://www.virustotal.com/gui/file/8c49833f76b17fdaafe5130f249312ca)|Win32 EXE|Quasar|2017-05-09 14:41:53|Client.exe|
|[1a655affc8d5fffa48915a934f31f95e](https://www.virustotal.com/gui/file/1a655affc8d5fffa48915a934f31f95e)|Win32 EXE|Disfa|2017-05-09 13:22:16|Stub.exe|
|[98d584d4d575e31f9f4f70c9be05166f](https://www.virustotal.com/gui/file/98d584d4d575e31f9f4f70c9be05166f)|Android|Kasandra|2017-03-29 21:19:31|FlashPlayer.apk|
|[8bb342a3e770717bd8f39ac12a687b54](https://www.virustotal.com/gui/file/8bb342a3e770717bd8f39ac12a687b54)|Win32 EXE|Disfa|2017-03-29 19:08:36|FlashPlayer_x86.exe|
|[bfaf6389cb9fba695daa8552f697d40b](https://www.virustotal.com/gui/file/bfaf6389cb9fba695daa8552f697d40b)|Win32 EXE|injector|2017-03-27 12:14:17|SysSettings.exe x64|
|[085e195c9b14ef099171805c44ff4914](https://www.virustotal.com/gui/file/085e195c9b14ef099171805c44ff4914)|Win32 EXE|injector|2017-03-27 12:14:17|uu.exe|
|[daf7f053cf78690ff0c6ec0384d85bf2](https://www.virustotal.com/gui/file/daf7f053cf78690ff0c6ec0384d85bf2)|Win32 EXE|injector|2017-03-27 12:14:17|java-rmi|
|[d207a876369681ed476f650d808a25a8](https://www.virustotal.com/gui/file/d207a876369681ed476f650d808a25a8)|Android|Kasandra|2017-03-07 04:14:56|d207a876369681ed476f650d808a25a8.virus|
|[2706be45411ed22ce456b8fe8273b285](https://www.virustotal.com/gui/file/2706be45411ed22ce456b8fe8273b285)|Android|Kasandra|2017-03-07 03:56:40|2706be45411ed22ce456b8fe8273b285.virus|
|[12100da4635765f8d69d684f742a47bd](https://www.virustotal.com/gui/file/12100da4635765f8d69d684f742a47bd)|Android|Kasandra|2017-02-16 19:43:52|12100da4635765f8d69d684f742a47bd.virus|
|[3751db0d511305b39601e09959491d8e](https://www.virustotal.com/gui/file/3751db0d511305b39601e09959491d8e)|Android|Kasandra|2017-02-16 19:43:30|3751db0d511305b39601e09959491d8e.virus|
|[e92651bb3ad8c5c3acf38dedb2abc2ca](https://www.virustotal.com/gui/file/e92651bb3ad8c5c3acf38dedb2abc2ca)|Android|Kasandra|2017-02-16 19:30:46|e92651bb3ad8c5c3acf38dedb2abc2ca.virus|
|[d195511307a2c5ac52bebf8a98b9dfae](https://www.virustotal.com/gui/file/d195511307a2c5ac52bebf8a98b9dfae)|Android|Kasandra|2017-01-17 15:44:12| |
|[291c3f5b9b53381283a044e337899c84](https://www.virustotal.com/gui/file/291c3f5b9b53381283a044e337899c84)|Win32 EXE|Disfa|2016-11-18 01:36:58|C:\Users\John\AppData\Roaming\scvhosts.exe|
|[ea6e187934fc1459d3b04b0898496b2c](https://www.virustotal.com/gui/file/ea6e187934fc1459d3b04b0898496b2c)|Android|Kasandra|2016-10-19 03:13:40| |
|[430a0b26cc53f7d39b8192d0b3f79837](https://www.virustotal.com/gui/file/430a0b26cc53f7d39b8192d0b3f79837)|Android|Kasandra|2016-09-07 19:35:49|hakr.apk|
|[523845736fc92ea80e9880641b768dc1](https://www.virustotal.com/gui/file/523845736fc92ea80e9880641b768dc1)|Android|Kasandra|2016-08-09 17:42:28|PlayVideo.apk|
|[c9e434e780b5bed397c543bb3264deea](https://www.virustotal.com/gui/file/c9e434e780b5bed397c543bb3264deea)|Android|Kasandra|2016-08-09 17:36:58|AndroidUpdates.apk|
|[a31f1ce49662a60daa46180d02ab6218](https://www.virustotal.com/gui/file/a31f1ce49662a60daa46180d02ab6218)|Android|Kasandra|2016-05-16 23:04:02|a31f1ce49662a60daa46180d02ab6218.virus|
|[a95d57eaaf7847a07e62c6ea0fecbfb7](https://www.virustotal.com/gui/file/a95d57eaaf7847a07e62c6ea0fecbfb7)|Android|Kasandra|2016-05-11 13:36:06|PDFReader.apk|
|[249aad5d2722b69aac7ed27c9e669c79](https://www.virustotal.com/gui/file/249aad5d2722b69aac7ed27c9e669c79)|Android|Kasandra|2016-05-09 07:17:06|249aad5d2722b69aac7ed27c9e669c79.virus|
|[1aa391db2faba21bf17c2d7a5095aca4](https://www.virustotal.com/gui/file/1aa391db2faba21bf17c2d7a5095aca4)|Android||2020-02-13 21:31:19|1aa391db2faba21bf17c2d7a5095aca4.virus|
|[ab02d61c30db30dea7653cfa10f74c91](https://www.virustotal.com/gui/file/ab02d61c30db30dea7653cfa10f74c91)|Android|Wacatac|2020-02-11 22:21:39|ab02d61c30db30dea7653cfa10f74c91.virus|
|[ff9f49df527c17ad9fbedd71665d462d](https://www.virustotal.com/gui/file/ff9f49df527c17ad9fbedd71665d462d)|Android|Kasandra|2019-12-12 02:29:28|/1/e/6/e6ca83caef862bddbcd9c1808aec074410d314f451de3fba96516107a1cb73cb.file|
