**NAME:**  
PatchWork  
  
**Alias**  
Hangover, Viceroy Tiger, 摩诃草, Dropping Elephant, MONSOON, 白象, 丰收行动, Chinastrats, Sarit, APT-C-09, PatchWork  

**Description**:   
Patchwork, also known as Hangover, is a targeted attack that has infected an estimated 2,500 machines since it was first observed in December 2015. While the group has not been definitively attributed, circumstantial evidence suggests the group may be a pro-Indian or Indian entity.
Patchwork targeted industries related to diplomatic and government agencies such as military and political assignments, especially those working on issues relating to Southeast Asia and the South China Sea. Affected systems including Windows, Android and Mac OS.
This attack group may have connection to Confucius and Bitter. Lots of exploits have been used in targeted attacks and at least one of them is 0-day.  
  
**References**:  
http://www.symantec.com/connect/blogs/patchwork-cyberespionage-group-expands-targets-governments-wide-range-industries  
https://blogs.forcepoint.com/security-labs/monsoon-analysis-apt-campaign  
https://www.cymmetria.com/patchwork-targeted-attack/
  