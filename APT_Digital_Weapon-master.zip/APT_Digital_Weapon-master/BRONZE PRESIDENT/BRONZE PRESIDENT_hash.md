|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[0d3fbc842a430f5367d480dd1b74449b](https://www.virustotal.com/gui/file/0d3fbc842a430f5367d480dd1b74449b)|Win32 EXE||2019-08-15 12:39:14|NATIONAL SECURITY CONCEPT OF MONGOLIA.exe|
|[e5a23e8a2c0f98850b1a43b595c08e63](https://www.virustotal.com/gui/file/e5a23e8a2c0f98850b1a43b595c08e63)|Win32 EXE||2019-06-13 05:08:12|DSR & CSR of Special Branch Sind.exe|
|[0617cad9e5d559356c43d4037c86227f](https://www.virustotal.com/gui/file/0617cad9e5d559356c43d4037c86227f)|Win32 DLL||2017-07-25 07:06:46|goopdate.dll|
