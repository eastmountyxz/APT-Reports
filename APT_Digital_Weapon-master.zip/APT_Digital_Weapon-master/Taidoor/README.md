**NAME:**  
Taidoor  

**Description**:   
Taidoor, an attack group disclosed by Trend Micro, has operated since at least 2009 and primarily targeted Taiwan, China. It exploits a wide variety of vulnerabilities as attack vectors in Microsoft Office and Adobe Reader.
  
**References**:  
https://www.trendmicro.de/cloud-content/us/pdfs/security-intelligence/white-papers/wp_the_taidoor_campaign.pdf