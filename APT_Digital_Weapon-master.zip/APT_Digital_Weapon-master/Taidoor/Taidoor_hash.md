|Hash|Type|Family|First_Seen|Name|
|:--|:--|:--|:--|:--|
|[c182e33cf7e85316e9dc0e13999db45e](https://www.virustotal.com/gui/file/c182e33cf7e85316e9dc0e13999db45e)|Win32 EXE|Zbot|2015-09-18 10:08:11|word.exe|
|[68bebcd9d2ad418332980a7dab71bf79](https://www.virustotal.com/gui/file/68bebcd9d2ad418332980a7dab71bf79)|Win32 EXE|Banload|2015-09-02 10:12:11|ChangeAdminPasswd.exe|
|[eca0ef705d148ff105dbaf40ce9d1d5e](https://www.virustotal.com/gui/file/eca0ef705d148ff105dbaf40ce9d1d5e)|Win32 DLL||2015-08-14 07:06:53|ExtensionDLL|
|[285de6e5d3ed8ca966430846888a56ff](https://www.virustotal.com/gui/file/285de6e5d3ed8ca966430846888a56ff)|Win32 EXE||2014-11-14 05:56:53|web_news_app.exe|
|[4438921ea3d08d0c90f2f903556967e5](https://www.virustotal.com/gui/file/4438921ea3d08d0c90f2f903556967e5)|Win32 EXE||2014-11-13 10:41:29|uptp.exe|
|[e7205c0b80035b629d80b5e7aeff7b0e](https://www.virustotal.com/gui/file/e7205c0b80035b629d80b5e7aeff7b0e)|Win32 EXE|dynamer|2014-08-02 19:47:03|php40ZnAg|
|[7ad3b2b6eee18af6816b6f4f7f7f71a6](https://www.virustotal.com/gui/file/7ad3b2b6eee18af6816b6f4f7f7f71a6)|Win32 EXE||2014-04-07 23:53:44|kav.exe1|
|[c3e6ce287d12ac39ceb24e08dc63e3b5](https://www.virustotal.com/gui/file/c3e6ce287d12ac39ceb24e08dc63e3b5)|Win32 EXE||2014-04-03 17:35:10|vti-rescan|
|[272ff690f6d27d2953fbadf75791274c](https://www.virustotal.com/gui/file/272ff690f6d27d2953fbadf75791274c)|Win32 EXE||2013-12-10 17:00:16|vti-rescan|
|[ae80f056b8c38873ab1251c454ed1fe9](https://www.virustotal.com/gui/file/ae80f056b8c38873ab1251c454ed1fe9)|Win32 EXE||2013-11-07 01:29:40|ae80f056b8c38873ab1251c454ed1fe9.exe|
|[cbde79b6ba782840db4aca46a5a63467](https://www.virustotal.com/gui/file/cbde79b6ba782840db4aca46a5a63467)|Win32 EXE||2013-07-12 05:13:14|22d7b626-164c-4424-bb0f-c6f8c73c1578.exe|
