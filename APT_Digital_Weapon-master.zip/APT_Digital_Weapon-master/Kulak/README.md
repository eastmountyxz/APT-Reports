**NAME:**  
Kulak  

**Description**:   
Kulak is reported to be a plan deployed by North Korea to develop malicious anti-virus software.  

**References**:  
https://blog.alyac.co.kr/2215
